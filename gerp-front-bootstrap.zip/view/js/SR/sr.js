/*
 * @desc    SR 모듈 공통 함수
 * @author  김준일
 * @date    2019.07.11
 * @path    /view/js/sr.js
 */
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'SR';  //모듈 코드

  //API
  module.api = {
    /* --------------------------------------------------------------------------------------------
     *  @desc           공급사 거래처 조회함수
     *  @param          - obj_partner : 공급사 파트너
     *
     *  @return         - PARTNER_CD, NM : 고객사일 경우 공급사 정보
     *                  - NULL           : 관리자일 경우
     *
     *  @ex             var obj_fn_partner = get_fn_partner(dewself.s_partner_cd);
     * ------------------------------------------------------------------------------------------*/
    get_fn_partner: function (obj_partner) {
      var return_data = null;
      dews.api.get(dews.url.getApiUrl("SR", "SrCommonService", "get_fn_partner"), {
        async: false,
        data: {}
      }).done(function (data) {
        if(data && data.length > 0){
          // 공급사(고객사)일 경우
          return_data = data[0];

          var partner_cd_data = {
            PARTNER_CD : return_data.PARTNER_CD,
            PARTNER_NM : return_data.PARTNER_NM,
          }
          obj_partner.setData(partner_cd_data);
          obj_partner.enable(false);
        } else {
          // 관리자일 경우
          obj_partner.enable(true);
        }
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });
      return return_data;
    },

    /* --------------------------------------------------------------------------------------------
     *  @desc           SRM환경설정정보 전체 정보 조회함수
     *  @param          - p_partner_cd : [필수]공급사코드
     *
     *  @return         SR_CTRLCONFIG_MST 테이블의 CD, VR 데이터 조회.
     *
     *  @ex             var ctrl_vr = getCodeData(dewself.s_partner_cd.code());
     * ------------------------------------------------------------------------------------------*/
    getSrCodeData : function (p_partner_cd) {
      var objCodeDtl = [];
      if(!p_partner_cd){
        console.error("srJs - getCodeData 함수의 'p_partner_cd' 파라미터가 부족합니다.");
        return [];
      } else{
        dews.api.get(dews.url.getApiUrl("SR", "SrCommonService", "get_code_data"), {
          async: false,
          data: {
            partner_cd : p_partner_cd
          }
        }).done(function (data) {
          if (data.length > 0) {
            $.each(data, function (i, obj) {
              // objCodeDtl[obj.CTRL_CD] = [];
              objCodeDtl.push(obj);
              // tmpCdField = obj.CTRL_CD;
            });
          } else {
          }
        }).fail(function (xhr, status, error) {
          dews.error(error);
        });
      }
      return objCodeDtl;
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc           SRM환경설정정보 조회함수
     *  @param          - p_adminFlg : true(관리자), false(고객사)
     *                  - p_partner_cd : 공급사코드
     *
     *  @return         Y    : 특정필드를 보여준다.
     *                  N    : 특정필드를 숨긴다.
     *                  NULL : SRM환경설정 메뉴에서 사용여부를 설정하라는 경고창을 보여준다.
     *                  ### 관리자 계정으로 최초 화면을 열 경우 'Y'값 리턴 ###
     *
     *  @ex             var ctrl_vr = get_fn_settingInfo(true, dewself.s_partner_cd.code());
     * ------------------------------------------------------------------------------------------*/
    get_fn_settingInfo : function (p_adminFlg, p_partner_cd, p_ctrl_var) {
      var return_data = null;
      dews.api.get(dews.url.getApiUrl("SR", "SrCommonService", "get_fn_settingInfo"), {
        async: false,
        data: {
          admin_flg : p_adminFlg,
          partner_cd : p_partner_cd,
          ctrl_var : p_ctrl_var
        }
      }).done(function (data) {
        return_data = data;
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });

      return return_data;
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc           SRM환경설정정보에 따른 컬럼설정 함수
     *  @param          - p_ctrl_vr : 'Y', 'N', NULL
     *                  - obj_grid  : 적용할 그리드
     *                  - p_column  : 적용할 컬럼명
     *
     *  @return
     *  @ex             chg_fn_GridColumn('Y', mstGrid, 'SUPPLIERITEM_CD');
     * ------------------------------------------------------------------------------------------*/
    chg_fn_GridColumn : function(p_ctrl_vr, obj_grid, p_column){
      // 초기화
      obj_grid.showColumn(p_column);

      if(p_ctrl_vr == 'N'){
        obj_grid.hideColumn(p_column);
      } else if(p_ctrl_vr == undefined || p_ctrl_vr == null || p_ctrl_vr == ''){
        dews.alert('SRM환경설정이 설정되지 않았습니다.' + '\n' + '공급사품목 사용여부를 설정하세요.', "warning").done(function () {});
      }
    }
  }

  /*********************************************************************************************
  *  @desc  js파일 상속
  *  @param {Object} targetJS [필수] js 객체 변수
  *  @ex
  * ------------------------------------------------------------------------------------------*/
   module.extendJS = function(targetJS){
    $.each(Object.keys(targetJS), function(idx, key){
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
        겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName){
        if(keyArr.indexOf(kName) >= 0){
          console.error("js 상속중 동일한 메소드 명이 존재합니다 - ", (key + '.' + kName));
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  }

  // ma.scm.js 상속
  var scmJS;
  dews.ajax.script('~/view/js/MA/ma.scm.js', {
    once: true,
    async: false
  }).done(function() {
    scmJS = gerp.MA;
  });

  module.extendJS(scmJS);

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=view/js/sr.js
