/*********************************************************************************************
 * @desc    MRO 공통 함수
 * @date    2022.12.13
 * @path    /view/js/MA/ma.mro.js
 * @update  2022.12.13 최초작성
**********************************************************************************************/
(function (dews, gerp, $) {
    var module = {};
    var moduleCode = 'MA';

    module.com = {
    /*********************************************************************************************
     *  @desc   더포터존 인증 토큰을 검증 및 생성하는 함수
     *  @return {Boolean} result     토큰 검증 결과
     * ------------------------------------------------------------------------------------------*/
        validateToken: function() {
            let result = false;
            if(sessionStorage.getItem('porterzone-app-token') == null || sessionStorage.getItem('porterzone-user-token') == null 
                || sessionStorage.getItem('porterzone-app-token') == "" || sessionStorage.getItem('porterzone-user-token') == "") {
                dews.api.get(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getToken'), {
                    async: false,
                }).done(function (data) {
                    if(data.length > 0) {
                        sessionStorage.setItem('porterzone-app-token', data[0].APP_TOKEN);
                        sessionStorage.setItem('porterzone-user-token', data[0].USER_TOKEN);
                        result = true;
                    }
                }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                })
            } else {
                result = true;
            }
            return result;
        },

    /*********************************************************************************************
     *  @desc   더포터존 담당자 등록 상태를 검증하는 함수
     *  @param  {Object} companyCode ERP10 회사코드
     *  @param  {Object} userId     ERP10 회원ID
     *  @return {Boolean} result     유효성 검증 결과
     * ------------------------------------------------------------------------------------------*/
        validateAdminUser : function(companyCode, userId) {
            let result = false;
            if (module.com.validateToken()) {   // 앱토큰, 사용자토큰 모두 존재할때만 수행
                dews.api.post(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'validationCheck'), {
                    async: false,
                    data: {
                        companyCode: companyCode,
                        userId: userId,
                        userToken: sessionStorage.getItem('porterzone-user-token')
                    }
                }).done(function (data) {
                    let res = data[0];
                    if(res.checkResult != 'SUCCESS') {
                        if (res.checkResult === 'NOT_REGIST_MANAGER') {
                            dews.confirm('담당자로 지정되었지만\n아직 회원가입 하지 않으셨습니다.\n회원가입을 진행 하시겠습니까?').yes(function (e) {
                                module.com.callAdminModule(companyCode, empCode);
                            });
                        } else {
                            let invalidMessage = "";
                            switch (res.checkResult) {
                                case 'NOT_REGIST_COMPANY':
                                    invalidMessage = '가입되지 않은 회사입니다.';
                                    break;
                                case 'NOT_EXIST_MANAGER':
                                    invalidMessage = '담당자가 공석입니다.';
                                    break;
                                case 'NOT_EXIST_BASE_WORKPLACE':
                                    invalidMessage = '사업장이 등록되지 않았습니다.';
                                    break;
                                case 'NOT_MANAGER':
                                    invalidMessage = '담당자로 지정된 계정이 아닙니다.';
                                    break;
                                case 'FAIL':
                                    invalidMessage = '담당자 정보를 확인하는 중 오류가 발생했습니다.';
                                    break;
                            }
                            dews.ui.snackbar.warning(invalidMessage + ' 관리자에게 문의하세요.');
                        }
                    } else {
                        result = true;
                    }
                }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                });
            }
            return Boolean(result);
        },
        /*********************************************************************************************
         *  @desc   더포터존 담당자 회원 가입 다이얼로그 호출
         *  @param  {Object} companyCode ERP10 회사코드
         *  @param  {Object} empCode     ERP10 회원ID
         * ------------------------------------------------------------------------------------------*/
        callAdminModule : function(companyCode, empCode) {
            let requestUrl = `http://support.douzonebnf.net/members/popup/apply-manager/manager?memberId=${empCode}?cno=${companyCode}`;
            let xPos = (document.body.offsetWidth / 2) - (1055 / 2);     // 가로 가운데 정렬
            xPos += window.screenLeft;                                  // 듀얼 모니터일 때의 정렬
            let yPos = (document.body.offsetHeight / 2) - (804 / 2);    // 세로 가운데 정렬
            yPos += (window.screenTop / 2);                             // 듀얼 모니터일 때의 정렬
            const options = `top=${yPos}, left=${xPos}, width=1054, height=804, status=no, menubar=no, toolbar=no, resizable=no, location=no, scrollbars=no`; // (필수)
            window.open(requestUrl, 'signinModule', options);      // (필수)
        },

        /*********************************************************************************************
         *  @desc   더포터존 결제 다이얼로그 호출
         *  @param  {Object} orderId    더포터존 주문번호 (MA_MROORD_MST.ORD_NO)
         * ------------------------------------------------------------------------------------------*/
        callPaymentModule : function(orderId) {
            let requestUrl = `http://pay.douzonebnf.net/payment/pages?orderIds=${orderId}`;
            let xPos = (document.body.offsetWidth / 2) - (520 / 2);     // 가로 가운데 정렬
            xPos += window.screenLeft;                                  // 듀얼 모니터일 때의 정렬
            let yPos = (document.body.offsetHeight / 2) - (600 / 2);    // 세로 가운데 정렬
            yPos += (window.screenTop / 2);                             // 듀얼 모니터일 때의 정렬
            const options = `top=${yPos}, left=${xPos}, width=520, height=600, status=no, menubar=no, toolbar=no, resizable=no, location=no, scrollbars=no`; // (필수)
            window.open(requestUrl, 'paymentModule', options);      // (필수)
        },

        /*********************************************************************************************
         *  @desc   더포터존 주문취소 다이얼로그 호출
         *  @param  {Object} orderId    더포터존 주문번호 (MA_MROORD_MST.ORD_NO)
         *  @return popupObject
         *  @Description 다이얼로그 자동로그인 처리를 위해 더포터존에서 사용자 인증처리 후 리턴해주는 URL로 다이얼로그 오픈함
         * ------------------------------------------------------------------------------------------*/
        callCancleOrderModule : function(orderId) {
            let returnPopup = null;
            dews.api.get(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getCancelDialogueUrl'), {
                async: false,
                data: {
                    userToken: sessionStorage.getItem('porterzone-user-token'),
                    orderId: orderId
                }
            }).done(function (requestUrl) {
                if(requestUrl != null) {
                    let xPos = (document.body.offsetWidth / 2) - (600 / 2);     // 가로 가운데 정렬
                    xPos += window.screenLeft;                                  // 듀얼 모니터일 때의 정렬
                    let yPos = (document.body.offsetHeight / 2) - (880 / 2);    // 세로 가운데 정렬
                    yPos += (window.screenTop / 2);                             // 듀얼 모니터일 때의 정렬
                    const options = `top=${yPos}, left=${xPos}, width=600, height=880, status=no, menubar=no, toolbar=no, resizable=no, location=no, scrollbars=no`; // (필수)
                    returnPopup =  window.open(requestUrl, 'cancleOrderModule', options); 
                }
                
            }).fail(function (xhr, status, error) {
                dews.ui.snackbar.error(error);
            });

            return returnPopup;
        },

         /*********************************************************************************************
         *  @desc   회사정보와 회원정보에 대한 가입 여부 상태 검증 함수
         *  @param  {Object} company_cd,  ERP10 회사코드
         *  @param  {Object} bizArea_cd,  ERP10 사업장코드
         *  @return {Integer} result     가입여부에 따른 return message ("NOT_EXSIT", "MANAGER_EXIST", "EXIST")
         * ------------------------------------------------------------------------------------------*/
        companyExistCheck : function(company_cd, bizArea_cd) {
            let result = "";

                // 아래 발신여부 API로 회사정보와 회원정보에 대한 가입 여부 상태 검증 함수
                dews.api.post(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getExistcheck'), {
                    async: false,
                    data: {
                        company_cd : company_cd,
                        bizArea_cd : bizArea_cd
                    },
                }).done(function (data) {

                    result = data[0].value;

                }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(dews.localize.get('더포터존 가입 여부 확인에 실패하였습니다.', '', '', 'MROITM00100'));
                    console.log(error);
                });

            return result;
        },


          /*********************************************************************************************
         *  @desc   위하고에 가입된 회사인지 체크 후 가입된 회사의 정보 전송 
         *  @param  {Object} company_cd,  ERP10 회사코드
         *  @param  {Object} bizArea_cd,  ERP10 사업장코드
         *  @return {Array} result     위하고 companyData
         * ------------------------------------------------------------------------------------------*/
         wehagoCoCdChk : function(company_cd, bizArea_cd) {
            let result = "";

                // 아래 발신여부 API로 회사정보와 회원정보에 대한 가입 여부 상태 검증 함수
                dews.api.post(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getWehagoCoCd'), {
                    async: false,
                    data: {
                        company_cd : company_cd,
                        bizArea_cd : bizArea_cd
                    },
                }).done(function (data) {

                    result = data;
                    
                }).fail(function (xhr, status, error) {
                    dews.ui.loading.hide();
                    dews.ui.snackbar.error(dews.localize.get('위하고 회사코드 조회에 실패하였습니다.', ''));
                    result = [];
                });

            return result;
        },

         /*********************************************************************************************
         *  @desc   더포터존 가입된 회사인지 체크 후 가입된 회사의 정보 전송 
         *  @param  {Object} company_cd,  ERP10 회사코드
         *  @param  {Object} bizArea_cd,  ERP10 사업장코드
         *  @return {Array} result     더포터존 companyCd
         * ------------------------------------------------------------------------------------------*/
         porterJoneCoCdChk  : function(company_cd) {
            let result = "";

                // 더포터존 회사코드 가입여부 확인
                dews.api.post(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getPorterJoneCoCd'), {
                    async: false,
                    data: {
                        companyCode: company_cd,
                        appToken: sessionStorage.getItem('porterzone-app-token')
                    },
                }).done(function (data) {

                    if (data.length > 0 && data[0].wehagoCoCd != null && data[0].wehagoCoCd != "") {
                        
                        result = data[0].wehagoCoCd;
                    }

                }).fail(function (xhr, status, error) {
                    dews.ui.loading.hide();
                    dews.ui.snackbar.error(dews.localize.get('더포터존 회사코드 조회에 실패하였습니다.', ''));
                    result = "";
                });

            return result;
        },

         /*********************************************************************************************
         *  @desc   ERP10 회사코드로 더포터존에 가입된 리스트 조회
         *  @param  {Object} companyCode ERP10 회사코드
         *  @return {Integer} result 리스트 결과값   
         * ------------------------------------------------------------------------------------------*/
        companiesInfoList : function(companyCode) {
            let result = "";

            // 아래 발신여부 API로 회사정보와 회원정보에 대한 가입 여부 상태 검증 함수
            dews.api.post(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getCompaniesInfoList'), {
              async: false,
              data: {
                  companyCode: companyCode,
                  appToken: sessionStorage.getItem('porterzone-app-token'),
              },
          }).done(function (data) {

              result = data;

          }).fail(function (xhr, status, error) {
          });

            return result;
        },

        /*********************************************************************************************
         *  @desc   더포터존 회원 가입 다이얼로그 호출
         *  @param  {Object} url 선물하기 : /gift, MRO : /mro
         *  @return popupObject
         * ------------------------------------------------------------------------------------------*/
        porterzoneRegi : function(url) {

            let userTokenArray  = sessionStorage.getItem('porterzone-user-token').split('.');
            let token = userTokenArray[1];
            let signature = userTokenArray[2];
            let porterJoneUrl;


            // 아래 발신여부 API로 회사정보와 회원정보에 대한 가입 여부 상태 검증 함수
            dews.api.get(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getPorterJoneUrl'), {
                async: false,
                data: {
                    urlSort: "AUTH",
                },
            }).done(function (data) {

                porterJoneUrl = data;

            }).fail(function (xhr, status, error) {
                dews.ui.snackbar.error(dews.localize.get('더포터존 url 확인을 실패하였습니다.', '', '', 'MROITM00100'));
                console.log(error);
                return;
            });

            let requestUrl = porterJoneUrl + `/common/auth/ssoToken?token=${token}&signature=${signature}&url=${url}`;
            let xPos = (document.body.offsetWidth / 2) - (1370 / 2);     // 가로 가운데 정렬
            xPos += window.screenLeft;                                  // 듀얼 모니터일 때의 정렬
            let yPos = (document.body.offsetHeight / 2) - (890 / 2);    // 세로 가운데 정렬
            yPos += (window.screenTop / 2);                             // 듀얼 모니터일 때의 정렬

            const options = `top=${yPos}, left=${xPos}, width=1370, height=890, status=no, menubar=no, toolbar=no, resizable=no, location=no, scrollbars=no`; // (필수)
            return window.open(requestUrl, 'signinModule', options);      // (필수)

        },
        
          /*********************************************************************************************
         *  @desc   더포터존 간소화 프로세스를 위해 더포터존으로 임시저장한 사원의 데이터 여부 확인
         *  @param  {Object} clientId 
         *  @param  {Object} gEmpNo 
         *  @param  {Object} companyCode
         *  @return {Boolean} true, false
         * ------------------------------------------------------------------------------------------*/
        solutionInfoCheck : function(clienId, gEmpNo, companyCode ) {
            let result = "";

                // 아래 발신여부 API로 회사정보와 회원정보에 대한 가입 여부 상태 검증 함수
                dews.api.post(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getSolutionInfoCheck'), {
                    async: false,
                    data: {
                        gEmpNo: gEmpNo,
                        clientId: clienId,
                        companyCode: companyCode
                    },
                }).done(function (data) {

                    result = JSON.parse(data[0].value);

                }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(dews.localize.get('임시정보 저장여부 확인을 실패했습니다.', '', '', 'MROITM00100'));
                    console.log(error);
                });

            return result;
        },

         /*********************************************************************************************
         *  @desc   app-token에 대한 인증여부 확인
         *  @param  {Object} companyCode
         *  @return {Boolean} true, false
         * ------------------------------------------------------------------------------------------*/
         appTokenAuth : function(companyCode) {
            let result = false;

              // 아래 발신여부 API로 회사정보와 회원정보에 대한 가입 여부 상태 검증 함수
              dews.api.post(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'getAppTokenAuth'), {
                async: false,
                data: {
                    companyCode: companyCode,
                    appToken: sessionStorage.getItem('porterzone-app-token'),
                },
            }).done(function (data) {

                result = data;

            }).fail(function (xhr, status, error) {
                dews.ui.snackbar.error(dews.localize.get('더포터존 인증토큰 확인을 실패하였습니다.', '', '', 'MROITM00100'));
                console.log(error);
            });


            return result;
        },
           
        /*********************************************************************************************
         *  @desc   회원가입 간소화서비스를 위한 solutionInfo에 임시데이터 저장
         *  @param  {Object} arr_data
         *  @return {String} value (value 값이 넘어오면 정상)
         * ------------------------------------------------------------------------------------------*/
        solutionInfoSend : function(arr_data) {
            let result = "";

            dews.api.post(dews.url.getApiUrl('MA', 'MaintenanceRepairOperationItemService', 'solutionInfoSend'), {
                async: false,
                data: {
                    arr_data: JSON.stringify(arr_data)
                }
            }).done(function (data) {

                result = data[0].value;
            }).fail(function (xhr, status, error) {
                dews.ui.snackbar.error(dews.localize.get('더포터존 간소화 데이터 전송 중 오류가 발생했습니다.', '', '', 'MROITM00100'));
                console.log(error);
            });

            return result;
        },


    }

    var newModule = {};
    newModule[moduleCode] = module;
    window.gerp = $.extend(true, gerp, newModule);

})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=/js/MA/ma.mro.js
