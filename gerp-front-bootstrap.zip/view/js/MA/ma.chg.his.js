/*
 * 생성자 : 조숭원
 * 생성일 : 2020.02.10
 * 내용 : 변경이력현황 공통기능
*/

(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'MA'; //모듈 코드

  //기준정보설정 연동
  module.CHANGE = {


    History: function () {

      return {
        self: {},
        table_id: '',
        key_col: '',
        his_data:'',
        
        initPage: function(self, param){
          var initself = this;
          initself.self = self;
          initself.table_id = param.table_id;
          var checkHis = false;

         
          if(initself.checkChgHis(initself.table_id)){
            checkHis = true;
          }

          if(checkHis){
            var container = self.$content.find('.dews-ui-condition-panel');
            var btnGroup = container.prev();
  
            if(btnGroup.length > 0){//검색조건 상단에 buttonGroup이 있을때
              var html = '<button class="dews-ui-button dews-control k-button dews-control-activate cm-btn-checkhistory" type="button" data-dews-localize-key="" data-role="button" role="button" aria-disabled="false" tabindex="0">변경이력</button>'
              btnGroup.prepend(html);
            }
            else{//검색조건 상단에 buttonGroup이 없을때
              var html = '<div class="dews-button-group">';
              html += '<button class="dews-ui-button dews-control k-button dews-control-activate cm-btn-checkhistory" type="button" data-dews-localize-key="" data-role="button" role="button" aria-disabled="false" tabindex="0">변경이력</button>'
              html += '</div>'
              self.$content.prepend(html);
            }
  
            var $btnCtrl = self.$content.find('.cm-btn-checkhistory');
  
            $btnCtrl.on('click',function(e){
              initself.openHistoryDialog();
            });
          }
        },

        checkChgHis:function(table_id){

          var result = false;

          dews.api.get(dews.url.getApiUrl("MA", "MaCommonService", "check_change_his"), {
            async: false,
            data:{
              table_id: table_id
            }
          }).done(function (data) {
            result = data;
          }).fail(function (xhr, status, error) {
            dews.error(error || dews.localize.get(dews.localize.get('작업이 실패하였습니다.', 'M0000055')));
          });

          return result;
        },

        settingData: function(table_id, value){
          var initself = this;
          initself.table_id = table_id;
          initself.key_col = table_id.substring(0,2) == 'CI' ? '' : initself.self.user.companyCode;
          initself.his_data = value;
        },

        openHistoryDialog: function(){
          var diaself = this;
          var dialogInitData = {
            mode: 'single',
            code: 'H_CI_DOCCHGE_MST_C',
            params: {
              table_id: diaself.table_id,
              key_cd: diaself.key_col + "|" + diaself.his_data + "%"
            },
            data: null
          }
    
          var dialog = dews.ui.dialog('H_CI_DOCCHGE_MST_C', {
            url: '~/codehelp/CI/H_CI_DOCCHGE_MST_C',
            title: '변경이력',
            width: '1100',
            height: '550',
            buttons: 'applyAndClose',
            ok: function (datas) {
            }
          });
          
          dialog.setInitData(dialogInitData);
          dialog.open();
        }
      };

    }
  };  

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);

})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=ma.chg.his.js
