/*
 * @desc    SD 메시지 공통
 * @author  landameizer
 * @date    2019.07.09
 * @path    /view/js/MA/ma.scm.msg.js
 */
(function (dews, gerp, $) {

  var module = {};
  var moduleCode = "SCM"; //모듈 코드

  module.MSG =  {
    //닫기
    CLOSE_CONFIRM : '저장하지 않은 데이터가 있습니다. \n닫기를 계속하시겠습니까?',                   //종료 확인
    //조회
    SEARCH_AGAIN_CONFIRM : '저장하지 않은 데이터가 있습니다. \n조회를 계속하시겠습니까?',           //재조회 확인    
    SEARCH_NO_DATA_ALERT : '데이터가 존재하지 않습니다.',                                         //조회된 데이터 없음
    //삭제
    DELETE_CONFIRM : '삭제하시겠습니까?',                                                        //삭제 확인
    DELETE_DONE_ALERT : '삭제가 완료되었습니다.',                                                //삭제 완료    
    //저장
    SAVE_NO_DATA_ALERT : '저장할 데이터가 없습니다.',                                             //저장할 데이터 없음
    SAVE_CONFIRM : '저장하시겠습니까?',                                                           //저장 확인
    SAVE_DONE_ALERT : '저장이 완료되었습니다.',                                                   //저장 완료
    SAVE_VALID_ALERT : '필수항목을 입력하지 않았습니다.',                                          //필수값 누락
    SAVE_VALID_GRID_ALERT : '입력은 필수입니다.',                                                 //필수값 누락 (그리드)
    SAVE_EXISTENT_DATA: '이미 저장된 데이터입니다.',
    //로딩
    LOADING_SEARCH : '조회하는 중입니다.',                                                        //조회 로딩
    LOADING_SAVE : '저장하는 중입니다.',                                                          //저장 로딩
    LOADING_DELETE : '삭제하는 중입니다.',          
    //선택
    CHECK_NO_DATA_ALERT : '선택된 데이터가 없습니다.',                                            //체크된 데이터 없음    
    CHECK_CONFIRM_ALERT :'을 먼저 선택해주세요.',
    //실패
    FAIL_OPERATION_ALERT :'작업이 실패하였습니다' ,                                               //작업실패
    FAIL_DELETE_ALERT : '삭제할 수 없는 데이터입니다.',
    FAIL_SAVE_ALERT : '저장에 실패하였습니다.',
    //입력값 오류
    ERROR_VALUE_INTEGER: '정수만 입력 가능합니다.',
    ERROR_VALUE_NATURAL_NUMBER  : '0보다 큰 값을 입력해주세요.'
  }; 

  function initResource () {
    
    dews.localize.load(dews.localize.language(), 'SDCPPD00900')
    .then(function (data) {

      window.gerp.SCM.MSG  =  {
        //닫기
        CLOSE_CONFIRM : dews.localize.get('저장하지 않은 데이터가 있습니다. \n닫기를 계속하시겠습니까?', 'M0001734', dews.localize.language(), 'SDCPPD00900'),
        //조회
        SEARCH_AGAIN_CONFIRM : dews.localize.get('저장하지 않은 데이터가 있습니다. \n조회를 계속하시겠습니까?', 'M0001803', dews.localize.language(), 'SDCPPD00900'),
        SEARCH_NO_DATA_ALERT : dews.localize.get('데이터가 존재하지 않습니다.', 'M0001412', dews.localize.language(), 'SDCPPD00900'),
        //삭제
        DELETE_CONFIRM : dews.localize.get('삭제하시겠습니까?', 'M0000120', dews.localize.language(), 'SDCPPD00900'),
        DELETE_DONE_ALERT : ' ' + dews.localize.get('	삭제가 완료되었습니다.', 'M0000244', dews.localize.language(), 'SDCPPD00900'),
        //저장
        SAVE_NO_DATA_ALERT : dews.localize.get('저장할 데이터가 없습니다.', 'M0001179', dews.localize.language(), 'SDCPPD00900'),
        SAVE_CONFIRM : dews.localize.get('저장하시겠습니까?', 'M0000002', dews.localize.language(), 'SDCPPD00900'),
        SAVE_DONE_ALERT : dews.localize.get('저장이 완료되었습니다.', 'M0000021', dews.localize.language(), 'SDCPPD00900'),
        SAVE_VALID_ALERT : dews.localize.get('필수항목을 입력하지 않았습니다.', 'M0003685', dews.localize.language(), 'SDCPPD00900'),
        SAVE_VALID_GRID_ALERT : dews.localize.get('입력은 필수입니다.', 'M0003197', dews.localize.language(), 'SDCPPD00900'),
        SAVE_EXISTENT_DATA : dews.localize.get('이미 저장된 데이터입니다.', 'M0001059', dews.localize.language(), 'SDCPPD00900'),
        //로딩
        SEARCH_LOADING : dews.localize.get('조회하는 중입니다.', 'M0007041', dews.localize.language(), 'SDCPPD00900'),
        SAVE_LOADING : dews.localize.get('저장하는 중입니다.', 'M0007093', dews.localize.language(), 'SDCPPD00900'),
        DELETE_LOADING : dews.localize.get('삭제하는 중입니다.', 'M0009058', dews.localize.language(), 'SDCPPD00900'),
        //선택
        CHECK_NO_DATA_ALERT : dews.localize.get('선택된 데이터가 없습니다.', 'M0000155', dews.localize.language(), 'SDCPPD00900'),
        //실패
        FAIL_OPERATION_ALERT : dews.localize.get('작업이 실패하였습니다', 'D0027481', dews.localize.language(), 'SDCPPD00900'),
        FAIL_DELETE_ALERT : dews.localize.get('삭제할 수 없는 데이터입니다.', 'M0007300', dews.localize.language(), 'SDCPPD00900'),
        FAIL_SAVE_ALERT : dews.localize.get('저장에 실패하였습니다.', 'M0000213', dews.localize.language(), 'SDCPPD00900'),
        //입력값 오류
        ERROR_VALUE_INTEGER : dews.localize.get('정수만 입력 가능합니다.', 'M0011381', dews.localize.language(), 'SDCPPD00900'),
        ERROR_VALUE_NATURAL_NUMBER : dews.localize.get('0보다 큰 값을 입력해주세요.', 'M0011382', dews.localize.language(), 'SDCPPD00900')
      };

    }, function (err) {
      console.log(err);
    })
    ;
  }    

  initResource();


  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=ma.scm.msg.js
