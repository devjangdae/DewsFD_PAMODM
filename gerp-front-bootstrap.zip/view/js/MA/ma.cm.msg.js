/*
 * 메시지 공통
 * /view/js/MA/ma.cm.msg.js
 */
(function (dews, gerp, $) {

  var module = {};
  var moduleCode = "MA"; //모듈 코드

  module.MSG =  {
    //닫기
    CLOSE_CONFIRM : '저장하지 않은 데이터가 있습니다. \n닫기를 계속하시겠습니까?',                   //종료 확인
    //조회
    SEARCH_AGAIN_CONFIRM : '저장하지 않은 데이터가 있습니다. \n조회를 계속하시겠습니까?',           //재조회 확인
    SEARCH_NO_DATA_ALERT : '데이터가 존재하지 않습니다.',                                         //조회된 데이터 없음
    //삭제
    DELETE_CONFIRM : '삭제하시겠습니까?',                                                        //삭제 확인
    DELETE_DONE_ALERT : '	삭제가 완료되었습니다.',                                                //삭제 완료
    //저장
    SAVE_NO_DATA_ALERT : '저장할 데이터가 없습니다.',                                             //저장할 데이터 없음
    SAVE_CONFIRM : '저장하시겠습니까?',                                                           //저장 확인
    SAVE_DONE_ALERT : '저장이 완료되었습니다.',                                                   //저장 완료
    SAVE_VALID_ALERT : '필수항목을 입력하지 않았습니다.',                                          //필수값 누락
    SAVE_VALID_GRID_ALERT : '입력은 필수입니다.',                                                 //필수값 누락 (그리드)
    //로딩
    SEARCH_LOADING : '조회하는 중입니다.',                                                        //조회 로딩
    SAVE_LOADING : '저장하는 중입니다.',                                                          //저장 로딩
    DELETE_LOADING : '삭제하는 중입니다.',

    //예외처리
    PROCESS_FAIL_ALERT : '작업이 실패하였습니다.',

    //선택
    CHECK_NO_DATA_ALERT : '선택된 데이터가 없습니다.',                                              //체크된 데이터 없음

    //결산마감
    CHECK_CLOSE_STATE_ALERT : '결산마감 상태를 확인해 주십시오.'                                    //결산 마감 알림
  };

  function initResource () {

    dews.localize.load(dews.localize.language(), 'CASENV00100')
    .then(function (data) {

      window.gerp.MA.MSG  =  {
        //닫기
        CLOSE_CONFIRM : dews.localize.get('저장하지 않은 데이터가 있습니다. \n닫기를 계속하시겠습니까?', 'M0001734', dews.localize.language(), 'CASENV00100'),
        //조회
        SEARCH_AGAIN_CONFIRM : dews.localize.get('저장하지 않은 데이터가 있습니다. \n조회를 계속하시겠습니까?', 'M0001803', dews.localize.language(), 'CASENV00100'),
        SEARCH_NO_DATA_ALERT : dews.localize.get('데이터가 존재하지 않습니다.', 'M0001412', dews.localize.language(), 'CASENV00100'),
        //삭제
        DELETE_CONFIRM : dews.localize.get('삭제하시겠습니까?', 'M0000120', dews.localize.language(), 'CASENV00100'),
        DELETE_DONE_ALERT : ' ' + dews.localize.get('	삭제가 완료되었습니다.', 'M0000244', dews.localize.language(), 'CASENV00100'),
        //저장
        SAVE_NO_DATA_ALERT : dews.localize.get('저장할 데이터가 없습니다.', 'M0001179', dews.localize.language(), 'CASENV00100'),
        SAVE_CONFIRM : dews.localize.get('저장하시겠습니까?', 'M0000002', dews.localize.language(), 'CASENV00100'),
        SAVE_DONE_ALERT : dews.localize.get('저장이 완료되었습니다.', 'M0000021', dews.localize.language(), 'CASENV00100'),
        SAVE_VALID_ALERT : dews.localize.get('필수항목을 입력하지 않았습니다.', 'M0003685', dews.localize.language(), 'CASENV00100'),
        SAVE_VALID_GRID_ALERT : dews.localize.get('입력은 필수입니다.', 'M0003197', dews.localize.language(), 'CASENV00100'),
        //로딩
        SEARCH_LOADING : dews.localize.get('조회하는 중입니다.', 'M0007041', dews.localize.language(), 'CASENV00100'),
        SAVE_LOADING : dews.localize.get('저장하는 중입니다.', 'M0007093', dews.localize.language(), 'CASENV00100'),
        DELETE_LOADING : dews.localize.get('삭제하는 중입니다.', 'M0009058', dews.localize.language(), 'CASENV00100'),

        //예외처리
        PROCESS_FAIL_ALERT : dews.localize.get('작업이 실패하였습니다.', 'M0000055', dews.localize.language(), 'CASENV00100'),

        //선택
        CHECK_NO_DATA_ALERT : dews.localize.get('선택된 데이터가 없습니다.', 'M0000155', dews.localize.language(), 'CASENV00100'),

        //결산마감
        CHECK_CLOSE_STATE_ALERT : dews.localize.get('결산마감 상태를 확인해 주십시오.', 'M0012283', dews.localize.language(), 'CASENV00100')
      };

    }, function (err) {
      console.log(err);
    })
    ;
  }

  initResource();

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=ma.cm.msg.js
