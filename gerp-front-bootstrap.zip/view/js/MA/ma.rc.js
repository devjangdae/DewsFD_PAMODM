/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
 * MA 모듈 공통 함수
 * /view/js/ma.rc.js
 */
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'MA'; //모듈 코드

  //기준정보설정 연동
  module.RECORD = {

    RecordUtil: function () {

      return {
        dewself : {},
        recordDataSource : {},
        recordControlInfo : {},
        recordControlMap : {},
        recordComponent : {},
        recordKey : '',
        recordServiceURL : '',


        getDewsControl: function (node) {
          "use strict";
          var self = node;
          var dewsControl;
          var classes = node.prop("class").split(/\s+/);
          $.each(classes, function (idx, cls) {
            var controlType = "dews.ui.formpanel";
            if (cls.indexOf("dews-ui-form-") > -1) {
              controlType = "dews.ui.formpanel";
              dewsControl = eval(controlType + "(self)");
              return false;
            }else if (cls.indexOf("dews-ui-") > -1) {
              controlType = cls.replace(/-/g, ".");
              dewsControl = eval(controlType + "(self)");
              return false;
            }
          });
          return dewsControl;
        },
        initRecordControl : function(dewself, recordComponent, recordKey, recordServiceURL){

          var self = this;

          self.dewself = dewself;
          self.recordComponent = recordComponent;
          self.recordKey = recordKey;
          self.recordServiceURL = recordServiceURL;

          dews.api.get(dews.url.getApiUrl('CM', 'RecordItemService', dews.string.format('recordItem_list')), {
            async: false,
            data: {
              menu_cd: self.dewself.menu.id
            }
          }).done(function (data) {

            self.insertRecordControl(data);

          }).fail(function (xhr, satus, error) {
            dews.error(error || '작업이 실패하였습니다.');
          });
        },
        insertRecordControl : function (data) {

          var self = this;

          if (data && data.length > 0) {

            $.each(data, function (idx, item) {

              self.recordControlInfo[item.MCLS_CD] = item;

              var $targetul = self.getRecordControlTargetUl(item);

              if ($targetul && $targetul.length > 0 && item.TYPE_FG) {

                var $li = $("<li></li>");
                var $label = $("<label>" + item.MCLS_NM + "</label>");
                var $span = $("<span></span>");

                $li.append($label);
                $li.append('\n');
                $li.append($span);

                var $control = self.getRecordControlTag(item);
                $span.append($control);

                $targetul.append($li);

                var dewsControl = self.getDewsControl($control);

                self.recordControlMap[item.MCLS_CD] = $control;

                if (item.MCLS_TP === "8" && item.MNDR_YN=='N') {

                  var ds = [{ MNGD_DTL_CD: '', MNGD_NM: '' }];
                  $.each(item.items, function (index, d) {
                    ds.push({ MNGD_DTL_CD: d.MNGD_DTL_CD, MNGD_NM: d.MNGD_NM });
                  });

                  dewsControl.dataSource.data(ds);
                  dewsControl.value(item.BASE_DC);

                }
                else if(item.MCLS_TP === "8" && item.MNDR_YN=='Y') {

                  var ds = [];
                  $.each(item.items, function (index, d) {
                    ds.push({ MNGD_DTL_CD: d.MNGD_DTL_CD, MNGD_NM: d.MNGD_NM });
                  });

                  dewsControl.dataSource.data(ds);
                  dewsControl.value(item.BASE_DC);
                }

                self.dewself[item.MCLS_CD] = dewsControl;

                //---------------------------------------------------------------
                // dewsControl 에 change 이벤트를 사용하는 경우
                //---------------------------------------------------------------

                dewsControl.on('change', function (e) {

                  //2019-02-20 수정 (dews-ui-textbox // e.sender == undefined)
                  if (!e.sender) {
                    e.sender = $('#' + e.target.id);
                    e.sender.element = e.sender;
                  }

                  if (e.sender && e.sender.element.eq(0) && e.sender.element.eq(0).hasClass('mng-data')) {

                    var targetId = e.sender.element.eq(0).attr("id")
                    var val = self.getRecordControlValue(e.sender.element.eq(0));
                    var keys = self.recordKey.split("|");
                    var key = "";

                    if(keys && keys.length > 0){
                      if(keys.length == 1){
                        key = self.recordComponent.dataItem(self.recordComponent.select())[self.recordKey];
                      }else{
                        var cnt = 0;
                        for(var i=0; i<keys.length; i++){
                          if(self.recordComponent.dataItem(self.recordComponent.select())[keys[i]]){
                            key += self.recordComponent.dataItem(self.recordComponent.select())[keys[i]] + "|";
                            cnt++;
                          }
                          if(cnt > 1){
                            key = key.substring(0,key.length-1);
                          }
                        }
                      }
                    }

                    if (self.recordDataSource[key]) {
                      var ds = self.recordDataSource[key];

                      $.each(ds, function (index, item) {
                        if (item.MCLS_CD == targetId) {
                          item.CD_VALUE = val;
                          if (item.ST_ROW != 'added')
                            item.ST_ROW = (item.ST_ROW == 'nodata') ? 'added' : 'updated';
                        }
                      });
                    }
                  }
                });

                //---------------------------------------------------------------
              }
            });

            if(self.recordComponent.dataItems().length <= 0){
              readonly(true);
            }

            self.recordComponent.on('change', function(e){
              if(self.recordComponent.dataItems().length <= 0){
                readonly(true)
              }else{
                readonly(false)
              }
            });
          }

          function readonly(flag){
            $.map(self.recordControlMap, function ($control, key){
              var dewsControl = $control.data('dews-control');
              dewsControl.readonly(flag);
            });
          }
        },
        getRecordControlTargetUl : function (item) {

          var self = this;

          var $targetDiv;

          var $targetul;
          var formid = self.dewself.menu.id + "_record_form_1";

          var $tab = self.dewself.$content.find(".dews-ui-tab-panel .dews-form-panel");
          if ($tab.length == 0) {

            if (self.dewself.$content.find(".dews-ui-container-panel>.dews-container-item>.dews-ui-form-panel:last").length) {

              $targetDiv = self.dewself.$content.find(".dews-ui-container-panel>.dews-container-item>.dews-ui-form-panel:last").parent();
              formid = self.dewself.menu.id + "_record_form_1";
            }

          } else {

            var $tabcontents = self.dewself.$content.find(".dews-tab-content");

            if ($tabcontents.length < parseInt(item.TAB_FG)) {
              $targetDiv = $tabcontents.last();
              $formid = self.dewself.menu.id + "_record_form_" + $tabcontents.length.toString();
            } else {
              $targetDiv = $tabcontents.eq(parseInt(item.TAB_FG) - 1);
              formid = self.dewself.menu.id + "_record_form_" + item.TAB_FG;
            }
          }

          if ($targetDiv) {

            if ($targetDiv.find('.dews-ui-form-panel-mng').length > 0) {
              $targetul = $targetDiv.find('.dews-ui-form-panel-mng ul:last');

            } else {

              {
                var $form = $targetDiv.find('.dews-ui-form-panel:last .dews-form-panel-form:last');
                $form.addClass('dews-ui-form-panel-mng');

                var $prevul = $form.find("ul:last");
                if($prevul){
                  //$prevul.removeAttr("style");
                  $prevul.css('border-bottom', '');
                }

                $targetul = $("<ul style='border-bottom: none'></ul>");
                $form.append($targetul);


              //---------------------------------------------------------------
              // ul tag 에 change 이벤트를 사용하는 경우
              //---------------------------------------------------------------

                // $targetul.on('change', function (e) {

                //   if (e.target && $(e.target).hasClass('mng-data')) {

                //     var targetId = $(e.target).attr('id');
                //     var val = self.getRecordControlValue($(e.target));

                //     if (self.recordDataSource[self.recordComponent.dataItem(self.recordComponent.select())[self.recordKey]]) {
                //       var ds = self.recordDataSource[self.recordComponent.dataItem(self.recordComponent.select())[self.recordKey]];

                //       $.each(ds, function (index, item) {
                //         if (item.MCLS_CD == targetId) {
                //           item.CD_VALUE = val;
                //           if (item.ST_ROW != 'added')
                //             item.ST_ROW = (item.ST_ROW == 'nodata') ? 'added' : 'updated';
                //         }
                //       });
                //     }
                //   }
                // });

                //---------------------------------------------------------------

              }


              //---------------------------------------------------------------
              // form-panel 에 change 이벤트를 사용하는 경우
              //---------------------------------------------------------------
              // {
              //   var $form = $("<div class='dews-ui-form-panel dews-ui-form-panel-mng'style='border-top:none!important;'></div>");
              //   $targetul = $("<ul style='border-bottom: none'></ul>");

              //   $targetDiv.append($form);
              //   $form.append($targetul);

              //   $form.attr("id", "mngPanel" + formid);

              //   var dewsControl = self.getDewsControl($form);

              //   dewsControl.on('change', function (e) {

              //     if (e.source) {
              //       var targetId = e.$source.attr('id');
              //       var val = self.getRecordControlValue(e.$source);

              //       if (self.recordDataSource[self.recordComponent.dataItem(self.recordComponent.select())[self.recordKey]]) {
              //         var ds = self.recordDataSource[self.recordComponent.dataItem(self.recordComponent.select())[self.recordKey]];

              //         $.each(ds, function (index, item) {
              //           if (item.CD_MNG == targetId) {
              //             item.CD_VALUE = val;
              //             if (item.ST_ROW != 'added')
              //               item.ST_ROW = (item.ST_ROW == 'nodata') ? 'added' : 'updated';
              //           }
              //         });
              //       }
              //     }
              //   });

              // }
              //---------------------------------------------------------------

            }

            return $targetul;
          }
        },
        getRecordControlTag : function (item) {

          var self = this;

          var $control;

          var type2 = item.TYPE_FG.substr(0, 2);
          var type3 = item.TYPE_FG.substr(0, 3);

          if (item.MCLS_TP === "8") {
            $control = $("<select class='dews-ui-dropdownlist mng-data' data-dews-value-field='MNGD_DTL_CD' data-dews-text-field='MNGD_NM'></select>");
          }
          else {
            var len =0;

            switch (type2) {
              case "CD":
                {
                  $control = $("<input class='dews-ui-codepicker mng-data' type='text' data-target='MNGD_CD' data-target-text='MNGD_NM'>");
                }
                break;
              case "FG":
              case "NM":
              case "DC":
              case "NO":
                {
                  if(type3 == 'FG2'){
                    len = item.TYPE_FG.substr(3,item.TYPE_FG.length);
                  }else{
                    len = item.TYPE_FG.slice(2,item.TYPE_FG.length);
                  }
                  $control = $("<input type='text' class='dews-ui-textbox mng-data' data-target='MNGD_NM' maxlength='" + len + "'>");
                }
                break;
              case "DT":
                {
                  //$control = $("<input type='text' class='dews-ui-textbox mng-data' data-target='NM_MNGD'>");
                  $control = $("<input type='text' class='dews-ui-datepicker mng-data'>");

                }
                break;
              case "AM":
              case "CN":
              case "QT":
              case "UM":
                {
                  len = item.TYPE_FG.slice(4);
                  $control = $("<input type='text' class='dews-ui-numerictextbox mng-data' data-target='MNGD_VN' maxlength='19'>");
                }
                break;
              case "RT":
                {
                  $control = $("<input type='text' class='dews-ui-numerictextbox mng-data' data-target='MNGD_VN' data-dews-format='#,##0.00' maxlength='19'>");
                }
                break;
              case "TM":
                {
                  $control = $("<input type='text' class='dews-ui-timepicker mng-data'>");
                }
                break;
              default:
                if (type3 == "CNT") {
                  // len = item.TYPE_FG.slice(5);
                  len = item.TYPE_FG.substr(3,item.TYPE_FG.length);
                  $control = $("<input type='text' class='dews-ui-numerictextbox mng-data' data-target='MNGD_VN' data-dews-format='#,##0.00' maxlength='" + len + "'>");
                }
                else {
                  $control = $(dews.localize.get("<span>허용되지 않은 입력타입</span>", 'D0002719'));
                }
            }
          }

          if ($control) {
            $control.attr("id", item.MCLS_CD);

            if (item.MNDR_YN == "Y") {
              $control.addClass("required");
            }
          }

          return $control;
        },
        bindingRecordControl : function (keyValue, param, mainRowState) {

          if(!keyValue && mainRowState == 'none'){
            return;
          }

          var keys = Object.keys(param);
          for(var i=0; i<keys.length; i++) {
            if(param[keys[i]] === undefined) {
              param[keys[i]] = '';
            }
          }

          var self = this;

          if ($.type(self.recordDataSource[keyValue]) === "undefined") {
            if(!self.recordServiceURL) {
              return;
            }
            dews.api.get(self.recordServiceURL, {
              async: false,
              data: param
            }).done(function (data) {

              self.recordDataSource[keyValue] = data;

              $.each(data, function (index, item) {

                // if (self.recordItem.MNDR_YN == "Y") {
                //   if(self.recordControlMap[item.MCLS_CD].hasClass("dews-ui-dropdownlist")) {
                //     self.recordControlMap[item.MCLS_CD][0].options.remove(0);
                //   }
                // }
                var $control = self.recordControlMap[item.MCLS_CD];

                //기본값 설정은 메인데이터의 rowState가 added 인 경우에만 셋팅
                if (mainRowState == 'added' && item.ST_ROW == 'nodata') {

                  if (item.MCLS_TP == '8' && item.BASE_DC && item.BASE_DC != '') {
                    item.CD_VALUE = item.BASE_DC;
                    item.ST_ROW = "added";
                  }

                }

                self.setRecordControlValue($control, item.CD_VALUE);

              });

            }).fail(function (xhr, satus, error) {
              dews.error(error || dews.localize.get(dews.localize.get('작업이 실패하였습니다.', 'M0000055')));
            });
          } else {
            var ds = self.recordDataSource[keyValue];

            $.each(ds, function (index, item) {
              var $control = self.recordControlMap[item.MCLS_CD];
              self.setRecordControlValue($control, item.CD_VALUE);
            });
          }
        },
        setRecordControlValue : function ($control, val) {

          var self = this;

          if ($control != undefined) {
            var dewsControl = $control.data('dews-control');

            if(
              $control.hasClass("dews-ui-dropdownlist") ||
              $control.hasClass("dews-ui-numerictextbox") ||
              $control.hasClass("dews-ui-maskedtextbox") ||
              $control.hasClass("dews-ui-datepicker") ||
              $control.hasClass("dews-ui-timepicker") ||
              $control.hasClass("dews-ui-monthpicker") ||
              $control.hasClass("dews-ui-datetimepicker") ||
              $control.hasClass("dews-ui-zipcodepicker") ||
              $control.hasClass("dews-ui-combobox")
            )
            {
              dewsControl.value(val);
              // if(typeof(dewsControl.text) == "function") {
              //   dewsControl.text(dt[0].name);
              // }
            }
            else if($control.hasClass("dews-ui-textbox")) {
              //dewsControl.text(val);
              dewsControl.element.val(val); //2019-02-20 수정
            }
            // else if(
            //   $control.hasClass("dews-ui-monthperiodpicker") ||
            //   $control.hasClass("dews-ui-weekperiodpicker"))
            // {
            //   var start ="", end = "";
            //   for(var i = 0; i<dt.length; i++) {
            //     if(i==0) end = dt[i].code;
            //     else start = dt[i].code;
            //   }
            //   dewsControl.setPeriod(start, end);
            // }
            // else if($control.hasClass("dews-ui-periodpicker")) {
            //   var start ="", end = "";
            //   for(var i = 0; i<dt.length; i++) {
            //     if(i==0) end = dt[i].code;
            //     else start = dt[i].code;
            //   }
            //   dewsControl.setStartDate(start);
            //   dewsControl.setEndDate(end);
            // }

            // else if($control.hasClass("dews-ui-codepicker")) {
            //   var obj = {};
            //   obj[dewsControl.options.codeField] = dt[0].code;
            //   obj[dewsControl.options.textField] = dt[0].name;
            //   dewsControl.setData(obj);
            // }
            // else if($control.hasClass("dews-ui-multicodepicker")) {
            //   var arr = [];
            //   for(var i =0; i<dt.length; i++) {
            //     var obj = {};
            //     obj[dewsControl.options.codeField] = dt[i].code;
            //     obj[dewsControl.options.textField] = dt[i].name;
            //     arr.push(obj);
            //   }
            //   dewsControl.setData(arr);
            // }

          }
        },
        getRecordControlValue: function($control) {

          var self = this;

          var obj = "";
          if ($control != undefined) {

            var dewsControl = $control.data('dews-control');

            if(
              $control.hasClass("dews-ui-dropdownlist") ||
              $control.hasClass("dews-ui-numerictextbox") ||
              $control.hasClass("dews-ui-maskedtextbox") ||
              $control.hasClass("dews-ui-datepicker") ||
              $control.hasClass("dews-ui-timepicker") ||
              $control.hasClass("dews-ui-monthpicker") ||
              $control.hasClass("dews-ui-datetimepicker") ||
              $control.hasClass("dews-ui-zipcodepicker") ||
              $control.hasClass("dews-ui-combobox")
            )
            {
              obj = dewsControl.value();
            }
            else if($control.hasClass("dews-ui-textbox")) {
              obj = dewsControl.text();
            }
            // else if(
            //   $control.hasClass("dews-ui-monthperiodpicker") ||
            //   $control.hasClass("dews-ui-periodpicker"))
            // {
            //   items.push({ id: node.id + "_#START", code: dewsControl.getStartDate(), name: "" , etc : ""});
            //   items.push({ id: node.id + "_#END", code: dewsControl.getEndDate(), name: "" , etc : ""});
            // }
            // else if($control.hasClass("dews-ui-weekperiodpicker")) {
            //   items.push({ id: node.id + "_#START", code: dewsControl.getStartWeek(), name: "" , etc : ""});
            //   items.push({ id: node.id + "_#END", code: dewsControl.getEndWeek(), name: "" , etc : ""});
            // }

            // else if($control.hasClass("dews-ui-codepicker")) {
            //   var code = dewsControl.code() == "NULL" || dewsControl.code() == null ? "" : dewsControl.code();
            //   obj = { id: node.id, code: code, name: dewsControl.text() , etc : ""};
            // }
            // else if($control.hasClass("dews-ui-multicodepicker")) {
            //   for(var i = 0; i<dewsControl.codes().length; i++) {
            //     items.push({ id: node.id + "_#" + i, code: dewsControl.codes()[i], name: dewsControl.texts()[i] , etc : ""});
            //   }
            // }

          }

          return obj;
        },
        deleteRecordControlValue: function(keyValue) {

          if(!keyValue){
            return;
          }

          var self = this;

          if (self.recordDataSource[keyValue]) {
            delete self.recordDataSource[keyValue]
          }
        },
        clearRecordControl : function () {

          var self = this;

          $.map(self.recordControlMap, function ($control, key) {

            var start ="", end = "";
            var obj = {};

            var dewsControl = $control.data('dews-control');

            if(
                $control.hasClass("dews-ui-dropdownlist") ||
                $control.hasClass("dews-ui-numerictextbox") ||
                $control.hasClass("dews-ui-maskedtextbox") ||
                $control.hasClass("dews-ui-datepicker") ||
                $control.hasClass("dews-ui-timepicker") ||
                $control.hasClass("dews-ui-monthpicker") ||
                $control.hasClass("dews-ui-datetimepicker") ||
                $control.hasClass("dews-ui-zipcodepicker") ||
                $control.hasClass("dews-ui-combobox")
              )
              {
                dewsControl.value('');
              }
              else if($control.hasClass("dews-ui-textbox")) {
                dewsControl.text('');
              }
              else if(
                $control.hasClass("dews-ui-monthperiodpicker") ||
                $control.hasClass("dews-ui-weekperiodpicker"))
              {
                dewsControl.setPeriod(start, end);
              }
              else if($control.hasClass("dews-ui-periodpicker")) {
                dewsControl.setStartDate(start);
                dewsControl.setEndDate(end);
              }
              else if($control.hasClass("dews-ui-codepicker")) {
                obj[dewsControl.options.codeField] = '';
                obj[dewsControl.options.textField] = '';
                dewsControl.setData(obj, false);
              }
              else if($control.hasClass("dews-ui-multicodepicker")) {
                var arr = [];
                for(var i =0; i<dt.length; i++) {
                  obj = {};
                  obj[dewsControl.options.codeField] = dt[i].code;
                  obj[dewsControl.options.textField] = dt[i].name;
                  arr.push(obj);
                }
                dewsControl.setData(arr);
              }

          });
        },
        getDirtyRecordData: function () {

          var self = this;

          var dirtyData = { Updated: [], Deleted: [], Added: [] };

          $.map(self.recordDataSource, function (ds, key) {

            $.each(ds, function (index, item) {
              if (item.ST_ROW == 'added') {
                dirtyData.Added.push(item);
              } else if (item.ST_ROW == 'updated') {
                dirtyData.Updated.push(item);
              }
            });

          });

          return dirtyData;
        },
        getDirtyRecordCount : function () {

          var self = this;

          var count = 0;
          $.map(self.recordDataSource, function (ds, key) {

            $.each(ds, function (index, item) {
              if (item.ST_ROW == 'added' || item.ST_ROW == 'updated') {
                count++;
              }
            });

          });

          return count;
        },
        clearDirtyRecordState : function () {

          var self = this;

          $.map(self.recordDataSource, function (ds, key) {

            $.each(ds, function (index, item) {
              if (item.ST_ROW == 'added' || item.ST_ROW == 'updated') {
                item.ST_ROW = 'none';
              }
            });

          });

        },
        checkNotNullField : function (keyValue) {

          var self = this;
          var ret = null;

          $.each(self.recordDataSource[keyValue], function(index, item) {
            if (item) {
              var info = self.recordControlInfo[item.MCLS_CD];
              if(info){
                if (info.MNDR_YN == 'Y' && !item.CD_VALUE) {
                  //ret = self.recordControlInfo[item.MCLS_CD];
                  //ret.$control = self.recordControlMap[item.MCLS_CD];
                  ret = { label: info.MCLS_NM, tab:info.TAB_FG, $control:self.recordControlMap[item.MCLS_CD]};
                  return false;
                }
              }
            }
          });

          return ret;
        }, //checkNotNullField
        copyRecordData : function (trgKeyValue, keyValue) {

          var self = this;

          if (self.recordDataSource[trgKeyValue]) {
            self.recordDataSource[keyValue] = JSON.parse(JSON.stringify(self.recordDataSource[trgKeyValue]));
            var keyValues = keyValue.split("|");
            var thisKeys = self.recordKey.split("|");
            $.each(self.recordDataSource[keyValue], function (index, item) {
              item.ST_ROW = 'added';
              for(var i=0; i<thisKeys.length; i++){
                if(keyValues[i]){
                  item[thisKeys[i]] = keyValues[i]
                }
              }
            });
          }
        }

        // checkNotNullField : function (keyValue) {

        //   var self = this;

        //   for( i = 0; i < self.recordDataSource[keyValue].length; i++){
        //     var item = self.recordDataSource[keyValue][i];
        //     if (item) {
        //       var info = self.recordControlInfo[item.MCLS_CD];
        //       if(info){
        //         if (info.MNDR_YN == 'Y' && !item.CD_VALUE) {
        //           //ret = self.recordControlInfo[item.MCLS_CD];
        //           //ret.$control = self.recordControlMap[item.MCLS_CD];
        //           ret = { label: info.MCLS_NM, tab:info.TAB_FG, $control:self.recordControlMap[item.MCLS_CD]};
        //           return ret;
        //         }
        //       }
        //     }
        //   } //for
        // } //checkNotNullField

      };

    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);

})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=ma.rc.js
