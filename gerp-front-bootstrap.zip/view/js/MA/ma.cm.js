/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
 * MA 모듈 공통 함수
 * /view/js/ma.cm.js
 */
(function (dews, gerp, $) {
  var module = {};
  // var test = new Map();
  //---------Setting
  var defaultObject = {};
  var moduleCode = 'MA'; //모듈 코드
  // Map = function () {
  //   this.map = new Object();
  // };
  // Map.prototype = {
  //   put: function (key, value) {
  //     this.map[key] = value;
  //   },
  //   get: function (key) {
  //     return this.map[key];
  //   },
  //   containsKey: function (key) {
  //     return key in this.map;
  //   },
  //   containsValue: function (value) {
  //     for (var prop in this.map) {
  //       if (this.map[prop] == value) return true;
  //     }
  //     return false;
  //   },
  //   isEmpty: function (key) {
  //     return (this.size() == 0);
  //   },
  //   clear: function () {
  //     for (var prop in this.map) {
  //       delete this.map[prop];
  //     }
  //   },
  //   remove: function (key) {
  //     delete this.map[key];
  //   },
  //   keys: function () {
  //     var keys = new Array();
  //     for (var prop in this.map) {
  //       keys.push(prop);
  //     }
  //     return keys;
  //   },
  //   values: function () {
  //     var values = new Array();
  //     for (var prop in this.map) {
  //       values.push(this.map[prop]);
  //     }
  //     return values;
  //   },
  //   size: function () {
  //     var count = 0;
  //     for (var prop in this.map) {
  //       count++;
  //     }
  //     return count;
  //   }
  // };
  //---------Start

  //Date공통함수
  module.DATE = {

    /**
     * 날짜가져오기 (yyyyMM)
     * @example var yyyyMM = DATE.getMonth(-1); -> 현재월기준 전달
     * @param {*} addMonth 조정월 / nothing 현재월
     * @return {*} 년월
     */
    getMonth: function (addMonth) {

      var today = new Date();
      var yyyyMM;

      if (addMonth >= 0) {
        yyyyMM = (today.getFullYear() + Math.floor(addMonth / 12) + Math.floor((today.getMonth() + 1 + (addMonth % 12)) / 12)).toString()
          + ((today.getMonth() + 1 + (addMonth % 12)) % 12).toString().replace(/^(\d)$/, '0$1');
      }
      else {
        addMonth = Math.abs(addMonth);

        if (today.getMonth() + 1 - (addMonth % 12) <= 0) {
          yyyyMM = (today.getFullYear() - 1 - Math.floor(addMonth / 12)).toString()
            + ((today.getMonth() + 1 - (addMonth % 12)) == 0 ? 12 : (12 + (today.getMonth() + 1 - (addMonth % 12))).toString().replace(/^(\d)$/, '0$1'));
        }
        else {
          yyyyMM = (today.getFullYear() - Math.floor(addMonth / 12)).toString()
            + (today.getMonth() + 1 - (addMonth % 12)).toString().replace(/^(\d)$/, '0$1');
        }
      }

      return yyyyMM;
    },

    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMMdd = DATE.getFirstDate(1); -> 현재월기준 전달
     * @param {*} date 조정월 / nothing 현재월
     * @return {*} 년월일(시작일 : 1일)
     */
    getFirstDate: function (addMonth) {
      var yyyyMM = this.getMonth(addMonth);

      return yyyyMM + "01";
    },

    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMMdd = DATE.getLastDate(1); -> 현재월기준 전달
     * @param {*} date 조정월 / nothing 현재월
     * @return {*} 년월일(마지막일자)
     */
    getLastDate: function (addMonth) {
      var yyyyMM = this.getMonth(addMonth);
      var yyyyMMdd = yyyyMM + (new Date(yyyyMM.substring(0, 4), yyyyMM.substring(4), 0)).getDate();

      return yyyyMMdd;
    },

    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMMdd = DATE.getFirstDateOfMonth("201801");
     * @param {*} yyyyMM
     * @return {*} 년월일(시작일 : 1일)
     */
    getFirstDateOfMonth: function (yyyyMM) {
      var today = new Date(Number(yyyyMM.substr(0, 4)), Number(yyyyMM.substr(4, 2)));

      var yyyyMMstart;
      if (today.getMonth() == 0) {
        today.setFullYear(today.getFullYear() - 1);
        yyyyMMstart = today.getFullYear().toString() + "12" + "01";
      }
      else {
        yyyyMMstart = today.getFullYear().toString() + today.getMonth().toString().replace(/^(\d)$/, "0$1");
        yyyyMMstart += "01";
      }

      return yyyyMMstart;
    },
    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMMdd = DATE.getLastDateOfMonth("201801");
     * @param {*} yyyyMM
     * @return {*} 년월일(마지막일)
     */
    getLastDateOfMonth: function (yyyyMM) {
      var today = new Date(Number(yyyyMM.substr(0, 4)), Number(yyyyMM.substr(4, 2)));

      var yyyyMMstart, yyyyMMend;
      if (today.getMonth() == 0) {
        today.setFullYear(today.getFullYear() - 1);
        yyyyMMend = today.getFullYear().toString() + "12" + "31";
      }
      else {
        yyyyMMstart = today.getFullYear().toString() + today.getMonth().toString().replace(/^(\d)$/, "0$1");
        var ecdays = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
        var cyear = new Date(today.getFullYear(), today.getMonth() - 1);
        if ((((cyear.getFullYear() % 4) == 0) && ((cyear.getFullYear() % 100) != 0)) || ((cyear.getFullYear() % 400) == 0)) ecdays[1] = 29;
        yyyyMMend = yyyyMMstart + ecdays[cyear.getMonth()];
      }

      return yyyyMMend;
    },
    parseDateYYYYMMDD: function(str){
      var targetDate = new Date(str);
      var year = targetDate.getFullYear();
      var month = (targetDate.getMonth() + 1).toString();
      var date = targetDate.getDate().toString();

      if(month.length == 1){
        month = '0' + month;
      }

      if(date.length == 1){
        date = '0' + date;
      }

      return year + month + date;
    },
    parseDateYYYYMM: function(str){
      var targetDate = new Date(str);
      var year = targetDate.getFullYear();
      var month = (targetDate.getMonth() + 1).toString();

      if(month.length == 1){
        month = '0' + month;
      }

      return year + month;
    },
    getServerTime: function(flag){
      var timeMap = {};

      dews.api.get(dews.url.getApiUrl('CM', 'ConfigService', 'getServerTime'), {
        async: false
      }).done(function (data) {
        timeMap = data;
      });

      if(flag || flag == '' || flag == 'local'){
        return timeMap["localTime"];
      } else {
        return timeMap["gmtTime"];
      }
    },
  };

  module.CHECKER = {
    /**
     * 필수조회조건 검증
     * @example CHECKER.beforeSearch(dewself.$content.find('.dews-condition-panel-form .required'), function(controlId){
     *            dews.ui.requiredTooltip.show(dewself.$content.find('#' + controlId));
     *          });
     * @param {*} requiredControl : 필수 조회조건 컨트롤, function(e) : callback 함수처리
     * @return {*} boolean
     */
    beforeSearch: function (requiredControl, callback) {
      var isValid = true;
      if (requiredControl) {
        for (var idx = 0; idx < requiredControl.length; idx++) {
          var classList = requiredControl[idx].classList;
          var dewsControl = $(requiredControl[idx]).data('dews-control');
          if (classList.contains('dews-ui-textbox')) {
            // 텍스트박스
            if (!dewsControl.text()) { isValid = false; }
          } else if (classList.contains('dews-ui-numerictextbox')) {
            // 숫자텍스트박스
            if (!dewsControl.value()) { isValid = false; }
          } else if (classList.contains('dews-ui-maskedtextbox')) {
            // 마스크텍스트박스
            if (!dewsControl.value()) { isValid = false; }
          } else if (classList.contains('dews-ui-autocomplete')) {
            // 자동완성텍스트박스
            if (!dewsControl.value()) { isValid = false; }
          } else if (classList.contains('dews-ui-combobox')) {
            // 콤보박스
            if (!dewsControl.value()) { isValid = false; }
          } else if (classList.contains('dews-ui-codepicker')) {
            // 코드피커
            if (!dewsControl.code()) { isValid = false; }
          } else if (classList.contains('dews-ui-multicodepicker')) {
            // 멀티코드피커
            if (dewsControl.codes().length <= 0) { isValid = false; }
          } else if (classList.contains('dews-ui-datepicker') || classList.contains('dews-ui-timepicker') || classList.contains('dews-ui-monthpicker') || classList.contains('dews-ui-datetimepicker')) {
            // 날짜, 시간, 월, 날짜/시간/월 피커
            if (!dewsControl.value()) { isValid = false; }
          } else if (classList.contains('dews-ui-periodpicker') || classList.contains('dews-ui-monthperiodpicker')) {
            // 기간피커, 월기간피커
            if (!dewsControl.getStartDate() || !dewsControl.getEndDate()) { isValid = false; }
          } else if (classList.contains('dews-ui-weekperiodpicker')) {
            // 주기간피커
            if (!dewsControl.getStartWeek() || !dewsControl.getEndWeek()) { isValid = false; }
          }
          //  else if (classList.contains('dews-ui-dropdownlist')) {
          //   // 드랍다운리스트 -> '전체'항목이 존재하므로 임시 주석처리
          //   if (!dewsControl.value()) { isValid = false; }
          // }
          if (!isValid) {
            break;
          }
        }
        if (!isValid) {
          if (typeof callback === 'function') {
            callback(requiredControl[idx].id);
          }
        }
        return isValid;
      }
    },
    beforeDelete: function(param1, param2, param3, param4){
      var isValid = true;
      if(arguments.length == 3){
        dews.api.get(dews.url.getApiUrl('CM', 'VerifyService', 'beforeDelete'), {
          async: false,
          data: {
            cdFile: param1,
            value: param2
          }
        }).done(function (data) {
          if (typeof param3 === 'function') {
            param3(data);
          }
        });
      } else if (arguments.length == 4){
        dews.api.post(dews.url.getApiUrl('CM', 'VerifyService', 'beforeDelete2'), {
          async: false,
          data: {
            cdFile: param1,
            value: param2,
            keyMap : JSON.stringify(param3)
          }
        }).done(function (data) {
          if (typeof param4 === 'function') {
            param4(data);
          }
        });
      }
    },
    chkLength: function (colName, length) {
      var result = {};
      var digitSet = dews.ui.page.env.digit;
      if(digitSet && digitSet[colName]){
        if(digitSet[colName].yn_use == 'Y'){
          if(digitSet[colName].regulate == '1'){
            if(digitSet[colName].ctl == length){
              result.isValid = true;
              result.message = "";
            } else {
              result.isValid = false;
              var msg = "{0}의 길이를 {1} 자리로 입력해주십시오.";
              result.message = dews.string.format(msg, colName, digitSet[colName].ctl);
            }
          } else {
            if(parseInt(digitSet[colName].ctl) <= length){
              result.isValid = true;
              result.message = "";
            } else {
              result.isValid = false;
              var msg = "{0}의 길이를 {1} 자리 이하로 입력해주십시오.";
              result.message = dews.string.format(msg, colName, digitSet[colName].ctl);
            }
          }
        }
      }
      return result;
    }
  }

  module.CODE = {
    /**
     * 환경설정 데이터 가져오기 (CI)
     * @example var ret = COMMON.getCiCtrlConfig("IA", "P00540");
     * @param {*} module_cd : 모듈
     * @param {*} ctrl_cd : 구분
     * @return {*} 년월
     */
    getCiCtrlConfig: function(module_cd, ctrl_cd) {
      var ret = null;

      dews.api.get(dews.url.getApiUrl("CM", "CommonCtrlConfigService", "common_ci_ctrlconfig_string"), {
        async: false,
        data: {
          module_cd: module_cd,
          ctrl_cd: ctrl_cd,
          use_yn: 'Y'
        }
      }).done(function (data) {
        if (data) {
          ret = data;
        }
      });

      return ret;
    },

    /**
     * 환경설정 데이터 가져오기 (MA)
     * @example var ret = COMMON.getMaCtrlConfig("IA", "P00540");
     * @param {*} module_cd : 모듈
     * @param {*} ctrl_cd : 구분
     * @return {*} 년월
     */
    getMaCtrlConfig: function(module_cd, ctrl_cd) {
      var ret = null;

      dews.api.get(dews.url.getApiUrl("CM", "CommonCtrlConfigService", "common_ma_ctrlconfig_string"), {
        async: false,
        data: {
          module_cd: module_cd,
          ctrl_cd: ctrl_cd,
          use_yn: 'Y'
        }
      }).done(function (data) {
        if (data) {
          ret = data;
        }
      });

      return ret;
    },
    /**
     * CICodeData 조회
     * @example MA_CODE.getCICode('HR', "P00750|P00220|P00010|P00640|P00920|P00980|", "P00750|P00220|", true, function(codeSet){ ... } });
     * @param {*} module : 모듈코드, fieldPipe : field코드 (pipe), addEmptyLineFieldPipe: emptyData 추가할 field코드 (pipe), function(e) : callback 함수처리
     * @return {*} none, callback Parameter => {cd_field1 : Array[], cd_field2 : Array[], ...}
     */
    getCICode: function (module, fieldPipe, addEmptyLineFieldPipe, orderByName, callback) {
      var resultSet = {};
      var fieldArray = fieldPipe.split('|');
      var apiName = "common_ci_codeDtl_list";
      var aSync = typeof callback === 'function' ? true : false;

      if(orderByName){
        apiName = "common_ci_codeDtl_list_nm";
      }

      dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', apiName), {
        async: aSync,
        data: {
          module_cd: module, /* #.# cd_module 변환됨 => module_cd */
          field_cd_pipe: fieldPipe,
          syscode_yn: "",
          base_yn: "", /* #.# yn_default 변환됨 => base_yn */
          foreign_yn: "",
          end_dt: "", /* @.@ dt_end 변환 선택 => end_dt (end_dt,dept_end_dt) */
          keyword: ""
        }
      }).done(function (data) {
        fieldArray.forEach(function (field, idx) {
          var codeArray = $.grep(data, function (codeData, codeIdx) {
            return codeData.FIELD_CD == field; /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */
          })

          if (addEmptyLineFieldPipe && addEmptyLineFieldPipe.indexOf(field) != -1) {
            codeArray.insert(0, { FIELD_CD: '', SYSDEF_CD: '', SYSDEF_NM: '' }); /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */ /* @.@ CD_SYSDEF 변환 선택 => SYSDEF_CD (SYSDEF_CD,SYSBASE_CD) */ /* @.@ NM_SYSDEF 변환 선택 => SYSDEF_NM (SYSDEF_NM,SYSBASE_NM) */
          }

          resultSet[field] = codeArray;
        })

        if (typeof callback === 'function') {
          callback(resultSet);
        }
      });

      return resultSet;
    },
    getCICodeExt: function (module, fieldPipe, syscodeYn, baseYn, foreignYn, endDt, keyword, addEmptyLineFieldPipe, orderByName, callback) {
      var resultSet = {};
      var fieldArray = fieldPipe.split('|');
      var apiName = "common_ci_codeDtl_list";
      var aSync = typeof callback === 'function' ? true : false;

      if(orderByName){
        apiName = "common_ci_codeDtl_list_nm";
      }

      dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', apiName), {
        async: aSync,
        data: {
          module_cd: module, /* #.# cd_module 변환됨 => module_cd */
          field_cd_pipe: fieldPipe,
          syscode_yn: syscodeYn || "",
          base_yn: baseYn || "", /* #.# yn_default 변환됨 => base_yn */
          foreign_yn: foreignYn || "",
          end_dt: endDt || "", /* @.@ dt_end 변환 선택 => end_dt (end_dt,dept_end_dt) */
          keyword: keyword || ""
        }
      }).done(function (data) {
        fieldArray.forEach(function (field, idx) {
          var codeArray = $.grep(data, function (codeData, codeIdx) {
            return codeData.FIELD_CD == field; /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */
          })

          if (addEmptyLineFieldPipe && addEmptyLineFieldPipe.indexOf(field) != -1) {
            codeArray.insert(0, { FIELD_CD: '', SYSDEF_CD: '', SYSDEF_NM: '' }); /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */ /* @.@ CD_SYSDEF 변환 선택 => SYSDEF_CD (SYSDEF_CD,SYSBASE_CD) */ /* @.@ NM_SYSDEF 변환 선택 => SYSDEF_NM (SYSDEF_NM,SYSBASE_NM) */
          }

          resultSet[field] = codeArray;
        })

        if (typeof callback === 'function') {
          callback(resultSet);
        }
      });

      return resultSet;
    },
    /**
     * CodeData 조회
     * @example MA_CODE.getCode('HR', "P00750|P00220|P00010|P00640|P00920|P00980|", "P00750|P00220|", function(codeSet){ ... } });
     * @param {*} module : 모듈코드, fieldPipe : field코드 (pipe), addEmptyLineFieldPipe: emptyData 추가할 field코드 (pipe), function(e) : callback 함수처리
     * @return {*} none, callback Parameter => {cd_field1 : Array[], cd_field2 : Array[], ...}
     */
    getCode: function (module, fieldPipe, addEmptyLineFieldPipe, orderByName, callback) {
      var resultSet = {};
      var fieldArray = fieldPipe.split('|');
      var apiName = "common_codeDtl_list";
      var aSync = typeof callback === 'function' ? true : false;

      if(orderByName){
        apiName = "common_codeDtl_list_nm";
      }

      dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', apiName), {
        async: aSync,
        data: {
          module_cd: module, 
          field_cd_pipe: fieldPipe,
          syscode_yn: "",
          base_yn: "", 
          foreign_yn: "",
          end_dt: "", 
          keyword: ""
        }
      }).done(function (data) {
        fieldArray.forEach(function (field, idx) {
          var codeArray = $.grep(data, function (codeData, codeIdx) {
            return codeData.FIELD_CD == field;
          })

          if (addEmptyLineFieldPipe && addEmptyLineFieldPipe.indexOf(field) != -1) {
            codeArray.insert(0, { FIELD_CD: '', SYSDEF_CD: '', SYSDEF_NM: '' }); 
          }

          resultSet[field] = codeArray;
        })

        if (typeof callback === 'function') {
          callback(resultSet);
        }
      });

      return resultSet;
    },
    getCodeExt: function (module, fieldPipe, syscodeYn, baseYn, foreignYn, endDt, keyword, addEmptyLineFieldPipe, orderByName, callback) {
      var resultSet = {};
      var fieldArray = fieldPipe.split('|');
      var apiName = "common_codeDtl_list";
      var aSync = typeof callback === 'function' ? true : false;

      if(orderByName){
        apiName = "common_codeDtl_list_nm";
      }

      dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', apiName), {
        async: aSync,
        data: {
          module_cd: module, /* #.# cd_module 변환됨 => module_cd */
          field_cd_pipe: fieldPipe,
          syscode_yn: syscodeYn || "",
          base_yn: baseYn || "", /* #.# yn_default 변환됨 => base_yn */
          foreign_yn: foreignYn || "",
          end_dt: endDt || "", /* @.@ dt_end 변환 선택 => end_dt (end_dt,dept_end_dt) */
          keyword: keyword || ""
        }
      }).done(function (data) {
        fieldArray.forEach(function (field, idx) {
          var codeArray = $.grep(data, function (codeData, codeIdx) {
            return codeData.FIELD_CD == field; /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */
          })

          if (addEmptyLineFieldPipe && addEmptyLineFieldPipe.indexOf(field) != -1) {
            codeArray.insert(0, { FIELD_CD: '', SYSDEF_CD: '', SYSDEF_NM: '' }); /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */ /* @.@ CD_SYSDEF 변환 선택 => SYSDEF_CD (SYSDEF_CD,SYSBASE_CD) */ /* @.@ NM_SYSDEF 변환 선택 => SYSDEF_NM (SYSDEF_NM,SYSBASE_NM) */
          }

          resultSet[field] = codeArray;
        })

        if (typeof callback === 'function') {
          callback(resultSet);
        }
      });

      return resultSet;
    },

    getUserCode: function (codeList, nameList) {
      var resultList = [];

      var codeArray = codeList.split('|');
      var nameArray = nameList.split('|');

      if (codeArray && nameArray) {
        if (codeArray.length == nameArray.length) {
          for (var idx = 0; idx < codeArray.length; idx++) {
            resultList.push({ SYSDEF_CD: codeArray[idx], SYSDEF_NM: nameArray[idx] }); /* @.@ CD_SYSDEF 변환 선택 => SYSDEF_CD (SYSDEF_CD,SYSBASE_CD) */ /* @.@ NM_SYSDEF 변환 선택 => SYSDEF_NM (SYSDEF_NM,SYSBASE_NM) */
          }
        } else {
          return null;
        }
      }

      return resultList;
    },
    /**
    * Array -> DataSource Converting
    * @example var dataSource = MA_CODE.getDropDownDataSource('dataSource', [{CD_SYSDEF: 'A', NM_SYSDEF: 'NAME_A'}, {CD_SYSDEF: 'B', NM_SYSDEF: 'NAME_B'} ...]);
    * @param {*} name: dataSource명, dataItems: dataSource에 binding할 Items (array/datasource)
    * @return {*} dataSource
    */
    getDropDownDataSource: function (name, dataItems) {
      var dataSource = null;
      dataSource = dews.ui.dataSource(name, {
        data: dataItems
      });

      return dataSource;
    },

    getModuleCode: function (module_cd, allYn) {
      var resultSet;

      dews.api.get(dews.url.getApiUrl('MA', 'MaCommonService', 'module_list'), {
        async: false,
        data: {
          all_yn: allYn,
          module_cd: module_cd
        }
      }).done(function (data) {
        resultSet = data;
      });

      return resultSet;
    },
    /**
     * CommonCodeData 조회
     * @example MA_CODE.getHierarchy.getCommonCode
     * @param {*} module : 모듈코드 
     * @param {*} fieldPipe : fieldPipe : field코드 (pipe)
     * @param {*} orderByName
     * @param {*} syscodeYn
     * @param {*} baseYn
     * @param {*} foreignYn
     * @param {*} endDt
     * @param {*} keyword
     * @param {*} baseDt
     * @return {*} none, callback Parameter => {cd_field1 : Array[], cd_field2 : Array[], ...}
     */
    getCommonCode: function (module, fieldPipe, orderByName, syscodeYn, baseYn, foreignYn, endDt, keyword, baseDt) {
      var resultSet = {};
      var fieldArray = fieldPipe.split('|');
      var apiName = "common_codeDtl_list";
      var aSync = typeof callback === 'function' ? true : false;

      if(orderByName){
        apiName = "common_codeDtl_list_nm";
      }
      if (!resultSet.hasOwnProperty(module)) {
        resultSet[module] = {};
      }
      $.each(fieldPipe.split("|"), function (i, v) {
        if (v != null && v != "") {
          resultSet[module][v] = [];
        }
      });

      dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', apiName), {
        async: aSync,
        data: {
          module_cd: module, 
          field_cd_pipe: fieldPipe,
          syscode_yn: syscodeYn,
          base_yn: baseYn, 
          foreign_yn: foreignYn,
          end_dt: endDt, 
          keyword: keyword,
          base_dt: baseDt
        }
      }).done(function (data) {
        $.each(data, function (i, obj) {
          resultSet[module][obj.FIELD_CD].push(obj);
        });
      }).fail(function (xhr, status, error) {
        dews.alert(error);
      });

      return resultSet;
    },
    /**
     * CommonCodeData 조회
     * @example MA_CODE.getHierarchy.getCommonCode
     * @param {*} self : 화면 
     * @param {*} objCodeDtl : 공통코드 데이터
     * @param {*} fieldParam : 공통코드 필드(파이프형태)
     * @param {*} emptyYn : 데이터소스 공백(전체)여부(Y,N)
     */
    setHierarchy: function (self, objCodeDtl, fieldParam, emptyYn) {
      var hiSelf = this;
      var hierarchyCode = [];
      emptyYn = (emptyYn == undefined || emptyYn == null || emptyYn == '') ? 'N' : 'Y';

      dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', 'common_codeDtl_cdstrct'), {
        async: false,
        data: {
        }
      }).done(function (data) {
        hierarchyCode = data;
      }).fail(function (xhr, status, error) {
        dews.alert(error);
      });

      var hierarchyCtrl = [];
      $.each(self.$content.find('*[class^=dews-ui-dropdownlist]'), function(idx, node){
        if($(node).hasClass('dews-ui-dropdownlist')){
          var field = $(node).attr('data-field');
          if(field != undefined && field != "" ){
            var fieldArr = field.split("|");
            if(fieldParam.indexOf(fieldArr[1]) != -1 && objCodeDtl[fieldArr[0]][fieldArr[1]] && objCodeDtl[fieldArr[0]][fieldArr[1]].length > 0){
              var dataItems = objCodeDtl[fieldArr[0]][fieldArr[1]][objCodeDtl[fieldArr[0]][fieldArr[1]].length - 1]; //각 코드별 맨 마지막 값으로 계층구조여부 확인
              if(dataItems && dataItems.HIKEY_YN == 'Y'){
                hierarchyCtrl.push(node.id+"|"+field);
                var pModule = dataItems.UP_MODULE_CD;//현시점의 부모모듈
                var pField = dataItems.UP_FIELD_CD;//현시점의 부모필드

                function hierarchySetting(node){
                  var items = changehierarchy(node.attr('data-field'));
                  var arrItems = items.split(",");
                  for(var i=1; i < arrItems.length; i++){
                    var target = $("select[data-field='"+arrItems[i]+"']");
                    var parentTarget = $("select[data-field='"+arrItems[i-1]+"']");
                    var targetData = arrItems[i].split("|");
  
                    var arr = objCodeDtl[targetData[0]][targetData[1]].filter(function(item){
                      return item.UP_SYSDEF_CD == self[parentTarget[0].id].value();
                    });

                    if(arr.length > 0 && emptyYn == 'Y'){
                      arr.insert(0, { SYSDEF_CD: '', SYSDEF_NM: '' });
                    }
  
                    self[target[0].id].setDataSource(arr);
                  }
                }

                function changehierarchy(value){
                  var attr = value.split("|");
                  var arr = hierarchyCode.filter(function(item){
                    return item.UP_MODULE_CD == attr[0] && item.UP_FIELD_CD == attr[1];
                  });
  
                  if(arr.length == 1){
                    var result = changehierarchy(arr[0].MODULE_CD+"|"+arr[0].FIELD_CD);
                    return value + "," + result;
                  }else{
                    return value;
                  }
                }
                
                if(!pModule && !pField){// 최상위
                  if(emptyYn == 'Y'){
                    objCodeDtl[fieldArr[0]][fieldArr[1]].insert(0, { SYSDEF_CD: '', SYSDEF_NM: '' });
                  }
                  self[node.id].setDataSource(objCodeDtl[fieldArr[0]][fieldArr[1]]);
                }else{//그이외
                  /*var fModule = "";
                  var fField = "";
                  var pKeys = Object.keys(objCodeDtl);
                  for(var i=0; i<pKeys.length; i++){
                    var cKeys = Object.keys(objCodeDtl[pKeys[i]]);
                    for(var j=0; j<cKeys.length; j++){
                      if(objCodeDtl[pKeys[i]][cKeys[j]][objCodeDtl[pKeys[i]][cKeys[j]].length - 1].MODULE_CD == pModule && objCodeDtl[pKeys[i]][cKeys[j]][objCodeDtl[pKeys[i]][cKeys[j]].length - 1].FIELD_CD == pField){//부모의 코드값 찾기
                        fModule = pKeys[i];
                        fField = cKeys[j];
                        break;
                      }
                    }
                  }
  
                  if(objCodeDtl[fModule][fField][0].SYSDEF_CD != undefined && objCodeDtl[fModule][fField][0].SYSDEF_CD != ""){//찾은 부모 코드에서 빈값 O -> 자식도 값 X, 빈값 X -> 부모코드에 해당하는 자식코드값 입력
                    var filter = objCodeDtl[fieldArr[0]][fieldArr[1]].filter(function(item){
                      return item.UP_SYSDEF_CD == objCodeDtl[fModule][fField][0].SYSDEF_CD;
                    });
                    if(filter && filter.length > 0){
                      filter.insert(0, {SYSDEF_CD: '', SYSDEF_NM: '' });
                    }
                    self[node.id].setDataSource(filter);
                  }*/
                  hierarchySetting($(node));
                }
                //드롭다운리스트 변경시 계층구조에 따라 데이터소스 변환
                self[node.id].on('change',function(e){
                  hierarchySetting($(node));
                });
  
              }else if(dataItems && dataItems.HIKEY_YN == 'N'){
                if(emptyYn == 'Y'){
                  objCodeDtl[fieldArr[0]][fieldArr[1]].insert(0, { SYSDEF_CD: '', SYSDEF_NM: '' });
                }
                self[node.id].setDataSource(objCodeDtl[fieldArr[0]][fieldArr[1]]);
              }
            }
          }
        }
      });
    },
    /**
     * CommonCodeData 조회
     * @example MA_CODE.getHierarchy.getCommonCode
     * @param {*} codehelpId : 도움창ID
     * @return {*} callback Parameter => "true|false"
     */
    getHelpAutoSearchYn: function (codehelpId) {
      var reuslt = true;
      try{
        if(!codehelpId){
          throw "도움창ID값이 존재하지 않습니다.";
        }
        dews.api.get(dews.url.getApiUrl('CM', 'EnvironmentService', 'getCodehelpAutoReadYn'), {
          async: false,
          data: {
            codeHelpId: codehelpId, 
          }
        }).done(function (data) {
          reuslt = data;
        }).fail(function (xhr, status, error) {
          dews.alert(error);
        });
      }catch(exception){
        dews.ui.snackbar.error(exception);
      }

      return reuslt;
    }
  };


  module.VALIDATE = {
    /**
     * 사업자등록번호체크로직
     * @example VALIDATE.isCorpRegNumber('1231212345');  -> 123-12-12345
     * @param {*} value: 사업자등록번호 ('-'는 제외된 10자리)
     * @return {*} boolean
     */
    isCorpRegNumber: function (value) {
      try {
        var chk_no = [1,3,7,1,3,7,1,3,5]			//검증번호
        var str_company_no = String(value);		//문자열로 변환
        var nLast = 0;								        //검증번호의 마지막 문자열 계산값을 담기 위해서
        var tmp = 0;								          //계산된 값

        if(str_company_no.length != 10) {			//10자리 숫자가 아닌 경우
          return false;
        }

        for(var i = 0;i < 9; i++){
          tmp += chk_no[i] * str_company_no[i];	//(1).검증번호 * 사업자 번호
        }

        nLast = parseInt((chk_no[8] * str_company_no[8]) / 10);	//(2).9번째 계산된 값 / 10 의 몫

        tmp = tmp + (nLast);				            //(3). (1)+(2)
        if((10 - parseInt(tmp % 10)) % 10 != str_company_no[9]) {      //10 - (3) /10 과 사업자등록번호의 마지막 숫자와 같으면 정상
          return false;
        }

        return true;
      } catch (error) {
        return false;
      }
    },

    /**
     * 법인번호체크로직
     * @example VALIDATE.isCorpNumber('9012121521521');  -> 123456-1234567
     * @param {*} value: 법인번호 ('-'는 제외된 13자리)
     * @return {*} boolean
     */
    isCorpNumber: function (value) {
      try {
        var chk_no = [1,2,1,2,1,2,1,2,1,2,1,2];
        var str_corp_no = String(value);
        var tmp = 0;

        if(str_corp_no.length != 13) {				//13자리 숫자가 아닌 경우
          return false;
        }

        for(var i = 0;i < 12; i++){
          tmp += chk_no[i] * str_corp_no[i];	//(1).검증번호 * 사업자 번호
        }

        if (((10 - (tmp % 10)) % 10) != str_corp_no[12]) {
          return false;
        }

        return true;
      } catch (error) {
        return false;
      }
    },

    /**
     * 민증번호체크로직 --> 7번째 자리수가 1234
     * @example VALIDATE.isRegNumber('9012121521521');  -> 123456-1234567
     * @param {*} value: 민증번호 ('-'는 제외된 13자리)
     * @return {*} boolean
     */
    isRegNumber: function (value) {
      try {
        var format = /^\d{6}[1234]\d{6}$/;
        if (false == format.test(value)) {
          return false;
        }

        var array = new Array(13);
        for (var i = 0; i < 13; i++) {
          array[i] = parseInt(value.charAt(i));
        }

        var date = (array[0] * 100000) + (array[1] * 10000) + (array[2] * 1000) + (array[3] * 100) + (array[4] * 10) + array[5];
        if (date >= 201005) {
          var month = array[2] * 10 + array[3];
          if (month < 1 || month > 12) {
            return false;
          }

          var day = array[4] * 10 + array[5];
          if (day < 1 || day > 31) {
            return false;
          }
        }
        else {        
          var birthYear = (value.charAt(6) <= "2") ? "19" : "20";
          birthYear += value.substr(0, 2);
          var birthMonth = value.substr(2, 2) - 1;
          var birthDay = value.substr(4, 2);
          var birthDate = new Date(birthYear, birthMonth, birthDay);

          if (birthDate.getFullYear() % 100 != value.substr(0, 2) ||
            birthDate.getMonth() != birthMonth ||
            birthDate.getDate() != birthDay) {
            return false;
          }

          var multipliers = [2,3,4,5,6,7,8,9,2,3,4,5];
          for (var sum = 0, i = 0; i < 12; i++) {
            sum += (array[i] *= multipliers[i]);
          }

          if ((11 - (sum % 11)) % 10 != array[12]) {
            return false;
          }
        }

        return true;
      } catch (error) {
        return false;
      }
    },

    /**
     * 외국인등록번호 --> 7번째 자리수가 5678
     * @example VALIDATE.isForeignerNumber('9012121521521');  -> 123456-1234567
     * @param {*} value: 외국인등록번호 ('-'는 제외된 13자리)
     * @return {*} boolean
     */
    isForeignerNumber: function (value) {
      try {
        ////(신)방식 적용
        var format = /^\d{6}[5678]\d{6}$/;
        if (false == format.test(value)) {
          return false;
        }
        
        var str_foreigner = String(value);
        var buf = new Array(13);
        for (var i = 0; i < 13; i++) {
          buf[i] = parseInt(str_foreigner.charAt(i));
        }

        var month = buf[2] * 10 + buf[3];
        if (month < 1 || month > 12) {
          return false;
        }

        var day = buf[4] * 10 + buf[5];
        if (day < 1 || day > 31) {
          return false;
        }
        
        ////하단 주석은 (구)방식
        // var str_foreigner = String(value);
        // if(str_foreigner.length != 13) {				//13자리 숫자가 아닌 경우
        //   return false;
        // }

        // var sum = 0;
        // var buf = new Array(13);
        // for (var i = 0; i < 13; i++) {
        //   buf[i] = parseInt(str_foreigner.charAt(i));
        // }
        // var odd = buf[7] * 10 + buf[8];

        // if (odd % 2 != 0) {
        //   return false;
        // }
        // else if ((buf[11] != 6) && (buf[11] != 7) && (buf[11] != 8) && (buf[11] != 9)) {
        //   return false;
        // }

        // var multipliers = [2,3,4,5,6,7,8,9,2,3,4,5];
        // for (var i = 0, sum = 0; i < 12; i++) {
        //   sum += (buf[i] *= multipliers[i]);
        // }

        // sum = 11 - (sum % 10);
        // if (sum >= 10) {
        //   sum -= 10;
        // }
        // sum += 2;
        // if (sum >= 10) {
        //   sum -= 10;
        // }
        // if (sum != buf[12]) {
        //   return false;
        // }

        return true;
      } catch (error) {
        return false;
      }
    },

    /**
     * 이메일
     * @example VALIDATE.isEmail('genius@douzone.com');
     * @param {*} value: 이메일주소
     * @return {*} boolean
     */
    isEmail: function (value) {
      try {
        var regExp = /[0-9a-zA-Z][_0-9a-zA-Z-]*@[_0-9a-zA-Z-]+(\.[_0-9a-zA-Z-]+){1,2}$/;

        if (this.isNotNull(value)) {
          if (this.nvl(value.match(regExp), '') == '') {
            dews.ui.snackbar.warning('이메일이 잘못되었습니다.', 'warning');
            return false;
          } else {
            return true;
          }
        } else {
          return true;
        }
      } catch (error) {
        return false;
      }
    },

		onlyNumber : function (event){
      //event = event || window.event;

      console.log('event.key' + '/ ' + event.key );
      console.log('event.which' + '/ ' + event.which );
      console.log('event.keyCode' + '/ ' + event.keyCode );

      var keyID = (event.which) ? event.which : event.keyCode;
      if ( (keyID >= 35 && keyID <= 36) //35:HOME, 36:END
          || (event.ctrlKey == true && (keyID == 67 ||  keyID == 86) ) //Copy&Paste
          || (keyID >= 48 && keyID <= 57)   //0~9
          || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
          || (keyID >= 37 && keyID <= 40)   //방향키
          || keyID == 8 || keyID == 27 || keyID == 46 /*|| keyID == 109 || keyID == 189*/ //8:백스페이스, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
        )
				return;
			else{
        event.preventDefault();
        return;
      }
    },

		removeNotNumber : function (event) {
      //event = event || window.event;

      console.log('event.key' + '/ ' + event.key );
      console.log('event.which' + '/ ' + event.which );
      console.log('event.keyCode' + '/ ' + event.keyCode );

      var keyID = (event.which) ? event.which : event.keyCode;
      if ( (keyID >= 35 && keyID <= 36) //35:HOME, 36:END
          || (event.ctrlKey == true && (keyID == 67 ||  keyID == 86) ) //Copy&Paste
          || (keyID >= 48 && keyID <= 57)   //0~9
          || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
          || (keyID >= 37 && keyID <= 40)   //방향키
          || keyID == 8 || keyID == 27 || keyID == 46 /*|| keyID == 109 || keyID == 189*/ //8:백스페이스, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
        )
				return;
			else{

        console.log('removeNotNumber' + '/ ' + event.target.value + '/ ' + event.target.value.replace(/[^0-9]/g, "") );
        event.target.value = event.target.value.replace(/[^0-9]/g, "");
      }
    },

		onlyPhoneNumber : function (event){
			//event = event || window.event;

      console.log('event.key' + '/ ' + event.key );
      console.log('event.which' + '/ ' + event.which );
      console.log('event.keyCode' + '/ ' + event.keyCode );

      var keyID = (event.which) ? event.which : event.keyCode;
      if ( (keyID >= 35 && keyID <= 36) //35:HOME, 36:END
          || (event.ctrlKey == true && (keyID == 67 ||  keyID == 86) ) //Copy&Paste
          || (keyID >= 48 && keyID <= 57)   //0~9
          || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
          || (keyID >= 37 && keyID <= 40)   //방향키
          || keyID == 8 || keyID == 27 || keyID == 46 || keyID == 109 || keyID == 189 //8:백스페이스, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
        )
				return;
			else{
        event.preventDefault();
        return;
      }
    },

		removeNotPhoneNumber : function (event) {
      //event = event || window.event;

      console.log('event.key' + '/ ' + event.key );
      console.log('event.which' + '/ ' + event.which );
      console.log('event.keyCode' + '/ ' + event.keyCode );

      var keyID = (event.which) ? event.which : event.keyCode;
      if ( (keyID >= 35 && keyID <= 36) //35:HOME, 36:END
          || (event.ctrlKey == true && (keyID == 67 ||  keyID == 86) ) //Copy&Paste
          || (keyID >= 48 && keyID <= 57)   //0~9
          || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
          || (keyID >= 37 && keyID <= 40)   //방향키
          || keyID == 8 || keyID == 27 || keyID == 46 || keyID == 109 || keyID == 189 //8:백스페이스, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
        )
				return;
			else{
        console.log('removeNotPhoneNumber' + '/ ' + event.target.value + '/ ' + event.target.value.replace(/[^0-9\-]/g, "") );
        event.target.value = event.target.value.replace(/[^0-9\-]/g, "");
      }
    }

  };

  //공통 다국어 처리
  module.LANGUAGE = {
    LanguageUtil : function() {
      return {
        self: {},
        popOpen: false,
        useCompany: true,
        col_Info_multi: [],
        col_Info: {},
        col_Param: {},
        col_Name: "",
        std_Lang: "",
        otherCOL:"",
        multiTitle: "",
        multiButton: "",
        isSession: false,
        isSeq: "",
        initPage: function (self, isSession) {

          var popself = this;
          popself.isSession = isSession;

          dews.localize.load(dews.localize.language(), 'BASLAN00400')
          .then(function (data) {
            popself.multiTitle = dews.localize.get('다국어 설정', 'D0000898', dews.localize.language(), 'BASLAN00400');
          });

          popself.multiButton = "저장";
          dews.localize.load(dews.localize.language(), 'CSBCIC00500')
          .then(function (data) { 
            popself.multiButton = dews.localize.get('저장', 'D0000388', dews.localize.language(), 'CSBCIC00500');
          });

          if(popself.isSession){
            std_Lang = self.user.language.toUpperCase();
          }
          else{
            dews.api.get(dews.url.getApiUrl("CM", "MultiLanguageService", "company_std_language"), {
              async: false
            }).done(function (data) {
              if(data && data.length > 0){
                std_Lang = data;
              }
            }).fail(function (xhr, status, error) {
              dews.ui.snackbar.error(error);
            });
          }
          
          dews.api.get(dews.url.getApiUrl("CM", "MultiLanguageService", "language_list"), {
            async: false
          }).done(function (data) {
            if (data) {
              var popupHtml = '<div class="dews-popup-panel cm-popup-multilanguage" id="popup" style="padding:0 !important">';
              popupHtml += '<div class="dews-button-group" style="background: #f1f6f9; margin-bottom:0;">';
              popupHtml += '<div style="float:left;height:36px;">';
              popupHtml += '<h3 style="float: left; padding-left:15px; margin-top: 8px;" class="cm-title-multilanguage">'+popself.multiTitle+'</h3>';
              popupHtml += '</div>';
              popupHtml += '<button class="dews-ui-button cm-btn-multilanguage-save" style="float:right;">'+ popself.multiButton +'</button>';
              popupHtml += '</div>';
              popupHtml += '<div class="dews-popup-item" style="height: calc(100% - 39px); padding-top:8px;">';
              popupHtml += '<div class="dews-popup-content"></div>';
              popupHtml += '<div class="cm-content-multilanguage" style="height:123px;overflow:auto;border-top:2px solid #666;">';
              var tableHtml = "";
              if (data.length > 0) {
                tableHtml = '<table style="width: 100%;width: 100%;table-layout: fixed;border-collapse: collapse;border-spacing: 0;">';
                tableHtml += '<colgroup>';
                tableHtml += '<col width="20%">';
                tableHtml += '<col width="30%">';
                tableHtml += '<col width="20%">';
                tableHtml += '<col width="30%">';
                tableHtml += '</colgroup>';
                tableHtml += '<tbody>';

                $.each(data, function (i, it) {
                  if (i%2 == 0) {
                    var concatHtml = '<tr style="height:40px;border-bottom: 1px solid #e1e1e1;">';
                    concatHtml += '<th style="padding: 6px 9px;color: #000; font-weight: normal; text-align: right; background-color: #f7f7f7;text-align: right !important;">{0}</th>';
                    concatHtml += '<td style="padding: 6px 9px;">';
                    concatHtml += '<input type="text" id="{1}" class="dews-ui-textbox k-textbox dews-control-activate dews-form-control" style="width:100%" maxlength="200"></input>';
                    concatHtml += '<input type="text" id="old_{1}" class="cm-popup-multilanguagehidden" style="display:none"></input>';
                    concatHtml += '</td>';


                    tableHtml += dews.string.format(concatHtml , it.COL_NM + ' (' + it.COL2_NM + ')', it.COL_CD);

                    if (data.length >= i+2) {
                      concatHtml = '<th style="padding: 6px 9px;color: #000; font-weight: normal; text-align: right; background-color: #f7f7f7;text-align: right !important;">{0}</th>'
                      concatHtml += '<td style="padding: 6px 9px;">';
                      concatHtml += '<input type="text" id="{1}" class="dews-ui-textbox k-textbox dews-control-activate dews-form-control" style="width:100%" maxlength="200"></input>';
                      concatHtml += '<input type="text" id="old_{1}" class="cm-popup-multilanguagehidden" style="display:none"></input>';
                      concatHtml += '</td>';
                      concatHtml += '</tr>';

                      tableHtml += dews.string.format(concatHtml, data[i+1].COL_NM + ' (' + data[i+1].COL2_NM + ')', data[i+1].COL_CD);
                    }
                    else {
                      tableHtml += '<td colspan="2" style="border-left:0px;padding: 6px 9px;" />';
                      tableHtml += '</tr>';
                    }
                  }
                });


                tableHtml += '</tbody></table>';
              }

              popupHtml += tableHtml;
              popupHtml += '</div></div></div>';

              self.$content.append(popupHtml);


              // var std_Lang = dews.ui.page.user.language.toUpperCase();

              var textbox_list = self.$content.find('.cm-popup-multilanguage .dews-ui-textbox');
              $.each(textbox_list, function(i, textbox) {
                //$(textbox).trigger('inituicontrols');
                self[textbox.id] = dews.ui.textbox($(textbox));

                //---현재사용중인 언어 readonly
                if (textbox.id == std_Lang) {
                  self[textbox.id].readonly(true)
                }
              });

              var textbox_list_old = self.$content.find('.cm-popup-multilanguagehidden');
              $.each(textbox_list_old, function(i, textbox) {
                //$(textbox).trigger('inituicontrols');
                self[textbox.id] = textbox;

                //---현재사용중인 언어 readonly
                if (textbox.id == std_Lang) {
                  self[textbox.id].readonly(true)
                }
              });

              var $btnSave = self.$content.find('.cm-btn-multilanguage-save');
              dews.ui.button($btnSave);

              var $btnCtrl = self.$content.find('.cm-btn-multilanguage');
              var $popupCtrl = self.$content.find('.cm-popup-multilanguage');
              var $popup = dews.ui.popuppanel($popupCtrl, {
                height: 180
              });

              //다국어 버튼 메인으로 변환 후 삭제
              $btnCtrl.on('click', function(e) {
                if ($popupCtrl[0].style.display == 'none') {
                  popself.popOpen = true;
                  if (popself.col_Param) {
                    popself.bindDataMulti(popself.col_Param, popself.col_Name, null);
                  }
                  $popup.show();
                }
                else {
                  popself.popOpen = false;
                  $popup.hide();
                }
              });

              dews.ui.mainbuttons.localize.on('click', function(e) {
                if ($popupCtrl[0].style.display == 'none') {
                  popself.popOpen = true;
                  if (popself.col_Param) {
                    popself.bindDataMulti(popself.col_Param, popself.col_Name, null);
                  }
                  $popup.show();
                }
                else {
                  popself.popOpen = false;
                  $popup.hide();
                }
              });

              $btnSave.on('click', function(e) {
                //save
                popself.saveData(true);
              });

              $('.cm-popup-multilanguage .dews-popup-close-button', self.$content).on('click', function(e) {
                if ($popupCtrl[0].style.display != 'none') {
                  popself.popOpen = false;
                }
              });

              $('.cm-popup-multilanguage .dews-ui-textbox', self.$content).on('change', function(e) {
                popself.saveButtonEnable(true);
                
              });

              popself.saveButtonEnable(false);

              //popup 저장버튼 스타일이 생성시..right인데 안먹힘..어느순간부터
              $(".cm-popup-multilanguage .cm-btn-multilanguage-save", self.$content).attr("style", "float:right;");
              //-------------------------

              $(".cm-popup-multilanguage .dews-popup-arrow-button", self.$content).attr("style","display:none;");
              $(".cm-popup-multilanguage .cm-btn-multilanguage-save", self.$content).attr("style", "margin-top: 4px;margin-right: 29px;")

            }
          });
        },
        initInfo: function (self, info) {//다국어 변경컬럼이 단일일때
          var popself = this;
          popself.self = self;
          popself.col_Info = info;
        },
        initInfoMulti: function (self, infos) {//다국어 변경 테이블이 여러개 일때
          var popself = this;
          popself.self = self;
          popself.col_Info_multi = infos;
          popself.setInitInfo(0);
        },
        initInfoMultiSeq: function (self, infos, isSeq) {//다국어 변경 테이블이 여러개이고 PK컬럼이 SQ컬럼이며 표시되는 순서가 정렬순서와 일치할때
          var popself = this;
          popself.self = self;
          popself.col_Info_multi = infos;
          popself.isSeq = isSeq
          popself.setInitInfo(0);
        },
        setInitInfo: function (idx) {
          var popself = this;
          if (idx != null) {
            popself.col_Info = popself.col_Info_multi[idx];
          }
        },
        setUseCompany: function (isUse) {
          var popself = this;
          popself.useCompany = isUse;
        },
        setAllCompany: function (table_id, col_cd, mTable_id) { //CI 기준 정보 입력시 MA아래의 모든 회사의 값 동기화
          var popself = this;
          popself.downTable = table_id;
          popself.downCol = col_cd;
          popself.mTable = mTable_id;
        },
        saveButtonEnable: function (isModify) {
          var popself = this;
          if (!isModify) {
            $('.cm-btn-multilanguage-save', popself.self.$content).prop('disabled', true);
            $('.cm-btn-multilanguage-save', popself.self.$content).addClass("k-state-disabled");
          }
          else {
            $('.cm-btn-multilanguage-save', popself.self.$content).prop('disabled', false);
            $('.cm-btn-multilanguage-save', popself.self.$content).removeClass("k-state-disabled");
          }
        },
        clearData: function () {
          var popself = this;
          popself.saveButtonEnable(false);
          var textbox_list = $('.cm-popup-multilanguage .dews-ui-textbox', popself.self.$content);
          $.each(textbox_list, function(i, textbox) {
            popself.self[textbox.id].text("");
            popself.self["old_"+textbox.id].textContent = "";
          });
        },
        // bindData: function (params) {
        //   var popself = this;
        //   if(!$('.cm-btn-multilanguage-save', popself.self.$content).hasClass("k-state-disabled")) {
        //     dews.confirm('다국어설정 데이터가 저장되지 않았습니다.' + "\n" + '저장하시겠습니까?', 'question').yes(function () {
        //       popself.saveData();
        //       popself.bindDataSearch(params, "");
        //     }).no(function () {
        //       popself.bindDataSearch(params, "");
        //     });
        //   }
        //   else {
        //     popself.bindDataSearch(params, "");
        //   }
        // },
        bindData: function (params, name) {
          var popself = this;
          popself.bindDataMulti(params, name, null);
        },
        bindDataParamMulti: function (params, name, COL) {//변경된 컬럼이 여러개일 경우 현재와 이전을 구분하기 위해 생성
          var popself = this;
          popself.beforeCol = popself.col_Info.COL;
          popself.col_Info.COL = COL;
          popself.bindDataMulti(params, name, null);
        },
        bindDataMulti: function (params, name, idx) {
          var popself = this;
          var textbox_list = $('.cm-popup-multilanguage .dews-ui-textbox', popself.self.$content);
          var checkData = false;

          $.each(textbox_list, function(i, textbox) {
            //IE에서는 popself.self["old_"+textbox.id].textContent 값이 "undefined"로 나옴 
            if(popself.self[textbox.id].text() != (popself.self["old_"+textbox.id].textContent == "undefined" ? '' :popself.self["old_"+textbox.id].textContent) ){
              checkData = true;
            }
          });

          if(checkData) {
          // if(!$('.cm-btn-multilanguage-save', popself.self.$content).hasClass("k-state-disabled")) {
            dews.confirm('다국어설정 데이터가 저장되지 않았습니다.' + "\n" + '저장하시겠습니까?', 'question').yes(function () {
              popself.saveData();
              popself.setInitInfo(idx);
              popself.bindDataSearch(params, name);
            }).no(function () {
              popself.setInitInfo(idx);
              popself.bindDataSearch(params, name);
            });
          }
          else {
            popself.setInitInfo(idx);
            popself.bindDataSearch(params, name);
          }
        },
        bindDataTableAndParamMulti: function (params, name, COL,idx) { //다국어 저장하는 테이블과 대상 컬럼이 여러개일 경우 
          var popself = this;
          popself.beforeCol = popself.col_Info.COL;
          popself.col_Info.COL = COL;
          popself.otherCOL = COL;
          popself.bindDataMulti(params, name, idx);
        },
        bindDataSearch: function (params, name) {

          var popself = this;
          popself.clearData();
          popself.col_Param = params;
          popself.col_Name = name;

          if(popself.otherCOL) {
            if(popself.otherCOL != popself.col_Info.COL){
              popself.col_Info.COL= popself.otherCOL;
            }
          }
          
          //title
          if(name != null) {
            var title = name + " " + popself.multiTitle;
          }
          else{
            var title = popself.multiTitle;
          }
          
          $('.cm-title-multilanguage', popself.self.$content).text(title);
          $('.cm-btn-multilanguage-save', popself.self.$content).text(popself.multiButton)

          // if (name == "") {
          //   popself.statePop(true);
          //   return true;
          // }
          if(popself.isSeq == "" ) {
            
            if ($('.cm-popup-multilanguage', popself.self.$content)[0].style.display != 'none' || popself.popOpen) {

              var plist = popself.col_Info.PCOL.split('|');
              var keys = "";

              if(popself.useCompany){
                $.each(plist, function(i, p) {
                  if (p != "COMPANY_CD" && p != "") {
                    keys += params[p] + "|";
                  }
                });
              }
              else{
                $.each(plist, function(i, p) {
                  if (p != "") {
                    if(p.indexOf("_SQ") == -1) {
                      keys += params[p] + "|";
                    }
                    else {
                      keys += i+"|"
                    }
                    
                  }
                });
              }

              var param = {
                table: popself.col_Info.TABLE,
                pcols: popself.col_Info.PCOL,
                col: popself.col_Info.COL,
                keys: keys,
                usecompany: popself.useCompany ? "1" : "2",
                isSession : popself.isSession ? "1" : "2"
              }

              dews.api.get(dews.url.getApiUrl("CM", "MultiLanguageService", "language_list_bind"), {
                async: false,
                data: param
              }).done(function (data) {
                if (data) {
                  $.each(data, function(i, it) {
                    if (popself.self[it.LANG_CD]) {
                      popself.self[it.LANG_CD].text(it.DATA);
                      popself.self["old_"+it.LANG_CD].textContent = it.DATA;
                    }
                  });
                }

                // var std_Lang = dews.ui.page.user.language.toUpperCase();
                // if (popself.self[std_Lang]) {
                //   if(popself.self[std_Lang].text() == "") {
                //     popself.self[std_Lang].text(name);
                //     popself.self["old_"+std_Lang].textContent = name;
                //   }
                // }

              });
            }
          }
          else {
            var names = name.split(this.isSeq);
            var lang = {};
            for(var seq = 1; seq <= names.length; seq++) {
              if ($('.cm-popup-multilanguage', popself.self.$content)[0].style.display != 'none' || popself.popOpen) {

                var plist = popself.col_Info.PCOL.split('|');
                var keys = "";
  
                if(popself.useCompany){
                  $.each(plist, function(i, p) {
                    if (p != "COMPANY_CD" && p != "") {
                      keys += params[p] + "|";
                    }
                  });
                }
                else{
                  $.each(plist, function(i, p) {
                    if (p != "") {
                      if(p.indexOf("_SQ") == -1) {
                        keys += params[p] + "|";
                      }
                      else {
                        keys += seq+"|"
                      }
                    }
                  });
                }
  
                var param = {
                  table: popself.col_Info.TABLE,
                  pcols: popself.col_Info.PCOL,
                  col: popself.col_Info.COL,
                  keys: keys,
                  usecompany: popself.useCompany ? "1" : "2",
                  isSession : popself.isSession ? "1" : "2"
                }
  
                dews.api.get(dews.url.getApiUrl("CM", "MultiLanguageService", "language_list_bind"), {
                  async: false,
                  data: param
                }).done(function (data) {
                  if (data) {
                    $.each(data, function(i, it) {
                      if (popself.self[it.LANG_CD]) {
                        if(lang[it.LANG_CD] == undefined || lang[it.LANG_CD] == ' ') {
                          lang[it.LANG_CD] = ""
                          lang[it.LANG_CD] += it.DATA
                        }
                        else if (it.DATA != ' '){
                          lang[it.LANG_CD] += ("," + it.DATA)
                        }
                      }
                    });
                  }
                });
              }
            }
            var langCd = Object.keys(lang);
            for (var i = 0; i < langCd.length; i++){
              popself.self[langCd[i]].text(lang[langCd[i]]);
              popself.self["old_"+langCd[i]].textContent = lang[langCd[i]];
            }
          }
          // var std_Lang = dews.ui.page.user.language.toUpperCase();
          if (popself.self[std_Lang]) {
            if(popself.self[std_Lang].text() == "") {
              popself.self[std_Lang].text(name);
              popself.self["old_"+std_Lang].textContent = name;
            }
          }
          return true;
        },
        saveDataPop: function () { //저장시 태우는 로직
          var popself = this;
          if(!$('.cm-btn-multilanguage-save', popself.self.$content).hasClass("k-state-disabled")) {
            popself.saveData();
          }
        },
        saveData: function (flag) { //저장로직
          var popself = this;
          var textbox_list = $('.cm-popup-multilanguage .dews-ui-textbox', popself.self.$content);
          var dataList = [];
          var plist = popself.col_Info.PCOL.split('|');
          var params = popself.col_Param;
          var keys = "";

          if(popself.isSeq == "") {
            
            //현재 사용중인 언어는 저장하지 않는다. (우선 저장)
            //var std_Lang = dews.ui.page.user.language.toUpperCase();
            $.each(textbox_list, function(i, textbox) {
              //if ($(self[textbox.id]).val() != "" && textbox.id != std_Lang) {
              // if (popself.self[textbox.id].text() != "") {
                if(popself.self[textbox.id].text() != popself.self["old_"+textbox.id].textContent){
                  dataList.push({ LANG_CD: textbox.id, DATA: popself.self[textbox.id].text() });
                }
              // }
            });

            if(popself.useCompany){
              $.each(plist, function(i, p) {
                if (p != "COMPANY_CD" && p != "") {
                  keys += params[p] + "|";
                }
              });
            }
            else{
              $.each(plist, function(i, p) {
                if (p != "") {
                  keys += params[p] + "|";
                }
              });
            }

            var iscompany = popself.useCompany ? "1" : "2";
            var param = {
              table: popself.col_Info.TABLE,
              pcols: popself.col_Info.PCOL,
              //저장버튼을 눌렀을경우 현재의 컬럼
              //그 이외의 이벤트로 저장이 발생할경우 이전의 컬럼으로 저장
              col: flag ? popself.col_Info.COL : popself.beforeCol ? popself.beforeCol: popself.col_Info.COL,
              keys: keys,
              datalist: JSON.stringify(dataList),
              usecompany: iscompany
            }

            dews.ajax.post(dews.url.getApiUrl("CM", "MultiLanguageService", "language_save"), {
              async: false,
              dataType: 'json',
              data: param
            }).done(function (data) {
              if(popself.downTable){
                var dParam = { //CI 다국어테이블과 그아래 다국어테이블의 명칭 컬럼명이 같다는 전제하에 진행(1:1)
                  uTable : popself.col_Info.TABLE,
                  dTable : popself.downTable,
                  mTable : popself.mTable,
                  pcols: popself.col_Info.PCOL,
                  dCol : popself.downCol,
                  keys: keys
                }
                dews.ajax.post(dews.url.getApiUrl("CM", "MultiLanguageService", "language_save_down"), {
                  async: false,
                  dataType: 'json',
                  data: dParam
                }).done(function (data) {
                  popself.saveButtonEnable(false);
                  dews.ui.snackbar.ok(dews.localize.get('저장이 완료되었습니다.', 'M0000021'));
                  popself.bindDataSearch(popself.col_Param, popself.col_Name);
                });
              }else{
                popself.saveButtonEnable(false);
                dews.ui.snackbar.ok(dews.localize.get('저장이 완료되었습니다.', 'M0000021'));
                popself.bindDataSearch(popself.col_Param, popself.col_Name);
              }
            });
          }
          else {
            // var names = textbox_list[0].value.split(this.isSeq);
            var names = popself.self[dews.ui.page.user.stdrLangCd.toUpperCase()].text().split(this.isSeq);
            var datas = '';
            var cnt = 1;
            var exit = false;
            var forOneDataL;
            var forOneDataD;

            for(var seq = 1; seq <= names.length; seq++) {
              $.each(textbox_list, function(i, textbox) {
                if(popself.self[textbox.id].text() != popself.self["old_"+textbox.id].textContent){
                  let text = popself.self[textbox.id].text();
                  if(text.indexOf(popself.isSeq) != -1) {
                    datas = text.split(popself.isSeq);
                    if(datas[seq-1] !== '' && datas[seq-1] !== null && datas[seq-1] !== undefined)  {
                      dataList.push({ LANG_CD: textbox.id, DATA: datas[seq-1]});  
                    }
                    else {
                      dataList.push({ LANG_CD: textbox.id, DATA: ' '});  
                    }
                  }
                  else if(text.indexOf(popself.isSeq) == -1 && text == ''){
                      dataList.push({ LANG_CD: textbox.id, DATA: ' '});
                  }
                  else if (text.indexOf(popself.isSeq) == -1) {
                    if( forOneDataL != textbox.id  && forOneDataD != text) {
                      dataList.push({ LANG_CD: textbox.id, DATA: text});
                      forOneDataL = textbox.id;
                      forOneDataD = text;
                    }
                    else {
                      dataList.push({ LANG_CD: textbox.id, DATA: ' '});
                    }
                      // forOneData.push({ LANG_CD: textbox.id, DATA: text});
                    }
                  }
                  // datas = datas.filter(function(data){
                  //   return data !== '' && data !== null && data !== undefined;
                  // });
                  // if(datas.length != names.length){
                  //   exit = true;
                  //   dews.ui.snackbar.warning('다국어 설정값이 잘못되었습니다.');
                  //   popself.self[textbox.id].focus();
                  //   return false;
                  // }
                  // else {
                  // }
                // }
              });
              
              if(exit) {
                return false;
              }
              
              if(popself.useCompany){
                $.each(plist, function(i, p) {
                  if (p != "COMPANY_CD" && p != "") {
                    keys += params[p] + "|";
                  }
                });
              }
              else{
                $.each(plist, function(i, p) {
                  if (p != "") {
                    if(p.indexOf("_SQ") == -1) {
                      keys += params[p] + "|";
                    }
                    else {
                      keys += seq+"|"
                    }
                  }
                });
              }
  
              var iscompany = popself.useCompany ? "1" : "2";
              var param = {
                table: popself.col_Info.TABLE,
                pcols: popself.col_Info.PCOL,
                //저장버튼을 눌렀을경우 현재의 컬럼
                //그 이외의 이벤트로 저장이 발생할경우 이전의 컬럼으로 저장
                col: flag ? popself.col_Info.COL : popself.beforeCol ? popself.beforeCol: popself.col_Info.COL,
                keys: keys,
                datalist: JSON.stringify(dataList),
                usecompany: iscompany
              }
  
              dews.ajax.post(dews.url.getApiUrl("CM", "MultiLanguageService", "language_save"), {
                async: false,
                dataType: 'json',
                data: param
              }).done(function (data) {
                popself.saveButtonEnable(false);
                if(names.length == cnt ) {
                  dews.ui.snackbar.ok(dews.localize.get('저장이 완료되었습니다.', 'M0000021'));
                  popself.bindDataSearch(popself.col_Param, popself.col_Name);
                }
                else {
                  cnt ++;
                  dataList = [];
                }
                keys = "";
              });
            }
          }

        },
        statePop: function (isAdd) {
          var popself = this;
          var textbox_list = $('.cm-popup-multilanguage .dews-ui-textbox', popself.self.$content);

          // var std_Lang = dews.ui.page.user.language.toUpperCase();
          $.each(textbox_list, function(i, textbox) {
            if (isAdd) {
              // $(popself.self[textbox.id]).prop('readonly', true);
              // $(popself.self[textbox.id]).addClass("readonly");
              popself.self[textbox.id].readonly(true);
            }
            else {
              //---현재사용중인 언어 readonly 제외
              if (textbox.id != std_Lang) {
                // $(popself.self[textbox.id]).prop('readonly', false);
                // $(popself.self[textbox.id]).removeClass("readonly");
                popself.self[textbox.id].readonly(false);
              }
            }
          });
        },
        addPop: function () {
          var popself = this;
          var $popup = $('.cm-popup-multilanguage', popself.self.$content);
          if ($popup[0].style.display != 'none') {
            popself.popOpen = false;
            $popup.hide();
          }
        },
      }
    }
  };
  //---------End

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=ma.cm.js
