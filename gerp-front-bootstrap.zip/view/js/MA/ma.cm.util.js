/*
 * 메시지 공통 함수
 * /view/js/MA/ma.cm.util.js
 * 사용안함 ma.cm.msg.js 사용 바람
 */
(function (dews, gerp, $) {

  /**
   * var msgUtil;
   * 
   * dews.ajax.script('~/view/js/MA/ma.cm.util.js', {
   *    once: true,
   *    async: false
   * }).done(function() {
   *    msgUtil = gerp.MA.MessageUtil;
   * });
   * 
   * // msgUtil.SEARCH_AGAIN_CONFIRM 사용
   */
  var module = {};
  var moduleCode = "MA"; //모듈 코드

  var MessageEnum =  {
    //닫기
    CLOSE_CONFIRM : "저장하지 않은 데이터가 있습니다." + "\n" + "닫기를 계속하시겠습니까?",         //종료 확인
    //조회
    SEARCH_AGAIN_CONFIRM : "저장하지 않은 데이터가 있습니다." + "\n" + "조회를 계속하시겠습니까?",  //재조회 확인    
    SEARCH_NO_DATA_ALERT : "데이터가 존재하지 않습니다.",                                         //조회된 데이터 없음
    //삭제
    DELETE_CONFIRM : "삭제하시겠습니까?",                                                        //삭제 확인
    DELETE_DONE_ALERT : "	삭제가 완료되었습니다.",                                                //삭제 완료    
    //저장
    SAVE_NO_DATA_ALERT : "저장할 데이터가 없습니다.",                                             //저장할 데이터 없음
    SAVE_CONFIRM : "저장하시겠습니까?",                                                           //저장 확인
    SAVE_DONE_ALERT : "저장이 완료되었습니다.",                                                   //저장 완료
    SAVE_VALID_ALERT : "필수항목을 입력하지 않았습니다.",                                          //필수값 누락
    SAVE_VALID_GRID_ALERT : "입력은 필수입니다.",                                                 //필수값 누락 (그리드)
    //로딩
    SEARCH_LOADING : "조회하는 중입니다.",                                                        //조회 로딩
    SAVE_LOADING : "저장하는 중입니다.",                                                          //저장 로딩
    DELETE_LOADING : "삭제하는 중입니다.",          
    //선택
    CHECK_NO_DATA_ALERT : "선택된 데이터가 없습니다."                                              //체크된 데이터 없음
    
    
  };

  module.MessageUtil = MessageEnum;
  /*********************************************************************************************
     *  @desc 중복저장 상세내용 표기
     *  @param {Object} result [필수] 저장 API에서 반환된 list 
     *  @param {function} callback [선택] 다이얼로그 닫기 버튼 후 처리되야 하는 이벤트
     *  @ex  saveCon.SaveConcurr.showDialog(data,callback);
     * ------------------------------------------------------------------------------------------*/
  module.SaveConcurr = {
    showDialog : function(result,callback) {
      var dialog = dews.ui.dialog('H_CM_SAVE_INFO_C', {
        url: '~/codehelp/MA/H_CM_SAVE_INFO_C',
        title: dews.localize.get('저장결과', ""),
        buttons: "close",
        width: 1000,
        height: 482,
        initData: {
          DATA: result 
        },
        close: function(dialogData) {
          callback();
        }
      });
      dialog.open();
    }
  }
  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=ma.cm.util.js