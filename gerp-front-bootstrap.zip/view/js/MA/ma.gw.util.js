/*
 * 메시지 공통 함수
 * /view/js/MA/ma.gw.util.js
 */
(function (dews, gerp, $) {

  /**
   * var MA_UTIL;
   * 
   * dews.ajax.script('~/view/js/MA/ma.gw.util.js', {
   *    once: true,
   *    async: false
   * }).done(function() {
   *    MA_UTIL = gerp.MA.UTIL;
   * });
   * 
   */
  var module = {};
  var moduleCode = "MA"; //모듈 코드
  var objCodeDtl = {};

  /*********************************************************************************************
     *  @desc 중복저장 상세내용 표기
     *  @param {Object} result [필수] 저장 API에서 반환된 list 
     *  @param {function} callback [선택] 다이얼로그 닫기 버튼 후 처리되야 하는 이벤트
     *  @ex  saveCon.SaveConcurr.showDialog(data,callback);
     * ------------------------------------------------------------------------------------------*/

  module.UTIL = {
    /* --------------------------------------------------------------------------------------------
      *  @desc       현재년월일 or 파라미터Date의 년월일 구하기
      *  @return     yyyyMMdd
      *  @call       getToday()
      * ------------------------------------------------------------------------------------------*/
    getToday: function (date) {
      if (typeof (date) == "string") {
        return date;
      }
      else if (typeof (date) == "number") {
        return String(date);
      }
      else {
        if (date) {
          return date.getFullYear().toString() + (date.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
            + (date.getDate()).toString().replace(/^(\d)$/, "0$1");
        } else {
          var today = new Date();
          return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
            + (today.getDate()).toString().replace(/^(\d)$/, "0$1");
        }
      }
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc           objCodeDtl 객체를 초기화한다.
    *  @ex             gerp.PS.UTIL.getCodeClear()
    *  @memo           메뉴마다 사용되는 코드가 다르므로 메뉴를 열때마다 초기화를 시킵니다.
    *  @call           getCodeClear()
    * --------------------------------------------------------------------------------------------*/
    getCodeClear: function () {
      objCodeDtl = {};
    },
    isApproval: function (formId) {
      var returnGwFormInfo = false;
      if (!formId) {
        console.log('전자결재양식등록의 form_id가 누락되었습니다.');
      } else {
        dews.api.get(dews.url.getApiUrl("MA", "MaCommonService", "MaApiProvider_get_gw_form_info"), {
          async: false,
          data: {
            form_id: formId,
          }
        }).done(function (data) {
          // debugger;
          if (data && data.length > 0) {
            returnGwFormInfo = true;
          }
        }).fail(function (xhr, status, error) {
          // setTimeout(function () {
          //   dews.alert("전자결재 사용여부 조회 오류!", { icon: "warning" });
          // }, 200);
        });
      }
      return returnGwFormInfo;
    },    

    UUID_UPDATE: function(func_nm, func_data) {
      var UUID = null;
      if (!func_nm) {
        console.log('func_nm이 누락되었습니다. "예:PS_PJTPRGR_DTL_FILE_DC_UPDATE"');
      } else if (!func_data) {
        console.log('func_data가 누락되었습니다. "예:{company_cd : self.user.company_cd, pjt_no : self.grid.getCellValue(self.grid.select(), "PJT_NO")}"');
      } else {
        dews.api.post(dews.url.getApiUrl("MA", "MACommonUUID_Service", func_nm), {
          async: false,
          data: func_data
        }).done(function (resultData) {
          if (resultData.SUCCESS) {
            UUID = resultData.MSG;
          } else {
            setTimeout(function () {
              dews.alert(resultData.MSG, { icon: 'warning' });
            }, 200);
          }
        }).fail(function (xhr, status, error) {
          setTimeout(function () {
            dews.error('오류가 발생하였습니다.');
          }, 200);
          console.error(error);
        });
      }
      return UUID;
    },
    /**
      * 전자결재의 상태값을 가져와서 mod를 결정해서 리턴합니다.
      * @param {*} athz_rpts_cd
      */
    getApprovalState: function (company_cd, athz_rpts_cd) {
      var mod;
      dews.api.post(dews.url.getApiUrl("MA", "MaCommonService", "getApprovalInfo"), {
        async: false,
        data: {
          company_cd: company_cd,
          athz_rpts_cd: athz_rpts_cd
        }
      }).done(function (row) {
        if (!row || !row.GWAPRVLST_CD || $.inArray(row.GWAPRVLST_CD, ["1", "5", "6"]) != -1) {
          // 전자결재 신규건으로 진행함. mod = "W"
          mod = "W";
        } else {
          // mode = "V"
          mod = "V";
        }
      }).fail(function (xhr, status, error) {
        // dews.ui.snackbar.warning('전자결재 상태값 조회를 실패하였습니다.', false);
      });
      return mod;
    },
    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc           공통코드조회
      *  @ex             gerp.MA.UTIL.getCodeData("PS", "Y:P00730|N:P00790|", null, null, null, null, null);
      *  @memo           이 함수를 타기전에 셋팅하는 부분을 타는 경우는 에러발생함.
      * --------------------------------------------------------------------------------------------
      *  @module_cd      모듈코드
      *  @cd_field_pipe  코드디테일 코드(PIPE 사용) >>> Y:P00730 빈칸여부를 Y, N으로 세팅한다.
      *  @yn_sycode     시스템코드 유무(Y,N)
      *  @base_yn        디폴트 코드구분(Y,N)
      *  @yn_foreign     외국언어적용 유무(Y,N)- Y : NM_SYSDEF2, N : NM_SYSDEF
      *  @end_dt         종료일-종료일이 있는 경우 종료일 이전 데이터 제외 =>(수정)
      *                  common_codeDtl_list API 통신 시 오늘날짜(var today // yyyymmdd포맷)의 데이터를 보낸다. [210203-수정-김동은]
      *  @nm_keyword        검색할 코드 또는 명
      * --------------------------------------------------------------------------------------------
      *  @return         검색된 code에 대한 data set
      * ------------------------------------------------------------------------------------------*/
    getCodeData: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword) {
      if (!objCodeDtl.hasOwnProperty(module_cd)) {
        objCodeDtl[module_cd] = {};
      }

      var isEmpty;
      var str;
      var cd_field_pipe_result = "";
      $.each(cd_field_pipe.split("|"), function (i, v) {
        if (v.indexOf(':') != -1) {
          isEmpty = v.split(":")[0]; // 'Y' or 'N'
          str = v.split(":")[1]; // P00100
          if (isEmpty == "Y") {
            objCodeDtl[module_cd][str] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];
          }
          cd_field_pipe_result = cd_field_pipe_result + str + "|";
        }
        else {
          if (v != null && v != "") {
            objCodeDtl[module_cd][v] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];

            cd_field_pipe_result = cd_field_pipe_result + v + "|";
          }
        }
      });



      dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", "common_codeDtl_list"), {
        async: false,
        data: {
          module_cd: module_cd,
          field_cd_pipe: cd_field_pipe_result,
          syscode_yn: yn_sycode,
          base_yn: base_yn,
          foreign_yn: yn_foreign,
          end_dt: end_dt ? end_dt : gerp.MA.UTIL.getToday(),
          keyword: nm_keyword,
          base_dt: dews.date.format(new Date(), 'yyyyMMdd')
        }
      }).done(function (data) {

        $.each(data, function (i, obj) {
          if (objCodeDtl[module_cd][obj.FIELD_CD] == null) {
            objCodeDtl[module_cd][obj.FIELD_CD] = [{ SYSDEF_CD: obj.SYSDEF_CD, SYSDEF_NM: obj.SYSDEF_NM, FLAG_CD: obj.FLAG_CD, SYSCODE_YN: obj.SYSCODE_YN }];
          } else {
            objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
          }
        });

      }).fail(function (xhr, status, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
      });
      return objCodeDtl;
    },    

    /*
    * 아마란스 전자결재
    */
    AMARANTH_APPROVAL: function (paramData) {

      var loginId = paramData.loginId;
      var company_cd = paramData.company_cd || dews.ui.page.user.companyCode;
      var menu_id = paramData.menu_id;
      var grid = paramData.grid;
      var form_id = paramData.form_id;
      var athz_rpts_cd = paramData.athz_rpts_cd;
      var service_url = paramData.service_url;
      var contents_url = paramData.contents_url;
      var module_cd = paramData.module_cd || "MA";
      // var title = paramData.title;
      var table_nm = paramData.table_nm || "";
      var matkey_vr = paramData.matkey_vr || "";

      
      if (!loginId) {
        setTimeout(function () {
          dews.alert("필수파라미터누락! loginId", { icon: "warning" });
        }, 200);
        return;
      }
      
      if (!company_cd) {
        setTimeout(function () {
          dews.alert("필수파라미터누락! company_cd", { icon: "warning" });
        }, 200);
        return;
      }
      if (!menu_id) {
        setTimeout(function () {
          dews.alert("필수파라미터누락! menu_id", { icon: "warning" });
        }, 200);
        return;
      }

      if (!grid) {
        setTimeout(function () {
          dews.alert("필수파라미터누락! grid", { icon: "warning" });
        }, 200);
        return;
      }

      if (!form_id) {
        setTimeout(function () {
          dews.alert("필수파라미터누락! form_id", { icon: "warning" });
        }, 200);
        return;
      }

      if (!athz_rpts_cd) {
        setTimeout(function () {
          dews.alert("전자결재키값누락! athz_rpts_cd", { icon: "warning" });
        }, 200);
        return;
      }

      var contents_data = null;
      //work2
      var mod = gerp.MA.UTIL.getApprovalState(company_cd, athz_rpts_cd);

      if (!mod) {
        setTimeout(function () {
          dews.alert("결재요청 상태체크에 오류가 있습니다! mod", { icon: "warning" });
        }, 200);
        return;
      }      
      var formIdValue = "";
      //work2
      // var obj = PS_UTIL.getCodeData("MA", "Y:S00400", null, null, null, null, null);
      // var obj = gerp.MA.UTIL.getCodeData("MA", "Y:S00400", null, null, null, null, null);
      // var groupSeq;

      /*WORK3 삭제필요
      [22.10.13-추가-김동은연구원]
      groupSeq는 공통코드(S00400)에서 관리하는 로직 추가
      */
      // if (!obj.MA.S00400) {
      //     dews.alert("그룹웨어의 groupSeq를 찾을 수 없습니다.\n공통코드등록 메뉴의 MA/S00400을 확인하세요.", "warning");
      //     return;
      // }
      // $.each(obj.MA.S00400, function (_idx, _data) {
      //     if (!_data.SYSDEF_CD) {
      //         return true;
      //     }
      //     groupSeq = _data.REL_FLAG_1_CD;
      // });
  
      /* (1) 전자결재정보 가져오기 */
      dews.api.get(dews.url.getApiUrl("MA", "MaCommonService", "MaApiProvider_getGwFormInfo"), {
        async: false,
        data: {
          company_cd: company_cd, 
          form_id: form_id
        }
      }).done(function (form_data) {
        if (form_data && form_data.length > 0) {
          if(mod == "W") {
            // 신규생성 해야 할 경우 contents는 필수입니다.
            // 개발자가 해당메뉴단에서 전달하지 않았다면 전자결재양식등록에 설정된 서비스 URL을 사용하도록 합니다.
            if (!contents_url && !form_data[0].CTNTS_URL) {
              setTimeout(function () {
                dews.alert("본문내용 서비스 URL 누락! contents_url", { icon: "warning" });
              }, 200);
              return;
            } else if(form_data[0].CTNTS_URL) {
              // 전자결재양식등록의 값이 우선시 됩니다.
              contents_url = form_data[0].CTNTS_URL;
            }
            contents_data = contents_url.replace(/ /gi, "").split("/");
            if (!contents_data || contents_data.length < 2) {
              setTimeout(function () {
                dews.alert("본문내용 서비스 URL 형식오류! " + contents_url, { icon: "warning" });
              }, 200);
              return;
            }
          }


          if (mod == "W") {
              //////////////////////////////////////////////////////
              //      mod == "W" 신규건은 Write페이지를 호출합니다. //
              //////////////////////////////////////////////////////

            /* (2) 본문내용(contents) 가져오기. */
            dews.api.post(dews.url.getApiUrl(module_cd, contents_data[0], contents_data[1]), {
                async: false,
                data: {
                  list: JSON.stringify(grid.dataItems(grid.select()))
                }
            }).done(function (contents) {

              if(form_data[0].SERVICE_URL) {
                service_url = form_data[0].SERVICE_URL;
              }

              /* (3) 전자결재 데이터 생성(MA_GWINT_MST) */
              dews.api.post(dews.url.getApiUrl("MA", "MaCommonService", "approval"), {
                  data: {
                      athz_rpts_cd: athz_rpts_cd,
                      menu_id: menu_id,
                      contents: contents,
                      service_url: service_url,
                      module_cd: module_cd,
                      table_nm: table_nm,
                      matkey_vr: matkey_vr
                  }

              }).done(function (approvalData) {
                if (approvalData && approvalData.SUCCESS) {
                  // var aes_key = approvalData.MSG;
                  /* (4) 전자결재페이지 호출 */

                  gerp.MA.UTIL.createEltrAthz_amaranth(
                    {
                        params: {
                              loginId: loginId
                            // , groupSeq: groupSeq                        // 아마란스 서버의 groupseq
                            , outProcessCode: form_data[0].GW_PROC_CD   // 전자결재양식등록 메뉴의 GW_PROC_CD값
                            , approKey: athz_rpts_cd
                            , formId: formIdValue
                            , docId: ''
                            , mod: mod
                            , fileKey: ''
                            , contentsEnc: 'U'
                            , contentsType: 'outer'
                            , appLineList: ''
                            , receiveList: ''
                            , itemList: ''
                            // , contentsStr: '<div><p>본문내용 테스트3333<p></div>'
                            , empSeq: ''
                            , widthYn: true
                        },
                        close: function (data) {
                          grid.options.dataSource.read();
                        }
                    }
                  );

                } else {
                    setTimeout(function () {
                        dews.alert(approvalData.MSG, { icon: approvalData.TYPE_CD });
                    }, 200);
                }
              }).fail(function (xhr, status, error) {
                  console.error(error);
                  setTimeout(function () {
                      dews.error('전자결재진행 오류!');
                  }, 200);
                  return;
              }).always(function () {
                  dews.ui.loading.hide();
              });

            }).fail(function (xhr, status, error) {
                console.error(error);
                setTimeout(function () {
                    dews.error('오류가 발생하였습니다.');
                }, 200);
            });
          }
          else {
              ///////////////////////////////////////////////////////////
              //      mod == "V" 이미 진행된건은 View페이지를 호출합니다. //
              ///////////////////////////////////////////////////////////

              gerp.MA.UTIL.createEltrAthz_amaranth(
              {
                params: {
                      loginId: loginId
                    // , groupSeq: groupSeq                        // 아마란스 서버의 groupseq
                    , outProcessCode: form_data[0].GW_PROC_CD   // 전자결재양식등록 메뉴의 GW_PROC_CD값
                    , approKey: athz_rpts_cd
                    , formId: formIdValue
                    , docId: ''
                    , mod: mod
                    , fileKey: ''
                    , contentsEnc: 'U'
                    , contentsType: 'outer'
                    , appLineList: ''
                    , receiveList: ''
                    , itemList: ''
                    // , contentsStr: '<div><p>본문내용 테스트12431234<p></div>'   // , contentsStr: '<div><p>본문내용 테스트<p></div>'
                    , empSeq: ''
                    , widthYn: true
                },
                close: function (data) {
                  grid.options.dataSource.read();
                }
              }
            );
          }
        }
        else {
          dews.ui.snackbar.warning("[전자결재양식등록]에 등록된 내역이 없습니다.");
        }        
      }).fail(function (xhr, status, error) {
        // debugger;
        dews.ui.snackbar.warning(error, false);
      });    
    },

    getCookieInfo : function(key) {
      let idx = document.cookie.indexOf(`${key}=`);
      if (idx > -1) {
          let lastIdx = document.cookie.indexOf(';', idx);
          if (lastIdx === -1) {
              lastIdx = document.cookie.length;
          }
          return document.cookie.substring(idx, lastIdx).replace(`${key}=`, '');
      } else {
          return;
      }
    },

    createEltrAthz_amaranth: function (param, widthYn) {
      var callback;
      var eltrAthzPopup;

      var width = 981;
      var height = 769;

      if (param.hasOwnProperty("widthYn")) {
        widthYn = param.widthYn;
      }
      if (param.hasOwnProperty("width")) {
        width = param.width;
      }
      if (param.hasOwnProperty("height")) {
        height = param.height;
      }
      if (param.hasOwnProperty("close")) {
        callback = param.close;
      }
      if (param.hasOwnProperty("params")) {
        param = param.params;
      }

      var reqData = {
        loginId: param.loginId,
        groupSeq: param.groupSeq,
        outProcessCode: param.outProcessCode,
        approKey: param.approKey,
        formId: param.formId,
        docId: param.docId,
        mod: param.mod,
        fileKey: param.fileKey,
        contentsEnc: param.contentsEnc,
        contentsType: param.contentsType,
        appLineList: param.appLineList,
        receiveList: param.receiveList,
        itemList: param.itemList,
        contentsStr: param.contentsStr
      };

      // 기존 loading 결제창 제거("전자결재 진행 중입니다." 라는 메세지로 보이도록)
      if (self.$(".dews-ui-loading").length > 0) {
        dews.ui.loading.hide();
      }

      // loading show
      setTimeout(function () {
        dews.ui.loading.show({
          text: "전자결재 진행 중입니다."
        })
      });

      if(this.getCookieInfo(encodeURIComponent('am10:auth:token')) && false){//20230420 쿠키정보에 대한 portal.post 사용은 추가 테스트가 더 필요함
        // reqData['X-Authenticate-Token'] = access_token;
        dews.portal.post('/gw/gw016A01',
        {
          type:"popup",
          popupCode:"UBAP036",
          groupSeq:param.groupSeq,
          loginIdEnc:param.loginId,
          MicroModuleCode:"eap",
          appParams:reqData
        }
        ).then(data => {
          var url = data.resultData.fullUrl;
          eltrAthzPopup = window.open(url, "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");

          try {
            eltrAthzPopup.focus();
          } catch (exception) {
            dews.alert("그룹웨어 팝업이 차단되어있습니다.", "warning");
          }

          var popupTick = setInterval(function () {
            if (eltrAthzPopup.closed) {
              clearInterval(popupTick);
              dews.ui.loading.hide();
              if (callback && $.isFunction(callback)) {
                callback();
              }
            }
          }, 500);

          return eltrAthzPopup;
        });
      }else{

        dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getApprovalSsoUrl"), {
          async: false,
          data: {
            reqData: JSON.stringify(reqData)
          }
        }).done(function (res) {
          if (param.mod === "D") {
            if (res.resultCode === "0") {
              window.gerp.CM.EltrAthzUtil.eltrLoadingClosing();

              dews.alert("결재문서 삭제 완료");
            }
          } else {
            var url = res.resultData.fullUrl;
            eltrAthzPopup = window.open(url, "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");

            try {
              eltrAthzPopup.focus();
            } catch (exception) {
              dews.alert("그룹웨어 팝업이 차단되어있습니다.", "warning");
            }

            var popupTick = setInterval(function () {
              if (eltrAthzPopup.closed) {
                clearInterval(popupTick);
                dews.ui.loading.hide();
                if (callback && $.isFunction(callback)) {
                  callback();
                }
              }
            }, 500);
          }

        }).fail(function (xhr, status, error) {
          window.gerp.CM.EltrAthzUtil.eltrLoadingClosing();
          dews.ui.snackbar.warning(error, false);
        });

        return eltrAthzPopup;
      }
    },
  }
  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=/view/js/MA/ma.gw.util.js