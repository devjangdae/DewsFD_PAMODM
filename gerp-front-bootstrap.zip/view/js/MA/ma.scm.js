/*********************************************************************************************
 * @desc    SCM 모듈 공통 함수
 * @date    2019.07.02
 * @path    /view/js/MA/ma.scm.js
 * @update  2019.08.12
            - 플랫폼2팀에서 정적리소스 변경요청
            - SCM개발2팀 확인하여 CI로 변경하기로 함.
            - SCM개발2팀 확인하여 MA로 변경하기로 함.
            2019.11.08
            - sd.js 소스 추가
 var scmJS;
 dews.ajax.script('~/view/js/MA/ma.scm.js', {
   once: true,
   async: false
 }).done(function() {
   scmJS = gerp.MA;
 });
**********************************************************************************************/
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'MA';  //모듈 코드
  const dynamic_object_name   = 'DYNAMIC_OBJECT'; // 저장메뉴에서 사용할 그리드 값.
  const dynamic_tab_id_prev   = 'DYNAMIC_TAB_';   // 동적컬럼 추가대상 탭 ID
  const dynamic_form_id_prev  = 'DYNAMIC_FORM_';  // 동적컬럼 추가대상 폼패널 ID
  const project_version = "1.0.0.0";
  dews.ajax.script('~/view/js/MA/ma.bignumber.js', {
    once: true,
    async: false
  });

  {
    /*********************************************************************************************
     * 모듈별 점프 번호 선언 작성
     * 우선 SD 기준으로 작성되었기 때문에 각 모듈 담당자가 별도로 수정 필요
    *********************************************************************************************/
    var openMenuDefined = {
      //SD 번호기준
      SODOC_NO: {
        title: "수주번호",
        moveMenu: [
          {
            module_cd: "SD", menu_id: "SLSSTR00300", desc: "수주현황",
            params: { sodoc_no: true, so_dt: false }
          }
        ]

      },
      DLVDOC_NO: {
        title: "납품지시번호",
        moveMenu: [
          {
            module_cd: "SD", menu_id: "SHPSDR00300", desc: "납품지시현황",
            params: { dlvdoc_no: true, do_dt: true, rtp_yn: true, others: [{ col: "rtp_yn", repModule: "SD", repMenu: "SHPSDR00800" }] }
          }
        ]
      },
      GIDOC_NO: {
        title: "출고번호",
        moveMenu: [
          {
            module_cd: "SD", menu_id: "SHPDLV00400", desc: "출고현황",
            params: { gidoc_no: true, invtrx_dt: true, others: [{ col: "rtp_yn", repModule: "SD", repMenu: "SHPDLV00500" }] }
          }
        ]
      },
      BILLDOC_NO: {
        title: "매출번호",
        moveMenu: [
          {
            module_cd: "SD", menu_id: "BILBIV00300", desc: "매출현황",
            params: { billdoc_no: true, bill_dt: true, others: [{ col: "bill_dt", repCol: "actg_dt" }] }
          }
        ]
      },
      BILL_CNCL_DOC_NO: {
        title: "매출취소번호",
        moveMenu: [
          {
            module_cd: "SD", menu_id: "BILBIV00100", desc: "매출취소현황",
            params: { billdoc_no: true, bill_dt: true, others: [{ col: "bill_dt", repCol: "actg_dt" }] }
          }
        ]
      },
      //IM 번호기준
      INVTRX_DOC_NO: {
        title: "수불번호",
        moveMenu: [
          {
            module_cd: "IM", menu_id: "IMARTP00200", desc: "재고전기내역조회",
            params: { invtrx_doc_no: true, others: [{ col: "invtrx_doc_no", repCol: "trans_no_mtldoc" }] }
          }
        ]
      },
      //PU 번호기준
      RCPT_NO: {
        title: "가입고번호",
        moveMenu: [
          {
            module_cd: "PU", menu_id: "PUGGRR00400", desc: "구매입고현황",
            params: { rcpt_no: true, plant_cd: true, plant_nm: true, rcpt_proc_dt: true }
          }
        ]
      },
      //FI 번호기준
      DOCU_NO: {
        title: "전표번호",
        moveMenu: [
          {
            module_cd: "FI", menu_id: "GLDDOC00700", desc: "전표번호",
            params: { docu_no: true, pc_cd: false }
          }
        ]
      },
      CSTS_DOCU_NO: {
        title: "매출원가전표번호",
        moveMenu: [
          {
            module_cd: "FI", menu_id: "GLDDOC00700", desc: "전표번호",
            params: { docu_no: true, pc_cd: false }
          }
        ]
      },
      CNCL_DOCU_NO: {
        title: "취소전표번호",
        moveMenu: [
          {
            module_cd: "FI", menu_id: "GLDDOC00700", desc: "전표번호",
            params: { docu_no: true, pc_cd: false }
          }
        ]
      },
      CNCL_CSTS_DOCU_NO: {
        title: "매출원가 취소전표번호",
        moveMenu: [
          {
            module_cd: "FI", menu_id: "GLDDOC00700", desc: "전표번호",
            params: { docu_no: true, pc_cd: false }
          }
        ]
      },
      //CO 번호기준
      PLMI_DOCU_NO: {
        title: "수익성전표번호",
        moveMenu: [
          {
            module_cd: "CO", menu_id: "PANPIA00100", desc: "수익성전표번호",
            params: { padoc_no: true, others: [{ col: "padoc_no", repCol: "plmi_docu_no" }, { col: "invtrx_dt", repCol: "yyyyMMstart|yyyyMMend" }] }
          }
        ]
      },
      PADOC_NO: {
        title: "수익성전표번호",
        moveMenu: [
          {
            module_cd: "FI", menu_id: "PANPIA00100", desc: "수익성전표번호",
            params: { padoc_no: true, others: [{ col: "invtrx_dt", repCol: "yyyyMMstart|yyyyMMend" }] }
          }
        ]
      },
      CNCL_PLMI_DOCU_NO: {
        title: "수익성전표번호",
        moveMenu: [
          {
            module_cd: "FI", menu_id: "PANPIA00100", desc: "수익성전표번호",
            params: { padoc_no: true, others: [{ col: "padoc_no", repCol: "cncl_plmi_docu_no" }, { col: "invtrx_dt", repCol: "yyyyMMstart|yyyyMMend" }] }
          }
        ]
      },
      MTRIL_LEDG_DOC_NO: {
        title: "자재원장번호",
        moveMenu: [
          {
            module_cd: "CO", menu_id: "MLEMIA00100", desc: "자재원장번호",
            params: { mtril_ledg_doc_no: true, plant_cd: false, invtrx_dt: true, others: [{ col: "mtril_ledg_doc_no", repCol: "mldoc_no" }, { col: "invtrx_dt", repCol: "yyyyMMstart|yyyyMMend" }] }
          }
        ]
      }
    };
  }

  //공통
  module.com = {

    /*********************************************************************************************
     *  @desc   - 메뉴별부가정보로 추가된 그리드의 컬럼에 대해 readonly처리를 해주는 함수 -  setReadonlyMenuDynamicFields_for_grid
     *          - 메뉴별부가정보로 추가된 FormPanel의 컨트롤에 대해 readonly처리를 해주는 함수 - setReadonlyMenuDynamicFields_for_panel
     *  @param  {Object} self     [필수]해당 페이지의 self
     *  @param  {Array} addFields [필수]메뉴별부가정보의 동적필드 배열
     *  @param  {Boolean} read    [필수]읽기전용 처리여부(true, false)
     *********************************************************************************************/
    setReadonlyMenuDynamicFields_for_panel :function (self, addFields, read) {
      try {
        var addPanelFields = addFields.filter(function (item) {
          return item.CTRL_CD >= '5'  //5 : condition panel, 6. Form panel, 7. Tab Panel
        })
        $.each(addPanelFields, function (idx, item) {
          var field_id = item.FIELD_ATTR_CD == '10' ? item.FIELD_ID_RAW + '_TEXT' : item.FIELD_ID_RAW; //10 : 파일
          self[field_id].readonly(read);  //파일을 제외한 나머지 컨트롤 1 : 일반코드값 2 : 날짜(년월일) 3 : 날짜(년월) 4 : 날짜(년) 5 : 금액 6 : 수량 7 : 비율(%) 8 : 비율(일반) 11 : 텍스트(비고)
        })
      }catch(e) {
        console.error(e.message);
      }
    },
    setReadonlyMenuDynamicFields_for_grid : function (self, addFields, read) {
      try {
        var addGridFields = addFields.filter(function (item) {
          return item.CTRL_CD == '1' //1 : grid
        })
        $.each(addGridFields, function (idx, item) {
          var attr = read ? 'readonly' : item.MNDR_YN == 'Y' ? 'required': 'none';
          var field_id = item.FIELD_ATTR_CD == '10' ? item.FIELD_ID_RAW + '_TEXT' : item.FIELD_ID_RAW;
          self[item.OBJECT_CD].setColumn(field_id, {
            attributes: { class: attr },
            editor : {editable : !read}
          })
        })
      }catch(e) {
        console.error(e.message);
      }
    },

    getDefaultProjectVersion: function(){
      return project_version;
    },
    /*********************************************************************************************
     *  @desc   회사환경설정 - 소수점처리
     *          (자바스크립트 특성상 number형 17자리 이상의 숫자는 왜곡됨 주의)
     *  @param  {Object} p_all_list 회사환경설정 전체 리스트
     *  @param  {Object} p_ctrl_cd  설정 통제코드
     *  @param  {Object} p__number  숫자
     *  @param  {Object} p_exch_cd  환종코드
     *  @param  {Object} c_exch_cd  회사환종코드(장부통화)
     *  @return {Number}
     * ------------------------------------------------------------------------------------------*/
    getChangeNumber : function (p_all_list, p_ctrl_cd, p_number, p_exch_cd, c_exch_cd){
      //정상값이 안될때
      if(!p_number)
        return 0;
      else{
        var rtn_number = Number(p_number);
        var obj = null;
        //▶ MA00016 환종별 포맷설정 통제값 =='Y' &&  외화단가 또는 외화금액의 경우.
        if(p_all_list[0]["MA00016_YN"] == 'Y' &&
            (p_ctrl_cd == "MA00004" || p_ctrl_cd == "MA00005")){
          for(var i = 0; i<p_all_list.length; i++){
            if(p_all_list[i]["CTRL_CD"] == p_ctrl_cd && p_all_list[i]["EXCH_CD"] == p_exch_cd){
              obj = p_all_list[i];
            }
          };
        }

        //외화금액일때 회사환종과 환종이 같은 경우 장부금액으로 처리한다. 2021.05.31 (환종코드가 둘다 있어야 해당)
        if(p_ctrl_cd === "MA00005" && c_exch_cd && p_exch_cd && c_exch_cd === p_exch_cd){
          for(var i = 0; i<p_all_list.length; i++){
            if(p_all_list[i]["CTRL_CD"] == "MA00003"){
              obj = p_all_list[i];
              break;
            }
          };
        }

        if(!obj){
          for(var i = 0; i<p_all_list.length; i++){
            if(!p_all_list[i]["EXCH_CD"] && p_all_list[i]["CTRL_CD"] == p_ctrl_cd){
              obj = p_all_list[i];
            }
          };
        }
        if(obj){
          var digits = Math.pow(10, obj.CTRL_VR);  //자리수 변수사용 제곱수 구함.
          var gubun_zero = false;

          if(rtn_number < 0){ //음수일경우 -1 곱한다음 리턴시 다시 -1 곱하여 처리.
            gubun_zero = true;
            rtn_number = Number(rtn_number) *(-1);
          }
          switch (obj.RND_FG){
            case "1":{  //반올림.
              rtn_number = Math.round(rtn_number * digits) / digits;
              break;
            }
            case "2":{ //올림.
              rtn_number = Math.ceil(rtn_number * digits) / digits;
              break;
            }
            case "3":{ //내림.
              rtn_number = Math.floor(rtn_number * digits) / digits;
              break;
            }
          }
          return gubun_zero == true? Number((rtn_number*-1).toFixed(obj.CTRL_VR)) : Number(rtn_number.toFixed(obj.CTRL_VR));
        } else {
          return p_number;
        }


      }
    },
    /*********************************************************************************************
     *  @desc  폼/컨디션패널 요소들 값 제거(소스에 명시된 클래스를 제외한 요소들의 값은 제거되지 않음)
     *  @param {Object} self  [필수]해당 페이지의 self
     *  @param {Object} panel [필수]폼 패널 DOM객체 - self.$expccm00100_form
     *  @ex    scmJS.com.clearForm(self, self.$expccm00100_form);
     * ------------------------------------------------------------------------------------------*/
    clearForm: function(self, panel){
      if(!self || !panel){
        console.error("scmJS - clearForm 함수 인자가 부족합니다.");
      } else{
        var self = self;
        var panel = panel.$element || panel; // dews데이터객체 or dom객체
      }
      $.each(panel.find('*[class^=dews-ui-]'), function(idx, node){
        if($(node).hasClass('dews-ui-multilingual')){ // 제외(dews에서 자동생성되는 클래스)
          return true;
        } else if($(node).hasClass('dews-ui-textbox')){
          self[node.id].text('');
        } else if($(node).hasClass('dews-ui-numerictextbox')){
          self[node.id].value(null);
        } else if($(node).hasClass('dews-ui-dropdownlist')){
          self[node.id].text(null);
          self[node.id].value(null);
        } else if($(node).hasClass('dews-ui-datepicker')){
          self[node.id].value(null);
        } else if($(node).hasClass('dews-ui-codepicker')){
          self[node.id].clearData();
        } else if($(node).hasClass('dews-ui-multicodepicker')){
          self[node.id].clearData();
        } else if($(node).hasClass('dews-ui-periodpicker')){
          self[node.id].setPeriod();
        } else if($(node).hasClass('dews-ui-zipcodepicker')){
          self[node.id].value(null);
        }
      });
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc           단수조정
    *  @ex             maScmJS.com.getNumberRound()
    *  @params         n 값  round PS_P800값
    * --------------------------------------------------------------------------------------------*/
    // P00190 금액단위처리코드
    // *  11 : 1원미만 절사
    // *  12 : 1원미만절상
    // *  13 : 10원미만절사
    // *  14 : 10원미만절상 -> 9를 더한 뒤에 10원미만자리 절사
    // *  15 : 반올림
    // *  16 : 정상
    // *  17 : 100원미만절사
    // *  18 : 100원미만절상 -> 90을 더한 뒤에 100원미만자리 절사.
    // *  19 : 1000원미만절사
    // *  20 : 1000원미만절상 -> 900을 더한 뒤에 1000원미만자리 절사.
    getNumberRound: function (n, round) {
      var returnValue = null;
      if (n) {
        switch (round) {
          case "11": // 1원미만절사
            returnValue = Math.floor(n);
            break;
          case "12": // 1원미만절상
            returnValue = Math.ceil(n);
            break;
          case "13": //10원미만절사
            returnValue = Math.floor(n / 10) * 10;
            break;
          case "14": //10원미만절상
            returnValue = Math.ceil(n / 10) * 10;
            break;
          case "15": //반올림
            returnValue = Math.round(n);
            break;
          case "17": //100원미만절사
            returnValue = Math.floor(n / 100) * 100;
            break;
          case "18": //100원이상절상
            returnValue = Math.ceil(n / 100) * 100;
            break;
          case "19": //1000원미만절사
            returnValue = Math.floor(n / 1000) * 1000;
            break;
          case "20": //1000원미만절상
            returnValue = Math.ceil(n / 1000) * 1000;
            break;
          default:
            returnValue = n;
            break;
        }
      }
      return returnValue;
    },
    /*********************************************************************************************
    * @desc enableForm과 같은 기능 - enableForm 사용할 것(명칭변경)
    * ------------------------------------------------------------------------------------------*/
    activateForm: function(self, panel, bool){
      module.com.enableForm(self, panel, bool);
    },
    /*********************************************************************************************
     *  @desc  폼/컨디션패널 요소들 enable true/false 처리
     *  @param {Object}  self  [필수]해당 페이지의 self
     *  @param {Object}  panel [필수]패널 객체 - self.$expccm00100_form
     *  @param {Boolean} bool  true(활성화)/false(비활성화) - 파라미터 없을시 true처리
     *  @ex    scmJS.com.activateForm(self, self.$expccm00100_form, false);
     * ------------------------------------------------------------------------------------------*/
    enableForm: function(self, panel, bool){
      if(!self || !panel){
        console.error("scmJS - enableForm 함수 인자가 부족합니다.");
      } else{
        var self = self;
        var panel = panel.$element || panel; // dews데이터객체 or dom객체
      }

      bool = (bool == undefined ? true : bool);
      $.each(panel.find('*[class^=dews-ui-]'), function(idx, node){
        if(!$(node).hasClass('dews-ui-multilingual') && !$(node).hasClass('dews-ui-title')){
          if(!$(node).hasClass('dews-ui-radio-group dews-form-control dews-control dews-control-activate'))
            self[node.id].enable(bool);
        }
      });
    },
    /*********************************************************************************************
     *  @desc  패널 요소들 readonly true/false 처리 함수
     *  @param {object}  self 해당 페이지의 self
     *  @param {object}  panel    패널 DOM객체 - self.$immewp00100_form
     *  @param {Boolean} cond    true(활성화)/false(비활성화)
     *  @ex    scmJS.com.readonlyPanel(self, self.$immewp00100_form, true(default = true));
     * ------------------------------------------------------------------------------------------*/
    readonlyPanel: function (self, panel, cond) {
      if (!self || !panel) {
        console.error("scmJS - readonlyPanel 함수 인자가 부족합니다.");
      }

      panel = panel.$element || panel;
      cond = cond == null || typeof cond !== "boolean"
        ? true
        : cond;

      $.each(panel.find("*[class^=dews-ui-]"), function (idx, node) {
        if (!$(node).hasClass("dews-ui-multilingual")) {
          if (
            !(
              $(node).hasClass("dews-ui-radio-group dews-form-control dews-control dews-control-activate")
              || $(node).hasClass("dews-ui-title")
            )
          )
            self[node.id].readonly(cond);
        }
      });
    },
    /*********************************************************************************************
     *  @desc  그리드에서 원하는 상태(updated, added, none)행의 index를 배열로 가져옴 - 현재 노출된 데이터만
     *  @param {Object} grid  [필수]그리드 객체
     *  @param {String} state 원하는 상태값(값 없을시 updated, added 상태값 가져옴)
     *  @ex    var updatedIndex = scmJS.com.getGridIndex(mstGrid, 'updated');
     * ------------------------------------------------------------------------------------------*/
    getGridIndex: function(grid, state){
      var return_arr = [];
      $.each(grid.dataItems(), function(idx){
        if(!state && (grid.getRowState(idx) == 'updated' || grid.getRowState(idx) == 'added')){ // state가 falsy값일 때
          return_arr.push(idx);
        } else if(state == 'updated' && grid.getRowState(idx) == 'updated'){
          return_arr.push(idx);
        } else if(state == 'added' && grid.getRowState(idx) == 'added'){
          return_arr.push(idx);
        } else if(state == 'none' && grid.getRowState(idx) == 'none'){
          return_arr.push(idx);
        } else if(!state && grid.getRowState(idx) == 'none'){
        } else{
          console.error("scmJS - getGridIndex 함수의 인자가 잘못되었습니다.");
        }
      });
      return return_arr;
    },
    /*********************************************************************************************
     *  @desc   그리드에서 업데이트된(updated, added 상태의) 행들의 인덱스, 데이터를 가져옵니다
                현재 그리드에서 노출된 데이터만 가져오므로, 하위 그리드는 사용 불가능
     *  @param  {Object} grid  필수]그리드 객체
     *  @return {Array}  객체 배열(index, data)
     *  @ex     var updatedRows = scmJS.com.getUpdatedRows(mstGrid);
     * ------------------------------------------------------------------------------------------*/
    getUpdatedRows: function(grid){
      var return_arr = [];
      var updated_items = module.com.getGridIndex(grid);
      $.each(grid.dataItems(), function(idx, item){
        if(grid.getRowState(idx) == 'updated' || grid.getRowState(idx) == 'added'){
          return_arr.push({
            index: updated_items.shift(),
            data: item
          });
        }
      });
      return return_arr;
    },
    /*********************************************************************************************
     *  @desc   필수값 체크로직에 사용(module.com.getRequiredFields)
     * ------------------------------------------------------------------------------------------*/
    makeHashMap: function(){
      var HashMap = function () {this.map = new Array();};
      HashMap.prototype = {
        put: function (key, value) {this.map[key] = value;},
        get: function (key) {return this.map[key];}
      }
      obj = new HashMap();
      return obj;
    },
    /*********************************************************************************************
     *  @desc   컨테이너의 타입을 String으로 반환해주는 메소드 - 필수값체크(validate) 외에서 사용하기 위함
     *  @param  {Object} container [필수]컨테이너 객체
     *  @return {String} 해당 파라미터의 컨테이너 타입
     *  @ex     var containerType = scmJS.com.getContainerType(mstGrid);
     * ------------------------------------------------------------------------------------------*/
    getContainerType: function(container){
      var element = container.$element || container.element || container._element;
      var containerType = '';
      if(container.hasOwnProperty('menu')){
        containerType = 'Menu';
      } else if(element.hasClass('dews-form-panel') || element.hasClass('dews-ui-form-panel')){
        containerType = 'FormPanel';
      } else if(element.hasClass('dews-form-panel') || element.hasClass('dews-ui-condition-panel')){
        containerType = 'ConditionPanel';
      } else if(element.hasClass('dews-ui-cardlist')){
        containerType = 'CardList';
      } else if(element.hasClass('dews-ui-treeview')){
        containerType = 'TreeView';
      } else if(element.parents('.dews-ui-grid').length > 0 || element.hasClass('dews-ui-grid')){
        containerType = 'Grid';
      } else if(element.parents('.dews-ui-treegrid').length > 0 || element.hasClass('dews-ui-treegrid')){
        containerType = 'TreeGrid';
      } else if(element.hasClass('dews-ui-tab-panel')){
        containerType = 'TabPanel';
      } else{}
      return containerType;
    },
    /*********************************************************************************************
     *  @desc   컨트롤 타입을 String으로 반환해주는 메소드
     *  @param  {Object} container [필수]컨트롤 객체
     *  @return {String} 해당 파라미터의 컨트롤 타입
     *  @ex     var controlType = scmJS.com.getControlType(self.s_tran_fg.value());
     * ------------------------------------------------------------------------------------------*/
    getControlType: function(control){
      var node = control.element || control._element;
      var controlType = '';
      if($(node).hasClass('dews-ui-codepicker')){
        controlType = 'codepicker';
      } else if($(node).hasClass('dews-ui-dropdownlist')){
        controlType = 'dropdownlist';
      } else if($(node).hasClass('dews-ui-textbox')){
        controlType = 'textbox';
      }else{
      }
      return controlType;
    },
    /*********************************************************************************************
     *  @desc   validate 메소드에서 사용,
                container의 타입(그리드, 폼 패널 등)에 따라 필수값 필드명을 map으로 return
     *  @param  {Object} container [필수]필수 컬럼명을 추출할 컨테이너 객체
     *  @return {Object} 필수값 컬럼명을 배열로 리턴받음
     * ------------------------------------------------------------------------------------------*/
    getRequiredFields: function(container, exceptArray){
      var requiredFields = module.com.makeHashMap();
      if(typeof exceptArray == 'string'){
        exceptArray = [exceptArray];
      }
      switch(module.com.getContainerType(container)){
        case 'FormPanel':{
          var form = container;
          /* 폼 패널 내 required 필드 추출 - required 클래스를 갖고
                                            data-dews-bind-value 또는 data-dews-bind-code  property를 가질것
          */
          $.each(form.$element.find('*[class^=dews-ui-]'), function(idx, node){
            var key = $(node).data('dews-bind-value') || $(node).data('dews-bind-code') || $(node).data('dews-bind-column') || $(node).data('dews-bind-name');
            if($(node).hasClass('required') && key && exceptArray.indexOf(key) == -1){
              requiredFields.put(key, $($(node).parents('li')[0]).children('label').text());
            }
          });
          break;
        }
        case 'Grid':{
          var grid = container;
          var gridColumns = grid.columns;
          var gridKey = getObjectKeyValue(gridColumns, "key"); // 컬럼
          var gridVal = getObjectKeyValue(gridColumns, "val");
          var requiredFields = module.com.makeHashMap();
          for(var i=0;i<gridKey.length;i++){
            if(gridVal[i].attributes && gridVal[i].attributes.class == "required" && exceptArray.indexOf(gridVal[i].field) == -1){
              requiredFields.put(gridVal[i].field, gridVal[i].title);
            }
          }
          break;
        }
      }
      function getObjectKeyValue(obj, gbn) {
        var result = [];
        if (gbn == "key") {
          Object.keys(obj).forEach(function eachKey(key) {
            result.push(key);
          });
        } else if (gbn == "val") {
          Object.keys(obj).forEach(function eachKey(key) {
            if (obj[key] == undefined) {
              result.push("");
            } else {
              result.push(obj[key]);
            }
          });
        }
        return result;
      }
      return requiredFields;
    },
    /*********************************************************************************************
     * 추후 작성 예정 메소드, 사용하지 말 것
     * @desc  트리뷰의 더티데이터를 잡기 위한 함수
     * ------------------------------------------------------------------------------------------*/
    setTreeDirtyData: function(container, dirtyData){
      if(!module.com.getContainerType(container) == 'TreeView'){
        console.error("scmJS - setTreeDirtyData: 객체가 트리뷰가 아닙니다.", container);
      } else if(!dirtyData.hasOwnProperty('Added') || !dirtyData.hasOwnProperty('Updated') || !dirtyData.hasOwnProperty('Deleted')){
        console.error("scmJS - setTreeDirtyData: 두번째 인자가 잘못되었습니다.");
        console.error("scmJS - setTreeDirtyData: Added, Updated, Deleted 배열 변수를 갖는 객체여야 합니다.");
      } else{
        container._dsTree = dirtyData;
        container.getDirtyData = function(){
          return container._dsTree;
        }
      }
    },
    /*********************************************************************************************
     *  @desc    카드리스트, 그리드 등에 연결될 입력컨테이너를 설정해주는 메소드
     *  @param   {Object} container       [필수]값을 가지고 있을 컨테이너 객체
     *  @param   {Object} inputContainer  [필수]값을 표시, 입력할 컨테이너 객체
     *  @ex      scmJS.com.setBind(cardList, formPanel);
     * ------------------------------------------------------------------------------------------*/
    setBind: function(container, inputContainer){
      if(!container || !inputContainer){
        console.error("scmJS - setBind 함수의 인자가 잘못되었습니다.");
      } else{
        if(container.sdBindContainer){
          container.sdBindContainer.push(inputContainer);
        } else{
          container.sdBindContainer = [inputContainer];
        }
        inputContainer.sdBindContainer = container;
        inputContainer.$sdBindContainer = container.$element || container.element;
      }
    },
    setTabBind: function(container, inputContainer){
      if(!container || !inputContainer){
        console.error("scmJS - setBind 함수의 인자가 잘못되었습니다.");
      } else{
        inputContainer.sdBindContainer = container;
        inputContainer.$sdBindContainer = container.$element || container.element;
      }
    },
    /*********************************************************************************************
     *  @desc    컨테이너에 대한 필수 입력값 유효성 체크하는 함수
                 - dirtyData에 대한 필수값 유효성을 체크하고 입력되지 않은 값의 위치로 이동합니다.
                 - 상위 컨테이너(setDetail로 묶인)가 있을시 scmJS.com.setDetail을 사용할 것
                 - 체크 가능한 컨테이너: 그리드, 카드리스트
     *  @param   {Object} container [필수]최상위 컨테이너
     *  @param   {Object} options   = { // 옵션 객체, 파라미터로 넘겨주지 않아도 무방.
                             @param {Boolean} check    체크된 행의 필수값만 검사합니다 (!단일 '그리드'만 사용 가능)
                             @param {Boolean} alert    필수값 누락시 alert를 띄웁니다(기본: snackbar)
                             @param {Boolean} single   인자로 넘어온 container의 필수값만 체크
                             @param {Boolean} loading  필수값 누락을 검사하는 동안 로딩창을 생성
                             @param {String}  except   필수값 표시가 되어있지만 체크하고 싶지 않은 컬럼명(들)을 기입
                                                       // String 또는 String 배열값.
                                                       // 주의 - 상/하위 그리드의 컬럼에 모두 적용
                          }
     *  @return  {Boolean} 필수값 누락시 false, 필수값 모두 있을시 true
     *
     *  ## 테스트된 관계
     *  - 단그리드, n단 그리드
     *  - 카드리스트-마스터그리드-디테일그리드(PUBINF00400)
     *  - 그리드(폼패널바인드)-디테일그리드(SDCCTC00500)
     *
     *  ### 사용예시 ###
     *  # 단그리드 - scmJS.com.validate(mstGrid);
     *  # n단 그리드 - scmJS.com.setDetail(mstGrid, dtlGrid, dtlGridDataSource);
     *                scmJS.com.validate(mstGrid);
     *  # 카드리스트 - scmJS.com.setBind(mstCard, self.formPanel);
     *                scmJS.com.setDetail(mstCard, mstGrid, mstGridDataSource);
     *                scmJS.com.setDetail(mstGrid, dtlGrid, dtlGridDataSource);
     *                scmJS.com.validate(mstCard);
     *
     *  !! 사용시 선행사항 !!
     *  ## setDetail로 묶어준 디테일까지 체크시, scmJS.com.setDetail을 사용할 것
     *  ## scmJS.com.setDetail 관계시, 조회될 때 back에서 마스터의 _uid를 받아와 dtlGrid의 _uidParent에 넣어줄 것
     *  ## scmJS.com.setDetail 관계시, dtlGrid의 행 추가 이벤트에 마스터의 _uid를 받아와 dtlGrid의 _uidParent에 넣어줄 것
     *                               (_uidParent가 없으면 마스터를 찾아 이동할 수 없음)
     *  ## 그리드에 값을 입력하는 경우
     *  - 그리드 객체의 필드에 attributes:{class:'required'}를 명시해줄 것
     *
     *  ## 폼 패널에 값을 입력하는 경우(카드리스트, 그리드, 트리뷰-미구현)
     *  - 바인드 관계를 명시하기 위해, scmJS.com.setBind를 먼저 사용할 것
     *  - 폼 패널의 필드들에, required 클래스와 data-dews-bind-value || data-dews-bind-code || data-dews-bind-column || data-dews-bind-text을 명시할 것
     *                                       (bindTo, bindPanel시 사용되는 data property)
     * ------------------------------------------------------------------------------------------*/
    validate: function(container, options){
      // 옵션 인자값 세팅
      var checkOption   = options ? (options.check   == true ? true : false) : false; // 체크박스에 체크한 값만 검사할 것인지
      var alertOption   = options ? (options.alert   == true ? true : false) : false; // snackbar를 alert로 대체
      var loadingOption = options ? (options.loading == true ? true : false) : false; // loading bar를 띄울지 옵션
      var singleOption  = options ? (options.single  == true || checkOption == true ? true : false) : false; // check 옵션값이 true면 단일 컨테이너 검사 - 디테일 검사 X
      var exceptArray   = options ? (typeof options.except == "string" || Array.isArray(options.except) ? options.except : [] ) : [];
      // var self = options ? (options.dewself || options.self ) : undefined;
      var self = dews.ui.page;
      // 단일 컨테이너만 검사할 지 체크
      if(!singleOption){
        singleOption = container.sdMaster || container.sdDetail ? false : true;
      }
      // 로딩바 open
      if(loadingOption == true && !container.sdMaster){
        dews.ui.loading.show({text: "필수값 체크중입니다."});
      }
      var containerType = module.com.getContainerType(container); // 필수값 체크할 컨테이너의 타입(String형으로 'Grid', 'CardList' 등 반환)
      var requiredFields; // 아래에서 사용할 필수값(컬럼, 컬럼명) 변수
      var tabCheckContainer; // 필수값 누락된 컨테이너(상위에 탭 패널이 있는지 체크하여 탭을 클릭하기 위함)
      var result = true; // 최종 반환값(Boolean) - 필수값 누락시 false, 모두 입력되었을시 true
      var requiredChkRows = []; // 필수값 체크할 데이터들
      var dirtySources = [];
      // scmJS.com.setDetail 걸린(하위) 그리드 만큼 해당함수 재귀, 단일 컨테이너 검사시
      if(!singleOption){
        $.each(container.sdDetail, function(idx, dtlContainer){
          result = module.com.validate(dtlContainer, options);
          if(!result){return false;}
        });
      }
      // 더티데이터 체크할 데이터소스 세팅
      switch(containerType){
        case 'Grid':{
          container.sdDataSource = container.sdDataSource || container.dataSource;
          break;
        }
        case 'CardList':{
          container.sdDataSource = container.sdDataSource || container.options.dataSource;
          break;
        }
        case 'TreeView':{
          // container.sdDataSource = container.sdDataSource || container.dataSource;
          break;
        }
      }

      if(container.sdDataSource){
        // dirtyData 가져옴
        $.merge(dirtySources, container.sdDataSource.getDirtyData().Added);
        $.merge(dirtySources, container.sdDataSource.getDirtyData().Updated);
      }

      // 재귀함수 이므로, 앞에서 필수값 누락이 있다면 더 이상 검사하지 않도록 result 변수값으로 분기 처리
      if(result){
        switch(containerType){ // 컨테이너에 구분에 따라 다르게 필수값 체크
          case 'Grid': { // 그리드일 때,
            // bind 관계의 컨테이너를 찾음, 없다면 해당 컨테이너 자신
            var inputContainerArr = container.sdBindContainer ? container.sdBindContainer : [container];
            // 1. setDetail 관계가 있을때 - dirty data로 먼저 검사, 마스터들을 먼저 select 후 2.에서 다시 위치를 찾음
            if(!singleOption){
              $.each(inputContainerArr, function(index, inputContainer){ // setBind된 컨테이너 만큼
                requiredFields = module.com.getRequiredFields(inputContainer, exceptArray); // 필수값 가져옴
                if(Object.keys(requiredFields.map).length > 0){ // 필수값으로 선언되어있는 필드가 없을때도 dirtyRows만큼 반복하는 것 방지하기 위함
                  $.each(dirtySources, function(idx, dirtyData){ // 더티체크
                    $.each(Object.keys(requiredFields.map), function(i, key){
                      if(module.com.isNull(dirtyData[key])){ // 필수값 누락시(Number 0 제외)
                        if(container.sdMaster){ // 마스터 컨테이너(setDetail) 존재시 상위 행을 먼저 클릭하기 위함(해당 위치로 이동)
                          if(!dirtyData._uidParent){
                            console.error("scmJS - validate: 누락된 필수값에 '_uidParent'가 필요합니다.", container);
                          }
                          module.com.selectMstContainer(container, dirtyData._uidParent);
                        }
                        result = false; // 더이상 필수값 체크하지 않음
                        return false;
                      }
                    });
                    if(!result){return false;}
                  });
                }
                if(!result){return false;}
              });
            }
            // 2. setDetail 관계가 없거나 / single 옵션이 true, check 옵션이 true 이거나 / 앞(1)에서 필수값 누락인 데이터가 있을때
            if(!result || singleOption){
              if(checkOption == true){ // 그리드의 checked 옵션
                var checkedRows = container.getCheckedRows();
                var checkedIndex = container.getCheckedIndex();
                $.each(checkedRows, function(idx, item){
                  requiredChkRows.push({
                    index: checkedIndex[idx],
                    data: item
                  });
                });
              } else{
                requiredChkRows = module.com.getUpdatedRows(container); // 추가/수정된 데이터와 행 가져옴
              }
              $.each(inputContainerArr, function(index, inputContainer){
                var inputContainerType = module.com.getContainerType(inputContainer);
                var stopFG = true;
                requiredFields = module.com.getRequiredFields(inputContainer, exceptArray);
                if(Object.keys(requiredFields.map).length > 0){ // 필수값으로 선언되어있는 필드가 없을때도 dirtyRows만큼 반복하는 것 방지하기 위함
                  $.each(requiredChkRows, function(idx, dirtyData){
                    $.each(Object.keys(requiredFields.map), function(idx, key){
                      if(dirtyData.data.hasOwnProperty(key) && module.com.isNull(dirtyData.data[key])){ // 필수값 누락시
                        stopFG = false;
                        result = false;
                        tabCheckContainer = inputContainer; // 컨테이너의 탭 체크
                        container.setFocus(); // 해당 그리드로 포커스
                        container.select(dirtyData.index); // 해당 행 select
                        messageOpen(requiredFields.get(key));
                        if(inputContainerType == 'FormPanel'){ // 입력 컨테이너가 폼 패널일 때 formPanel.validate
                          if(self){
                            $.each(inputContainer.$element.find('*[class^=dews-ui-]'), function(nIndex, node){
                              var data = $(node).data('dews-bind-value') || $(node).data('dews-bind-code') ||
                                        $(node).data('dews-bind-column') || $(node).data('dews-bind-name');
                              if(data == key){
                                controlFocus(node);
                              }
                            });
                          }
                          inputContainer.validate();
                        } else{ // 그리드일 때로 가정, 누락 행으로 이동
                          container.searchCell({
                            fields: [key],
                            value: '',
                            startIndex: dirtyData.index
                          });
                          if(container.columns[key].visible == false){
                            console.error("scmJS - validate: 필수값이 누락되었지만 컬럼의 visible값이 false 입니다.",  key);
                          } else{
                            container.showTooltip(dirtyData.index, key, {
                              // 툴팁 옵션
                              type: 'required',
                              text: dews.localize.get('필수 입력 항목입니다.', 'M0000424'),
                              position: 'top',
                              durationTime: 1,
                              fadeOutTime: 3000
                            });
                          }
                        }
                        return false;
                      }
                    });
                    if(!stopFG){return false;}
                  });
                }
                if(!stopFG){return false;}
              });
            }
            break;
          }
          case 'TreeGrid':{
            break;
          }
          case 'CardList':{ // 카드리스트 체크
            var requiredChkRows = module.com.getUpdatedRows(container); // 추가/수정된 데이터와 행 가져옴
            var inputContainerArr = container.sdBindContainer; // 카드리스트와 연결된 컨테이너(폼패널 또는 그리드 외)
            var hidddenCheckYn;
            $.each(inputContainerArr, function(index, inputContainer){ // 연결된 컨테이너 만큼 반복
              var inputContainerType = module.com.getContainerType(inputContainer);
              if(inputContainer.$element.closest('li') && inputContainer.$element.closest('li').hasClass('dews-tab-item')){
                hidddenCheckYn = inputContainer.$element.closest('li')[0].style.display == 'none' ? true : false;
              }
              if(hidddenCheckYn){
                return true;
              }
              var stopFG = true;
              requiredFields = module.com.getRequiredFields(inputContainer, exceptArray);
              if(Object.keys(requiredFields.map).length > 0){ // 필수값으로 선언되어있는 필드가 없을때도 dirtyRows만큼 반복하는 것 방지하기 위함
                $.each(requiredChkRows, function(idx, dirtyData){
                  $.each(Object.keys(requiredFields.map), function(idx, key){
                    if(dirtyData.data.hasOwnProperty(key) && module.com.isNull(dirtyData.data[key])){ // 필수값 누락시
                      stopFG = false;
                      result = false;
                      tabCheckContainer = inputContainer; // 컨테이너의 탭 체크
                      container.setFocus(); // 해당 그리드로 포커스
                      container.select(dirtyData.index); // 해당 행 select
                      messageOpen(requiredFields.get(key));
                      if(inputContainerType == 'FormPanel'){ // 입력 컨테이너가 폼 패널일 때 formPanel.validate
                        if(self){
                          $.each(inputContainer.$element.find('*[class^=dews-ui-]'), function(nIndex, node){
                            var data = $(node).data('dews-bind-value') || $(node).data('dews-bind-code') ||
                                      $(node).data('dews-bind-column') || $(node).data('dews-bind-name');
                            if(data == key){
                              controlFocus(node);
                            }
                          });
                        }
                        inputContainer.validate();
                      } else{ // 그리드일 때로 가정, 누락 행으로 이동
                        container.searchCell({
                          fields: [key],
                          value: '',
                          startIndex: dirtyData.index
                        });

                        if(container.columns[key].visible == false){
                          console.error("scmJS - validate: 필수값이 누락되었지만, visible: false [" + key + "]");
                        } else{
                          container.showTooltip(dirtyData.index, key, {
                            // 툴팁 옵션
                            type: 'required',
                            text: dews.localize.get('필수 입력 항목입니다.', 'M0000424'),
                            position: 'top',
                            durationTime: 1,
                            fadeOutTime: 3000
                          });
                        }
                      }
                      return false;
                    }
                  });
                  if(!stopFG){return false;}
                });
              }
              if(!stopFG){return false;}
            });
            break;
          }
          case 'TreeView':{
            var mergeData = [];
            $.merge(mergeData, container.dataItems());
            $.each(mergeData, function(idx, item){
              getTreeDirtyData(item);
            });
            var inputContainerArr = container.sdBindContainer; // 카드리스트와 연결된 컨테이너(폼패널 또는 그리드 외)
            var hidddenCheckYn;
            $.each(inputContainerArr, function(index, inputContainer){ // 연결된 컨테이너 만큼 반복
              var inputContainerType = module.com.getContainerType(inputContainer);
              if(inputContainer.$element.closest('li') && inputContainer.$element.closest('li').hasClass('dews-tab-item')){
                hidddenCheckYn = inputContainer.$element.closest('li')[0].style.display == 'none' ? true : false;
              }
              if(hidddenCheckYn){
                return true;
              }
              var stopFG = true;
              requiredFields = module.com.getRequiredFields(inputContainer, exceptArray);
              if(Object.keys(requiredFields.map).length > 0){ // 필수값으로 선언되어있는 필드가 없을때도 dirtyRows만큼 반복하는 것 방지하기 위함
                $.each(dirtySources, function(idx, dirtyData){
                  $.each(Object.keys(requiredFields.map), function(idx, key){
                    if(dirtyData.hasOwnProperty(key) && module.com.isNull(dirtyData[key])){ // 필수값 누락시
                      stopFG = false;
                      result = false;
                      tabCheckContainer = inputContainer; // 컨테이너의 탭 체크
                      container.select(container.findByUid(dirtyData.uid)[0]);
                      messageOpen(requiredFields.get(key));
                      if(inputContainerType == 'FormPanel'){ // 입력 컨테이너가 폼 패널일 때 formPanel.validate
                        if(self){
                          $.each(inputContainer.$element.find('*[class^=dews-ui-]'), function(nIndex, node){
                            var data = $(node).data('dews-bind-value') || $(node).data('dews-bind-code') ||
                                      $(node).data('dews-bind-column') || $(node).data('dews-bind-name');
                            if(data == key){
                              controlFocus(node);
                            }
                          });
                        }
                        inputContainer.validate();
                      }
                      return false;
                    }
                  });
                  if(!stopFG){return false;}
                });
              }
              if(!stopFG){return false;}
            });
            break;
          }
          // 단순 컨디션/폼 패널 체크시 사용
          // 누락 데이터 체크, 해당탭으로 이동, 스낵바(or Alert), 포커스처리
          case 'FormPanel':
          case 'ConditionPanel':{
            if(self){
              $.each(container.$element.find('*[class^=dews-ui-]'), function(idx, node){
                if(!$(node).hasClass('required')){
                  return true;
                } else if($(node).hasClass('dews-ui-multilingual')){ // 제외(dews에서 자동생성되는 클래스)
                  return true;
                } else if($(node).hasClass('dews-ui-textbox')){
                  result = !module.com.isNull(self[node.id].text());
                } else if($(node).hasClass('dews-ui-numerictextbox')){
                  result = !module.com.isNull(self[node.id].value());
                } else if($(node).hasClass('dews-ui-dropdownlist')){
                  result = !module.com.isNull(self[node.id].value());
                } else if($(node).hasClass('dews-ui-datepicker')){
                  result = !module.com.isNull(self[node.id].value());
                } else if($(node).hasClass('dews-ui-codepicker')){
                  result = !module.com.isNull(self[node.id].code());
                } else if($(node).hasClass('dews-ui-multicodepicker')){
                  result = !module.com.isNull(self[node.id].codes().length, true);
                } else if($(node).hasClass('dews-ui-periodpicker')){
                  result = !module.com.isNull(self[node.id].getStartDate());
                  result = !result ? result : module.com.isNull(self[node.id].getEndDate());
                } else if($(node).hasClass('dews-ui-zipcodepicker')){
                  result = !module.com.isNull(self[node.id].value());
                }

                if(!result){
                  var column = $(node).parents('li').eq(0).children('label').text(); // 라벨 텍스트
                  tabCheckContainer = container; // 해당 탭으로 이동
                  messageOpen(column); // 라벨 텍스트 값으로 메시지 처리
                  container.validate();
                  controlFocus(node);
                  return false;
                }
              });
            } else{
              console.error("scmJS - validate 함수의 인자가 부족합니다. - self(dewself)");
              result = false;
            }
            break;
          }
        }
      }

      // 컨트롤에 포커스.(일부 컨트롤들은 다른 노드들과 다르게 id만으로 포커싱 불가하여 분기처리한 메소드)
      function controlFocus(node){
        if($(node).hasClass('dews-ui-numerictextbox')){ // numeric-textbox
          if($(node).css('display') != 'none'){
            $(node).focus();
          } else{
            $(node).siblings('input[type="text"].required').focus();
          }
        }
        else if($(node).hasClass('dews-ui-dropdownlist')){ // dropdown-list
          $(node).parent().focus();
        } else if($(node).hasClass('dews-ui-codepicker')){ // codepicker
          $(node).siblings('.dews-codepicker-text').focus();
        } else{
          $(node).focus();
        }
      }

      // 메시지 띄우는 함수
      function messageOpen(column){
        setTimeout(function(){
          if(alertOption == true){
            dews.alert("[" + column + "]은(는) 필수 입력값 입니다.", 'warning');
          }
          // else{
          //   dews.ui.snackbar.warning("[" + column + "]은(는) 필수 입력값 입니다.");
          // }
        },10);
      }

      function getTreeDirtyData(treeData){
        if(treeData.children && treeData.children._view && treeData.children._view.length > 0){
          $.each(treeData.children._view, function(idx, item){
            getTreeDirtyData(item);
          })
        }
        if(treeData.dirty){
          dirtySources.push(treeData);
        }
      }

      // 필수값 누락된 컨테이너의 탭으로 이동
      if(!result){module.com.tabSelect(tabCheckContainer);}
      // 로딩바 제거
      if(loadingOption == true && (!container.sdDetail || singleOption)){
        dews.ui.loading.hide();
      }
      return result;
    },
    /**
     *  @desc   dews의 setDetail관계를 설정하며,
                추가로 validate 메소드에 필요한 관계를 설정
     *  @param  {Object} mstContainer [필수]마스터 컨테이너
     *  @param  {Object} dtlContainer [필수]디테일 컨테이너
     *  @param  {Object} dtlContainerDataSource : 디테일 컨테이너의 데이터소스
     *  @ex     scmJS.com.setDetail(mstGrid, dtlGrid, dtlGridDataSource);
     * ------------------------------------------------------------------------------------------*/
    setDetail: function(mstContainer, dtlContainer, dtlDataSource){
      if(!mstContainer || !dtlContainer || !dtlDataSource){
        console.error("scmJS - setDetail 함수의 인자가 부족합니다.");
      } else{
        var _uidBool = false; // 마스터 컨테이너의 데이터소스에 _uid가 있는지 체크용
        var _uidParentBool = false; // 디테일 컨테이너의 데이터소스에 _uidParent가 있는지 체크용

        // mstContainer가 어떤 컨테이너의 하위 컨테이너라면, sdDataSource를 가지고 있을 것이지만, 아니라면 아래에서 초기화
        var mstDataSource = mstContainer.sdDataSource;

        if(!mstDataSource){ // mstDataSource 초기화
          switch(module.com.getContainerType(mstContainer)){
            case 'Grid':{ // 그리드일 때
              mstDataSource = mstContainer.dataSource;
              break;
            }
            case 'CardList':{ // 카드리스트 일 때
              mstDataSource = mstContainer.options.dataSource;
              break;
            }
            default:{
              console.error("scmJS - setDetail 함수 오류: 그리드 또는 카드리스트가 아닙니다.", mstContainer);
              break;
            }
          }
        }

        // 마스터 컨테이너의 데이터소스에 _uid가 있는지 체크
        $.each(mstDataSource.options.schema.model.fields, function(idx, item){
          if(item.field == '_uid'){ // _uid가 존재하면,
            _uidBool = true;
            return false;
          }
        });
        // 디테일 컨테이너의 데이터소스에 _uidParent가 있는지 체크
        $.each(dtlDataSource.options.field, function(idx, item){
          if(item.field == '_uidParent'){// _uidParent 존재하면,
            _uidParentBool = true;
            return false;
          }
        });

        mstContainer.setDetail(dtlContainer); // setDetail
        dtlContainer.sdMaster = mstContainer; // 상위 컨테이너 설정
        dtlContainer.sdDataSource = dtlDataSource; // 하위 컨테이너에 데이터소스 설정

        if(mstContainer.sdDetail){ // 하나의 상위 컨테이너에 여러 하위 컨테이너가 물릴 수 있으므로 하위 컨테이너를 배열로 가짐
          $.merge(mstContainer.sdDetail, [dtlContainer]);
        } else{
          mstContainer.sdDetail = [dtlContainer];
        }

        if(!_uidBool){
          console.error("scmJS - setDetail 오류: 상위 컨테이너 데이터소스에 _uid가 없습니다.", mstDataSource);
        }
        if(!_uidParentBool){
          console.error("scmJS - setDetail 오류: 하위 컨테이너 데이터소스에 _uidParent가 없습니다.", dtlDataSource);
        }
        if(!_uidBool || !_uidParentBool){
          console.error("scmJS - 필수값 체크 메소드(validate)가 동작하지 않을 수 있습니다.");
        }
      }

      return (_uidBool && _uidParentBool);
    },
    /*********************************************************************************************
     *  @desc    넘겨받은 컨테이너의 상위에 탭이 있는지 체크하고, 해당 탭을 select
     *  @param   {Object}  container
     *  @ex      scmJS.com.tabSelect(self.formPanel);
     *  @notice  각 메뉴들은 self.tabPanel.items.getById('tabItemId').select()를 쓰는 것을 권장
     * ------------------------------------------------------------------------------------------*/
    tabSelect: function(container){
      var tabPanel = container ? container.$element.parents('.dews-ui-tab-panel') : [];
      var parentTab;
      if(tabPanel.length > 0){
        try{
          parentTab = container.$element.parents('.dews-tab-item').index();
          tabPanel.find('.dews-tab-item-title').eq(parentTab).click();
        } catch(exception){
          console.log("다음의 상위 탭을 찾을 수 없습니다.", container);
        }
      }
    },
    /*********************************************************************************************
     *  @desc   배열의 맨 앞에, 첫번째 객체와 같은 key를 갖는 빈 객체를 추가
     *  @param  {Array} array [필수]빈 객체가 추가될 배열
     *  @ex     scmJS.com.addNullObject(objCodeDtl_SD.P00570);
     * ------------------------------------------------------------------------------------------*/
    addNullObject: function(array){
      var arrayBool = Array.isArray(array);
      var obj = {};
      if(!arrayBool){
        console.error("scmJS - addNullObject 함수의 인자가 배열이 아닙니다.");
      } else if(arrayBool && array.length > 0){
        $.each(Object.keys(array[0]), function(idx, item){
          obj[item] = '';
        });
        array.unshift(obj);
      } else if(arrayBool && array.length == 0){
        console.error("scmJS - addNullObject 함수 배열 인자의 length가 0입니다.");
      }
    },
    /*********************************************************************************************
     *  @desc   값이 null인지 체크
     *  @param  {any}     value   [필수]체크할 값
     *  @param  {Boolean} zero_yn value가 0일때 false로 체크할 것인지 여부
                                  - true  => 0도 null로 체크
                                  - false => undefined, null, ''만
     *  @ex     scmJS.com.isNull('Hello');  => false
                scmJS.com.isNull(0);        => false
                scmJS.com.isNull(0, true);  => true
     * ------------------------------------------------------------------------------------------*/
    isNull: function(value, zero_yn){
      zero_yn = zero_yn ? zero_yn : false;
      if (zero_yn) { // 0을 null로 체크
        if (value === undefined || value === null || value === "" || value === 0) {
          return true;
        } else {
          return false;
        }
      } else {
        if (value === undefined || value === null || value === "") {
          return true;
        } else {
          return false;
        }
      }
    },
    /*********************************************************************************************
     *  @desc   그리드에서 해당 컬럼들의 데이터를 null로 setCellValue
     *  @param  {Object}       grid    [필수]그리드 객체
     *  @param  {String/Array} columns [필수]제거할 데이터 컬럼명('String' 또는 'String 배열')
     *  @param  {Number}       row     처리할 행 - 파라미터 없을시 그리드 또는 카드리스트에서 현재 선택된 행
     *  @ex     scmJS.com.deleteData(mstGrid, ['ITEM_CD', 'SELL_QT']);
     * ------------------------------------------------------------------------------------------*/
    deleteData: function(grid, columns, row){
      var deletable = 0;
      var chk_columns = (Array.isArray(columns) ? columns : []);
      var bad_columns = [];
      var containerType = module.com.getContainerType(grid);
      row = module.com.isNull(row) ? grid.select() : row;
      // 유효성 체크
      if(!grid || !columns){ // 파라미터 체크
        console.error("scmJS - deleteData 함수 인자가 부족합니다.");
        return false;
      } else if(!(containerType == 'Grid')){ // 그리드 체크
        console.error("scmJS - deleteData 오류: 첫번째 파라미터 타입이 그리드가 아닙니다.", grid);
      } else{
        var grid_columns = [];

        $.each(grid.dataSource.options.field, function(idx, item){
          grid_columns.push(item.field);
        });
        if(typeof columns == 'string'){
          chk_columns.push(columns);
        }
        // 그리드에 해당 컬럼이 존재하는지 유효성 체크
        $.each(chk_columns, function(idx, column){
          if(grid_columns.indexOf(column) < 0){
            deletable++;
            bad_columns.push(column);
          }
        });
        // null로 setCellValue
        if(deletable == 0){
          $.each(chk_columns, function(idx, column){
            grid.setCellValue(row, column, null, false);
          });
        } else{
          console.error("scmJS - deleteData 오류: 존재하지 않는 컬럼이 있습니다.", bad_columns);
        }
      }
    },
    /*********************************************************************************************
     *  @desc   uid를 생성하여 리턴
     *  @return {String} 리턴될 String형 uid
     *  @ex     var _uid = scmJS.com.getUid();
     * ------------------------------------------------------------------------------------------*/
    getUid: function(){
      return 'xxxxxxxx-xxxx-4xxx-9xxx-xxxxxxxxxxxx'.replace(/[xy]/g,
      function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
    /*********************************************************************************************
     *  @desc  디테일 컨테이너의 _uidParent를 이용하여 마스터 컨테이너를 select합니다.
     *         ## 선행사항: scmJS.com.setDetail
     *  @param {Object} container  그리드 또는 카드리스트 객체
     *  @param {String} _uidParent 해당 객체의 _uidParent
     *  @ex    scmJS.com.selectMstContainer(subGrid, subGrid.dataItem(subGrid.select())._uidParent);
     * ------------------------------------------------------------------------------------------*/
    selectMstContainer: function(container, _uidParent){
      var mstContainer = container.sdMaster;
      var mstRow = 0;

      // 더 상위 컨테이너가 존재하면 먼저 찾음(재귀) - 디테일의 _uidParent와 일치하는 마스터 _uid 찾음
      if(mstContainer.sdMaster){
        $.each(Object.keys(mstContainer.sdDataSource.options.lineDataSources), function(idx, item){ // 마스터의 마스터 uid들
          var stopFG = true;
          var parentItems = mstContainer.sdDataSource.options.lineDataSources[item].data();
          $.each(parentItems, function(i, parentItem){
            if(parentItem._uid == _uidParent){
              module.com.selectMstContainer(mstContainer, parentItem._uidParent);
              return false;
            }
          });
          if(!stopFG){return false;}
        });
      }

      // 마스터의 uid를 찾아 인덱스 찾음
      $.each(mstContainer.dataItems(), function(idx, item){
        if(item._uid == _uidParent){
          mstRow = idx;
          return false;
        }
      });

      mstContainer.select(mstRow);
    },
    /*********************************************************************************************
     * @desc  그리드 footer 합계(sum) currency 환종 포맷 설정
     * @param {Object} mstExchCd   [필수] 해당 메뉴의 마스터그리드 환종
     * @param {String} grid        [필수] 해당 포맷 적용할 그리드
     * @param {String} fieldArr    [필수] 해당 포맷을 적용하고 싶은 필드의 배열
                                     EX] var fieldArr = ['SELL_AMT'];
     * @ex    scmJS.com.changeSetColumn(mstExchCd, grid, fieldArr);
     * ------------------------------------------------------------------------------------------*/
    changeSetColumn: function (mstExchCd, grid, fieldArr) {
      try {
        //마스터 환종이 있을 경우에만 작동(현재 금액인 경우에만 처리)
        if(mstExchCd) {
          //변경할 컬럼 옵션 설정
          var option = {
            editor: { type: 'readonly' },
            width: 100,
            align: 'right',
            formats: { type: 'number', predefined: true, format: 'MA00005', currency: mstExchCd },
            footer: { type: 'sum', predefined: true, format: 'MA00005', currency: mstExchCd }
          }
          //해당 필드의 배열 수 만큼 컬럼 옵션 적용
          $.each(fieldArr, function (idx, item) {
            grid.setColumn(item, option);
          });
        }
      } catch (exception) {
        console.error(exception);
      }
    },
    /*********************************************************************************************
     * @desc  인자로 받은 배열을 그룹핑하여 반환
     * @param {Array}  targetArray  [필수] 그룹핑 대상 배열
     * @param {Array}  fieldArr     [필수] 그룹핑 기준 필드 배열 또는 필드 문자열
     * @param {Object} options      옵션값을 설정하여, 추가 반환값을 받습니다.
     *                              - ex] {sum: 'ITEM_AMT' }: ITEM_AMT 필드를 전체/그룹별로 합계하여 반환
     * @ex    scmJS.com.grouping(targetArray, ['SALESORGN_CD', 'DISCH_CD'], options);
     * ------------------------------------------------------------------------------------------*/
    grouping: function(targetArray, fieldArr, options){
      { // 변수 초기화
        var result = {};       // 반환 객체
        var result_arr = [];   // 그룹핑되어 반환될 배열
        var grouping_arr = []; // 그룹핑 기준이 될 배열
        var sum_field = options ? options.sum : []; // 합계 필드
        var _sum = {};

        // 그룹핑 조건이 단일로, string 형일 경우 배열로 초기화
        if(typeof fieldArr == 'string'){
          fieldArr = [fieldArr];
        }

        // 합계 필드가 단일로, string 형일 경우 배열로 초기화
        if(typeof sum_field == 'string'){
          sum_field = [sum_field];
        }

        // 합계 필드들의 값 0으로 초기화
        $.each(sum_field, function(idx, item){
          _sum[item] = 0;
        });
      }


      // -------------------------
      // 실제 그룹핑 수행
      // -------------------------
      $.each(targetArray, function(idx, item){ // 대상 배열
        var i = -1; // 그룹핑 기준 및 중복시 인덱스
        var obj = {};

        // obj 변수에 그룹핑 데이터 세팅
        $.each(fieldArr, function(fIndex, fItem){
          obj[fItem] = item[fItem];
        });

        // 그룹핑 기준에 만족하는 데이터가 이미 있는지 체크,
        $.each(grouping_arr, function(index, group){
          if(group == JSON.stringify(obj)){
            i = index;
            return false;
          }
        });

        if(i < 0){ // 기존 그룹핑 기준을 만족하는 데이터가 없다면,
          grouping_arr.push(JSON.stringify(obj)); // 중복(그룹핑)기준 추가
          obj.group_list = [item];
          if(sum_field.length > 0){ // 합계
            obj._sum = {};
            $.each(sum_field, function(sIndex, sItem){
              obj._sum[sItem] = isNaN(Number(item[sItem])) ? 0 : Number(item[sItem]); // 그룹별합계
              _sum[sItem] += isNaN(Number(item[sItem])) ? 0 : Number(item[sItem]); // 전체합계
            });
          }
          result_arr.push(obj);
        } else{ // 그룹핑 기준에 이미 데이터가 있을시,
          result_arr[i].group_list.push(item);
          $.each(sum_field, function(sIndex, sItem){ // 합계
            result_arr[i]._sum[sItem] += (isNaN(Number(item[sItem])) ? 0 : Number(item[sItem])); // 그룹별 합계
            _sum[sItem] += isNaN(Number(item[sItem])) ? 0 : Number(item[sItem]); // 전체합계
          });
        }
      });

      // 반환할 데이터(그룹핑된 배열)
      result = {
        list: result_arr
      };

      // 합계(sum) 옵션 존재시, 반환할 데이터에 전체의 합계변수 추가하여 반환
      if(sum_field.length > 0){
        result._sum = _sum;
      }

      return result;
    },
    /*********************************************************************************************
     * @desc   패널(폼/컨디션) 내 id를 key로 갖는 Json 데이터를 반환
     * @param  {String} panel [필수] 대상 panel(폼/컨디션)
     * @return {Object} Json형태의 Object {SALEORGN_CD: '1000', DISCH_CD: '00'}...
     * @ex    scmJS.com.panelToJson(self.slsecm00100_condition1);
     * ------------------------------------------------------------------------------------------*/
    panelToJson: function(panel){
      var self = dews.ui.page;

      if(!panel){
        console.error("scmJS - panelToJson 함수 인자가 부족합니다.");
        return null;
      }

      var containerType = module.com.getContainerType(panel);
      if(!(containerType == 'ConditionPanel' || containerType == 'FormPanel')){
        console.error("scmJS - panelToJson: 인자가 condition 또는 form 패널이 아닙니다: ", panel);
      } else{
        var self = self;
        var panel = panel.$element || panel; // dews데이터객체 or dom객체
        var obj = {}; // 반환할 데이터

        $.each(panel.find('*[class^=dews-ui-]'), function(idx, node){
          if($(node).hasClass('dews-ui-multilingual')){ // 제외(dews에서 자동생성되는 클래스)
            return true;
          } else if($(node).hasClass('dews-ui-textbox')){
            obj[node.id] = self[node.id].text();
          } else if($(node).hasClass('dews-ui-numerictextbox')){
            obj[node.id] = self[node.id].value();
          } else if($(node).hasClass('dews-ui-dropdownlist')){
            obj[node.id] = self[node.id].value();
          } else if($(node).hasClass('dews-ui-datepicker')){
            obj[node.id] = self[node.id].value();
          } else if($(node).hasClass('dews-ui-codepicker')){
            obj[node.id] = self[node.id].code();
          } else if($(node).hasClass('dews-ui-multicodepicker')){
            obj[node.id] = self[node.id].codes().join('|');
          } else if($(node).hasClass('dews-ui-periodpicker')){
            obj[node.id+"_FROM"] = self[node.id].getStartDate();
            obj[node.id+"_TO"] = self[node.id].getEndDate();
          } else if($(node).hasClass('dews-ui-zipcodepicker')){
            obj[node.id] = self[node.id].value();
          }
        });
        return obj;
      }
    },
    /*********************************************************************************************
     * @desc   상위 그리드에 물린 하위 그리드에 data가 있는지 체크
     *         하위 데이터가 없는 상위 그리드의 행으로 이동 - 상위 그리드 데이터소스의 컬럼에 '_uid'가 필요
     *         # mstGrid가 최상위 그리드인 경우만 사용 가능
     * @notice 메시지 처리는 반환받는 row 값으로 각자 처리
     *         setDetail 관계의 lineDataSource를 이용하기 때문에,
     *         아직 load되지 않은 하위 데이터에 대해서는 체크하지 않음(lineDataSource의 객체에 _uid가 들어가지 않음)
     * @param  {Object}  mstGrid           [필수] 상위그리드 객체
     * @param  {Object}  dtlGridDataSource [필수] 하위그리드 데이터소스 객체
     * @return {Number}  하위 데이터가 없는 상위 그리드의 index를 반환하며, 하위 데이터가 있는 경우 -1을 반환
     * @ex     scmJS.com.dtlExistCheck(mstGrid, dtlGridDataSource);
     * ------------------------------------------------------------------------------------------*/
    dtlExistCheck: function(mstGrid, dtlGridDataSource){
      /* row: 반환값
         1. 하위 데이터가 없는 상위 데이터가 있는 경우: 해당 행의 row 반환
         2. 하위 데이터가 없는 상위 데이터가 없는 경우: -1 반환
         3. 메소드를 수행할 수 없는 경우: undefined 반환 */
      var row = -1;
      if(!mstGrid || !dtlGridDataSource){ // 함수 필수인자 체크
        row = undefined;
        console.error("scmJS - dtlExistCheck: 함수 인자가 부족합니다.");
      } else if(JSON.stringify(mstGrid.dataSource.options.field).indexOf("_uid") < 0){ // 상위 그리드의 데이터소스에 _uid필드 존재 체크
        row = undefined;
        console.error("scmJS - dtlExistCheck: 상위 그리드(첫번째인자)에 '_uid' 컬럼이 없습니다.");
      } else{
        $.each(Object.keys(dtlGridDataSource.options.lineDataSources), function(idx, item){ // 마스터 데이터 수 만큼 반복
          if(dtlGridDataSource.options.lineDataSources[item].data().length == 0){ // 마스터의 하위 데이터가 없다면,
            row = mstGrid.searchCell({ // 해당 행으로 이동 및 반환값 세팅
              fields: '_uid',
              value: item,
              startIndex: 0
            });
            return false;
          }
        });
      }
      return row;
    },
    /*********************************************************************************************
     * @desc   단그리드 커스텀도움창 이벤트 처리
     * @param  {Object} options 옵션 객체 -
     * @notice #도움창 소스에서 그리드 변수 설정 이후에 메소드 사용할 것
     *         #단그리드에서만 사용할 것
     * @ex     scmJS.com.setCodeHelpEvent();
     * ------------------------------------------------------------------------------------------*/
    setCodeHelpEvent: function(options){
      // 변수세팅
      {
        var dialog  = dews.ui.dialogPage; // 도움창 페이지 변수(self)
        var $dialog = dialog.$content; // 도움창 DOM 객체
        var grid = dialog[$dialog.find('.dews-ui-grid').attr('id')]; // Grid 객체
        var gridDataSource = grid ? grid.dataSource : undefined; // 그리드 데이터소스

        var $condition = $dialog.find('.dews-ui-condition-panel').attr('id'); // 컨디션 패널 DOM 객체
        var condition = dialog[$condition]; // 컨디션 패널 객체
        // var $container_panel = $dialog.find('.dews-container-panel'); // 컨테이너 객체
        // var initData = dialog.getInitData() ? dialog.getInitData() : {}; // 다이얼로그 파라미터

        // var codePicker = (!initData.mode || initData.mode === "single") ? true : false; // 도움창이 코드피커인지/멀티코드피커인지 체크

        // grid의 checkable 옵션은 false가 아니면 모두 true로 적용되는듯(grid.options.checkable이 number형이어도 true로 인식)
        var codePicker = typeof grid.options.checkable == 'boolean' ? !grid.options.checkable : false;

        // '검색어' 조회조건 객체 - id가 s_keyword/keyword/s_search/search/s_filter/filter인 경우 검색어 파라미터 세팅 위함
        // var keyword = dialog.s_keyword || dialog.keyword || dialog.s_search || dialog.search || dialog.s_filter || dialog.filter;
        // var keyword_param = initData.params ? (initData.params.keyword ? initData.params.keyword : '') : ''; // 검색어 파라미터

        /* 도움창이 아닌, 다이얼로그로 띄울때의 경우에 따른 처리
          var dialog = dews.ui.dialog("H_SD_MA_ITEM_SET_C2",
          {
            url: "/codehelp/SD/H_SD_MA_ITEM_SET_C2",
            helpCustom: true,
            ...
          }
          # 위 예시에서 helpCustom이 없거나 false인 경우, 도움창에 있는 버튼이 적용됨
          # true인 경우, 기본적으로 생성되는 버튼이 적용됨
        */
        var dialog_btn_flag = !dews.ui.dialogPage.buttons.ok.hasClass('dews-control-activate');
        // var dialog_btn_group = $dialog.find('.dews-dialog-contents').find('.dews-ui-button');
        var dialog_btn_group = $dialog.find('.dews-dialog-contents').find('.dews-ui-button').length == 0 ?
          $dialog.find('.dews-dialog-button-group').find('.dews-ui-button') : $dialog.find('.dews-dialog-contents').find('.dews-ui-button');
      }

      /* 옵션값 파라미터 예시
        {
          loading: false,
          title: '품목 조회',
          autoSearch: false,
          size: 'large', // 사이즈는 string-표준사이즈 또는
          size: {        // width, height를 직접 주는 방식
            width: 1100,
            height: 700
          }
        }
      */

      { // 옵션값 정의
        // var autoSearch = options && !module.com.isNull(options.autoSearch) ? options.autoSearch : false; // 도움창 오픈시 자동조회 여부 (기본값: false)
        // var loading    = options && !module.com.isNull(options.loading)    ? options.loading    : false; // loading 옵션 여부  (기본값: false)
        // var fit_bottom = options && !module.com.isNull(options.fit_bottom) ? options.fit_bottom : false; // 그리드 컨테이너 패널 fit-bottom 처리 (기본값: false)
        var title      = options && !module.com.isNull(options.title)      ? options.title      : '';   // 도움창 타이틀
        var size       = options && !module.com.isNull(options.size)       ? options.size       : undefined; // 커스텀 도움창 사이즈 조정 옵션
        // var error      = options && !module.com.isNull(options.error)      ? options.error      : undefined; // 그리드 데이터소스 read 오류창 설정
        // keyword        = options && !module.com.isNull(options.keyword)    ? keyword            : undefined; // '검색어' text 자동세팅 사용여부
      }

      // 도움창 내에서 그리드를 찾을 수 없을 때 (그리드가 'dews-ui-grid' 클래스를 갖고있지 않을 수 있음)
      if(!grid){
        console.error("scmJS - setCodeHelpEvent: 도움창 내에서 그리드를 찾을 수 없습니다. - 그리드 id확인");
        return false;
      }

      // 도움창 사이즈 조정
      if(size){
        switch(typeof size){
          case 'object':{
            if(typeof size.width == 'number' && size.width > 0 && typeof size.height == 'number' && size.height > 0){
              dialog.resize(size.width, size.height);
            } else{
              console.error("scmJS - setCodeHelpEvent: 옵션(size) 변수가 잘못되었습니다 - ", size);
            }
            break;
          }
          case 'string':
          case 'number':{
            module.com.setCodeHelpSize(size);
            break;
          }
          default:{
            console.error("scmJS - setCodeHelpEvent: 옵션(size) 변수가 잘못되었습니다 - ", size);
            break;
          }
        }
      }

      // 그리드 컨테이너패널에 'fit-bottom' 처리 및 window-resize 이벤트 강제호출(해당 이벤트에 fit-bottom처리 되는 기능이 있음)
      // if($container_panel && fit_bottom){
      //   $container_panel.data('dews-fit-bottom', true);
      //   $(window).trigger('resize');
      // }

      // 그리드 옵션 처리
      // grid.setOptions({
      //   checkable: !codePicker,
      //   selectable: true,
      //   noData: true,
      //   noDataMessage: dews.localize.get('검색 결과가 없습니다.', 'M0000203')
      // });

      // 하단 '적용' 버튼 클릭 이벤트 - 선택 또는 체크된 데이터들 리턴
      dialog.buttons.ok.on('click', set_ok_enter);

      // 하단 '닫기' 버튼 이벤트
      dialog.buttons.cancel.on('click', function(e){ dialog.close(); });

      // 그리드 '엔터' 이벤트 - 선택 또는 체크된 데이터들 리턴
      grid.on('keyDown', function(e){
        if(e.keyCode == '13'){ set_ok_enter(); }
      });

      // 그리드 '더블클릭' 이벤트 - 더블클릭된 데이터 리턴
      grid.on('dblClicked', function(e){
        var row = grid.select();
        var selectedItem = grid.dataItem(row);

        if(codePicker) { // 코드피커일 때
          dialog.ok(selectedItem);
        } else { // 멀티코드피커일 때
          dialog.ok(selectedItem ? [selectedItem] : []);
        }
      });

      /* 컨디션 패널 존재할 경우, 조회조건 값 변경 이벤트 설정 - 자동 조회
        다만, 다이얼로그로 띄웠을때 자동생성된 버튼이 아닐때 '조회' 버튼이 있다면 이벤트 적용되지 않음 */
      // if($condition && (!dialog_btn_flag || (dialog_btn_flag && dialog_btn_group.length <= 2))){
      //   condition.on('change', function(){
      //     search();
      //   });
      // }

      // 검색어 textBox가 존재시 검색어 파라미터 자동 세팅
      // if(keyword && keyword.element.hasClass('dews-ui-textbox')){
      //   keyword.text(keyword_param || "");
      // }

      // 그리드 조회 완료시 이벤트 - loading.hide()
      // if(loading){
      grid.on('dataBound', function(e){
        dews.ui.loading.hide();
      });
      // }

      // 데이터소스 read시 error 처리 - #콜백변수 data, message에 대한 검증 필요함
      // if(error){
      // gridDataSource.options.error = function (data, message) {
      //   dews.ui.loading.hide();
      // };
      // }

      // 도움창 타이틀
      if(title){
        dialog.title(title || dialog.dialog.options.title || "");
      }

      // 자동조회 기능
      // if(autoSearch){
      //   search();
      // }

      /* 다이얼로그로 창을 띄워 도움창 내 소스의 버튼을 사용할 경우, 버튼에 이벤트 추가
        버튼의 순서는 '조회/적용/닫기' 순으로 들어가며 버튼이 1~3개일 경우에만 이벤트 적용 */
      if(dialog_btn_flag){
        switch(dialog_btn_group.length){
          case 1:{ // '닫기'일 경우로 가정
            // '닫기' 이벤트
            var cancel_id = dialog_btn_group.eq(0).attr('id');
            dialog[cancel_id].on('click', function(){
              dialog.close();
            });
            break;
          }
          case 2:{ // '적용', '닫기'일 경우로 가정
            // '적용' 이벤트
            var ok_id = dialog_btn_group.eq(0).attr('id');
            dialog[ok_id].on('click', function(){
              set_ok_enter();
            });
            // '닫기' 이벤트
            var cancel_id = dialog_btn_group.eq(1).attr('id');
            dialog[cancel_id].on('click', function(){
              dialog.close();
            });
            break;
          }
          case 3:{ // '조회', '적용', '닫기'일 경우로 가정
            // '조회' 이벤트
            var search_id = dialog_btn_group.eq(0).attr('id');
            dialog[search_id].on('click', function(){
              search();
            });
            // '적용' 이벤트
            var ok_id = dialog_btn_group.eq(1).attr('id');
            dialog[ok_id].on('click', function(){
              set_ok_enter();
            });
            // '닫기' 이벤트
            var cancel_id = dialog_btn_group.eq(2).attr('id');
            dialog[cancel_id].on('click', function(){
              dialog.close();
            });
            break;
          }
          default:{
            console.error("scmJS - setCodeHelpEvent: 버튼 개수가 범위내(1~3개)에 없어 이벤트 설정에 실패했습니다.");
            break;
          }
        }
      }

      // '적용'버튼/그리드 엔터키 버튼 이벤트 함수
      function set_ok_enter(){
        var row = grid.select();
        var selectedItem = grid.dataItem(row);
        var checkedItems = grid.getCheckedRows();

        if(codePicker){ // 코드피커일 때
          if(grid.dataItems().length > 0){ // 그리드에 조회된 데이터가 있을때,
            dialog.ok(selectedItem); // 리턴
          } else{ // 그리드에 조회된 데이터가 없을때,
            dialog.close(); // 닫기
          }
        } else{ // 멀티코드피커일 때,
          if(grid.dataItems().length > 0){ // 그리드에 조회된 데이터가 있을때,
            if (checkedItems.length > 0) { // 체크된 데이터가 있다면, 체크된 데이터 배열 반환
              dialog.ok(checkedItems);
            } else { // 체크된 데이터가 없다면, 선택된 데이터 단 건 배열 반환
              dialog.ok([selectedItem]); // 리턴
            }
          } else{ // 그리드에 조회된 데이터가 없을때,
            dialog.close(); // 다이얼로그 닫기
          }
        }
      }

      // 조회함수
      function search(){
        if($condition ? condition.validate() : true){ // 컨디션 패널 존재시 필수값 체크

          // if(loading){
          //   dews.ui.loading.show({
          //     type: 'tiny', // 도움창 로딩바 'tiny'로 적용
          //     text: "조회중입니다."
          //   });
          // }
          gridDataSource.read();
        }
      }

      // 다이얼로그 닫힐때, 로딩바 제거
      dialog.on('closed', function(){
        dews.ui.loading.hide();
      });
    },
    /*********************************************************************************************
     * @desc   커스텀도움창 표준사이즈 조정처리
     *          - 도움창 소스에 사용하여, 도움창이 열리는 크기를 고정하기 위함
     *            표준 사이즈가 아닌 경우, 도움창 소스에 dialog.resize(width, height); 사용
     * @param  {String/Number} size [필수] small(1)/medium(2)/large(big, 3)/largebig(extra, 4)
     * @ex     scmJS.com.setCodeHelpSize('large');
     * ------------------------------------------------------------------------------------------*/
    setCodeHelpSize: function(size){
      var dialog = dews.ui.dialogPage;
      var obj = {
        width: 0,
        height: 0
      };
      if(!size){
        console.error("scmJS - setCodeHelpSize: 함수 인자가 잘못되었습니다.", size);
      } else{
        size = typeof size === 'string' ? size.toUpperCase() : size;
        switch(size){ // 도움창 표준 사이즈 처리(dews2/2.0.191222)
          // 만약, 추후 표준 사이즈가 변경될 시 width와 height 조정이 필요
          case 1:
          case 'SMALL':{
            obj.width = 360;
            obj.height = 397;
            break;
          }
          case 2:
          case 'MEDIUM':{
            obj.width = 560;
            obj.height = 537;
            break;
          }
          case 3:
          case 'LARGE':
          case 'BIG':{
            obj.width = 746;
            obj.height = 537;
            break;
          }
          case 4:
          case 'EXTRA':
          case 'LARGEBIG':{
            obj.width = 818;
            obj.height = 630;
            break;
          }
          default:{
            if(typeof size === 'object'){
              obj.width  = size.width;
              obj.height = size.height;
            } else{
              console.error("scmJS - setCodeHelpSize: 함수 인자가 잘못되었습니다. size: ", size);
            }
            break;
          }
        }
        if(obj.width > 0 && obj.height > 0){
          dialog.resize(obj.width, obj.height);
        }
      }
    },
    /*********************************************************************************************
     * @desc   날짜 계산(+, -) 함수
     * @param  {Date/String} date   [필수] 날짜
     * @param  {number}      number [필수] 날짜에 계산될 일자
     * @return {String}      계산된 날짜 반환 ex] - "20200120"
     * @ex     scmJS.com.dateCalculate(new Date(), 7); // 현재날짜(new Date)에 +7일 한 날짜 반환
     * ------------------------------------------------------------------------------------------*/
    dateCalculate: function(date, number){
      if(!date || isNaN(Number(number)) || module.com.isNull(number)){
        console.error("scmJS - dateCalculate: 함수 인자가 잘못되었습니다 -", date, ", ", number);
        return '';
      } else{
        if(typeof date === 'object' && date instanceof Date){ // date의 타입이 Date
          date = dews.date.format(date, 'yyyyMMdd');
        } else if(typeof date === 'string' && date.length === 8){ // date 타입이 string("20200113")
        } else{
          console.error("scmJS - dateCalculate: 함수 인자(date)가 잘못되었습니다.", date);
          return '';
        }
        var return_date = new Date(date.substr(0, 4) + '-' + date.substr(4,2) + '-' + date.substr(6,2));
        return_date.setDate(dews.date.parse(date, 'yyyyMMdd').getDate()+number);
        return_date = dews.date.format(return_date, 'yyyyMMdd');
      }
      return return_date;
    },
    /*********************************************************************************************
     * @desc   마스터-디테일 관계의 그리드에서 체크박스 이벤트 적용
     *         - (디테일 데이터의 체크박스를 계속 유지하기 위함)
     * @notice ! 체크된 디테일데이터들은 dirtyData로 잡히므로 유의할 것
     *         ! mstGrid는 최상위 그리드일 것
     *         ! dtlGrid의 데이터소스 async옵션이 false일 것
     *         ! mstGrid, dtlGrid의 checkable옵션값이 true일 것
     * @param  {Object} mstGrid [필수] 마스터그리드 객체
     * @param  {Object} dtlGrid [필수] 디테일그리드 객체
     * @ex     scmJS.com.registCheckGrid(self.mstGrid, self.dtlGrid);
     * ------------------------------------------------------------------------------------------*/
    registCheckGrid: function(mstGrid, dtlGrid, gubun) {
      if(!mstGrid || !dtlGrid){
        console.error("scmJS - registCheckGrid: 함수 인자가 잘못되었습니다.");
      } else if(dtlGrid.dataSource.options.async != false){
        console.error("scmJS - registCheckGrid: 디테일그리드 데이터소스의 async 옵션이 false여야 합니다.", dtlGrid.dataSource.options);
      } else if(!mstGrid.options.checkBar.visible || !dtlGrid.options.checkBar.visible){
        console.error("scmJS - registCheckGrid: 마스터그리드 또는 디테일그리드의 checkable 옵션이 true가 아닙니다.");
      } else{
        // 디테일 그리드와 데이터소스에 체크값 가지고있을 field 추가
        {
          dtlGrid.options.dataSource.options.schema.model.fields.push({field: "DTL_CHK", fieldName: "DTL_CHK", dataType: "text"});
          dtlGrid.options.columns.push({
            field: "DTL_CHK", title: "체크여부", width: 50, align: "center",
            editor: {type: "check", trueValue: "true", falseValue: undefined, editable: true, textAlignment: "center"},
            visible: false,
            fieldName: "DTL_CHK",
            editable: false,
            name: "DTL_CHK"
          });
        }

        // 마스터그리드 체크박스 체크 이벤트
        // - 디테일 그리드의 숨겨진 값(DTL_CHK) 변경
        mstGrid.on("selected", function(e){
          var isClicked = e.cell.isClicked;
          var row = e.row.index;
          if(e.cell.header.isClicked){ // 마스터그리드 헤더 체크박스 클릭시,
            $.each(mstGrid.dataItems(), function (mIdx, mItem) {
              mstGrid.select(mIdx);
              $.each(dtlGrid.dataItems(), function (dIdx, dItem) {
                dtlGrid.setCellValue(dIdx, "DTL_CHK", isClicked ? isClicked : undefined, false);
                if(dtlGrid.dataItems().length-1 == dIdx){
                  dtlGrid.setCheck(dIdx, isClicked);
                }
              });
              mstGrid.setCheck(mIdx, isClicked);
              dtlGrid.setHeaderCheck(isClicked);
            });
            e.grid.select(row);
          } else { // 마스터그리드 체크박스 단 건 클릭시,
            var row = typeof(e.row.index) === 'object' ? e.row.index[0] : e.row.index;
            e.grid.select(row);
            e.grid.setCheck(row, isClicked);

            if(isClicked){ // 체크시,
              if(e.grid.dataItems().length == e.grid.getCheckedRows().length){
                e.grid._grid.setAllCheck(true);
              } else{
                e.grid._grid.setAllCheck(false);
              }
            } else{ // 체크 해제시,
              e.grid._grid.setAllCheck(false);
            }

            dtlGrid.setHeaderCheck(isClicked);
            $.each(dtlGrid.sortDataItems(), function (dIdx, dItem) {
              dtlGrid.setCellValue(dIdx, "DTL_CHK", isClicked ? isClicked : undefined, false);
            });
          }
        });

        // 마스터그리드 행 변경 이벤트 - 디테일 그리드의 체크박스 다시 체크
        mstGrid.on("change", function(e){
          if(e.row.isChange){
            var dtlRows;
            var count = 0;
            var sortedData = dtlGrid.sortDataItems();
            if(mstGrid.dataSource.options.detailDataSource.options.lineDataSources[mstGrid.dataItems(mstGrid.select())._uid]){
              dtlRows = mstGrid.dataSource.options.detailDataSource.options.lineDataSources[mstGrid.dataItems(mstGrid.select())._uid].options.data;
              $.each(dtlRows, function (idx, item) {
                if(item.DTL_CHK == "true"){count++;}
              });

              if(dtlRows.length && (count === dtlRows.length)){dtlGrid.setHeaderCheck(true);}
              // else{dtlGrid.setHeaderCheck(false);} //change 됐을 시, 마스터 체크 해제되는 문제로 인하여 주석 처리 함

              $.each(sortedData, function (idx, item) {
                var checkFlag = false;
                for(var dtlIdx = 0; dtlIdx < dtlRows.length; dtlIdx++){
                  if (item.__UUID == dtlRows[dtlIdx].__UUID && item.DTL_CHK == "true") {
                    dtlGrid.setCheck(idx, true);
                    checkFlag = true;
                    break;
                  }
                }
                if(!checkFlag) {
                  dtlGrid.setCheck(idx, false);
                }
              });
            }
          }
        });

        // 디테일그리드 체크박스 체크 이벤트
        // - 디테일 그리드의 숨겨진 값(DTL_CHK) 변경 및 헤더, 마스터의 체크값 변경
        dtlGrid.on("selected", function(e){
          var isClicked = e.cell.isClicked;

          if (e.cell.header.isClicked) { // 디테일그리드 헤더 체크박스 체크시,
            $.each(e.grid.sortDataItems(), function (idx, item) {
              e.grid.setCheck(idx, isClicked);
              e.grid.setCellValue(idx, "DTL_CHK", isClicked ? isClicked : undefined, false);
            });
            mstGrid.setCheck(mstGrid.select(), isClicked);
          } else { // 디테일그리드 체크박스 단 건 클릭시,
            e.grid.setCheck(e.row.index, isClicked);
            e.grid.setCellValue(e.row.index, "DTL_CHK", isClicked ? isClicked : undefined, false);

            if(e.grid.getCheckedRows().length > 0){
              var dtlRows = e.grid.sortDataItems();
              var dtlSelected = e.grid.dataItem(e.row.index);
              e.grid.setHeaderCheck(false);
              $.each(dtlRows, function (dIdx, dItem) {
                e.grid.setCellValue(dIdx, "DTL_CHK", dItem.DTL_CHK ? dItem.DTL_CHK : undefined, false);
                e.grid.setCheck(dIdx, Boolean(dItem.DTL_CHK));

                //SET품 혹은 EC품일 때, 디테일 그리드 모품목 선택 시 자품목도 선택되도록 하기 위한 체크 부분 추가(수주, 납품 모두 SET_ITEM_SQ, SET_ITEM_SUB_SQ가 들어가는 부분이 통일하기 어려워 gubun값 추가)
                if(gubun == "DV") {
                  //SET품 혹은 EC품일 때, 디테일 그리드 모품목 선택 시 자품목도 선택되도록 하기 위한 체크
                  //일단은 SET_ITEM_FG_CD, SET_ITEM_CD, SET_ITEM_SQ로 구분, 추후 변경될 수 있음
                  if(dtlSelected.SET_ITEM_FG_CD != undefined || dtlSelected.SET_ITEM_FG_CD != null) {
                    if(dtlSelected.SET_ITEM_FG_CD == "1") {//SET품
                      if(dItem.SET_ITEM_FG_CD == "2" && dItem.SET_ITEM_CD == dtlSelected.SET_ITEM_CD && dItem.SET_ITEM_SUB_SQ == dtlSelected.SET_ITEM_SUB_SQ) {
                        e.grid.setCellValue(dIdx, "DTL_CHK", dtlSelected.DTL_CHK);
                        e.grid.setCheck(dIdx, Boolean(dtlSelected.DTL_CHK));
                      }
                    } else if (dtlSelected.SET_ITEM_FG_CD == "6") {//EC품
                      if(dItem.SET_ITEM_FG_CD == "7" && dItem.SET_ITEM_CD == dtlSelected.SET_ITEM_CD && dItem.SET_ITEM_SUB_SQ == dtlSelected.SET_ITEM_SUB_SQ) {
                        e.grid.setCellValue(dIdx, "DTL_CHK", dtlSelected.DTL_CHK);
                        e.grid.setCheck(dIdx, Boolean(dtlSelected.DTL_CHK));
                      }
                    }
                  }
                }

              });
              mstGrid.setCheck(mstGrid.select(), true);
            }

            if(e.grid.getCheckedRows().length == e.grid.dataItems().length){
              e.grid.setHeaderCheck(true);
              mstGrid.setCheck(mstGrid.select(), true);
            }else if(e.grid.getCheckedRows().length == 0){
              e.grid.setHeaderCheck(false);
              mstGrid.setCheck(mstGrid.select(), false);
              mstGrid._grid.setAllCheck(false);
            }

            // 마스터 헤더 체크박스 핸들링
            if(mstGrid.getCheckedRows().length == 0){
              mstGrid._grid.setAllCheck(false);
            } else if(mstGrid.getCheckedRows().length == mstGrid.dataItems().length){
              mstGrid._grid.setAllCheck(true);
            }
          }
        });
      }
    },
    // registCheckGrid2: function(mstGrid, dtlGrid){
    //   var self = dews.ui.page;
    //   self._checkBox = {}; // 체크박스 담고있을 값 세팅

    //   // 그리드 데이터 읽을시 변수 초기화
    //   mstGrid.on('dataBound', function(e){
    //     self._checkBox = {};
    //   });

    //   // 마스터그리드 체크박스 체크시,
    //   mstGrid.on('selected', function(e){
    //     var clicked_value = e.cell.isClicked; // 현재 누른 체크박스의 체크값

    //     if(e.cell.header.isClicked){ // 헤더 클릭시,
    //       if(clicked_value){ // 헤더 체크
    //         $.each(Object.keys(self._checkBox), function(mIdx, mItem){
    //           if(self._checkBox[mItem]){
    //             $.each(Object.keys(self._checkBox[mItem].detail), function(dIdx, dItem){
    //               self._checkBox[mItem][dItem] = clicked_value;
    //             });
    //           }
    //         });
    //       } else{ // 헤더 체크 해제
    //         self._checkBox = {};
    //       }
    //     } else{
    //       var row = e.row.index;
    //       var _uid = e.row.data._uid;

    //       // 마스터 내부 디테일의 값 변경
    //       if(self._checkBox[_uid]){
    //         $.each(Object.keys(self._checkBox[_uid].detail), function(dIdx, dItem){
    //           // self._checkBox[_uid].detail[dItem] = clicked_value;
    //           self.dtlGrid._grid.checkItem(dIdx);
    //         });
    //       } else{

    //       }
    //     }
    //   });

    //   // 마스터그리드 행 클릭시
    //   mstGrid.on('change', function(e){
    //     if(mstGrid.dataItems().length > 0 && e.row.isChange){
    //       var dtl_list = dtlGrid.dataItems();
    //       var row = e.row.index;
    //       var _uid = mstGrid.dataItem(row)._uid;
    //       var checked = mstGrid.isCheckedRow(row);

    //       if(!self._checkBox[_uid]){ // 처음 읽을때
    //         self._checkBox[_uid] = module.com.isNull(self._checkBox[_uid]) ? {} : self._checkBox[_uid];
    //         self._checkBox[_uid].detail = {};
    //         $.each(dtl_list, function(idx, item){
    //           self._checkBox[_uid].detail[dtlGrid.dataItem(idx).__UUID] = checked;
    //           dtlGrid._grid.checkItem(idx, checked);
    //         });
    //       } else{ // 이후 읽을때
    //         $.each(Object.keys(self._checkBox[_uid].detail), function(idx, item){ // 변수에서 체크값을 읽어
    //           var dtlRow = dtlGrid.searchCell({
    //             fields: '__UUID',
    //             value: item,
    //             select: false
    //           });

    //           dtlGrid._grid.checkItem(dtlRow, self._checkBox[_uid].detail[item]); // 디테일에 체크해줌
    //         });

    //         // 디테일에 모두 체크됐다면,
    //         if(dtlGrid.dataItems().length > 0 && dtlGrid.dataItems().length == dtlGrid.getCheckedIndex().length){
    //           dtlGrid._grid.setAllCheck(true); // 디테일 헤더 체크
    //         } else{ // 모두 체크되지 않았다면,
    //           dtlGrid._grid.setAllCheck(false); // 디테일 체크 해제
    //         }
    //       }
    //     }
    //   });

    //   // 디테일그리드 체크박스 체크시
    //   dtlGrid.on('selected', function(e){
    //     var dtl_list = dtlGrid.dataItems();
    //     var mstRow = mstGrid.select();
    //     var mst_uid = mstGrid.dataItem(mstRow)._uid;
    //     var clicked_value = e.cell.isClicked; // 현재 누른 체크박스의 체크값

    //     if(e.cell.header.isClicked){ // 헤더 클릭시,
    //       // self._checkBox[mst_uid].header = clicked_value;
    //       mstGrid._grid.checkItem(mstRow, clicked_value); // 마스터 item도 같이 체크
    //       $.each(Object.keys(self._checkBox[mst_uid].detail), function(idx, item){
    //         item = clicked_value;
    //       });
    //     } else{ // 단 건 클릭시,
    //       var row = e.row.index; // 현재 클릭한 행
    //       var dtl_uid = dtlGrid.dataItem(row).__UUID; // 디테일 _uid

    //       if(dtlGrid.getCheckedIndex().length == 0){ // 더이상 체크된 행이 없을때,
    //         dtlGrid._grid.setAllCheck(false); // 디테일그리드 헤더체크 false 처리
    //         mstGrid._grid.checkItem(mstRow, false); // 마스터 item도 같이 체크
    //         // self._checkBox[mst_uid].header = false;
    //       } else if(dtl_list.length > 0 && dtlGrid.getCheckedIndex().length == dtl_list.length){ // 모두 체크되었을 때,
    //         dtlGrid._grid.setAllCheck(true); // 디테일그리드 헤더체크 true 처리
    //         mstGrid._grid.checkItem(mstRow, true); // 마스터 item도 같이 체크
    //         // self._checkBox[mst_uid].header = true;
    //       } else{
    //         dtlGrid._grid.setAllCheck(false); // 디테일그리드 헤더체크 false 처리
    //         mstGrid._grid.checkItem(mstRow, true); // 마스터 item도 같이 체크
    //         // self._checkBox[mst_uid].header = true;
    //       }
    //       self._checkBox[mst_uid].detail[dtl_uid] = clicked_value;
    //     }
    //   });
    // },
    /*********************************************************************************************
     * @desc   파라미터를 Number형으로 리턴 : null, undefined, object, Array 타입을 0으로 반환
     * @param  {any}     data [필수] Number형으로 변경할 파라미터
     * @return {Number}  Number 형으로 변경된 데이터
     * @ex     scmJS.com.toNumber("1234");
     * ------------------------------------------------------------------------------------------*/
    toNumber: function(data){
      return isNaN(Number(data)) ? 0 : Number(data);
    },
    /*********************************************************************************************
     * @desc   파라미터를 받아 falsy값일시 공백('') 또는 대체 파라미터로 리턴, falsy값이 아니면 그대로 리턴
     * @param  {any} data [필수] data
     * @return {any}
     * @ex     scmJS.com.replaceNull(data);
     * ------------------------------------------------------------------------------------------*/
    replaceNull: function(data, replaceData){
      return module.com.isNull(data) ? replaceData || '' : data;
    },
    /*********************************************************************************************
     * @desc   파라미터를 받아 String으로 변환시 bytes를 리턴 - 주로 Back단으로 보낼 Object, Array 데이터 등.
     * @param  {any}    param [필수] param
     * @return {Number} bytes.
     * @ex     scmJS.com.getStringBytes(param);
     * ------------------------------------------------------------------------------------------*/
    getStringBytes: function(param){
      try{
        var bytes = (function(s,b,i,c){
          for(b=i=0;c=s.charCodeAt(i++);b+=c>>11?3:c>>7?2:1);
          return b;
        })(JSON.stringify(param));
      } catch(exception){
        console.error("scmJS - getStringBytes 함수 변환실패.");
      }
      return bytes;
    },
    /*********************************************************************************************
     * @desc   파라미터를 받아 해당 flag의 정규식으로 체크하여 boolean 반환
     * @param  {Str/Num} param [필수] 체크할 데이터
     * @param  {String}  flag  [필수] param - 숫자인지, 문자열인지 등..
     * @return {Boolean} true/false
     * @ex     var bool = scmJS.com.regexpCheck('ASDFG99', 'NUMBER'); // false
     * ------------------------------------------------------------------------------------------*/
    regexpCheck: function(param, flag){
      var param_type = typeof param;
      var regExp;

      // 플래그는 STRING이며 UPPERCASE로 비교.
      if(typeof flag === 'string'){
        flag = flag.toUpperCase();
      } else{
        console.error("scmJS - regexpCheck 유효하지 않은 플래그 값");
        return false;
      }

      // 파라미터가 string/number가 아님 => false 리턴
      if(!(param_type === 'string' || param_type === 'number')){
        return false;
      }

      // number면 string으로 변환
      param = param_type === 'number' ? String(param) : param;

      switch(flag){
        case 'NUMBER' :
        case 'NUMBER1':{ // 숫자-소수까지 가능 - EX] 금액등.
          regExp = /^[-]?\d+(?:[.]\d+)?$/;
          break;
        }
        case 'NUMBER2':{ // 숫자-정수만 가능 - EX] 일부수량, 품번증가 등.
          regExp = /^[\d]+$/;
          break;
        }
        case 'NUMBER3':{ // 숫자-정수만 가능(음수 포함) - EX] 일부수량
          regExp = /^[-]?[\d]+$/;
          break;
        }
        case 'STRING' :
        case 'STRING1':{ // 문자-숫자+영대소문자 가능
          regExp = /^[\da-zA-Z]+$/;
          break;
        }
        case 'STRING2':{ // 문자-숫자+영대문자 가능 - EX] XX유형 등
          regExp = /^[\dA-Z]+$/;
          break;
        }
        case 'STRING3':{ // 문자-숫자+영소문자 가능
          regExp = /^[\da-z]+$/;
          break;
        }
        default:{ // 매칭되지 않는 케이스.
          break;
        }
      }

      if(regExp){
        return regExp.test(param);
      } else{ // 매칭되지 않는 케이스.
        console.error("scmJS - regexpCheck 유효하지 않은 플래그 값");
      }
    },
    /*********************************************************************************************
     * @desc   자식 코드피커의 'codedialog' 이벤트와 상위 데이터에 대한 이벤트 세팅
     * @param  {any}    param [필수] param
     * @ex     scmJS.com.setChildCodeEvent(param);
     * ------------------------------------------------------------------------------------------*/
    // setChildCodeEvent: function(parent, child, param, requiredFlag){
    //   var parentNode  = parent._element;
    //   var parentLabel = $(parentNode).parents('li').eq(0).children('label').text(); // 부모객체 라벨
    //   var parentType  = module.com.getControlType(parent);
    //   var parentValue;
    //   requiredFlag = requiredFlag === false ? false : true;

    //   if(module.com.getControlType(child) == 'codepicker'){
    //     // 자식 도움창 오픈 이벤트 세팅
    //     child.on('codedialog', function(e){
    //       // 부모컨트롤 값 Get(코드피커/드롭다운/텍스트박스만 처리.)
    //       switch(parentType){
    //         case 'codepicker':{
    //           parentValue = parent.code();
    //           break;
    //         }
    //         case 'dropdownlist':{
    //           parentValue = parent.value();
    //           break;
    //         }
    //         case 'textbox':{
    //           parentValue = parent.text();
    //           break;
    //         }
    //       }

    //       e.params[param] = parentValue;

    //       // 부모컨트롤 값을 선택해야 다이얼로그 오픈 가능 처리
    //       if(requiredFlag && module.com.isNull(parentValue)){
    //         dews.ui.snackbar.warning("[" + parentLabel + "]을(를) 먼저 선택하세요.");
    //         dews.ui.requiredTooltip.show($(parentNode), dews.localize.get('선행 입력사항입니다.', 'M0000419'));
    //         e.preventDefault();
    //       }
    //     });

    //     // 부모컨트롤 값 변경시, 자식 도움창 데이터 제거
    //     parent.on('change', function(e){
    //       child.clearData();
    //     });
    //   } else{
    //     // 오류!
    //   }
    // },
/*********************************************************************************************
     * @desc   그리드 현재행의 null여부확인용 함수
     * @param  {String}      self      [필수]해당 메뉴의 this(dewself/self)
     * @param  {String}      gridNm    [필수] 그리드
     * @param  {String}      colNm     [필수] 칼럼
     * @return {String}      그리드의 칼럼값
     * @ex     scmJS.com.gridValNullCheck("claimGrid","_uid")
     * ------------------------------------------------------------------------------------------*/
    gridValNullCheck: function(self, gridNm, colNm){
      if(!self || !gridNm || !colNm){
        console.error("scmJS - gridValNullCheck: 함수 인자가 잘못되었습니다 -");
        return "";
      }

      var colValue = self[gridNm].getCellValue(self[gridNm].select(),colNm);
      if(colValue == undefined || colValue == null || colValue == ""){
        return "";
      }else{
        return colValue;
      }
    },
    /*********************************************************************************************
     *  @desc   '메뉴별부가정보등록' 메뉴의 등록된 정보를 리턴
     *  @param  {Object} filtering   [선택] 필터링옵션객체 - MENU_ID, TABLE_ID 등으로 필터링
     *  @ex     var menuDynamicInfo = scmJS.com.getMenuDynamicFields({MENU_ID: 'SLSSOR00100'});
     * ------------------------------------------------------------------------------------------*/
    getMenuDynamicFields: function(filtering){
      var result = [];
      filtering = filtering || {};
      if(!filtering.hasOwnProperty('MENU_ID') && !filtering.hasOwnProperty('menu_id')
      && !filtering.hasOwnProperty('TABLE_ID') && !filtering.hasOwnProperty('table_id')){
        filtering.MENU_ID = dews.ui.page.menu.id;
      } else{
        // 메뉴별 부가정보등록에 등록된 리스트 조회.
        var result = module.api.selectDynamicFields(filtering);
      }
      return result;
    },
     /*********************************************************************************************
     *  @desc   메뉴 이동시 전용메뉴가 있다면 전용메뉴로, 없다면 패키지 메뉴로 이동하는 함수.
     *  @param  {*}  회사코드 company_cd, 메뉴그룹코드 menugrp_cd,이동할 menuid, 메뉴이동시 넘길 데이터 linkData
     *  @ex     scmJS.com.linkToMenu(dews.ui.page.user.companyCode, dews.ui.page.user.groupCode, 'PMMSDT00100', data);
     * ------------------------------------------------------------------------------------------*/
     linkToMenu: function (company_cd, menugrp_cd, menuid, linkData, drs_cd) {
      // 현재 태림포장, 태림페이퍼에만 해당 함수를 적용시키기 위함
      // 향후 함수 변경될 예정.
      if(drs_cd == '20029' || drs_cd == '20033'){
      dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_GET_LINK_TO_MENU"), {
        async: false,
        data: {
          menu_cd: menuid,
          company_cd: company_cd,
          menugrp_cd : menugrp_cd
        }
      }).done(function (data) {
        dews.ui.openMenu(data[0].MODULE_CD, data[0].MENU_CD, linkData);
      }).fail(function (xhr, status, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
      });
      }else{
        dews.ui.openMenu(dews.ui.page.menu.module, menuid, linkData);
      }
        return;
    },
    /*********************************************************************************************
     *  @desc   '메뉴별부가정보등록' 메뉴의 등록된 정보를 세팅.
     *  @param  {Object}  self      [필수] 메뉴/커스텀도움창의 this
     *  @param  {Array}   addFields [필수] 추가할 요소들
     *  @param  {Object}  addTarget [옵션] 동적필드가 추가될 대상(현황메뉴인 경우만사용하며 필수)
     *  @param  {boolean} connUseYn [옵션] 연결메뉴 사용여부(사용 : true, 미사용 : undefiend, false)
     *  @param  {boolean} onlyDataSourceYn [옵션] 데이터소스만 바인딩(사용 : true, 미사용 : undefiend, false)
     *  @return {Promise} Promise 객체를 리턴합니다. 동적 필드들이 추가된 후 이벤트가 실행되어야 하는 경우,
     *                    .then(function(){...})에 메소드를 작성합니다.
     *  @ex
     *  # 1. 메뉴별부가정보를 입력하는 메뉴인 경우 #
     *  var addFields = scmJS.com.getMenuDynamicFields({MENU_ID: 'SLSSOR00100'});
     *  scmJS.com.setMenuDynamicFields(self, addFields);
     *
     *  # 2. 입력한 메뉴별부가정보를 보여주는 현황인 경우 #
     *  var addFields = scmJS.com.getMenuDynamicFields({MENU_ID: 'SLSSOR00100'});
     *  scmJS.com.setMenuDynamicFields(self, addFields, self.mstGrid);
     * ------------------------------------------------------------------------------------------*/
    setMenuDynamicFields: function(self, addFields, addTarget, connUseYn, onlyDataSourceYn){
      return new Promise(function(resolve){
        /* 탭패널의 addTab 메소드 사용시, 메뉴의 스크립트(dews.ready)를 모두 다시 읽게 처리되어있어,
          플랫폼팀에 문의, setTimeout 사용하도록 안내받음. */
        setTimeout(function(){
          // 맨 앞에 self를 받도록 변경되어, 이전 소스들 오류나지 않도록 임시 설정.
          if(Array.isArray(self)){
            var tmp = {
              self: self,
              addFields: addFields,
              addTarget: addTarget
            };

            self = dews.ui.page;
            addFields = tmp.self;
            addTarget = tmp.addFields;
          }
          self._connUseYn = connUseYn ? connUseYn : false;
          self._addedFields = self._addedFields ? self._addedFields : [];
          self._dynamicDataItems = self._dynamicDataItems || {};
          self._dynamicFileDataItems = {};
          var gridArr = []; // 그리드 id 리스트.
          var cardArr = []; // 카드리스트 id 리스트.
          var treeArr = []; // 트리리스트 id 리스트.
          var fileArr = []; // 파일 id 리스트.
          var bindPanelArr = []; // 바인드 이벤트 추가될 패널 리스트.
          var inputMaxLength = 2000; // 저장테이블 컬럼 LENGTH.

          if(addFields && Array.isArray(addFields) && addFields.length > 0){
            // 입력메뉴인지, 현황메뉴인지 플래그값(현재메뉴===메뉴별부가정보에 입력된 메뉴)
            var insertBool = self.menu ? (addFields[0].MENU_ID === self.menu.id) : false;
            var addTargetType = addTarget ? module.com.getContainerType(addTarget) : null;
            var target;
            var targetConAddYn;

            $.each(addFields, function(index, item){ // 추가할 컨트롤 만큼, 반복.
              if(addTarget){
                switch(addTargetType){
                  case 'Grid':{
                    item.CTRL_CD = '1';
                    break;
                  }
                  case 'ConditionPanel':{
                    item.CTRL_CD = '5';
                    break;
                  }
                  case 'FormPanel':{
                    item.CTRL_CD = '6';
                    break;
                  }
                }
              }
              target = addTarget || self[item.OBJECT_CD];
              field_id = self._connUseYn ? item.FIELD_ID_RAW : item.FIELD_ID;
              targetConAddYn = self._addedFields.indexOf(field_id) === -1; // 대상에게 컨트롤 추가 가능여부
              /* CTRL_CD = 공통코드(CI)
                  1 Grid
                  2 Button
                  3 Tab
                  4 Process
                  5 Condition Panel
                  6 Form Panel
                  7 Tab Panel  */
              switch(item.CTRL_CD){ // 대상구분(위 구분과 같음.)
                case '1':{ //그리드
                  add_to_grid(item, undefined, onlyDataSourceYn);
                  break;
                } // 대상구분 그리드 END --
                case '2':
                case '3':
                case '4':{ // 버튼/탭/프로세스는 제외됨.(MA쪽 공통코드 사용으로 해당 기능에 불필요)
                  targetConAddYn = false;
                  break;
                }
                case '5':
                case '6':{ // 컨디션패널(5)/폼패널(6)
                  add_to_panel(item);
                  if(insertBool && target.sdBindContainer){ // 바인드 컨테이너 존재시, 해당 컨테이너에도 필드 추가.
                    var bindContainerType = module.com.getContainerType(target.sdBindContainer);
                    switch(bindContainerType){
                      case 'TreeGrid':{
                        // 그리드 필드 추가
                        add_to_grid(item, target.sdBindContainer.$element.parents('.dews-ui-treegrid').eq(0).attr('id'));
                        break;
                      }
                      case 'Grid':{
                        // 그리드 필드 추가
                        add_to_grid(item, target.sdBindContainer.$element.parents('.dews-ui-grid').eq(0).attr('id'));
                        break;
                      }
                      case 'CardList':{
                        add_to_card(item, $(target.sdBindContainer.$element).attr('id'));
                        break;
                      }
                      case 'TreeView':{
                        add_to_tree(item, $(target.sdBindContainer.element).attr('id'));
                        break;
                      }
                    }
                  }
                  module.com.setZeroWithSpaceRemove(self, field_id);
                  break;
                } // 대상구분 ~ 5/6 END
                case '7':{ // 탭 패널(7)
                  if(insertBool){
                    var $tabPanel = self['$'+item.OBJECT_CD] // 탭패널 찾음.
                    var tabPanelID = item.OBJECT_CD ; // 탭 패널 ID
                    var tabPanel = self[tabPanelID]; // 듀스 탭패널 객체
                    var dynamicTabID = dynamic_tab_id_prev + tabPanelID + item.OBJECT_SQ; // 동적으로 생성될 탭 ID
                    var dynamicTab = self[tabPanelID].items.getById(dynamicTabID); // 동적생성된 탭 객체(아직 생성되지 않았다면 undefined)
                    var dynamicFormID = dynamic_form_id_prev + tabPanelID + item.OBJECT_SQ; // 동적으로 생성될 폼패널 ID

                    // 동적탭+폼패널이 생성되지 않았다면 생성.
                    if(!dynamicTab){
                      // 대상 탭 뒤에 부가정보 탭 생성 => '메뉴별부가정보등록' 탭에 컬럼 추가되어 그 값을 가져올 수도 있음+다국어
                      self[tabPanelID].addTab({id: dynamicTabID, title: item.TAB_NM == undefined ? '부가정보' : item.TAB_NM}, $tabPanel.find('.dews-tab-item').length);

                      var $dynamicTab = self['$' + dynamicTabID] || self.$content.find('#' + dynamicTabID);
                      var $tab_items = $tabPanel.children('ul.dews-tab-items').children('li.dews-tab-item'); // 탭패널 내 탭 요소들

                      // 추가한 탭으로 포커스 되기 때문에 첫번째 탭으로 다시 포커스 주기 위함.
                      self[tabPanelID].items.getById($tab_items.eq(0).attr('id')).select();

                      // 폼패널 생성 및 메뉴의 self 밑에 동적 form 붙여줌.
                      var $dynamicForm = $("<div class='dews-form-panel' id=\'" + dynamicFormID + "\' data=dews-position='normal'><ul></ul></div>");
                      $dynamicTab.find('.dews-tab-content').eq(0).append($dynamicForm);
                      self[dynamicFormID] = dews.ui.formpanel(self.$content.find('#' + dynamicFormID));
                      self['$' + dynamicFormID] = $dynamicForm;

                      // 탭 패널에 동적으로 생성된 폼패널 ID를 추가.
                      if(!tabPanel._dynamicFormID){
                        tabPanel._dynamicFormID = [];
                      }
                      tabPanel._dynamicFormID.push(dynamicFormID);
                    }

                    // 탭>폼패널>내부에 동적요소들 생성.
                    add_to_panel(item, self[dynamicFormID]);

                    //탭안에 생성된 폼패널 ID
                    item.OBJECT_TAB_CD = dynamicFormID;

                    if(target.sdBindContainer){
                      //초기 탭에 연결된 컨테이너 정보 생성
                      module.com.setBind(target.sdBindContainer, self[dynamicFormID]);

                      var bindContainerType = module.com.getContainerType(target.sdBindContainer);
                      var gridId;
                      switch(bindContainerType){
                        case 'TreeGrid':{
                          // 그리드 필드 추가
                          gridId = target.sdBindContainer.$element.parents('.dews-ui-treegrid').eq(0).attr('id');
                          add_to_grid(item, target.sdBindContainer.$element.parents('.dews-ui-treegrid').eq(0).attr('id'));
                          break;
                        }
                        case 'Grid':{
                          // 그리드 필드 추가
                          gridId = target.sdBindContainer.$element.parents('.dews-ui-grid').eq(0).attr('id');
                          add_to_grid(item, target.sdBindContainer.$element.parents('.dews-ui-grid').eq(0).attr('id'));
                          break;
                        }
                        case 'CardList':{
                          gridId = $(target.sdBindContainer.$element).attr('id');
                          add_to_card(item, $(target.sdBindContainer.$element).attr('id'));
                          break;
                        }
                      }
                      if(gridId){
                        self[gridId].on('change', function(e){
                          self[gridId].bindPanel(self[dynamicFormID]);
                        });
                      }
                    }
                  } else{}
                  break;
                } // 대상구분 ~ 7 END
              } // 대상구분 END --

              if(targetConAddYn){ // 동적필드 정상추가시.
                self._hasDynamicFields = true;
                self._addedFields.push(field_id);
              }
            });

            // 컬럼이 추가된 그리드 만큼, setColumns 호출하여 그리드를 다시 그려줌.
            $.each(gridArr, function(idx, id){
              var grid = self[id];
              grid.setColumns();
              // 값 변경시 이벤트 추가.
              grid.on('save', function(e){
                if(grid.dynamicFields && grid.dynamicFields.indexOf(e.cell.field) >= 0){
                  module.com.setDynamicData(self, grid);
                }
              });
              grid.on('dblClicked', function(e){
                var fieldId = e.cell.field.replace("_TEXT", "");
                if(grid.dynamicInfo && grid.dynamicInfo[fieldId] && grid.dynamicInfo[fieldId].FIELD_ATTR_CD == '10'){
                  setFileDataList(grid, fieldId);
                }
              });
            });

            // 컬럼이 추가된 카드리스트 만큼, 'rowAdd' 이벤트 추가
            $.each(cardArr, function(idx, id){
              var card = self[id];
              card.on('rowAdd', function(e){
                $.each(card.dynamicFields, function(fIdx, fName){
                  card.setValue(e.row.index, fName, null);
                });
              });
            });

            // 컬럼이 추가된 트리리스트 만큼 바인딩
            $.each(treeArr, function(idx, id){
              var tree = self[id];
              tree.on('change', function(e){
                $.each(tree.dynamicFields, function(fIdx, fName){
                  if(self[fName]){
                    var target = self[fName].element ? $(self[fName].element) : $(self[fName]._element);
                    if (target != undefined) {
                      var dewsControl = self[fName];
                      if (
                        $(target).hasClass("dews-ui-dropdownlist") ||
                        $(target).hasClass("dews-ui-numerictextbox") ||
                        $(target).hasClass("dews-ui-maskedtextbox") ||
                        $(target).hasClass("dews-ui-datepicker") ||
                        $(target).hasClass("dews-ui-timepicker") ||
                        $(target).hasClass("dews-ui-monthpicker") ||
                        $(target).hasClass("dews-ui-datetimepicker") ||
                        $(target).hasClass("dews-ui-zipcodepicker") ||
                        $(target).hasClass("dews-ui-combobox")
                      ) {
                        dewsControl.value(tree.dataItem(tree.select())[fName]);
                      }
                      else if ($(target).hasClass("dews-ui-textbox")) {
                        dewsControl.text(tree.dataItem(tree.select())[fName]);
                      }
                      else if ($(target).hasClass("dews-ui-codepicker")) {
                        var obj = {};
                        if(tree.dynamicInfo[fName].HWND_FG == '2'){
                          obj['SYSDEF_CD'] = tree.dataItem(tree.select())[fName];
                          obj['SYSDEF_NM'] = tree.dataItem(tree.select())[fName + "_NM"];
                        }else if(tree.dynamicInfo[fName].HWND_FG == '3'){
                          obj[fName] = tree.dataItem(tree.select())[fName];
                          obj[fName + "_NM"] = tree.dataItem(tree.select())[fName + "_NM"];
                        }
                        dewsControl.setData(obj, false);
                      }
                    }
                  }
                  else{
                    if(tree.dynamicInfo[fName] && tree.dynamicInfo[fName].FIELD_ATTR_CD == '10'){
                      var dewsControl = self[fName + "_TEXT"];
                      dewsControl.text(tree.dataItem(tree.select())[fName + "_TEXT"]);
                    }
                  }
                });
              });
            });

            // 바인드 관계의 폼/컨디션 값이 변경되었을 때, 바인드 대상(그리드/카드리스트)에 물린 패널들 모두 조회하여 값 바인드.
            $.each(bindPanelArr, function(idx, id){
              var panel = self[id];
              if(panel.sdBindContainer){ // 바인드 된 대상이 있을 경우에만.
                // 코드피커 외 요소의 이벤트.
                self['$'+id].on('change', function(e){
                  var row = panel.sdBindContainer.select();
                  if(( typeof row === 'object' || row >= 0) && panel.dynamicFields.indexOf(e.target.id) >= 0){
                    panel.bindTo(panel.sdBindContainer);
                    var uid_column = module.com.getDynamicUIDColumn(panel.sdBindContainer.dataItem(row));
                    self._dynamicDataItems[panel.sdBindContainer.dataItem(row)[uid_column]]
                      = module.com.mergeDynamicForPanel(panel.sdBindContainer.sdBindContainer, {})[dynamic_object_name];
                    for(var i=0; i<self._dynamicDataItems[panel.sdBindContainer.dataItem(row)[uid_column]].length; i++){
                      self._dynamicDataItems[panel.sdBindContainer.dataItem(row)[uid_column]][i].RECORD_KEY_VR = panel.sdBindContainer.dataItem(row).RECORD_KEY_VR;
                    }
                    if(typeof row === 'object'){
                      if(!panel.sdBindContainer.dataItem(panel.sdBindContainer.select()).rowState
                         || panel.sdBindContainer.dataItem(panel.sdBindContainer.select()).rowState != 'added'){
                          panel.sdBindContainer.dataItem(panel.sdBindContainer.select()).rowState = 'updated';
                      }
                    }
                  }
                });
                // 코드피커 이벤트.
                panel.on('change', function(e){
                  var row = panel.sdBindContainer.select();
                  if(( typeof row === 'object' || row >= 0) && panel.dynamicFields.indexOf(e.target.id) >= 0){
                    panel.bindTo(panel.sdBindContainer);
                    var uid_column = module.com.getDynamicUIDColumn(panel.sdBindContainer.dataItem(row));
                    self._dynamicDataItems[panel.sdBindContainer.dataItem(row)[uid_column]]
                      = module.com.mergeDynamicForPanel(panel.sdBindContainer.sdBindContainer, {})[dynamic_object_name];
                    for(var i=0; i<self._dynamicDataItems[panel.sdBindContainer.dataItem(row)[uid_column]].length; i++){
                      self._dynamicDataItems[panel.sdBindContainer.dataItem(row)[uid_column]][i].RECORD_KEY_VR = panel.sdBindContainer.dataItem(row).RECORD_KEY_VR;
                    }
                    if(typeof row === 'object'){
                      if(!panel.sdBindContainer.dataItem(panel.sdBindContainer.select()).rowState
                         || panel.sdBindContainer.dataItem(panel.sdBindContainer.select()).rowState != 'added'){
                          panel.sdBindContainer.dataItem(panel.sdBindContainer.select()).rowState = 'updated';
                      }
                    }
                  }
                });
              }
            });

            $.each(fileArr, function(idx, fileId){
              var file = self[fileId];
              file.on('click', function(e){
                var file_id = fileId.replace("_btn","" );
                var target;
                if(gridArr && gridArr.length > 0){
                  $.each(gridArr,function(idx, grid){
                    if(self[grid].dynamicFields.indexOf(file_id) > -1){
                      target = self[grid];
                    }
                  });
                }
                //오윤성 - 분기처리 수정 else if
                if(cardArr && cardArr.length > 0){
                  $.each(cardArr,function(idx, card){
                    if(self[card].dynamicFields.indexOf(file_id) > -1){
                      target = self[card];
                    }
                  });
                }
                if(treeArr && treeArr.length > 0){
                  $.each(treeArr,function(idx, tree){
                    if(self[tree].dynamicFields.indexOf(file_id) > -1){
                      target = self[tree];
                    }
                  });
                }
                if(!target){
                  return false;
                }
                setFileDataList(target, file_id);
              });
            });

          } else{ // 메뉴별부가정보등록으로 세팅된 데이터 없음.

          }
          resolve();

          // ------------------------- 동적필드 추가 메소드 -------------------------

          // # 그리드에 동적필드 요소를 추가합니다.
          function add_to_grid(item, bindTargetID, onlyDataSourceYn){
            var target = insertBool && bindTargetID ? self[bindTargetID] : (addTarget || self[item.OBJECT_CD]);
            var field_id = self._connUseYn ? item.FIELD_ID_RAW : item.FIELD_ID;
            var field_id_nm = field_id + '_NM'; // 코드피커전용
            var field = field_id;
            var field_title = item.FIELD_NM;
            // 그리드 객체
            var grid = target;
            var gridName = insertBool ? (bindTargetID ? bindTargetID : item.OBJECT_CD ) : (grid.$element.parents('.dews-ui-grid').eq(0).attr('id') || grid.$element.parents('.dews-ui-treegrid').eq(0).attr('id'));
            /*  그리드데이터소스 객체
                setDetial로 연결된 dtl의 경우 dataSource가 아래와같이 달라질 수 있으므로, 분기처리함 */
            var gridDataSource = grid && grid.dataSource ? grid.dataSource : grid.dataSource.options._baseDataSource;

            // 그리드데이터소스에 추가될 객체
            var dataSourceArr = [];

            // 컬럼속성 정의
            var align = 'center';
            var formats = {};
            var editor = {};
            var attributes = item.MNDR_YN === 'Y' && insertBool && !bindTargetID ? {class: 'required'} : undefined; // 필수값처리
            var dropDownDataSource;
            var result = true; //매소드내 그리드 추가시 컨트롤용
            var helpSize = "medium";
            switch(item.HWND_SIZE_CD){
              case '1':
                helpSize = 'small';
              break;
              case '2':
                helpSize = 'medium';
              break;
              case '3':
                helpSize = 'Big';
              break;
              case '4':
                helpSize = 'Largebig';
              break;
            }

            switch(item.FIELD_ATTR_CD){ //필드속성 (SD/P00620) - 필드속성에 따른 세팅(도움창/드롭다운/날짜/텍스트..등)
              case '1':{ // 일반(코드값)
                switch(item.HWND_FG){ //도움창구분 (SD/P00630) - 도움창/드롭다운
                  case '1':{ // 공통코드 콤보
                    dataSourceArr.push(
                      {field : field_id, dataType: 'text'}
                    );
                    align = 'left';

                    if(item.MODULE_CD && item.COMM_FIELD_CD){
                      // 드롭다운리스트 데이터소스
                      var codeData = module.api.getCodeData(item.MODULE_CD, item.COMM_FIELD_CD);
                      var codeDataSourceName = item.MODULE_CD + '_' + item.COMM_FIELD_CD + 'dataSource';
                      module.com.addNullObject(codeData[item.COMM_FIELD_CD]);
                      dropDownDataSource =  dews.ui.dataSource(codeDataSourceName, {
                        data: codeData[item.COMM_FIELD_CD]
                      });
                    }else if(item.MCLS_YN == 'Y' && item.MCLS_CD){//관리항목으로 연결된 필드
                      dews.api.get(dews.url.getApiUrl("MA", "MaMenuAddInfoService", "menuAddInfo_mcls_dtl_list"), {
                        async: false,
                        data: {
                          aply_module_cd: item.APLY_MODULE_CD,
                          mcls_cd: item.MCLS_CD
                        }
                      }).done(function (data) {
                        if (data.length > 0) {
                          if(item.MNDR_YN == 'N'){
                            data.insert(0, {SYSDEF_CD: '', SYSDEF_NM: ''})
                          }
                          dropDownDataSource =  dews.ui.dataSource(codeDataSourceName, {
                            data: data
                          });
                        } 
                      }).fail(function (xhr, status, error) {
                        dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                      });
                    }
                    editor = {
                      type: 'dropDown',
                      dataSource: dropDownDataSource,
                      dataValueField: 'SYSDEF_CD',
                      dataTextField: 'SYSDEF_NM',
                      dataSelectable: {field: 'SELECTABLE', trueValue: 'Y', falseValue: 'N'}
                    };
                    break;
                  }
                  case '2':{ // 공통코드 도움창
                    field = field_id_nm;
                    dataSourceArr.push(
                      {field : field_id,    dataType: 'text'},
                      {field : field_id_nm, dataType: 'text'}
                    );
                    align = 'left';

                    editor = {
                      type: 'codepicker',
                      helpCode: 'H_MA_CODEDTL_S',
                      helpParams: { module_cd: item.MODULE_CD, field_cd: item.COMM_FIELD_CD },
                      helpTitle: field_title + " 조회",
                      gridCodeField : field_id,
                      gridTextField : field_id_nm,
                      callback: function (rowData, pickerData) {
                        var row = grid.select();
                        grid.setCellValue(row, field_id,    pickerData.SYSDEF_CD, false);
                        grid.setCellValue(row, field_id_nm, pickerData.SYSDEF_NM, false);
                        module.com.setDynamicData(self, grid);
                      }
                    }
                    break;
                  }
                  case '3':{ // 개별 도움창
                    field = field_id_nm;
                    var customYn = item.HWND_TP_CD == "C" ? true : false;
                    var paramArr = [], paramJson = {};
                    var fieldArr = ['SYSDEF_CD', 'SYSDEF_NM'];

                    if(item.HWND_FIELD_ID){
                      fieldArr = item.HWND_FIELD_ID.split("|");
                    }

                    dataSourceArr.push(
                      {field : field_id,    dataType: 'text'},
                      {field : field_id_nm, dataType: 'text'}
                    );
                    align = 'left';
                    editor = {
                      type: 'codepicker',
                      helpCode: item.HWND_ID,
                      helpSize: helpSize,
                      helpParams: function (e) {
                        var paramValue = {};
                        if(item.PARA_VAL_DC){
                          var paramArr = item.PARA_VAL_DC.split('&');
                          try{
                            for(var i=0; i<paramArr.length; i++){
                              var paramArrIn = paramArr[i].split('=');
                              if(paramArrIn && paramArrIn.length > 1){
                                if(paramArrIn[1].indexOf("self.") >= 0){
                                  paramValue[paramArrIn[0]] = eval(paramArrIn[1]);
                                }else{
                                  paramValue[paramArrIn[0]] = paramArrIn[1];
                                }
                              }
                            }
                          }catch(exception){
                          }
                        }
                        return paramValue;
                      },
                      helpCustom: customYn,
                      // helpTitle: field_title + " 조회",
                      gridCodeField : field_id,
                      gridTextField : field_id_nm,
                      callback: function (rowData, pickerData) {//콜백함수 외부로 빼기
                        var row = grid.select();
                        grid.setCellValue(row, field_id, pickerData[fieldArr[0]], false);
                        grid.setCellValue(row, field_id_nm, pickerData[fieldArr[1]], false);
                        module.com.setDynamicData(self, grid);
                      }
                    }
                    if(customYn){
                      editor.helpViewUrl = "~/codehelp/" + item.MODULE_CD + "/" + item.HWND_ID;
                    }
                    break;
                  }
                  default : {
                    console.error("scmJS - setMenuDynamicFields: 도움창구분 케이스가 없습니다. 도움창구분 = "+item.HWND_FG);
                    break;
                  }
                }
                break;
              }
              case '2':{ // 날짜(년월일)
                dataSourceArr.push(
                  {field : field_id, dataType: 'datetime'} // 'datetime' 이어야만 그리드에 바인드 가능!!
                );
                align = 'center';
                editor = {
                  type: 'date',
                  predefined: true,
                  format: 'MA00007'
                };
                formats = {
                  type: 'date',
                  predefined: true,
                  format: 'MA00007'
                };
                break;
              }
              case '3':{ // 날짜(년월) - # 그리드에 '년월'피커가 없으므로 보류.
                dataSourceArr.push(
                  {field : field_id, dataType: 'date'}
                );
                // align = 'center';
                // editor = {
                //   type: 'date',
                //   predefined: true,
                //   format: 'yyyy-MM'
                // };
                // formats = {
                //   type: 'date',
                //   predefined: true,
                //   format: 'yyyy-MM'
                // };
                result = false;  //그리드에 안그려지기 위함 처리
                break;
              }
              case '4':{ // 날짜(년) - # 그리드에 '년'피커가 없으므로 보류.
                dataSourceArr.push(
                  {field : field_id, dataType: 'date'}
                );
                // align = 'center';
                // editor = {
                  // type: 'date',
                //   predefined: true,
                //   format: 'yyyy-MM'
                // };
                // formats = {
                //   type: 'date',
                //   predefined: true,
                //   format: 'yyyy-MM'
                // };
                result = false;  //그리드에 안그려지기 위함 처리
                break;
              }
              case '5':{ // 금액
                dataSourceArr.push(
                  {field : field_id, dataType: 'number'}
                );
                align = 'right';
                editor = {
                  type: 'number',
                  predefined: true,
                  format: 'MA00005'
                };
                formats = {
                  type: 'number',
                  predefined: true,
                  format: 'MA00005'
                };
                break;
              }
              case '6':{ // 수량
                dataSourceArr.push(
                  {field : field_id, dataType: 'number'}
                );
                align = 'right';
                editor = {
                  type: 'number',
                  predefined: true,
                  format: 'MA00001'
                };
                formats = {
                  type: 'number',
                  predefined: true,
                  format: 'MA00001'
                };
                break;
              }
              case '7':{ // 비율(%)
                dataSourceArr.push(
                  {field : field_id, dataType: 'number'}
                );
                align = 'right';
                editor = {
                  type: 'number',
                  predefined: true,
                  format: 'MA00009'
                };
                formats = {
                  type: 'number',
                  predefined: true,
                  format: 'MA00009'
                };
                break;
              }
              case '8':{ // 비율(일반)
                dataSourceArr.push(
                  {field : field_id, dataType: 'number'}
                );
                align = 'right';
                editor = {
                  type: 'number',
                  predefined: true
                };
                formats = {
                  type: 'number',
                  predefined: true
                };
                break;
              }
              case '9':
              case '11':{ // 텍스트
                dataSourceArr.push(
                  {field : field_id, dataType: 'text'}
                );
                align = 'left';
                break;
              }
              case '10':{ // 파일
                dataSourceArr.push(
                  {field : field_id, dataType: 'text'},
                  {field : field_id + "_TEXT", dataType: 'text'}
                );
                break;
              }
              case '12':{ // 시간
                dataSourceArr.push(
                  {field : field_id, dataType: 'time'}
                );
                formats = {
                  type: 'time',
                  format: 'HH:mm',
                  min: '0000',
                  max: '2400',
                  useAP: true,
                  secondValue: true
                };
                editor = {
                  type: 'time',
                  format: 'HH:mm',
                  min: '0000',
                  max: '2400',
                  useAP: true,
                  secondValue: true
                };
                break;
              }
              default: {
                console.error("scmJS - setMenuDynamicFields: 필드속성 케이스가 없습니다. 필드속성 = " + item.FIELD_ATTR_CD);
                break;
              }
            }
            if(result){
              var gridAditable = (item.UPDATE_YN && item.UPDATE_YN == "Y") ? true : false;
              if(item.FIELD_ATTR_CD == '10'){
                gridAditable = false;
                field = field_id + "_TEXT";
                var checkRecordField = true;
                for(var keyidx = 0; keyidx < gridDataSource.options.schema.model.fields.length; keyidx++){
                  if(gridDataSource.options.schema.model.fields[keyidx] == 'RECORD_KEY_VR'){
                    checkRecordField = false;
                    break;
                  }
                }
                if(checkRecordField){
                  dataSourceArr.push(
                    {field : 'RECORD_KEY_VR', dataType: 'text'}
                  )
                }
              }
              // 데이터소스에 값 추가
              $.merge(gridDataSource.options.schema.model.fields, dataSourceArr);
              gridDataSource.setFields(gridDataSource.options.schema.model.fields);
              editor.maxLength = inputMaxLength; // 컬럼 사이즈

              // 그리드에 컬럼 추가
              if(!onlyDataSourceYn){
                grid.addColumn(
                  {
                    field: field,
                    title: field_title,
                    visible: !bindTargetID,
                    align: align,
                    editor: editor,
                    editable: gridAditable,
                    attributes: attributes,
                    formats: formats
                  }
                );
              }

              if(item.HWND_FG == '3'){
                grid.on('codedialog',function(e){
                  if(field_id_nm == e.field){
                    var paramValue = {};
                    if(item.PARA_VAL_DC){
                      var paramArr = item.PARA_VAL_DC.split('&');
                      try{
                        for(var i=0; i<paramArr.length; i++){
                          var paramArrIn = paramArr[i].split('=');
                          if(paramArrIn && paramArrIn.length > 1){
                            if(paramArrIn[1].indexOf("self.") >= 0){
                              paramValue[paramArrIn[0]] = eval(paramArrIn[1]);
                            }else{
                              paramValue[paramArrIn[0]] = paramArrIn[1];
                            }
                          }
                        }
                      }catch(exception){
                        dews.error('메뉴별부가정보등록메뉴에서 파라미터 셋팅을 확인해 주세요');
                        e.preventDefault();
                        return false;
                      }
                    }
                  }
                });
              }

              // 추가한 대상 그리드 id 리스트에 추가.
              if(gridArr.indexOf(gridName) < 0){
                gridArr.push(gridName);
              }

              if(bindTargetID){
                if(bindPanelArr.indexOf(item.OBJECT_CD ) < 0){ // 추가한 바인드 패널 리스트 추가.
                  if(item.CTRL_CD == '7'){
                    bindPanelArr.push(item.OBJECT_TAB_CD);
                  }else{
                    bindPanelArr.push(item.OBJECT_CD );
                  }
                }
              }

              add_dynamic_info(item, target);
            }
          }

          // # 카드리스트에 동적필드 요소를 추가합니다.
          function add_to_card(item, cardName){
            var card = self[cardName]; // 카드리스트
            var cardDataSource = card.options.dataSource; // 카드리스트 데이터소스
            // var cardDataSource2 = card._card.dataSource; // 카드리스트 데이터소스
            var field_id = self._connUseYn ? item.FIELD_ID_RAW : item.FIELD_ID;
            var field_id_nm = field_id + "_NM"; // 코드피커전용

            // 그리드데이터소스에 추가될 객체
            var dataSourceArr = [];

            // 컬럼속성 정의
            switch(item.FIELD_ATTR_CD){ //필드속성 (SD/P00620) - 필드속성에 따른 세팅(도움창/드롭다운/날짜/텍스트..등)
              case '1':{ // 일반(코드값)
                switch(item.HWND_FG){ //도움창구분 (SD/P00630) - 도움창/드롭다운
                  case '1':{ // 공통코드 콤보
                    dataSourceArr.push(
                      {field : field_id, dataType: 'text'}
                    );
                    break;
                  }
                  case '2':// 공통코드 도움창
                  case '3':// 개별 도움창
                  {
                    dataSourceArr.push(
                      {field : field_id,    dataType: 'text'},
                      {field : field_id_nm, dataType: 'text'}
                    );
                    break;
                  }
                  default : {
                    console.error("scmJS - setMenuDynamicFields: 도움창구분 케이스가 없습니다. 도움창구분 = "+item.HWND_FG);
                    break;
                  }
                }
                break;
              }
              case '2':{ // 날짜(년월일)
                dataSourceArr.push(
                  {field : field_id, dataType: 'date'}
                );
                break;
              }
              case '3':{ // 날짜(년월) - # 그리드에 '년월'피커가 없으므로 보류.
                dataSourceArr.push(
                  {field : field_id, dataType: 'date'}
                );
                break;
              }
              case '4':{ // 날짜(년) - # 그리드에 '년'피커가 없으므로 보류.
                dataSourceArr.push(
                  {field : field_id, dataType: 'date'}
                );
                break;
              }
              case '5':{ // 금액
                dataSourceArr.push(
                  {field : field_id, dataType: 'number'}
                );
                break;
              }
              case '6':{ // 수량
                dataSourceArr.push(
                  {field : field_id, dataType: 'number'}
                );
                break;
              }
              case '7':{ // 비율(%)
                dataSourceArr.push(
                  {field : field_id, dataType: 'number'}
                );
                break;
              }
              case '8':{ // 비율(일반)
                dataSourceArr.push(
                  {field : field_id, dataType: 'number'}
                );
                break;
              }
              case '9':
              case '11':{ // 텍스트
                dataSourceArr.push(
                  {field : field_id, dataType: 'text'}
                );
                break;
              }
              case '10':{
                dataSourceArr.push(
                  {field : field_id, dataType: 'text'},
                  {field : field_id + "_TEXT", dataType: 'text'}
                );
                break;
              }
              case '12':{ // 시간
                dataSourceArr.push(
                  {field : field_id, dataType: 'time'}
                );
                break;
              }
              default : {
                console.error("scmJS - setMenuDynamicFields: 필드속성 케이스가 없습니다. 필드속성 = " + item.FIELD_ATTR_CD);
                break;
              }
            }
            if(dataSourceArr){
              // 데이터소스에 값 추가
              $.merge(cardDataSource.options.schema.model.fields,  dataSourceArr);

              if(!card.dynamicFields){
                card.dynamicFields = [];
              }

              if(card.dynamicFields.indexOf(field_id_nm) <= 0 && (item.HWND_FG === "2" || item.HWND_FG === "3")){
                card.dynamicFields.push(field_id_nm);
              }

              if(bindPanelArr.indexOf(item.OBJECT_CD ) < 0){ // 추가한 바인드 패널 리스트 추가.
                if(item.CTRL_CD == '7'){
                  bindPanelArr.push(item.OBJECT_TAB_CD);
                }else{
                  bindPanelArr.push(item.OBJECT_CD );
                }
              }

              // 추가한 대상 카드리스트 id 리스트에 추가.
              if(cardArr.indexOf(cardName) < 0){
                cardArr.push(cardName);
              }

              add_dynamic_info(item, card);
            }
          }

          // # 카드리스트에 동적필드 요소를 추가합니다.
          function add_to_tree(item, treeName){
            var tree = self[treeName]; // 카드리스트
            var field_id = self._connUseYn ? item.FIELD_ID_RAW : item.FIELD_ID;
            var field_id_nm = field_id + "_NM"; // 코드피커전용

            // 데이터소스에 값 추가
            if(!tree.dynamicFields){
              tree.dynamicFields = [];
            }

            if(tree.dynamicFields.indexOf(field_id_nm) <= 0 && (item.HWND_FG === "2" || item.HWND_FG === "3")){
              tree.dynamicFields.push(field_id_nm);
            }

            if(bindPanelArr.indexOf(item.OBJECT_CD ) < 0){ // 추가한 바인드 패널 리스트 추가.
              if(item.CTRL_CD == '7'){
                bindPanelArr.push(item.OBJECT_TAB_CD);
              }else{
                bindPanelArr.push(item.OBJECT_CD );
              }
            }

            // 추가한 대상 카드리스트 id 리스트에 추가.
            if(treeArr.indexOf(treeName) < 0){
              treeArr.push(treeName);
            }

            add_dynamic_info(item, tree);
          }

          // # 패널(컨디션/폼)에 동적필드 요소를 추가합니다.
          function add_to_panel(item, target){
            var target = target || self[item.OBJECT_CD];
            var field_id = self._connUseYn ? item.FIELD_ID_RAW : item.FIELD_ID;
            var field_id_nm = (field_id + '_NM');
            var field_title = item.FIELD_NM;

            var $li = $("<li></li>");
            var $label = $("<label>" + field_title + "</label>");
            var span_str = "";
            var $span;

            var add_open_span = "<span>";
            var add_close_span = "</span>";
            var add_input_tag = "<input ";
            var add_textarea_tag = "<textarea ";
            var add_close_tag = "\/>";
            var add_text_type = ("type=\'text\' id=\'" + field_id + "\'");
            var add_textarea_type = ("id=\'" + field_id + "\'");
            var add_file_type = ("type=\'file\' id=\'" + field_id + "\'");
            var add_file_bind_key = ("data-dews-bind-file-key=\'KEY\'");
            var add_file_bind_filename = ("data-dews-bind-filename=\'FILENAME\'");
            var add_file_bind_extension = ("data-dews-bind-extension=\'EXTENSION\'");
            var add_file_bind_size = ("data-dews-bind-size=\'FILESIZE\'");
            var add_file_is_new = ("data-dews-bind-is-new=\'ISNEW\'");
            var add_select_tag = ("<select id=\'" + field_id + "\'");
            var add_custom_dynamic_field = ("data-custom-dynamic-field=\'" + field_id + "\'");
            var add_custom_bizdoc_ctgry_cd = ("data-custom-bizdoc-ctgry-cd=\'" + item.BIZ_DOC_CTGRY_CD + "\'");
            var add_custom_doctp_cd = ("data-custom-doctp-cd=\'" + item.DOC_TP_CD + "\'");
            var add_data_dews_value_field = ("data-dews-value-field=\'SYSDEF_CD\'");
            var add_data_dews_text_field  = ("data-dews-text-field=\'SYSDEF_NM\'");
            var add_data_dews_bind_value  = ("data-dews-bind-value=\'"  + field_id + "\'");
            var add_data_dews_bind_code   = ("data-dews-bind-code=\'"   + field_id + "\'");
            var add_data_dews_bind_text   = ("data-dews-bind-text=\'"   + field_id_nm   + "\'");
            var add_data_dews_bind_column = ("data-dews-bind-column=\'" + field_id + "\'");
            var add_data_dews_selectable = ("data-dews-selectable=\'SELECTABLE\'");
            var add_data_dews_selectable_false_value = ("data-dews-selectable-false-value=\'N\'");
            var add_data_dews_format_predefined = ("data-dews-format-predefined=\'true\'");
            var add_tag_readonly = "";
            var add_maxLength = ("maxLength=\'" + 200 + "\'");
            var excute_func; // 대상을 변경시킬 메소드.
            var add_codehelp_size = "medium";
            var add_file_button_tag = ("<button id=\'" + field_id + "_btn" +"\' class=\'dews-ui-button\' type=\'button\'>첨부파일</button>");
            // var add_file_button_tag = ("<span id=\'" + field_id + "_btn" +"\' class=\'dews-custom-profile-button\'><span class=\'dews-custom-profile-file-upload-icon\'></span><span class=\'dews-custom-profile-button-frame-text\'>파일</span></span>");
            var add_file_text_tag = ("<input id=\'" + field_id + "_TEXT" +"\' type=\'text\' style=\'width:105.8px!important;\' readonly=\'readonly\' />");

            if(item.FIELD_ATTR_CD == '11'){
              $li = $("<li class=\'col-2\'></li>");
              add_maxLength = ("maxLength=\'" + 2000 + "\'");
            }

            switch(item.HWND_SIZE_CD){
              case '1':
                add_codehelp_size = 'small';
              break;
              case '2':
                add_codehelp_size = 'medium';
              break;
              case '3':
                add_codehelp_size = 'Big';
              break;
              case '4':
                add_codehelp_size = 'Largebig';
              break;
            }

            if(item.UPDATE_YN && item.UPDATE_YN == "N"){
              add_tag_readonly = ("readonly=\'readonly\'");
            }

            switch(item.FIELD_ATTR_CD){ //필드속성 (SD/P00620) - 필드속성에 따른 세팅(도움창/드롭다운/날짜/텍스트..등)
              case '1':{ // 일반(코드값)
                switch(item.HWND_FG){ //도움창구분 (SD/P00630) - 도움창/드롭다운
                  case '1':{ // 공통코드 콤보
                    excute_func = dews.ui.dropdownlist;
                    span_str += add_open_span;
                    span_str += add_select_tag;
                    span_str += (add_data_dews_value_field + add_data_dews_text_field);
                    span_str += add_custom_dynamic_field;
                    span_str += add_custom_bizdoc_ctgry_cd;
                    span_str += add_custom_doctp_cd;
                    span_str += add_data_dews_bind_value;
                    span_str += add_data_dews_selectable;
                    span_str += add_data_dews_selectable_false_value;
                    span_str += add_tag_readonly;
                    span_str += add_close_tag;
                    span_str += add_close_span;
                    $span = $(span_str);
                    break;
                  }
                  case '2':{ // 공통코드 도움창
                    excute_func = dews.ui.codepicker;
                    span_str += add_open_span;
                    span_str += add_input_tag;
                    span_str += add_text_type;
                    span_str += "data-dews-help-code=\'H_MA_CODEDTL_S\'";
                    span_str += "data-dews-code-field=\'SYSDEF_CD\' data-dews-text-field=\'SYSDEF_NM\'";
                    span_str += "data-dews-help-title=\'" + field_title + "\'";
                    span_str += "data-dews-help-params='module_cd=" + item.MODULE_CD + "&&field_cd=" + item.COMM_FIELD_CD + "\'";
                    span_str += "data-dews-help-custom=\'false\'"
                    span_str += "data-dews-help-size=" + add_codehelp_size + " ";
                    span_str += add_custom_dynamic_field;
                    span_str += add_custom_bizdoc_ctgry_cd;
                    span_str += add_custom_doctp_cd;
                    span_str += add_data_dews_bind_code;
                    span_str += add_data_dews_bind_text;
                    span_str += add_tag_readonly;
                    span_str += add_close_tag;
                    span_str += add_close_span;
                    $span = $(span_str);
                    break;
                  }
                  case '3':{ // 개별 도움창
                    var fieldArr = ['SYSDEF_CD', 'SYSDEF_NM'];
                    if(item.HWND_FIELD_ID){
                      fieldArr = item.HWND_FIELD_ID.split("|");
                    }
                    var customYn = item.HWND_TP_CD == "C" ? "true" : "false";

                    excute_func = dews.ui.codepicker;
                    span_str += add_open_span;
                    span_str += add_input_tag;
                    span_str += add_text_type;
                    span_str += "data-dews-help-code=\'" + item.HWND_ID + "\'";
                    span_str += "data-dews-code-field=\'"+ fieldArr[0] +"\' data-dews-text-field=\'" + fieldArr[1] + "\'";
                    span_str += "data-dews-help-title=\'" + field_title + "\'";
                    // span_str += "data-dews-help-params=\'" + item.PARA_VAL_DC + "\'";
                    span_str += "data-dews-help-custom=\'" + customYn + "\'";
                    if(customYn == "true"){
                      span_str += "data-dews-help-view-url=\'~/codehelp/"+ item.MODULE_CD + "/" + item.HWND_ID + "\'";
                    }
                    span_str += "data-dews-help-size=" + add_codehelp_size + " ";;
                    span_str += add_custom_dynamic_field;
                    span_str += add_custom_bizdoc_ctgry_cd;
                    span_str += add_custom_doctp_cd;
                    span_str += add_data_dews_bind_code;
                    span_str += add_data_dews_bind_text;
                    span_str += add_tag_readonly;
                    span_str += add_close_tag;
                    span_str += add_close_span;
                    $span = $(span_str);
                    break;
                  }
                  default : {
                    console.error("scmJS - setMenuDynamicFields: 도움창구분 케이스가 없습니다. 도움창구분 = "+item.HWND_FG);
                    break;
                  }
                }
                break;
              }
              case '2':{ // 날짜(년월일)
                excute_func = dews.ui.datepicker;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += "data-dews-format=\'" + 'MA00007' + "\'";
                span_str += add_data_dews_format_predefined;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '3':{ // 날짜(년월)
                excute_func = dews.ui.monthpicker;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += "data-dews-format=\'" + 'MA00008' + "\'";
                span_str += add_data_dews_format_predefined;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '4':{ // 날짜(년)
                excute_func = dews.ui.yearpicker;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '5':{ // 금액
                excute_func = dews.ui.numerictextbox;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += add_maxLength;
                span_str += "data-dews-format=\'" + 'MA00003' + "\'";
                span_str += add_data_dews_format_predefined;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '6':{ // 수량
                excute_func = dews.ui.numerictextbox;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += add_maxLength;
                span_str += "data-dews-format=\'" + 'MA00001' + "\'";
                span_str += add_data_dews_format_predefined;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '7':{ // 비율(%)
                excute_func = dews.ui.numerictextbox;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += add_maxLength;
                span_str += "data-dews-format=\'" + 'MA00009' + "\'";
                span_str += add_data_dews_format_predefined;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '8':{ // 비율(일반)
                excute_func = dews.ui.numerictextbox;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += add_maxLength;
                span_str += "data-dews-format=\'" + 'MA00009' + "\'";
                span_str += add_data_dews_format_predefined;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '9':{ // 텍스트
                excute_func = dews.ui.textbox;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += add_maxLength;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '10':{ // 파일
                excute_func = dews.ui.textbox;
                span_str += add_file_text_tag;
                span_str += add_file_button_tag;
                $span = $(span_str);
                if(fileArr.indexOf(field_id + "_btn") < 0){
                  fileArr.push(field_id + "_btn");
                }
                break;
              }
              case '11':{ // 텍스트(비고)
                excute_func = dews.ui.textbox;
                span_str += add_open_span;
                span_str += add_textarea_tag;
                span_str += add_textarea_type;
                span_str += add_maxLength;
                span_str += add_custom_dynamic_field;
                span_str += add_custom_bizdoc_ctgry_cd;
                span_str += add_custom_doctp_cd;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              case '12':{ // 시간
                excute_func = dews.ui.timepicker;
                span_str += add_open_span;
                span_str += add_input_tag;
                span_str += add_text_type;
                span_str += add_data_dews_bind_column;
                span_str += add_tag_readonly;
                span_str += add_close_tag;
                span_str += add_close_span;
                $span = $(span_str);
                break;
              }
              default: {
                console.error("scmJS - setMenuDynamicFields: 필드속성 케이스가 없습니다. 필드속성 = " + item.FIELD_ATTR_CD);
                break;
              }
            }

            // 컨디션/폼패널에 컨트롤요소 추가.
            if(span_str && span_str.length > 0){
              $li.append($label);
              $li.append('\n');
              $li.append($span);
              var lIIndex = 0;
              var hiddenIndex = 0;
              let colLength = target.$element[0].className.split('col-')[1].charAt(0);
              if(item.CTRL_CD === '5'){
                var lastULIndex = $(target._element).find('ul').length-1;
                for(var i=0; i<$(target._element).find('ul').eq(lastULIndex).find('li').length; i++){
                  if($($(target._element).find('ul').eq(lastULIndex).find('li')[i])[0].style.display == 'none'){
                    ++hiddenIndex;
                  }
                }
                lIIndex =  $(target._element).find('ul').eq(lastULIndex).find('li').length - hiddenIndex;
                $(target._element).find('ul').eq(lastULIndex).append($li);
                if(item.FIELD_ATTR_CD == '11'){
                  var $li2 = $("<li class=\'dews-form-panel-item-transparency transparency\'></li>");
                  $(target._element).find('ul').eq(lastULIndex).append($li2);
                }
              } else{
                var lastULIndex = $(target.$element).find('ul').length-1;
                for(var i=0; i<$(target.$element).find('ul').eq(lastULIndex).find('li').length; i++){
                  if($($(target.$element).find('ul').eq(lastULIndex).find('li')[i])[0].style.display == 'none'){
                    ++hiddenIndex;
                  }
                }
                lIIndex = $(target.$element).find('ul').eq(lastULIndex).find('li').length- hiddenIndex;
                $(target.$element).find('ul').eq(lastULIndex).append($li);
                if(item.FIELD_ATTR_CD == '11'){
                  var $li2 = $("<li class=\'dews-form-panel-item-transparency transparency\'></li>");
                  $(target.$element).find('ul').eq(lastULIndex).append($li2);
                }
              }
              if(lIIndex % colLength == 0){
                $li.css('clear','left');
              }else{
                $li.css('clear','right');
              }
              if(item.FIELD_ATTR_CD == "10"){
                self[field_id + "_TEXT"] = excute_func(self.$content.find('#' + field_id + "_TEXT"));
                excute_func = dews.ui.button;
                self[field_id + "_btn"] = excute_func(self.$content.find('#' + field_id + "_btn"));
                field_id = field_id + "_TEXT";
              }else{
                self[field_id] = excute_func(self.$content.find('#'+field_id));
              }
              var element = self[field_id].element || self[field_id]._element;
              var $element = element && element.id ? $(element) : element;
              self[('$' + field_id)] = $element;
              $element.addClass('dynamic-fields');
              // 드롭다운리스트라면, 데이터소스 세팅
              if($element.hasClass('dews-ui-dropdownlist')){
                if(item.MODULE_CD && item.COMM_FIELD_CD){
                  var codeData = module.api.getCodeData(item.MODULE_CD, item.COMM_FIELD_CD);
                  var codeDataSourceName = item.MODULE_CD + '_' + item.COMM_FIELD_CD + 'dataSource';
                  module.com.addNullObject(codeData[item.COMM_FIELD_CD]);
                  var dropDownDataSource =  dews.ui.dataSource(codeDataSourceName, {
                    data: codeData[item.COMM_FIELD_CD]
                  });
                } else if(item.MCLS_YN == 'Y' && item.MCLS_CD){//관리항목으로 연결된 필드
                  dews.api.get(dews.url.getApiUrl("MA", "MaMenuAddInfoService", "menuAddInfo_mcls_dtl_list"), {
                    async: false,
                    data: {
                      aply_module_cd: item.APLY_MODULE_CD,
                      mcls_cd: item.MCLS_CD
                    }
                  }).done(function (data) {
                    if (data.length > 0) {
                      if(item.MNDR_YN == 'N'){
                        data.insert(0, {SYSDEF_CD: '', SYSDEF_NM: ''})
                      }
                      dropDownDataSource =  dews.ui.dataSource(codeDataSourceName, {
                        data: data
                      });
                    } 
                  }).fail(function (xhr, status, error) {
                    dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                  });
                } 
                
                self[field_id].setDataSource(dropDownDataSource);
              }
              else if($element.hasClass('dews-ui-codepicker')){
                if(item.PARA_VAL_DC){
                  var paramArr = item.PARA_VAL_DC.split('&');

                  self[field_id].on('codedialog',function(e){
                    var paramValue = {};
                    try{
                      for(var i=0; i<paramArr.length; i++){
                        var paramArrIn = paramArr[i].split('=');
                        if(paramArrIn && paramArrIn.length > 1){
                          if(paramArrIn[1].indexOf("self.") >= 0){
                            paramValue[paramArrIn[0]] = eval(paramArrIn[1]);
                          }else{
                            paramValue[paramArrIn[0]] = paramArrIn[1];
                          }
                        }
                      }
                    }catch(exception){
                      dews.error('메뉴별부가정보등록메뉴에서 파라미터 셋팅을 확인해 주세요');
                      e.preventDefault();
                      return false;
                    }
                  });

                  self[field_id].setHelpParams(function(e){
                    var paramValue = {};
                    try{
                      for(var i=0; i<paramArr.length; i++){
                        var paramArrIn = paramArr[i].split('=');
                        if(paramArrIn && paramArrIn.length > 1){
                          if(paramArrIn[1].indexOf("self.") >= 0){
                            paramValue[paramArrIn[0]] = eval(paramArrIn[1]);
                          }else{
                            paramValue[paramArrIn[0]] = paramArrIn[1];
                          }
                        }
                      }
                    }catch(exception){
                    }
                    return paramValue;
                  });
                }
              }
              add_dynamic_info(item, target);

              if(item.MNDR_YN === 'Y'){  // 요소 필수값 처리.
                self[field_id].required(true);
              }
            }
          }

          // 동적컬럼 추가 대상에게 동적컬럼 정보를 넣어줍니다.
          function add_dynamic_info(item, target){
            var field_id = self._connUseYn ? item.FIELD_ID_RAW : item.FIELD_ID;
            if(target.dynamicFields){
              target.dynamicFields.push(field_id);
            } else{
              target.dynamicFields = [field_id];
            }

            if(target.dynamicInfo){
              target.dynamicInfo[field_id] = item;
            } else{
              target.dynamicInfo = {};
              target.dynamicInfo[field_id] = item;
            }
          }

          function setFileDataList(target, field_id){
            var uid_column = module.com.getDynamicUIDColumn(target.dataItem(target.select()));
            var uid = target.dataItem(target.select())[uid_column];
            var dynamicFileDataSource;
            var dynamicFlag = true;
            if(self._dynamicDataItems[uid]){
              for(var i=0; i<self._dynamicDataItems[uid].length; i++){
                if( ((self._connUseYn && self._dynamicDataItems[uid][i].FIELD_ID_RAW == field_id)
                  || (!self._connUseYn && self._dynamicDataItems[uid][i].FIELD_ID == field_id))
                  && (typeof self._dynamicDataItems[uid][i].VALUE === "object")){
                  dynamicFlag = false;
                  break;
                }
              }
            }

            if(dynamicFlag){
              dynamicFileDataSource = dews.ui.dataSource('dynamicFileDataSource', {
                transport: {
                  read: {
                    url: dews.url.getApiUrl('MA', 'MaMenuAddInfoService', 'menuAddInfo_file_list'),
                    data: {
                      file_dc: target.dataItem(target.select())[field_id]
                    }
                  }
                },
                schema: {
                  model: {
                    id: "COMPANY_CD",
                    fields: [
                      { field: "FILE_DC" },
                      { field: "NEW_FILE_DC" },
                      { field: "ORGL_FILE_DC" },
                      { field: "ORGL_FEXTSN_DC" },
                      { field: "FILE_VR" }
                    ]
                  }
                }
              });
            }else{
              dynamicFileDataSource = dews.ui.dataSource('dynamicFileDataSource', {
                data: self._dynamicFileDataItems[uid],
                schema: {
                  model: {
                    id: "COMPANY_CD",
                    fields: [
                      { field: "FILE_DC" },
                      { field: "NEW_FILE_DC" },
                      { field: "ORGL_FILE_DC" },
                      { field: "ORGL_FEXTSN_DC" },
                      { field: "FILE_VR" }
                    ]
                  }
                }
              });
            }

            var dynamicMultidialog = dews.ui.multifiledialog('dynamicMultidialog', {
              dataSource: dynamicFileDataSource,
              title: dews.localize.get('파일 업로드', 'D0023049'),
              size: 'large',
              buttons: 'applyAndClose',
              upload: { use: true },
              delete: { use: true },
              download: { use: true },
              binding: {
                fileKey: 'NEW_FILE_DC',
                filename: 'ORGL_FILE_DC',
                extension: 'ORGL_FEXTSN_DC',
                size: 'FILE_VR'
              },
              ok: function (data) {
                var targetType = module.com.getContainerType(target);
                var fileDatas = {Added:[], Deleted:[], Updated:[]};
                var fileName = "";
                $.each(dynamicFileDataSource.data(), function (idx, datas) {
                  if (datas.isNewFile) {
                    fileDatas.Added.push(datas);
                    fileName = fileName ? fileName : datas.ORGL_FILE_DC;
                  } else if (datas.isDeleteFile) {
                    fileDatas.Deleted.push(datas);
                  } else {
                    fileDatas.Updated.push(datas);
                    fileName = fileName ? fileName : datas.ORGL_FILE_DC;
                  }
                });
                var fileLength = fileDatas.Added.length + fileDatas.Updated.length;
                fileName = fileLength == 0 ? "" : (fileLength == 1 ? fileName : fileName + "외 " + (fileLength - 1) + "건");

                switch(targetType){
                  case 'TreeGrid': // 트리그리드
                  case 'Grid':{
                    self._dynamicFileDataItems[uid] = dynamicFileDataSource.data();
                    module.com.setDynamicData(self, target, fileDatas);
                    target.setCellValue(target.select(), field_id+"_TEXT", fileName, false);
                    break;
                  }
                  case 'CardList':{
                    self._dynamicFileDataItems[uid] = dynamicFileDataSource.data();
                    self._dynamicDataItems[uid]
                      = module.com.mergeDynamicForPanel(self, target.sdBindContainer, {}, fileDatas)[dynamic_object_name];
                    target.setValue(target.select(), field_id+"_TEXT", fileName);
                    for(var i=0; i<self._dynamicDataItems[uid].length; i++){
                      self._dynamicDataItems[uid][i].RECORD_KEY_VR = target.dataItems(target.select()).RECORD_KEY_VR;
                    }
                  }
                  case 'TreeView':{
                    self._dynamicFileDataItems[uid] = dynamicFileDataSource.data();
                    self._dynamicDataItems[uid]
                      = module.com.mergeDynamicForPanel(self, target.sdBindContainer, {}, fileDatas)[dynamic_object_name];
                    target.dataItem(target.select())[field_id+"_TEXT"] = fileName;
                    for(var i=0; i<self._dynamicDataItems[uid].length; i++){
                      self._dynamicDataItems[uid][i].RECORD_KEY_VR = target.dataItems(target.select()).RECORD_KEY_VR;
                    }
                    if(!target.dataItem(target.select()).rowState || target.dataItem(target.select()).rowState != 'added'){
                      target.dataItem(target.select()).rowState = 'updated';
                      target.dataItem(target.select()).dirty = true;
                    }
                  }
                }
                $.each(target.sdBindContainer, function(idx, panel){
                  if(panel.dynamicFields && panel.dynamicFields.indexOf(field_id) >= 0 ){
                    target.bindPanel(panel);
                  }
                });
              }
            });
            dynamicMultidialog.open();
            dynamicMultidialog.dialog.buttons.ok.on('click', function () {
              dynamicMultidialog.ok();
            });

          }
        },10);
      });
    },
    /*********************************************************************************************
     *  @desc   컨디션/폼패널 객체를 받아, 해당 객체에 '메뉴별부가정보등록'에 의해 동적으로 그려진 컨트롤이 있을시,
     *          값들을 객체배열 형태로 리턴.
     *  @param  {Object} self   [필수] 페이지 self.
     *  @param  {Object} panel  [필수] 컨디션/폼패널 객체
     *  @return {Array}         객체배열 형태로 리턴.
     *  @ex     scmJS.com.getDynamicFieldValues(self, self.slssor00100_condition);
     * ------------------------------------------------------------------------------------------*/
    getDynamicFieldValues: function(self, target, fileData){
      if(!target){ // 맨 앞에 self를 받도록 변경되어, 이전 소스들 오류나지 않도록 임시 설정.
        target = self;
        self = dews.ui.page;
      }
      var result = []; // 반환 배열.

      var targetType = module.com.getContainerType(target);
      switch(targetType){
        case 'TreeGrid': // 트리그리드
        case 'Grid': // 그리드
        case 'CardList':////////////////// [2023.01.19] 카드리스트 추가부분
        {
          var grid = target;
          var row = grid.select();
          var data = grid.dataItem(row);
          $.each(grid.dynamicFields, function(idx, field_id){
            var val = module.com.replaceNull(data[field_id], '');
            val = val instanceof Date ? dews.date.format(val, 'yyyyMMdd') : val;
            if(!grid.dynamicInfo[field_id]){}
            else if(grid.dynamicInfo[field_id].FIELD_ATTR_CD === '1') {  //공통코드일때
              var txtVal = module.com.replaceNull(data[field_id + "_NM"], '');
              result.push($.extend({}, grid.dynamicInfo[field_id], {VALUE: String(val) || null , TEXT: String(txtVal), RECORD_KEY_VR: data.RECORD_KEY_VR }));
            } else if(grid.dynamicInfo[field_id].FIELD_ATTR_CD === '10') {  //파일일때
              result.push($.extend({}, grid.dynamicInfo[field_id], {VALUE: fileData || String(val) || null, RECORD_KEY_VR: data.RECORD_KEY_VR }));
            }else {
              result.push($.extend({}, grid.dynamicInfo[field_id], {VALUE: String(val) || null, RECORD_KEY_VR: data.RECORD_KEY_VR}));
              if(data[field_id + "_NM"]){
                var txtVal = module.com.replaceNull(data[field_id + "_NM"], '');
                result.push($.extend({}, grid.dynamicInfo[field_id], {TEXT: String(txtVal) || null, RECORD_KEY_VR: data.RECORD_KEY_VR}));
              }
            }
          });
          break;
        }
        case 'TabPanel':{
          if(Array.isArray(target._dynamicFormID)){
            $.each(target._dynamicFormID,function(idx, item){
              $.merge(result, module.com.getDynamicFieldValues(self, self[item]));
            });
          }else{
            result = module.com.getDynamicFieldValues(self, self[target._dynamicFormID]);
          }
          break;
        }
        case 'FormPanel':
        case 'ConditionPanel':{ // 컨디션/폼패널 체크
          $.each(target.dynamicFields || [], function(idx, field_id){ // 대상에 추가된 컨트롤들의 id배열.
            var control = self[field_id];
            var controlElement = self[('$'+field_id)];
            var data = JSON.parse(JSON.stringify(target.dynamicInfo[field_id]));

            if(data){ // 객체에 VALUE 설정.
              if(fileData && self[field_id+"_btn"] && self[('$'+field_id+"_TEXT")] && self[('$'+field_id+"_TEXT")].hasClass('dews-ui-textbox')){
                data.VALUE = fileData;
              }else if(controlElement && controlElement.hasClass('dews-ui-dropdownlist')){
                data.VALUE = !module.com.isNull(control.value()) ? String(control.value()) : null;
              } else if(controlElement && controlElement.hasClass('dews-ui-codepicker')){
                data.VALUE = !module.com.isNull(control.code()) ? String(control.code()) : null;
                data.TEXT  = !module.com.isNull(control.code()) ? String(control.text()) : null;
              } else if(controlElement && controlElement.hasClass('dews-ui-textbox')){
                data.VALUE = !module.com.isNull(control.text()) ? String(control.text()) : null;
              } else if(controlElement && controlElement.hasClass('dews-ui-numerictextbox')){
                data.VALUE = !module.com.isNull(control.value()) ? String(control.value()) : null;
              } else if(controlElement && controlElement.hasClass('dews-ui-datepicker')){
                data.VALUE = !module.com.isNull(control.value()) ? String(control.value()) : null;
              } else if(controlElement && controlElement.hasClass('dews-ui-monthpicker')){
                data.VALUE = !module.com.isNull(control.value()) ? String(control.value()) : null;
              } else if(controlElement && controlElement.hasClass('dews-ui-yearpicker')){
                data.VALUE = !module.com.isNull(control.value()) ? String(control.value()) : null;
              }
              else if(controlElement && controlElement.hasClass('dews-ui-timepicker')){
                data.VALUE = !module.com.isNull(control.value()) ? String(control.value()) : null;
              }
            }
            result.push(data);
          });
          break;
        }
        default:{
          console.error("scmJS - getDynamicFieldValues: 파라미터 객체가 폼패널/컨디션패널/그리드가 아닙니다." + target);
          break;
        }
      }
      return result;
    },
    /*********************************************************************************************
     *  @desc   그리드/카드리스트의 동적필드 값을 수동으로 세팅해둡니다.
     *  @param  {Object} self    [필수] 메뉴내 this(self/dewself)
     *  @param  {Object} target  [필수] setBind를 사용하는 그리드/카드리스트지만 로직적으로 폼/컨디션패널을 수정하지 않고
     *                                  강제 setCellValue/setValue만 사용한 경우, mergeDynamicForObj를 사용해도 DYNAMIC_OBJECT를
     *                                  리턴받지 못하여 강제로 직접 동적필드 값들을 세팅 및 리턴.
     *  @return {Object} 동적필드 값들을 리턴.
     *  @ex     scmJS.com.setDynamicData(self, self.mstGrid);
     * ------------------------------------------------------------------------------------------*/
    setDynamicData: function(self, target, fileData){
      self._dynamicDataItems = self._dynamicDataItems ? self._dynamicDataItems : {};
      var row = target.select();
      var rowData = target.dataItem(row);
      var uid_column = module.com.getDynamicUIDColumn(rowData);
      var dynamic_data = module.com.getDynamicFieldValues(self, target, fileData);
      self._dynamicDataItems[rowData[uid_column]] = dynamic_data;
      return dynamic_data;
    },
    /*********************************************************************************************
     *  @desc   컨디션/폼패널 객체를 받아, 해당 객체에 '메뉴별부가정보등록'에 의해 동적으로 그려진 컨트롤이 있을시,
     *          값들을 객체배열 형태로 리턴.
     *  @param  {Object} self    [필수] 메뉴내 this(self/dewself)
     *  @param  {Array}  panels  [필수] 컨디션/폼패널 객체 리스트
     *  @param  {Object} obj     [옵션] 객체배열 형태로 리턴.
     *  @return {Object} 두번째 파라미터(obj. 또는 빈 객체)에 DYNAMIC_OBJECT 객체로 배열값을 넣어 리턴.
     *  @ex     scmJS.com.mergeDynamicForPanel(self, [self.slssor00100_condition1, self.slssor00100_condition2], sd_so_mst);
     * ------------------------------------------------------------------------------------------*/
    mergeDynamicForPanel: function(self, panels, obj, fileData){
      var dynamicFieldsArr = [];
      // self 추가되어 없을때 호환(임시.)
      if(!self.id){
        var tmp = {
          self: self,
          panels: panels,
          obj: obj,
        };

        self = dews.ui.page;
        panels = tmp.self;
        obj = tmp.panels;
      }
      obj = obj || {}; // obj 없을시,
      panels = Array.isArray(panels) ? panels : [panels];
      $.each(panels, function(idx, panel){
        $.merge(dynamicFieldsArr, module.com.getDynamicFieldValues(self, panel, fileData));
      });
      obj[dynamic_object_name] = dynamicFieldsArr;

      return obj;
    },
    /*********************************************************************************************
     *  @desc   더티데이터 또는 배열을 받아 객체에 DYNAMIC_OBJECT를 추가시켜 리턴.
     *  @param  {Object/Array} data [필수] 더티데이터 또는 배열
     *  @return {Object/Array} DYNAMIC_OBJECT가 추가된 더티데이터 또는 배열
     *  @ex     scmJS.com.mergeDynamicForObj(self.mstGridDataSource.getDirtyData());
     * ------------------------------------------------------------------------------------------*/
    mergeDynamicForObj: function(self, data, initSetting){
      // 맨 앞에 self를 받도록 변경되어, 이전 소스들 오류나지 않도록 임시 설정.
      if(arguments && arguments.length == 1){ // 맨 앞에 self를 받도록 변경되어, 이전 소스들 오류나지 않도록 임시 설정.
        initSetting = data;
        data = self;
        self = dews.ui.page;
      }else if(arguments && arguments.length == 2 && typeof data === "string"){
        initSetting = data;
        data = self;
        self = dews.ui.page;
      }

      if(Array.isArray(data)){ // 배열의 경우.
        $.each(data, function(idx, item){
          var uid_column = module.com.getDynamicUIDColumn(item);
          item[dynamic_object_name] = self._dynamicDataItems[item[uid_column]];
          if(initSetting && !self._dynamicDataItems[item[uid_column]]){
            var targetArr = initSetting.split("|");
            item[dynamic_object_name] = settingDynamicData(self, targetArr, item);
          }
        });
      } else if(typeof data === 'object'){ // 더티데이터의 경우.
        if(data.hasOwnProperty('Added') && data.hasOwnProperty('Updated')){
          $.each(Object.keys(data), function(kIdx, state_key){
            $.each(data[state_key], function(idx, item){
              var uid_column = module.com.getDynamicUIDColumn(item);
              item[dynamic_object_name] = self._dynamicDataItems[item[uid_column]];
              if(initSetting && !self._dynamicDataItems[item[uid_column]]){
                var targetArr = initSetting.split("|");
                item[dynamic_object_name] = settingDynamicData(self, targetArr, item);
              }
            });
          });
        } else{
          console.error("scmJS - mergeDynamicForObj: 파라미터가 부적합 합니다.", data);
        }
      } else{
        console.error("scmJS - mergeDynamicForObj: 파라미터가 부적합 합니다.", data);
      }

      function settingDynamicData(self, targetArr, item){
        var result = [];
        $.each(targetArr, function(idx, target){
          $.each(self[target].dynamicFields, function(idx, field_id){
            var val = module.com.replaceNull(item[field_id], '');
            val = val instanceof Date ? dews.date.format(val, 'yyyyMMdd') : val;
            if(!self[target].dynamicInfo[field_id]){}
            else if(self[target].dynamicInfo[field_id].FIELD_ATTR_CD === '1') {  //공통코드일때
              var txtVal = module.com.replaceNull(item[field_id + "_NM"], '');
              result.push($.extend({}, self[target].dynamicInfo[field_id], {VALUE: String(val) || null , TEXT: String(txtVal), RECORD_KEY_VR: item.RECORD_KEY_VR }));
            } else if(self[target].dynamicInfo[field_id].FIELD_ATTR_CD === '10') {  //파일일때
              result.push($.extend({}, self[target].dynamicInfo[field_id], {VALUE: null || null, RECORD_KEY_VR: item.RECORD_KEY_VR }));
            }else {
              result.push($.extend({}, self[target].dynamicInfo[field_id], {VALUE: String(val) || null, RECORD_KEY_VR: item.RECORD_KEY_VR}));
              if(item[field_id + "_NM"]){
                var txtVal = module.com.replaceNull(item[field_id + "_NM"], '');
                result.push($.extend({}, self[target].dynamicInfo[field_id], {TEXT: String(txtVal) || null, RECORD_KEY_VR: item.RECORD_KEY_VR}));
              }
            }
          });
        });
        return result;
      }
      return data;
    },
    /*********************************************************************************************
     *  @desc   그리드/카드리스트 등의 컴포넌트 마다 고유값 컬럼이 달라 있을수도, 없을수도 있어
                동적컬럼의 고유값으로 사용할 컬럼명을 리턴받는 용도로 사용.
                '__UUID' => '_uid' => 'uid' 순으로 체크.
     *  @return {String} uid컬럼명을 반환. 동적컬럼 관련하여 사용.
     * ------------------------------------------------------------------------------------------*/
    getDynamicUIDColumn: function(data){
      var uid_column = '';
      $.each(['__UUID', '_uid', 'uid'], function(idx, id){
        if(data.hasOwnProperty(id) && !module.com.isNull(data[id])){
          uid_column = id;
          return false;
        }
      });
      return uid_column;
    },
    /*********************************************************************************************
     *  @desc     메뉴에서 이함수 등록하면 그리드내에 메뉴이동한 항목을 찾아 더블클릭시 자동으로 이동시킴
     *
     *  @사용법   사용하고자하는 메뉴에서는
     *            scmJS.com.setAutoMenuOpen(dewself); 선언만 하면됨
     *
     *            최초작성 이용규 선임연구원, 최종완성은 노태현 연구원이 단계별로 개발하도록합니다.
     *            2020.11.05 노태현 -> 최지영 담당자 변경
     *
     *            영업모듈만 적용하고 필요시 타모듈도 적용합니다. (SCM내), 현재는 문서번호위주이지만 수주유형 등도 추가될 수 있음
     *
     *            개발1단계 - 더블클릭시 이동하는 처리
     *                       param명칭 통일화합니다. A메뉴에서는 menuId, B메뉴에서는 menu_id 이런거 금지
     *                       필요시 메뉴담당자들에게 전파하여 수정하도록 하세요.
     *                       2020.11.05 [수정 사항]
     *                       - 그리드 데이터 소스 기준으로 컬럼 찾도록 수정
     *                       [개선사항]
     *                       - 번호 자체가 같은 점프 메뉴를 바라보지만 컬럼이 다른 경우 현재는 선언부에서 각각 작성했으나 추후에 이 부분은 개선 필요할듯 합니다.
     *                       (ex. 전표번호:  PLMI_DOCU_NO(수익성전표번호), PADOC_NO(수익성전표번호), CNCL_PLMI_DOCU_NO(수익성 취소전표번호))
     *                       - 그리드 외 컨디션 패널 등의 더블클릭 시에도 가능하도록 개선 필요
     *
     * **********************************************************************************************/
    setAutoMenuOpen: function (v) {
      if (v.$content) {
        if (v.$content.find('.dews-ui-grid') && v.$content.find('.dews-ui-grid').length > 0) {
          $.each(v.$content.find('.dews-ui-grid'), function (idx, grid) {
            var grid = dews.ui.grid($(grid));

            //그리드 더블클릭 이벤트 클릭 시 실행
            grid.on("dblClicked", function (e) {
              var keys = Object.keys(openMenuDefined);

              // 값이 있고 메뉴이동가능한 컬럼을 더블클릭하였을때
              if (keys.indexOf(e.cell.field) > -1 && e.grid.getCellValue(e.row.index, e.cell.field) && e.grid.getRowState(e.row.index) != "added") {

                var gridColumns = [];
                //기존에는 그리드에 실제로 보여지는 필드 기준(Object.keys(e.grid.dataSource.options.field);)으로 했었으나 데이터소스에만 있고 보여주지 않는 컬럼들이 있어서 데이터 소스 내에서 가져오도록 변경
                $(e.grid.dataSource.options.field).each(function (idx, item) {
                  gridColumns.push(item.field);
                });

                //이동할 대상 메뉴가 한개만 존재할경우
                if (openMenuDefined[e.cell.field].moveMenu.length === 1) {
                  //점프하려는 메뉴가 자기자신 메뉴가 아닐때만 실행
                  if(openMenuDefined[e.cell.field].moveMenu[0].menu_id != dews.ui.page.menu.id) {
                    var params = Object.keys(openMenuDefined[e.cell.field].moveMenu[0].params);
                    var otherParams = openMenuDefined[e.cell.field].moveMenu[0].params.others;
                    var flag = true;
                    var repFlag = false;
                    var newParams = { menuID: dews.ui.page.menu.id };
                    var replaceParam = [];//대체되는 컬럼 담는 배열 변수
                    var errColumn = "";//점프 시 에러컬럼 담는 변수
                    var moveModule = openMenuDefined[e.cell.field].moveMenu[0].module_cd;
                    var moveMenu = openMenuDefined[e.cell.field].moveMenu[0].menu_id;
                    for (var i = 0; i < params.length; i++) {
                      // 필수인자값이 존재하는지 체크
                      if (openMenuDefined[e.cell.field].moveMenu[0].params[params[i]] === true) {
                        //인자값이 필수체크일 경우
                        if (!module.com.isNull(otherParams)) {//대체되는 컬럼이 있을 경우
                          $(otherParams).each(function (idx, item) {
                            if (otherParams[idx].col) {
                              if (params[i] === otherParams[idx].col) {
                                repFlag = true;
                                if (!module.com.isNull(otherParams[idx].repCol)) {
                                  replaceParam = otherParams[idx].repCol.split("|");//대체되는 컬럼이 2개 이상일 경우 '|'로 구분
                                  $(replaceParam).each(function (r, rItem) {
                                    if (!(gridColumns.indexOf(params[i].toUpperCase()) > -1)) {//대체되는 컬럼이 그리드데이터 소스에 존재할 경우, 그리드데이터 소스에 존재하는 컬럼 그대로 세팅
                                      newParams[params[i]] = e.grid.getCellValue(e.row.index, rItem.toUpperCase());
                                    } else {//대체되는 컬럼이 그리드데이터 소스에 존재하지 않을 경우, 대체되는 컬럼으로 세팅
                                      newParams[rItem] = e.grid.getCellValue(e.row.index, params[i].toUpperCase());
                                    }
                                  });
                                }
                                /*********************************************************************************************
                                //어떤 컬럼값에 따라 점프하는 메뉴id 자체가 다른 경우
                                //이부분도 모듈마다 달라질 수 있기에 추가 작성 필요
                                *********************************************************************************************/
                                if (gridColumns.indexOf(otherParams[idx].col.toUpperCase().toUpperCase()) > -1) {
                                  switch (otherParams[idx].col.toUpperCase()) {
                                    case "RTP_YN": { //영업의 경우, 반품여부값(RTP_YN = 'Y'|'N')에 따라 납품이냐 반품지시현황이냐로 나뉘기 때문에 해당 부분 별도 처리
                                      if (gridColumns.indexOf(params[i].toUpperCase()) > -1) {
                                        if (e.grid.getCellValue(e.row.index, otherParams[idx].col.toUpperCase()) === "Y") {
                                          moveModule = otherParams[idx].repModule;
                                          moveMenu = otherParams[idx].repMenu;
                                        }
                                      } else {
                                        flag = false;
                                        errColumn = otherParams[idx].col.toUpperCase();
                                        return false;
                                      }
                                      break;
                                    }
                                    default:
                                      break;
                                  }
                                }
                              }
                            }
                          });
                        }
                        if (!repFlag) {
                          if (gridColumns.indexOf(params[i].toUpperCase()) > -1 && e.grid.getCellValue(e.row.index, params[i].toUpperCase())) {
                            newParams[params[i]] = e.grid.getCellValue(e.row.index, params[i].toUpperCase());
                          } else {
                            flag = false;
                            errColumn = params[i].toUpperCase();
                            break;
                          }
                        }
                      }
                      else if (openMenuDefined[e.cell.field].moveMenu[0].params[params[i]] === false) {//필수가 아닌 경우 인자 값 그대로 세팅
                        if (gridColumns.indexOf(params[i].toUpperCase()) > -1 && e.grid.getCellValue(e.row.index, params[i].toUpperCase())) {
                          newParams[params[i]] = e.grid.getCellValue(e.row.index, params[i].toUpperCase());
                        }
                      }
                    }

                    if (flag) {//정상적으로 처리됐을 시, 점프메뉴로 이동
                      dews.ui.openMenu(
                        moveModule,
                        moveMenu,
                        true, newParams);
                    } else {
                      dews.alert("분기에 없는 파라미터가 입력되었습니다.", "warning");
                      console.log(errColumn + "값은 필수값입니다.");
                    }
                  }


                } else {
                  //추후 개선 : 이동할 대상 메뉴가 N개 존재할경우 > 컨텍스트로 구성합니다.
                }
              }
            });
          });
        }
      }
    },

    /*********************************************************************************************
     *  @desc     condition패널 체크하여 필수값에 컴포넌트별로 값셋팅하고 자동조회처리합니다. 마스터그리드 기준
     *
     *  @사용법   사용하고자하는 메뉴에서는
     *            scmJS.com.setAutoMenuOpenAfter(dewself); 선언만 하면됨
     *
     *            최초작성 노태현 연구원이 단계별로 개발
     *            개발2단계 - openMenu되는 페이지에서 자동조회처리 ex) setAutoMenuOpenAfter
     *                       condition패널 체크하여 필수값에 컴포넌트별로 값셋팅하고 자동조회처리합니다. 마스터그리드 기준
     *                     - 파라미터가 드롭다운리스트로 변경되는 경우 아예 컬럼과 관계없는 id로 설정되는 경우가 있어 이 부분은 제외
     *
     *********************************************************************************************/
    setAutoMenuOpenAfter: function(objSelf){
      if(objSelf.$content && objSelf.initialData){
        var ret = objSelf.$content.find('*[class^=dews-ui-]');
        $(ret).each(function (index, node) {
          $(Object.keys(objSelf.initialData)).each(function (i_index, i_item){
            if(node.id === "s_" + i_item){
              var target = objSelf[node.id];
              if (target != undefined) {
                var dewsControl = $(node).data('dews-control');
                if (
                  $(node).hasClass("dews-ui-dropdownlist") ||
                  $(node).hasClass("dews-ui-numerictextbox") ||
                  $(node).hasClass("dews-ui-maskedtextbox") ||
                  $(node).hasClass("dews-ui-datepicker") ||
                  $(node).hasClass("dews-ui-timepicker") ||
                  $(node).hasClass("dews-ui-monthpicker") ||
                  $(node).hasClass("dews-ui-datetimepicker") ||
                  $(node).hasClass("dews-ui-zipcodepicker") ||
                  $(node).hasClass("dews-ui-combobox")
                ) {
                  dewsControl.value(objSelf.initialData[i_item]);
                }
                else if ($(node).hasClass("dews-ui-textbox")) {
                  dewsControl.text(objSelf.initialData[i_item]);
                }
                else if (
                  $(node).hasClass("dews-ui-monthperiodpicker") ||
                  $(node).hasClass("dews-ui-weekperiodpicker")) {
                  dewsControl.setPeriod(objSelf.initialData[i_item], objSelf.initialData[i_item]);
                }
                else if ($(node).hasClass("dews-ui-periodpicker")) {
                  dewsControl.setStartDate(objSelf.initialData[i_item]);
                  dewsControl.setEndDate(objSelf.initialData[i_item]);
                }
                else if (
                  $(node).hasClass("dews-ui-codepicker") ||
                  $(node).hasClass("dews-ui-multicodepicker")) {
                  var obj = {};
                  if(node.id === "s_" + i_item){
                    obj[dewsControl.options.codeField] = objSelf.initialData[i_item];
                  }
                  else if((i_item.slice(-2) === 'nm' && node.id === "s_" + i_item.slice(0, i_item.length-2))){
                    obj[dewsControl.options.textField] = objSelf.initialData[i_item];
                  }
                  dewsControl.setData(obj, false);
                }
              }
            }
          });
        });
      }
    },

    /*********************************************************************************************
     *  @desc     dews-ui-textbox에서 발생하는 붙여넣기 이벤트에서 불필요한 공백 제거
     *
     *  @사용법   사용하고자하는 메뉴에서는
     *            scmJS.com.setZeroWithSpaceRemove(dewself); 선언만 하면됨
     *********************************************************************************************/
    setZeroWithSpaceRemove: function(self, fieldId){
      if(fieldId && self['$'+fieldId] && self['$'+fieldId].hasClass('dews-ui-textbox')){
        self['$'+fieldId].on('keydown',function(e){
          var content ='';
          if(e.currentTarget.value){
            content = e.currentTarget.value;
          }
          content = content.replace(/[\u200B-\u200D\uFEFF]/g, "");
          content = content.replace(/[\x00-\x09]|[\x0B-\x0C]|[\x0E-\x1F]/gi, "");
          self[e.currentTarget.id].text(content);
        });
      }else if(!fieldId){
        $(self.$content).find('.dews-ui-textbox').on('keydown',function(e){
          var content ='';
          if(e.currentTarget.value){
            content = e.currentTarget.value;
          }
          content = content.replace(/[\u200B-\u200D\uFEFF]/g, "");
          content = content.replace(/[\x00-\x09]|[\x0B-\x0C]|[\x0E-\x1F]/gi, "");
          self[e.currentTarget.id].text(content);
        });
      }
    }
  }

  //API
  module.api = {
    /*********************************************************************************************
     *  @desc   회사환경설정 값을 조회하여 리턴
     *  @return {Array} 환경설��� 배열
     *  @ex     var ma_format_list = scmJS.api.getCommonFormat();
     * ------------------------------------------------------------------------------------------*/
    getCommonFormat : function () {
      var rtn_data;
      dews.api.get(dews.url.getApiUrl("IM", "SCMCommonService", "SCMApiProvider_MA_COMMON_CODE_list"), {
        async: false,
        data: {}
      }).done(function (data) {
          rtn_data = data;
      }).fail(function (_xhr, _status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.'));
      });
      return rtn_data;
    },
    // refreshCommonFormat: function(){
    //   module.formatList = module.api.getCommonFormat();
    // },
    /*********************************************************************************************
     *  @desc   공통코드(MA_CODEDTL)를 가져옵니다.
     *  @param  {String} module_cd     - [필수]모듈코드
     *  @param  {String} field_cd_pipe - [필수]필드코드(multi)
     *  @return {Array}  해당 모듈/필드의 데이터를 배열(파라미터 부족등의 오류시 빈 배열)
     *  @ex     var objCodeDtl_SD = scmJS.api.getCodeData('SD', 'C00010|C00020');
     * ------------------------------------------------------------------------------------------*/
    getCodeData: function(module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
      var objCodeDtl = {};
      syscode_yn = (syscode_yn != undefined ? syscode_yn : null);
      base_yn    = (base_yn    != undefined ? base_yn    : null);
      foreign_yn = (foreign_yn != undefined ? foreign_yn : null);
      end_dt     = (end_dt     != undefined ? end_dt     : null);
      keyword    = (keyword    != undefined ? keyword    : null);
      if(!module_cd){
        console.error("scmJS - getCodeData 함수의 'module_cd' 파라미터가 부족합니다.");
        return [];
      } else if(!field_cd_pipe){
        console.error("scmJS - getCodeData 함수의 'field_cd_pipe' 파라미터가 부족합니다.");
        return [];
      } else{
        $.each(field_cd_pipe.split("|"), function (i, v) {
          if (v != null && v != "") {
            objCodeDtl[v] = [];
          }
        });
        dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
          async: false,
          data: {
            module_cd: module_cd, // 모듈
            field_cd_pipe: field_cd_pipe,   // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
            syscode_yn: syscode_yn,   // 시스템코드 유무(Y,N)
            base_yn: base_yn,   // 디폴트 코드구분(Y,N)
            foreign_yn: foreign_yn,   // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
            end_dt: end_dt,   // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
            keyword: keyword,    // 검색할 코드 또는 명
            base_dt: dews.date.format(new Date(), 'yyyyMMdd')
          }
        }).done(function (data) {
          if (data.length > 0) {
            $.each(data, function (i, obj) {
              objCodeDtl[obj.FIELD_CD].push(obj);
              tmpCdField = obj.FIELD_CD;
            });
          } else {
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
        return objCodeDtl;
      }
    },
    /*********************************************************************************************
     * @desc  출력기능 수행
     * @param {Object} self      [필수]해당 메뉴의 this(dewself/self)
     * @param {String} reportId  [필수]"R_SHPSDR00400_0"  (리포트 아이디)
     * @param {String} objectId  [필수]"R_SHPSDR00400_01" (출력물 아이디)
     * @param {String} reportParams  파라미터 객체 배열(서비스단에서 받을 파라미터 명과 값)
                                     - 넘길 파라미터 없을시, 위 3개만 넘김
                                     EX]
                                     var reportParams = [
                                       { name: 'plant_cd',   value: self.s_plant_cd.code() },
                                       { name: 'so_dt_from', value: self.s_so_dt.getStartDate() }
                                     ];
     * @ex    scmJS.api.excutePrint(self, reportParams, "R_SHPSDR00400_0", "R_SHPSDR00400_01");
     * ------------------------------------------------------------------------------------------*/
    excutePrint: function(self, reportId, objectId, reportParams){
      reportParams = reportParams || [];
      if(!self || !reportId || !objectId){
        console.error("scmJS - excutePrint 함수의 인자가 부족합니다.");
        return false;
      } else{
        var items = [];
        $(reportParams).each(function(idx, item) {
          items.push({
            RPRT_CD : reportId,
            OBJECT_CD : objectId,
            PARA_CD : item.name,
            PARA_TXT : item.value
          });
        });

        // 파라미터 저장 요청
        dews.api.post(dews.url.getApiUrl("CM", "printService", "setPrintParam"), {
          async : false,
          data : {
            reportCode : reportId,
            items : JSON.stringify(items)
          }
        }).done(function(data){
          /* 파라미터 키 리턴 */
          var parameterKey = data;
          if(!module.com.isNull(parameterKey)){
            if(typeof dews.app.print === 'function'){
              dews.app.print({ /* DRWebViewer 호출 */
                reportId: reportId,
                parameterKey: parameterKey,
                menuId: self.menu.id
              });
            } else{
              /* 인증토큰 */
              var authToken = JSON.parse(self.token).access_token;
              /* 출력물 정보 */
              var reportInfoUrl = window.location.protocol + "//" + window.location.host + "/api/CM/printService/getPrintFormList";
              /* DRWebViewer 호출 */
              location.href = 'GERP://" "' + authToken + '" "' + reportId + '" "' + reportInfoUrl + '" "' + parameterKey + '" "' + self.menu.id;
            }
          } else{
            dews.error("출력 요청에 실패하였습니다.");
          }
        }).fail(function(){
          dews.error("출력 요청에 실패하였습니다.");
        });
      }
    },
    /*********************************************************************************************
     *  @desc   단위와 기준단위에 따른 기준수량을 반환받음
     *  @param  {String} item_cd      [필수]품목코드
     *  @param  {Number} rqmnt_qt     [필수]소요수량
     *  @param  {String} unit_cd      [필수]단위
     *  @param  {String} std_unit_cd  [필수]기준단위
     *  @return {Number} 기준수량. 품목단위환산(CI/MA)에 등록된 데이터가 없다면 null 반환
     *  @ex     var std_unit_qt = scmJS.api.getStdUnitQt('100000', 1000, 'G', 'KG');
     * ------------------------------------------------------------------------------------------*/
    getStdUnitQt: function(item_cd, rqmnt_qt, unit_cd, std_unit_cd){
      var item_qt = null;
      if(!item_cd || module.com.isNull(rqmnt_qt) || !unit_cd || !std_unit_cd){
        console.error("scmJS - getStdUnitQt 함수의 인자가 부족합니다.");
      } else{
        dews.api.get(dews.url.getApiUrl("IM", "SCMCommonService", "getChanged_Unit_Qt"), {
          async: false,
          data: {
            item_cd: item_cd, // 품목코드
            source_qt: rqmnt_qt, // 소요수량
            source_unit_cd: unit_cd, // 단위
            target_unit_cd : std_unit_cd // 기준단위
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        }).done(function (data) {
          if (data) {
            item_qt = data;
          } else{
            item_qt = null;
          }
        });
      }
      return item_qt;
    },
    /*********************************************************************************************
     *  @desc   일자/통화/환율타입과 일치하는 환율을 반환 - 해당날짜 없을시 가장 가까운 날짜의 환율
     *  @param  {string} std_dt       [필수]환율 날짜 - Date형 또는 String(yyyyMMdd)
     *  @param  {string} std_crnc_cd  [필수]통화코드(KRW/USD/..)
     *  @param  {string} exrt_rt_fg   [필수]환율타입(1:표준환율, 2:사업계획환율, 3:거래처계약환율, 4:연결환율),
     *  @param  {string} trgt_crnc_cd 타겟통화코드(KRW/USD/..)
     *  @param  {string} set_zero_yn  조회된 환율이 없을 경우 기본값 '1'로 셋팅여부(Y/N)
     *  @return {Number} 환율
     *  @ex     var exrt_rt = scmJS.api.getExrt(self.s_dt.value(), self.s_exch_cd.value(), self.s_exchrtp_cd.value());
     * ------------------------------------------------------------------------------------------*/
    getExrt: function(std_dt, std_crnc_cd, exrt_rt_fg, trgt_crnc_cd, set_zero_yn){
      set_zero_yn  = module.com.isNull(set_zero_yn)  ? 'Y' : set_zero_yn;
      trgt_crnc_cd = module.com.isNull(trgt_crnc_cd) ? ''  : trgt_crnc_cd;
      var exrt_rt  = 1;

      if(!std_dt || !std_crnc_cd || !exrt_rt_fg){
        console.error("scmJS - getExrt 함수의 인자가 부족합니다.");
      } else{
        // 환율 날짜 파라미터가 Date형식이면, 변환
        std_dt = (std_dt.constructor.name == 'Date' ? dews.date.format(std_dt, 'yyyyMMdd') : std_dt);
        dews.api.get(dews.url.getApiUrl('IM', 'SCMCommonService', 'SCMApiProvider_getExrtRt'), {
          async: false,
          data: {
            exrt_rt_fg  : exrt_rt_fg,
            std_dt      : std_dt,
            std_crnc_cd : std_crnc_cd,
            trgt_crnc_cd: trgt_crnc_cd,
            set_zero_yn : set_zero_yn
          }
        }).done(function (data) {
          if(data.length > 0){ // 조건에 맞는 제일 최근 환율 가져옴
            exrt_rt = module.com.toNumber(data[0].STD_EXRT_RT);
          } else{ // 가져온 데이터 없을시 환율 1
            if(set_zero_yn){
              exrt_rt = 1;
              console.error("scmJS - getExrt: 환율 정보를 가져오지 못해 1로 설정됩니다.");
            } else{
              exrt_rt = null;
            }
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || "환율 정보를 가져오는데 실패했습니다.");
        });
        return exrt_rt;
      }
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc           화면상의 모든컨트롤을 초기화(CLEAR)합니다.
     *  @ex             maScmJS.api.clearPanel(self)
     *  @memo           컨트롤초기화
     * --------------------------------------------------------------------------------------------*/
    clearPanel: function (self) {
      var ret = self.$content.find(".dews-form-panel li input[class|='dews-ui'], "
        + ".dews-form-panel li select[class|='dews-ui'], "
        + ".dews-form-panel li span[class|='dews-ui'], "
        + ".dews-form-panel li textarea[class|='dews-ui']")
      $(ret).each(function (index, node) {
        var target = self[node.id];
        if (target != undefined) {
          var dewsControl = $(node).data('dews-control');
          if (
            $(node).hasClass("dews-ui-dropdownlist") ||
            $(node).hasClass("dews-ui-numerictextbox") ||
            $(node).hasClass("dews-ui-maskedtextbox") ||
            $(node).hasClass("dews-ui-datepicker") ||
            $(node).hasClass("dews-ui-timepicker") ||
            $(node).hasClass("dews-ui-monthpicker") ||
            $(node).hasClass("dews-ui-datetimepicker") ||
            $(node).hasClass("dews-ui-zipcodepicker") ||
            $(node).hasClass("dews-ui-combobox")
          ) {
            dewsControl.value('');
            if (typeof (dewsControl.text) == "function") {
              dewsControl.text('');
            }
          }
          else if ($(node).hasClass("dews-ui-textbox")) {
            dewsControl.text('');
          }
          else if (
            $(node).hasClass("dews-ui-monthperiodpicker") ||
            $(node).hasClass("dews-ui-weekperiodpicker")) {
            var start = "", end = "";
            dewsControl.setPeriod(start, end);
          }
          else if ($(node).hasClass("dews-ui-periodpicker")) {
            var start = "", end = "";
            dewsControl.setStartDate(start);
            dewsControl.setEndDate(end);
          }
          else if ($(node).hasClass("dews-ui-codepicker")) {
            var obj = {};
            obj[dewsControl.options.codeField] = '';
            obj[dewsControl.options.textField] = '';
            dewsControl.setData(obj, false);
          }
          else if ($(node).hasClass("dews-ui-multicodepicker")) {
            dewsControl.clear(false);
          }
          else if ($(node).hasClass("dews-ui-checkbox")) {
            dewsControl.target[0].checked = false;
          }
          else if ($(node).hasClass("dews-ui-file")) {
            dewsControl.deleteFile();
          }
        }
      });
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc           해당ContainerItem 하위의 dews-form-panel의 모든컨트롤을 초기화(CLEAR)합니다.
     *  @ex             maScmJS.api.clearTabPanel(self, self.$containerItemAct --> form-panel의 상위 containerItem ID)
     *  @memo           컨트롤초기화
     * --------------------------------------------------------------------------------------------*/
    clearTabPanel: function (self, panel) {
      var ret = panel.find(".dews-form-panel li input[class|='dews-ui'], "
        + ".dews-form-panel li select[class|='dews-ui'], "
        + ".dews-form-panel li span[class|='dews-ui'], "
        + ".dews-form-panel li textarea[class|='dews-ui']")
      $(ret).each(function (index, node) {
        var target = self[node.id];
        if (target != undefined) {
          var dewsControl = $(node).data('dews-control');
          if (
            $(node).hasClass("dews-ui-dropdownlist") ||
            $(node).hasClass("dews-ui-numerictextbox") ||
            $(node).hasClass("dews-ui-maskedtextbox") ||
            $(node).hasClass("dews-ui-datepicker") ||
            $(node).hasClass("dews-ui-timepicker") ||
            $(node).hasClass("dews-ui-monthpicker") ||
            $(node).hasClass("dews-ui-datetimepicker") ||
            $(node).hasClass("dews-ui-zipcodepicker") ||
            $(node).hasClass("dews-ui-combobox")
          ) {
            dewsControl.value('');
            if (typeof (dewsControl.text) == "function") {
              dewsControl.text('');
            }
          }
          else if ($(node).hasClass("dews-ui-textbox")) {
            dewsControl.text('');
          }
          else if (
            $(node).hasClass("dews-ui-monthperiodpicker") ||
            $(node).hasClass("dews-ui-weekperiodpicker")) {
            var start = "", end = "";
            dewsControl.setPeriod(start, end);
          }
          else if ($(node).hasClass("dews-ui-periodpicker")) {
            var start = "", end = "";
            dewsControl.setStartDate(start);
            dewsControl.setEndDate(end);
          }
          else if ($(node).hasClass("dews-ui-codepicker")) {
            var obj = {};
            obj[dewsControl.options.codeField] = '';
            obj[dewsControl.options.textField] = '';
            dewsControl.setData(obj, false);
          }
          else if ($(node).hasClass("dews-ui-multicodepicker")) {
            var arr = [];
            for (var i = 0; i < dt.length; i++) {
              var obj = {};
              obj[dewsControl.options.codeField] = dt[i].code;
              obj[dewsControl.options.textField] = dt[i].name;
              arr.push(obj);
            }
            dewsControl.setData(arr);
          }
          else if ($(node).hasClass("dews-ui-checkbox")) {
            dewsControl.target[0].checked = false;
          }
        }
      });
    },
    /**
     * 환경설정 데이터 가져오기 (CI)
     * @example var ret = COMMON.getCiCtrlConfig("IA", "P00540");
     * @param {*} module_cd : 모듈
     * @param {*} ctrl_cd : 구분
     * @return {*} 년월
     */
    getCiCtrlConfig: function(module_cd, ctrl_cd) {
      var ret = null;

      dews.api.get(dews.url.getApiUrl("CM", "CommonCtrlConfigService", "common_ci_ctrlconfig_string"), {
        async: false,
        data: {
          module_cd: module_cd,
          ctrl_cd: ctrl_cd,
          use_yn: 'Y'
        }
      }).done(function (data) {
        if (data) {
          ret = data;
        }
      });

      return ret;
    },

    /**
     * 환경설정 데이터 가져오기 (MA)
     * @example var ret = COMMON.getMaCtrlConfig("IA", "P00540");
     * @param {*} module_cd : 모듈
     * @param {*} ctrl_cd : 구분
     * @return {*} 년월
     */
    getMaCtrlConfig: function(module_cd, ctrl_cd) {
      var ret = null;

      dews.api.get(dews.url.getApiUrl("CM", "CommonCtrlConfigService", "common_ma_ctrlconfig_string"), {
        async: false,
        data: {
          module_cd: module_cd,
          ctrl_cd: ctrl_cd,
          use_yn: 'Y'
        }
      }).done(function (data) {
        if (data) {
          ret = data;
        }
      });

      return ret;
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc           첨부파일 커스텀 도움창 호출
     *  @ex             maScmJS.api.FILE_UPLOAD(file_dc)
     *  @param          file_dc : CM_FILE_INFO 테이블 PK (FILE_DC) 로 INSERT 할 데이터
     *  @param          uploaduse : 업로드 기능 사용 여부를 설정합니다. (true : 사용  false : 미사용)
     *  @param          downloaduse : 다운로드 기능 사용 여부를 설정합니다. (true : 사용  false : 미사용)
     * --------------------------------------------------------------------------------------------*/
    FILE_UPLOAD: function (file_dc, uploaduse, downloaduse) {
      return new Promise(function (resolve, reject) {
        var dialog;
        var initData;
        initData = {
          file_dc: file_dc,
          uploaduse: uploaduse,
          downloaduse:downloaduse
        };
        dialog = dews.ui.dialog("H_MA_FILE_UPLOAD_C",
          {
            url: "/codehelp/MA/H_MA_FILE_UPLOAD_C",
            title: '첨부파일등록',
            buttons: 'applyAndClose',
            height: '250px',
            initData: initData,
            ok: function (data) {
              resolve(data); // 적용버튼 클릭시 등록된 파일정보를 리턴합니다.
            }
          });
        dialog.open();
      });
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc       현재년월일 or 파라미터Date의 년월일 구하기
    *  @return     yyyyMMdd
    *  @call       getToday()
    * ------------------------------------------------------------------------------------------*/
    getToday: function (date) {
      if (typeof (date) == "string") {
        return date;
      }
      else if (typeof (date) == "number") {
        return String(date);
      }
      else {
        if (date) {
          return date.getFullYear().toString() + (date.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
            + (date.getDate()).toString().replace(/^(\d)$/, "0$1");
        } else {
          var today = new Date();
          return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
            + (today.getDate()).toString().replace(/^(\d)$/, "0$1");
        }
      }
    },
    /* --------------------------------------------------------------------------------------------
    *  @no
    *  @desc           캘린더 정보 조회
    *  @ex             get_calender_all_list()
    *  @memo           캘린더 정보 조회
    * --------------------------------------------------------------------------------------------*/
    /* --------------------------------------------------------------------------------------------
    *  @return         전체 캘린터 일자
    * ------------------------------------------------------------------------------------------*/
    get_calender_all_list: function (clnd_tp) {
      var calendarData;
      //캘린더 일자정보 리스트\
      dews.api.get(dews.url.getApiUrl("MA", "MaCommonService", dews.string.format('MAApiProvider_calendar_list_ALL')), {
        async: false,
        data: {clnd_tp: clnd_tp}
      }).done(function (data) {
        calendarData = data;
      }).fail(function (xhr, status, error) {
        console.error(error);
        setTimeout(function () {
          dews.error('오류가 발생하였습니다.');
        }, 200);
      });

      return calendarData;
    },
    //*********************************************/
    //* 입력된 일자의 캘린더 존재여부               */
    //*********************************************/
    exist_calender: function (calendar, dt, clnd_cd) {
      if (typeof (dt) != "string") {
        dt = this.getToday(dt);
      }
      var DATE_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == dt });

      return DATE_INFO.length > 0 ? true : false;
    },
    //*********************************************/
    //* 시작일과 종료일로 기간을 계산합니다. */
    //*********************************************/
    get_calendar_duration: function (calendar, start_dt, end_dt, clnd_cd, grid) {
      var day_count = 0;
      if (!start_dt || !end_dt) {
        return undefined;
      }

      if (calendar && calendar.length > 0) {
        if (typeof (start_dt) != "string") {
          start_dt = this.getToday(start_dt);
        }
        if (typeof (end_dt) != "string") {
          end_dt = this.getToday(end_dt);
        }

        var start_yyyy = Number(start_dt.substring(0, 4));
        var end_yyyy = Number(end_dt.substring(0, 4));

        var START_INFO = null;
        var END_INFO = null;
        var YEAR_LAST_INFO = null;
        if (start_yyyy == end_yyyy) {
          // 시작년도와 종료년도가 같을때
          START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == start_dt });
          END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == end_dt });
          if (END_INFO.length > 0 && START_INFO.length > 0) {
            day_count = END_INFO[0].ACMTL_BWRK_DY - START_INFO[0].ACMTL_BWRK_DY + 1;
          }
        } else if (end_yyyy - start_yyyy == 1) {
          // 시작년도와 종료년도가 1년차이일때 (시작년도:2020, 종료년도:2021)
          YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(start_yyyy).concat("1231") });
          START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == start_dt });
          END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == end_dt });
          if (YEAR_LAST_INFO.length > 0 && END_INFO.length > 0 && START_INFO.length > 0) {
            day_count = YEAR_LAST_INFO[0].ACMTL_BWRK_DY - START_INFO[0].ACMTL_BWRK_DY + END_INFO[0].ACMTL_BWRK_DY + 1;
          }

          if (YEAR_LAST_INFO.length == 0) {
            console.error("[scmJS.api.get_calendar_duration] YEAR_LAST_INFO == null");
            dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
              .done(function () {
                if (grid) {
                  grid.setFocus();
                }
              });
          }
          else if (START_INFO.length == 0) {
            console.error("[scmJS.api.get_calendar_duration] START_INFO == null");
            dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
              .done(function () {
                if (grid) {
                  grid.setFocus();
                }
              });
          }
          else if (END_INFO.length == 0) {
            console.error("[scmJS.api.get_calendar_duration] END_INFO == null");
            dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
              .done(function () {
                if (grid) {
                  grid.setFocus();
                }
              });
          }
        } else {
          // 시작년도와 종료년도가 1년 이상 차이일때 (시작년도:2018, 종료년도:2022)
          for (var i = start_yyyy + 1; i < end_yyyy; i++) {
            // 2019, 2020, 2021의 워킹데이를 더합니다.
            YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(i).concat("1231") });
            if (YEAR_LAST_INFO.length) {
              day_count += YEAR_LAST_INFO[0].ACMTL_BWRK_DY;
            }
          }

          // 2018, 2022년도 워킹데이터를 구합니다.
          YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(start_yyyy).concat("1231") });
          START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == start_dt });
          END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == end_dt });
          if (YEAR_LAST_INFO.length > 0 && END_INFO.length > 0 && START_INFO.length > 0) {
            day_count += YEAR_LAST_INFO[0].ACMTL_BWRK_DY - START_INFO[0].ACMTL_BWRK_DY + END_INFO[0].ACMTL_BWRK_DY + 1;
          } else {
            if (YEAR_LAST_INFO.length == 0) {
              console.error("[scmJS.api.get_calendar_duration] YEAR_LAST_INFO == null");
              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                .done(function () {
                  if (grid) {
                    grid.setFocus();
                  }
                });
            }
            else if (START_INFO.length == 0) {
              console.error("[scmJS.api.get_calendar_duration] START_INFO == null");
              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                .done(function () {
                  if (grid) {
                    grid.setFocus();
                  }
                });
            }
            else if (END_INFO.length == 0) {
              console.error("[scmJS.api.get_calendar_duration] END_INFO == null");
              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                .done(function () {
                  if (grid) {
                    grid.setFocus();
                  }
                });
            }
          }
        }

      }

      return day_count;
    },
    //*********************************************/
    //* 시작일과 소요기간으로 종료일자를 계산합니다. */
    //* returnType : (String)'20210713' (PipeString)'2021-07-13' (Date) DateType - Tue Jul 13 2021 09:00:00 GMT+0900 (대한민국 표준시)
    //*********************************************/
    get_calendar_end_dt: function (calendar, start_dt, duration, clnd_cd, returnType, grid) {
      var end_dt = null;
      if (!duration || !start_dt) {
        return undefined;
      }

      if (calendar && calendar.length > 0) {
        if (typeof (start_dt) != "string") {
          start_dt = this.getToday(start_dt);
        }

        var start_yyyy = Number(start_dt.substring(0, 4));
        var START_INFO = null;
        var YEAR_LAST_INFO = null;
        var remainingTime = duration; // 잔여일수
        var END_INFO = null;


        while (true) {
          if (!START_INFO) {
            START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == start_dt });
          } else {
            START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(start_yyyy).concat("0101") });
          }
          YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(start_yyyy).concat("1231") });
          if (YEAR_LAST_INFO.length > 0 && START_INFO.length > 0) {
            duration = remainingTime;
            remainingTime = remainingTime - (YEAR_LAST_INFO[0].ACMTL_BWRK_DY - START_INFO[0].ACMTL_BWRK_DY + 1);
            if (remainingTime <= 0) {
              // 해당년도 내에서 종료일자 추출이 가능합니다.
              END_INFO = calendar.filter(function (v) {
                return v.CLND_TP == clnd_cd && v.CLND_DT.substring(0, 4) == start_yyyy &&
                  v.ACMTL_BWRK_DY >= START_INFO[0].ACMTL_BWRK_DY + duration - 1
              });
              if (END_INFO.length == 0) {
                console.error("[scmJS.api.get_calendar_end_dt] END_INFO == null");
                dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                  .done(function () {
                    if (grid) {
                      grid.setFocus();
                    }
                  });
              } else {
                end_dt = END_INFO[0].CLND_DT;
              }
              break;
            } else {
              start_yyyy++;
            }
          } else {
            if (YEAR_LAST_INFO.length == 0) {
              console.error("[scmJS.api.get_calendar_end_dt] YEAR_LAST_INFO == null");
              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                .done(function () {
                  if (grid) {
                    grid.setFocus();
                  }
                });
            }
            else if (START_INFO.length == 0) {
              console.error("[scmJS.api.get_calendar_end_dt] START_INFO == null");
              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                .done(function () {
                  if (grid) {
                    grid.setFocus();
                  }
                });
            }
            break;
          }
        }
      }
      if (returnType == "PipeString") {
        if (end_dt && end_dt.length == 8) {
          return end_dt.substring(0, 4) + '-' + end_dt.substring(4, 6) + '-' + end_dt.substring(6, 8);
        }
      }
      else if (returnType == "Date") {
        if (end_dt && end_dt.length == 8) {
          return new Date(end_dt.substring(0, 4) + '-' + end_dt.substring(4, 6) + '-' + end_dt.substring(6, 8));
        }
      }
      return end_dt;
    },

    //*********************************************/
    //* 종료일과 소요기간으로 시작일자를 계산합니다.
    //* 종료일이 시작일자 이전으로 세팅된경우 소요기간만큼 시작일을 앞당기도록합니다.
    //* returnType : (String)'20210713' (PipeString)'2021-07-13' (Date) DateType - Tue Jul 13 2021 09:00:00 GMT+0900 (대한민국 표준시)
    //*********************************************/
    get_calendar_start_dt: function (calendar, end_dt, duration, clnd_cd, returnType, grid) {
      var start_dt = null;
      if (!duration || !end_dt) {
        return undefined;
      }

      if (calendar && calendar.length > 0) {
        if (typeof (start_dt) != "string") {
          end_dt = this.getToday(end_dt);
        }

        var end_yyyy = Number(end_dt.substring(0, 4));
        var ori_end_yyyy = Number(end_dt.substring(0, 4));
        var YEAR_LAST_INFO = null;
        var remainingTime = duration; // 잔여일수
        var END_INFO = null;
        var START_INFO = null;

        while (true) {
          if (!END_INFO) {
            END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == end_dt });
          } else {
            END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(end_yyyy).concat("0101") });
          }
          YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(end_yyyy).concat("1231") });
          if (YEAR_LAST_INFO.length > 0 && END_INFO.length > 0) {
            if (ori_end_yyyy == end_yyyy) {
              remainingTime = remainingTime - END_INFO[0].ACMTL_BWRK_DY - 1;

              if (remainingTime <= 0) {
                // 해당년도 내에서 시작일자 추출이 가능합니다.
                START_INFO = calendar.filter(function (v) {
                  return v.CLND_TP == clnd_cd && v.CLND_DT.substring(0, 4) == end_yyyy && v.BWRK_FG_CD != '3' &&
                    v.ACMTL_BWRK_DY <= Math.abs(remainingTime)
                });
                if (START_INFO.length == 0) {
                  console.error("[scmJS.api.get_calendar_start_dt] START_INFO == null");

                  dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                    .done(function () {
                      if (grid) {
                        grid.setFocus();
                      }
                    });

                } else {
                  start_dt = START_INFO[START_INFO.length - 1].CLND_DT;
                }
                break;
              } else {
                end_yyyy--;
              }
            } else {
              remainingTime = YEAR_LAST_INFO[0].ACMTL_BWRK_DY - remainingTime;
              if (remainingTime <= 0) {
                end_yyyy--;
              } else {
                START_INFO = calendar.filter(function (v) {
                  return v.CLND_TP == clnd_cd && v.CLND_DT.substring(0, 4) == end_yyyy && v.BWRK_FG_CD != '3' &&
                    v.ACMTL_BWRK_DY <= remainingTime
                });
                if (START_INFO.length == 0) {
                  console.error("[scmJS.api.get_calendar_start_dt] START_INFO == null");
                  dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                    .done(function () {
                      if (grid) {
                        grid.setFocus();
                      }
                    });
                } else {
                  start_dt = START_INFO[START_INFO.length - 1].CLND_DT;
                }
                break;
              }
            }

          } else {
            if (YEAR_LAST_INFO.length == 0) {
              console.error("[scmJS.api.get_calendar_start_dt] YEAR_LAST_INFO == null");
              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                .done(function () {
                  if (grid) {
                    grid.setFocus();
                  }
                });
            }
            else if (END_INFO.length == 0) {
              console.error("[scmJS.api.get_calendar_start_dt] START_INFO == null");
              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                .done(function () {
                  if (grid) {
                    grid.setFocus();
                  }
                });
            }
            break;
          }
        }
      }
      if (returnType == "PipeString") {
        if (start_dt && start_dt.length == 8) {
          return start_dt.substring(0, 4) + '-' + start_dt.substring(4, 6) + '-' + start_dt.substring(6, 8);
        }
      }
      else if (returnType == "Date") {
        if (start_dt && start_dt.length == 8) {
          return new Date(start_dt.substring(0, 4) + '-' + start_dt.substring(4, 6) + '-' + start_dt.substring(6, 8));
        }
      }
      return start_dt;
    },


    /* --------------------------------------------------------------------------------------------
     *  @no
     *  @desc           환율 정보 로드
     *  @ex             getExrt_rt(환종(통화), 기준일자 )
     *  @memo           기준일자가 있으면 해당 기준일자의 최신값, 기준일자가 없으면 오늘일자 최신값
     * --------------------------------------------------------------------------------------------
     *  @exch_cd        환종
     *  @dt             기준일자
     * --------------------------------------------------------------------------------------------
     *  @return         환율
     * ------------------------------------------------------------------------------------------*/
    getExrt_rt: function (exch_cd, dt) {
      var exrt_rt = null;
      if (!dt) {
        dt = this.getToday();
      }
      dews.api.get(dews.url.getApiUrl("MA", "MaCommonService", "MAApiProvider_Exch_Rt"), {
        async: false,
        data: {
          exch_cd: exch_cd,
          dt: dt
        }
      }).done(function (data) {
        if (data.length > 0) {
          exrt_rt = data[0].STD_EXRT_RT;
        } else {
          exrt_rt = 1;
        }
      }).fail(function (xhr, status, error) {
        dews.error(error || '작업이 실패하였습니다.');
      });

      return exrt_rt;
    },
    /*********************************************************************************************
     *  @desc   '메뉴별부가정보등록' 메뉴의 등록된 정보를 리턴받아 module.menuDynamicInfo에 세팅.
     *  @param  {String} aply_module_cd     [필수] 모듈코드
     *  @ex     scmJS.api.initMenuDynamicInfo('SD');
     * ------------------------------------------------------------------------------------------*/
    initMenuDynamicInfo: function(aply_module_cd){
      if(module.com.isNull(aply_module_cd)){ // 파라미터 필수값 체크.
        console.error("scmJS - initMenuDynamicInfo: 필수 파라미터가 입력되지 않았습니다.");
      } else{
        dews.api.get(dews.url.getApiUrl("MA", "MaMenuAddInfoService", "menuAddInfo_list"), {
          async: false,
          data: {
            aply_module_cd : aply_module_cd
          }
        }).done(function (data) { // 메뉴별 부가정보등록에 등록된 리스트 조회.
          if(data && Array.isArray(data) && data.length > 0){
            // module.menuDynamicInfo = data[0];
            module.menuDynamicInfo = data;
          }
        }).fail(function(xhr, status, error){
          console.error("scmJS - initMenuDynamicInfo: 메뉴별부가정보 조회에 실패했습니다.");
        });
      }
    },
    /*********************************************************************************************
     *  @desc   '메뉴별부가정보등록' 메뉴의 등록된 정보를 리턴받아 module.menuDynamicInfo에 세팅.
     *  @param  {String} aply_module_cd     [필수] 모듈코드
     *  @ex     scmJS.api.selectDynamicFields({ APLY_MODULE_CD:'SD', MENU_ID:'SDCORT00100', TABLE_ID: 'SD_SODTYPE_MST' });
     * ------------------------------------------------------------------------------------------*/
    selectDynamicFields: function(filter){ // filter: { APLY_MODULE_CD, MENU_ID, TABLE_ID, BIZ_DOC_CTGRY_CD, DOC_TP_CD }
      var result = [];
      filter = filter || {};

      // 파라미터 필수값 체크.
      if(!filter.hasOwnProperty('APLY_MODULE_CD') || module.com.isNull(filter.APLY_MODULE_CD)){
        console.error("scmJS - selectDynamicFields: 필수 파라미터가 입력되지 않았습니다(APLY_MODULE_CD)");
      }
      else{
        dews.api.get(dews.url.getApiUrl("MA", "MaMenuAddInfoService", "menuAddInfo_list"), {
          async: false,
          data: {
            aply_module_cd: filter.APLY_MODULE_CD,
            menu_id: module.com.replaceNull(filter.MENU_ID, ''),
            table_id: module.com.replaceNull(filter.TABLE_ID, ''),
            biz_doc_ctgry_cd: module.com.replaceNull(filter.BIZ_DOC_CTGRY_CD, ''),
            doc_tp_cd: module.com.replaceNull(filter.DOC_TP_CD, '')
          }
        }).done(function (data) { // 메뉴별 부가정보등록에 등록된 리스트 조회.
          if(data){
            result = data;
          }
        }).fail(function(xhr, status, error){
          console.error("scmJS - selectDynamicFields: 메뉴별부가정보 조회에 실패했습니다.");
        });
      }
      return result;
    },
    /*********************************************************************************************
     *  @desc   사용자별세부권한 리스트 조회
     *  @param  {String} table_nm     [필수] 테이블명
     *  @ex     scmJS.api.getAuthList('PS_PROJ_MST');
     * ------------------------------------------------------------------------------------------*/
     getAuthList: function(table_nm){
      var authList = null;

      dews.api.get(dews.url.getApiUrl("MA", "MaCommonService", "MAApiProvider_get_auth_list"), {
        async: false,
        data: {
          table_nm: table_nm
        }
      }).done(function (data) {
        authList = data;
      }).fail(function(xhr, status, error){
        setTimeout(function() {
          dews.error('오류가 발생했습니다.');
        }, 0)
        console.error(error || "scmJS - getAuthList: 사용자별세부권한 리스트 조회에 실패했습니다.");
      });

      if (authList == 'DETAIL_AUTH_NOT_USED') {
        authList = null;
      } else if (!authList) {
        authList = this.getUUID();
      }

      return authList;
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc           36자리 난수키를 생성한다.
    *  @ex             scmJS.api.getUUID()
    *  @call           getUUID()
    * --------------------------------------------------------------------------------------------*/
    getUUID: function () {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 3 | 8);
        return v.toString(16);
      });
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc           현재년월일로부터 몇달후, 몇달전 년월일 구하기 (몇달인지는 파라미터로 세팅)
    *  @ex             scmJS.api.getTodayMonAdd(-1)
    *  @call           getUUID()
    * --------------------------------------------------------------------------------------------*/
    getTodayMonAdd: function (mon) {
      var today = new Date();
      today.setMonth(today.getMonth() + mon);
      return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
        + (today.getDate()).toString().replace(/^(\d)$/, "0$1");
    },
    /*********************************************************************************************
      *  @desc   첨부파일키(FILE_DC), 전자결재키(ATHZ_DOC_CD)를 업데이트합니다.
      *  @param  {String} func_nm     [필수] 서비스함수명
      *  @param  {Object} func_data   [필수] 파라미터   {
      *                                                 company_cd : self.user.companycd,
      *                                                 pjt_no : self.grid.getCellValue(self.grid.select(), "PJT_NO")
      *                                                }
      *  @ex     scmJS.api.UUID_UPDATE('PS_PROJ_MST');
      * ------------------------------------------------------------------------------------------*/
     UUID_UPDATE: function (func_nm, func_data) {
      var UUID = null;
      if (!func_nm) {
        console.log('func_nm이 누락되었습니다. "예:PS_PROJ_MST_FILE_DC_UPDATE"');
      } else if (!func_data) {
        console.log('func_data가 누락되었습니다. "예:{company_cd : self.user.company_cd, pjt_no : self.grid.getCellValue(self.grid.select(), "PJT_NO")}"');
      } else {
        dews.api.post(dews.url.getApiUrl("MA", "MACommonUUID_Service", func_nm), {
          async: false,
          data: func_data
        }).done(function (resultData) {
          if (resultData.SUCCESS) {
            UUID = resultData.MSG;
          } else {
            setTimeout(function () {
              dews.alert(resultData.MSG, { icon: 'warning' });
            }, 200);
          }
        }).fail(function (xhr, status, error) {
          setTimeout(function () {
            dews.error('오류가 발생하였습니다.');
          }, 200);
          console.error(error);
        });
      }
      return UUID;
    },
    left: function (str, length) {
      var new_str = String(str);
      if (length <= 0) return "";
      else if (new_str.length <= length) return new_str;
      else return new_str.substring(0, length);
    },
    /* --------------------------------------------------------------------------------------------
      *  @desc       right 함수 작성
      *  @return     str
      *  @call       right(str, length)
      * ------------------------------------------------------------------------------------------*/
    right: function (str, length) {
      var new_str = String(str);
      if (length <= 0) return "";
      else if (new_str.length <= length) return new_str;
      else return new_str.substring(new_str.length - length, new_str.length);
    },
    /* --------------------------------------------------------------------------------------------
      *  @desc       mid 함수 작성
      *  @return     str
      *  @call       mid(str, start, length)
      * ------------------------------------------------------------------------------------------*/
    mid: function (str, start, length) {
      var new_str = String(str);
      if (length <= 0) return "";
      else if (new_str.length < start) return "";
      else if (new_str.length <= length) return new_str;
      return module.api.left(module.api.right(new_str, new_str.length - start), length);
    },
    replaceAll: function (str, searchStr, replaceStr) {
      return str.split(searchStr).join(replaceStr);
    },


    /**
     * 이메일
     * @example VALIDATE.isEmail('genius@douzone.com');
     * @param {*} value: 이메일주소
     * @return {*} boolean
     */
    isEmail: function (value) {
      try {
        var regExp = /[0-9a-zA-Z][_0-9a-zA-Z-]*@[_0-9a-zA-Z-]+(\.[_0-9a-zA-Z-]+){1,2}$/;

        if (this.isNotNull(value)) {
          if (this.nvl(value.match(regExp), '') == '') {
            dews.ui.snackbar.warning('이메일이 잘못되었습니다.', 'warning');
            return false;
          } else {
            return true;
          }
        } else {
          return true;
        }
      } catch (error) {
        return false;
      }
    },
    /* --------------------------------------------------------------------------------------------
      *  @desc       숫자만 추출하기.
      *  @return     '123'
      *  @call       scmJS.api.replaceOnlyNumber('_1a23')
      * ------------------------------------------------------------------------------------------*/
    replaceOnlyNumber: function (str) {
      var res;
      if(str == null) {
        return str;
      }
      res = String(str).replace(/[^0-9]/g, "");
      return res;
    },
    /**
     * 정수만입력가능(keyDown이벤트에서 사용가능합니다.)
     * @example scmJS.api.onlyNumber(e, exceptionList);
     * @param {*} event: keyDown이벤트
     * @param {*} exceptionList : 추가로 입력가능한 예외키코드
     *                          : var exceptionList = [];
                                  exceptionList.push('188'); -> 콤마
      * @return {*} boolean
      */
    onlyNumber: function (event, exceptionList) {
      //event = event || window.event;

      console.log('event.key' + '/ ' + event.key);
      console.log('event.which' + '/ ' + event.which);
      console.log('event.keyCode' + '/ ' + event.keyCode);

      var keyID = (event.which) ? event.which : event.keyCode;

      if (exceptionList) {
        for (var i = 0; i < exceptionList.length; i++) {
          if (keyID == exceptionList[i]) {
            return;
          }
        }
      }

      if ((keyID >= 35 && keyID <= 36) //35:HOME, 36:END
        //|| (event.ctrlKey == true && (keyID == 67 ||  keyID == 86) ) Copy&Paste
        || (keyID >= 48 && keyID <= 57)   //0~9
        || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
        || (keyID >= 37 && keyID <= 40)   //방향키
        || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46/*|| keyID == 109 || keyID == 189*/ //8:백스페이스, 13:Enter, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
      )
        return;
      else {
        event.preventDefault();
        return;
      }
    },

    removeNotNumber: function (event) {
      //event = event || window.event;

      console.log('event.key' + '/ ' + event.key);
      console.log('event.which' + '/ ' + event.which);
      console.log('event.keyCode' + '/ ' + event.keyCode);

      var keyID = (event.which) ? event.which : event.keyCode;
      if ((keyID >= 35 && keyID <= 36) //35:HOME, 36:END
        || (event.ctrlKey == true && (keyID == 67 || keyID == 86)) //Copy&Paste
        || (keyID >= 48 && keyID <= 57)   //0~9
        || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
        || (keyID >= 37 && keyID <= 40)   //방향키
        || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46 /*|| keyID == 109 || keyID == 189*/ //8:백스페이스, 13:Enter, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
      )
        return;
      else {

        console.log('removeNotNumber' + '/ ' + event.target.value + '/ ' + event.target.value.replace(/[^0-9]/g, ""));
        event.target.value = event.target.value.replace(/[^0-9]/g, "");
      }
    },

    onlyPhoneNumber: function (event) {
      //event = event || window.event;

      console.log('event.key' + '/ ' + event.key);
      console.log('event.which' + '/ ' + event.which);
      console.log('event.keyCode' + '/ ' + event.keyCode);

      var keyID = (event.which) ? event.which : event.keyCode;
      if ((keyID >= 35 && keyID <= 36) //35:HOME, 36:END
        || (event.ctrlKey == true && (keyID == 67 || keyID == 86)) //Copy&Paste
        || (keyID >= 48 && keyID <= 57)   //0~9
        || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
        || (keyID >= 37 && keyID <= 40)   //방향키
        || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46 || keyID == 109 || keyID == 189 //8:백스페이스, 13:Enter, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
      )
        return;
      else {
        event.preventDefault();
        return;
      }
    },

    removeNotPhoneNumber: function (event) {
      //event = event || window.event;

      console.log('event.key' + '/ ' + event.key);
      console.log('event.which' + '/ ' + event.which);
      console.log('event.keyCode' + '/ ' + event.keyCode);

      var keyID = (event.which) ? event.which : event.keyCode;
      if ((keyID >= 35 && keyID <= 36) //35:HOME, 36:END
        || (event.ctrlKey == true && (keyID == 67 || keyID == 86)) //Copy&Paste
        || (keyID >= 48 && keyID <= 57)   //0~9
        || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
        || (keyID >= 37 && keyID <= 40)   //방향키
        || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46 || keyID == 109 || keyID == 189 //8:백스페이스, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
      )
        return;
      else {
        console.log('removeNotPhoneNumber' + '/ ' + event.target.value + '/ ' + event.target.value.replace(/[^0-9\-]/g, ""));
        event.target.value = event.target.value.replace(/[^0-9\-]/g, "");
      }
    },
    /**
      * @method convertCodeDTL : 공통코드의 SYSDEF_CD or SYSDEF_NM 값을 통하여 SYSDEF_CD값 리턴.
      *                          주로 엑셀업로드시 "생성"이란값을 입력받으면 "1" 이라는 코드값으로 변환해주기 위해 사용합니다.
      * @param {*} sysdef : 찾아보는 대상 SYSDEF_CD or SYSDEF_NM (예: 1 or 생성)
      * @param {*} datasource : 공통코드 dataSource
      * @return returnValue (예 : { SUCCESS: false, MSG: "미등록 코드입니다." } or { SUCCESS: true, MSG: "1"} )
      */
     convertCodeDTL: function(sysdef, datasource) {

      var returnValue = { SUCCESS: false, MSG: "" };
      if (!sysdef) return returnValue;
      if (!datasource) return sysdef;

      if (datasource.options) {
        // datasource가 객체일때,
        $.each(datasource.options.data, function (_idx, _data) {
          if (sysdef == _data.SYSDEF_CD) {
            returnValue.SUCCESS = true;
            returnValue.MSG = _data.SYSDEF_CD;
            return false;
          }
        });

        if (!returnValue.SUCCESS) {
          $.each(datasource.options.data, function (_idx, _data) {
            if (sysdef == _data.SYSDEF_NM) {
              returnValue.SUCCESS = true;
              returnValue.MSG = _data.SYSDEF_CD;
              return false;
            }
          });
        }
      }
      else {
        // datasource가 배열일때,
        $.each(datasource, function (_idx, _data) {
          if (sysdef == _data.SYSDEF_CD) {
            returnValue.SUCCESS = true;
            returnValue = _data.SYSDEF_CD;
            return false;
          }
        });

        if (!returnValue.SUCCESS) {
          $.each(datasource, function (_idx, _data) {
            if (sysdef == _data.SYSDEF_NM) {
              returnValue.SUCCESS = true;
              returnValue = _data.SYSDEF_CD;
              return false;
            }
          });
        }
      }
      if (!returnValue.SUCCESS) {
        // 값을 못찾으면
        returnValue.MSG = "미등록 코드입니다.";
      }
      return returnValue;
    },

    /**
      * @method convertExcelDate : 엑셀로부터 입력받은 날짜값의 타입에 따라 String형의 날짜값 리턴.
      * @param {*} excelValue : 엑셀로부터 입력받은 날짜값
      * @param {*} returnType : String형 날짜값의 포맷. default : new Date타입, String : '20210713', PipeString : '2021-07-13', Date : new Date타입
      * @return returnDate (Date) DateType - Tue Jul 13 2021 09:00:00 GMT+0900 (대한민국 표준시)
      * @return returnDate (String) '20210713'
      * @return returnDate (PipeString) '2021-07-13'
      */
      convertExcelDate: function(excelValue, returnType) {
      var returnDate = null;

      if (excelValue instanceof Date) {
        returnDate = dews.date.format(excelValue, 'yyyyMMdd');
      }
      else {
        // 숫자만 추출
        var oriDate = module.api.replaceOnlyNumber(String(excelValue));
        if(oriDate.length == 8) {
          returnDate = dews.date.format(oriDate, 'yyyyMMdd');
        }
      }
      if(!returnDate) {
        return excelValue;
      }

      if(returnType == "String") {
        return returnDate;
      } else if(returnType == "PipeString") {
        return dews.date.format(returnDate, 'yyyy-MM-dd');
      }
      return new Date(dews.date.format(returnDate, 'yyyy-MM-dd'));
    },
    /*********************************************************************************************
      *  @desc   그리드에서 입력된 데이터를 선택된 범위에 복사합니다.
      *          또는 Ctrl+V로 입력된 데이터를 선택된 범위에 복사합니다.
      *  @param  e : save이벤트 or pasted이벤트
      *          saveEventHandler : save이벤트 동작여부
      *  @return true or false
      *  @ex     maScmJS.api.CopyCellData(e, saveEventHandler));
      * ------------------------------------------------------------------------------------------*/
     CopyCellData: function(e, saveEventHandler){
      var modifyValue = null;
      if(e.type == "save") {
        $.each(e.grid.multiSelect().columns, function (c_idx, c_data) {
          $.each(e.grid.multiSelect().rows, function (r_idx, r_data) {
            if (module.api.getGridColEdit(e.grid, c_data, r_data)) {
              if (e.grid.options.columns) {
                if (!modifyValue) {
                  modifyValue = e.grid.getCellValue(r_data, c_data); // 붙여넣기시 붙여넣는 첫번째컬럼의 첫번째행에만 값이 세팅되므로 해당값을 별도로 저장합니다.
                }
                if(saveEventHandler) {
                  e.grid.setCellValue(r_data, c_data, "-99901236", false);
                }
                e.grid.setCellValue(r_data, c_data, modifyValue, saveEventHandler, true);
              }
            }
          });
        });
      } else if(e.type == "pasted") {

        $.each(e.grid.multiSelect().columns, function (c_idx, c_data) {
          $.each(e.grid.multiSelect().rows, function (r_idx, r_data) {
            if (module.api.getGridColEdit(e.grid, c_data, r_data)) {
              if(e.grid.clipboard.copyData.length == 1) {
                if (!modifyValue && modifyValue != 0) {
                  modifyValue = e.grid.getCellValue(r_data, c_data); // 붙여넣기시 붙여넣는 첫번째컬럼의 첫번째행에만 값이 세팅되므로 해당값을 별도로 저장합니다.
                }
              } else {
                modifyValue = e.grid.getCellValue(r_data, c_data); // 복수 값 복사 붙여넣기 처리
              }
              // 기존 코드
              // if (!modifyValue) {
              //   modifyValue = e.grid.getCellValue(r_data, c_data); // 붙여넣기시 붙여넣는 첫번째컬럼의 첫번째행에만 값이 세팅되므로 해당값을 별도로 저장합니다.
              // }
              if(saveEventHandler) {
                e.grid.setCellValue(r_data, c_data, "-99901236", false);
              }
              e.grid.setCellValue(r_data, c_data, modifyValue, saveEventHandler, true);
            }
          });
        });
      }
    },
    pastedCellData: function (e, saveEventHandler) {
      //복사붙여넣기시 강제로 save이벤트를 호출하도록함
      var param;
      var dataitem;
      if (e.rows && e.columns) {
        $.each(e.rows, function (i, row) {
          dataitem = e.grid.dataItem(row);
          $.each(e.columns, function (j, col) {
            param = {
              cell: { field: col, data: dataitem[col] },
              grid: e.grid,
              row: { index: row, data: dataitem }
            }
            e.grid.options.save(param);
          });
        });
      }
    },
    /*********************************************************************************************
      *  @desc   그리드의 컬럼 수정가능여부 리턴 (체크가능한 헤더행의 최대갯수는 3개입니다!!!!!!!!!)
      *  @param  grid : self.grid   그리드
      *  @param  col_cd : "PJT_NO" 수정가능여부를 체크하고싶은 컬럼코드
      *  @return true or false
      *  @ex      maScmJS.api.getGridColEdit(self.grid, 1, "PJT_NO");
      * ------------------------------------------------------------------------------------------*/
     getGridColEdit: function(grid, col_cd, col_idx){
      var editable = false;
      var return_flag = false;
      let colData = { grid: grid, row: { data: grid.sortDataItems().find(function (_item, _idx) { return _idx === col_idx; }), index: col_idx }};
      $.each(grid.options.columns, function (e_idx, e_data) {
        if (grid.options.columns[e_idx].columns) {
          $.each(grid.options.columns[e_idx].columns, function (e2_idx, e2_data) {
            if (grid.options.columns[e_idx].columns[e2_idx].columns) {
              $.each(grid.options.columns[e_idx].columns[e2_idx].columns, function (e3_idx, e3_data) {
                if (e3_data.field == col_cd) {
                  editable = (typeof e3_data.editor.editable === 'function' ? !e3_data.editor.editable(colData) : !e3_data.editor.editable || !e3_data.editable) ? false : true;
                  return_flag = true;
                  return false;
                }
              });
            } else {
              if (e2_data.field == col_cd) {
                editable = (typeof e2_data.editor.editable === 'function' ? !e2_data.editor.editable(colData) : !e2_data.editor.editable || !e2_data.editable) ? false : true;
                return_flag = true;
                return false;
              }
            }
            if (return_flag) {
              return false;
            }
          });
        } else {
          if (e_data.field == col_cd) {
            editable = (typeof e_data.editor.editable === 'function' ? !e_data.editor.editable(colData) : !e_data.editor.editable || !e_data.editable) ? false : true;
            return_flag = true;
            return false;
          }
        }

        if (return_flag) {
          return false;
        }
      });
      return editable;
    },
    /**
             * 메뉴점프(openmenu)시 현재 로그인한그룹이 해당 메뉴로 어떤 모듈에 등록되어있는가를 조회합니다.
             * @param {*} 이동할 menuid
             * @return module_cd(PS, CX....)
             */
    getGrpMenuModuleCd: function (menuid) {
      var module_cd = "";
      dews.api.get(dews.url.getApiUrl("MA", "MaCommonService", "MAApiProvider_GROUP_MENU_MODULE_INFO"), {
        async: false,
        data: {
          menu_cd: menuid
        }
      }).done(function (mResultData) {
        if (mResultData.SUCCESS) {
          module_cd = mResultData.MSG;
          console.log(mResultData.PARAMS);

        } else {
          console.log(mResultData.MSG);
          // [2021.02.25-이현태] 메뉴진입시 해당 함수를 바로 호출하는 부분이 있어서 주석처리합니다.
          // mResultData.MSG = "로그인한 그룹으로 해당 메뉴에 대한 접근 권한이 없습니다." + menuid
          // setTimeout(function () {
          //   dews.alert(mResultData.MSG, { icon: mResultData.TYPE_CD });
          // }, 200);
        }
      }).fail(function (xhr, status, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
      });
      return module_cd;
    },
    getPartnerDivisionInfo : function() {
      var divisionInfo;
      dews.api.get(dews.url.getApiUrl('CI','CommonMasterConfigurationPRTService', 'cocprt00600_list'), {
        async: false,
      }).done(function(data) {
        if (data != null && data.length > 0) {
          divisionInfo = data;
        }
      }).fail(function (xhr, status, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
      });
      return divisionInfo;
    },
    setPartnerCodeStateByRule : function(data, partnerFgController, partnerController, bizNoController) {
      var rule = data != null ? data.filter(function(d) { return d.PARTNER_FG_CD == partnerFgController.value()}) : null;
      if(rule != null && rule.length > 0) {
        isAuto = (rule[0].EXTNO_FG == '1' || rule[0].EXTNO_FG == '3') ? true : false
        partnerController.readonly(isAuto)
        partnerController.required(!isAuto)
        if(rule[0].EXTNO_FG == '3' && rule[0].CD_FG == '1' && bizNoController != null) {
          partnerController.text(bizNoController.raw())
        }
      } else {
        dews.alert("해당거래처구분에 해당되는 채번규칙이 생성되지 않았습니다.",'warning').yes(function() {
          partnerController.text('')
          partnerFgController.value(null)
        });
      }
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc           회사환경설정 통제값 조회
    *  @ex             getCmpyEnvControl(module_cd, ctrl_cd)
    * --------------------------------------------------------------------------------------------*/
    getCmpyEnvControl: function (module_cd, ctrl_cd) {
      /******회사환경설정등록******/
      // 회사환경설정 : 모듈(PS), 통제코드(BC00000), 통제코드명([1.예산통제]여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00010), 통제코드명([1-1. 집계공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
      // 회사환경설정 : 모듈(PS), 통제코드(BC00020), 통제코드명([1-2. 집계공종]경고알림 여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00030), 통제코드명([1-2-1. 집계공종]경고수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00040), 통제코드명([1-2-2. 집계공종]통제수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00050), 통제코드명([1-3. 내역공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
      // 회사환경설정 : 모듈(PS), 통제코드(BC00060), 통제코드명([1-4. 내역공종]경고알림 여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00070), 통제코드명([1-4-1. 내약공종]경고수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00080), 통제코드명([1-4-2.내역공종]통제수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00090), 통제코드명([실행예산]실행예산 Sync 시점), 1:실행예산요청시, 2:실행예산승인시
      // 회사환경설정 : 모듈(PS), 통제코드(BC00100), 통제코드명(외주변경계약 위치), 1:외주계약등록, 2:외주발주품의등록
      // 회사환경설정 : 모듈(PS), 통제코드(PS00000), 통제코드명(기준정보)
      // 회사환경설정 : 모듈(PS), 통제코드(PS00010), 통제코드명(예산연동여부), Y : Yes  N : No
      // 회사환경설정 : 모듈(PS), 통제코드(PS00020), 통제코드명(실행예산연동여부), Y : Yes  N : No
      var isCmpyEnvControl = null;
      {
        dews.api.get(dews.url.getApiUrl('MA', 'MaCommonService', 'MAApiProvider_Get_Company_Control'), {
          async: false,
          data: {
            module_cd: module_cd,
            ctrl_cd: ctrl_cd  // 사업계획 사용여부
          }
        }).done(function (data) {
          isCmpyEnvControl = data;
        }).fail(function (xhr, status, error) {
          setTimeout(function () {
            dews.error('오류가 발생하였습니다.');
          }, 200);
          console.error(error);
        });
      }
      return isCmpyEnvControl;
    },

    /* --------------------------------------------------------------------------------------------
    *  @desc           회사환경설정 조회
    *  @ex             getCmpyEnvControlInfo("PS", "PS00185", "FORMAT_VR")
    *
    * --------------------------------------------------------------------------------------------*/
    getCmpyEnvControlInfo: function (module_cd, ctrl_cd, col_cd) {
      /******회사환경설정등록******/
      // 회사환경설정 : 모듈(PS), 통제코드(BC00000), 통제코드명([1.예산통제]여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00010), 통제코드명([1-1. 집계공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
      // 회사환경설정 : 모듈(PS), 통제코드(BC00020), 통제코드명([1-2. 집계공종]경고알림 여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00030), 통제코드명([1-2-1. 집계공종]경고수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00040), 통제코드명([1-2-2. 집계공종]통제수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00050), 통제코드명([1-3. 내역공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
      // 회사환경설정 : 모듈(PS), 통제코드(BC00060), 통제코드명([1-4. 내역공종]경고알림 여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00070), 통제코드명([1-4-1. 내약공종]경고수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00080), 통제코드명([1-4-2.내역공종]통제수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00090), 통제코드명([실행예산]실행예산 Sync 시점), 1:실행예산요청시, 2:실행예산승인시
      // 회사환경설정 : 모듈(PS), 통제코드(BC00100), 통제코드명(외주변경계약 위치), 1:외주계약등록, 2:외주발주품의등록
      // 회사환경설정 : 모듈(PS), 통제코드(PS00000), 통제코드명(기준정보)
      // 회사환경설정 : 모듈(PS), 통제코드(PS00010), 통제코드명(예산연동여부), Y : Yes  N : No
      // 회사환경설정 : 모듈(PS), 통제코드(PS00020), 통제코드명(실행예산연동여부), Y : Yes  N : No
      var isCmpyEnvControl = null;
      {
        dews.api.get(dews.url.getApiUrl('MA', 'MaCommonService', 'MAApiProvider_Get_Company_Control_API'), {
          async: false,
          data: {
            module_cd: module_cd,
            ctrl_cd: ctrl_cd  // 사업계획 사용여부
          }
        }).done(function (data) {
          if (data) {
            isCmpyEnvControl = data[col_cd];
          }
        }).fail(function (xhr, status, error) {
          setTimeout(function () {
            dews.error('오류가 발생하였습니다.');
          }, 200);
          console.error(error);
        });
      }
      return isCmpyEnvControl;
    },
    decimalPointFloor: function(value, length) {
      // 소수점을 반올림없는 버림이 하고 싶습니다.
      // value = 0.09999
      // length = 4
      // floor_value = 10000
      // return = 0.0999
      var floor_value = "1".padEnd(Number(length) + 1, '0').replace(length, ""); // "10000" 소수점 4자리 버림.
      return Math.floor(value * Number(floor_value)) / floor_value;
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       backendService 버전정보 리턴 (콘솔 log 찍습니다.)
     *  @return     versionInfo
     *  @call       maScmJs.api.getVersion('1.0.22072701', 'PSCustomCodeHelpService')
     * ------------------------------------------------------------------------------------------*/
    getVersion: function (frontEndVersion, backEndServiceName) {
      var versionInfo = { frontEndVersion: frontEndVersion, backEndVersion: '' };
      dews.api.get(dews.url.getApiUrl('CM', 'ServiceVersion'), {
        async: false,
        data: {
          service: backEndServiceName
        }
      }).done(function (data) {
        if (data && data.length > 0) {
          versionInfo.backEndVersion = data;
        }
      }).fail(function (xhr, status, error) {
        setTimeout(function () {
          dews.error('오류가 발생하였습니다.');
        }, 200);
        console.error(error);
      });
      console.log("%c■ 버전정보", 'color: rgb(0,  84,  255)')
      console.log("> FrontEnd-Version : " + versionInfo.frontEndVersion);
      console.log("> BackEnd-Version : " + versionInfo.backEndVersion);
      return versionInfo;
    },
    getDRS_CODE: function () {
      return dews.app.drsCode;
    },
    /*
    none_gwaprvlst_cd : ["2","4"] 제외할 상태값을 배열로 넣어준다.
    */
    approvalStatusChecking: function (company_cd, athz_rpts_cd, gwaprvlst_cd, none_gwaprvlst_cd) {
      var msg = null;
      var resultData = null;

      if (msg = this.approvalStatusCheckingMessage(gwaprvlst_cd, none_gwaprvlst_cd)) return msg;

      // 백엔드 common은 모듈 사용여부 상관없이 모든 프로젝트가 배포되기 때문에 ps-common을 사용합니다.[전체공통은 ps-common]
      dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_ApprovalStatusChecking"), {
        async: false,
        data: {
          company_cd: company_cd,
          athz_rpts_cd: athz_rpts_cd || ''
        }
      }).done(function (data) {
        if (data && data.length > 0) {
          resultData = data;
        }
      }).fail(function (xhr, status, error) {
        console.error(error);
        setTimeout(function () {
          dews.error('오류가 발생하였습니다.');
        }, 200);
        msg = error;
      });

      if (resultData && resultData.length > 0) {
        msg = this.approvalStatusCheckingMessage(resultData[0].GWAPRVLST_CD, none_gwaprvlst_cd);
      }

      return msg;
    },
    approvalStatusCheckingMessage: function (gwaprvlst_cd, none_gwaprvlst_cd) {
      var msg = null;
      var none_check_state = null;
      if (none_gwaprvlst_cd && none_gwaprvlst_cd.length > 0) {
        none_check_state = none_gwaprvlst_cd.filter(function (row) { return row == gwaprvlst_cd });
      }
      if (!none_check_state || none_check_state.length == 0) {
        if (gwaprvlst_cd) {
          if (gwaprvlst_cd == "2") {
            msg = "[상신]건은 처리가 불가합니다.";
          } else if (gwaprvlst_cd == "3") {
            msg = "[진행]건은 처리가 불가합니다.";
          } else if (gwaprvlst_cd == "4") {
            msg = "[종결]건은 처리가 불가합니다.";
          } else if (gwaprvlst_cd == "7") {
            msg = "[보류]건은 처리가 불가합니다.";
          } else if (gwaprvlst_cd == "9") {
            msg = "[보관]건은 처리가 불가합니다.";
          }
        }
      }
      return msg;
    }
  }

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/MA/ma.scm.js
