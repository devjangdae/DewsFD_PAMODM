/*
 * @desc    IM 모듈 전자결재 properties
 * @date    2021.10.13
 * @path    /view/js/im.gw.properties.js
 */

(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'CI_GW_PROPERTIES';

  dews.ajax.script('~/view/js/HR/hr.gw.util.js', {
    once: true,
    async: false
  });

  /*
  * ● 그룹웨어 공통 설정, WF별 세부설정은 module.formId 에서 설정
  * gwServerUrl  : 전자결재 서버 URL (설정이 없다면 config/gw.properties-gw.server.url 로 설정)
  * url_type     : url타입 : 그룹웨어 결재구분 구분자 : "common" or "x"+drsCode (config/gw.properties - gw.approval.[url_type]].url)
  */
  module.gw = {
    package : {
      desc : "Package",
      url_type : "common"
    },
    20039 : {
      desc : "현대오일터미널",
      url_type : "common"
    },
    20171 : {
      desc : "모트라스 주식회사",
      url_type : "common"
    },
    20172 : {
      desc : "유니투스 주식회사",
      url_type : "common"
    },
    // 10072 : {
    //   desc : "DEV테스트",
    //   gwServerUrl : "https://gw.comet.duzon.net/gw/outProcessEncLogOn.do",
    //   url_type : "common"
    // },
  };


  /*
  * ● 메뉴 WF 별 세부설정
  *
  * contents_url        : 전자결재 양식 url
  * athz_rpts_table_nm  : ATHZ_RPTS_CD UPDATE 할 테이블ID
  * postProcess_url     : 후처리 서비스 url
  * gwWindow_close_event: 전자결재 창 close 시 이벤트
  */
  module.formId = {
    COCPRT00200_WF01 : {
      package : {
        desc : "Package",
        contents_url : "/api/CI/CommonMasterConfigurationPRTService/cocprt00200_get_html_contents",
        athz_rpts_table_nm : "CI_PARTNERREQ_MST",
        postProcess_url : "/api/CI/CommonMasterConfigurationPRTService/cocprt00200_gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20039 : {
        desc : "현대오일터미널",
        contents_url : "/api/CI/CommonMasterConfigurationPRTService/cocprt00200_get_html_contents",
        athz_rpts_table_nm : "CI_PARTNERREQ_MST",
        postProcess_url : "/api/CI/CommonMasterConfigurationPRTService/cocprt00200_gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20171 : {
        desc : "모트라스 주식회사",
        contents_url : "/api/CI/CommonMasterConfigurationPRTService/cocprt00200_get_html_contents",
        athz_rpts_table_nm : "CI_PARTNERREQ_MST",
        postProcess_url : "/api/CI/CommonMasterConfigurationPRTService/cocprt00200_gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20172 : {
        desc : "유니투스 주식회사",
        contents_url : "/api/CI/CommonMasterConfigurationPRTService/cocprt00200_get_html_contents",
        athz_rpts_table_nm : "CI_PARTNERREQ_MST",
        postProcess_url : "/api/CI/CommonMasterConfigurationPRTService/cocprt00200_gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
