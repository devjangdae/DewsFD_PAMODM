(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'CI';

  if (!Array.prototype.find) {
    Array.prototype.find = function (predicate) {
      'use strict';
      if (this == null) {
        throw new TypeError('Array.prototype.find called on null or undefined');
      }
      if (typeof predicate !== 'function') {
        throw new TypeError('predicate must be a function');
      }
      var list = Object(this);
      var length = list.length >>> 0;
      var thisArg = arguments[1];
      var value;

      for (var i = 0; i < length; i++) {
        value = list[i];
        if (predicate.call(thisArg, value, i, list)) {
          return value;
        }
      }
      return undefined;
    };
  }

  if (!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
      value: function (predicate) {
        'use strict';
        if (this == null) {
          throw new TypeError('Array.prototype.findIndex called on null or undefined');
        }
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }
        var list = Object(this);
        var length = list.length >>> 0;
        var thisArg = arguments[1];
        var value;

        for (var i = 0; i < length; i++) {
          value = list[i];
          if (predicate.call(thisArg, value, i, list)) {
            return i;
          }
        }
        return -1;
      },
      enumerable: false,
      configurable: false,
      writable: false
    });
  }

  module.GB = (function () {
    return {

      globalVariables : {
        self : null
      },

      messages : {
    	  // 조회
    	  search : {
    		  not_saved : '저장하지 않은 데이터가 있습니다.' + '\n' + '조회를 계속하시겠습니까?',
    		  searching : '조회하는 중 입니다.'
    	  },
    	  // 메일
    	  mail : {
    		  sending : '메일을 보내는 중 입니다.',
    		  send_ok : '메일 보내기가 완료되었습니다.',
    		  send_fail : '메일 보내기가 실패하였습니다.',
    		  send_error : '메일을 보내는 중 오류가 발생하였습니다.',
    	  },
    	  // 쪽지
    	  message : {
    		  sending : '쪽지를 보내는 중 입니다.',
    		  send_ok : '쪽지 보내기가 완료되었습니다.',
    		  send_fail : '쪽지 보내기가 실패하였습니다.',
    		  send_error : '쪽지를 보내는 중 오류가 발생하였습니다.',
    	  },
    	  // 알림
    	  alert : {
    		  sending : '알림을 보내는 중 입니다.',
    		  send_ok : '알림 보내기가 완료되었습니다.',
    		  send_fail : '알림 보내기가 실패하였습니다.',
    		  send_error : '알림을 보내는 중 오류가 발생하였습니다.',
    	  },
    	  // 수정
    	  edit : {
    		  closed: '마감 되었습니다.'
    	  },
    	  // 삭제
    	  delete : {
    		  no_rows: {
    			  grid: '삭제할 항목을 체크해 주십시오.',
    			  cardlist: '삭제할 항목을 선택해 주십시오.'
    		  },
    		  ask: '삭제 하시겠습니까?' + '\n' + '(반드시 저장을 하셔야 반영이 됩니다.)'
    	  },
    	  // 저장
    	  save : {
			ask: '저장하시겠습니까?',
			no_dirty: '저장할 데이터가 없습니다.',
			done: '저장이 완료되었습니다.',
			error: '자료를 저장하는 중 오류가 발생되었습니다.',
			cancel: '취소하였습니다.',
			verify: '필수항목을 입력하지 않았습니다.',
			saving: '저장하는 중입니다.'
    	  },
    	  // 닫기
    	  closing: {
    		  not_saved: '저장하지 않은 데이터가 있습니다.' + '\n' + '닫기를 계속하시겠습니까?'
    	  },
    	  // 불러오기
    	  load : {
    		  no_options: '불러오기 할 수 있는 항목이 없습니다.',
    		  done: '불러오기가 완료되었습니다.',
    		  londing: '불러오는 중 입니다.'
    	  }
      },
      // 메뉴 정보 저장(self)
      initialize : function(self) {
        this.globalVariables.self = self;
      },
      // 인쇄미리보기 호출
      previewReport : function(reportMasterCode,parameterGroup) {
        var commonjs = this;

        reportMasterCode = this.normalizeParameter(reportMasterCode);
        parameterGroup = this.normalizeParameter(parameterGroup);

        if (typeof parameterGroup === 'undefined' || parameterGroup == null) {
          parameterGroup = {};
          parameterGroup['Z_' + (this.globalVariables.self.menu || {}).id + '_01'] = {};
        }

        var items = [];
        for (var objectCode in parameterGroup) {
          var parameters = $.extend(true,{print_dt : this.getYyyymmdd()},this.normalizeParameter(parameterGroup[objectCode]));

          for (var parameterCode in parameters) {
            items.push({
              RPRT_CD: reportMasterCode,
              OBJECT_CD: objectCode,
              PARA_CD: parameterCode,
              PARA_TXT: parameters[parameterCode]
            });
          }
        }

        dews.api.post(dews.url.getApiUrl('CM', 'printService', 'setPrintParam'), {
        	data: {
        		reportCode: reportMasterCode,
        		items: JSON.stringify(items)
        	}
        }).done(function (parameterKey) {
          if (commonjs.nvl(parameterKey, '').length > 0) {
            var options = {
              reportId : reportMasterCode,
              parameterKey : parameterKey,
              menuId : (commonjs.globalVariables.self.menu || {}).id
            };
            dews.app.print(options);
          }
        });
      },
      sendMail : function(sender,receiver,referer,title,content,attachedFiles) {
    	  return new Promise(function(resolve, reject) {
    		  dews.api.post(dews.url.getApiUrl('CZ', 'HandyGroupware', 'sendMail'), {
        		  data: {
        			'sender'      	: sender,
      	            'receiver'		: JSON.stringify(receiver),
      	            'referer'		: JSON.stringify(referer),
      	            'title'			: title,
      	            'content'		: content,
      	            'attachedFiles'	: JSON.stringify(attachedFiles)
    			}
        	  }).done(function (result) {
        		  resolve(result);
        	  }).fail(function (error) {
        		  reject(error);
        	  });
    	  });
      },
      sendMessage : function(sender,receiver,title,content) {
    	  return new Promise(function(resolve, reject) {
    		  dews.api.post(dews.url.getApiUrl('CZ', 'HandyGroupware', 'sendMessage'), {
        		  data: {
        			'sender'      	: sender,
      	            'receiver'		: JSON.stringify(receiver),
      	            'title'			: title,
      	            'content'		: content
    			}
        	  }).done(function (result) {
        		  resolve(result);
        	  }).fail(function (error) {
        		  reject(error);
        	  });
    	  });
      },
      sendAlert : function(receiver,title,content,url) {
    	  return new Promise(function(resolve, reject) {
    		  dews.api.post(dews.url.getApiUrl('CZ', 'HandyGroupware', 'sendAlert'), {
        		  data: {
      	            'receiver'		: JSON.stringify(receiver),
      	            'title'			: title,
      	            'content'		: content,
      	            'url'			: url
    			}
        	  }).done(function (result) {
        		  resolve(result);
        	  }).fail(function (error) {
        		  reject(error);
        	  });
    	  });
      },
      showMailForm : function (sender, receiver, referer, title, content, attachedFiles) {

    	  var commonjs = this
    	  return new Promise(function(resolve, reject) {
			  dews.ui.dialog('COMMON_Z10062_DLG0001', {
			        url: '/view/CZ/COMMON_Z10062_DLG0001',
			        title: '메일 보내기',
			        width: 1000,
			        height: 800,
			        initData: {
			        	'session'   	: commonjs.globalVariables.self.user,
			            'sender'		: sender,
			            'receiver'		: receiver,
			            'referer'		: referer,
			            'title'			: title,
			            'content'		: content,
			            'attachedFiles'	: attachedFiles
			        },
			        ok: function (result) {
			        	if(result){
			        		 resolve(result);
			        	}
			        	else {
			        		reject(result);
			        	}
			        },
			    }).open();
    	  });
      },
      showMessageForm : function (sender, receiver, title, content) {

    	  var commonjs = this
    	  return new Promise(function(resolve, reject) {
			  dews.ui.dialog('COMMON_Z10062_DLG0002', {
			        url: '/view/CZ/COMMON_Z10062_DLG0002',
			        title: '쪽지 보내기',
			        width: 510,
			        height: 450,
			        initData: {
			        	'session'   	: commonjs.globalVariables.self.user,
			            'sender'		: sender,
			            'receiver'		: receiver,
			            'title'			: title,
			            'content'		: content
			        },
			        ok: function (result) {
			        	if(result){
			        		 resolve(result);
			        	}
			        	else {
			        		reject(result);
			        	}
			        },
			    }).open();
    	  });
      },
      sendKogasFile : function (attachedFiles,send_dt) {

    	  var commonjs = this
    	  return new Promise(function(resolve, reject) {
    		  dews.api.post(dews.url.getApiUrl('CZ', 'KogasLinkSystem', 'sendFileToDate'), {
        		  data: {
    				'attachedFiles'	: JSON.stringify(attachedFiles),
    				'send_dt'		: commonjs.coalesce(send_dt,commonjs.getYyyymmdd()),
    			}
        	  }).done(function (data) {
        		  resolve(data);
        	  }).fail(function (error) {
        		  reject(error);
        	  });
    	  });
      },
      getEmployeeInfo : function (company_cd,emp_no) {
    	  return new Promise(function(resolve, reject) {
    		  dews.api.get(dews.url.getApiUrl('CZ', 'HandyGroupware', 'getEmployeeInfo'), {
        		  data: {
    				'company_cd'	: company_cd,
    				'emp_nos'		: Array.isArray(emp_no) ? emp_no.join('|') : emp_no + '|'
    			}
        	  }).done(function (data) {
        		  resolve(data);
        	  }).fail(function (error) {
        		  reject(error);
        	  });
    	  });
      },
      getYyyymmdd : function(date) {

        if(date == undefined)
          date = new Date();

    	  var yyyy = date.getFullYear().toString();
    	  var mm = (date.getMonth() + 1).toString();
    	  var dd = date.getDate().toString();
    	  return yyyy + (mm[1] ? mm : '0'+mm[0]) + (dd[1] ? dd : '0'+dd[0]);
      },
      normalizeParameter : function (value, defaultValue) {
        if (typeof value === 'function') {
          value = value();
        }
        if (this.isNotNull(value) == false && this.isNotNull(defaultValue)) {
          value = defaultValue;
        }

        return value;
      },

      coalesce : function (value, nullValue) {
        return this.nvl(value,nullValue);
      },

      nvl : function (value, nullValue) {
        if (this.isNotNull(value) == false) return nullValue;
        return value;
      },

      isNotNull : function (value) {
        if (value != null && value != undefined && value != '') return true;
        return false;
      },

      isNull : function (value) {
        if (value == null)
          return true;

        if (value == undefined)
          return true;

        if (value == '')
          return true;
        return false;
      },

      test : function(e){
      }
    };
})();

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=/CI/gb.common.js
