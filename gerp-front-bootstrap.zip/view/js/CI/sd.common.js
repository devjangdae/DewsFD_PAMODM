(function (gerp, $) {
	var module = {};
	var moduleCode = 'CI';
	
	if (!Object.values) {
		Object.values = function(o) {
			if (Object.prototype.toString.call(o) != '[object Object]') {
				return [];
			}
			return Object.keys(o).map(function(e) {
				return o[e];
			});
		};
	}
	
	module.SD = new function() {
		this.isOnce = true;
		
		/**
		 * @desc		: Initialize key down event
		 * @param1		: Each self of menu
		 * @returnType	: void
		 * */
		this.initKeyDownEvt = function(self_menu_id) {
			var _this = this;
		    $('body').keydown(function(e) {
		        if (e.altKey && e.keyCode == 85 && self_menu_id == dews.ui.page.menu.id) {
		        	if (_this.isOnce) {
			            $('#content_' + dews.ui.page.menu.id).find('.except_auth_checkbox, .preview-docu').toggle();
		        		_this.isOnce = false;
			            setTimeout(function() {
			            	_this.isOnce = true;
			            }, 0);
		        	}
		        }
		        else if (e.altKey && e.keyCode == 67) {
		            console.clear();
		        }
		    });
		};
		
		/**
		 * @desc		: Keep row in grid after re-lookup
		 * @param1		: ReadGrid object
		 * @param2		: Whether grid is selected
		 * @returnType	: void
		 * */
		this.keepRow = function(grid, selected) {
			try {
				if (grid.keep_row && selected == true) {
					// Variable closure handling
					(function(index, column) {
						// Put at the back of the browser javascript work queue
						setTimeout(function() {
							grid.select(index, column);
						}, 0);
					})(grid.keep_row.index, grid.keep_row.column);
				}
				// Put at the back of the browser javascript work queue
				setTimeout(function() {
					grid.keep_row = new function() {
						this.index = grid.select();
						this.column = grid.getCurrentColumn();
					};
				}, 0);
			}
			catch(e) {
				throw e;
			}
		};
		
		/**
		 * @desc		: Get real variable type
		 * @param1		: Any type of variable
		 * @returnType	: string
		 * */
		this.getRealType = function(variable) {
			return Object.prototype.toString.call(variable);
		};
		
		/**
		 * @desc		: Move left grid row to right grid
		 * @param1		: Row index to move from left grid
		 * @param2		: Left grid
		 * @param3		: Right grid
		 * @returnType	: void
		 * */
		this.moveRow = function(index, left_grid, right_grid) {
		    var array
		    , _this = this;
		    
		    if (left_grid.dataItems().length == 0) {
		    	return;
		    }

		    if (_this.getRealType(index) == '[object Number]') {
		        array = [index];
		    }
		    else if (_this.getRealType(index) == '[object Array]') {
		        array = index;
		    }
		    else {
		        throw 'Variable `index` must be type of `Number` or `Array`';
		    }

		    array.forEach(function(i) {
		        var data = left_grid.dataItem(i);
		        if (data) {
			        right_grid.addRow();
		        	right_grid.updateRow(right_grid.select(), data);
		        }
		    });
		};
		
		/**
		 * @desc		: Get index for column value
		 * @param1		: ReadGrid object
		 * @param2		: Column by which row to find
		 * @param3		: Value of column by which row to find
		 * @returnType	: number
		 * */
		this.getIndexForColumn = function(grid, column, value) {
		    var index = -1;
		    
		    grid.dataItems().some(function(e, i) {
		        if (grid.dataItem(i)[column] == value) {
		            index = i;
		            return true;
		        }
		    });
		    
		    return index;
		};

		/**
		 * @desc		: Get index for multi column values
		 * @param1		: ReadGrid object
		 * @param2		: Column object by which row to find or array filter callback function
		 * @returnType	: number
		 * */
		this.getIndexForColumns = function(grid, obj) {
		    var index = -1
		    , _this = this
		    , matched_array = grid.dataItems().filter(function(e, i) {
	    		if (_this.getRealType(obj) == '[object Function]') {
	    			return obj(e, i);
	    		}
	    		else {
			        return !Object.keys(obj).some(function(key) {
			        	return e[key] != obj[key];
			        });	
	    		}		    		
		    });
		    
		    if (matched_array.length > 0) {
		        index = _this.getIndexForColumn(grid, '__UUID', matched_array[0].__UUID);
		    }
		    
		    return index;
		};
		
		/**
		 * @desc		: Enable or disable all controls in form panel
		 * @param1		: Form panel object of kendo ui
		 * @param2		: Whether form panel is enable/disable
		 * @returnType	: void
		 * */
		this.enableFormPanel = function(form_panel, enable) {
	        form_panel.$element.find('[class^=dews-ui].dews-form-control').each(function() {
	            if ($(this).data('dews-control').enable) {
	                $(this).data('dews-control').enable(enable);
	            }
	            else if ($(this).data('dews-control').disable) {
                    $(this).data('dews-control').disable(!enable);
	            }
	        });
	    };
	    
	    /**
	     * @desc		: Clear and disable all controls in form panel
	     * @param1		: Form panel object of kendo ui
	     * @returnType	: void
	     * */
	    this.clearFormPanel = function(form_panel) {
	        var form_panel_data = form_panel.serialize()
		    , _this = this;
	        
	        Object.keys(form_panel_data).forEach(function(e) {
	            form_panel_data[e] = '';
	        });

	        form_panel.bindData(form_panel_data);

	        _this.enableFormPanel(form_panel, false);
	    };
	    
	    /**
	     * @desc		: Fit last control in form panel to bottom
	     * @param1		: Dews self object
	     * @returnType	: void
	     * */
	    this.formFitBottom = function(self) {
	    	self.$content.find('[data-form-fit-bottom=true].dews-ui-form-panel').each(function() {
	    	    var $form_div = $(this)
	    	    , $form = $form_div.find('> form')
	    	    , $ul = $form.find('> ul')
	    	    , $li = $ul.find('> li').not('.transparency')
	    	    , $last_li = $li.filter(':last')
	    	    , $not_last_li = $li.not($last_li)
	    	    , column_length = (
	    	        $form_div.data('dews-columns')
	    	        || (
	    	            $form_div.hasClass('col-1') ? 1 :
	    	            $form_div.hasClass('col-2') ? 2 :
	    	            $form_div.hasClass('col-3') ? 3 :
	    	            $form_div.hasClass('col-4') ? 4 :
	    	            0
	    	        )
	    	    );
	    	    
	    	    if (column_length == 0) {
	    	        console.error($form_div);
	    	        console.error('column_length is 0');
	    	    }
	    	    else {
	    	        var control_length = (
	    	        	$not_last_li.size()
	    	            + ($not_last_li.filter('.col-2').length * 1)
	    	            + ($not_last_li.filter('.col-3').length * 2)
	    	            + ($not_last_li.filter('.col-4').length * 3)
	    	        )
	    	        , line_length = Math.ceil(control_length/column_length);

	    	        if ($form_div.prop('style').height == '') {
	    	            $form_div.css('height', '100%');
	    	        }
	    	        $form.css('height', '100%');
	    	        $ul.css('height', '100%');
	    	        $last_li.css('height', 'calc(100% - ' + (31 * line_length + 6) + 'px)');
	    	        $last_li.find('*').css('height', '100%');
	    	    }
	    	});
	    };

	    /**
	     * @desc		: Check null argument 
	     * @param1		: Variable
	     * @returnType	: Boolean
	     * */
	    this.isNull = function(arg) {
	    	return (arg || true) === true;
	    };

	    /**
	     * @desc		: Check not null argument 
	     * @param1		: Variable
	     * @returnType	: Boolean
	     * */
	    this.isNotNull = function(arg) {
	    	return !this.isNull(arg);
	    };

	    /**
	     * @desc		: Validate readGrid
	     * @param1		: ReadGrid object
	     * @returnType	: Object
	     * */
	    this.validateGrid = function(grid) {
	        var result = false;
	        var message = '';

	        var validate = grid.validate();
	        result = validate.result;
	        if (result) {
	            return {
	                message : message
	                , validate : result
	            };
	        }

	        var column_name = validate.fields[0].columnName;
	        var row_index = validate.fields[0].rowIndex + 1;
	        var column_title = '';
	        grid.options.columns.forEach(function(e1) { // 1.
	            if (e1.field == column_name) {
	                column_title = ' ' + e1.title;
	                return false;
	            }
	            if (typeof e1.columns != 'undefined') { // 2.
	                var find = false;
	                e1.columns.forEach(function(e2) {
	                    if (e2.field == column_name) {
	                        column_title = ' ' + e1.title + ' ' + e2.title;
	                        find = true;
	                        return false;
	                    }
	                });
	                if (find) {
	                    return false;
	                }
	            }
	        });
	        message = '필수항목을 입력하지 않았습니다.\n' + row_index + '행 ' + column_title;

	        return {
	            message : message
	            , validate : result
	            , column_title : column_title
	        };
	    };

	    /**
	     * @desc		: Validate child readGrid
	     * @param1		: Parent grid
	     * @param2		: Child object
	     * @param3		: Key field
	     * @returnType	: Object
	     * */
	    this.validateChildGrid = function(parent_grid, child_grid, key_field, self) {
	        var getRequired = function(columns) {
	            var required = [];
	            columns.forEach(function(e) {
	                if (e.columns) {
	                    required = getRequired(e.columns);
	                }
	                else {
	                    if (e.attributes && e.attributes.class == 'required') {
	                        required.push(e);
	                    }
	                }
	            });
	            return required;
	        }
	        , required_list = getRequired(child_grid.getColumns())
	        , validate = {
	            result : true
	            , list : []
	        }
	        , child_data_source = child_grid.userOptions.dataSource
	        , added = child_data_source.getDirtyData().Added
	        , updated = child_data_source.getDirtyData().Updated
	        , _this = this;
	        
	        added.concat(updated).forEach(function(e) {
	            var inner_list = [];
	            required_list.forEach(function(required) {
	                if (_this.isNull(e[required.field])) {
	                    inner_list.push({
	                        data : e
	                        , field : required.field
	                        , title : required.title
	                        , index : _this.getIndexForColumn(child_grid, '__UUID', e.__UUID)
	                        , parent_index : key_field ? _this.getIndexForColumn(parent_grid, key_field, e[key_field]) : -1
	                    });
	                    validate.result = false;
	                }
	            });
	            if (!validate.result) {
	                validate.list.push(inner_list);
	            }
	        });
	        
	        return validate;
	    };

	    /**
	     * @desc		: Validate child readGrid and alert message
	     * @param1		: Validate options
	     * @returnType	: void
	     * */
	    this.validateAndAlertChildGrid = function(options) {
	    	var _this = this;
	    	
	        if (!options.parent_grid) {
	            console.error('parent_grid is not defined.');
	            return;
	        }
	        if (!options.child_grid) {
	            console.error('child_grid is not defined.');
	            return;
	        }
	        
	        var validate = _this.validateChildGrid(options.parent_grid, options.child_grid, options.key_field, options.self);
	        if (!validate.result) {
	            var target_object = validate.list[0][0];
	            if (target_object.parent_index != -1) {
	                options.parent_grid.select(target_object.parent_index);
	                validate = _this.validateChildGrid(options.parent_grid, options.child_grid, options.key_field, options.self);
	                target_object = validate.list[0][0];
	            }
	            var msg = '';
	            if (options.prefix_msg) {
	                msg += options.prefix_msg;
	            }
	            msg += '필수항목을 입력하지 않았습니다.' + '\n';
	            if (
	                target_object.index != -1
	                && options.show_row_number != false
	            ) {
	                options.child_grid.select(target_object.index);
	                msg += (target_object.index + 1) + '행 ';
	            }
	            msg += target_object.title;
	            dews.alert(msg, 'warning');
	        }
	        
	        return validate.result;
	    };

	    /**
	     * @desc		: Get id of form panel controls 
	     * @param1		: Form panel object
	     * @returnType	: Array
	     * */
	    this.getFormPanelControlId = function(form_panel) {
	    	var _this = this;
	    	
	        return form_panel.items.map(function(e) {
	            var element = e._$element.find('.dews-form-control')[0];

	            if (_this.isNull($(element).data('dews-control'))) {
	                element = $(element).find('.dews-form-control:eq(0)')[0];
	            }

	            return element.id;
	        });
	    };

	    /**
	     * @desc		: Get pc code for bizarea code 
	     * @param1		: Bizarea code
	     * @returnType	: String
	     * */
	    this.getPcInfoForBizareaCd = function(bizarea_cd) {
	    	var pc_cd = '';
	    	
	    	dews.api.get(
			    dews.url.getApiUrl('SD', 'SD_Z10062CommonService', 'get_pcInfo')
			    , {
			        async : false
			        , data : {
			            bizarea_cd : bizarea_cd
			        }
			    }
			).done(function(data) {
				pc_cd = data;
			}).fail(function(a, b, c) {
				dews.error(c);
			});
	    	
	    	return pc_cd;
	    };
	    
	    /**
	     * @desc		: Get all tree list 
	     * @param1		: Tree grid data items
	     * @returnType	: Array
	     * */
	    this.getAllTreeList = function(list) {
	        var result = []
	        , _this = this;
	        
	        list.forEach(function(e) {
	            result.push(e);
	            if (e.items != null) {
	            	_this.getAllTreeList(e.items).forEach(function(sub_e) {
	                    result.push(sub_e);
	                });
	            }
	        });
	        
	        return result;
	    };

	    
	    /**
	     * @desc		: Document common function object
	     * */
	    this.doc = new function() {
		    /**
		     * @desc		: Get document model
		     * @param1		: Api url
		     * @param2		: Api parameter
		     * @returnType	: Json Array
		     * */
		    this.getDocuModel = function(api_url, data) {
		        var docu_model;

		        dews.ajax.post(
	        		api_url
		            , {
		                async : false
		                , data : data
		            }
		        ).done(function(response) {
		            if (response.state != 'success') {
		                dews.error('전표모델 생성 중 에러가 발생하였습니다.');
		                dews.ui.loading.hide();
		                return;
		            }

		            docu_model = JSON.stringify(JSON.parse(response.data).fiDocuMst);
		        });

		        return docu_model;
		    };

		    /**
		     * @desc		: Preview document
		     * @param1		: Document preview main title
		     * @param2		: Document model
		     * @param3		: Ok callback function
		     * @returnType	: void
		     * */
		    this.previewDocu = function(preview_title, data, ok_callback_func) {
		        if (data.length > 0) {
		            var docuData = data;
		            var previewData = {
		                menuId : dews.ui.page.menu.id
		                , docuData : docuData
		                , mainTitle : preview_title
		            };            
		            var previewDialog = dews.ui.dialog('GLDDOC00500_PREVIEW', {
		                url : '/view/FI/GLDDOC00500_PREVIEW'
		                , title : '전표 미리보기'
		                , width : 720
		                , height : 586
		                , ok : ok_callback_func
		            });
		            previewDialog.setInitData(previewData);
		            previewDialog.open();
		        }
		        else {
		            dews.alert('전표를 발행할 데이터가 없습니다.', 'warning');
		        }
		    };

		    /**
		     * @desc		: Save document
		     * @param1		: Api url
		     * @param2		: Api data
		     * @param3		: Closed callback function
		     * @param4		: Error callback function
		     * @returnType	: void
		     * */
		    this.saveDocu = function(api_url, api_data, closed_callback_func, error_callback_func) {
		        dews.api.post(
	        		api_url
		            , {
		                async: false
		                , data: api_data
		            }
		        ).done(function (data) {
		            dews.ui.loading.hide();                   
		            dews.alert('['+data+'] 전표처리에 성공하였습니다.').on('closed', function() {
	                	if (closed_callback_func) {
		                	closed_callback_func();	
	                	}
		            });
		        }).fail(function (xhr, status, error) {
		            dews.ui.loading.hide();
		            dews.error('전표 생성중 에러가 발생하였습니다.').on('closed', function() {
			            dews.ui.dialog('errorDialog', {
			                content: error
			                , modal:false
			                , title: '전표 처리 검증 결과'
			                , width: 700
			                , height:400
			                , buttons:'close'
			                , resizable:true
			                , close : function (data) {
			                	if (error_callback_func) {
			                		error_callback_func(data);
			                	}
			                }
			            }).open();
		            });
		        });
		    };

		    /**
		     * @desc		: Cancel document
		     * @param1		: Api url
		     * @param2		: Api data
		     * @param3		: Closed callback function
		     * @param4		: Error callback function
		     * @returnType	: void
		     * */
		    this.cancelDocu = function(api_url, api_data, closed_callback_func, error_callback_func) {
		        dews.api.post(
	        		api_url
		            , {
		                async: false
		                , data: api_data
		            }
		        ).done(function (data) {
		            dews.ui.loading.hide();
		            dews.alert('['+data+'] 전표취소에 성공하였습니다.').on('closed', function() {
	                	if (closed_callback_func) {
		                	closed_callback_func();	
	                	}
		            });
		        }).fail(function (xhr, status, error) {
		            dews.ui.loading.hide();
		            dews.error('전표 취소중 에러가 발생하였습니다.').on('closed', function() {
			            dews.ui.dialog('errorDialog', {
			                content: error
			                , modal:false
			                , title: '전표 취소 검증 결과'
			                , width: 700
			                , height:400
			                , buttons:'close'
			                , resizable:true
			                , close : function (data) {
			                	if (error_callback_func) {
			                		error_callback_func(data);
			                	}
			                }
			            }).open();
		            });
		        });
		    };
	    };
	};
	
	window.gerp = $.extend(true, gerp, new function() {
		this[moduleCode] = module;
	});
})(window.gerp || {}, window.jQuery);

//# sourceURL=/CI/sd.common.js
