/*
 * @desc    CI 모듈 GroupWare 공통
 * @date    2022.01.12
 * @path    /view/js/ci.gw.common.js
 */

(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'CI_GW';

  dews.ajax.script('~/view/js/HR/hr.gw.util.js', {
    once: true,
    async: false
  });

  let ma_cm_js;
  dews.ajax.script('~/view/js/MA/ma.cm.js', {
    once: true,
    async: false
  }).done(function () {
    ma_cm_js = gerp.MA;
  });

  module.gw = {
    GroupWareStore : function (dewself) {
      var store = new Map();
      var gw_properties = {};
      // 그룹웨어 설정여부
      let gwConfigSettings = {
        CI00011 : ma_cm_js.CODE.getCiCtrlConfig("CI", "CI00011")
      }

      // GroupWare Properties 가져오기
      dews.ajax.script('~/view/js/CI/ci.gw.properties.js', {
        once: true,
        async: false
      }).done(function () {
        if(gerp.CI_GW_PROPERTIES){
          gw_properties = gerp.CI_GW_PROPERTIES.gw;
          formId_properties = gerp.CI_GW_PROPERTIES.formId;
        }
      });

      var api = {
        private : {
          setup : function(formInfo){
            var property = gw_properties[dewself.mainEnv.drsCode] || gw_properties["package"];

            /* GW구분
             * 1:사용안함  2:bizbox  3:전자결재
            */
            if(gwConfigSettings["CI00011"] == "2") {
              // formInfo : FORM_ID, GW_FORM_ID, GW_PROC_CD
              property = $.extend({}, property, formInfo);
            }

            /* formId별 설정 */
            if(formId_properties[property.FORM_ID]){
              var formId_property = formId_properties[property.FORM_ID][dewself.mainEnv.drsCode] || formId_properties[property.FORM_ID].package;
              if(formId_property){
                property = $.extend({}, property, formId_property);
                if(!property.gwServerUrl){
                  property.gwServerUrl =  gerp.CM.EltrAthzUtil.getApprovalUrl(property.url_type);
                }
                store.set(formInfo.FORM_ID, this.extendsAttr(property));
              }
            }
          },
          extendsAttr : function(property) {
            return {
              getProperty : function(){
                return property;
              },
              getHtmlContents : function(paramData){
                var htmlContents = null;

                dews.api.post(property.contents_url, {
                  async: false,
                  data: {
                    checkData : paramData,
                    type: "GW"
                  }
                }).done(function (data) {
                  if(data != null)
                    htmlContents = data;
                });

                return htmlContents;
              },
              /**
               * 전자결재 신청
               * @param {object} paramData 전자결재 신청을 위한 파라미터, 아래 sample 참고
               * paramData = {
               *   table_key_value : targetTable의 key값 배열  ex) ["1st_key_value", "2nd_key_value", "3rd_key_value"] (company_cd는 생략) : 필수
               *   mstGridData : self.mstGrid.dataItem(i) // 그리드 데이터, htmlContents 생성 시 사용, key는 임의대로 명명 가능
               *   dtlGridData : self.dtlGrid.dataItems()
               * }
               */
              approval : function(paramData) {
                var that = this;
                dews.ui.loading.show({
                  text : dews.localize.get("결재신청 진행중입니다.", "M0011658", "")
                });

                // GW_FORM_ID 체크
                if(!property.GW_FORM_ID){
                  dews.ui.loading.hide();
                  dews.ui.snackbar.error(dews.localize.get("전자결재양식등록에 등록되지 않은 서식 ID입니다.", '', '', ''));
                  return false;
                }

                // htmlContents 조회 및 체크
                var htmlContents = that.getHtmlContents(paramData.table_key_value[0]);
                if(!htmlContents){
                  dews.ui.loading.hide();
                  dews.ui.snackbar.error(dews.localize.get("서식이 등록되어있지 않습니다.", '', '', ''));
                  return false;
                }

                dews.api.post(dews.url.getApiUrl("CI", "CiCommonGwService", "approval"), {
                  async: false,
                  data: {
                    menu_id         : dewself.menu.id,
                    table_nm        : property.athz_rpts_table_nm,
                    gw_form_id      : property.GW_FORM_ID,
                    htmlContents    : htmlContents,
                    table_key_value : JSON.stringify(paramData.table_key_value),
                    postProcess_url : property.postProcess_url
                  }
                }).done(function(res){
                  if(res && res.error_type == null) {
                    that.openView({
                      mode : "W",
                      athz_rpts_cd : res.data[0].ATHZ_RPTS_CD,
                      loginId : res.aes_key
                    });
                    property.ATHZ_RPTS_CD = res.data[0].ATHZ_RPTS_CD;
                    dews.ui.snackbar.ok(dews.localize.get("결재신청 되었습니다.", '', '', ''));
                  }else{
                    dews.ui.snackbar.error(error);
                  }
                }).fail(function (xhr, status, error) {
                  dews.ui.snackbar.error(error);
                }).always(function(){
                  dews.ui.loading.hide();
                });

              },
              /**
               * 전자결재 openView
               * @param {object} data 전자결재 window Open을 위한 파라미터, 아래 sample 참고
               * data = {
               *  athz_rpts_cd  : 전자결재코드
               *  mode          : V(view모드) or W(상신모드-approval에서 사용) : 생략 시 V모드
               * }
               */
              openView : function(data){
                if(!data.loginId){
                  data.loginId = gerp.CM.EltrAthzUtil.getBizBoxLoginId();
                }
                if(!data.mode){
                  data.mode = "V";
                }

                var properties = {
                  toQueryString : function(obj) {
                    return Object.keys(obj).map(function(val) { return val+"="+obj[val]; }).join("&");
                  },
                  20171 : {
                    desc : "모트라스 주식회사",
                    FORM_ID : "",
                    GW_PROC_CD : "CI_WF01",
                    provider : "amaranth",
                    GROUPSEQ: ""
                  },
                  20172 : {
                    desc : "유니투스 주식회사",
                    FORM_ID : "",
                    GW_PROC_CD : "CI_WF01",
                    provider : "amaranth",
                    GROUPSEQ: ""
                  }
                }

                if(properties[dewself.mainEnv.drsCode] && properties[dewself.mainEnv.drsCode].provider =="amaranth"){

                  var gwApprovalData = {
                    compSeq: dewself.user.companyCode
                    , approKey: data.athz_rpts_cd
                    , outProcessCode: properties[dewself.mainEnv.drsCode].GW_PROC_CD
                    , formId:  properties[dewself.mainEnv.drsCode].FORM_ID
                    , mod: data.mode
                    , contentsType: "inner"
                    , contentsStr: ""
                    , loginId: data.loginId
                    , widthYn: true
                  }

                  // if (dewself.mainEnv.drsCode == '20171') { // 테스트용
                  //   gwApprovalData.groupSeq = 'klagoDev'
                  //   gwApprovalData.loginId = 'erp01'
                  //   gwApprovalData.outProcessCode = 'CI_WF01'
                  //   gwApprovalData.formId = '1103'
                  // } else {
                    gwApprovalData.loginId = dewself.user.userid;
                  // }

                  if (dewself.mainEnv.drsCode != 'dev' && properties[dewself.mainEnv.drsCode].desc == "portal" && gerp.CM.EltrAthzUtil.getCookieInfo(encodeURIComponent('am10:auth:token')) != undefined) {
                    var authtoken = decodeURIComponent(gerp.CM.EltrAthzUtil.getCookieInfo(encodeURIComponent('am10:auth:token')))
                    gwApprovalData.groupSeq = authtoken.split('|')[0];
                    gwApprovalData.loginId = dewself.user.userid;
                  }

                  if (data.mode == "W" && (data.file_dc != null || data.file_dcs != null)) {
                    gwApprovalData.fileKey = data.file_dc != null ? data.file_dc : data.file_dcs.join("|");
                  }

                  gwApprovalData.close = function() { dews.ui.mainbuttons.search.click()}
                  gerp.CM.EltrAthzUtil.createEltrAthz_amaranth(gwApprovalData);
                } else{
                  gerp.CM.EltrAthzUtil.createEltrAthz(property.gwServerUrl, {
                    params : {
                      compSeq : dewself.user.companyCode
                      ,approKey : data.athz_rpts_cd
                      ,outProcessCode : property.GW_PROC_CD
                      ,formId : property.GW_FORM_ID
                      ,mod : data.mode
                      ,contentsType : "inner"
                      ,contentsStr: ""
                      ,loginId : data.loginId
                      ,widthYn : true
                    },
                    close : function(e) {
                      dews.api.post(dews.url.getApiUrl("CI", "CiCommonGwService", "close_event"), {
                        async: false,
                        data: {
                          menu_id         : dewself.menu.id,
                          table_nm        : property.athz_rpts_table_nm,
                          key_code        : property.ATHZ_RPTS_CD,
                        }
                      }).done(function(res){
                      }).fail(function (xhr, status, error) {
                        dews.ui.snackbar.error(error);
                      }).always(function(){
                        dews.ui.loading.hide();
                      });
                      property.gwWindow_close_event();
                    }
                  });
                }
              }
            };
          }
        },
        public : {
          get : function(menuid) {
            return store.get(menuid);
          },
        }
      }

      // 전자결재양식등록에 있는 해당 메뉴 서식ID 리스트
      var formInfoList = null;
      dews.api.get(dews.url.getApiUrl("CI", "CiCommonGwService", "getListFormId"), {
        async: false,
        data: {
          menuId : dewself.menu.id
        }
      }).done(function (data){
        formInfoList = data;
      });

      // 전자결재 설정 setup
      if(formInfoList != null){
        $.each(formInfoList, function(idx, item){
          api.private.setup(item);
        });
      }

      return api.public;
    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/CI/ci.gw.common.js
