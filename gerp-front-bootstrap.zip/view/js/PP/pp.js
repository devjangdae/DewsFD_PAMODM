/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
 * @desc    PP 모듈 공통 함수
 * @author  yklee
 * @date    2018.04.09
 * @path    /view/js/pp.js
 */
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'PP';  //모듈 코드

  //------------------------------------------Start------------------------------------------
  //

  //공통
  module.com = {
    /* --------------------------------------------------------------------------------------------
     *  @desc       현재년월일 구하기
     *  @return     yyyyMMdd
     * ------------------------------------------------------------------------------------------*/
    getToday: function () {
      var today = new Date();
      return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
        + (today.getDate()).toString().replace(/^(\d)$/, "0$1");
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       현재년월 구하기
     *  @return     yyyyMM
     * ------------------------------------------------------------------------------------------*/
    getYearMonth: function () {
      var today = new Date();
      return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1");
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       현재년도 구하기
     *  @return     yyyy
     * ------------------------------------------------------------------------------------------*/
    getYear: function () {
      var today = new Date();
      return today.getFullYear().toString();
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       현재월 구하기
     *  @return     MM
     * ------------------------------------------------------------------------------------------*/
    getMonth: function () {
      var today = new Date();
      return (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1");
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       현재일 구하기
     *  @return     dd
     * ------------------------------------------------------------------------------------------*/
    getDate: function () {
      var today = new Date();
      return (today.getDate()).toString().replace(/^(\d)$/, "0$1");
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       오늘기준 이전날짜 구하기
     *  @param      i 오늘날짜 기준 구할 전일날짜(day)
     *  @return     yyyyMMdd
     * ------------------------------------------------------------------------------------------*/
    getDateFromToday: function (i) {
      var today = new Date();
      var ty = today.getFullYear();
      var tm = today.getMonth() + 1;
      var td = today.getDate();
      if (tm < 10) tm = "0" + tm;
      if (td < 10) td = "0" + td;

      targetDay = new Date(today.valueOf() + (24 * 60 * 60 * 1000) * i);
      ty = targetDay.getFullYear();
      tm = targetDay.getMonth() + 1;
      td = targetDay.getDate();
      if (tm < 10) tm = "0" + tm;
      if (td < 10) td = "0" + td;
      return String(ty) + String(tm) + String(td);
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       Y, N 드롭다운 초기화 사용
     *  @return     Array
     * ------------------------------------------------------------------------------------------*/
    getYNddl: function () {
      return [{ SYSDEF_CD: "Y", SYSDEF_NM: "Yes" }, { SYSDEF_CD: "N", SYSDEF_NM: "No" }]; /* @.@ CD_SYSDEF 변환 선택 => SYSDEF_CD (SYSDEF_CD,SYSBASE_CD) */ /* @.@ NM_SYSDEF 변환 선택 => SYSDEF_NM (SYSDEF_NM,SYSBASE_NM) */ /* @.@ CD_SYSDEF 변환 선택 => SYSDEF_CD (SYSDEF_CD,SYSBASE_CD) */ /* @.@ NM_SYSDEF 변환 선택 => SYSDEF_NM (SYSDEF_NM,SYSBASE_NM) */
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       다음선순서구하기
     *  @param      다음 순서를 구할 기본문자
     *  @return     str
     * ------------------------------------------------------------------------------------------*/
    getNextPrefix: function (str) {
      var len = 0;

      if (str != undefined) len = str.length;

      var regType = /^[0-9]*$/;

      if (!regType.test(str)) {
        return 10;
      } else {
        var strValue = str;
        var strIdx = 0;
        for (i = 0; i < strValue.length; i++) {
          var retChar = strValue.substr(i, 1).toUpperCase();

          if (retChar != 0) {
            strIdx = i;
            break;
          }
        }

        var sub = str.substring(strIdx, len);

        sub = parseInt(sub) + 10;
        return pad(sub, len);
      }
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       자릿수 0으로 채우기
     *  @param      n : 숫자, w : 채울 자리길이
     *  @return     str
     * ------------------------------------------------------------------------------------------*/
    pad: function (n, w) {
      n = n + '';
      return n.length >= w ? n : new Array(w - n.length + 1).join('0') + n;
    },
    /* --------------------------------------------------------------------------------------------
     *  @desc       Grid uid생성
     *  @return     str
     * ------------------------------------------------------------------------------------------*/
    guid: function () {
      return 'xxxxxxxx-xxxx-4xxx-9xxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    }
  }

  //API
  module.api = {

    /* --------------------------------------------------------------------------------------------
      *  @no             01
      *  @desc           공통코드조회
      *  @ex             getCodeData("PP", "P00090|P00100|", null, null, null, null, null);
      *  @memo           이 함수를 타기전에 셋팅하는 부분을 타는 경우는 에러발생함.
      * --------------------------------------------------------------------------------------------
      *  @cd_module      모듈코드
      *  @cd_field_pipe  코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
      *  @yn_sycode      시스템코드 유무(Y,N)
      *  @yn_foreign     외국언어적용 유무(Y,N)- Y : NM_SYSDEF2, N : NM_SYSDEF
      *  @dt_end         종료일-종료일이 있는 경우 종료일 이전 데이터 제외
      *  @nm_keyword     검색할 코드 또는 명
      * ------------------------------------------------------------------------------------------*/
    getCodeData: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword) { /* #.# cd_module 변환됨 => module_cd */ /* #.# yn_default 변환됨 => base_yn */ /* @.@ dt_end 변환 선택 => end_dt (end_dt,dept_end_dt) */

      var objCodeDtl = {};

      if (!objCodeDtl.hasOwnProperty(module_cd)) { objCodeDtl[module_cd] = {}; } /* #.# cd_module 변환됨 => module_cd */ /* #.# cd_module 변환됨 => module_cd */
      $.each(cd_field_pipe.split("|"), function (i, v) {
        if (v != null && v != "") { objCodeDtl[module_cd][v] = []; } /* #.# cd_module 변환됨 => module_cd */
      });
      dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
        async: false,
        data: {
          module_cd: module_cd, /* #.# cd_module 변환됨 => module_cd */ /* #.# cd_module 변환됨 => module_cd */
          cd_field_pipe: cd_field_pipe,
          yn_sycode: yn_sycode,
          base_yn: base_yn, /* #.# yn_default 변환됨 => base_yn */ /* #.# yn_default 변환됨 => base_yn */
          yn_foreign: yn_foreign,
          end_dt: end_dt, /* @.@ dt_end 변환 선택 => end_dt (end_dt,dept_end_dt) */ /* @.@ dt_end 변환 선택 => end_dt (end_dt,dept_end_dt) */
          nm_keyword: nm_keyword,
        }
      }).done(function (data) {
        if (data.length > 0) {
          $.each(data, function (i, obj) {
            objCodeDtl[module_cd][obj.FIELD_CD].push(obj); /* #.# cd_module 변환됨 => module_cd */ /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */
            tmpCdField = obj.FIELD_CD; /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */
          });
        }
      }).fail(function (xhr, status, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.'));
      });

      return objCodeDtl;
    },
    /* --------------------------------------------------------------------------------------------
      *  @no             02
      *  @desc           에러다이얼로그열기
      *  @memo           SCM공통 에러처리
      * --------------------------------------------------------------------------------------------
      *  @e              에러배열
      * ------------------------------------------------------------------------------------------*/
    openErrorDialog: function (e) {
      var location = window.location.href;
      if (location.indexOf('localhost') > -1 || location.indexOf('10.35.13') > -1) {
        // 로컬일 경우 팝업창 띄움
        var initData = { err: e };
        dialog = dews.ui.dialog("SOPOPP00504_POP",
          {
            url: "/view/PP/SOPOPP00504_POP",
            title: "에러확인",
            width: "600",
            height: "400",
            ok: function (data, e) {
            }
          });
        dialog.setInitData(initData);
        dialog.open();
      } else {
        // 이외의 접속인 경우 console로 처리(개발서버, 데모서버, ...)
        $.each(e, function (idx, item) {
          if (idx == 0) {
            console.log('1. Error Type : ' + item);
          } else if (idx == 1) {
            console.log('2. Error Class : ' + item);
          } else if (idx == 2) {
            console.log('3. Error Method : ' + item);
          } else if (idx == 3) {
            console.log('4. Error Line : ' + item);
          } else if (idx == 4) {
            console.log('5. Error Log : ' + item);
          }
        });
      }
    },
    getPpCtrlConfig: function (plant_cd) {
      var objCtrlConfig = {};

      dews.api.get(dews.url.getApiUrl("PP", "PpCommonService", dews.string.format("PP_CTRLCONFIG_MST_list")), {
        async: false,
        data: {
          plant_cd: plant_cd
        }
      }).done(function (data) {
        if (data.length > 0) {
          $.each(data, function (i, obj) {
            objCtrlConfig[obj.CTRL_CD] = obj;
          });
        }
      }).fail(function (xhr, status, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.'));
      });

      return objCtrlConfig;
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc       backendService 버전정보 리턴 (콘솔 log 찍습니다.)
    *  @return     versionInfo
    *  @call       PP_UTIL.getVersion('1.0.22102101', 'PPCustomCodeHelpService')
    * ------------------------------------------------------------------------------------------*/
    getVersion: function (frontEndVersion, backEndServiceName) {
      var versionInfo = { frontEndVersion: frontEndVersion, backEndVersion: '' };
      dews.api.get(dews.url.getApiUrl('CM', 'ServiceVersion'), {
        async: false,
        data: {
          service: backEndServiceName
        }
      }).done(function (data) {
        if (data && data.length > 0) {
          versionInfo.backEndVersion = data;
        }
      }).fail(function (xhr, status, error) {
        setTimeout(function () {
          dews.error('오류가 발생하였습니다.');
        }, 200);
        console.error(error);
      });
      console.log("%c■ 버전정보", 'color: rgb(0,  84,  255)')
      console.log("> FrontEnd-Version : " + versionInfo.frontEndVersion);
      console.log("> BackEnd-Version : " + versionInfo.backEndVersion);
      return versionInfo;
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc           회사환경설정 통제값 조회
    *  @ex             getCmpyEnvControl(module_cd, ctrl_cd)
    * --------------------------------------------------------------------------------------------*/
    getCmpyEnvControl: function (module_cd, ctrl_cd) {
      /******회사환경설정등록******/
      // 회사환경설정 : 모듈(PS), 통제코드(BC00000), 통제코드명([1.예산통제]여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00010), 통제코드명([1-1. 집계공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
      // 회사환경설정 : 모듈(PS), 통제코드(BC00020), 통제코드명([1-2. 집계공종]경고알림 여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00030), 통제코드명([1-2-1. 집계공종]경고수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00040), 통제코드명([1-2-2. 집계공종]통제수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00050), 통제코드명([1-3. 내역공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
      // 회사환경설정 : 모듈(PS), 통제코드(BC00060), 통제코드명([1-4. 내역공종]경고알림 여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00070), 통제코드명([1-4-1. 내약공종]경고수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00080), 통제코드명([1-4-2.내역공종]통제수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00090), 통제코드명([실행예산]실행예산 Sync 시점), 1:실행예산요청시, 2:실행예산승인시
      // 회사환경설정 : 모듈(PS), 통제코드(BC00100), 통제코드명(외주변경계약 위치), 1:외주계약등록, 2:외주발주품의등록
      // 회사환경설정 : 모듈(PS), 통제코드(PS00000), 통제코드명(기준정보)
      // 회사환경설정 : 모듈(PS), 통제코드(PS00010), 통제코드명(예산연동여부), Y : Yes  N : No
      // 회사환경설정 : 모듈(PS), 통제코드(PS00020), 통제코드명(실행예산연동여부), Y : Yes  N : No
      var isCmpyEnvControl = null;
      {
        dews.api.get(dews.url.getApiUrl('PP', 'PpCommonService', 'PPApiProvider_Get_Company_Control'), {
          async: false,
          data: {
            module_cd: module_cd,
            ctrl_cd: ctrl_cd  // 사업계획 사용여부
          }
        }).done(function (data) {
          isCmpyEnvControl = data;
        }).fail(function (xhr, status, error) {
          setTimeout(function () {
            dews.error('오류가 발생하였습니다.');
          }, 200);
          console.error(error);
        });
      }
      return isCmpyEnvControl;
    },

    /* --------------------------------------------------------------------------------------------
    *  @desc           회사환경설정 조회
    *  @ex             getCmpyEnvControlInfo("PS", "PS00185", "FORMAT_VR")
    *
    * --------------------------------------------------------------------------------------------*/
    getCmpyEnvControlInfo: function (module_cd, ctrl_cd, col_cd) {
      /******회사환경설정등록******/
      // 회사환경설정 : 모듈(PS), 통제코드(BC00000), 통제코드명([1.예산통제]여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00010), 통제코드명([1-1. 집계공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
      // 회사환경설정 : 모듈(PS), 통제코드(BC00020), 통제코드명([1-2. 집계공종]경고알림 여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00030), 통제코드명([1-2-1. 집계공종]경고수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00040), 통제코드명([1-2-2. 집계공종]통제수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00050), 통제코드명([1-3. 내역공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
      // 회사환경설정 : 모듈(PS), 통제코드(BC00060), 통제코드명([1-4. 내역공종]경고알림 여부), Y:Yes,  N:No
      // 회사환경설정 : 모듈(PS), 통제코드(BC00070), 통제코드명([1-4-1. 내약공종]경고수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00080), 통제코드명([1-4-2.내역공종]통제수준)
      // 회사환경설정 : 모듈(PS), 통제코드(BC00090), 통제코드명([실행예산]실행예산 Sync 시점), 1:실행예산요청시, 2:실행예산승인시
      // 회사환경설정 : 모듈(PS), 통제코드(BC00100), 통제코드명(외주변경계약 위치), 1:외주계약등록, 2:외주발주품의등록
      // 회사환경설정 : 모듈(PS), 통제코드(PS00000), 통제코드명(기준정보)
      // 회사환경설정 : 모듈(PS), 통제코드(PS00010), 통제코드명(예산연동여부), Y : Yes  N : No
      // 회사환경설정 : 모듈(PS), 통제코드(PS00020), 통제코드명(실행예산연동여부), Y : Yes  N : No
      var isCmpyEnvControl = null;
      {
        dews.api.get(dews.url.getApiUrl('PP', 'PpCommonService', 'PPApiProvider_Get_Company_Control_API'), {
          async: false,
          data: {
            module_cd: module_cd,
            ctrl_cd: ctrl_cd  // 사업계획 사용여부
          }
        }).done(function (data) {
          if (data) {
            isCmpyEnvControl = data[col_cd];
          }
        }).fail(function (xhr, status, error) {
          setTimeout(function () {
            dews.error('오류가 발생하였습니다.');
          }, 200);
          console.error(error);
        });
      }
      return isCmpyEnvControl;
    }
  }


  //-------------------------------------------End-------------------------------------------

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=pp.js
