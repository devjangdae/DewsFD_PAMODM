/* PS pollfill
 * /view/js/ps.polyfill.js
 * 2020-10-22 곽민기 : hr.common.js 참조하여 polyfill 작성(Object.assign, Math.trunc, Array.includes, String.prototype.repeat, array.prototype.findindex)
 */
// Polyfill 정의구간
(function() {
  // Object.assign
  if (typeof Object.assign != 'function') {
    // Must be writable: true, enumerable: false, configurable: true
    Object.defineProperty(Object, "assign", {
      value: function assign(target, varArgs) { // .length of function is 2
        'use strict';
        if (target == null) { // TypeError if undefined or null
          throw new TypeError('Cannot convert undefined or null to object');
        }

        var to = Object(target);

        for (var index = 1; index < arguments.length; index++) {
          var nextSource = arguments[index];

          if (nextSource != null) { // Skip over if undefined or null
            for (var nextKey in nextSource) {
              // Avoid bugs when hasOwnProperty is shadowed
              if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
                to[nextKey] = nextSource[nextKey];
              }
            }
          }
        }
        return to;
      },
      writable: true,
      configurable: true
    });
  }

  if (typeof Math.trunc != 'function') {
    Math.trunc = Math.trunc || function(x) {
      if (isNaN(x)) {
        return NaN;
      }
      if (x > 0) {
        return Math.floor(x);
      }
      return Math.ceil(x);
    };
  }
  //2020-05-25 added
  if (!Array.prototype.includes) {
		Object.defineProperty(Array.prototype, 'includes', {
		value: function (searchElement, fromIndex) {

		  if (this == null) {
			throw new TypeError('"this" is null or not defined');
		  }

		  // 1. Let O be ? ToObject(this value).
		  var o = Object(this);

		  // 2. Let len be ? ToLength(? Get(O, "length")).
		  var len = o.length >>> 0;

		  // 3. If len is 0, return false.
		  if (len === 0) {
			return false;
		  }

		  // 4. Let n be ? ToInteger(fromIndex).
		  //    (If fromIndex is undefined, this step produces the value 0.)
		  var n = fromIndex | 0;

		  // 5. If n ≥ 0, then
		  //  a. Let k be n.
		  // 6. Else n < 0,
		  //  a. Let k be len + n.
		  //  b. If k < 0, let k be 0.
		  var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

		  function sameValueZero(x, y) {
			return x === y || (typeof x === 'number' && typeof y === 'number' && isNaN(x) && isNaN(y));
		  }

		  // 7. Repeat, while k < len
		  while (k < len) {
			// a. Let elementK be the result of ? Get(O, ! ToString(k)).
			// b. If SameValueZero(searchElement, elementK) is true, return true.
			if (sameValueZero(o[k], searchElement)) {
			  return true;
			}
			// c. Increase k by 1.
			k++;
		  }

		  // 8. Return false
		  return false;
		}
	  });
  }

  // String.prototype.repeat() polyfill
  if (!String.prototype.repeat) {
    String.prototype.repeat = function(count) {
      'use strict';
      if (this == null) {
        throw new TypeError('can\'t convert ' + this + ' to object');
      }
      var str = '' + this;
      count = +count;
      if (count != count) {
        count = 0;
      }
      if (count < 0) {
        throw new RangeError('repeat count must be non-negative');
      }
      if (count == Infinity) {
        throw new RangeError('repeat count must be less than infinity');
      }
      count = Math.floor(count);
      if (str.length == 0 || count == 0) {
        return '';
      }
      // Ensuring count is a 31-bit integer allows us to heavily optimize the
      // main part. But anyway, most current (August 2014) browsers can't handle
      // strings 1 << 28 chars or longer, so:
      if (str.length * count >= 1 << 28) {
        throw new RangeError('repeat count must not overflow maximum string size');
      }
      var maxCount = str.length * count;
      count = Math.floor(Math.log(count) / Math.log(2));
      while (count) {
         str += str;
         count--;
      }
      str += str.substring(0, maxCount - str.length);
      return str;
    }
  }

  // https://tc39.github.io/ecma262/#sec-array.prototype.findindex
  if (!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
      value: function(predicate) {
      // 1. Let O be ? ToObject(this value).
        if (this == null) {
          throw new TypeError('"this" is null or not defined');
        }

        var o = Object(this);

        // 2. Let len be ? ToLength(? Get(O, "length")).
        var len = o.length >>> 0;

        // 3. If IsCallable(predicate) is false, throw a TypeError exception.
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }

        // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
        var thisArg = arguments[1];

        // 5. Let k be 0.
        var k = 0;

        // 6. Repeat, while k < len
        while (k < len) {
          // a. Let Pk be ! ToString(k).
          // b. Let kValue be ? Get(O, Pk).
          // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
          // d. If testResult is true, return k.
          var kValue = o[k];
          if (predicate.call(thisArg, kValue, k, o)) {
            return k;
          }
          // e. Increase k by 1.
          k++;
        }

        // 7. Return -1.
        return -1;
      },
      configurable: true,
      writable: true
    });
  }

})();


// ps.polyfill.js start
(function (dews, derp, $) {
  var module = {};
  var moduleCode = "PS";
  var newModule = {};
  var addSentence = "_A";

  console.log("[ LOAD :: ps.polyfill.js ]");

  newModule[moduleCode] = module;
  window.derp = $.extend(true, derp, newModule);
})(window.dews, window.derp || {}, jQuery);

//# sourceURL=ps.polyfill.js
