/*
 * @desc    PS 모듈 공통 함수
 * @author  이현태(hyeontae.lee)
 * @date    2019.03.22
 * @path    /view/js/ps/ps.js
 *
 * @ex      var PS_UTIL;
            dews.ajax.script('~/view/js/PS/ps.js', {
              once: true,
              async: false
            }).done(function () {
              PS_UTIL = gerp.PS.UTIL;
            });
            var objCodeDtl = PS_UTIL.getCodeData("PS", "Y:P00730|N:P00790|", null, null, null, null, null);
 */
            (function (dews, gerp, $) {
              var module = {};
              var moduleCode = 'PS';  //모듈 코드
              var objCodeDtl = {};
              var AddField = new Array(); // xlsList함수에서 데이터소스 field설정에 사용.
            
              //------------------------------------------Start------------------------------------------
              //
            
              function VerifyNode(msg, rowId, target, gridName, tabItem) {
                this.msg = msg;
                this.rowId = rowId;
                this.target = target;
              }
            
            
              //API
              module.UTIL = {
                /* --------------------------------------------------------------------------------------------
                  *  @desc       업체별 DRS CODE를 리턴합니다.
                  *  @return     drsCode
                  *              개발서버 : 10012
                  *              동서발전 : 10005
                  *  @call       PS_UTIL.getDRS_CODE()
                  * ------------------------------------------------------------------------------------------*/
                getDRS_CODE: function () {
                  return dews.app.drsCode;
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       현재년월일 or 파라미터Date의 년월일 구하기
                  *  @return     yyyyMMdd
                  *  @call       getToday()
                  * ------------------------------------------------------------------------------------------*/
                getToday: function (date) {
                  if (typeof (date) == "string") {
                    return date;
                  }
                  else if (typeof (date) == "number") {
                    return String(date);
                  }
                  else {
                    if (date) {
                      return date.getFullYear().toString() + (date.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
                        + (date.getDate()).toString().replace(/^(\d)$/, "0$1");
                    } else {
                      var today = new Date();
                      return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
                        + (today.getDate()).toString().replace(/^(\d)$/, "0$1");
                    }
                  }
                },
                getTime: function (date) {
                  if (date) {
                    return date.getHours().toString().replace(/^(\d)$/, "0$1") + date.getMinutes().toString().replace(/^(\d)$/, "0$1");
                  } else {
                    var today = new Date();
                    return today.getHours().toString().replace(/^(\d)$/, "0$1") + today.getMinutes().toString().replace(/^(\d)$/, "0$1");
                  }
                },
                getTodayMonAdd: function (mon) {
                  var today = new Date();
                  today.setMonth(today.getMonth() + mon);
                  return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
                    + (today.getDate()).toString().replace(/^(\d)$/, "0$1");
                },
                getToday_slash: function (date) {
                  if (date) {
                    return date.getFullYear().toString() + "/" + (date.getMonth() + 1).toString().replace(/^(\d)$/, "0$1") + "/"
                      + (date.getDate()).toString().replace(/^(\d)$/, "0$1");
                  } else {
                    var today = new Date();
                    return today.getFullYear().toString() + "/" + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1") + "/"
                      + (today.getDate()).toString().replace(/^(\d)$/, "0$1");
                  }
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       현재년월일시를 아래 포맷으로 리턴합니다.
                  *  @return     2020-03-12 13:58:30
                  *  @call       getTimeStamp()
                  * ------------------------------------------------------------------------------------------*/
                getTimeStamp: function () {
                  var d = new Date();
                  var s =
                    gerp.PS.UTIL.leadingZeros(d.getFullYear(), 4) + '-' +
                    gerp.PS.UTIL.leadingZeros(d.getMonth() + 1, 2) + '-' +
                    gerp.PS.UTIL.leadingZeros(d.getDate(), 2) + ' ' +
            
                    gerp.PS.UTIL.leadingZeros(d.getHours(), 2) + ':' +
                    gerp.PS.UTIL.leadingZeros(d.getMinutes(), 2) + ':' +
                    gerp.PS.UTIL.leadingZeros(d.getSeconds(), 2);
                  return s;
                },
                leadingZeros: function (n, digits) {
                  var zero = '';
                  n = n.toString();
            
                  if (n.length < digits) {
                    for (i = 0; i < digits - n.length; i++)
                      zero += '0';
                  }
                  return zero + n;
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       현재년월 구하기
                  *  @return     yyyyMM
                  *  @call       getYearMonth()
                  * ------------------------------------------------------------------------------------------*/
                getYearMonth: function () {
                  var today = new Date();
                  return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1");
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       파라미터로 전달받은 Date타입의 날짜를 String타입의 년월로 리턴한다.
                  *  @return     yyyyMM
                  *  @call       getYearMonth_P()
                  * ------------------------------------------------------------------------------------------*/
                getYearMonth_P: function (date) {
                  return date.getFullYear().toString() + (date.getMonth() + 1).toString().replace(/^(\d)$/, "0$1");
                },
                /* --------------------------------------------------------------------------------------------
                    *  @desc       파라미터로 전달받은 Date타입의 날짜를 다시 Date타입으로 리턴한다. 기존객체값은 보존함. 날짜객체의 값만 복사함.
                    *  @return     new Date()
                    *  @call       newDate()
                    * ------------------------------------------------------------------------------------------*/
                newDate: function (date) {
                  var newDate = new Date(date.getFullYear()
                    , date.getMonth()
                    , date.getDate());
                  return newDate;
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       현재년도 구하기
                  *  @return     yyyy
                  *  @call       getYear()
                  * ------------------------------------------------------------------------------------------*/
                getYear: function () {
                  var today = new Date();
                  return today.getFullYear().toString();
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       현재월 구하기
                  *  @return     MM
                  *  @call       getMonth()
                  * ------------------------------------------------------------------------------------------*/
                getMonth: function () {
                  var today = new Date();
                  return (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1");
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       현재일 구하기
                  *  @return     dd
                  *  @call       getDate()
                  * ------------------------------------------------------------------------------------------*/
                getDate: function () {
                  var today = new Date();
                  return (today.getDate()).toString().replace(/^(\d)$/, "0$1");
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       오늘기준 이전날짜 구하기
                  *  @param      i 오늘날짜 기준 구할 전일날짜(day)
                  *  @return     yyyyMMdd
                  *  @call       getDateFromToday(i)
                  * ------------------------------------------------------------------------------------------*/
                getDateFromToday: function (i) {
                  var today = new Date();
                  var ty = today.getFullYear();
                  var tm = today.getMonth() + 1;
                  var td = today.getDate();
                  if (tm < 10) tm = "0" + tm;
                  if (td < 10) td = "0" + td;
            
                  targetDay = new Date(today.valueOf() + (24 * 60 * 60 * 1000) * i);
                  ty = targetDay.getFullYear();
                  tm = targetDay.getMonth() + 1;
                  td = targetDay.getDate();
                  if (tm < 10) tm = "0" + tm;
                  if (td < 10) td = "0" + td;
                  return String(ty) + String(tm) + String(td);
                },
                getDateDiff: function (_date1, _date2) {
                  var diffDate_1 = _date1 instanceof Date ? _date1 : new Date(_date1);
                  var diffDate_2 = _date2 instanceof Date ? _date2 : new Date(_date2);
            
                  diffDate_1 = new Date(diffDate_1.getFullYear(), diffDate_1.getMonth() + 1, diffDate_1.getDate());
                  diffDate_2 = new Date(diffDate_2.getFullYear(), diffDate_2.getMonth() + 1, diffDate_2.getDate());
            
                  var diff = Math.abs(diffDate_2.getTime() - diffDate_1.getTime());
                  diff = Math.ceil(diff / (1000 * 3600 * 24));
            
                  return diff;
                },
                getStrDateDiff: function (str_date1, str_date2) {
                  var _date1 = new Date(str_date1.substring(0, 4), str_date1.substring(4, 6), str_date1.substring(6, 8));
                  var _date2 = new Date(str_date2.substring(0, 4), str_date2.substring(4, 6), str_date2.substring(6, 8));
                  var diffDate_1 = _date1 instanceof Date ? _date1 : new Date(_date1);
                  var diffDate_2 = _date2 instanceof Date ? _date2 : new Date(_date2);
            
                  diffDate_1 = new Date(diffDate_1.getFullYear(), diffDate_1.getMonth() + 1, diffDate_1.getDate());
                  diffDate_2 = new Date(diffDate_2.getFullYear(), diffDate_2.getMonth() + 1, diffDate_2.getDate());
            
                  var diff = Math.abs(diffDate_2.getTime() - diffDate_1.getTime());
                  diff = Math.ceil(diff / (1000 * 3600 * 24));
            
                  return diff;
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       Y, N 드롭다운 초기화 사용
                  *  @return     Array
                  *  @call       getYNddl()
                  * ------------------------------------------------------------------------------------------*/
                getYNddl: function () {
                  return [{ SYSDEF_CD: "Y", SYSDEF_NM: "Yes" }, { SYSDEF_CD: "N", SYSDEF_NM: "No" }]; /* @.@ CD_SYSDEF 변환 선택 => SYSDEF_CD (SYSDEF_CD,SYSBASE_CD) */ /* @.@ NM_SYSDEF 변환 선택 => SYSDEF_NM (SYSDEF_NM,SYSBASE_NM) */ /* @.@ CD_SYSDEF 변환 선택 => SYSDEF_CD (SYSDEF_CD,SYSBASE_CD) */ /* @.@ NM_SYSDEF 변환 선택 => SYSDEF_NM (SYSDEF_NM,SYSBASE_NM) */
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       left 함수 작성
                  *  @return     str
                  *  @call       left(str, length)
                  * ------------------------------------------------------------------------------------------*/
                left: function (str, length) {
                  var new_str = String(str);
                  if (length <= 0) return "";
                  else if (new_str.length <= length) return new_str;
                  else return new_str.substring(0, length);
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       right 함수 작성
                  *  @return     str
                  *  @call       right(str, length)
                  * ------------------------------------------------------------------------------------------*/
                right: function (str, length) {
                  var new_str = String(str);
                  if (length <= 0) return "";
                  else if (new_str.length <= length) return new_str;
                  else return new_str.substring(new_str.length - length, new_str.length);
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       mid 함수 작성
                  *  @return     str
                  *  @call       mid(str, start, length)
                  * ------------------------------------------------------------------------------------------*/
                mid: function (str, start, length) {
                  var new_str = String(str);
                  if (length <= 0) return "";
                  else if (new_str.length < start) return "";
                  else if (new_str.length <= length) return new_str;
                  return gerp.PS.UTIL.left(gerp.PS.UTIL.right(new_str, new_str.length - start), length);
                },
                replaceAll: function (str, searchStr, replaceStr) {
                  return str.split(searchStr).join(replaceStr);
                },
            
            
                /**
                 * 이메일
                 * @example VALIDATE.isEmail('genius@douzone.com');
                 * @param {*} value: 이메일주소
                 * @return {*} boolean
                 */
                isEmail: function (value) {
                  try {
                    var regExp = /[0-9a-zA-Z][_0-9a-zA-Z-]*@[_0-9a-zA-Z-]+(\.[_0-9a-zA-Z-]+){1,2}$/;
            
                    if (this.isNotNull(value)) {
                      if (this.nvl(value.match(regExp), '') == '') {
                        dews.ui.snackbar.warning('이메일이 잘못되었습니다.', 'warning');
                        return false;
                      } else {
                        return true;
                      }
                    } else {
                      return true;
                    }
                  } catch (error) {
                    return false;
                  }
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc       숫자만 추출하기.
                  *  @return     '123'
                  *  @call       PS_UTIL.replaceOnlyNumber('_1a23')
                  * ------------------------------------------------------------------------------------------*/
                replaceOnlyNumber: function (str) {
                  var res;
                  if (str == null) {
                    return str;
                  }
                  res = String(str).replace(/[^0-9]/g, "");
                  return res;
                },
                /**
                 * 정수만입력가능(keyDown이벤트에서 사용가능합니다.)
                 * @example PS_UTIL.onlyNumber(e, exceptionList);
                 * @param {*} event: keyDown이벤트
                 * @param {*} exceptionList : 추가로 입력가능한 예외키코드
                 *                          : var exceptionList = [];
                                              exceptionList.push('188'); -> 콤마
                  * @return {*} boolean
                  */
                onlyNumber: function (event, exceptionList) {
                  //event = event || window.event;
            
                  console.log('event.key' + '/ ' + event.key);
                  console.log('event.which' + '/ ' + event.which);
                  console.log('event.keyCode' + '/ ' + event.keyCode);
            
                  var keyID = (event.which) ? event.which : event.keyCode;
            
                  if (exceptionList) {
                    for (var i = 0; i < exceptionList.length; i++) {
                      if (keyID == exceptionList[i]) {
                        return;
                      }
                    }
                  }
            
                  if ((keyID >= 35 && keyID <= 36) //35:HOME, 36:END
                    //|| (event.ctrlKey == true && (keyID == 67 ||  keyID == 86) ) Copy&Paste
                    || (keyID >= 48 && keyID <= 57)   //0~9
                    || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
                    || (keyID >= 37 && keyID <= 40)   //방향키
                    || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46/*|| keyID == 109 || keyID == 189*/ //8:백스페이스, 13:Enter, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
                  )
                    return;
                  else {
                    event.preventDefault();
                    return;
                  }
                },
            
                removeNotNumber: function (event) {
                  //event = event || window.event;
            
                  console.log('event.key' + '/ ' + event.key);
                  console.log('event.which' + '/ ' + event.which);
                  console.log('event.keyCode' + '/ ' + event.keyCode);
            
                  var keyID = (event.which) ? event.which : event.keyCode;
                  if ((keyID >= 35 && keyID <= 36) //35:HOME, 36:END
                    || (event.ctrlKey == true && (keyID == 67 || keyID == 86)) //Copy&Paste
                    || (keyID >= 48 && keyID <= 57)   //0~9
                    || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
                    || (keyID >= 37 && keyID <= 40)   //방향키
                    || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46 /*|| keyID == 109 || keyID == 189*/ //8:백스페이스, 13:Enter, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
                  )
                    return;
                  else {
            
                    console.log('removeNotNumber' + '/ ' + event.target.value + '/ ' + event.target.value.replace(/[^0-9]/g, ""));
                    event.target.value = event.target.value.replace(/[^0-9]/g, "");
                  }
                },
            
                onlyPhoneNumber: function (event) {
                  //event = event || window.event;
            
                  console.log('event.key' + '/ ' + event.key);
                  console.log('event.which' + '/ ' + event.which);
                  console.log('event.keyCode' + '/ ' + event.keyCode);
            
                  var keyID = (event.which) ? event.which : event.keyCode;
                  if ((keyID >= 35 && keyID <= 36) //35:HOME, 36:END
                    || (event.ctrlKey == true && (keyID == 67 || keyID == 86)) //Copy&Paste
                    || (keyID >= 48 && keyID <= 57)   //0~9
                    || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
                    || (keyID >= 37 && keyID <= 40)   //방향키
                    || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46 || keyID == 109 || keyID == 189 //8:백스페이스, 13:Enter, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
                  )
                    return;
                  else {
                    event.preventDefault();
                    return;
                  }
                },
            
                removeNotPhoneNumber: function (event) {
                  //event = event || window.event;
            
                  console.log('event.key' + '/ ' + event.key);
                  console.log('event.which' + '/ ' + event.which);
                  console.log('event.keyCode' + '/ ' + event.keyCode);
            
                  var keyID = (event.which) ? event.which : event.keyCode;
                  if ((keyID >= 35 && keyID <= 36) //35:HOME, 36:END
                    || (event.ctrlKey == true && (keyID == 67 || keyID == 86)) //Copy&Paste
                    || (keyID >= 48 && keyID <= 57)   //0~9
                    || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
                    || (keyID >= 37 && keyID <= 40)   //방향키
                    || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46 || keyID == 109 || keyID == 189 //8:백스페이스, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
                  )
                    return;
                  else {
                    console.log('removeNotPhoneNumber' + '/ ' + event.target.value + '/ ' + event.target.value.replace(/[^0-9\-]/g, ""));
                    event.target.value = event.target.value.replace(/[^0-9\-]/g, "");
                  }
                },
            
            
            
            
            
                /* --------------------------------------------------------------------------------------------
                *  @desc           36자리 난수키를 생성한다.
                *  @ex             PS.UTIL.getUUID()
                *  @call           getUUID()
                * --------------------------------------------------------------------------------------------*/
                getUUID: function () {
                  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 3 | 8);
                    return v.toString(16);
                  });
                },
            
            
                /* --------------------------------------------------------------------------------------------
                *  @desc           objCodeDtl 객체를 초기화한다.
                *  @ex             gerp.PS.UTIL.getCodeClear()
                *  @memo           메뉴마다 사용되는 코드가 다르므로 메뉴를 열때마다 초기화를 시킵니다.
                *  @call           getCodeClear()
                * --------------------------------------------------------------------------------------------*/
                getCodeClear: function () {
                  objCodeDtl = {};
                },
            
                /* --------------------------------------------------------------------------------------------
                  *  @no
                  *  @desc           공통코드조회
                  *  @ex             gerp.PS.UTIL.getCodeData("PS", "Y:P00730|N:P00790|", null, null, null, null, null);
                  *  @memo           이 함수를 타기전에 셋팅하는 부분을 타는 경우는 에러발생함.
                  * --------------------------------------------------------------------------------------------
                  *  @module_cd      모듈코드
                  *  @cd_field_pipe  코드디테일 코드(PIPE 사용) >>> Y:P00730 빈칸여부를 Y, N으로 세팅한다.
                  *  @yn_sycode     시스템코드 유무(Y,N)
                  *  @base_yn        디폴트 코드구분(Y,N)
                  *  @yn_foreign     외국언어적용 유무(Y,N)- Y : NM_SYSDEF2, N : NM_SYSDEF
                  *  @end_dt         종료일-종료일이 있는 경우 종료일 이전 데이터 제외 =>(수정)
                  *                  common_codeDtl_list API 통신 시 오늘날짜(var today // yyyymmdd포맷)의 데이터를 보낸다. [210203-수정-김동은]
                  *  @nm_keyword        검색할 코드 또는 명
                  * --------------------------------------------------------------------------------------------
                  *  @return         검색된 code에 대한 data set
                  * ------------------------------------------------------------------------------------------*/
                getCodeData: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword) {
                  if (!objCodeDtl.hasOwnProperty(module_cd)) {
                    objCodeDtl[module_cd] = {};
                  }
            
                  var isEmpty;
                  var str;
                  var cd_field_pipe_result = "";
                  $.each(cd_field_pipe.split("|"), function (i, v) {
                    if (v.indexOf(':') != -1) {
                      isEmpty = v.split(":")[0]; // 'Y' or 'N'
                      str = v.split(":")[1]; // P00100
                      if (isEmpty == "Y") {
                        objCodeDtl[module_cd][str] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];
                      }
                      cd_field_pipe_result = cd_field_pipe_result + str + "|";
                    }
                    else {
                      if (v != null && v != "") {
                        objCodeDtl[module_cd][v] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];
            
                        cd_field_pipe_result = cd_field_pipe_result + v + "|";
                      }
                    }
                  });
            
            
            
                  dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", "common_codeDtl_list"), {
                    async: false,
                    data: {
                      module_cd: module_cd,
                      field_cd_pipe: cd_field_pipe_result,
                      syscode_yn: yn_sycode,
                      base_yn: base_yn,
                      foreign_yn: yn_foreign,
                      end_dt: end_dt ? end_dt : gerp.PS.UTIL.getToday(),
                      keyword: nm_keyword,
                      base_dt: dews.date.format(new Date(), 'yyyyMMdd')
                    }
                  }).done(function (data) {
            
                    $.each(data, function (i, obj) {
                      if (objCodeDtl[module_cd][obj.FIELD_CD] == null) {
                        objCodeDtl[module_cd][obj.FIELD_CD] = [{ SYSDEF_CD: obj.SYSDEF_CD, SYSDEF_NM: obj.SYSDEF_NM, FLAG_CD: obj.FLAG_CD, SYSCODE_YN: obj.SYSCODE_YN }];
                      } else {
                        objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
                      }
                    });
            
                  }).fail(function (xhr, status, error) {
                    dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                  });
                  return objCodeDtl;
                },
                getCodeData_Flag: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword, flag_cd) {
                  if (!objCodeDtl.hasOwnProperty(module_cd)) {
                    objCodeDtl[module_cd] = {};
                  }
            
                  var isEmpty;
                  var str;
                  var cd_field_pipe_result = "";
            
                  $.each(cd_field_pipe.split("|"), function (i, v) {
                    if (v.indexOf(':') != -1) {
                      isEmpty = v.split(":")[0]; // 'Y' or 'N'
                      str = v.split(":")[1]; // P00100
                      if (isEmpty == "Y") {
                        objCodeDtl[module_cd][str] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];
                      }
                      cd_field_pipe_result = cd_field_pipe_result + str + "|";
                    }
                    else {
                      if (v != null && v != "") {
                        objCodeDtl[module_cd][v] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];
            
                        cd_field_pipe_result = cd_field_pipe_result + v + "|";
                      }
                    }
                  });
            
            
                  dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", "common_codeDtl_list"), {
                    async: false,
                    data: {
                      module_cd: module_cd,
                      field_cd_pipe: cd_field_pipe_result,
                      syscode_yn: yn_sycode,
                      base_yn: base_yn,
                      foreign_yn: yn_foreign,
                      end_dt: end_dt ? end_dt : gerp.PS.UTIL.getToday(),
                      keyword: nm_keyword,
                    }
                  }).done(function (data) {
            
                    var objFLAG_CD = "";
                    $.each(data, function (i, obj) {
                      objFLAG_CD = "";
                      if (objCodeDtl[module_cd][obj.FIELD_CD] == null) {
                        if (obj.FLAG_CD) {
                          objFLAG_CD = obj.FLAG_CD;
                        }
                        if (objFLAG_CD.indexOf(flag_cd) != -1) {
                          objCodeDtl[module_cd][obj.FIELD_CD] = [{ SYSDEF_CD: obj.SYSDEF_CD, SYSDEF_NM: obj.SYSDEF_NM, FLAG_CD: obj.FLAG_CD, SYSCODE_YN: obj.SYSCODE_YN }];
                        }
                      } else {
                        if (obj.FLAG_CD) {
                          objFLAG_CD = obj.FLAG_CD;
                        }
                        if (objFLAG_CD.indexOf(flag_cd) != -1) {
                          objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
                        }
                      }
                    });
            
                  }).fail(function (xhr, status, error) {
                    dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                  });
                  return objCodeDtl;
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc           화면상의 모든컨트롤을 초기화(CLEAR)합니다.
                  *  @ex             PS_UTIL.clearPanel(dewself)
                  *  @memo           컨트롤초기화
                  * --------------------------------------------------------------------------------------------*/
                clearPanel: function (dewself) {
                  var ret = dewself.$content.find(".dews-form-panel li input[class|='dews-ui'], " +
                    ".dews-form-panel li select[class|='dews-ui'], " +
                    ".dews-form-panel li span[class|='dews-ui'], " +
                    ".dews-form-panel li textarea[class|='dews-ui']")
                  $(ret).each(function (index, node) {
                    var target = dewself[node.id];
                    if (target != undefined) {
                      var dewsControl = $(node).data('dews-control');
                      if (
                        $(node).hasClass("dews-ui-dropdownlist") ||
                        $(node).hasClass("dews-ui-maskedtextbox") ||
                        $(node).hasClass("dews-ui-datepicker") ||
                        $(node).hasClass("dews-ui-timepicker") ||
                        $(node).hasClass("dews-ui-monthpicker") ||
                        $(node).hasClass("dews-ui-datetimepicker") ||
                        $(node).hasClass("dews-ui-zipcodepicker") ||
                        $(node).hasClass("dews-ui-combobox") ||
                        $(node).hasClass("dews-ui-yearpicker")
                      ) {
                        dewsControl.value('');
                        if (typeof (dewsControl.text) == "function") {
                          dewsControl.text('');
                        }
                      }
                      else if ($(node).hasClass("dews-ui-textbox")) {
                        dewsControl.text('');
                      }
                      else if ($(node).hasClass("dews-ui-numerictextbox")) {
                        dewsControl.value(null);
                      }
                      else if (
                        $(node).hasClass("dews-ui-monthperiodpicker") ||
                        $(node).hasClass("dews-ui-weekperiodpicker")) {
                        dewsControl.setPeriod("", "");
                      }
                      else if ($(node).hasClass("dews-ui-periodpicker")) {
                        dewsControl.setStartDate("");
                        dewsControl.setEndDate("");
                      }
                      else if ($(node).hasClass("dews-ui-codepicker")) {
                        var obj = {};
                        obj[dewsControl.options.codeField] = '';
                        obj[dewsControl.options.textField] = '';
                        dewsControl.setData(obj, false);
            
                        // [2020년 12월의 마지막날-이현태] clearData를 사용할경우 해당컨트롤에 focus가 이동되는 문제가 발생함.
                        // 그리드에서 포커스가 컨트롤로 이동되면서 방향키로 행이동이 멈춤.
                        // dewsControl.clearData();
                      }
                      else if ($(node).hasClass("dews-ui-multicodepicker")) {
                        // var arr = [];
                        // dewsControl.setData(arr);
                        // [2020년 12월의 마지막날-이현태] clearData를 사용할경우 해당컨트롤에 focus가 이동되는 문제가 발생함.
                        // 그리드에서 포커스가 컨트롤로 이동되면서 방향키로 행이동이 멈춤.
                        // 
                        // [2023-01-26 윤우형] clear함수 사용 시 파라미터로 false를 보낼 경우 setData 이벤트를 타지 않고 focus도 되지 않음
                        dewsControl.clear(false);
                      }
                      else if ($(node).hasClass("dews-ui-checkbox")) {
                        dewsControl.target[0].checked = false;
                      }
                      else if ($(node).hasClass("dews-ui-radio-group")) {
                        dewsControl.select(0);
                      }
                      else if ($(node).hasClass("dews-ui-multidropdownlist")) {
                        dewsControl.deselectAll();
                      }
                    }
                  });
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc           해당ContainerItem 하위의 dews-form-panel의 모든컨트롤을 초기화(CLEAR)합니다.
                  *  @ex             PS_UTIL.clearTabPanel(dewself, dewself.$containerItemAct --> form-panel의 상위 containerItem ID)
                  *  @memo           컨트롤초기화
                  * --------------------------------------------------------------------------------------------*/
                clearTabPanel: function (dewself, panel) {
                  var ret = panel.find(".dews-form-panel li input[class|='dews-ui'], "
                    + ".dews-form-panel li select[class|='dews-ui'], "
                    + ".dews-form-panel li span[class|='dews-ui'], "
                    + ".dews-form-panel li textarea[class|='dews-ui']")
                  $(ret).each(function (index, node) {
                    var target = dewself[node.id];
                    if (target != undefined) {
                      var dewsControl = $(node).data('dews-control');
                      if (
                        $(node).hasClass("dews-ui-dropdownlist") ||
                        $(node).hasClass("dews-ui-numerictextbox") ||
                        $(node).hasClass("dews-ui-maskedtextbox") ||
                        $(node).hasClass("dews-ui-datepicker") ||
                        $(node).hasClass("dews-ui-timepicker") ||
                        $(node).hasClass("dews-ui-monthpicker") ||
                        $(node).hasClass("dews-ui-datetimepicker") ||
                        $(node).hasClass("dews-ui-zipcodepicker") ||
                        $(node).hasClass("dews-ui-combobox")
                      ) {
                        dewsControl.value('');
                        if (typeof (dewsControl.text) == "function") {
                          dewsControl.text('');
                        }
                      }
                      else if ($(node).hasClass("dews-ui-textbox")) {
                        dewsControl.text('');
                      }
                      else if (
                        $(node).hasClass("dews-ui-monthperiodpicker") ||
                        $(node).hasClass("dews-ui-weekperiodpicker")) {
                        var start = "", end = "";
                        dewsControl.setPeriod(start, end);
                      }
                      else if ($(node).hasClass("dews-ui-periodpicker")) {
                        var start = "", end = "";
                        dewsControl.setStartDate(start);
                        dewsControl.setEndDate(end);
                      }
                      else if ($(node).hasClass("dews-ui-codepicker")) {
                        var obj = {};
                        obj[dewsControl.options.codeField] = '';
                        obj[dewsControl.options.textField] = '';
                        dewsControl.setData(obj, false);
                      }
                      else if ($(node).hasClass("dews-ui-multicodepicker")) {
                        var arr = [];
                        for (var i = 0; i < dt.length; i++) {
                          var obj = {};
                          obj[dewsControl.options.codeField] = dt[i].code;
                          obj[dewsControl.options.textField] = dt[i].name;
                          arr.push(obj);
                        }
                        dewsControl.setData(arr);
                      }
                      else if ($(node).hasClass("dews-ui-checkbox")) {
                        dewsControl.target[0].checked = false;
                      }
                    }
                  });
                },
            
                /* --------------------------------------------------------------------------------------------
                  *  @no
                  *  @desc           환율 정보 로드
                  *  @ex             getExrt_rt(환종, 기준일자, 환율타입, 타겟통화코드, 기본값세팅여부)
                  *  @memo           일자/통화 등 전달한 파라미터와 일치하는 환율을 반환 - 해당날짜 없을시 가장 가까운 날짜의 환율
                  * --------------------------------------------------------------------------------------------
                  *  @exch_cd        [필수]환종
                  *  @dt             [필수]기준일자
                  *  @exrt_rt_fg     환율타입(1:표준환율, 2:사업계획환율, 3:거래처계약환율, 4:연결환율) - default 값 1 세팅
                  *  @trgt_crnc_cd   타겟통화코드(KRW/USD/..)
                  *  @set_zero_yn    조회된 환율이 없을 경우 기본값 '1'로 셋팅여부(Y/N)
                  * --------------------------------------------------------------------------------------------
                  *  @return         환율
                  * ------------------------------------------------------------------------------------------*/
                getExrt_rt: function (exch_cd, dt, exrt_rt_fg, trgt_crnc_cd, set_zero_yn) {
                  dt = (dt) ? dt : this.getToday();
                  exrt_rt_fg = (exrt_rt_fg) ? exrt_rt_fg : 1;
                  set_zero_yn  = (set_zero_yn)  ? set_zero_yn : 'Y';
                  trgt_crnc_cd = (trgt_crnc_cd) ? trgt_crnc_cd : '';
                  var exrt_rt = 1;
            
                  if(!exch_cd || !dt || !exrt_rt_fg) {
                    console.error("ps.js - getExrt_rt 함수의 인자가 부족합니다.");
                  } else {
                    dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_Exch_Rt2"), {
                      async: false,
                      data: {
                        exch_cd: exch_cd || "KRW",
                        dt: dt,
                        exrt_rt_fg : exrt_rt_fg,
                        trgt_crnc_cd : trgt_crnc_cd,
                        set_zero_yn : set_zero_yn
                      }
                    }).done(function (data) {
                      if(data.length > 0){ // 조건에 맞는 제일 최근 환율 가져옴
                        // exrt_rt = module.com.toNumber(data[0].STD_EXRT_RT);
                        exrt_rt = data[0].STD_EXRT_RT;
                      } else{ // 가져온 데이터 없을시 환율 1
                        if(set_zero_yn){
                          exrt_rt = 1;
                          console.error("scmJS - getExrt: 환율 정보를 가져오지 못해 1로 설정됩니다.");
                        } else{
                          exrt_rt = null;
                        }
                      }
                    }).fail(function (xhr, status, error) {
                      dews.error(error || "환율 정보를 가져오는데 실패했습니다.");
                    });
                    return exrt_rt;
                  }
                },
            
                // 기존
                // getExrt_rt: function (exch_cd, dt) {
                //   var exrt_rt = null;
                //   if (!dt) {
                //     dt = this.getToday();
                //   }
                //   dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_Exch_Rt"), {
                //     async: false,
                //     data: {
                //       exch_cd: exch_cd || "KRW",
                //       dt: dt
                //     }
                //   }).done(function (data) {
                //     if (data.length > 0) {
                //       exrt_rt = data[0].STD_EXRT_RT;
                //     } else {
                //       exrt_rt = 1;
                //     }
                //   }).fail(function (xhr, status, error) {
                //     dews.error(error || '작업이 실패하였습니다.');
                //   });
            
                //   return exrt_rt;
                // },
            
            
                /* --------------------------------------------------------------------------------------------
                  *  @no
                  *  @desc           노무자 세율 정보 조회
                  *  @ex             getLbrrTaxRate()
                  *  @memo           가장 최근의 노무자 세율 정보를 조회합니다. data[0]
                  *                  갑근세, 소용보험, 건강보험, 국민연금, 절사단위(TRNC_UNIT_FG)
                  * --------------------------------------------------------------------------------------------
                  *  @return         세율정보
                  * ------------------------------------------------------------------------------------------*/
                getLbrrTaxRoundType: function () {
                  var tax_info = null;
                  dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_PS_LBRR_TAX_RATE_list"), {
                    async: false
                  }).done(function (data) {
                    if (data.length > 0) {
                      tax_info = data[0];
                    }
                  }).fail(function (xhr, status, error) {
                    dews.error({
                      message: '데이터를 전송받지 못하였습니다.'
                    });
                    console.error(e.message);
                  });
            
                  return tax_info;
                },
                /* --------------------------------------------------------------------------------------------
                  *  @no
                  *  @desc           기준시간관리 조회
                  *  @ex             getSTD_TIME_MNG()
                  * ------------------------------------------------------------------------------------------*/
                getSTD_TIME_MNG: function (pjt_no) {
                  var time_info = null;
                  dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_PS_STD_TIME_MNG_list"), {
                    async: false,
                    data: { pjt_no: pjt_no }
                  }).done(function (data) {
                    time_info = data;
                  }).fail(function (xhr, status, error) {
                    dews.error({
                      message: '데이터를 전송받지 못하였습니다.'
                    });
                    console.error(e.message);
                  });
            
                  return time_info;
                },
                saveDocu: function (api_url, api_data, closed_callback_func, error_callback_func) {
                  dews.api.post(
                    api_url
                    , {
                      async: false
                      , data: api_data
                    }
                  ).done(function (resultData) {
                    dews.ui.loading.hide();
                    if (resultData.SUCCESS) {
                      dews.alert('전표처리에 성공하였습니다.').on('closed', function () {
                        if (closed_callback_func) {
                          closed_callback_func();
                        }
                      });
                    } else {
                      setTimeout(function () {
                        dews.error('전표 생성중 에러가 발생하였습니다.').on('closed', function () {
                          dews.ui.dialog('errorDialog', {
                            content:
                              // '<div class="dews-ui-referbox" style="height: 290px;">' +
                              '<div style="height: 290px;">' +
                              '  <ul>' +
                              '<li>' + resultData.MSG + '</li>' +
                              '</ul>' +
                              '</div>'
                            , modal: false
                            , title: '전표처리결과'
                            , width: 700
                            , height: 400
                            , buttons: 'close'
                            , resizable: true
                            , close: function (data) {
                              if (error_callback_func) {
                                error_callback_func(data);
                              }
                            }
                          }).open();
                        });
                      });
                    }
                  }).fail(function (xhr, status, error) {
                    setTimeout(function () {
                      dews.ui.loading.hide();
                      dews.error('오류가 발생하였습니다.');
                    }, 200);
                    console.error(error);
                  });
                },
                openErrorDialog: function (e) {
                  var location = window.location.href;
                  if (location.indexOf('localhost') > -1 || location.indexOf('10.35.13') > -1) {
                    // 로컬일 경우 팝업창 띄움
                    var initData = { err: e };
                    dialog = dews.ui.dialog("SOPOPP00504_POP",
                      {
                        url: "/view/PP/SOPOPP00504_POP",
                        title: "에러확인",
                        width: "600",
                        height: "400",
                        ok: function (data, e) {
                        }
                      });
                    dialog.setInitData(initData);
                    dialog.open();
                  } else {
                    // 이외의 접속인 경우 console로 처리(개발서버, 데모서버, ...)
                    $.each(e, function (idx, item) {
                      if (idx == 0) {
                        console.log('1. Error Type : ' + item);
                      } else if (idx == 1) {
                        console.log('2. Error Class : ' + item);
                      } else if (idx == 2) {
                        console.log('3. Error Method : ' + item);
                      } else if (idx == 3) {
                        console.log('4. Error Line : ' + item);
                      } else if (idx == 4) {
                        console.log('5. Error Log : ' + item);
                      }
                    });
                  }
                },
            
            
                /**
                  * 숫자 컴마 추가
                  * @param {object} x 설정대상 값
                  * @returns {string} 변환된 값
                  */
                numberWithCommas: function (x) {
                  if (x) {
                    var parts = x.toString().split(".");
                    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    return parts.join(".");
                  }
                },
                /** @method 숫자 왼쪽에 원하는 길이만큼 0 채우기
                    * @description 기준 문자열 왼쪽에 원하는 길이 만큼 text를 채워 반환하는 함수
                    * @param {string} text 채울문자열
                    * @param {number} num 기준 숫자
                    * @param {number} totalLength 전체길이
                  */
                lPad: function (text, num, totalLength) {
                  num = num + '';
                  return num.length >= totalLength ? num : new Array(totalLength - num.length + 1).join(text) + num;
                },
            
                /* --------------------------------------------------------------------------------------------
                  *  @no
                  *  @desc           엑셀업로드설정 데이터를 조회하여 그리드에서 사용할 컬럼을 리턴한다.
                  *  @ex             xlsGridColumns()
                  * --------------------------------------------------------------------------------------------
                  * --------------------------------------------------------------------------------------------
                  *  @table_id       엑셀업로드설정에 등록된 테이블ID (예:PS_WBS_MST)
                  *  @state_yn       상태컬럼 추가 여부 (Y or N)
                  * --------------------------------------------------------------------------------------------
                  * --------------------------------------------------------------------------------------------
                  *  @return         AddColumn : 그리드에서 사용될 컬럼리스트.
                  *                  var AddColumn = PS_UTIL.xlsGridColumns('PS_WBS_MST', state_yn);
                  *                  excelGrid.setColumns(AddColumn);
                  * ------------------------------------------------------------------------------------------*/
                xlsGridColumns: function (table_id, state_yn) {
                  AddField = []; // DataSource에서 사용될 Field값 초기화
            
                  var AddColumn = new Array();
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_excel_info'), {
                    async: false,
                    data: { table_id: table_id }
                  }).done(function (data) {
                    if (data.length > 0) {
                      if (state_yn == "Y") {
                        AddColumn.push({
                          field: 'STATE', title: '상태',
                          width: 100,
                          formats: { type: 'text' }, align: 'left',
                          attributes: { class: "readonly" }
                        });
            
                        AddField.push({ field: 'STATE' });
                      }
            
                      var attributes = "none";
                      $.each(data, function (idx, item) {
            
                        // 표시여부가 Y인건들만 ADD합니다.
                        if (item.DISP_YN != "Y") {
                          return true;
                        }
            
                        if (item.MNDR_YN == "Y") {// 필수여부
                          attributes = "required";
                        } else {
                          attributes = "none";
                        }
                        switch (item.COL_ATTR_CD) {
                          case "2": // 숫자
                            AddColumn.push({
                              field: item.COL_NM, title: item.COL_KOR_NM,
                              width: 100,
                              formats: { type: 'number', format: item.INSR_FORM_DC }, align: 'right',
                              editor: {
                                editable: function (e) { return true; }
                              },
                              attributes: { class: attributes }
                            });
            
                            AddField.push({ field: item.COL_NM, dataType: 'number' });
                            break;
                          case "3": // 날짜
                            AddColumn.push({
                              field: item.COL_NM, title: item.COL_KOR_NM,
                              width: 100,
                              formats: { type: 'date', format: item.INSR_FORM_DC }, align: 'center',
                              editor: {
                                type: 'date', format: item.INSR_FORM_DC,
                                editable: function (e) {
                                  return true;
                                }
                              },
                              attributes: { class: attributes }
                            });
            
                            AddField.push({ field: item.COL_NM });
            
                            break;
                          default: // 문자
                            AddColumn.push({
                              field: item.COL_NM, title: item.COL_KOR_NM,
                              width: 100,
                              formats: { type: 'text', format: "" }, align: 'left',
                              editor: {
                                editable: function (e) { return true; }
                              },
                              attributes: { class: attributes }
                            });
            
                            AddField.push({ field: item.COL_NM });
            
                            if (item.COL_FORM_CD == "1") {
                              // 형식 : 코드
            
                            }
                            else if (item.COL_FORM_CD == "2") {
                              // 형식 : 포멧
                            }
                            else if (item.COL_FORM_CD == "3") {
                              // 형식 : 기타
                            }
                            break;
                        }
                      });
                    }
                  }).fail(function (xhr, status, error) {
                    dews.error(error);
                  });
            
                  return AddColumn;
            
                },
                /* --------------------------------------------------------------------------------------------
                  *  @no
                  *  @desc           엑셀업로드설정 데이터를 조회하여 DataSource에서 사용할 Field를 리턴한다.
                  *  @ex             xlsDataSourceFields()
                  * --------------------------------------------------------------------------------------------
                  * --------------------------------------------------------------------------------------------
                  *  @table_id       엑셀업로드설정에 등록된 테이블ID (예:PS_WBS_MST)
                  *  @state_yn       상태컬럼 추가 여부 (Y or N)
                  * --------------------------------------------------------------------------------------------
                  * --------------------------------------------------------------------------------------------
                  *  @return         AddField : 그리드에서 사용될 컬럼리스트.
                  *                  var AddField = PS_UTIL.xlsDataSourceFields();
                  *                  mainDataSource.setFields(AddField);
                  * ------------------------------------------------------------------------------------------*/
                xlsDataSourceFields: function () {
                  return AddField;
                },
                xlsVerify: function (excelGrid) {
                  var ret = null;
            
                  // 필수컬럼 추출
                  var requiredColumns = [];
                  $.each(excelGrid.options.columns, function (idx, item) {
                    if (item.attributes) {
                      if (item.attributes.class == "required") {
                        requiredColumns.push(item);
                      }
                    }
                  });
            
                  for (var i = 0; i < excelGrid.dataItems().length; i++) {
                    $.each(requiredColumns, function (idx, column) {
                      if (!excelGrid.getCellValue(i, column.field)) {
                        ret = new VerifyNode("[" + column.title + "]는 필수입력항목입니다.", i, column.field);
                        return false;
                      }
                    });
                    if (ret) {
                      return ret;
                    }
                  }
                },
                /* --------------------------------------------------------------------------------------------
                *  @no
                *  @desc           캘린더 일자 정보
                *  @ex             get_calender_date_list()
                *  @memo           캘린더 일자 정보
                * --------------------------------------------------------------------------------------------
                *
                * --------------------------------------------------------------------------------------------
                *  @return         캘린터 일자
                * ------------------------------------------------------------------------------------------*/
                get_calender_date_list: function (pjt_no, clnd_cd, dnl_fg_cd, start_dt, end_dt, bwrk_fg_cd) {
                  var date_list = [];
                  //캘린더 일자정보 리스트\
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', dews.string.format('PSApiProvider_calendar_date_list')), {
                    async: false,
                    data: {
                      pjt_no: pjt_no,
                      clnd_cd: clnd_cd,      //캘린더유형 :  카렌다(1), PlantA(2), PlantB(3), PlantC(4)
                      dnl_fg_cd: dnl_fg_cd,   // 근태구분 : 평일(1), 주휴(2), 유후(3), 무휴(4), 공휴(5)
                      start_dt: start_dt,
                      end_dt: end_dt,
                      bwrk_fg_cd: bwrk_fg_cd //근무구분 : 전일(2), 반일(B), 휴일(1)
                    }
                  }).done(function (data) {
                    if (data.length > 0) {
                      $(data).each(function (i, item) {
                        date_list[i] = item.CLND_DT;
                      })
                    }
                  }).fail(function (xhr, status, error) {
                    dews.error(error);
                  });
            
                  return date_list;
            
                },
                /* --------------------------------------------------------------------------------------------
                *  @no
                *  @desc           캘린더 정보 조회
                *  @ex             get_calender_all_list(clnd_tp)
                *  @memo           캘린더 정보 조회
                * --------------------------------------------------------------------------------------------*/
                /* --------------------------------------------------------------------------------------------
                *  @return         전체 캘린터 일자
                * ------------------------------------------------------------------------------------------*/
                get_calender_all_list: function (clnd_tp) {
                  var calendarData;
                  //캘린더 일자정보 리스트\
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', dews.string.format('PSApiProvider_calendar_list_ALL')), {
                    async: false,
                    data: { clnd_tp: clnd_tp }
                  }).done(function (data) {
                    calendarData = data;
                  }).fail(function (xhr, status, error) {
                    console.error(error);
                    setTimeout(function () {
                      dews.error('오류가 발생하였습니다.');
                    }, 200);
                  });
            
                  return calendarData;
                },
                //*********************************************/
                //* 입력된 일자의 캘린더 존재여부               */
                //*********************************************/
                exist_calender: function (calendar, dt, clnd_cd) {
                  if (typeof (dt) != "string") {
                    dt = this.getToday(dt);
                  }
                  var DATE_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == dt });
            
                  return DATE_INFO.length > 0 ? true : false;
                },
                //*********************************************/
                //* 시작일과 종료일로 기간을 계산합니다. */
                //*********************************************/
                get_calendar_duration: function (calendar, start_dt, end_dt, clnd_cd, grid) {
                  var day_count = 0;
                  if (!start_dt || !end_dt) {
                    return undefined;
                  }
            
                  if (calendar && calendar.length > 0) {
                    if (typeof (start_dt) != "string") {
                      start_dt = this.getToday(start_dt);
                    }
                    if (typeof (end_dt) != "string") {
                      end_dt = this.getToday(end_dt);
                    }
            
                    var start_yyyy = Number(start_dt.substring(0, 4));
                    var end_yyyy = Number(end_dt.substring(0, 4));
            
                    var START_INFO = null;
                    var END_INFO = null;
                    var YEAR_LAST_INFO = null;
                    if (start_yyyy == end_yyyy) {
                      // 시작년도와 종료년도가 같을때
                      START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == start_dt });
                      END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == end_dt });
                      if (END_INFO.length > 0 && START_INFO.length > 0) {
                        var plusDay = 0;
                        if (START_INFO[0].BWRK_FG_CD == '2') {
                          plusDay = 1;
                        } else if (START_INFO[0].BWRK_FG_CD == 'B') {
                          plusDay = 0.5;
                        }
                        day_count = END_INFO[0].ACMTL_BWRK_DY - START_INFO[0].ACMTL_BWRK_DY + plusDay;
                      }
                    } else if (end_yyyy - start_yyyy == 1) {
                      // 시작년도와 종료년도가 1년차이일때 (시작년도:2020, 종료년도:2021)
                      YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(start_yyyy).concat("1231") });
                      START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == start_dt });
                      END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == end_dt });
                      if (YEAR_LAST_INFO.length > 0 && END_INFO.length > 0 && START_INFO.length > 0) {
                        var plusDay = 0;
                        if (START_INFO[0].BWRK_FG_CD == '2') {
                          plusDay = 1;
                        } else if (START_INFO[0].BWRK_FG_CD == 'B') {
                          plusDay = 0.5;
                        }
                        day_count = YEAR_LAST_INFO[0].ACMTL_BWRK_DY - START_INFO[0].ACMTL_BWRK_DY + END_INFO[0].ACMTL_BWRK_DY + plusDay;
                      }
            
                      if (YEAR_LAST_INFO.length == 0) {
                        console.error("[PS_UTIL.get_calendar_duration] YEAR_LAST_INFO == null");
                        dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                          .done(function () {
                            if (grid) {
                              grid.setFocus();
                            }
                          });
                      }
                      else if (START_INFO.length == 0) {
                        console.error("[PS_UTIL.get_calendar_duration] START_INFO == null");
                        dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                          .done(function () {
                            if (grid) {
                              grid.setFocus();
                            }
                          });
                      }
                      else if (END_INFO.length == 0) {
                        console.error("[PS_UTIL.get_calendar_duration] END_INFO == null");
                        dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                          .done(function () {
                            if (grid) {
                              grid.setFocus();
                            }
                          });
                      }
                    } else {
                      // 시작년도와 종료년도가 1년 이상 차이일때 (시작년도:2018, 종료년도:2022)
                      for (var i = start_yyyy + 1; i < end_yyyy; i++) {
                        // 2019, 2020, 2021의 워킹데이를 더합니다.
                        YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(i).concat("1231") });
                        if (YEAR_LAST_INFO.length) {
                          day_count += YEAR_LAST_INFO[0].ACMTL_BWRK_DY;
                        }
                      }
            
                      // 2018, 2022년도 워킹데이터를 구합니다.
                      YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(start_yyyy).concat("1231") });
                      START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == start_dt });
                      END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == end_dt });
                      if (YEAR_LAST_INFO.length > 0 && END_INFO.length > 0 && START_INFO.length > 0) {
                        var plusDay = 0;
                        if (START_INFO[0].BWRK_FG_CD == '2') {
                          plusDay = 1;
                        } else if (START_INFO[0].BWRK_FG_CD == 'B') {
                          plusDay = 0.5;
                        }
                        day_count += YEAR_LAST_INFO[0].ACMTL_BWRK_DY - START_INFO[0].ACMTL_BWRK_DY + END_INFO[0].ACMTL_BWRK_DY + plusDay;
                      } else {
                        if (YEAR_LAST_INFO.length == 0) {
                          console.error("[PS_UTIL.get_calendar_duration] YEAR_LAST_INFO == null");
                          dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                            .done(function () {
                              if (grid) {
                                grid.setFocus();
                              }
                            });
                        }
                        else if (START_INFO.length == 0) {
                          console.error("[PS_UTIL.get_calendar_duration] START_INFO == null");
                          dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                            .done(function () {
                              if (grid) {
                                grid.setFocus();
                              }
                            });
                        }
                        else if (END_INFO.length == 0) {
                          console.error("[PS_UTIL.get_calendar_duration] END_INFO == null");
                          dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                            .done(function () {
                              if (grid) {
                                grid.setFocus();
                              }
                            });
                        }
                      }
                    }
            
                  }
            
                  return day_count;
                },
                //*********************************************/
                //* 시작일과 소요기간으로 종료일자를 계산합니다. */
                //* returnType : (String)'20210713' (PipeString)'2021-07-13' (Date) DateType - Tue Jul 13 2021 09:00:00 GMT+0900 (대한민국 표준시)
                //*********************************************/
                get_calendar_end_dt: function (calendar, start_dt, duration, clnd_cd, returnType, grid) {
                  var end_dt = null;
                  if (!duration || !start_dt) {
                    return undefined;
                  }
            
                  if (calendar && calendar.length > 0) {
                    if (typeof (start_dt) != "string") {
                      start_dt = this.getToday(start_dt);
                    }
            
                    var start_yyyy = Number(start_dt.substring(0, 4));
                    var START_INFO = null;
                    var YEAR_LAST_INFO = null;
                    var remainingTime = duration; // 잔여일수
                    var END_INFO = null;
            
            
                    while (true) {
                      if (!START_INFO) {
                        START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == start_dt });
                      } else {
                        START_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(start_yyyy).concat("0101") });
                      }
                      YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(start_yyyy).concat("1231") });
                      if (YEAR_LAST_INFO.length > 0 && START_INFO.length > 0) {
                        duration = remainingTime;
                        remainingTime = remainingTime - (YEAR_LAST_INFO[0].ACMTL_BWRK_DY - START_INFO[0].ACMTL_BWRK_DY + 1);
                        if (remainingTime <= 0) {
                          // 해당년도 내에서 종료일자 추출이 가능합니다.
                          END_INFO = calendar.filter(function (v) {
                            return v.CLND_TP == clnd_cd && v.CLND_DT.substring(0, 4) == start_yyyy &&
                              v.ACMTL_BWRK_DY >= START_INFO[0].ACMTL_BWRK_DY + duration - 1
                          });
                          if (END_INFO.length == 0) {
                            console.error("[PS_UTIL.get_calendar_end_dt] END_INFO == null");
                            dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                              .done(function () {
                                if (grid) {
                                  grid.setFocus();
                                }
                              });
                          } else {
                            end_dt = END_INFO[0].CLND_DT;
                          }
                          break;
                        } else {
                          start_yyyy++;
                        }
                      } else {
                        if (YEAR_LAST_INFO.length == 0) {
                          console.error("[PS_UTIL.get_calendar_end_dt] YEAR_LAST_INFO == null");
                          dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                            .done(function () {
                              if (grid) {
                                grid.setFocus();
                              }
                            });
                        }
                        else if (START_INFO.length == 0) {
                          console.error("[PS_UTIL.get_calendar_end_dt] START_INFO == null");
                          dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                            .done(function () {
                              if (grid) {
                                grid.setFocus();
                              }
                            });
                        }
                        break;
                      }
                    }
                  }
                  if (returnType == "PipeString") {
                    if (end_dt && end_dt.length == 8) {
                      return end_dt.substring(0, 4) + '-' + end_dt.substring(4, 6) + '-' + end_dt.substring(6, 8);
                    }
                  }
                  else if (returnType == "Date") {
                    if (end_dt && end_dt.length == 8) {
                      return new Date(end_dt.substring(0, 4) + '-' + end_dt.substring(4, 6) + '-' + end_dt.substring(6, 8));
                    }
                  }
                  return end_dt;
                },
            
                //*********************************************/
                //* 종료일과 소요기간으로 시작일자를 계산합니다.
                //* 종료일이 시작일자 이전으로 세팅된경우 소요기간만큼 시작일을 앞당기도록합니다.
                //* returnType : (String)'20210713' (PipeString)'2021-07-13' (Date) DateType - Tue Jul 13 2021 09:00:00 GMT+0900 (대한민국 표준시)
                //*********************************************/
                get_calendar_start_dt: function (calendar, end_dt, duration, clnd_cd, returnType, grid) {
                  var start_dt = null;
                  if (!duration || !end_dt) {
                    return undefined;
                  }
            
                  if (calendar && calendar.length > 0) {
                    if (typeof (start_dt) != "string") {
                      end_dt = this.getToday(end_dt);
                    }
            
                    var end_yyyy = Number(end_dt.substring(0, 4));
                    var ori_end_yyyy = Number(end_dt.substring(0, 4));
                    var YEAR_LAST_INFO = null;
                    var remainingTime = duration; // 잔여일수
                    var END_INFO = null;
                    var START_INFO = null;
            
                    while (true) {
                      if (!END_INFO) {
                        END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == end_dt });
                      } else {
                        END_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(end_yyyy).concat("0101") });
                      }
                      YEAR_LAST_INFO = calendar.filter(function (v) { return v.CLND_TP == clnd_cd && v.CLND_DT == String(end_yyyy).concat("1231") });
                      if (YEAR_LAST_INFO.length > 0 && END_INFO.length > 0) {
                        if (ori_end_yyyy == end_yyyy) {
                          remainingTime = remainingTime - END_INFO[0].ACMTL_BWRK_DY - 1;
            
                          if (remainingTime <= 0) {
                            // 해당년도 내에서 시작일자 추출이 가능합니다.
                            START_INFO = calendar.filter(function (v) {
                              return v.CLND_TP == clnd_cd && v.CLND_DT.substring(0, 4) == end_yyyy && v.BWRK_FG_CD != '3' &&
                                v.ACMTL_BWRK_DY <= Math.abs(remainingTime)
                            });
                            if (START_INFO.length == 0) {
                              console.error("[PS_UTIL.get_calendar_start_dt] START_INFO == null");
            
                              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                                .done(function () {
                                  if (grid) {
                                    grid.setFocus();
                                  }
                                });
            
                            } else {
                              start_dt = START_INFO[START_INFO.length - 1].CLND_DT;
                            }
                            break;
                          } else {
                            end_yyyy--;
                          }
                        } else {
                          remainingTime = YEAR_LAST_INFO[0].ACMTL_BWRK_DY - remainingTime;
                          if (remainingTime <= 0) {
                            end_yyyy--;
                          } else {
                            START_INFO = calendar.filter(function (v) {
                              return v.CLND_TP == clnd_cd && v.CLND_DT.substring(0, 4) == end_yyyy && v.BWRK_FG_CD != '3' &&
                                v.ACMTL_BWRK_DY <= remainingTime
                            });
                            if (START_INFO.length == 0) {
                              console.error("[PS_UTIL.get_calendar_start_dt] START_INFO == null");
                              dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                                .done(function () {
                                  if (grid) {
                                    grid.setFocus();
                                  }
                                });
                            } else {
                              start_dt = START_INFO[START_INFO.length - 1].CLND_DT;
                            }
                            break;
                          }
                        }
            
                      } else {
                        if (YEAR_LAST_INFO.length == 0) {
                          console.error("[PS_UTIL.get_calendar_start_dt] YEAR_LAST_INFO == null");
                          dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                            .done(function () {
                              if (grid) {
                                grid.setFocus();
                              }
                            });
                        }
                        else if (END_INFO.length == 0) {
                          console.error("[PS_UTIL.get_calendar_start_dt] START_INFO == null");
                          dews.alert("캘린더정보가 없습니다." + "\n" + "캘린더등록메뉴에서 해당기간의 캘린더를 생성하세요.", "warning")
                            .done(function () {
                              if (grid) {
                                grid.setFocus();
                              }
                            });
                        }
                        break;
                      }
                    }
                  }
                  if (returnType == "PipeString") {
                    if (start_dt && start_dt.length == 8) {
                      return start_dt.substring(0, 4) + '-' + start_dt.substring(4, 6) + '-' + start_dt.substring(6, 8);
                    }
                  }
                  else if (returnType == "Date") {
                    if (start_dt && start_dt.length == 8) {
                      return new Date(start_dt.substring(0, 4) + '-' + start_dt.substring(4, 6) + '-' + start_dt.substring(6, 8));
                    }
                  }
                  return start_dt;
                },
            
                /* --------------------------------------------------------------------------------------------
                *  @return         캘린터 일자
                * ------------------------------------------------------------------------------------------*/
                get_calender_info_list: function (pjt_no, clnd_cd, dnl_fg_cd, start_dt, end_dt, bwrk_fg_cd) {
                  var calendarData;
                  //캘린더 일자정보 리스트\
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', dews.string.format('PSApiProvider_calendar_date_list')), {
                    async: false,
                    data: {
                      pjt_no: pjt_no,
                      clnd_cd: clnd_cd,      //캘린더유형 :  카렌다(1), PlantA(2), PlantB(3), PlantC(4)
                      dnl_fg_cd: dnl_fg_cd,   // 근태구분 : 평일(1), 주휴(2), 유후(3), 무휴(4), 공휴(5)
                      start_dt: start_dt,
                      end_dt: end_dt,
                      bwrk_fg_cd: bwrk_fg_cd //근무구분 : 전일(2), 반일(B), 휴일(1)
                    }
                  }).done(function (data) {
                    calendarData = data;
                  }).fail(function (xhr, status, error) {
                    dews.error(error);
                  });
            
                  return calendarData;
            
                },
                /* --------------------------------------------------------------------------------------------
                *  @no
                *  @desc           해당프로젝트의 캘린터등록 데이터를 가져온다.
                *  @ex             get_pjt_calender_date_list()
                * --------------------------------------------------------------------------------------------
                *
                * --------------------------------------------------------------------------------------------
                *  @return         캘린터 일자
                * ------------------------------------------------------------------------------------------*/
                get_pjt_calender_date_list: function (pjt_no, clnd_cd, dnl_fg_cd, pjt_type, bwrk_fg_cd) {
                  var calendarData;
                  //캘린더 일자정보 리스트\
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', dews.string.format('PSApiProvider_pjt_calendar_list')), {
                    async: false,
                    data: {
                      pjt_no: pjt_no,
                      clnd_cd: clnd_cd, //캘린더유형 :  카렌다(1), PlantA(2), PlantB(3), PlantC(4)
                      dnl_fg_cd: dnl_fg_cd,   // 근태구분 : 평일(1), 주휴(2), 유후(3), 무휴(4), 공휴(5)
                      pjt_type: pjt_type,
                      bwrk_fg_cd: bwrk_fg_cd //근무구분 : 전일(2), 반일(B), 휴일(1)
                    }
                  }).done(function (data) {
                    calendarData = data
                  }).fail(function (xhr, status, error) {
                    setTimeout(function () {
                      dews.alert('작업이 실패되었습니다.' + '\n' + error, { icon: 'error' });
                    }, 200);
                  });
            
                  return calendarData;
            
                },
                /* --------------------------------------------------------------------------------------------
            *  @no
            *  @desc           캘린더 일자 카운트
            *  @ex             get_calender_date_count()
            *  @memo           캘린더 일자 카운트
            * --------------------------------------------------------------------------------------------
            *
            * --------------------------------------------------------------------------------------------
            *  @return         캘린터 일자 카운트
            * ------------------------------------------------------------------------------------------*/
                get_calender_date_count: function (pjt_no, clnd_cd, dnl_fg_cd, start_dt, end_dt, bwrk_fg_cd) {
                  var date_count = 0;
                  //캘린더 일자 카운트//
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', dews.string.format('PSApiProvider_calendar_date_list')), {
                    async: false,
                    data: {
                      pjt_no: pjt_no,
                      clnd_cd: clnd_cd,      //캘린더유형 :  카렌다(1), PlantA(2), PlantB(3), PlantC(4)
                      dnl_fg_cd: dnl_fg_cd,   // 근태구분 : 평일(1), 주휴(2), 유후(3), 무휴(4), 공휴(5)
                      start_dt: start_dt,
                      end_dt: end_dt,
                      bwrk_fg_cd: bwrk_fg_cd //근무구분 : 전일(2), 반일(B), 휴일(1)
                    }
                  }).done(function (data) {
                    if (data.length == 0) {
                      dews.ui.snackbar.warning('캘린더 내용이 없습니다.');
                    }
                    date_count = data.length;
                  }).fail(function (xhr, status, error) {
                    dews.error(error);
                  });
            
                  return date_count;
            
                },
                /* --------------------------------------------------------------------------------------------
                *  @desc           회사환경설정 통제값 조회
                *  @ex             getCmpyEnvControl(module_cd, ctrl_cd)
                * --------------------------------------------------------------------------------------------*/
                getCmpyEnvControl: function (module_cd, ctrl_cd) {
                  /******회사환경설정등록******/
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00000), 통제코드명([1.예산통제]여부), Y:Yes,  N:No
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00010), 통제코드명([1-1. 집계공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00020), 통제코드명([1-2. 집계공종]경고알림 여부), Y:Yes,  N:No
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00030), 통제코드명([1-2-1. 집계공종]경고수준)
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00040), 통제코드명([1-2-2. 집계공종]통제수준)
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00050), 통제코드명([1-3. 내역공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00060), 통제코드명([1-4. 내역공종]경고알림 여부), Y:Yes,  N:No
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00070), 통제코드명([1-4-1. 내약공종]경고수준)
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00080), 통제코드명([1-4-2.내역공종]통제수준)
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00090), 통제코드명([실행예산]실행예산 Sync 시점), 1:실행예산요청시, 2:실행예산승인시
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00100), 통제코드명(외주변경계약 위치), 1:외주계약등록, 2:외주발주품의등록
                  // 회사환경설정 : 모듈(PS), 통제코드(PS00000), 통제코드명(기준정보)
                  // 회사환경설정 : 모듈(PS), 통제코드(PS00010), 통제코드명(예산연동여부), Y : Yes  N : No
                  // 회사환경설정 : 모듈(PS), 통제코드(PS00020), 통제코드명(실행예산연동여부), Y : Yes  N : No
                  var isCmpyEnvControl = null;
                  {
                    dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_Company_Control'), {
                      async: false,
                      data: {
                        module_cd: module_cd,
                        ctrl_cd: ctrl_cd  // 사업계획 사용여부
                      }
                    }).done(function (data) {
                      isCmpyEnvControl = data;
                    }).fail(function (xhr, status, error) {
                      setTimeout(function () {
                        dews.error('오류가 발생하였습니다.');
                      }, 200);
                      console.error(error);
                    });
                  }
                  return isCmpyEnvControl;
                },
            
                /* --------------------------------------------------------------------------------------------
                *  @desc           회사환경설정 조회
                *  @ex             getCmpyEnvControlInfo("PS", "PS00185", "FORMAT_VR")
                *
                * --------------------------------------------------------------------------------------------*/
                getCmpyEnvControlInfo: function (module_cd, ctrl_cd, col_cd) {
                  /******회사환경설정등록******/
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00000), 통제코드명([1.예산통제]여부), Y:Yes,  N:No
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00010), 통제코드명([1-1. 집계공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00020), 통제코드명([1-2. 집계공종]경고알림 여부), Y:Yes,  N:No
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00030), 통제코드명([1-2-1. 집계공종]경고수준)
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00040), 통제코드명([1-2-2. 집계공종]통제수준)
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00050), 통제코드명([1-3. 내역공종]통제시 통제방법), 1:전체예산통제, 2:기간예산통제
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00060), 통제코드명([1-4. 내역공종]경고알림 여부), Y:Yes,  N:No
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00070), 통제코드명([1-4-1. 내약공종]경고수준)
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00080), 통제코드명([1-4-2.내역공종]통제수준)
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00090), 통제코드명([실행예산]실행예산 Sync 시점), 1:실행예산요청시, 2:실행예산승인시
                  // 회사환경설정 : 모듈(PS), 통제코드(BC00100), 통제코드명(외주변경계약 위치), 1:외주계약등록, 2:외주발주품의등록
                  // 회사환경설정 : 모듈(PS), 통제코드(PS00000), 통제코드명(기준정보)
                  // 회사환경설정 : 모듈(PS), 통제코드(PS00010), 통제코드명(예산연동여부), Y : Yes  N : No
                  // 회사환경설정 : 모듈(PS), 통제코드(PS00020), 통제코드명(실행예산연동여부), Y : Yes  N : No
                  var isCmpyEnvControl = null;
                  {
                    dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_Company_Control_API'), {
                      async: false,
                      data: {
                        module_cd: module_cd,
                        ctrl_cd: ctrl_cd  // 사업계획 사용여부
                      }
                    }).done(function (data) {
                      if (data) {
                        isCmpyEnvControl = data[col_cd];
                      }
                    }).fail(function (xhr, status, error) {
                      setTimeout(function () {
                        dews.error('오류가 발생하였습니다.');
                      }, 200);
                      console.error(error);
                    });
                  }
                  return isCmpyEnvControl;
                },
                getCommonFormat: function () {
                  var rtn_data;
            
                  dews.api.get(dews.url.getApiUrl("IM", "SCMCommonService", "SCMApiProvider_MA_COMMON_CODE_list"), {
                    async: false,
                    data: {
                    }
                  }).done(function (data) {
                    rtn_data = data;
                  }).fail(function (_xhr, _status, error) {
                    setTimeout(function () {
                      dews.error('오류가 발생하였습니다.');
                    }, 200);
                    console.error(error);
                  });
            
                  return rtn_data;
                },
            
                /*********************************************************************************************
                 * @desc  그리드 number컬럼에 환종별 포맷 적용하기. 그리드의 save이벤트에서 사용합니다.
                 * @param {Object} p_all_list   [필수] 환종별포맷 리스트
                 * @param {String} p_ctrl_cd    [필수] 통제코드(MA00004...)
                 * @param {String} p_number     [필수] 포맷지정값
                 * @param {String} p_exch_cd    [필수] 거래환종
                 * @param {String} c_exch_cd    [필수] 회사환종
                * @ex    PS_UTIL.getChangeNumber(p_all_list, p_ctrl_cd, p_number, p_exch_cd, c_exch_cd);
                * ------------------------------------------------------------------------------------------*/
                getChangeNumber: function (p_all_list, p_ctrl_cd, p_number, p_exch_cd, c_exch_cd) {
                  //정상값이 안될때
                  if (!p_number)
                    return 0;
                  else {
                    var rtn_number = Number(p_number);
                    var obj = null;
                    //▶ MA00016 환종별 포맷설정 통제값 =='Y' &&  외화단가 또는 외화금액의 경우.
                    if (p_all_list[0]["MA00016_YN"] == 'Y') {
                      if (p_ctrl_cd == "MA00002") {
                        $.each(p_all_list, function (_idx, _data) {
                          if (_data.CTRL_CD == "MA00004" && _data.EXCH_CD == p_exch_cd) {
                            obj = _data;
                            return false;
                          }
                        });
                      }
                      else if (p_ctrl_cd == "MA00003") {
                        $.each(p_all_list, function (_idx, _data) {
                          if (_data.CTRL_CD == "MA00005" && _data.EXCH_CD == p_exch_cd) {
                            obj = _data;
                            return false;
                          }
                        });
                      }
                      else if (p_ctrl_cd == "MA00004" || p_ctrl_cd == "MA00005") {
                        $.each(p_all_list, function (_idx, _data) {
                          if (_data.CTRL_CD == p_ctrl_cd && _data.EXCH_CD == p_exch_cd) {
                            obj = _data;
                            return false;
                          }
                        });
                      }
                    }
            
                    //외화금액일때 회사환종과 환종이 같은 경우 장부금액으로 처리한다. 2021.05.31 (환종코드가 둘다 있어야 해당)
                    if (p_ctrl_cd === "MA00005" && c_exch_cd && p_exch_cd && c_exch_cd === p_exch_cd) {
                      $.each(p_all_list, function (_idx, _data) {
                        if (_data.CTRL_CD == "MA00003") {
                          obj = _data;
                          return false;
                        }
                      });
                    }
            
                    if (!obj) {
                      $.each(p_all_list, function (_idx, _data) {
                        if (!_data.EXCH_CD && _data.CTRL_CD == p_ctrl_cd) {
                          obj = _data;
                          return false;
                        }
                      });
                    }
                    if (obj) {
                      var digits = Math.pow(10, obj.CTRL_VR);  //자리수 변수사용 제곱수 구함.
                      var gubun_zero = false;
            
                      if (rtn_number < 0) { //음수일경우 -1 곱한다음 리턴시 다시 -1 곱하여 처리.
                        gubun_zero = true;
                        rtn_number = Number(rtn_number) * (-1);
                      }
                      switch (obj.RND_FG) {
                        case "1": {  //반올림.
                          rtn_number = Math.round(rtn_number * digits) / digits;
                          break;
                        }
                        case "2": { //올림.
                          rtn_number = Math.ceil(rtn_number * digits) / digits;
                          break;
                        }
                        case "3": { //내림.
                          rtn_number = Math.floor(rtn_number * digits) / digits;
                          break;
                        }
                      }
                      return gubun_zero == true ? Number((rtn_number * -1).toFixed(obj.CTRL_VR)) : Number(rtn_number.toFixed(obj.CTRL_VR));
                    } else {
                      return p_number;
                    }
            
            
                  }
                },
            
                /*********************************************************************************************
                 * @desc  그리드 number컬럼에 환종별 포맷 적용하기
                 * @param {Object} p_all_list   [필수] 환종별포맷 리스트
                 * @param {String} p_ctrl_cd    [필수] 통제코드(MA00004...)
                 * @param {String} p_exch_cd    [필수] 거래환종
                 * @param {String} c_exch_cd    [필수] 회사환종
                 * @param {Object} grid         [필수] 해당 포맷 적용할 그리드
                 * @param {Object} fieldArr     [필수] 해당 포맷을 적용하고 싶은 필드의 배열
                                                 EX] var fieldArr = ['SELL_AMT'];
                * @ex    PS_UTIL.changeColEditFormat(p_all_list, "MA00004", "KRW", self.grid, ['SELL_AMT']);
                * ------------------------------------------------------------------------------------------*/
                changeColEditFormat: function (p_all_list, p_ctrl_cd, p_exch_cd, c_exch_cd, grid, fieldArr) {
                  try {
                    if (p_all_list.length > 0 && p_ctrl_cd && p_exch_cd && grid && fieldArr.length > 0) {
                      var obj = null;
                      //▶ MA00016 환종별 포맷설정 통제값 =='Y' &&  외화단가 또는 외화금액의 경우.
                      if (p_all_list[0]["MA00016_YN"] == 'Y') {
                        if (p_ctrl_cd == "MA00002") {
                          $.each(p_all_list, function (_idx, _data) {
                            if (_data.CTRL_CD == "MA00004" && _data.EXCH_CD == p_exch_cd) {
                              obj = _data;
                              return false;
                            }
                          });
                        }
                        else if (p_ctrl_cd == "MA00003") {
                          $.each(p_all_list, function (_idx, _data) {
                            if (_data.CTRL_CD == "MA00005" && _data.EXCH_CD == p_exch_cd) {
                              obj = _data;
                              return false;
                            }
                          });
                        }
                        else if (p_ctrl_cd == "MA00004" || p_ctrl_cd == "MA00005") {
                          $.each(p_all_list, function (_idx, _data) {
                            if (_data.CTRL_CD == p_ctrl_cd && _data.EXCH_CD == p_exch_cd) {
                              obj = _data;
                              return false;
                            }
                          });
                        }
                      }
            
                      //외화금액일때 회사환종과 환종이 같은 경우 장부금액으로 처리한다. 2021.05.31 (환종코드가 둘다 있어야 해당)
                      if (p_ctrl_cd === "MA00005" && c_exch_cd && p_exch_cd && c_exch_cd === p_exch_cd) {
                        $.each(p_all_list, function (_idx, _data) {
                          if (_data.CTRL_CD == "MA00003") {
                            obj = _data;
                            return false;
                          }
                        });
                      }
            
                      if (!obj) {
                        $.each(p_all_list, function (_idx, _data) {
                          if (!_data.EXCH_CD && _data.CTRL_CD == p_ctrl_cd) {
                            obj = _data;
                            return false;
                          }
                        });
                      }
            
                      if (obj) {
                        //변경할 컬럼 옵션 설정
                        var option = {
                          editor: { type: 'number', predefined: false, format: obj.FORMAT_VR },
                          formats: { type: 'number', predefined: false, format: "#,###.######" }
                        }
                        //해당 필드의 배열 수 만큼 컬럼 옵션 적용
                        $.each(fieldArr, function (idx, item) {
                          grid.setColumn(item, option);
                        });
                      }
                    }
                  } catch (exception) {
                    console.error(exception);
                  }
                },
                    /*********************************************************************************************
                 * @desc  폼아이템 number 텍스트박스 에 환종별 포맷 적용하기
                 * @param {Object} p_all_list   [필수] 환종별포맷 리스트
                 * @param {String} p_ctrl_cd    [필수] 통제코드(MA00004...)
                 * @param {String} p_exch_cd    [필수] 거래환종
                 * @param {String} c_exch_cd    [필수] 회사환종
                 * @param {Object} target_id    [필수] 해당 포맷 적용할 폼아이템 ID
                 * @ex    PS_UTIL.changeControlEditFormat(p_all_list, "MA00004", "KRW", self.textBoxId);
                * ------------------------------------------------------------------------------------------*/
                changeControlEditFormat: function (p_all_list, p_ctrl_cd, p_exch_cd, c_exch_cd, target_id) {
                try {
                  if (p_all_list.length > 0 && p_ctrl_cd && p_exch_cd && target_id) {
                    var obj = null;
                    //▶ MA00016 환종별 포맷설정 통제값 =='Y' &&  외화단가 또는 외화금액의 경우.
                    if (p_all_list[0]["MA00016_YN"] == 'Y') {
                      if (p_ctrl_cd == "MA00002") {
                        $.each(p_all_list, function (_idx, _data) {
                          if (_data.CTRL_CD == "MA00004" && _data.EXCH_CD == p_exch_cd) {
                            obj = _data;
                            return false;
                          }
                        });
                      }
                      else if (p_ctrl_cd == "MA00003") {
                        $.each(p_all_list, function (_idx, _data) {
                          if (_data.CTRL_CD == "MA00005" && _data.EXCH_CD == p_exch_cd) {
                            obj = _data;
                            return false;
                          }
                        });
                      }
                      else if (p_ctrl_cd == "MA00004" || p_ctrl_cd == "MA00005") {
                        $.each(p_all_list, function (_idx, _data) {
                          if (_data.CTRL_CD == p_ctrl_cd && _data.EXCH_CD == p_exch_cd) {
                            obj = _data;
                            return false;
                          }
                        });
                      }
                    }
            
                    //외화금액일때 회사환종과 환종이 같은 경우 장부금액으로 처리한다. 2021.05.31 (환종코드가 둘다 있어야 해당)
                    if (p_ctrl_cd === "MA00005" && c_exch_cd && p_exch_cd && c_exch_cd === p_exch_cd) {
                      $.each(p_all_list, function (_idx, _data) {
                        if (_data.CTRL_CD == "MA00003") {
                          obj = _data;
                          return false;
                        }
                      });
                    }
            
                    if (!obj) {
                      $.each(p_all_list, function (_idx, _data) {
                        if (!_data.EXCH_CD && _data.CTRL_CD == p_ctrl_cd) {
                          obj = _data;
                          return false;
                        }
                      });
                    }
            
                    if (obj) {
                      //변경할 폼아이템 옵션 설정
                      var options = {
                          format: obj.FORMAT_VR
                      }
                      //해당 폼아이템(target_id)에 포멧 옵션값 적용
                      target_id.setOptions(options)
                    }
            
                  }
                } catch (exception) {
                  console.error(exception);
                }
              },
                /* --------------------------------------------------------------------------------------------
                *  @desc           실행예산통제메뉴등록 조회
                *  @ex             getBudgetControlMenuList()
                * --------------------------------------------------------------------------------------------
                *
                * --------------------------------------------------------------------------------------------
                *  @return         실행예산통제메뉴리스트
                * ------------------------------------------------------------------------------------------*/
            
                getBudgetControlMenuList: function () {
                  var MENU_LIST = null;
                  {
                    dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_BudgetControl_Menu'), {
                      async: false,
                      data: {
                        menu_cd: dews.ui.page.menu.id
                      }
                    }).done(function (data) {
                      MENU_LIST = data;
                    }).fail(function (xhr, status, error) {
                      setTimeout(function () {
                        dews.ui.loading.hide(); //로딩화면 CLOSE
                      }, 0);
                      dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                    });
                  }
                  return MENU_LIST;
                },
                /* --------------------------------------------------------------------------------------------
                *  @desc           그리드 데이터의 상위레벨 데이터까지 조회한다.
                *  @ex             getBudgetGridList(obj)
                *  @return         실행예산통제설정등록 리스트
                * ------------------------------------------------------------------------------------------*/
                getBudgetGridList: function (obj) {
                  var GRID_LIST = null;
                  {
                    var action_bg_cds = "";
                    $.each(obj.grid.dataItems(), function (idx, data) {
                      action_bg_cds += data.ACTION_BG_CD + "|";
                    });
                    dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_BudgetGridList'), {
                      async: false,
                      data: {
                        pjt_no: obj.pjt_no,
                        action_bg_cds: action_bg_cds
                      }
                    }).done(function (data) {
                      // 1) 그리드에 세팅되었던 요청금액을 상위금액포함된 데이터소스에 세팅한다.
                      var requ_amt = 0;
                      var obj_requ_amt = 0;
                      var exclude_amt = 0;
                      var obj_exclude_amt = 0;
            
                      $.each(data, function (i, allData) {
                        $.each(obj.grid.dataItems(), function (j, gridData) {
                          if (allData.ACTION_BG_CD == gridData.ACTION_BG_CD) {
                            requ_amt = 0;
                            obj_requ_amt = 0;
                            exclude_amt = 0;
                            obj_exclude_amt = 0;
            
                            if (allData.REQU_AMT) {
                              requ_amt = allData.REQU_AMT;
                            }
            
                            if (obj.grid.getCellValue(j, obj.amt_column)) {
                              obj_requ_amt = obj.grid.getCellValue(j, obj.amt_column);
                            }
            
                            if (allData.EXCLUDE_AMT) {
                              exclude_amt = allData.EXCLUDE_AMT;
                            }
            
                            if (obj.grid.getCellValue(j, obj.exclude_amt_column)) {
                              obj_exclude_amt = obj.grid.getCellValue(j, obj.exclude_amt_column);
                            }
            
                            allData.REQU_AMT = requ_amt + obj_requ_amt;
                            allData.EXCLUDE_AMT = exclude_amt + obj_exclude_amt;
                            return true;
                          }
                        });
                      });
            
            
                      // 2) 세팅된 내역의 요청금액을 자기 상위공종에 SUM한다.
                      var targetRequAmt = 0;
                      var targetExcludeAmt = 0;
                      for (var i = data.length - 1; i >= 0; i--) {
                        for (var target = 0; target < data.length; target++) {
                          if (data[i].UPACTBD_CD == data[target].ACTION_BG_CD) {
                            if (data[target].REQU_AMT) {
                              targetRequAmt = data[target].REQU_AMT;
                            }
                            if (data[target].EXCLUDE_AMT) {
                              targetExcludeAmt = data[target].EXCLUDE_AMT;
                            }
                            data[target].REQU_AMT = targetRequAmt + (data[i].REQU_AMT ? data[i].REQU_AMT : 0);
                            data[target].EXCLUDE_AMT = targetExcludeAmt + (data[i].EXCLUDE_AMT ? data[i].EXCLUDE_AMT : 0);
            
                            targetRequAmt = 0;
                            targetExcludeAmt = 0;
                            break;
                          }
                        }
                      }
                      GRID_LIST = data;
                    }).fail(function (xhr, status, error) {
                      setTimeout(function () {
                        dews.ui.loading.hide(); //로딩화면 CLOSE
                      }, 0);
                      dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                    });
                  }
                  return GRID_LIST;
                },
                /* --------------------------------------------------------------------------------------------
                *  @desc           실행예산통제설정등록 조회
                *  @ex             getBudgetControlType1List(obj)
                * --------------------------------------------------------------------------------------------
                *
                * --------------------------------------------------------------------------------------------
                *  @return         실행예산통제설정등록 리스트
                * ------------------------------------------------------------------------------------------*/
            
                getBudgetControlType1List: function (obj, GRID_LIST) {
                  var SET_LIST = null;
                  {
                    dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Budget_Control_Type1_list'), {
                      async: false,
                      data: {
                        pjt_no: obj.pjt_no,
                        bg_ym: obj.bg_ym,
                        emp_no: obj.emp_no,
                        dept_cd: obj.dept_cd
                      }
                    }).done(function (data) {
                      // (1) 내역들의 요청금액을 세팅한다.
                      var gridValue;
                      var gridExcludeValue;
                      var warn_remian_amt = 0;
                      var ctrl_remain_amt = 0;
            
                      for (var i = 0; i < data.length; i++) {
                        for (var j = 0; j < GRID_LIST.length; j++) {
                          if (data[i].ACTION_BG_CD == GRID_LIST[j].ACTION_BG_CD) {
                            gridValue = GRID_LIST[j].REQU_AMT;
                            gridExcludeValue = GRID_LIST[j].EXCLUDE_AMT;
            
                            if (gridValue) {
                              data[i].REQU_AMT = gridValue;
                            }
                            if (gridExcludeValue) {
                              /* 기집행금액에서 빼줘야할 금액이 있다면 여기서 빼줍니다~
                              1) 외주계약저장시 기존 저장금액은 기집행금액에서 빼준다.
                              2) 외주발주 승인요청시 변경발주건을 승인요청할때 기집행금액에서 기실행발주금액은 빼준다.
                              */
                              // 기집행금액 = 기집행금액 - 원본요청금액
                              if (data[i].ALL_BG_EXCTN_AMT) {
                                data[i].ALL_BG_EXCTN_AMT = data[i].ALL_BG_EXCTN_AMT - gridExcludeValue;
                              }
                              if (data[i].MON_BG_EXCTN_AMT) {
                                data[i].MON_BG_EXCTN_AMT = data[i].MON_BG_EXCTN_AMT - gridExcludeValue;
                              }
                              if (data[i].DEPT_BG_EXCTN_AMT) {
                                data[i].DEPT_BG_EXCTN_AMT = data[i].DEPT_BG_EXCTN_AMT - gridExcludeValue;
                              }
                              if (data[i].USER_BG_EXCTN_AMT) {
                                data[i].USER_BG_EXCTN_AMT = data[i].USER_BG_EXCTN_AMT - gridExcludeValue;
                              }
            
            
                              // 잔여금액 = 잔여금액 - 원본요청금액
                              if (data[i].WARN_REMAIN_AMT) {
                                warn_remian_amt = data[i].WARN_REMAIN_AMT;
                              }
                              if (data[i].CTRL_REMAIN_AMT) {
                                ctrl_remain_amt = data[i].CTRL_REMAIN_AMT;
                              }
                              data[i].WARN_REMAIN_AMT = warn_remian_amt + gridExcludeValue;
                              data[i].CTRL_REMAIN_AMT = ctrl_remain_amt + gridExcludeValue;
                              warn_remian_amt = 0;
                              ctrl_remain_amt = 0;
                            }
                          }
                        }
                      }
            
                      // (2) 잔여금액 - 요청금액 = abs(초과금액)
                      var remainAmt = 0;
                      var requAmt = 0;
                      $.each(data, function (idx, item) {
                        remainAmt = item.CTRL_REMAIN_AMT;
                        if (!remainAmt) {
                          remainAmt = 0;
                        }
                        requAmt = item.REQU_AMT;
                        if (!requAmt) {
                          requAmt = 0;
                        }
                        data[idx].OVER_AMT = (remainAmt - requAmt) >= 0 ? undefined : Math.abs(remainAmt - requAmt);
                      });
                      SET_LIST = data;
                    }).fail(function (xhr, status, error) {
                      setTimeout(function () {
                        dews.ui.loading.hide(); //로딩화면 CLOSE
                      }, 0);
                      dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                    });
                  }
                  return SET_LIST;
                },
                /* --------------------------------------------------------------------------------------------
                *  @desc           실행예산통제 공통 함수
                *  @ex             BudgetControl(pjt_no, emp_no, dept_cd, bg_ym, evnt_fg, grid, bg_cd_column, amt_column, exclude_amt_column)
                *  @memo           BudgetControl(프로젝트코드,사원번호, 사원의부서코드, 통제체크년월, 이벤트구분, 예산체크할그리드, 실행예산코드컬럼명, 예산체크요청금액컬럼명, 예산체크요청 원본금액컬럼명)
                *                  evnt_fg : 1(승인요청-PSDOUT00200), 2(요청취소-PSDOUT00200), 3(검토완료-PSDOUT00300), 4(완료취소-PSDOUT00300), 5(업체선정-PSDOUT00400),
                *                            6(선정취소-PSDOUT00400), 7(저장-PSDOUT00500), 8(해약-PSDOUT00500), 9(해약취소-PSDOUT00500), 10(승인요청-PSDOUT00800),
                *                           11(요청취소-PSDOUT00800), 12(승인-PSDOUT00900), 13(승인취소-PSDOUT00900), 14(청구-PSDEXP00100), 15(청구취소-PSDEXP00100),
                *                           16(전표발행-PSDEXP00500), 17(발행취소-PSDEXP00500), 18(저장-PSDLAR00200), 19(저장-PSDLAR00300), 20(집계취소-PSDLAR00300)
                *                  exclude_amt_column : 집행금액에서 제외할 컬럼을 지정합니다.
                *                                   저장후 그리드 금액 수정후 체크시 기존집행금액을 제외할때 사용합니다.
                *                                   외주발주품의등록에서 변경발주건 승인요청시 기발주금액을 제외할때 사용합니다.
                *                 dialog.getInitData().help_type : 도움창의 사용용도!!!!!!!!!!!!!!!!!
                *                        "1" - 실행예산통제메뉴설정에 사용중인 메뉴(외주발주, 외주견적, 외주계약, 외주기성)에서 진행시 예산통제 체크를 위해서 사용합니다.
                *                        "2" - 실행예산등록/승인메뉴에서 요청, 요청취소, 승인, 승인취소시 해당 도움창을 사용한다. 집행금액과의 비교를 위해서 사용합니다.
                *                        "3" - 실행예산통제설정등록메뉴에서 금액수정이나 통제여부/경고여부 체크시 집행금액과의 비교를 위해서 사용합니다.
                *  @return         "PASS"-예산체크통과, "STOP"-통제함, "WARNING"-경고, "ERROR"-오류
                * --------------------------------------------------------------------------------------------*/
                BudgetControl: function (obj) {
                  try {
                    /* 개발자가 체크해야될 사항 START */
                    if (!obj.grid) {
                      dews.alert("[그리드누락]" + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
                    if (!obj.emp_no) {
                      dews.alert("[사원번호누락]" + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
                    if (!obj.dept_cd) {
                      dews.alert("[부서코드누락]" + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
                    if (!obj.bg_cd_column) {
                      dews.alert("[실행예산코드컬럼누락]" + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
                    if (!obj.amt_column) {
                      dews.alert("[요청금액컬럼누락]" + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
            
                    var hasColumns = false;
                    $.each(obj.grid.getColumns(), function (idx, c) {
                      if (c.type == 'group') {
                        $.each(c.columns, function (lowIdx, lowC) {
                          if (obj.bg_cd_column == lowC.name) {
                            hasColumns = true;
                            return false;
                          }
                        });
                        if (hasColumns) {
                          return false;
                        }
                      } else {
                        if (obj.bg_cd_column == c.name) {
                          hasColumns = true;
                          return false;
                        }
                      }
                    });
                    if (!hasColumns) {
                      dews.alert("해당그리드에 [" + obj.bg_cd_column + "] 컬럼이 없습니다." + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
            
                    hasColumns = false;
                    $.each(obj.grid.getColumns(), function (idx, c) {
                      if (c.type == 'group') {
                        $.each(c.columns, function (lowIdx, lowC) {
                          if (obj.amt_column == lowC.name) {
                            hasColumns = true;
                            return false;
                          }
                        });
                        if (hasColumns) {
                          return false;
                        }
                      } else {
                        if (obj.amt_column == c.name) {
                          hasColumns = true;
                          return false;
                        }
                      }
                    });
                    if (!hasColumns) {
                      dews.alert("해당그리드에 [" + obj.amt_column + "] 컬럼이 없습니다." + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
            
            
                    if (!obj.pjt_no) {
                      dews.alert("[프로젝트코드누락]" + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
                    if (!obj.bg_ym) {
                      dews.alert("[년월누락]" + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
                    if (!obj.evnt_fg) {
                      dews.alert("[이벤트구분누락]" + "\n" + "개발담당자에게 문의하세요." + "\n" + "(PS_UTIL.BudgetControl)", "warning");
                      return "ERROR";
                    }
                    /* 개발자가 체크해야될 사항 END */
            
            
                    setTimeout(function () {
                      dews.ui.loading.show({
                        text: '예산 Cheking...'
                      });
                    }, 0);
            
            
            
                    var COM_PS_BG0000 = this.getCmpyEnvControl("PS", "BC00000");
                    var MENU_LIST = null;
                    if (COM_PS_BG0000 == "Y") {
                      console.log("[BudgetControl]회사환경설정(PS, BC00000)-통제함");
                      {
                        MENU_LIST = this.getBudgetControlMenuList();
                      }
            
                      var CTRL_OK = null;
                      var EVENT_OK = null;
                      if (MENU_LIST && MENU_LIST.length > 0) {
                        $.each(MENU_LIST, function (idx, menu) {
                          if (menu.EVNT_FG == obj.evnt_fg) {
                            EVENT_OK = true;
                            CTRL_OK = menu.CTRL_YN;
                            return false;
                          }
                        });
                      } else {
                        console.log("[BudgetControl]실행예산통제메뉴등록 미등록 - 통제안함");
                        return "PASS";
                      }
            
                      if (EVENT_OK) {
                        if (CTRL_OK == "Y") {
                          console.log("[BudgetControl]실행예산통제시작!");
            
                          var GRID_LIST = this.getBudgetGridList(obj); // 그리드 데이터의 상위레벨 데이터까지 조회한다.
                          var SET_LIST = this.getBudgetControlType1List(obj, GRID_LIST);
            
            
                          var ctrl_remain_amt = 0; // 통제잔연금액
                          var warn_remain_amt = 0; // 경고잔여금액
                          var gridValue = 0;
                          var showWarning = false;
                          for (var i = 0; i < GRID_LIST.length; i++) {
                            for (var j = 0; j < SET_LIST.length; j++) {
                              if (SET_LIST[j].ACTION_BG_CD == GRID_LIST[i].ACTION_BG_CD) {
                                gridValue = 0;
                                if (GRID_LIST[i].REQU_AMT) {
                                  gridValue = GRID_LIST[i].REQU_AMT;
                                }
                                warn_remain_amt = 0;
                                if (SET_LIST[j].WARN_REMAIN_AMT) {
                                  warn_remain_amt = SET_LIST[j].WARN_REMAIN_AMT;
                                }
                                ctrl_remain_amt = 0;
                                if (SET_LIST[j].CTRL_REMAIN_AMT) {
                                  ctrl_remain_amt = SET_LIST[j].CTRL_REMAIN_AMT;
                                }
                                // (1) 경고알림여부가 Y이고, 요청금액이 경고잔여금액을 초과할 경우 메세지를 통해 알려준다.
                                if (SET_LIST[j].ERP_WARN_NOTF_YN == "Y" && warn_remain_amt < gridValue) {
                                  showWarning = true;
                                }
            
                                // (2) 통제여부가 Y이고, 요청금액이 통제잔여금액을 초과할 경우 예산통제팝업출력!
                                if (SET_LIST[j].CTRL_YN == "Y" && ctrl_remain_amt < gridValue) {
                                  var dialog = dews.ui.dialog("H_PS_BUDGET_CONTROL_C", {
                                    url: '~/codehelp/PS/H_PS_BUDGET_CONTROL_C',
                                    title: '예산통제',
                                    width: 1800,
                                    height: 800,
                                    buttons: 'close',
                                  });
                                  dialog.setInitData(obj);
                                  dialog.open();
                                  return "STOP";
                                }
                              }
                            }
                          }
            
            
                          if (showWarning) {
                            return "WARNING";
                          }
                          return "PASS";
            
                        } else {
                          console.log("[BudgetControl]실행예산통제메뉴등록에 통제여부='N' - 통제안함");
                          return "PASS";
                        }
                      } else {
                        console.log("[BudgetControl]실행예산통제메뉴등록에 이벤트구분 미등록 - 통제안함");
                        return "PASS";
                      }
                    } else {
                      console.log("[BudgetControl]회사환경설정(PS, BC00000) - 통제안함");
                      return "PASS";
                    }
                  }
                  catch (exception) {
                    dews.error(exception);
                    return true;
                  }
                  finally {
                    setTimeout(function () {
                      dews.ui.loading.hide(); //로딩화면 CLOSE
                    }, 0);
                  }
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc           실행예산통제여부조회
                  *                  실행예산등록 - 요청/요청취소시 집계금액 체크
                  *                  실행예산승인 - 승인/승인취소시 집계금액 체크
                  *  @ex             getBudgetControlType2List()
                  *  @params         pjt_no : 프로젝트코드
                  *                  ver_sq : 실행예산버전순번
                  *                  ver_st : 요청(2-1), 요청취소(1), 승인(3), 승인취소(2-2)
                  * --------------------------------------------------------------------------------------------
                  *
                  * --------------------------------------------------------------------------------------------
                  *  @return         실행예산통제메뉴리스트
                  * ------------------------------------------------------------------------------------------*/
            
                getBudgetControlType2List: function (pjt_no, ver_sq, ver_st) {
                  var return_value = null;
                  {
                    dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Budget_Control_Type2_list'), {
                      async: false,
                      data: {
                        pjt_no: pjt_no,
                        ver_sq: ver_sq,
                        ver_st: ver_st
                      }
                    }).done(function (list) {
                      $.each(list, function (idx, data) {
                        if (data.CTRL_YN && data.CTRL_YN == "Y") {
                          // 통제체크 진행
                          var all_ctrl_amt = 0;
                          if (data.ALL_CTRL_AMT) {
                            all_ctrl_amt = data.ALL_CTRL_AMT;
                          }
                          var bg_exctn_amt = 0;
                          if (data.ALL_BG_EXCTN_AMT) {
                            bg_exctn_amt = data.ALL_BG_EXCTN_AMT;
                          }
            
                          if (all_ctrl_amt < bg_exctn_amt) {
                            // 요청하려는 금액이 기존에 집행된 금액보다 작으면 통제처리함.
                            return_value = "STOP";
                            return false;
                          }
                        }
            
                        if (data.ERP_WARN_NOTF_YN && data.ERP_WARN_NOTF_YN == "Y") {
                          // 경고체크 진행
                          var all_warn_amt = 0;
                          if (data.ALL_WARN_AMT) {
                            all_warn_amt = data.ALL_WARN_AMT;
                          }
                          var bg_exctn_amt = 0;
                          if (data.ALL_BG_EXCTN_AMT) {
                            bg_exctn_amt = data.ALL_BG_EXCTN_AMT;
                          }
            
                          if (all_warn_amt < bg_exctn_amt) {
                            // 요청하려는 금액이 기존에 집행된 금액보다 작으면 경고처리함.
                            return_value = "WARNING";
                            return false;
                          }
                        }
                      });
            
            
                    }).fail(function (xhr, status, error) {
                      setTimeout(function () {
                        dews.ui.loading.hide(); //로딩화면 CLOSE
                      }, 0);
                      dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                    });
                  }
                  return return_value;
                },
                /* --------------------------------------------------------------------------------------------
                *  @desc           실행예산통제설정등록-경고금액/통제금액/경고알림/통제여부수정시 집행금액과 체크
                *  @ex             getBudgetControlType3List()
                *  @params         obj : 경고금액/통제금액/경고알림/통제여부 수정 행 리스트
                * --------------------------------------------------------------------------------------------*/
                getBudgetControlType3List: function (obj) {
                  var returnValue = null;
            
                  // 해당프로젝트/예산건으로 집행된 내역을 조회한다.
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Budget_Control_Type3_list'), {
                    async: false,
                    data: {
                      pjt_no: obj.pjt_no,
                      bg_ym: obj.bg_ym,
                      emp_no: obj.emp_no,
                      dept_cd: obj.dept_cd
                    }
                  }).done(function (exctn_list) {
                    // 1) 집행된 금액과 그리드에 수정된 금액을 체크해서 집행금액보다 적은건이 있는지 확인다.
                    // 이때 통제금액우선 체크.
            
                    $.each(exctn_list, function (exctn_idx, exctn_data) {
                      $.each(obj.grid, function (idx, data) {
                        if (exctn_data.ACTION_BG_CD == data.ACTION_BG_CD) {
                          if (exctn_data.ALL_BG_EXCTN_AMT2 > data.CTRL_AMT2) {
                            // 집행금액보다 통제금액이 작다면
                            returnValue = "STOP";
                            return false;
                          }
                          if (exctn_data.ALL_BG_EXCTN_AM2 > data.WARN_AMT2) {
                            // 집행금액보다 경고금액이 작다면
                            returnValue = "WARNING";
                          }
                        }
                      });
                      if (returnValue == "STOP") {
                        return false;
                      }
                    });
                  }).fail(function (xhr, status, error) {
                    setTimeout(function () {
                      dews.ui.loading.hide(); //로딩화면 CLOSE
                    }, 0);
                    dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                  });
                  return returnValue;
                },
            
                /**
                  * @method 채번
                  * @param {*} module_cd 모듈코드
                  * @param {*} class_cd 항목코드
                  * @param {*} ymd 날짜
                  */
                getSeqNo: function (module_cd, class_cd, ymd) {
                  var sequenceNumber;
            
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'getSequenceNumber'), {
                    async: false,
                    data: {
                      module_cd: module_cd,
                      class_cd: class_cd,
                      ymd: ymd || this.getToday()
                    }
                  }).done(function (data) {
                    if (data.length > 0) {
                      sequenceNumber = data;
                    }
                  }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                  });
                  return sequenceNumber;
                },
            
                /**
                  * @method 사용자정보조회(CI_USER_MST)
                  * 사용자아이디가 null일경우 로그인 USER ID로 정보를 조회합니다.
                  */
                getUserInfo: function (user_id) {
                  var user_info = null;
            
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_USER_INFO_list'), {
                    async: false,
                    data: {
                      user_id: user_id || ""
                    }
                  }).done(function (data) {
                    if (data.length > 0) {
                      user_info = data;
                    }
                  }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                  });
                  return user_info;
                },
            
            
                /* --------------------------------------------------------------------------------------------
                *  @desc           단수조정
                *  @ex             getNumberRound()
                *  @params         n 값  round PS_P800값
                * --------------------------------------------------------------------------------------------*/
                // PS_P800 단수조정구분
                // *  1 : 1원미만 절사
                // *  2 : 1원미만절상
                // *  3 : 10원미만절사
                // *  4 : 10원미만절상 -> 9를 더한 뒤에 10원미만자리 절사
                // *  5 : 반올림
                // *  6 : 정상
                // *  7 : 100원미만절사
                // *  8 : 100원미만절상 -> 90을 더한 뒤에 100원미만자리 절사.
                // *  9 : 1000원미만절사
                // *  10 : 1000원미만절상 -> 900을 더한 뒤에 1000원미만자리 절사.
                getNumberRound: function (n, round) {
                  var returnValue = null;
                  if (n) {
                    switch (round) {
                      case "1": // 1원미만절사
                        returnValue = Math.floor(n);
                        break;
                      case "2": // 1원미만절상
                        returnValue = Math.ceil(n);
                        break;
                      case "3": //10원미만절사
                        returnValue = Math.floor(n / 10) * 10;
                        break;
                      case "4": //10원미만절상
                        returnValue = Math.ceil(n / 10) * 10;
                        break;
                      case "5": //반올림
                        returnValue = Math.round(n);
                        break;
                      case "7": //100원미만절사
                        returnValue = Math.floor(n / 100) * 100;
                        break;
                      case "8": //100원이상절상
                        returnValue = Math.ceil(n / 100) * 100;
                        break;
                      case "9": //1000원미만절사
                        returnValue = Math.floor(n / 1000) * 1000;
                        break;
                      case "10": //1000원미만절상
                        returnValue = Math.ceil(n / 1000) * 1000;
                        break;
                      default:
                        returnValue = n;
                        break;
                    }
                  }
                  return returnValue;
                },
                /**
                  * 메일 보내기
                  * @example var ret = Mail.send("MAIL0401", {evrpt_sq: self.evrpt_sq.code(), ....} );
                  * @param {*} mailKey : ps_MAIL01010 (프로젝트 승인시 책임자에게 승인안내메일발송)
                  *                    : ps_MAIL01020 (프로젝트 종료일이 30일남은 프로젝트 책임자에게 알림메일 발송.)
                  * @param {*} param : 파라미터 객체
                  * @return {*} boolean
                  */
                sendMail: function (mailKey, param) {
                  var ret = false;
                  dews.api.post(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_SendMail"), {
                    async: true,
                    data: {
                      mailKey: mailKey,
                      param: JSON.stringify(param)
                    }
                  }).done(function (data) {
                    if (data) {
                      ret = true;
                    }
                  });
                  return ret;
                },
                /**
                * @method 주소정보로 경,위도조회.
                * @param {*} address 주소
                */
                getCoordination: function (address) {
                  var coordinates;
            
                  // 여기서 프로그래스바를 설정해주면 안뜨는 현상 발생
                  // 이 함수를 쓰기 전 부분에서 프로그래스바를 띄워줘야함
                  /*
                  dews.ui.loading.show({
                    type: 'full',
                    text: '경위도 조회중...'
                  });
                  */
            
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_Coordination'), {
                    async: false,
                    data: {
                      address: address
                    }
                  }).done(function (data) {
                    coordinates = data;
                    dews.ui.loading.hide();
                  }).fail(function (xhr, status, error) {
                    dews.ui.loading.hide();
                    dews.alert("경위도를 조회하지 못했습니다.", "warning");
                  });
                  return coordinates;
                },
                /**
                * @method 현장정보로 날씨구하기.
                * @param {*} pjt_no 프로젝트코드
                */
                getWeather: function (pjt_no, baseDate) {
                  var weather;
            
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_Weather'), {
                    async: false,
                    data: {
                      pjt_no: pjt_no,
                      baseDate: baseDate
                    }
                  }).done(function (data) {
                    weather = data;
                  }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                  });
                  return weather;
                },
                /**
                  * @method convertCodeDTL : 공통코드의 SYSDEF_CD or SYSDEF_NM 값을 통하여 SYSDEF_CD값 리턴.
                  *                          주로 엑셀업로드시 "생성"이란값을 입력받으면 "1" 이라는 코드값으로 변환해주기 위해 사용합니다.
                  * @param {*} sysdef : 찾아보는 대상 SYSDEF_CD or SYSDEF_NM (예: 1 or 생성)
                  * @param {*} datasource : 공통코드 dataSource
                  * @return returnValue (예 : { SUCCESS: false, MSG: "미등록 코드입니다." } or { SUCCESS: true, MSG: "1"} )
                  */
                convertCodeDTL: function (sysdef, datasource) {
            
                  var returnValue = { SUCCESS: false, MSG: "" };
                  if (!sysdef) return returnValue;
                  if (!datasource) return sysdef;
            
                  if (datasource.options) {
                    // datasource가 객체일때,
                    $.each(datasource.options.data, function (_idx, _data) {
                      if (sysdef == _data.SYSDEF_CD) {
                        returnValue.SUCCESS = true;
                        returnValue.MSG = _data.SYSDEF_CD;
                        return false;
                      }
                    });
            
                    if (!returnValue.SUCCESS) {
                      $.each(datasource.options.data, function (_idx, _data) {
                        if (sysdef == _data.SYSDEF_NM) {
                          returnValue.SUCCESS = true;
                          returnValue.MSG = _data.SYSDEF_CD;
                          return false;
                        }
                      });
                    }
                  }
                  else {
                    // datasource가 배열일때,
                    $.each(datasource, function (_idx, _data) {
                      if (sysdef == _data.SYSDEF_CD) {
                        returnValue.SUCCESS = true;
                        returnValue = _data.SYSDEF_CD;
                        return false;
                      }
                    });
            
                    if (!returnValue.SUCCESS) {
                      $.each(datasource, function (_idx, _data) {
                        if (sysdef == _data.SYSDEF_NM) {
                          returnValue.SUCCESS = true;
                          returnValue = _data.SYSDEF_CD;
                          return false;
                        }
                      });
                    }
                  }
                  if (!returnValue.SUCCESS) {
                    // 값을 못찾으면
                    returnValue.MSG = "미등록 코드입니다.";
                  }
                  return returnValue;
                },
            
                /**
                  * @method convertExcelDate : 엑셀로부터 입력받은 날짜값의 타입에 따라 String형의 날짜값 리턴.
                  * @param {*} excelValue : 엑셀로부터 입력받은 날짜값
                  * @param {*} returnType : String형 날짜값의 포맷. default : new Date타입, String : '20210713', PipeString : '2021-07-13', Date : new Date타입
                  * @return returnDate (Date) DateType - Tue Jul 13 2021 09:00:00 GMT+0900 (대한민국 표준시)
                  * @return returnDate (String) '20210713'
                  * @return returnDate (PipeString) '2021-07-13'
                  */
                 convertExcelDate: function (excelValue, returnType) {
                  var returnDate = null;
            
                  if (excelValue instanceof Date) {
                    returnDate = dews.date.format(excelValue, 'yyyyMMdd');
                  }
                  else {
                    // 숫자만 추출
                    var oriDate = gerp.PS.UTIL.replaceOnlyNumber(String(excelValue));
                    if (oriDate.length == 8) {
                      returnDate = dews.date.format(oriDate, 'yyyyMMdd');
                    } else if (oriDate.length == 6) {
                      // excelValue가 20220914 가 아닌, 201903 으로 년월타입의 6자리 데이터가 넘어올수도 있습니다.
                      returnDate = dews.date.format(oriDate, 'yyyyMM');
                    }
                  }
                  if (!returnDate) {
                    return excelValue;
                  }
            
                  if (returnType == "String") {
                    // excelValue가 20220914 가 아닌, 201903 으로 년월타입의 6자리 데이터가 넘어올수도 있습니다.
                    // 년월일이 아닌 년월 컬럼은 convertExcelDate 함수를 호출 시 returnType 파라미터에 'String'으로 넘겨주면 해당 로직을 탑니다.
                    // ex) row.COMT_YM = PS_UTIL.convertExcelDate(row.COMT_YM, 'String');
                    return returnDate;
                  } else if (returnType == "PipeString") {
                    return dews.date.format(returnDate, 'yyyy-MM-dd');
                  }
                  return new Date(dews.date.format(returnDate, 'yyyy-MM-dd'));
                },
                /**
                * @method ConvertAmt : 환종, 환율에 따라 금액변환
                * @param {*} p_all_list : 회사환경설정등록 데이터 리스트(통제유형 : 자릿수, 사용여부 : Y, 시스템적용여부 Y)
                * @param {*} p_ctrl_cd : 통제코드
                * @param {*} oriAmt : 변환할 금액
                * @param {*} exch_cd : 환종
                * @param {*} exrt_rt : 환율
                */
            
                ConvertAmt: function (p_all_list, p_ctrl_cd, oriAmt, exch_cd, exrt_rt) {
                  //금액, 환종, 환율
                  var returnAmt = null;
                  if (exch_cd == "JPY") {
                    returnAmt = oriAmt * exrt_rt / 100;
                  } else {
                    returnAmt = oriAmt * exrt_rt;
                  }
                  returnAmt = this.getChangeNumber(p_all_list, p_ctrl_cd, returnAmt, exch_cd);
                  //return 변환금액
                  return returnAmt;
                },
            
                /**
                * @method getCompanyExch : 회사환종가져오기
                */
                getCompanyExch: function () {
                  //금액, 환종, 환율
                  var exch_cd;
            
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_CompanyExch'), {
                    async: false,
                    data: {}
                  }).done(function (data) {
                    if (data.length > 0) {
                      exch_cd = data[0].EXCH_CD;
                    }
                  }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                  });
                  return exch_cd;
                },
            
                /**
                * @method getPjtNoExch : 프로젝트환종가져오기
                */
                getPjtNoExch: function (pjt_no) {
                  //환종
                  var exch_cd;
            
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_PjtNoExch'), {
                    async: false,
                    data: {
                      pjt_no: pjt_no
                    }
                  }).done(function (data) {
                    exch_cd = data[0].SCALA;
                  }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                  });
                  return exch_cd;
                },
            
                /**
                  * @method getAutoNumRule : 자동채번규칙 조회
                  */
                getAutoNumRule: function (editmask_cd) {
                  var extno_mthd_cd = "1";
            
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_Auto_Num_Rule'), {
                    async: false,
                    data: {
                      editmask_cd: editmask_cd
                    }
                  }).done(function (ruleList) {
                    if (ruleList && ruleList.length > 0) {
                      extno_mthd_cd = ruleList[0].EXTNO_MTHD_CD;
                    }
                  }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                  });
                  return extno_mthd_cd;
                },
            
                /**
                  * @method getAutoNumRuleCol : 자동채번규칙 COL_CD 조회
                  */
                getAutoNumRuleCol: function (editmask_cd) {
                  var colList = [];
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_Auto_Num_Rule'), {
                    async: false,
                    data: {
                      editmask_cd: editmask_cd
                    }
                  }).done(function (ruleList) {
                    if (ruleList && ruleList.length > 0) {
                      colList = ruleList.map(function (item) { return item.COL_CD; });
                    }
                  }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.error(error);
                  });
                  return colList.filter(function (a, i, self) {
                    return self.indexOf(a) === i;
                  });
                  // return Array.from(new Set(colList));
                },
            
                /**
                * @method SET_AUTO_PJT_NO : 자동채번규칙을 통해 프로젝트 코드를 자동생성합니다.
                * @param  dataItems : mDirtyMST.Added or new Array(mDirtyMST.Added[0]);
                */
                SET_AUTO_PJT_NO: function (dataItems) {
                  var error_msg = null;
                  $.each(dataItems, function (gridRow, gridData) {
                    if (!gridData.EDITMASK_CD) {
                      error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n" + "코드규칙누락!";
                      return false;
                    }
            
            
            
                    dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_Get_Auto_Num_Rule'), {
                      async: false,
                      data: {
                        editmask_cd: gridData.EDITMASK_CD
                      }
                    }).done(function (ruleList) {
                      if (ruleList && ruleList.length > 0) {
                        if (ruleList[0].EXTNO_MTHD_CD == "2") { // 채번방식(1:수동, 2:자동)
                          gerp.PS.UTIL.getCodeData("PS", "Y:P00690", null, null, null, null, null);
            
            
                          var MAX_COMB_COL_CD = ruleList[ruleList.length - 1].COMB_COL_CD;
                          var EDITMASK_DC = ruleList[0].EDITMASK_DC;
            
                          //*********************/
                          // 코드규칙 적용 START //
                          //*********************/
                          var COMB_COL_CD_1 = [];
                          var COMB_COL_CD_2 = [];
                          var COMB_COL_CD_3 = [];
                          var COMB_COL_CD_4 = [];
                          var COMB_COL_CD_5 = [];
                          var COMB_COL_CD_6 = [];
                          var COMB_COL_CD_7 = [];
                          $.each(ruleList, function (idx, item) {
                            if (!item.COMB_COL_CD) {
                              error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n"
                                + "조합구분이 누락되었습니다." + "\n"
                                + "코드규칙관리-자동채번규칙을 확인하세요.";
                              return false;
                            }
                            switch (item.COMB_COL_CD) {
                              case "1":
                                COMB_COL_CD_1.push(item);
                                break;
                              case "2":
                                COMB_COL_CD_2.push(item);
                                break;
                              case "3":
                                COMB_COL_CD_3.push(item);
                                break;
                              case "4":
                                COMB_COL_CD_4.push(item);
                                break;
                              case "5":
                                COMB_COL_CD_5.push(item);
                                break;
                              case "6":
                                COMB_COL_CD_6.push(item);
                                break;
                              case "7":
                                COMB_COL_CD_7.push(item);
                                break;
                            }
                          });
            
                          if (Number(MAX_COMB_COL_CD) >= 1) {
                            ////////////////////////////////////////
                            // 조합1 자동채번규칙 적용
                            var PJT_NO = "";
                            var add_pjt_no = "";
                            var resultData = null;
                            $.each(COMB_COL_CD_1, function (_row, item) {
                              add_pjt_no = "";
                              resultData = gerp.PS.UTIL.AutoProcess(gridData, item);
                              if (resultData.SUCCESS) {
                                add_pjt_no = resultData.MSG;
                                return false;
                              } else {
                                if (resultData.MSG) {
                                  error_msg = resultData.MSG;
                                  return false;
                                }
                              }
                            });
                            if (error_msg) {
                              return false;
                            }
            
                            if (!add_pjt_no) {
                              error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n"
                                + "조합1의 자동채번규칙을 위반하였습니다." + "\n"
                                + "코드규칙관리-자동채번규칙을 확인하세요.";
                              return false;
                            }
                            PJT_NO = PJT_NO.concat(add_pjt_no);
                            add_pjt_no = "";
                          }
            
                          var MaskCode = "";
                          // 전체 프로젝트코드 자릿수와 현재까지 만들어진 프로젝트코드의 길이 같다면 뒤에 특수문자들은 추가하지 않습니다.
            
                          var clearPJT_NO = PJT_NO;
            
                          $.each(objCodeDtl.PS.P00690, function (key, val) {
                            clearPJT_NO = gerp.PS.UTIL.replaceAll(clearPJT_NO, val.SYSDEF_NM, '');
                          });
                          if (clearPJT_NO.length != ruleList[0].PJT_CD_LEN_CNT) {
                            MaskCode = EDITMASK_DC.substring(PJT_NO.length, PJT_NO.length + 1);
                            if (MaskCode) {
                              $.each(objCodeDtl.PS.P00690, function (key, val) {
                                if (MaskCode == val.SYSDEF_NM) {
                                  PJT_NO = PJT_NO + val.SYSDEF_NM;
                                  return false;
                                }
                              });
                            }
                          }
            
                          if (Number(MAX_COMB_COL_CD) >= 2) {
                            ////////////////////////////////////////
                            // 조합2 자동채번규칙 적용
                            $.each(COMB_COL_CD_2, function (_row, item) {
                              add_pjt_no = "";
                              resultData = gerp.PS.UTIL.AutoProcess(gridData, item);
                              if (resultData.SUCCESS) {
                                add_pjt_no = resultData.MSG;
                                return false;
                              } else {
                                if (resultData.MSG) {
                                  error_msg = resultData.MSG;
                                  return false;
                                }
                              }
                            });
                            if (error_msg) {
                              return false;
                            }
            
                            if (!add_pjt_no) {
                              error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n"
                                + "조합2의 자동채번규칙을 위반하였습니다." + "\n"
                                + "코드규칙관리-자동채번규칙을 확인하세요.";
                              return false;
                            }
                            PJT_NO = PJT_NO.concat(add_pjt_no);
                            add_pjt_no = "";
                          }
            
                          // 전체 프로젝트코드 자릿수와 현재까지 만들어진 프로젝트코드의 길이 같다면 뒤에 특수문자들은 추가하지 않습니다.
                          clearPJT_NO = PJT_NO;
            
                          $.each(objCodeDtl.PS.P00690, function (key, val) {
                            clearPJT_NO = gerp.PS.UTIL.replaceAll(clearPJT_NO, val.SYSDEF_NM, '');
                          });
                          if (clearPJT_NO.length != ruleList[0].PJT_CD_LEN_CNT) {
                            MaskCode = EDITMASK_DC.substring(PJT_NO.length, PJT_NO.length + 1);
                            if (MaskCode) {
                              $.each(objCodeDtl.PS.P00690, function (key, val) {
                                if (MaskCode == val.SYSDEF_NM) {
                                  PJT_NO = PJT_NO + val.SYSDEF_NM;
                                  return false;
                                }
                              });
                            }
                          }
            
                          if (Number(MAX_COMB_COL_CD) >= 3) {
                            ////////////////////////////////////////
                            // 조합3 자동채번규칙 적용
                            $.each(COMB_COL_CD_3, function (_row, item) {
                              add_pjt_no = "";
                              resultData = gerp.PS.UTIL.AutoProcess(gridData, item);
                              if (resultData.SUCCESS) {
                                add_pjt_no = resultData.MSG;
                                return false;
                              } else {
                                if (resultData.MSG) {
                                  error_msg = resultData.MSG;
                                  return false;
                                }
                              }
                            });
                            if (error_msg) {
                              return false;
                            }
            
                            if (!add_pjt_no) {
                              error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n"
                                + "조합3의 자동채번규칙을 위반하였습니다." + "\n"
                                + "코드규칙관리-자동채번규칙을 확인하세요.";
                              return false;
                            }
                            PJT_NO = PJT_NO.concat(add_pjt_no);
                            add_pjt_no = "";
                          }
            
                          // 전체 프로젝트코드 자릿수와 현재까지 만들어진 프로젝트코드의 길이 같다면 뒤에 특수문자들은 추가하지 않습니다.
                          clearPJT_NO = PJT_NO;
            
                          $.each(objCodeDtl.PS.P00690, function (key, val) {
                            clearPJT_NO = gerp.PS.UTIL.replaceAll(clearPJT_NO, val.SYSDEF_NM, '');
                          });
                          if (clearPJT_NO.length != ruleList[0].PJT_CD_LEN_CNT) {
                            MaskCode = EDITMASK_DC.substring(PJT_NO.length, PJT_NO.length + 1);
                            if (MaskCode) {
                              $.each(objCodeDtl.PS.P00690, function (key, val) {
                                if (MaskCode == val.SYSDEF_NM) {
                                  PJT_NO = PJT_NO + val.SYSDEF_NM;
                                  return false;
                                }
                              });
                            }
                          }
            
                          if (Number(MAX_COMB_COL_CD) >= 4) {
                            ////////////////////////////////////////
                            // 조합4 자동채번규칙 적용
                            $.each(COMB_COL_CD_4, function (_row, item) {
                              add_pjt_no = "";
                              resultData = gerp.PS.UTIL.AutoProcess(gridData, item);
                              if (resultData.SUCCESS) {
                                add_pjt_no = resultData.MSG;
                                return false;
                              } else {
                                if (resultData.MSG) {
                                  error_msg = resultData.MSG;
                                  return false;
                                }
                              }
                            });
                            if (error_msg) {
                              return false;
                            }
            
                            if (!add_pjt_no) {
                              error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n"
                                + "조합4의 자동채번규칙을 위반하였습니다." + "\n"
                                + "코드규칙관리-자동채번규칙을 확인하세요.";
                              return false;
                            }
                            PJT_NO = PJT_NO.concat(add_pjt_no);
                            add_pjt_no = "";
                          }
            
                          // 전체 프로젝트코드 자릿수와 현재까지 만들어진 프로젝트코드의 길이 같다면 뒤에 특수문자들은 추가하지 않습니다.
                          clearPJT_NO = PJT_NO;
            
                          $.each(objCodeDtl.PS.P00690, function (key, val) {
                            clearPJT_NO = gerp.PS.UTIL.replaceAll(clearPJT_NO, val.SYSDEF_NM, '');
                          });
                          if (clearPJT_NO.length != ruleList[0].PJT_CD_LEN_CNT) {
                            MaskCode = EDITMASK_DC.substring(PJT_NO.length, PJT_NO.length + 1);
            
                            if (MaskCode) {
                              $.each(objCodeDtl.PS.P00690, function (key, val) {
                                if (MaskCode == val.SYSDEF_NM) {
                                  PJT_NO = PJT_NO + val.SYSDEF_NM;
                                  return false;
                                }
                              });
                            }
                          }
            
                          if (Number(MAX_COMB_COL_CD) >= 5) {
                            ////////////////////////////////////////
                            // 조합5 자동채번규칙 적용
                            $.each(COMB_COL_CD_5, function (_row, item) {
                              add_pjt_no = "";
                              resultData = gerp.PS.UTIL.AutoProcess(gridData, item);
                              if (resultData.SUCCESS) {
                                add_pjt_no = resultData.MSG;
                                return false;
                              } else {
                                if (resultData.MSG) {
                                  error_msg = resultData.MSG;
                                  return false;
                                }
                              }
                            });
                            if (error_msg) {
                              return false;
                            }
            
                            if (!add_pjt_no) {
                              error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n"
                                + "조합5의 자동채번규칙을 위반하였습니다." + "\n"
                                + "코드규칙관리-자동채번규칙을 확인하세요.";
                              return false;
                            }
                            PJT_NO = PJT_NO.concat(add_pjt_no);
                            add_pjt_no = "";
                          }
            
            
            
                          // 전체 프로젝트코드 자릿수와 현재까지 만들어진 프로젝트코드의 길이 같다면 뒤에 특수문자들은 추가하지 않습니다.
                          clearPJT_NO = PJT_NO;
            
                          $.each(objCodeDtl.PS.P00690, function (key, val) {
                            clearPJT_NO = gerp.PS.UTIL.replaceAll(clearPJT_NO, val.SYSDEF_NM, '');
                          });
                          if (clearPJT_NO.length != ruleList[0].PJT_CD_LEN_CNT) {
                            MaskCode = EDITMASK_DC.substring(PJT_NO.length, PJT_NO.length + 1);
            
                            if (MaskCode) {
                              $.each(objCodeDtl.PS.P00690, function (key, val) {
                                if (MaskCode == val.SYSDEF_NM) {
                                  PJT_NO = PJT_NO + val.SYSDEF_NM;
                                  return false;
                                }
                              });
                            }
                          }
            
            
                          if (Number(MAX_COMB_COL_CD) >= 6) {
                            ////////////////////////////////////////
                            // 조합6 자동채번규칙 적용
                            $.each(COMB_COL_CD_6, function (_row, item) {
                              add_pjt_no = "";
                              resultData = gerp.PS.UTIL.AutoProcess(gridData, item);
                              if (resultData.SUCCESS) {
                                add_pjt_no = resultData.MSG;
                                return false;
                              } else {
                                if (resultData.MSG) {
                                  error_msg = resultData.MSG;
                                  return false;
                                }
                              }
                            });
                            if (error_msg) {
                              return false;
                            }
            
                            if (!add_pjt_no) {
                              error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n"
                                + "조합6의 자동채번규칙을 위반하였습니다." + "\n"
                                + "코드규칙관리-자동채번규칙을 확인하세요.";
                              return false;
                            }
                            PJT_NO = PJT_NO.concat(add_pjt_no);
                            add_pjt_no = "";
                          }
            
                          // 전체 프로젝트코드 자릿수와 현재까지 만들어진 프로젝트코드의 길이 같다면 뒤에 특수문자들은 추가하지 않습니다.
                          clearPJT_NO = PJT_NO;
            
                          $.each(objCodeDtl.PS.P00690, function (key, val) {
                            clearPJT_NO = gerp.PS.UTIL.replaceAll(clearPJT_NO, val.SYSDEF_NM, '');
                          });
                          if (clearPJT_NO.length != ruleList[0].PJT_CD_LEN_CNT) {
                            MaskCode = EDITMASK_DC.substring(PJT_NO.length, PJT_NO.length + 1);
            
                            if (MaskCode) {
                              $.each(objCodeDtl.PS.P00690, function (key, val) {
                                if (MaskCode == val.SYSDEF_NM) {
                                  PJT_NO = PJT_NO + val.SYSDEF_NM;
                                  return false;
                                }
                              });
                            }
                          }
            
                          if (Number(MAX_COMB_COL_CD) >= 7) {
                            ////////////////////////////////////////
                            // 조합7 자동채번규칙 적용
                            $.each(COMB_COL_CD_7, function (_row, item) {
                              add_pjt_no = "";
                              resultData = gerp.PS.UTIL.AutoProcess(gridData, item);
                              if (resultData.SUCCESS) {
                                add_pjt_no = resultData.MSG;
                                return false;
                              } else {
                                if (resultData.MSG) {
                                  error_msg = resultData.MSG;
                                  return false;
                                }
                              }
                            });
                            if (error_msg) {
                              return false;
                            }
            
                            if (!add_pjt_no) {
                              error_msg = "프로젝트코드 자동생성이 불가합니다." + "\n"
                                + "조합7의 자동채번규칙을 위반하였습니다." + "\n"
                                + "코드규칙관리-자동채번규칙을 확인하세요.";
                              return false;
                            }
                            PJT_NO = PJT_NO.concat(add_pjt_no);
                            add_pjt_no = "";
                          }
                          //*******************/
                          // 코드규칙 적용 END //
                          //*******************/
                          gridData.PJT_NO = PJT_NO;
            
                          if (ruleList[0].MAX_LEN) {
                            //*******************/
                            // MAX채번 적용 START//
                            //*******************/
                            dews.api.get(dews.url.getApiUrl('PS', 'PSCommonBuilderService', 'PSApiProvider_GET_PJT_MAX_NO'), {
                              async: false,
                              data: {
                                company_cd: gridData.COMPANY_CD,
                                pjt_no: PJT_NO,
                                max_cnt: Number(ruleList[0].MAX_LEN)
                              }
                            }).done(function (mResult) {
                              if (mResult.SUCCESS) {
                                gridData.PJT_NO = mResult.MSG;
                              } else {
                                error_msg = mResult.MSG;
                                return false;
                              }
                            });
                          }
                        }
                      }
                    }).fail(function (xhr, status, error) {
                      dews.ui.snackbar.error(error);
                    });
            
            
                    if (error_msg) return false;
                  });
                  return error_msg;
                },
                AutoProcess: function (dataItem, item) {
                  var resultData = {
                    SUCCESS: false,
                    MSG: ""
                  };
                  switch (item.ATTR_CD) {
                    case "1":
                      // 코드
                      if (item.COL_CD) {
                        if (item.DC_CD) {
                          if (dataItem[item.COL_CD]) {
                            if (item.DC_CD == dataItem[item.COL_CD]) {
                              resultData.SUCCESS = true;
                              resultData.MSG = item.EXTNO_CD;
                            }
                          }
                          else {
                            resultData.SUCCESS = false;
                            resultData.MSG = "프로젝트코드 자동생성이 불가합니다." + "\n"
                              + "[" + item.COL_CD + "]" + item.COL_NM + " 누락되었습니다." + "\n"
                              + "저장하려는 프로젝트정보를 확인하세요.";
                          }
                        }
                        else {
                          resultData.SUCCESS = false;
                          resultData.MSG = "프로젝트코드 자동생성이 불가합니다." + "\n"
                            + "코드(DC_CD) 누락되었습니다." + "\n"
                            + "저장하려는 프로젝트정보를 확인하세요.";
                        }
            
                      } else {
                        resultData.SUCCESS = false;
                        resultData.MSG = "프로젝트코드 자동생성이 불가합니다." + "\n"
                          + "컬럼코드(COL_CD) 누락되었습니다." + "\n"
                          + "코드규칙관리-자동채번규칙을 확인하세요.";
                      }
                      break;
                    case "2":
                      // 문자열
                      resultData.SUCCESS = true;
                      resultData.MSG = item.EXTNO_CD;
                      break;
                    case "3":
                      // 입력값
                      if (item.COL_CD) {
                        if (dataItem[item.COL_CD]) {
                          if (item.FRML_CD) {
                            // 수식(LEFT, RIGHT, MID)
            
                            switch (item.FRML_CD) {
                              case "2":
                                // RIGHT
                                resultData.SUCCESS = true;
                                resultData.MSG = gerp.PS.UTIL.right(dataItem[item.COL_CD], item.LEN_CNT);
                                break;
                              case "3":
                                // MID
                                if (item.START_LEN_CNT) {
                                  resultData.SUCCESS = true;
                                  resultData.MSG = gerp.PS.UTIL.mid(dataItem[item.COL_CD], item.START_LEN_CNT, item.LEN_CNT);
                                } else {
                                  // MID인데 시작자릿수가 없으면 0부터 리턴합니다.
                                  resultData.SUCCESS = true;
                                  resultData.MSG = gerp.PS.UTIL.mid(dataItem[item.COL_CD], 0, item.LEN_CNT);
                                }
                                break;
                              default:
                                // LEFT
                                resultData.SUCCESS = true;
                                resultData.MSG = gerp.PS.UTIL.left(dataItem[item.COL_CD], item.LEN_CNT);
                                break;
                            }
                          } else {
                            resultData.SUCCESS = true;
                            resultData.MSG = dataItem[item.COL_CD];
                          }
                        }
                        else {
                          resultData.SUCCESS = false;
                          resultData.MSG = "프로젝트코드 자동생성이 불가합니다." + "\n"
                            + "[" + item.COL_CD + "]" + item.COL_NM + " 누락되었습니다." + "\n"
                            + "저장하려는 프로젝트정보를 확인하세요.";
                        }
                      } else {
                        resultData.SUCCESS = false;
                        resultData.MSG = "프로젝트코드 자동생성이 불가합니다." + "\n"
                          + "컬럼코드(COL_CD) 누락되었습니다." + "\n"
                          + "코드규칙관리-자동채번규칙을 확인하세요.";
                      }
                      break;
                    case "4":
                      // 자동채번
                      resultData.SUCCESS = true;
                      var auto_set_pjt_no = gerp.PS.UTIL.getSeqNo(item.MODULE_CD, item.CLAS_CD);
                      if (dews.app.drsCode == "10062" && auto_set_pjt_no.length > 5) {
                        // 한국가스기술공사 전용로직.
                        // 자동채번 PJT2021090001 로 채번된경우 다음과같이 변경 -> 21090001
                        resultData.MSG = auto_set_pjt_no.substring(5, auto_set_pjt_no.length);
                      } else {
                        resultData.MSG = auto_set_pjt_no;
                      }
                      break;
                    default:
                      // MAX채번
                      resultData.SUCCESS = true;
                      resultData.MSG = "";
                      break;
                  }
                  return resultData;
                },
            
                /* --------------------------------------------------------------------------------------------
                  *  @desc           회사사용모듈등록 조회
                  *  @ex             PS_UTIL.getModuleInfo(module_cd, use_yn)
                  * --------------------------------------------------------------------------------------------*/
                getModuleInfo: function (module_cd, use_yn) {
                  var IsPS;
                  dews.api.get(dews.url.getApiUrl('PS', 'PSCommonService', 'PSApiProvider_MA_MODULE_INFO_list'), {
                    async: false,
                    data: {
                      module_cd: module_cd,
                      use_yn: use_yn
                    }
                  }).done(function (data) {
                    if (data == undefined || data.length <= 0) {
                      // 회사에서 PS모듈을 사용하지 않는다.
                      // 해당메뉴에서 추가/수정/삭제가 가능합니다.
                      IsPS = 'N';
                    } else {
                      // 회사에서 PS모듈을 사용한다.
                      // 해당메뉴에서 추가/수정/삭제는 불가합니다.
                      IsPS = 'Y';
                    }
                  });
                  return IsPS;
                },
                /* --------------------------------------------------------------------------------------------
                  *  @desc           첨부파일 커스텀 도움창 호출
                  *  @ex             PS_UTIL.FILE_UPLOAD(file_dc)
                  *  @param          file_dc : CM_FILE_INFO 테이블 PK (FILE_DC) 로 INSERT 할 데이터
                  *  @param          uploaduse : 업로드 기능 사용 여부를 설정합니다. (true : 사용  false : 미사용)
                  *  @param          downloaduse : 다운로드 기능 사용 여부를 설정합니다. (true : 사용  false : 미사용)
                  * --------------------------------------------------------------------------------------------*/
                FILE_UPLOAD: function (file_dc, uploaduse, downloaduse) {
                  return new Promise(function (resolve, reject) {
                    var dialog;
                    var initData;
                    initData = {
                      file_dc: file_dc,
                      uploaduse: uploaduse,
                      downloaduse: downloaduse
                    };
                    dialog = dews.ui.dialog("H_PS_FILE_UPLOAD_C",
                      {
                        url: "/codehelp/PS/H_PS_FILE_UPLOAD_C",
                        title: '첨부파일등록',
                        buttons: 'applyAndClose',
                        height: '250px',
                        initData: initData,
                        ok: function (data) {
                          resolve(data); // 적용버튼 클릭시 등록된 파일정보를 리턴합니다.
                        }
                      });
                    dialog.open();
                  });
                },
                /* --------------------------------------------------------------------------------------------
                  * @desc   회사환경설정에 따른 첨부파일 커스텀 도움창 호출
                  *         파라미터들을 하나의 객체로 담아서 넘겨줘야 합니다.
                  * @ex     PS_UTIL.FILE_UPLOAD_STD(parameterInfo)
                  * @param  file_upload_flag: 업로드 기능 사용 여부를 설정합니다. (true : 사용  false : 미사용)
                  * @param  file_download_flag: 다운로드 기능 사용 여부를 설정합니다. (true : 사용  false : 미사용)
                  * @param  file_dc_col_nm: 업데이트되는 테이블의 FILE_DC 컬럼명
                  * @param  func_nm: FILE_DC를 업데이트시킬 api명
                  * @param  func_data: FILE_DC가 업데이트되는 테이블의 기본키
                  * @param  dataObject: 파일 도움창에 바인딩된 (트리)그리드or카드리스트 객체
                  * --------------------------------------------------------------------------------------------*/
                FILE_UPLOAD_STD: function (parameterInfo) {
                  var PS_PS00190 = this.getCmpyEnvControl('PS', 'PS00190');
            
                  if (!parameterInfo.file_dc_col_nm) {
                    dews.alert('도움창 호출 중 오류가 발생하였습니다.', 'warning');
                    console.error('file_dc_col_nm 파라미터 누락');
                    return;
                  }
                  if (!parameterInfo.func_nm) {
                    dews.alert('도움창 호출 중 오류가 발생하였습니다.', 'warning');
                    console.error('func_nm 파라미터 누락');
                    return;
                  }
                  if (!parameterInfo.func_data) {
                    dews.alert('도움창 호출 중 오류가 발생하였습니다.', 'warning');
                    console.error('func_data 파라미터 누락');
                    return;
                  }
                  if (!parameterInfo.dataObject) {
                    dews.alert('도움창 호출 중 오류가 발생하였습니다.', 'warning');
                    console.error('dataObject 파라미터 누락');
                    return;
                  }
            
                  if (parameterInfo.dataObject.dataItems().length == 0) {
                    return;
                  }
            
                  var FILE_DC = null;
                  var cardList;
                  var grid;
                  if (parameterInfo.dataObject._card) {
                    // 카드리스트
                    cardList = parameterInfo.dataObject;
                    FILE_DC = cardList.getValue(cardList.select(), parameterInfo.file_dc_col_nm);
                  } else {
                    // (트리)그리드
                    grid = parameterInfo.dataObject;
                    FILE_DC = grid.getCellValue(grid.select(), parameterInfo.file_dc_col_nm);
                  }
            
                  if (!FILE_DC) {
                    FILE_DC = this.UUID_UPDATE(parameterInfo.func_nm, parameterInfo.func_data);
                    if (!FILE_DC) {
                      dews.alert('도움창 호출 중 오류가 발생하였습니다.', 'warning');
                      console.error('FILE_DC 업데이트 실패');
                      return;
                    }
            
                    if (parameterInfo.dataObject._card) {
                      // 카드리스트
                      cardList.setValue(cardList.select(), parameterInfo.file_dc_col_nm, FILE_DC, false);
                      cardList.clearRowStates();
                    } else {
                      // (트리)그리드
                      grid.setCellValue(grid.select(), parameterInfo.file_dc_col_nm, FILE_DC, false);
                      grid.dataSource.dataProvider.clearRowStates();
                    }
                  }
                  return new Promise(function (resolve, reject) {
                    var dialog;
                    var initData;
                    if (PS_PS00190 == '1') {
                      initData = {
                        file_dc: FILE_DC,
                        uploaduse: parameterInfo.file_upload_flag,
                        downloaduse: parameterInfo.file_download_flag
                      };
                      dialog = dews.ui.dialog('H_PS_FILE_UPLOAD_C',
                        {
                          url: '/codehelp/PS/H_PS_FILE_UPLOAD_C',
                          title: '첨부파일등록',
                          buttons: 'applyAndClose',
                          height: '250px',
                          initData: initData,
                          ok: function (data) {
                            resolve(data); // 적용버튼 클릭시 등록된 파일정보를 리턴합니다.
                          }
                        });
                    } else {
                      initData = {
                        file_dc: FILE_DC
                      };
                      dialog = dews.ui.dialog('H_PS_FILE_UPLOAD_STD_C', {
                        width: 1250,
                        height: 700,
                        url: '/codehelp/PS/H_PS_FILE_UPLOAD_STD_C',
                        title: '파일 업로드',
                        buttons: 'applyAndClose',
                        initData: initData,
                        ok: function (data) {
                          resolve(data);
                        }
                      });
                    }
                    dialog.open();
                  });
                },
                isApproval: function (formId) {
                  var returnGwFormInfo = false;
                  if (!formId) {
                    console.log('전자결재양식등록의 form_id가 누락되었습니다.');
                  } else {
                    dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_get_gw_form_info"), {
                      async: false,
                      data: {
                        form_id: formId,
                      }
                    }).done(function (data) {
                      // debugger;
                      if (data && data.length > 0) {
                        returnGwFormInfo = true;
                      }
                    }).fail(function (xhr, status, error) {
                      // setTimeout(function () {
                      //   dews.alert("전자결재 사용여부 조회 오류!", { icon: "warning" });
                      // }, 200);
                    });
                  }
                  return returnGwFormInfo;
                },
            
                /**
                  * @param {*} company_cd : 회사코드
                  * @param {*} drs_cd : 서버키
                  * @param {*} menu_id : 메뉴id
                  * @param {*} grid : self.grid
                  * @param {*} form_id : 전자결재양식등록의 서식 ID를 넘겨줍니다. 보통은 self.menu.id 이겠지만 한메뉴에서 여러 전자결재가 진행된다면 달라질수 있습니다.
                  * @param {*} athz_rpts_cd : 전자결재키값
                  * @param {*} service_url : 후처리 서비스 URL
                  *                          기본 : "/api/PS/PSAfterService/confirm"
                  *                          예 : "/api/PS/ProjectSystemTrialDriveAfterService/confirm_x10005"
                  * @param {*} contents_url : 본문내용호출URL. 서비스명/함수명조합 PSApprovalContents/contents_PSCPJT00100_COMMON
                  * @param {*} title : 전자결재문서제목. 동서발전에는 해당값이 필수입니다.
                  */
                APPROVAL: function (paramData) {
                  var company_cd = paramData.company_cd || dews.ui.page.user.companyCode;
                  var drs_cd = paramData.drs_cd;
                  var menu_id = paramData.menu_id;
                  var grid = paramData.grid;
                  var form_id = paramData.form_id;
                  var athz_rpts_cd = paramData.athz_rpts_cd;
                  var service_url = paramData.service_url;
                  var contents_url = paramData.contents_url;
                  var module_cd = paramData.module_cd || "PS";
                  var title = paramData.title;
                  var table_nm = paramData.table_nm || "";
                  var matkey_vr = paramData.matkey_vr || "";
            
            
            
                  if (!company_cd) {
                    setTimeout(function () {
                      dews.alert("필수파라미터누락! company_cd", { icon: "warning" });
                    }, 200);
                    return;
                  }
                  if (!menu_id) {
                    setTimeout(function () {
                      dews.alert("필수파라미터누락! menu_id", { icon: "warning" });
                    }, 200);
                    return;
                  }
            
                  if (!grid) {
                    setTimeout(function () {
                      dews.alert("필수파라미터누락! grid", { icon: "warning" });
                    }, 200);
                    return;
                  }
            
                  if (!form_id) {
                    setTimeout(function () {
                      dews.alert("필수파라미터누락! form_id", { icon: "warning" });
                    }, 200);
                    return;
                  }
            
                  if (!athz_rpts_cd) {
                    setTimeout(function () {
                      dews.alert("전자결재키값누락! athz_rpts_cd", { icon: "warning" });
                    }, 200);
                    return;
                  }
            
                  var contents_data = null;
                  var mod = gerp.PS.UTIL.getApprovalState(company_cd, athz_rpts_cd);
            
                  if (!mod) {
                    setTimeout(function () {
                      dews.alert("결재요청 상태체크에 오류가 있습니다! mod", { icon: "warning" });
                    }, 200);
                    return;
                  }
            
            
                  /* (1) 전자결재정보 가져오기 */
                  dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_getGwFormInfo"), {
                    async: false,
                    data: {
                      company_cd: company_cd, 
                      form_id: form_id
                    }
                  }).done(function (form_data) {
                    if (form_data && form_data.length > 0) {
            
                      if(mod == "W") {
                        // 신규생성 해야 할 경우 contents는 필수입니다.
                        // 개발자가 해당메뉴단에서 전달하지 않았다면 전자결재양식등록에 설정된 서비스 URL을 사용하도록 합니다.
                        if (!contents_url && !form_data[0].CTNTS_URL) {
                          setTimeout(function () {
                            dews.alert("본문내용 서비스 URL 누락! contents_url", { icon: "warning" });
                          }, 200);
                          return;
                        } else if(form_data[0].CTNTS_URL) {
                          // 전자결재양식등록의 값이 우선시 됩니다.
                          contents_url = form_data[0].CTNTS_URL;
                        }
                        contents_data = contents_url.replace(/ /gi, "").split("/");
                        if (!contents_data || contents_data.length < 2) {
                          setTimeout(function () {
                            dews.alert("본문내용 서비스 URL 형식오류! " + contents_url, { icon: "warning" });
                          }, 200);
                          return;
                        }
                      }
            
            
                      //////////////////////////////////////////////////////
                      //      DRS코드에 따라서 분기처리됩니다.              //
                      //    업체마다 그룹웨어 주소(URL)이 다르겠죠.         //
                      /////////////////////////////////////////////////////
                      var URL_TYPE = "";
                      switch (drs_cd) {
                        case "10005":
                          URL_TYPE = "x10005"
                          break;
                        default:
                          break;
                      }
                      var url = gerp.PS.UTIL.getApprovalUrl(URL_TYPE);
            
            
            
                      // [2022.08.25-이현태] ERP10의 회사코드와 그룹웨어 회사코드가 다를수 있습니다.
                      // 1) 공통코드에 세팅된 그룹웨어의 회사코드를 가져옵니다.
                      // 2) 해당값이 없다면 로그인한 회사코드를 그대로 사용합니다.
                      gerp.PS.UTIL.getCodeClear(); // [22.11.04-추가-김동은]
                      var groupWareCompList = gerp.PS.UTIL.getCodeData("MA", "N:S00400", null, null, null, null, null);
                      if(groupWareCompList && groupWareCompList.MA && groupWareCompList.MA.S00400 && groupWareCompList.MA.S00400.length > 0) {
                        if(groupWareCompList.MA.S00400[0].FLAG_CD) {
                          company_cd = groupWareCompList.MA.S00400[0].FLAG_CD; //참조 컬럼
                        } else {
                          company_cd = groupWareCompList.MA.S00400[0].SYSDEF_CD; // 관리코드 컬럼
                        }
                      }
            
            
                      if (mod == "W") {
                        //////////////////////////////////////////////////////
                        //      mod == "W" 신규건은 Write페이지를 호출합니다. //
                        //////////////////////////////////////////////////////
            
                        /* (2) 본문내용(contents) 가져오기. */
                        dews.api.post(dews.url.getApiUrl(module_cd, contents_data[0], contents_data[1]), {
                          async: false,
                          data: {
                            list: JSON.stringify(grid.dataItems(grid.select()))
                          }
                        }).done(function (contents) {
            
                          if(form_data[0].SERVICE_URL) {
                            service_url = form_data[0].SERVICE_URL;
                          }
            
                          /* (3) 전자결재 데이터 생성(MA_GWINT_MST) */
                          dews.api.post(dews.url.getApiUrl("PS", "PSCommonService", "approval"), {
                            data: {
                              athz_rpts_cd: athz_rpts_cd,
                              menu_id: menu_id,
                              contents: contents,
                              service_url: !service_url ? "/api/PS/PSAfterService/confirm" : service_url,
                              module_cd: module_cd,
                              table_nm: table_nm,
                              matkey_vr: matkey_vr
                            }
                          }).done(function (approvalData) {
                            if (approvalData && approvalData.SUCCESS) {
                              var aes_key = approvalData.MSG;
                              /* (4) 전자결재페이지 호출 */
                              gerp.PS.UTIL.createEltrAthz(url,
                                {
                                  compCd: company_cd,
                                  approKey: athz_rpts_cd,
                                  outProcessCode: form_data[0].GW_PROC_CD,     //등록한 연동코드
                                  mod: mod,
                                  loginId: aes_key,
                                  title: title,
                                  grid: grid
                                });
                            } else {
                              setTimeout(function () {
                                dews.alert(approvalData.MSG, { icon: approvalData.TYPE_CD });
                              }, 200);
                            }
                          }).fail(function (xhr, status, error) {
                            console.error(error);
                            setTimeout(function () {
                              dews.error('전자결재진행 오류!');
                            }, 200);
                            return;
                          }).always(function () {
                            dews.ui.loading.hide();
                          });
                        }).fail(function (xhr, status, error) {
                          console.error(error);
                          setTimeout(function () {
                            dews.error('contents 조회 오류!');
                          }, 200);
                          return;
                        }).always(function () {
                          dews.ui.loading.hide();
                        });
                      }
            
            
                      else {
                        ///////////////////////////////////////////////////////////
                        //      mod == "V" 이미 진행된건은 View페이지를 호출합니다. //
                        ///////////////////////////////////////////////////////////
                        var loginId = gerp.PS.UTIL.getBizBoxLoginId();
                        gerp.PS.UTIL.createEltrAthz(url,
                          {
                              compCd: company_cd
                            , approKey: athz_rpts_cd
                            , outProcessCode: form_data[0].GW_PROC_CD
                            , mod: mod
                            , loginId: loginId
                            , title: title
                            , grid: grid
                          });
                      }
            
                    }
                    else {
                      dews.ui.snackbar.warning("[전자결재양식등록]에 등록된 내역이 없습니다.");
                    }
                  }).fail(function (xhr, status, error) {
                    // debugger;
                    dews.ui.snackbar.warning(error, false);
                  });
                },
            
                getApprovalUrl: function (gubun) {
                  var returnUrl;
                  dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getApprovalUrl"), {
                    async: false,
                    data: {
                      gubun: gubun,
                    }
                  }).done(function (data) {
                    returnUrl = data;
                  }).fail(function (xhr, status, error) {
                    console.error(error);
                    setTimeout(function () {
                      dews.error('호출 url 조회를 실패하였습니다.');
                    }, 200);
                  });
                  return returnUrl;
                },
                /**
                  * 전자결재의 상태값을 가져와서 mod를 결정해서 리턴합니다.
                  * @param {*} athz_rpts_cd
                  */
                getApprovalState: function (company_cd, athz_rpts_cd) {
                  var mod;
                  dews.api.post(dews.url.getApiUrl("PS", "PSCommonService", "getApprovalInfo"), {
                    async: false,
                    data: {
                      company_cd: company_cd,
                      athz_rpts_cd: athz_rpts_cd
                    }
                  }).done(function (row) {
                    if (!row || !row.GWAPRVLST_CD || $.inArray(row.GWAPRVLST_CD, ["1", "5", "6"]) != -1) {
                      // 전자결재 신규건으로 진행함. mod = "W"
                      mod = "W";
                    } else {
                      // mode = "V"
                      mod = "V";
                    }
                  }).fail(function (xhr, status, error) {
                    // dews.ui.snackbar.warning('전자결재 상태값 조회를 실패하였습니다.', false);
                  });
                  return mod;
                },
                getBizBoxLoginId: function () {
                  var returnId;
                  dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getBizBoxLoginId"), {
                    async: false,
                  }).done(function (data) {
                    returnId = data;
                  }).fail(function (xhr, status, error) {
                    dews.ui.snackbar.warning('로그인 id 조회를 실패하였습니다.', false);
                  });
                  return returnId;
                },
                createEltrAthz: function (url, param) {
                  var callback;
                  var width = 981;
                  var height = 769;
                  if (param.hasOwnProperty("width")) {
                    width = param.width;
                  }
                  if (param.hasOwnProperty("height")) {
                    height = param.height;
                  }
                  if (param.hasOwnProperty("close")) {
                    callback = param.close;
                  }
                  if (param.hasOwnProperty("params")) {
                    param = param.params;
                  }
            
                  var eltrAthzPopup;
                  var $eltrAthzForm = $('<form id="eltrAthzForm" name="eltrAthzForm" enctype="application/json" method="POST">').appendTo("body");
                  if (param.aesKey === null || param.aesKey === undefined) {
                    $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'aesKey', name: 'aesKey' }).val('1023497555960596')); // 1023497555960596: bizBoxA default key
                  } else {
                    $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'aesKey', name: 'aesKey' }).val(param.aesKey));
                  }
                  // [2022.08.25-이현태] 기존에는 사원정보 조직도 매핑후 compSeq에 회사코드를 넘겼습니다.
                  // 하지만 조직도 연동을 못하는업체(이미 i-cube와 연동중임)는 이로직으로 커버가 안됩니다.
                  // 따라서 compSeq -> compCd를 사용하도록합니다.
                  // 이때 compCd는 공통코드에 세팅된 그룹웨어에서 사용중이 회사코드를 사용하며 해당값이 없는경우 로그인한 회사코드를 사용하게됩니다.
                  $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'compCd', name: 'compCd' }).val(param.compCd));
            
                  // [2021.02.18-이현태] form_id는 업체마다 다르게 등록됩니다.
                  // 만약 form_id를 넘기려면 반드시 해당업체의 form_id와 동일하게 넘기고, 안넘기면 알아서 프로세스코드(PS_WF01)로 양식을 찾아갑니다.
                  // $eltrAthzForm.append($('<input>',{type:'hidden',id:'formId',name:'formId'}).val(param.formId));
                  $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'docId', name: 'docId' }).val(param.docId));
            
                  // empSeq -> loginId로 변경. 즉 ERP10의 아이디와 그룹웨어의 아이디가 동일해야합니다.
                  $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'loginId', name: 'loginId' }).val(param.loginId));
            
            
            
                  $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'approKey', name: 'approKey' }).val(param.approKey));
                  $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'outProcessCode', name: 'outProcessCode' }).val(param.outProcessCode));
                  $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'mod', name: 'mod' }).val(param.mod));
                  $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'X-Authenticate-Token', name: 'X-Authenticate-Token' }).val(JSON.parse(dews.ui.page.token).access_token)); // 토큰정보 필수
            
                  if (param.title) {
                    // $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'contentsStr', name: 'contentsStr' }).val(encodeURIComponent(param.title)));
                    // $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'subjectStr', name: 'subjectStr' }).val(encodeURIComponent(param.title)));
                    $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'contentsStr', name: 'contentsStr' }).val(param.title));
                    $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'subjectStr', name: 'subjectStr' }).val(param.title));
                  }
                  if (param.mod == 'W') {//작성
                    $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'contentsEnc', name: 'contentsEnc' }).val(param.contentsEnc));
                    $eltrAthzForm.append($('<input>', { type: 'hidden', id: 'contentsType', name: 'contentsType' }).val(param.contentsType));
                  } else if (param.mod == 'V') {//보기,삭제
                    // $eltrAthzForm.append($('<input>',{type:'hidden',id:'docId',name:'docId'}).val(param.docId));
                  }
                  // if(widthYn){
                  eltrAthzPopup = window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");
                  // }else{
                  //   eltrAthzPopup =  window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                  // }
                  try {
                    eltrAthzPopup.focus();
                  } catch (exception) {
                    alert('그룹웨어 팝업이 차단되어있습니다.');
                  }
            
                  $('#eltrAthzForm').attr("target", "eltrAthzPopup");
                  $('#eltrAthzForm').attr("action", url);
                  $('#eltrAthzForm').submit();
                  $('#eltrAthzForm').remove();
            
                  if (self.$('.dews-ui-loading').length > 0) {
                    dews.ui.loading.hide();
                  }
            
                  setTimeout(function () {
                    dews.ui.loading.show({
                      text: '전자결재 진행 중입니다.'
                    })
                  });
            
            
                  var popupTick = setInterval(function () {
                    if (eltrAthzPopup.closed) {
                      clearInterval(popupTick);
                      dews.ui.loading.hide();
                      param.grid.options.dataSource.read();
                      if (callback && $.isFunction(callback)) {
                        callback();
                      }
                    }
                  }, 500);
                  return eltrAthzPopup;
                },
                /**
                  * 메뉴점프(openmenu)시 현재 로그인한그룹이 해당 메뉴로 어떤 모듈에 등록되어있는가를 조회합니다.
                  * @param {*} 이동할 menuid
                  * @return module_cd(PS, CX....)
                  */
                getGrpMenuModuleCd: function (menuid) {
                  var module_cd = "";
                  dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_GROUP_MENU_MODULE_INFO"), {
                    async: false,
                    data: {
                      menu_cd: menuid
                    }
                  }).done(function (mResultData) {
                    if (mResultData.SUCCESS) {
                      module_cd = mResultData.MSG;
                      console.log(mResultData.PARAMS);
            
                    } else {
                      console.log(mResultData.MSG);
                      // [2021.02.25-이현태] 메뉴진입시 해당 함수를 바로 호출하는 부분이 있어서 주석처리합니다.
                      // mResultData.MSG = "로그인한 그룹으로 해당 메뉴에 대한 접근 권한이 없습니다." + menuid
                      // setTimeout(function () {
                      //   dews.alert(mResultData.MSG, { icon: mResultData.TYPE_CD });
                      // }, 200);
                    }
                  }).fail(function (xhr, status, error) {
                    dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                  });
                  return module_cd;
                },
                 /**
                  * 메뉴 이동시 전용메뉴가 있다면 전용메뉴로, 없다면 패키지 메뉴로 이동하는 함수.
                  * @param {*}  회사코드 company_cd, 메뉴그룹코드 menugrp_cd,이동할 menuid, 메뉴이동시 넘길 데이터 linkData
                  * @return void
                  */
                 linkToMenu: function (company_cd, menugrp_cd, menuid, linkData) {
                  dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_GET_LINK_TO_MENU"), {
                    async: false,
                    data: {
                      menu_cd: menuid,
                      company_cd: company_cd,
                      menugrp_cd : menugrp_cd
                    }
                  }).done(function (data) {
                    dews.ui.openMenu(data[0].MODULE_CD, data[0].MENU_CD, linkData);
                  }).fail(function (xhr, status, error) {
                    dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
                  });
                  return;
                },
            
                /**
                      *   그리드 사이 세로 드래그 기능 함수입니다.
                      *   드래그 css 공통 링크 파일 : /view/css/PS/ps.splitContainerLAND.css
                      *   호출방법
                      *      1)  preReady 아래 선언 :  self.$content.append('<link rel="stylesheet" href=\'/view/css/PS/ps.splitContainerLAND.css\'>');
                      *      2)  데이터 바운드 시점에 함수 호출 : PS_UTIL.splitContainerLAND(self,self.$id);
                      *      3)  탭패널안의 그리드에 적용 시, 데이터 바운드 시점이 아닌 탭 change 이벤트 시점에 함수 호출 : PS_UTIL.splitContainerLAND(self,self.$id);
                      *      4)  containerPanel1 의 클래스는 splitContainer로 설정해준다.
                      *   ///////////////////////////////////////////////////////////////////////////////////////////
                      *   데이터 바운드 시점에 드래그 높이가 제대로 잡힙니다
                      *   클래스 이름 : splitContainer
                      *   splitContainer 아래에 dews-container-item를 찾습니다.
                      *   dews-container-item 안에 dews-position(left,normal,right)를 구분합니다.
                      *   예) <div id="containerPanel1" class="dews-ui-container-panel splitContainer">
                      *        <div class="dews-container-item" data-dews-position='left'>
                      *          <div></div>
                      *        </div>
                      *        <div class="dews-container-item" data-dews-position='normal'>
                      *
                      *    또는
                      *        <div class="dews-container-item" data-dews-position='normal'>
                      *          <div></div>
                      *        </div>
                      *        <div class="dews-container-item" data-dews-position='right'>
                      *   ///////////////////////////////////////////////////////////////////////////////////////////
                      *
                      * @param {*} self
                      * @param {*} $containerPanel
                      */
                splitContainerLAND: function (self, $containerPanel) {
                  var $container = self.$content;
                  var $items = $('#' + self.$content[0].id + ' #' + $containerPanel.attr('id') + ' > .dews-container-item');
                  var $gridItems = [];
                  $.each($items, function (index, item) {
                    $gridItems.push(item.lastElementChild.id);
                  });
                  var minResizeWidth = 20; // 컨테이너 패널 최소 길이
            
                  if ($('#' + self.$content[0].id + ' #' + $containerPanel.attr('id') + ' > .container-item-split-container').length) {
                    $('#' + self.$content[0].id + ' #' + $containerPanel.attr('id') + ' > .container-item-split-container').remove();
                  }
            
                  if ($items) {
                    $items.each(function (index, item) {
                      var itemsLen = $items.length;
            
                      if (index < (itemsLen - 1)) {
                        var $resizeGutter = $('<div class="container-item-split-container vertical"><div class="resize-handle"></div></div>');
                        var $item = $(item);
                        var x = parseInt($item.css('margin-left'), 10) + $item.position().left + $item.outerWidth();
            
                        $containerPanel.append($resizeGutter);
                        $resizeGutter.css({
                          top: 0,
                          left: x,
                          height: $item.outerHeight()
                        });
            
                        var $dbl_item = $items.eq(index);
                        var $dbl_nextItem = $items.eq(index + 1);
            
                        if ($dbl_item.data('dews-position') == 'left' && $dbl_nextItem.data('dews-position') == 'normal') {
                          var dbl_item_NL_width = $dbl_item.width();
                          var x_NL = x;
                        } else if ($dbl_item.data('dews-position') == 'normal' && $dbl_nextItem.data('dews-position') == 'right') {
                          var dbl_nextItem_NR_width = $dbl_nextItem.width();
                          var x_NR = x;
                        }
            
            
            
                        var resizeItems = function (resizeWidth, gutterPositionX) {
            
            
            
                          var $item = $items.eq(index);
                          var $nextItem = $items.eq(index + 1);
            
                          var resizeItem = function () {
                            switch ($item.data('dews-position')) {
                              case 'left':
                                $item.css('width', resizeWidth);
                                break;
                              case 'normal':
                                $item.css('margin-right', $containerPanel.outerWidth() - gutterPositionX + 8);
                                break;
                              case 'right':
                                var gap = gutterPositionX - $nextItem.position().left;
                                $item.css('right', $containerPanel.outerWidth() - gutterPositionX);
                                $item.css('width', parseInt($item.css('width'), 10) + gap);
                                break;
                            }
            
                            switch ($nextItem.data('dews-position')) {
                              case 'left':
                                var gap = gutterPositionX - $nextItem.position().left;
                                $nextItem.css('left', gutterPositionX);
                                $nextItem.css('width', parseInt($nextItem.css('width'), 10) - gap);
                                break;
                              case 'normal':
                                $nextItem.css('margin-left', gutterPositionX + $resizeGutter.outerWidth() + 8);
                                break;
                              case 'right':
                                var gap = gutterPositionX - $nextItem.position().left;
                                $nextItem.css('width', parseInt($nextItem.css('width'), 10) - gap);
                                break;
                            }
                          }
            
                          if ($resizeGutter.next().hasClass('container-item-split-container')) {
                            if (gutterPositionX + minResizeWidth < parseInt($resizeGutter.next().css('left'), 10)) {
                              $resizeGutter.css('left', gutterPositionX + $resizeGutter.outerWidth());
                              resizeItem();
                            }
                          } else {
            
                            if ($('#' + self.$content[0].id + ' #' + $containerPanel.attr('id') + ' > .dews-container-item').length == 2 && $item.data('dews-position') == 'normal' && $nextItem.data('dews-position') == 'right') {
                              if (gutterPositionX - minResizeWidth > parseInt($resizeGutter.prev().prev().css('left'), 10)) {
                                $resizeGutter.css('left', gutterPositionX + $resizeGutter.outerWidth() - 15);
                              }
                              resizeItem();
                            } else {
                              if (gutterPositionX - minResizeWidth > parseInt($resizeGutter.prev().css('left'), 10)) {
                                if ($container.width() - $containerPanel.offset().left - minResizeWidth > gutterPositionX) {
                                  if ($('#' + self.$content[0].id + ' #' + $containerPanel.attr('id') + ' > .dews-container-item').length == 3) {
                                    $resizeGutter.css('left', gutterPositionX + $resizeGutter.outerWidth() - 15);
                                  } else {
                                    $resizeGutter.css('left', gutterPositionX + $resizeGutter.outerWidth());
                                  }
                                  resizeItem();
                                }
                              }
                            }
            
                          }
                        };
            
                        $resizeGutter.on('mousedown', function (e) {
                          e.preventDefault();
                          var distance = e.pageX - $resizeGutter.offset().left;
                          $resizeGutter.data({ draggable: true, distance: distance });
            
                        }).on('mouseup', function (e) {
                          e.preventDefault();
                          $resizeGutter.data('draggable', false);
                          $resizeGutter.removeData('distance');
                        }).on('click', function (e) {
                          e.stopPropagation();
                        }).on('dblclick', function (e) {
            
            
                          if ($dbl_item.data('dews-position') == 'left' && $dbl_nextItem.data('dews-position') == 'normal') {
                            NL_reset($dbl_item, $dbl_nextItem, $resizeGutter);
            
                          } else if ($dbl_item.data('dews-position') == 'normal' && $dbl_nextItem.data('dews-position') == 'right') {
                            NR_reset($dbl_item, $dbl_nextItem, $resizeGutter);
                          }
            
                        });
            
                        $containerPanel.on('mousemove', function (e, x) {
                          if ($resizeGutter.data('draggable') === true) {
                            var itemOffsetX = $item.offset().left;
                            var gutterWidth = $resizeGutter.outerWidth();
                            var distance = parseInt($resizeGutter.data('distance'));
                            var pageX = e.pageX ? e.pageX : x;
            
                            var resizeWidth = pageX - itemOffsetX + (gutterWidth - distance);
                            var gutterPositionX = pageX - $containerPanel.offset().left - distance;
            
                            if (resizeWidth >= minResizeWidth) {
                              resizeItems(resizeWidth, gutterPositionX);
                            } else {
                              if (resizeWidth < minResizeWidth) {
                                resizeWidth = minResizeWidth;
                                gutterPositionX = parseInt($(item).css('margin-left'), 10) + $(item).position().left + minResizeWidth;
                              }
                              resizeItems(resizeWidth, gutterPositionX);
                            }
                          }
                        })
            
                        var NL_reset = function ($dbl_item, $dbl_nextItem, $resizeGutter) {
                          $dbl_item.css('width', dbl_item_NL_width);
                          $resizeGutter.css({ left: x_NL });
                          $dbl_nextItem.css("margin-left", dbl_item_NL_width + $resizeGutter.outerWidth());
                        }
                        var NR_reset = function ($dbl_item, $dbl_nextItem, $resizeGutter) {
                          $dbl_nextItem.css('width', dbl_nextItem_NR_width);
                          $resizeGutter.css({ left: x_NR });
                          $dbl_item.css("margin-right", dbl_nextItem_NR_width + $resizeGutter.outerWidth());
                        }
                        var removeDragAction = function () {
                          if ($resizeGutter.data('draggable') === true) {
                            $resizeGutter.data('draggable', false);
                            $resizeGutter.removeData('distance');
                            setTimeout(function () {
                              $.each($gridItems, function (index, item) {
                                $('#' + item).css('display', 'none');
                                $('#' + item).css('display', '');
                              });
                            }, 400);
                          }
                        };
                        $container.on('mouseup click', removeDragAction.bind(this));
                      }
                    });
                  }
            
            
            
                },
                /**
                  * 그리드 사이 가로 드래그 기능 함수입니다.
                  * 드래그 css 공통 링크 파일 : /view/css/PS/ps.splitContainerPORT.css
                  *   호출방법
                  *      1)  html태그 설정
                              <div id="MainContainer" class="dews-ui-container-panel splitContainer">
                              메인컨테이너 id(MainContainer)를 설정하고 css클래스(splitContainer)를 추가해줍니다
                  *      2)  preReady 아래 css링크 추가 :
                              self.$content.append('<link rel="stylesheet" href=\'/view/css/PS/ps.splitContainerPORT.css\'>');
                  *      3)  함수의 3번째 매개 변수로 배열을 넘겨줘야합니다.(배열 순서 중요!!)
                            예시)
                            그리드 2개일 경우
                              var gridArray = [];
                              gridArray.push(self.grid_ORD); //1번 그리드
                              gridArray.push(self.grid_QUT); //2번 그리드
            
                            그리드 3개일 경우
                              var gridArray = [];
                              gridArray.push(self.grid_ORD); //1번 그리드
                              gridArray.push(self.grid_QUT); //2번 그리드
                              gridArray.push(self.grid_DTL); //3번 그리드
                *      4)  ready 아래에 함수 호출 : PS_UTIL.splitContainerPORT(self,self.$MainContainer,gridArray);
            
            
                      추가) fit-bottom을 넣으면 올바로 작동하지 않습니다.
            
                *      ///////////////////////////////////////////////////////////////////////////////////////////
                *      그리드가 3개일 경우 메인컨테이너 아래에(MainContainer) 2개의 그리드를 감싸는 1개의 컨테이너가 필요합니다
                *          => 그리드가 2개일 경우 하위 컨테이너 생성 필요 없음
                *          => 그리드가 3개일 경우 2개의 하위 컨테이너 생성
                *      데이터 바운드 시점에 드래그 너비가 제대로 잡힙니다.
                *      클래스 이름 : splitContainer
                      예) 그리드가 2개일 경우 (참조 : 계획대비실적조회 PSCBGT09200)
                      <div id="MainContainer" class="dews-ui-container-panel splitContainer" >
                        <div class="dews-container-item" data-dews-position="normal">
                            <h4>abc</h4>
                            <div id="grid_ORD" class="dews-ui-grid "></div>               =>  1번 그리드
                            <div class="dews-button-group" style="text-align: right;">
                              <button>abc</button>
                            </div>
                            <div id="grid_QUT" class="dews-ui-grid "></div>               =>  2번 그리드
                        </div>
            
                      </div>
            
                      예) 그리드가 3개일 경우 (참조 : 외주견적서등록 PSDOUT00400)
                            <div id="MainContainer" class="dews-ui-container-panel splitContainer" >
            
                              <div class="dews-ui-container-panel">                             => 1번 컨테이너
                                <div class="dews-container-item" data-dews-position="normal">
                                  <h4>abc</h4>
                                  <div id="grid_ORD" class="dews-ui-grid "></div>               =>  1번 그리드
                                  <div class="dews-button-group" style="text-align: right;">
                                    <button>abc</button>
                                  </div>
                                  <div id="grid_QUT" class="dews-ui-grid "></div>               =>  2번 그리드
                                </div>
                              </div>
            
                              <div class="dews-ui-container-panel">                             => 2번 컨테이너
                                <div class="dews-container-item" data-dews-position="normal">
                                  <div id="grid_DTL" class="dews-ui-grid "></div>               =>  3번 그리드
                                </div>
                              </div>
            
                          </div>
            
                *      ///////////////////////////////////////////////////////////////////////////////////////////
                *
                * @param {*} self
                * @param {*} $MainContainer
                * @param {*} gridArray[]
                */
                splitContainerPORT: function (self, $MainContainer, gridArray) {
                  var gridName = new Map();
            
                  // 초기 로드 시 발생하는 스크롤바 overflow hidden 처리 로직 추가 [210125-수정-김동은]
                  $MainContainer.children().css({ 'overflow': 'hidden' });
            
                  for (var i = 0; i < gridArray.length; i++) {
                    gridName.set(i + "grid", gridArray[i]);
                  }
                  var dragBar_distance = 30;
                  var HashMap = new Map();
                  var pageY = null;
                  var $containerPanel = null;
            
                  if (gridArray.length == 2) {
                    $containerPanel = $('#' + self.$content[0].id + ' #' + $MainContainer.attr('id'));
                  } else if (gridArray.length > 2) {
                    $containerPanel = $('#' + self.$content[0].id + ' #' + $MainContainer.attr('id') + ' > .dews-container-item  > .dews-ui-container-panel');
                  }
            
                  if ($containerPanel.length * 2 == gridArray.length || $containerPanel.length * 2 - 1 == gridArray.length) {
                    $containerPanel.each(function (index, items) {
            
                      var firstGrid = gridName.get(2 * index + "grid");
                      if (gridName.get(2 * index + 1 + "grid") != undefined) {
                        var secondGrid = gridName.get(2 * index + 1 + "grid");
                      }
            
            
                      var firstContainerItemGrid = firstGrid.$element[0];
                      if (gridName.get(2 * index + 1 + "grid") != undefined) {
                        var secondContainerItemGrid = secondGrid.$element[0];
                      }
            
                      var $firstContainerItemGrid = $(firstContainerItemGrid);
                      if (gridName.get(2 * index + 1 + "grid") != undefined) {
                        var $secondContainerItemGrid = $(secondContainerItemGrid);
                      }
            
                      $firstContainerItemGrid.after('<div class="container-item-split-container horizontal"><div class="resize-handle"></div></div>');
                      if (secondContainerItemGrid != undefined) {
                        $secondContainerItemGrid.after('<div class="container-item-split-container horizontal"><div class="resize-handle"></div></div>');
                      }
            
                      var $firstResizeGutter = $($firstContainerItemGrid.next());
                      if (secondContainerItemGrid != undefined) {
                        var $secondResizeGutter = $($secondContainerItemGrid.next());
                      }
            
                      //바의 길이는 상단그리드의 outerWidth값과 같도록 설정...
                      // 100%로 화면 확대 축소 시 유동적으로 변동될 수 있도록 설정..[210122-수정-김동은]
                      $firstResizeGutter.css({
                        // width: $secondContainerItemGrid.outerWidth(),
                        "width": "100%"
            
                      });
                      if (secondContainerItemGrid != undefined) {
                        $secondResizeGutter.css({
                          // width: $secondContainerItemGrid.outerWidth(),
                          "width": "100%"
                        });
                      }
            
            
                      // 마지막 드래그바 안보이게하기
                      if (index == Math.floor((gridName.size - 1) / 2)) {
                        if (gridName.size % 2 == 0) {
                          $secondResizeGutter.css('visibility', 'hidden');
                        } else if (gridName.size % 2 == 1) {
                          $firstResizeGutter.css('visibility', 'hidden');
                        }
                      }
            
                      //드래그바와 그리드 인덱스별로 이름 설정
                      HashMap.set(2 * index + "firstResizeGutter", $firstResizeGutter);
                      if (secondContainerItemGrid != undefined) {
                        HashMap.set(2 * index + 1 + "secondResizeGutter", $secondResizeGutter);
                      }
            
                      HashMap.set(2 * index + "firstContainerItemGrid", $firstContainerItemGrid);
                      if (secondContainerItemGrid != undefined) {
                        HashMap.set(2 * index + 1 + "secondContainerItemGrid", $secondContainerItemGrid);
                      }
                    });//첫번째 each 끝
            
                    $containerPanel.each(function (index, items) {
                      var secondContainerItemGrid = gridName.get(2 * index + 1 + "grid");
            
                      if (secondContainerItemGrid != undefined) {
                        HashMap.get(2 * index + 1 + "secondContainerItemGrid").data({ second_prev_ContainerItemGrid: HashMap.get((2 * index + 1) - 1 + "firstContainerItemGrid") });
                        HashMap.get(2 * index + 1 + "secondContainerItemGrid").data({ second_ContainerItemGrid: HashMap.get((2 * index + 1) + "secondContainerItemGrid") });
                      }
            
                      //드래그바 가로길이 때문에 추가
                      if (secondContainerItemGrid != undefined) {
                        HashMap.get(2 * index + "firstResizeGutter").data({ first_next_ResizeGutter: HashMap.get(2 * index + 1 + "secondResizeGutter") });
                        HashMap.get(2 * index + "firstContainerItemGrid").data({ first_next_ContainerItemGrid: HashMap.get(2 * index + 1 + "secondContainerItemGrid") });
                        HashMap.get(2 * index + 1 + "secondResizeGutter").data({ second_prev_ResizeGutter: HashMap.get((2 * index + 1) - 1 + "firstResizeGutter") });
                      }
            
            
                      if (secondContainerItemGrid != undefined) {
                        HashMap.get(2 * index + "firstResizeGutter").data({ init_first_next_ResizeGutterHeight: HashMap.get(2 * index + 1 + "secondResizeGutter").offset().top });
                        HashMap.get(2 * index + 1 + "secondResizeGutter").data({ init_second_ResizeGutterHeight: HashMap.get((2 * index + 1) + "secondResizeGutter").offset().top });
                        if (HashMap.get((2 * index + 1) + 1 + "firstContainerItemGrid") != undefined) {
                          HashMap.get(2 * index + 1 + "secondResizeGutter").data({ init_second_frontSecond_prev_ResizeGutterHeight: HashMap.get((2 * index + 1) + 1 + "firstResizeGutter").offset().top });
                        }
                      }
            
            
                      if (secondContainerItemGrid != undefined) {
                        HashMap.get(2 * index + "firstResizeGutter").data({ first_next_ResizeGutterHeight: HashMap.get(2 * index + 1 + "secondResizeGutter").offset().top });
                        HashMap.get(2 * index + 1 + "secondResizeGutter").data({ second_prev_ResizeGutterHeight: HashMap.get((2 * index + 1) - 1 + "firstResizeGutter").offset().top });
                      }
                    });
            
                    $containerPanel.each(function (index, items) {
                      var secondContainerItemGrid = gridName.get(2 * index + 1 + "grid");
            
                      // pageYY = MainContainer내부의 height의 현재 위치
                      var resizeItems = function (pageY, eitherResizeGutter, eitherContainerItemGrid, pageYY) {
            
                        var resizeItem = function () {
                          if (eitherResizeGutter == HashMap.get(2 * index + "firstResizeGutter")) {
            
                            if (gridArray.length == 2) {
            
                              if (pageY < parseInt(eitherResizeGutter.data('init_first_next_ResizeGutterHeight'))) {
                                // 위아래로 bar 이동 시 각 그리드의 설정값 유동적으로 변경된다. [수정-210122-김동은]
                                var StringHeight = $MainContainer.height() - pageYY - 40;
                                gridName.get(0 + "grid").setHeight(pageYY);
                                gridName.get(1 + "grid").setHeight("100%");
                                $("#" + gridName.get("1grid").$element[0].offsetParent.id).css({ 'height': StringHeight + 'px' });
                              }
                            }
            
                            if (gridArray.length == 3) {
                              if (pageY < parseInt(eitherResizeGutter.data('init_first_next_ResizeGutterHeight'))) {
                                if (pageY >= parseInt(eitherResizeGutter.data('first_next_ResizeGutterHeight'))) {
                                  gridName.get(0 + "grid").setHeight(pageY - parseInt(eitherContainerItemGrid.offset().top));
                                  gridName.get(1 + "grid").setHeight(dragBar_distance);
                                } else if (pageY < parseInt(eitherResizeGutter.data('first_next_ResizeGutterHeight'))) {
                                  gridName.get(0 + "grid").setHeight(pageY - parseInt(eitherContainerItemGrid.offset().top));
                                  gridName.get(1 + "grid").setHeight(parseInt(eitherResizeGutter.data('first_next_ResizeGutterHeight')) - 40 - pageY);
                                }
            
                                eitherResizeGutter.css({
                                  width: eitherContainerItemGrid.outerWidth()
                                });
                                eitherResizeGutter.data('first_next_ResizeGutter').css({
                                  width: eitherContainerItemGrid.data('first_next_ContainerItemGrid').outerWidth()
                                });
            
                              }
                            }
            
                          } else if (eitherResizeGutter == HashMap.get(2 * index + 1 + "secondResizeGutter")) {
                            if (gridArray.length == 3) {
                              if (pageY < parseInt(eitherResizeGutter.data('second_prev_ResizeGutterHeight'))) {
                                gridName.get(0 + "grid").setHeight(pageY - parseInt(eitherContainerItemGrid.data('second_prev_ContainerItemGrid').offset().top));
                                gridName.get(1 + "grid").setHeight(dragBar_distance);
                                gridName.get(2 + "grid").setHeight(parseInt(eitherResizeGutter.data('init_second_frontSecond_prev_ResizeGutterHeight')) - pageY);
                              } else {
                                if (pageY < parseInt(eitherResizeGutter.data('init_second_ResizeGutterHeight'))) {
                                  gridName.get(1 + "grid").setHeight(pageY - parseInt(eitherContainerItemGrid.data('second_ContainerItemGrid').offset().top));
                                  gridName.get(2 + "grid").setHeight(parseInt(eitherResizeGutter.data('init_second_frontSecond_prev_ResizeGutterHeight')) - pageY);
                                }
                              }
                              eitherResizeGutter.css({
                                width: eitherContainerItemGrid.outerWidth()
                              });
                              eitherResizeGutter.data('second_prev_ResizeGutter').css({
                                width: eitherContainerItemGrid.data('second_prev_ContainerItemGrid').outerWidth()
                              });
            
                            }
                          }
                        }
                        resizeItem();
                      }
            
                      HashMap.get(2 * index + "firstResizeGutter").on('mousedown', function (e) {
                        e.preventDefault();
                        HashMap.get(2 * index + "firstResizeGutter").data({ draggable: true });
                      }).on('mouseup', function (e) {
                        e.preventDefault();
                        HashMap.get(2 * index + "firstResizeGutter").data({ draggable: false });
                      }).on('click', function (e) {
                        e.stopPropagation();
                      });
            
                      if (secondContainerItemGrid != undefined) {
                        HashMap.get(2 * index + 1 + "secondResizeGutter").on('mousedown', function (e) {
                          e.preventDefault();
                          HashMap.get(2 * index + 1 + "secondResizeGutter").data({ draggable: true });
                        }).on('mouseup', function (e) {
                          e.preventDefault();
                          HashMap.get(2 * index + 1 + "secondResizeGutter").data({ draggable: false });
                        }).on('click', function (e) {
                          e.stopPropagation();
                        });
                      }
            
                      $MainContainer.on('mousemove', function (e) {
                        // [수정-210122-김동은]
                        pageY = e.pageY;
                        pageYY = e.pageY - 192;
            
                        if (HashMap.get(2 * index + "firstResizeGutter").data('draggable') == true) {
                          resizeItems(pageY, HashMap.get(2 * index + "firstResizeGutter"), HashMap.get(2 * index + "firstContainerItemGrid"), pageYY);
                        }
                        if (secondContainerItemGrid != undefined) {
                          if (HashMap.get(2 * index + 1 + "secondResizeGutter").data('draggable') == true) {
            
                            resizeItems(pageY, HashMap.get(2 * index + 1 + "secondResizeGutter"), HashMap.get(2 * index + 1 + "secondContainerItemGrid"));
                          }
                        }
                      }).on('mouseup', function (e) {
                        e.preventDefault();
            
            
                        if (secondContainerItemGrid != undefined) {
                          HashMap.get(2 * index + "firstResizeGutter").data({ first_next_ResizeGutterHeight: HashMap.get(2 * index + 1 + "secondResizeGutter").offset().top });//0번일때 1번드래그값 ||  2번일때 3번드래그값 || 4번일때 5번 드래그값
                          HashMap.get(2 * index + 1 + "secondResizeGutter").data({ second_prev_ResizeGutterHeight: HashMap.get((2 * index + 1) - 1 + "firstResizeGutter").offset().top });//1번일때 0번드래그값 || 3번일때 2번드래그값 || 5번일때 4번 드래그값
                        }
            
                        if (HashMap.get(2 * index + "firstResizeGutter").data('draggable') == true) {
                          HashMap.get(2 * index + "firstResizeGutter").data('draggable', false);
                        }
            
                      });
            
                      var removeDragAction = function () {
                        if (HashMap.get(2 * index + "firstResizeGutter").data('draggable') == true) {
                          HashMap.get(2 * index + "firstResizeGutter").data('draggable', false);
                        }
                        if (secondContainerItemGrid != undefined) {
                          if (HashMap.get(2 * index + 1 + "secondResizeGutter").data('draggable') === true) {
                            HashMap.get(2 * index + 1 + "secondResizeGutter").data('draggable', false);
                          }
                        }
                      };
                      $MainContainer.on('mouseup click', removeDragAction.bind(this));
            
                    });
            
                  }
                },
                /*
                  none_gwaprvlst_cd : ["2","4"] 제외할 상태값을 배열로 넣어준다.
                  */
                approvalStatusChecking: function (company_cd, athz_rpts_cd, gwaprvlst_cd, none_gwaprvlst_cd) {
                  var msg = null;
                  var resultData = null;
            
                  if (msg = this.approvalStatusCheckingMessage(gwaprvlst_cd, none_gwaprvlst_cd)) return msg;
            
                  dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_ApprovalStatusChecking"), {
                    async: false,
                    data: {
                      company_cd: company_cd,
                      athz_rpts_cd: athz_rpts_cd
                    }
                  }).done(function (data) {
                    if (data && data.length > 0) {
                      resultData = data;
                    }
                  }).fail(function (xhr, status, error) {
                    console.error(error);
                    setTimeout(function () {
                      dews.error('오류가 발생하였습니다.');
                    }, 200);
                    msg = error;
                  });
            
                  if (resultData && resultData.length > 0) {
                    msg = this.approvalStatusCheckingMessage(resultData[0].GWAPRVLST_CD, none_gwaprvlst_cd);
                  }
            
                  return msg;
                },
                approvalStatusCheckingMessage: function (gwaprvlst_cd, none_gwaprvlst_cd) {
                  var msg = null;
                  var none_check_state = null;
                  if (none_gwaprvlst_cd && none_gwaprvlst_cd.length > 0) {
                    none_check_state = none_gwaprvlst_cd.filter(function (row) { return row == gwaprvlst_cd });
                  }
                  if (!none_check_state || none_check_state.length == 0) {
                    if (gwaprvlst_cd) {
                      if (gwaprvlst_cd == "2") {
                        msg = "[상신]건은 처리가 불가합니다.";
                      } else if (gwaprvlst_cd == "3") {
                        msg = "[진행]건은 처리가 불가합니다.";
                      } else if (gwaprvlst_cd == "4") {
                        msg = "[종결]건은 처리가 불가합니다.";
                      } else if (gwaprvlst_cd == "7") {
                        msg = "[보류]건은 처리가 불가합니다.";
                      } else if (gwaprvlst_cd == "9") {
                        msg = "[보관]건은 처리가 불가합니다.";
                      }
                    }
                  }
                  return msg;
                },
                /**
                  * @desc 엑셀업로드시 업로드된 프로젝트코드(또는 WBS_NO....)가 존재하는지 체크합니다.
                  * @param {*} type: 체크할 타입
                  *                : "PJT_NO"
                  * *              : "WBS_NO"
                  *                ...
                  * @param {*} pkValues: ['회사코드', '프로젝트코드'] 체크할 PK값들을 전달합니다.
                *                     : ['회사코드', '프로젝트코드', 'WBS코드'] 체크할 PK값들을 전달합니다.
                  */
                codeValueExistCheck: function (type, pkValues) {
                  var flag = true;
            
                  if (!type || (!pkValues || pkValues.length == 0)) {
                    return false;
                  }
            
                  dews.api.post(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_CodeValue_Exist_Check"), {
                    async: false,
                    data: {
                      type: type,
                      pkValues: JSON.stringify(pkValues)
                    }
                  }).done(function (data) {
                    if (!data.SUCCESS) {
                      flag = false;
                    }
                  }).fail(function (xhr, status, error) {
                    console.error(error);
                    setTimeout(function () {
                      dews.error('오류가 발생하였습니다.');
                    }, 200);
                    flag = false;
                  });
            
                  return flag;
                },
                /**
                  * @desc 엑셀업로드시 업로드된 프로젝트코드(또는 WBS_NO....)를 통하여 프로젝트명을 조회합니다.
                  *       프로젝트가 존재하지 않으면 프로젝트명이 비어있습니다.
                  * @param {*} type: 체크할 타입
                  *                : "PJT_NO"
                  * *              : "WBS_NO"
                  *                ...
                  * @param {*} pkValues: List<스플릿String> ['프로젝트코드1', '프로젝트코드2'] 체크할 PK값들을 전달합니다.
                  *                     : ['프로젝트코드1|WBS코드1', '프로젝트코드2|WBS코드2'] 체크할 PK값들을 전달합니다.
                  */
                excelCD_NM_LIST: function (type, pkValues) {
                  var returnValue = null;
            
                  if (!type || (!pkValues || pkValues.length == 0)) {
                    return false;
                  }
            
                  dews.api.post(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_CD_NM_LIST"), {
                    async: false,
                    data: {
                      type: type,
                      pkValues: JSON.stringify(pkValues)
                    }
                  }).done(function (list) {
                    // list.get(0).SYSDEF_CD - 프로젝트코드 or WBS코드
                    // list.get(0).SYSDEF_NM - 프로젝트명 or WBS명
                    returnValue = list;
                  }).fail(function (xhr, status, error) {
                    console.error(error);
                    setTimeout(function () {
                      dews.error('오류가 발생하였습니다.');
                    }, 200);
                  });
            
                  return returnValue;
                },
                /**
                  * @desc 프로젝트코드의 사용자별 세부권한 등록여부를 리턴합니다.
                  */
                getPjtAuthInfo: function (pjt_no) {
                  var returnValue = false;
            
                  if ((pjt_no && pjt_no.length > 0)) {
                    dews.api.post(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_getPjtAuthInfo"), {
                      async: false,
                      data: {
                        pjt_no: pjt_no
                      }
                    }).done(function (mResult) {
                      returnValue = mResult.SUCCESS;
                    }).fail(function (xhr, status, error) {
                      console.error(error);
                      setTimeout(function () {
                        dews.error('오류가 발생하였습니다.');
                      }, 200);
                    });
                  }
                  return returnValue;
                },
                /*********************************************************************************************
                  *  @desc   사용자별세부권한 리스트 조회
                  *  @param  {String} table_nm     [필수] 테이블명
                  *  @ex     PS_UTIL.getAuthList('PS_PROJ_MST');
                  * ------------------------------------------------------------------------------------------*/
                getAuthList: function (table_nm) {
                  var authList = null;
            
                  dews.api.get(dews.url.getApiUrl("PS", "PSCommonService", "PSApiProvider_Get_auth_list"), {
                    async: false,
                    data: {
                      table_nm: table_nm
                    }
                  }).done(function (data) {
                    authList = data;
                  }).fail(function (xhr, status, error) {
                    setTimeout(function () {
                      dews.error('오류가 발생했습니다.');
                    }, 0)
                    console.error(error || "PS_UTIL - getAuthList: 사용자별세부권한 리스트 조회에 실패했습니다.");
                  });
            
                  if (authList == 'DETAIL_AUTH_NOT_USED') {
                    authList = null;
                  } else if (!authList) {
                    authList = this.getUUID();
                  }
            
                  return authList;
                },
                /*********************************************************************************************
                  *  @desc   첨부파일키(FILE_DC), 전자결재키(ATHZ_DOC_CD)를 업데이트합니다.
                  *  @param  {String} func_nm     [필수] 서비스함수명
                  *  @param  {Object} func_data   [필수] 파라미터   {
                  *                                                 company_cd : self.user.companycd,
                  *                                                 pjt_no : self.grid.getCellValue(self.grid.select(), "PJT_NO")
                  *                                                }
                  *  @ex     PS_UTIL.UUID_UPDATE('PS_PJTPRGR_DTL_FILE_DC_UPDATE', {
                  *                                                                   company_cd : self.user.company_cd,
                  *                                                                   pjt_no : self.grid.getCellValue(self.grid.select(), "PJT_NO")
                  *                                                               });
                  * ------------------------------------------------------------------------------------------*/
                UUID_UPDATE: function (func_nm, func_data) {
                  var UUID = null;
                  if (!func_nm) {
                    console.log('func_nm이 누락되었습니다. "예:PS_PJTPRGR_DTL_FILE_DC_UPDATE"');
                  } else if (!func_data) {
                    console.log('func_data가 누락되었습니다. "예:{company_cd : self.user.company_cd, pjt_no : self.grid.getCellValue(self.grid.select(), "PJT_NO")}"');
                  } else {
                    dews.api.post(dews.url.getApiUrl("PS", "PSCommonUUID_Service", func_nm), {
                      async: false,
                      data: func_data
                    }).done(function (resultData) {
                      if (resultData.SUCCESS) {
                        UUID = resultData.MSG;
                      } else {
                        setTimeout(function () {
                          dews.alert(resultData.MSG, { icon: 'warning' });
                        }, 200);
                      }
                    }).fail(function (xhr, status, error) {
                      setTimeout(function () {
                        dews.error('오류가 발생하였습니다.');
                      }, 200);
                      console.error(error);
                    });
                  }
                  return UUID;
                },
                /*********************************************************************************************
                *  @desc   그리드에서 입력된 데이터를 선택된 범위에 복사합니다.
                *          또는 Ctrl+V로 입력된 데이터를 선택된 범위에 복사합니다.
                *  @param  e : save이벤트 or pasted이벤트
                *          saveEventHandler : save이벤트 동작여부
                *  @return true or false
                *  @ex     PS_UTIL.CopyCellData(e, saveEventHandler));
                * ------------------------------------------------------------------------------------------*/
                CopyCellData: function (e, saveEventHandler) {
                  var modifyValue = null;
                  if (e.type == "save") {
                    $.each(e.grid.multiSelect().columns, function (c_idx, c_data) {
                      $.each(e.grid.multiSelect().rows, function (r_idx, r_data) {
                        if (gerp.PS.UTIL.getGridColEdit(e.grid, c_data, r_data)) {
                          if (e.grid.options.columns) {
                            if (!modifyValue) {
                              modifyValue = e.grid.getCellValue(r_data, c_data); // 붙여넣기시 붙여넣는 첫번째컬럼의 첫번째행에만 값이 세팅되므로 해당값을 별도로 저장합니다.
                            }
                            if (saveEventHandler) {
                              e.grid.setCellValue(r_data, c_data, "-99901236", false);
                            }
                            e.grid.setCellValue(r_data, c_data, modifyValue, saveEventHandler, true);
                          }
                        }
                      });
                    });
                  } else if (e.type == "pasted") {
            
                    $.each(e.grid.multiSelect().columns, function (c_idx, c_data) {
                      $.each(e.grid.multiSelect().rows, function (r_idx, r_data) {
                        if (gerp.PS.UTIL.getGridColEdit(e.grid, c_data, r_data)) {
                          if(e.grid.clipboard.copyData.length == 1) {
                            if (!modifyValue && modifyValue != 0) {
                              modifyValue = e.grid.getCellValue(r_data, c_data); // 붙여넣기시 붙여넣는 첫번째컬럼의 첫번째행에만 값이 세팅되므로 해당값을 별도로 저장합니다.
                            }
                          } else {
                            modifyValue = e.grid.getCellValue(r_data, c_data); // 복수 값 복사하여 붙여넣기
                          }
                          // 기존 코드
                          // if (!modifyValue) {
                          //   modifyValue = e.grid.getCellValue(r_data, c_data); // 붙여넣기시 붙여넣는 첫번째컬럼의 첫번째행에만 값이 세팅되므로 해당값을 별도로 저장합니다.
                          // }
                          if (saveEventHandler) {
                            e.grid.setCellValue(r_data, c_data, "-99901236", false);
                          }
                          e.grid.setCellValue(r_data, c_data, modifyValue, saveEventHandler, true);
                        }
                      });
                    });
                  }
                },
                /*********************************************************************************************
                  *  @desc   그리드의 컬럼 수정가능여부 리턴 (체크가능한 헤더행의 최대갯수는 3개입니다!!!!!!!!!)
                  *  @param  grid : self.grid   그리드
                  *  @param  col_cd : "PJT_NO" 수정가능여부를 체크하고싶은 컬럼코드
                  *  @return true or false
                  *  @ex     PS_UTIL.getGridColEdit(self.grid, 1, "PJT_NO");
                  * ------------------------------------------------------------------------------------------*/
                getGridColEdit: function (grid, col_cd, col_idx) {
                  var editable = false;
                  var return_flag = false;
                  let colData = { grid: grid, row: { data: grid.sortDataItems().find(function (_item, _idx) { return _idx === col_idx; }), index: col_idx }};
                  $.each(grid.options.columns, function (e_idx, e_data) {
                    if (grid.options.columns[e_idx].columns) {
                      $.each(grid.options.columns[e_idx].columns, function (e2_idx, e2_data) {
                        if (grid.options.columns[e_idx].columns[e2_idx].columns) {
                          $.each(grid.options.columns[e_idx].columns[e2_idx].columns, function (e3_idx, e3_data) {
                            if (e3_data.field == col_cd) {
                              editable = (typeof e3_data.editor.editable === 'function' ? !e3_data.editor.editable(colData) : !e3_data.editor.editable || !e3_data.editable) ? false : true;
                              return_flag = true;
                              return false;
                            }
                          });
                        } else {
                          if (e2_data.field == col_cd) {
                            editable = (typeof e2_data.editor.editable === 'function' ? !e2_data.editor.editable(colData) : !e2_data.editor.editable || !e2_data.editable) ? false : true;
                            return_flag = true;
                            return false;
                          }
                        }
                        if (return_flag) {
                          return false;
                        }
                      });
                    } else {
                      if (e_data.field == col_cd) {
                        editable = (typeof e_data.editor.editable === 'function' ? !e_data.editor.editable(colData) : !e_data.editor.editable || !e_data.editable) ? false : true;
                        return_flag = true;
                        return false;
                      }
                    }
            
                    if (return_flag) {
                      return false;
                    }
                  });
                  return editable;
                },
                readonlyFormPanel: function (form_panel, readonly) {
                  form_panel.$element.find('[class^=dews-ui].dews-form-control').each(function () {
                    if ($(this).data('dews-control').readonly) {
                      $(this).data('dews-control').readonly(readonly);
                    }
                  });
                },
                getPcInfoForBizareaCd: function (bizarea_cd) {
                  var pc_cd = '';
            
                  dews.api.get(
                    dews.url.getApiUrl('PS', 'PSCommonService', 'get_pcInfo')
                    , {
                      async: false
                      , data: {
                        bizarea_cd: bizarea_cd
                      }
                    }
                  ).done(function (data) {
                    pc_cd = data;
                  }).fail(function (a, b, c) {
                    dews.error(c);
                  });
            
                  return pc_cd;
                },
                getIndexForColumns: function (grid, obj) {
                  var index = -1
                    , _this = this
                    , matched_array = grid.dataItems().filter(function (e, i) {
                      if (_this.getRealType(obj) == '[object Function]') {
                        return obj(e, i);
                      }
                      else {
                        return !Object.keys(obj).some(function (key) {
                          return e[key] != obj[key];
                        });
                      }
                    });
            
                  if (matched_array.length > 0) {
                    index = _this.getIndexForColumn(grid, '__UUID', matched_array[0].__UUID);
                  }
            
                  return index;
                },
                /**
                 * 공통코드 종속관계 설정
                 * @param {*} self : 화면
                 * @param {*} objCodeDtl : 공통코드 데이터
                 * @param {*} fieldParam : 공통코드 필드(파이프형태)
                 * @param {*} emptyYn : 데이터소스 공백(전체)여부(Y,N)
                 * @param {*} dataObject : 그리드, 트리그리드, 카드리스트 등 ex)
                 * @param {*} controlAndColumnMappingArr : 그리드,트리그리드,카드리스트의 컬럼명과 그에 맞게 매핑된 컨트롤의 아이디 ex) ['I_CD_LGROUP|BIZ_L_CD','I_CD_MGROUP|BIZ_M_CD','I_CD_SGROUP|BIZ_S_CD']
                */
                setHierarchy: function (self, objCodeDtl, fieldParam, emptyYn, dataObject, controlAndColumnMappingArr) {
                  if (!self) {
                    dews.alert('종속구분 설정 중 오류가 발생하였습니다.');
                    console.log('self 파라미터 누락');
                    return;
                  }
                  if (!objCodeDtl) {
                    dews.alert('종속구분 설정 중 오류가 발생하였습니다.');
                    console.log('objCodeDtl 파라미터 누락');
                    return;
                  }
                  if (!fieldParam) {
                    dews.alert('종속구분 설정 중 오류가 발생하였습니다.');
                    console.log('fieldParam 파라미터 누락');
                    return;
                  }
                  if (!emptyYn) {
                    dews.alert('종속구분 설정 중 오류가 발생하였습니다.');
                    console.log('emptyYn 파라미터 누락');
                    return;
                  }
            
                  var hierarchyCode = [];
            
                  dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', 'common_codeDtl_cdstrct'), {
                    async: false,
                    data: {
                    }
                  }).done(function (data) {
                    hierarchyCode = data;
                  }).fail(function (xhr, status, error) {
                    dews.alert(error);
                  });
            
                  var hierarchyCtrl = [];
                  $.each(self.$content.find('[class^=dews-ui-dropdownlist]'), function (idx, node) {
                    var field = $(node).attr('data-field');
                    if (!field) {
                      return true;
                    }
            
                    var fieldArr = field.split("|");
                    if (fieldParam.indexOf(fieldArr[1]) < 0 || !objCodeDtl[fieldArr[0]][fieldArr[1]] || objCodeDtl[fieldArr[0]][fieldArr[1]].length == 0) {
                      return true;
                    }
            
                    var dataItems = objCodeDtl[fieldArr[0]][fieldArr[1]][objCodeDtl[fieldArr[0]][fieldArr[1]].length - 1]; //각 코드별 맨 마지막 값으로 계층구조여부 확인
                    if (dataItems && dataItems.HIKEY_YN == 'Y') {
                      hierarchyCtrl.push(node.id + "|" + field);
                      var pModule = dataItems.UP_MODULE_CD;//현시점의 부모모듈
                      var pField = dataItems.UP_FIELD_CD;//현시점의 부모필드
            
                      function hierarchySetting(node) {
                        var items = changehierarchy(node.attr('data-field'));
                        var arrItems = items.split(",");
                        for (var i = 1; i < arrItems.length; i++) {
                          var target = $("select[data-field='" + arrItems[i] + "']");
                          var parentTarget = $("select[data-field='" + arrItems[i - 1] + "']");
                          var targetData = arrItems[i].split("|");
            
                          var arr = objCodeDtl[targetData[0]][targetData[1]].filter(function (item) {
                            return item.UP_SYSDEF_CD == self[parentTarget[0].id].value();
                          });
            
                          if (arr.length > 0) {
                            arr.unshift({ SYSDEF_CD: '', SYSDEF_NM: '' });
                          }
            
                          self[target[0].id].setDataSource(arr);
                        }
                      }
            
                      function changehierarchy(value) {
                        var attr = value.split("|");
                        var arr = hierarchyCode.filter(function (item) {
                          return item.UP_MODULE_CD == attr[0] && item.UP_FIELD_CD == attr[1];
                        });
            
                        if (arr.length == 1) {
                          var result = changehierarchy(arr[0].MODULE_CD + "|" + arr[0].FIELD_CD);
                          return value + "," + result;
                        } else {
                          return value;
                        }
                      }
            
                      if (!pModule && !pField) {// 최상위
                        if (emptyYn == 'Y') {
                          objCodeDtl[fieldArr[0]][fieldArr[1]].unshift({ SYSDEF_CD: '', SYSDEF_NM: '' });
                        }
                        self[node.id].setDataSource(objCodeDtl[fieldArr[0]][fieldArr[1]]);
                      } else {//그이외
                        hierarchySetting($(node));
                      }
                      //드롭다운리스트 변경시 계층구조에 따라 데이터소스 변환
                      self[node.id].on('change', function (e) {
                        hierarchySetting($(node));
                      });
                    } else {
                      self[node.id].setDataSource(objCodeDtl[fieldArr[0]][fieldArr[1]]);
                    }
                  });
            
                  if (dataObject && controlAndColumnMappingArr && controlAndColumnMappingArr.length > 0) {
                    dataObject.on('change', function (e) {
                      if (e.row.index < 0) {
                        return;
                      }
                      // 카드리스트일 경우 e.row.isChange, e.isDataBound가 항상 undefined입니다.
                      if (!dataObject._card && !e.row.isChange && !e.isDataBound) {
                        return;
                      }
            
                      var clearFlag = true;
            
                      $.each(controlAndColumnMappingArr, function (idx, item) {
                        var splitArr = item.split('|');
                        if (splitArr.length != 2) {
                          console.error('controlAndColumnMappingArr:' + item + ' - ' + '해당 파라미터로 인하여 오류가 발생했습니다.');
                          return true;
                        }
            
                        self[splitArr[0]].value(e.row.data[splitArr[1]]);
            
                        if (dataObject.options.dataSource.getDirtyDataCount() > 0) {
                          clearFlag = false;
                        }
            
                        self[splitArr[0]].raiseEvent('change');
                      });
            
                      setTimeout(function () {
                        if (clearFlag) {
                          if (dataObject._card) {
                            // 카드리스트
                            dataObject.clearRowStates();
                          } else {
                            // (트리)그리드
                            dataObject.dataSource.dataProvider.clearRowStates();
                          }
                        }
                      }, 10);
                    });
                  }
                },
                /* --------------------------------------------------------------------------------------------
                 *  @desc       backendService 버전정보 리턴 (콘솔 log 찍습니다.)
                 *  @return     versionInfo
                 *  @call       PS_UTIL.getVersion('1.0.22072701', 'PSCustomCodeHelpService')
                 * ------------------------------------------------------------------------------------------*/
                getVersion: function (frontEndVersion, backEndServiceName) {
                  var versionInfo = { frontEndVersion: frontEndVersion, backEndVersion: '' };
                  dews.api.get(dews.url.getApiUrl('CM', 'ServiceVersion'), {
                    async: false,
                    data: {
                      service: backEndServiceName
                    }
                  }).done(function (data) {
                    if (data && data.length > 0) {
                      versionInfo.backEndVersion = data;
                    }
                  }).fail(function (xhr, status, error) {
                    setTimeout(function () {
                      dews.error('오류가 발생하였습니다.');
                    }, 200);
                    console.error(error);
                  });
                  console.log("%c■ 버전정보", 'color: rgb(0,  84,  255)')
                  console.log("> FrontEnd-Version : " + versionInfo.frontEndVersion);
                  console.log("> BackEnd-Version : " + versionInfo.backEndVersion);
                  return versionInfo;
                }
              };
            
            
            
            
            
            
            
            
              //-------------------------------------------End-------------------------------------------
            
              var newModule = {};
              newModule[moduleCode] = module;
              window.gerp = $.extend(true, gerp, newModule);
            })(window.dews, window.gerp || {}, jQuery);
            
                        //# sourceURL=/view/js/PS/ps.js
            