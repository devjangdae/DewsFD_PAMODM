/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
 * @desc    PU 모듈 공통 함수
 * @author  qkrwhdrb
 * @date    2019.01.04
 * @path    /view/js/pu.js
 */
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'PU';  //모듈 코드

    // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  /**********************************************************************************************/

  //------------------------------------------Start------------------------------------------

  //COM
  module.com = {
    /*********************************************************************************************
     *  @desc  문자의 byte를 체크하는 메서드
     *  @param {char} ch    byte를 체크할 문자
     *  @ex    puJS.com.charByteSize("A");
     * ------------------------------------------------------------------------------------------*/
    charByteSize : function(ch) {
      if (ch == null || ch.length == 0) {
        return 0;
      }
      var charCode = ch.charCodeAt(0);

      if (charCode <= 0x00007F) {
        return 1;
      } else if (charCode <= 0x0007FF) {
        return 2;
      } else if (charCode <= 0x00FFFF) {
        return 3;
      } else {
        return 4;
      }
    },

    /*********************************************************************************************
     *  @desc  문자열의 byte를 체크하는 메서드
     *  @param {char} s    byte를 체크할 문자열
     *  @ex    puJS.com.getByteLength("A");
     * ------------------------------------------------------------------------------------------*/
    getByteLength : function(s) {
      if (s == null || s.length == 0) {
        return 0;
      }
      var size = 0;
      for ( var i = 0; i < s.length; i++) {
        size += this.charByteSize(s.charAt(i));
      }
      return size;
    },

    /*********************************************************************************************
     *  @desc  문자열의 byte를 비교하는 메서드
     *  @param {char} s         byte를 체크할 문자열
     *  @param {Number} size    비교할 크기
     *  @ex    puJS.com.chkByteLength("TEST", 8);
     * ------------------------------------------------------------------------------------------*/
    chkByteLength : function(s, size){
      if (s == null || s.length == 0)  return true;
      var s_size = 0;

      s_size = this.getByteLength(s);

      return s_size > size ? false : true;
    }
  }

  //API
  module.api = {
    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc           계정범주설정 가능 여부
      *  @ex             Puracct_ctgry_cd_validation_check("1", "A")
      *  @memo           라인유형에 따른 설정 가능한 계정범주들에 대한 validation_check
      * --------------------------------------------------------------------------------------------
      *  @puracct_ctgry_cd   계정범주
      *  @pur_line_tp        라인유형
      * --------------------------------------------------------------------------------------------
      *  @return         true or false
      * ------------------------------------------------------------------------------------------*/
    Puracct_ctgry_cd_validation_check:  function (puracct_ctgry_cd, pur_line_tp)
    {

      if(pur_line_tp ==="A")
      {
        if(puracct_ctgry_cd !="1" &&  puracct_ctgry_cd !="C")
        {
          return false;
        }
      }
      else if(pur_line_tp ==="G")
      {
        if(puracct_ctgry_cd !="A" &&  puracct_ctgry_cd !="C" &&  puracct_ctgry_cd !="O" &&  puracct_ctgry_cd !="P")
        {
          return false;
        }
      }
      else if(pur_line_tp ==="I")
      {
        if(puracct_ctgry_cd !="1" &&  puracct_ctgry_cd !="A" &&  puracct_ctgry_cd !="O" &&  puracct_ctgry_cd !="P" &&  puracct_ctgry_cd !="S")
        {
          return false;
        }
      }
      else if(pur_line_tp ==="O")
      {
        if(puracct_ctgry_cd !="1")
        {
          return false;
        }
      }
      else if(pur_line_tp ==="S")
      {
        if(puracct_ctgry_cd !="1" && puracct_ctgry_cd !="O")
        {
          return false;
        }
      }
      else if(pur_line_tp ==="U")
      {
        if(puracct_ctgry_cd !="1")
        {
          return false;
        }
      }
      else if(pur_line_tp ==="V")
      {
        if(puracct_ctgry_cd !="1" && puracct_ctgry_cd !="P" && puracct_ctgry_cd !="S")
        {
          return false;
        }
      }
      //comboDataSource.setDataSource(ddl);

      return true;
    },

    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc           MA_SCMCODE_DTL 조회
      *  @ex             fn_get_scmCode_dtl(SCM공통코드)
      *  @memo           SCM공통 코드 정보 조회
      * --------------------------------------------------------------------------------------------
      *  @module_cd      모듈코드
      *  @cd_field_scm   SCM공통코드
      * --------------------------------------------------------------------------------------------
      *  @return         SCM공통코드에 대한 정보
      * ------------------------------------------------------------------------------------------*/
    getSCMCodeDtl : function (module_cd, cd_field_scm){
      var returnData = null;

      dews.api.get(dews.url.getApiUrl('PU', 'PuCommonService', dews.string.format('getScmcode_dtl')), {
        async: false,
        data: {
          module_cd: module_cd,
          cd_field_scm: cd_field_scm
        }
      }).done(function (data) {
        if(data.length > 0){
          returnData = data;
        }
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });

      return returnData;
    },

    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc           단위환산
      *  @ex             get_qt_unit_base(품목코드, 수량, 관리단위(발주단위), 기준단위 )
      *  @memo           입력 된 수량의 기준단위 대비 관리단위에 대한 수량
      * --------------------------------------------------------------------------------------------
      *  @item_cd        품목
      *  @qt_source      수량
      *  @unit_source    관리단위(발주단위),
      *  @unit_target    기준단위
      * --------------------------------------------------------------------------------------------
      *  @return          변환된 수량
      * ------------------------------------------------------------------------------------------*/
    get_qt_unit_base : function (item_cd, qt_source, unit_source, unit_target ){
      var unit_rate;
      // var item_cd, qt_source, cd_unit_source, cd_unit_target;
      var returnData = null;

      dews.api.get(dews.url.getApiUrl('PU', 'PuCommonService', dews.string.format('getQt_Unit_Changed')), {
        async: false,
        data: {
          item_cd: item_cd || "",
          qt_source: qt_source || 0,
          cd_unit_source: unit_source || "",
          cd_unit_target: unit_target || ""
        }
      }).done(function (data) {
        if (data != null) {
          returnData = Number(data);
        }
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });
      return returnData;
    },

    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc           회사 통화 정보
      *  @ex             get_company_exch_cd()
      *  @memo           회사 통화 정보
      * --------------------------------------------------------------------------------------------
      *
      * --------------------------------------------------------------------------------------------
      *  @return         회사통화
      * ------------------------------------------------------------------------------------------*/
    get_company_exch_cd : function ()
    {
      var company_exch_cd;
      var data =  module.api.getXmlData({P_XML_ID: "get_COMPANY_EXCH_CD"})
      if (data && data.length > 0) {
        company_exch_cd = data[0].EXCH_CD;
      }
      return company_exch_cd;
    },


    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc           환율 정보 로드
      *  @ex             getExrt_rt(환종(통화), 기축통화(회사 통화) )
      *  @memo           기축통화 대비 입력된 통화의 환율 정보
      * --------------------------------------------------------------------------------------------
      *  @exch_cd        환종
      *  @com_exch_cd    기축통화(회사통화)
      * --------------------------------------------------------------------------------------------
      *  @return         환율
      * ------------------------------------------------------------------------------------------*/
    getExrt_rt : function (exch_cd, com_exch_cd)
    {
      var exrt_rt = null;
      if(exch_cd && com_exch_cd){
        if(exch_cd == com_exch_cd){
          exrt_rt = 1;
        }
        else{
          dews.api.get(dews.url.getApiUrl('PU', 'PuCommonService', dews.string.format('getPU_Exrt_Rt')), {
            async: false,
            data: {
              exrt_rt_fg: "1",
              std_crnc_cd: exch_cd,
              trgt_crnc_cd: com_exch_cd
            }
          }).done(function (data) {
            if (data.length > 0) {
              exrt_rt = data[0].STD_EXRT_RT;
            } else {
              exrt_rt = 1;
            }
          }).fail(function (xhr, status, error) {
            dews.error(error);
          });
        }
      }
      return exrt_rt;
    },
    /* --------------------------------------------------------------------------------------------
    *  @no
    *  @desc           문서이력생성
    *  @ex             setDocMst_his
    *  @memo           변경컬럼에 대한 Mst 정보 DataSource추가
    * --------------------------------------------------------------------------------------------
    *  @hisDtl_dataSource  참조 DataSource
    *  @DOC_HIS_TP         문서유형 ex) 'PO'
    *  @DOC_HIS_NO         문서번호 ex) 'PUR2019010007'
    *  @DOC_HIS_SQ         문서이력순번(차수) ex) 1
    *  @PROC_MENU_CD       메뉴코드 ex) 'PUOORD00100'
    *  @CHGE_EMP_NO        변경사원 ex) 'wooya'
    *  @CHGE_RECORD_TP     변경레코드유형 ex) 'U'
    * --------------------------------------------------------------------------------------------
    *  @return hisMst_dataSource
    * ------------------------------------------------------------------------------------------*/

    setDocMst_his : function (hisMst_dataSource, DOC_HIS_TP, DOC_HIS_NO, DOC_HIS_SQ,
      PROC_MENU_CD, CHGE_EMP_NO, CHGE_RECORD_TP)
    {
      var returnData = hisMst_dataSource;

      var objDtlData = [
        { DOC_HIS_TP : DOC_HIS_TP },
        { DOC_HIS_NO : DOC_HIS_NO },
        { DOC_HIS_SQ : DOC_HIS_SQ },
        { PROC_MENU_CD : PROC_MENU_CD },
        { CHGE_EMP_NO : CHGE_EMP_NO },
        { CHGE_RECORD_TP : CHGE_RECORD_TP }
      ];

      return returnData.add(objDtlData);

    },

    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc           문서이력생성
      *  @ex             setDocdtl_his
      *  @memo           변경컬럼에 대한 Dtl 이력 DataSource추가추가
      * --------------------------------------------------------------------------------------------
      *  @hisDtl_dataSource  참조 DataSource
      *  @DOC_HIS_TP         문서유형 ex) 'PO'
      *  @DOC_HIS_NO         문서번호 ex) 'PUR2019010007'
      *  @DOC_HIS_SQ         문서이력순번(차수) ex) 1
      *  @TABLE_ID           테이블명 ex) 'PU_PURORDER_DTL'
      *  @RECORD_KEY_VR      레코드키문자값 ex) 'PUR20190100071'
      *  @COL_ID             컬럼ID ex) 'PUR_TRAN_UM'
      *  @CHGE_RECORD_TP     변경레코드유형 ex) 'U'
      *  @NEW_DATA           신규데이터 ex) ''
      *  @BEF_DATA           이전데이터 ex) ''
      *
      * --------------------------------------------------------------------------------------------
      *  @return hisDtl_dataSource
      * ------------------------------------------------------------------------------------------*/
    setDocDtl_his : function (hisDtl_dataSource, DOC_HIS_TP, DOC_HIS_NO, TABLE_ID,
                              RECORD_KEY_VR, COL_ID, CHGE_RECORD_TP, NEW_DATA,
                              BEF_DATA, DATA_TYPE)
    {
      var returnData = hisDtl_dataSource;

      var objDtlData = [
        { DOC_HIS_TP : DOC_HIS_TP },
        { DOC_HIS_NO : DOC_HIS_NO },
        { TABLE_ID : TABLE_ID },
        { RECORD_KEY_VR : RECORD_KEY_VR },
        { COL_ID : COL_ID },
        { CHGE_RECORD_TP : CHGE_RECORD_TP },
        { NEW_VR : null},
        { BEF_VR : null},
        { NEW_VN : null},
        { BEF_VN : null}
      ];

      if(DATA_TYPE == "String")
      {
        objDtlData.NEW_VR = NEW_DATA;
        objDtlData.BEF_VR = BEF_DATA;
      }
      else
      {
        objDtlData.NEW_VN = NEW_VN;
        objDtlData.BEF_VN = BEF_VN;
      }

      $.each(cd_field_pipe.split("|"), function (i, v) {
          if (v != null && v != "") {objCodeDtl[module_cd][v] = [];} /* #.# cd_module 변환됨 => module_cd */
      });

      return returnData.add(objDtlData);
    },


    getDocMst_his_schema : function ()
    {
      dataSource = dews.ui.dataSource("dataSource", {
        grid: true, async: false,
        schema: {
          model: {
            id: "DOC_HIS_NO",
            fields: [
              { field: "DOC_HIS_TP", type: "string" },
              { field: "DOC_HIS_NO", type: "string" },
              { field: "DOC_HIS_SQ", type: "string" },
              { field: "PROC_MENU_CD", type: "string" },
              { field: "CHGE_EMP_NO", type: "string" },
              { field: "CHGE_RECORD_TP", type: "string" }

            ]
          }
        }

      });

      return dataSource;
    },

    getDocDtl_his_schema : function ()
    {
      dataSource = dews.ui.dataSource("dataSource", {
        grid: true, async: false,
        schema: {
          model: {
            id: "RECORD_KEY_VR",
            fields: [
              { field: "DOC_HIS_TP", type: "string" },
              { field: "DOC_HIS_NO", type: "string" },
              { field: "DOC_HIS_SQ" },
              { field: "TABLE_ID", type: "string" },
              { field: "RECORD_KEY_VR", type: "string" },
              { field: "COL_ID", type: "string" },
              { field: "CHGE_RECORD_TP", type: "string" },
              { field: "NEW_VR", type: "string" },
              { field: "BEF_VR", type: "string" },
              { field: "NEW_VN" },
              { field: "BEF_VN" }
            ]
          }
        }

      });
    return dataSource;
    },

    /* --------------------------------------------------------------------------------------------
      *  @no             02
      *  @desc           에러다이얼로그열기
      *  @memo           SCM공통 에러처리
      * --------------------------------------------------------------------------------------------
      *  @e              에러배열
      * ------------------------------------------------------------------------------------------*/
    openErrorDialog : function (e){
      var location = window.location.href;
      if(location.indexOf('localhost') > -1 || location.indexOf('10.35.13') > -1){
        // 로컬일 경우 팝업창 띄움
        var initData = {err : e};
        dialog = dews.ui.dialog("SOPOPP00504_POP",
            {
              url: "/view/PP/SOPOPP00504_POP",
              title: "에러확인",
              width: "600",
              height: "400",
              ok: function (data, e) {
              }
            });
        dialog.setInitData(initData);
        dialog.open();
      } else {
        // 이외의 접속인 경우 console로 처리(개발서버, 데모서버, ...)
        $.each(e, function(idx, item){
          if(idx == 0){
            console.log('1. Error Type : ' + item);
          } else if(idx == 1){
            console.log('2. Error Class : ' + item);
          } else if(idx == 2){
            console.log('3. Error Method : ' + item);
          } else if(idx == 3){
            console.log('4. Error Line : ' + item);
          } else if(idx == 4){
            console.log('5. Error Log : ' + item);
          }
        });
      }
    },
    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc                  단가정보 로드
      *  @ex                    getPubinf(partner_cd, item_cd, item_grp_cd, plant_cd, purorg_cd, purdoc_ctgry_cd, valid_dt)
      *  @memo                  구매거래처, 구매조직을 기준으로
      * --------------------------------------------------------------------------------------------
      *  @param_partner_cd      구매거래처코드
      *  @param_item_cd         품목코드
      *  @param_po_unit_cd      품목단위코드
      *  @param_item_grp_cd     품목그룹코드
      *  @param_plant_cd        공장코드
      *  @param_purorg_cd       구매조직코드
      *  @param_purdoc_ctgry_cd 문서범주
      *  @param_valid_dt        유효일
      * --------------------------------------------------------------------------------------------
      *  @return                object<Pubinf00800_PUBINF> list (
      *                           item_cd : String
      *                           po_unit_cd : String
      *                           pur_tran_um : BigDecimal
      *                           exch_cd : String
      *                           po_price_info_no_dtl : String
      *                           po_price_info_sq_dtl : BigDecimal
      *                           ... 외 com.douzone.comet.service.pu.pubinf.models.Pubinf00800_PUBINF 참조.
      *                         )
      *  @수정
      *     2019.04.30 수정: 김준일, 내용: param_po_unit_cd 품목단위코드 파라미터 추가.
      *     2019.09.17 요청: 박종규, 수정: 김준일, 내용: param_po_unit_cd 품목단위코드 파라미터 추가.
      *     2019.10.09 요청: 박종규, 수정: 김준일, 내용: api url 변경(PUBINF -> PU공통서비스).
      * ------------------------------------------------------------------------------------------*/
    getPubinf: function (param_partner_cd, param_item_cd, param_po_unit_cd, param_item_grp_cd, param_plant_cd, param_purorg_cd, param_purdoc_ctgry_cd, param_valid_dt){
      var returnObject = null;
      dews.api.get(dews.url.getApiUrl('PU', 'PuCommonService', 'PuCommonService_list_pubinf'), {
        async: false,
        data: {
          partner_cd: param_partner_cd || null,
          item_cd: param_item_cd || null,
          po_unit_cd: param_po_unit_cd || null,
          item_grp_cd: param_item_grp_cd || null,
          plant_cd: param_plant_cd || null,
          purorg_cd: param_purorg_cd || null,
          purdoc_ctgry_cd: param_purdoc_ctgry_cd || null,
          valid_dt: param_valid_dt || null
        }
      }).done(function (data) {
        returnObject = data;
      });
      return returnObject;
    },

    /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc                  단가정보 로드 (통합환경의 단가결정 사용유무에 따른 단가정보 로드)
      *  @ex                    getPriceInfo(parameters)
      *  @memo                  구매거래처, 구매조직을 기준으로
      * --------------------------------------------------------------------------------------------
      *  @parameters.partner_cd      구매거래처코드
      *  @parameters.item_cd         품목코드
      *  @parameters.po_unit_cd      품목단위코드
      *  @parameters.item_grp_cd     품목그룹코드
      *  @parameters.plant_cd        공장코드
      *  @parameters.purorg_cd       구매조직코드
      *  @parameters.purdoc_ctgry_cd 문서범주
      *  @parameters.valid_dt        유효일
      * --------------------------------------------------------------------------------------------
      *  @return                object<PuCommonUtil_PU_PRICEINFO_PRTNR> list (
      *                           item_cd : String
      *                           po_unit_cd : String
      *                           pur_tran_um : BigDecimal
      *                           exch_cd : String
      *                           po_price_info_no_dtl : String
      *                           po_price_info_sq_dtl : BigDecimal
      *                           ... 외 com.douzone.comet.service.pu.common.models.PuCommonUtil_PU_PRICEINFO_PRTNR 참조.
      *                         )
      * ------------------------------------------------------------------------------------------*/
    getPriceInfo: function(parameters){
      var returnObject = null;
      var use_inf = false;
      var maCtrlConfig = module.api.getXmlData({ P_XML_ID: "get_MA_CTRLCONFIG", P_MODULE_CD: "PU", P_CTRL_CD: "PU00002"});
      var serviceUrl = 'PuCommonService_list_priceinfo';

      if(maCtrlConfig && maCtrlConfig.length > 0){
        if(maCtrlConfig[0].CTRL_VR == "Y"){
          serviceUrl = 'PuCommonService_list_pubinf';
          use_inf = true;
        }
      }

      //구매거래처단가 사용시 거래단위 제외한 나머지는 전부 필수
      if(!use_inf){
        for(var key in parameters){
          if(key != "po_unit_cd"){
            if(parameters[key] == undefined || parameters[key] == null || parameters[key] == ""){
              return returnObject;
            }
          }
        }
      }

      dews.api.get(dews.url.getApiUrl('PU', 'PuCommonService', serviceUrl), {
        async: false,
        data: {
          partner_cd: parameters.partner_cd || null,
          exch_cd: parameters.exch_cd || null,
          item_cd: parameters.item_cd || null,
          po_unit_cd: parameters.po_unit_cd || null,
          item_grp_cd: parameters.item_grp_cd || null,
          plant_cd: parameters.plant_cd || null,
          purorg_cd: parameters.purorg_cd || null,
          purdoc_ctgry_cd: parameters.purdoc_ctgry_cd || null,
          valid_dt: parameters.valid_dt || null
        }
      }).done(function (data) {
        returnObject = data[0];
      });

      return returnObject;
    },


    /* --------------------------------------------------------------------------------------------
    *  @desc                 결제조건 또는 거래처에 해당하는 결제조건을 조회하여, 결제예정일을 계산하는 함수
    *  @author               김준일 (kji6649)
    *  @ex                   getTerpay_Plan_Dt: function (terpay_cd, partner_cd, purorg_cd, base_dt, partner_fg)
    *  @memo                 실행순서
    *                         1. 결제조건 코드가 있을때, 해당하는 결제조건에 해당하는 결제예정일을 계산한다.
                              2. 결제조건코드가 null 또는 공백일때, 회사거래처여부에 따라, 조회기준 거래처테이블이 달라진다.
                                  partner_fg = '1' -> 회사거래처-매입거래-결제조건으로 결제예정일을 계산.
                                  partner_fg = '2' -> 구매거래처-결제조건으로 결제예정일을 계산.
                              3. 기준일은 필수이다.
    * --------------------------------------------------------------------------------------------
    *  terpay_cd             결제조건코드 (선택)
    *  partner_cd            거래처코드 (선택)
    *  purorg_cd             구매조직 (선택)
    *  base_dt               기준일 (필수, 포맷 'yyyyMMdd')
    *  partner_fg            회사거래처여부 = 1 구매거래처여부 = 2
    * --------------------------------------------------------------------------------------------
    *  @return               PuCommonUtil_Terpay_Plan_Dt, Exception
    *  @수정
    * ------------------------------------------------------------------------------------------*/
    getTerpay_Plan_Dt: function (terpay_cd, partner_cd, purorg_cd, base_dt, partner_fg) {
      var returnDt = null;
      dews.api.get(dews.url.getApiUrl("PU", "PuCommonService", "getTerpay_Plan_Dt"),{
        async : false,
        data : {
          terpay_cd : terpay_cd,
          partner_cd : partner_cd,
          purorg_cd : purorg_cd,
          partner_fg : partner_fg,
          base_dt : base_dt
        }
      }).done(function(data){
        returnDt = data;
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });
      return returnDt;
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc                 공통 세팅데이터 조회
    *  @author               김준일 (kji6649)
    *  @ex                   puApi.getXmlData({P_XML_ID: "get_MA_PARTNERPU_INFO", P_PURORG_CD: "1000", P_PARTNER_CD: "2000001001"})
    * --------------------------------------------------------------------------------------------
    *  params                파라미터 오브젝트
        P_XML_ID             P_XML_ID (필수)
    * --------------------------------------------------------------------------------------------
    *  @return               List<Map<String, Object>>, Exception
    *  @수정
    * ------------------------------------------------------------------------------------------*/
    getXmlData: function(obj){
      var returnVr = null;
      if(obj && obj.P_XML_ID){
        dews.api.post(dews.url.getApiUrl("PU", "PuCommonService", "getXmlData"),{
          async : false,
          data : {
            params: JSON.stringify(obj)
          }
        }).done(function(data){
          returnVr = data;
        }).fail(function (xhr, status, error) {
          dews.error(error);
        });
      }
      return returnVr;
    },
    /*********************************************************************************************
     *  @desc  저장 실패시 에러 메세지를 보여줄 수 있는 다이얼로그를 오픈한다
     *  @param {Array} arrErrorMsg    에러 메세지를
     *  @ex    puJS.openErrorMsgDialog(arrErrorMsg);
     *********************************************************************************************/
    openErrorMsgDialog : function(arrErrorMsg){
      dialog = dews.ui.dialog("H_PU_ERROR_C",
        {
          url: "/codehelp/PU/H_PU_ERROR_C",
          title: "저장실패",
          width: "700",
          height: "300",
          ok: function (data, e) {
          }
        });
      dialog.setInitData(arrErrorMsg);
      dialog.open();
    },
    /*********************************************************************************************
    *  @desc  예산 다이얼로그를 오픈한다
    *  @param {Object} data    예산 데이터 오픈시 필요한 정보
    *  @ex    puJS.openBudgetMsgDialog(data);
    *         data = {company_cd : 'test',
                      bmData     : resultBmApiData }
              resultBmApiData -> 예산 결과 데이터
    *********************************************************************************************/
   openBudgetMsgDialog : function (data){
     dialog = dews.ui.dialog("H_PU_BUDGET_C",
       {
         url: "/codehelp/PU/H_PU_BUDGET_C",
         title: "예산 오류",
       });
     dialog.setInitData(data);
     dialog.open();
   },

    /*********************************************************************************************
     *  @desc  회사환경설정보가져오기
     *  @param module_cd  모듈코드
     *  @param ctrl_cd    통제코드
     *  @ex    module.api.getMaCtrlConfig(module_cd, ctrl_cd);
    *********************************************************************************************/
    getMaCtrlConfig : function(module_cd, ctrl_cd){
      var resultData = null;
      dews.api.get(dews.url.getApiUrl("CM", "CommonCtrlConfigService", "common_ma_ctrlconfig_string"), {
        async : false,
        data  : {
          module_cd: module_cd,
          ctrl_cd: ctrl_cd,
          use_yn : 'Y'
        }
      }).done(function (data) {
        if(data.length > 0){
          resultData = data;
        }
      }).fail(function (xhr, satus, error) {
        dews.error(error);
      });
      return resultData;
    },

    /*********************************************************************************************
     *  @desc   구매공통예산체크
     *  @param  {Array} chkList 예산체크 대상 List [{BGACCT_CD, BUDGET_CD, BIZPLAN_CD, BUDGET_DT, BOOK_AMT}]
     *  @return bool
     *  @ex     module.api.bmProfitCheck([{BGACCT_CD, BUDGET_CD, BIZPLAN_CD, BUDGET_DT, BOOK_AMT}, .....]]);
    *********************************************************************************************/
    bmProfitCheck : function(chkList){
      var bRtn = true;
      var bFlag = false;
      var PU00001 = module.api.getMaCtrlConfig("PU", "PU00001");
      var menuId = dews.ui.page.menu.id.toString().substring(0, 6);
      if(menuId == "PUOPRQ" && (PU00001 == "1" || PU00001 == "2")){
        bFlag = true;
      }
      else if(menuId == "PUOORD" && (PU00001 == "1" || PU00001 == "3" || PU00001 == "2" )){
        bFlag = true;
      }

      if(bFlag){
        if(!chkList || chkList.length < 1){
          bRtn = false;
          dews.ui.snackbar.warning("예산체크 대상이 존재하지 않습니다.");
        }else{
          dews.api.post(dews.url.getApiUrl('PU', 'PuCommonService', 'PuCommonBmProfitCheck'), {
            async: false,
            data : {
              chkList: JSON.stringify(chkList)
            }
          }).done(function(data) {
            if(data.length > 0) {
              bRtn = false;
              dews.ui.loading.hide();
              if(data[0].RESULT == "exception"){
                if(data[0].BG_ERR_MSG == null || data[0].BG_ERR_MSG == ""){
                  dews.alert("예산체크중 시스템 오류가 발생했습니다.", {icon: "error"});
                }
                else{
                  dews.alert(data[0].BG_ERR_MSG , {icon: "error"});
                }
              }else{
                module.api.openBudgetMsgDialog({bmData : data});
              }
            }
          }).fail(function(xhr,status, error) {
            dews.ui.loading.hide();
            dews.error(error);
            bRtn = false;
          });
        }
      }
      return bRtn;
    },

    /*********************************************************************************************
     *  @desc   Closing Default Value 저장하기 (체크박스 컨트롤 포함하여 사용하기 위해 만듦)
     *  @param  dewself(dews 객체), onlyRequired(required만 대상 true/false), postData(컨트롤 설정을 위한 컨트롤 객체 배열(생략가능))
     *  @return none
     *  @ex     module.api.setMenuDefaultValue(dewself, false);
    *********************************************************************************************/
    setMenuDefaultValue : function(dewself, onlyRequired, postData){
      var items = [];
      var pageId = dewself.menu ? dewself.menu.id : dewself.id;
      var dewsContent;

      if (arguments.length == 2) {
        if (onlyRequired) {
          dewsContent = dewself.$content.find(".dews-ui-condition-panel .required");
        }
        else {
          dewsContent = dewself.$content.find(".dews-ui-condition-panel .dews-form-control");
        }
      }
      else if (arguments.length == 3) {
        dewsContent = postData;
      }
      else {
        return false;
      }

      if (dewsContent.length) {
        $(dewsContent).each(function (index, node) {
          if (!$(node).hasClass("disabled")) {
            var dewsControl = $(node).data('dews-control');
            if (dewsControl) {
              var obj = undefined;
              if ($(node).hasClass("dews-ui-dropdownlist")   || $(node).hasClass("dews-ui-numerictextbox") || $(node).hasClass("dews-ui-maskedtextbox") ||
                  $(node).hasClass("dews-ui-datepicker")     || $(node).hasClass("dews-ui-timepicker")     || $(node).hasClass("dews-ui-monthpicker")   ||
                  $(node).hasClass("dews-ui-datetimepicker") || $(node).hasClass("dews-ui-zipcodepicker")  || $(node).hasClass("dews-ui-combobox")      ||
                  $(node).hasClass("dews-ui-checkbox") ) {
                var name = typeof (dewsControl.text) == "function" ? dewsControl.text() : "";
                obj = { id: node.id, code: dewsControl.value(), name: name, etc: "" };
              }
              else if (
                $(node).hasClass("dews-ui-monthperiodpicker") ||
                $(node).hasClass("dews-ui-periodpicker")) {
                items.push({ id: node.id + "_#START", code: dewsControl.getStartDate(), name: "", etc: "" });
                items.push({ id: node.id + "_#END", code: dewsControl.getEndDate(), name: "", etc: "" });
              }
              else if ($(node).hasClass("dews-ui-weekperiodpicker")) {
                items.push({ id: node.id + "_#START", code: dewsControl.getStartWeek(), name: "", etc: "" });
                items.push({ id: node.id + "_#END", code: dewsControl.getEndWeek(), name: "", etc: "" });
              }
              else if ($(node).hasClass("dews-ui-textbox")) {
                obj = { id: node.id, code: dewsControl.text(), name: "", etc: "" };
              }
              else if ($(node).hasClass("dews-ui-codepicker")) {
                var code = dewsControl.code() == "NULL" || dewsControl.code() == null ? "" : dewsControl.code();
                obj = { id: node.id, code: code, name: dewsControl.text(), etc: "" };
              }
              else if ($(node).hasClass("dews-ui-multicodepicker")) {
                for (var i = 0; i < dewsControl.codes().length; i++) {
                  items.push({ id: node.id + "_#" + i, code: dewsControl.codes()[i], name: dewsControl.texts()[i], etc: "" });
                }
              }
              if (obj) {
                items.push(obj);
              }
            }
          }
        });
        dews.api.post(dews.url.getApiUrl('CM', 'AuthorityService', 'setMenuDefaultValue'), {
          async: false,
          data: {
            menuId: pageId,
            items: JSON.stringify(items)
          }
        }).done(function (data) {
        }).fail(function (xhr, satus, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.'));
        });
      }
    },

    /*********************************************************************************************
     *  @desc   Closing Default Value 가져오기 (체크박스 컨트롤 포함하여 사용하기 위해 만듦)
     *  @param  dewself(dews 객체), onlyRequired(required만 대상 true/false), postData(컨트롤 설정을 위한 컨트롤 객체 배열(생략가능))
     *  @return none
     *  @ex     module.api.getMenuDefaultValue(dewself, false);
    *********************************************************************************************/
    getMenuDefaultValue : function(dewself, onlyRequired, postData){
      var dewsContent;
      var menuDefault = [];

      // argument 비교
      if (arguments.length == 2) {
        if (onlyRequired) {
          dewsContent = dewself.$content.find(".dews-ui-condition-panel .required");
        }
        else {
          dewsContent = dewself.$content.find(".dews-ui-condition-panel .dews-form-control");
        }
      }
      else if (arguments.length == 3) {
        dewsContent = postData;
      }
      else {
        return false;
      }

      if (dewself.authority) { // 메뉴 페이지
        menuDefault = dewself.authority.menuDefault;
      }
      else { // 다이얼로그 페이지
        dews.api.get(dews.url.getApiUrl('CM', 'AuthorityService', 'getMenuDefaultValue'), {
          async: false,
          data: {
            menuId: dewself.id,
          }
        }).done(function (data) {
          if (data) {
            menuDefault = data;
          }
        }).fail(function (xhr, satus, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.'));
        });
      }

      if (menuDefault.length > 0) {
        if (dewsContent.length) {
          $(dewsContent).each(function (index, node) {
            if (!$(node).hasClass("disabled")) {
              var dewsControl = $(node).data('dews-control');
              if (dewsControl) {
                var dt = $.grep(menuDefault, function (v, i) {
                  var vlen = v.id.length;
                  var nlen = node.id.length;
                  return vlen >= nlen && v.id.substring(0, nlen) == node.id;
                });

                if (dt.length > 0) {
                  if ($(node).hasClass("dews-ui-dropdownlist")   || $(node).hasClass("dews-ui-numerictextbox") || $(node).hasClass("dews-ui-maskedtextbox") ||
                      $(node).hasClass("dews-ui-datepicker")     || $(node).hasClass("dews-ui-timepicker")     || $(node).hasClass("dews-ui-monthpicker") ||
                      $(node).hasClass("dews-ui-datetimepicker") || $(node).hasClass("dews-ui-zipcodepicker")  || $(node).hasClass("dews-ui-combobox")) {
                    dewsControl.value(dt[0].code);
                    if (typeof (dewsControl.text) == "function") {
                      dewsControl.text(dt[0].name);
                    }
                  }
                  else if (
                    $(node).hasClass("dews-ui-monthperiodpicker") ||
                    $(node).hasClass("dews-ui-weekperiodpicker")) {
                    var start = "", end = "";
                    for (var i = 0; i < dt.length; i++) {
                      if (i == 0){
                        end = dt[i].code;
                      }
                      else {
                        start = dt[i].code;
                      }
                    }
                    dewsControl.setPeriod(start, end);
                  }
                  else if ($(node).hasClass("dews-ui-periodpicker")) {
                    var start = "", end = "";
                    for (var i = 0; i < dt.length; i++) {
                      if (i == 0) {
                        end = dt[i].code;
                      }
                      else{
                        start = dt[i].code;
                      }
                    }
                    dewsControl.setStartDate(start);
                    dewsControl.setEndDate(end);
                  }
                  else if ($(node).hasClass("dews-ui-textbox")) {
                    dewsControl.text(dt[0].code);
                  }
                  else if ($(node).hasClass("dews-ui-codepicker")) {
                    var obj = {};
                    obj[dewsControl.options.codeField] = dt[0].code;
                    obj[dewsControl.options.textField] = dt[0].name;
                    dewsControl.setData(obj);
                  }
                  else if ($(node).hasClass("dews-ui-multicodepicker")) {
                    var arr = [];
                    for (var i = 0; i < dt.length; i++) {
                      var obj = {};
                      obj[dewsControl.options.codeField] = dt[i].code;
                      obj[dewsControl.options.textField] = dt[i].name;
                      arr.push(obj);
                    }
                    dewsControl.setData(arr);
                  }
                  else if ($(node).hasClass("dews-ui-checkbox")) {
                    var state = dt[0].code == 'false'? false : true;
                    dewsControl.check(state);
                  }
                }
              }
            }
          });
        }
      }
    },
    /*********************************************************************************************
      *  @desc   지금예정일
      *  @param terpay_cd     결제조건
      *  @param std_dt        기준일자
      *  @param calendar_yn   카렌다사용여부
      *  @return string
      *  @ex     module.api.getPaymentDate();
    *********************************************************************************************/
    getPaymentDate : function(terpay_cd, std_dt, calendar_yn){
      var resultData = null;
      dews.api.get(dews.url.getApiUrl("PU", "PuCommonService", "PuCommonGetPaymentDate"), {
        async : false,
        data  : {
          terpay_cd: terpay_cd,
          std_dt: std_dt,
          calendar_yn : calendar_yn
        }
      }).done(function (data) {
        if(data.length > 0){
          resultData = data;
        }
      }).fail(function (xhr, satus, error) {
        dews.error(error);
      });
      return resultData;
    },
    /*********************************************************************************************
      *  @desc   지급예정일
      *  @param terpay_cd     결제조건
      *  @param std_dt        기준일자
      *  @param calendar_yn   카렌다사용여부
      *  @return string
      *  @ex     module.api.getHldyPaymentDate();
    *********************************************************************************************/
    getHldyPaymentDate : function(terpay_cd, std_dt, calendar_yn){
      var resultData = null;
      dews.api.get(dews.url.getApiUrl("PU", "PuCommonService", "PuCommonGetHolidayPaymentDate"), {
        async : false,
        data  : {
          terpay_cd: terpay_cd,
          std_dt: std_dt,
          calendar_yn : calendar_yn
        }
      }).done(function (data) {
          resultData = data;
      }).fail(function (xhr, satus, error) {
        dews.error(error);
      });
      return resultData;
    },
    /*********************************************************************************************
      *  @desc   DirtyData에서 특정 컬럼 데이터의 유무를 체크해서 제거해주는 메소드
      *  @param gridDatas     결제조건
      *  @param fieldNm        기준일자
      *  @return Array
      *  @ex     module.api.dirtyDataRemove();
    *********************************************************************************************/
    dirtyDataRemove : function(gridDatas, fieldNm){
      var tmpList = [];
      let field_nm = fieldNm;
      if( null != gridDatas && field_nm){
        $.each(gridDatas, function(idx, items){
          if( null != items[field_nm] && undefined != items[field_nm] && ('0' != items[field_nm] || items[field_nm] > 0 ) ){
            tmpList.push(items);
          }
        });
      }else{
        console.log('필수값이 누락되어있습니다.');
        return null;
      }
      return tmpList;
    }
  }
  //-------------------------------------------End-------------------------------------------


  /*********************************************************************************************
  *  @desc  js파일 상속
  *  @param {Object} targetJS [필수] js 객체 변수
  *  @ex
  * ------------------------------------------------------------------------------------------*/
  module.extendJS = function(targetJS){
    $.each(Object.keys(targetJS), function(idx, key){
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
        겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName){
        if(keyArr.indexOf(kName) >= 0){
          console.error("js 상속중 동일한 메소드 명이 존재합니다 - ", (key + '.' + kName));
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  }

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  var scmJS;
  dews.ajax.script('~/view/js/MA/ma.scm.js', {
    once: true,
    async: false
  }).done(function() {
    scmJS = gerp.MA;
  });

  module.extendJS(scmJS);

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/PU/pu.js
