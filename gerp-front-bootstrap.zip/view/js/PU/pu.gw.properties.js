/*
 * @desc    PU 모듈 전자결재 properties
 * @date    2023.04.17
 * @path    /view/js/pu.gw.properties.js
 */
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'PU_GW_PROPERTIES';

  dews.ajax.script('~/view/js/HR/hr.gw.util.js', {
    once: true,
    async: false
  });

  /*
  * ● 그룹웨어 공통 설정, WF별 세부설정은 module.formId 에서 설정
  * gwServerUrl  : 전자결재 서버 URL (설정이 없다면 config/gw.properties-gw.server.url 로 설정)
  * url_type     : url타입 : 그룹웨어 결재구분 구분자 : "common" or "x"+drsCode (config/gw.properties - gw.approval.[url_type]].url)
  */
  module.gw = {
    package : {
      desc : "Package",
      url_type : "common"
    },
    10072 : {
      desc : "DEV테스트",
      gwServerUrl : "https://gw.comet.duzon.net/gw/outProcessEncLogOn.do", // 바꿔주면되고
      url_type : "common"
    }
  };

  /*
    * ● 메뉴 WF 별 세부설정
    *
    * contents_url        : 전자결재 양식 url
    * athz_rpts_table_nm  : ATHZ_RPTS_CD UPDATE 할 테이블ID
    * postProcess_url     : 후처리 서비스 url
    * gwWindow_close_event: 전자결재 창 close 시 이벤트
    */
  module.formId = {

    /***************** PU *****************/
    PUOORD00100_WF01 : {
      package : {
        DESC : "Package",
        PROVIDER : "bizbox",
        URL_TYPE : "common",
        CONTENTS_URL : "/api/PU/Puoord00100_GwContents_Service/puoord00100_GwContents_WF01",
        ATHZ_RPTS_TABLE_NM : "PU_PURORDER_MST",
        POST_PROCESS_URL : "/api/PU/PUOORD00100_SERVICE/puoord00100_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20057 : {
        DESC : "그린에코솔루션",
        PROVIDER : "external",
        URL_TYPE : "common",
        APPROVAL_URI : "ezApprGate.aspx?",
        SERVICE_NAME : "PUOORD00100_GW_SERVICE_x20057",
        COMPANY_ID : "GRE",
        GW_FORM_ID : "2023000003",
        DOC_ID : "PUOORD_"
      }
    },

    // 구매송장처리_WF03
    PUVIVE01300_WF03 : {
      package : {
        desc : "Package",
        contents_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_GwContents_WF01",
        athz_rpts_table_nm : "PU_PURREQ_MST",
        postProcess_url : "/api/PU/PUOPRQ00200_SERVICE/puoprq00200_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20057 : {
        DESC : "그린에코솔루션",
        PROVIDER : "external",
        URL_TYPE : "common",
        APPROVAL_URI : "ezApprGate.aspx?",
        SERVICE_NAME : "PUVIVE01300_GW_SERVICE_x20057",
        COMPANY_ID : "GRE",
        GW_FORM_ID : "2023000004",
        DOC_ID : "PUVIVE_"
      },
      20102 : {
        DESC : "아난티",
        PROVIDER : "external",
        URL_TYPE : "common",
        APPROVAL_URI : "/app/approval/dz/erp?",
        SERVICE_NAME : "Puvive01300_GwContents_Service_x20102",
        COMPANY_ID : "1000",
        GW_FORM_ID : "PU05",
        DOC_ID : "PUVIVE_"
      }
    },

    // 구매요청처리_WF02
    PUOPRQ00200_WF01 : {
      package : {
        DESC : "Package",
        PROVIDER : "bizbox",
        URL_TYPE : "common",
        CONTENTS_URL : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_GwContents_WF01",
        ATHZ_RPTS_TABLE_NM : "PU_PURORDER_MST",
        POST_PROCESS_URL : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_Gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20102 : {
        DESC : "아난티",
        PROVIDER : "external",
        URL_TYPE : "common",
        APPROVAL_URI : "/app/approval/dz/erp?",
        SERVICE_NAME : "Puoprq00200_GwContents_Service_x20102",
        COMPANY_ID : "1000",
        GW_FORM_ID : "PU01",
        DOC_ID : "PUOPRQ_"
      }
    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/PU/pu.gw.properties.js
