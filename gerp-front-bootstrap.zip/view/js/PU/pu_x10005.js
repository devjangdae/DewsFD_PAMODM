/*
 * @desc    PU 동서발전 모듈 공통 함수
 * @author  김준일(kji6649)
 * @date    2020.07.22
 * @path    /view/js/pu_x10005.js
 */
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'PU';  //모듈 코드
  const defaultFindStr = '*[class^=dews-ui-][id]'; //패널 find 용 기본 문자열

    // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  /**********************************************************************************************/

  //------------------------------------------Start------------------------------------------

  //API
  module.X10005 = {};
  module.X10005.com = {
    /* 
      패널 아이템 읽기전용 처리(boolean) 
      ex) panelItemReadonly(self, '.required', self.$puwewc00500_condition, isNotZeroRow);
    */
    panelItemReadonly: function (page, cssClass, panel, bEnable) {
      if ((cssClass || "") == "") {
        panel.find(defaultFindStr).each(function () { //패널내부 아이템 전체 검색
          var data = this;
          //버튼, 체크박스 예외처리
          if (page[data.id] && page[data.id].element && page[data.id].element.hasClass("dews-ui-button")){
            page[data.id].enable(!bEnable);
          }
          else if(page['$' + data.id] && page['$' + data.id].hasClass("dews-ui-checkbox")){
            page[data.id].disable(bEnable);
          }
          else {
            page[data.id].readonly(bEnable);
          }
        });
      }
      //cssClass 수동버전
      else {
        panel.find(defaultFindStr + cssClass).each(function () { //패널내부 아이템 중 특정 cssClass 를 가진 컴포넌트만 검색
          var data = this;
          page[data.id].readonly(bEnable);
        });
      }
    },
    /*********************************************************************************************
     *  @desc   공통코드(MA_CODEDTL)를 가져옵니다.
     *  @param  {String} module_cd     - [필수]모듈코드
     *  @param  {String} field_cd_pipe - [필수]필드코드(multi)
     *  @return {Array}  해당 모듈/필드의 데이터를 배열(파라미터 부족등의 오류시 빈 배열)
     *  @ex     var objCodeDtl_SD = scmJS.api.getCodeData('SD', 'C00010|C00020');
     * ------------------------------------------------------------------------------------------*/
    getCodeData: function(module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword, flag_cd_pipe) {
      var objCodeDtl = {};
      syscode_yn   = (syscode_yn   != undefined ? syscode_yn   : null);
      base_yn      = (base_yn      != undefined ? base_yn      : null);
      foreign_yn   = (foreign_yn   != undefined ? foreign_yn   : null);
      end_dt       = (end_dt       != undefined ? end_dt       : null);
      keyword      = (keyword      != undefined ? keyword      : null);
      flag_cd_pipe = (flag_cd_pipe != undefined ? flag_cd_pipe : null);
      if(!module_cd){
        console.error("scmJS - getCodeData 함수의 'module_cd' 파라미터가 부족합니다.");
        return [];
      } else if(!field_cd_pipe){
        console.error("scmJS - getCodeData 함수의 'field_cd_pipe' 파라미터가 부족합니다.");
        return [];
      } else{
        $.each(field_cd_pipe.split("|"), function (i, v) {
          if (v != null && v != "") {
            objCodeDtl[v] = [];
          }
        });
        dews.api.get(dews.url.getApiUrl("PU", "PuCommonService_X10005", "common_codeDtl_list_flag"), {
          async: false,
          data: {
            module_cd: module_cd, // 모듈
            field_cd_pipe: field_cd_pipe,   // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
            syscode_yn: syscode_yn,   // 시스템코드 유무(Y,N)
            base_yn: base_yn,   // 디폴트 코드구분(Y,N)
            foreign_yn: foreign_yn,   // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
            end_dt: end_dt,   // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
            keyword: keyword,    // 검색할 코드 또는 명
            flag_cd_pipe: flag_cd_pipe
          }
        }).done(function (data) {
          if (data.length > 0) {
            $.each(data, function (i, obj) {
              objCodeDtl[obj.FIELD_CD].push(obj);
              tmpCdField = obj.FIELD_CD;
            });
          } else {
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
        return objCodeDtl;
      }
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc                 공통 세팅데이터 조회
    *  @author               김준일 (kji6649)
    *  @ex                   puApi.getXmlData({P_XML_ID: "get_MA_PARTNERPU_INFO", P_PURORG_CD: "1000", P_PARTNER_CD: "2000001001"})
    * --------------------------------------------------------------------------------------------
    *  params                파라미터 오브젝트
        P_XML_ID             P_XML_ID (필수)
    * --------------------------------------------------------------------------------------------
    *  @return               List<Map<String, Object>>, Exception
    *  @수정
    * ------------------------------------------------------------------------------------------*/
    getXmlData: function(obj){
      var returnVr = null;
      if(obj && obj.P_XML_ID){
        dews.api.post(dews.url.getApiUrl("PU", "PuCommonService_X10005", "getXmlData"),{
          async : false,
          data : {
            params: JSON.stringify(obj)
          }
        }).done(function(data){
          returnVr = data;
        }).fail(function (xhr, status, error) {
          dews.error(error);
        });
      }
      return returnVr;
    },
    /*********************************************************************************************
     *  @desc   문서-첨부파일창을 오픈합니다.
     *          실제 저장되는 FILE_DC: 회사코드_[docu_no]
     *          실제 저장되는 FILE_ATCH_TXT(FILE_PATH.파일경로): /모듈/구분코드/
     *  @param  {String}  module_cd - [필수] 모듈코드(self.menu.module)
     *  @param  {String}  docu_no   - [필수] 문서번호
     *  @param  {String}  file_path - [필수] 저장경로(구분코드)
     *  @param  {Object}  options   - [옵션] 옵션값(title, download, upload, read)
     *  @return {Promise} 도움창에서 변경된 데이터 있을시 사용.
     *  @ex     puJS.X10005.com.openDocuFilePop(self.menu.module, self.menu.id, self.mstGrid.dataItem(e.row.index).SODOC_NO)
                .then(function(data) {
                  console.log(data);
                });
     * ------------------------------------------------------------------------------------------*/
    openDocuFilePop: function(module_cd, docu_no, file_path, options){
      if(module.com.isNull(module_cd) || module.com.isNull(docu_no) || module.com.isNull(file_path)){
        console.error("puJS_x10005 - openDocuFilePop 함수의 파라미터가 부족합니다.");
      } else{
        return module.X10005.com.openFilePop(module_cd, docu_no, file_path, options);
      }
    },
    /*********************************************************************************************
     *  @desc   첨부파일창을 오픈합니다. #고유문서번호가 있는 경우, openDocuFilePop메소드 사용
     *          실제 저장되는 FILE_ATCH_TXT(FILE_PATH.파일경로): /모듈/구분코드/
     *  @param  {String}  module_cd - [필수] 모듈코드(self.menu.module)
     *  @param  {String}  file_dc   - [필수] 파일내역(PK) - 회사코드 제외하고 넘길것(실제 저장되는 FILE_DC: 회사코드_[file_dc])
     *  @param  {String}  file_path - [필수] 저장경로(구분코드)
     *  @param  {Object}  options   - [옵션] 옵션값(title, download, upload, read)
     *  @return {Promise} 도움창에서 변경된 데이터 있을시 사용.
     *  @ex     puJS.X10005.com.openFilePop(self.menu.module, self.menu.id, '')
                .then(function(data) {
                  console.log(data);
                });
     * ------------------------------------------------------------------------------------------*/
    openFilePop: function(module_cd, file_dc, file_path, options){
      return new Promise(function(resolve){
        if(module.com.isNull(module_cd) || module.com.isNull(file_dc) || module.com.isNull(file_path)){
          console.error("puJS_x10005 - openFilePop 함수의 파라미터가 부족합니다.");
          resolve(false);
        } else{
          // 옵션값 세팅
          options = options || {};
          options.upload   = options.hasOwnProperty('upload')   ? options.upload   : true; // upload, delete 버튼 true/false
          options.download = options.hasOwnProperty('download') ? options.download : true; // download 버튼 true/false
          options.read     = options.hasOwnProperty('read')     ? options.read     : true; // read 자동조회 true/false
          options.title    = options.hasOwnProperty('title')    ? options.title    : '첨부파일'; // 타이틀 변경

          // 다이얼로그 세팅
          var dialog = dews.ui.dialog("H_PU_FILE_C", {
            url : "/codehelp/PU/H_PU_FILE_C",
            width : 680,
            height : 260,
            buttons : "none",
            ok: function(data){
              resolve(data);
            }
          });
          dialog.setInitData({
            file_dc   : file_dc,
            file_path : '/' + module_cd + '/' + file_path,
            options   : options
          });
          dialog.open();
        }
      });
    },
	
     /*********************************************************************************************
     *  @desc   추진계획 기준에따른 팝업
     *  @param  {Object} mstData       - [필수]Grid Select Row
     *  @return dialog 
     *  @ex     var objCodeDtl_SD = scmJS.api.attchPopupOption(self.mstData);
     * ------------------------------------------------------------------------------------------*/
    attchPopupOption :function (mstData){
      var dialog = dews.ui.dialog('PUUEWP_X10005_FILE', {
      url: '/view/CX/PUUEWP_X10005_FILE',
      title: '[' + mstData.PURPLAN_NO + '] ' + '첨부파일',
      width: 510,
      height: 290,
      initData: {
        purplan_no: mstData.PURPLAN_NO || ''
      },
      ok: function (rtnData) {
        dews.api.post(dews.url.getApiUrl('PU', 'PUUEWP_COMMON_X10005_SERVICE', 'puuewp_file_save'), {
        async: false,
        data: {
          purplan_no: mstData.PURPLAN_NO,
          add_file: JSON.stringify(rtnData.Added),
          delete_file: JSON.stringify(rtnData.Deleted)
        }
        }).done(function (data) {
        dews.ui.snackbar.ok("저장 되었습니다.");
        }).fail(function (xhr, status, error) {
        dews.error(error);
        });
      }
      });
      var docStAttcArr = ['4', '6', '7', '8', '9', 'E'];
      dialog.initData.delet = mstData.PURDOC_ST == "1" ? true : false;
      dialog.initData.upload = mstData.PURDOC_ST == "1" ? true : false;
      return dialog;
    },
	
	
     /*********************************************************************************************
     *  @desc   H_PU_SEL_COND_INFO_X10005 도움창에서 넘어온 데이터를 컨트롤러에 설정해준다.
     *  @param  {String} type       - [필수]컨트롤러의 타입 (코드피커 : C, 드랍다운리스트 : D, 텍스트박스: T)
     *  @param  {String} targetFrom - [필수]조회조건중 from에 해당하는 컨트롤러의 id
     *  @param  {String} targetTo   - [필수]조회조건중 to에 해당하는 컨트롤러의 id 
     *  @param  {String} data       - [필수]도움창에 설정되어있는 데이터
     *  @return null 
     *  @ex     var objCodeDtl_SD = scmJS.api.setCodepickerData(self.from, self.to, data);
     * ------------------------------------------------------------------------------------------*/
    setCodepickerData: function(type, targetFrom, targetTo, data) {
      if(type == "C") {
        var tmp = {};
        if(data.applyDatas != '' && data.applyDatas != undefined && data.applyDatas != null ) {
          tmp[targetFrom.options.codeField] = data.applyDatas.split("|")[0];
          tmp[targetFrom.options.textField] = data.applyDatas.split("|")[0];
          targetFrom.setData(tmp,false);
          tmp[targetFrom.options.codeField] = '';
          tmp[targetFrom.options.textField] = '';
          targetTo.setData(tmp,false);
        }
        else {
          tmp[targetFrom.options.codeField] = data.applyRangeFrom;
          tmp[targetFrom.options.textField] = data.applyRangeFrom;
          targetFrom.setData(tmp,false);
          tmp[targetFrom.options.codeField] = data.applyRangeTo;
          tmp[targetFrom.options.textField] = data.applyRangeTo;
          targetTo.setData(tmp,false);
        }
      }
      else if(type == "D"){
        if(data.applyDatas != '' && data.applyDatas != undefined && data.applyDatas != null ) {
          targetFrom.value(data.applyDatas.split("|")[0]);
          targetTo.value(null)
        }
        else {
          targetFrom.value(data.applyRangeFrom);
          targetTo.value(data.applyRangeTo);
        }
      }
      else if(type == "T"){
        if(data.applyDatas != '' && data.applyDatas != undefined && data.applyDatas != null ) {
          targetFrom.text(data.applyDatas.split("|")[0]);
          targetTo.text('');
        }
        else {
          targetFrom.text(data.applyRangeFrom);
          targetTo.text(data.applyRangeTo);
        }
      }
      return data;
    },
    changeButtonText : function (target, obj) {
      var cnt = 0;
      if(obj.applyDatas != '' && obj.applyDatas != undefined && obj.applyDatas != '') cnt += (obj.applyDatas.split("|").length-1);
      if(obj.applyNotDatas != '' && obj.applyNotDatas != undefined && obj.applyNotDatas != '') cnt += (obj.applyNotDatas.split("|").length-1);
      if((obj.applyRangeFrom != '' && obj.applyRangeFrom != undefined && obj.applyRangeFrom != '') || (obj.applyRangeTo != '' && obj.applyRangeTo != undefined && obj.applyRangeTo != '')) cnt++;
      if((obj.applyNotRangeFrom != '' && obj.applyNotRangeFrom != undefined && obj.applyNotRangeFrom != '') || (obj.applyNotRangeTo != '' && obj.applyNotRangeTo != undefined && obj.applyNotRangeTo != '')) cnt++;
    
      if(cnt > 1) {
        if(target.context) {
          target.context.innerText = "▶";
        }
        else {
          target.innerText = "▶";
        }
      } else {
        if(target.context) {
          target.context.innerText = "▷";
        }
        else {
          target.innerText = "▷";
        }
      }
    },
    setSearchOpt: function(self, btn){
      var $btn = btn.element;
      var $li = $btn.parents('li').eq(0); // 해당 버튼 복합컨트롤의 li
      var label_text = $li.find('label').eq(0).text(); // 라벨 텍스트(버튼 클릭시 조회조건 타이틀)
      var from_id = $li.find('*input[class^=dews-ui-]').eq(0).attr('id') || $li.find('*select[class^=dews-ui-]').eq(0).attr('id');
      var $from = self['$'+from_id];
      var from = self[from_id];
      var to_id = $li.find('*input[class^=dews-ui-]').eq(1).attr('id') || $li.find('*select[class^=dews-ui-]').eq(1).attr('id');
      var $to = self['$'+to_id];
      var to = self[to_id];
      var type = 'C';
      if($from.hasClass('dews-ui-codepicker')){
        type = 'C';
      } else if($from.hasClass('dews-ui-dropdownlist')){
        type = 'D';
      } else if($from.hasClass('dews-ui-textbox')){
        type = 'T';
      }

      // 버튼 조회조건 저장값.
      btn.search_opt = {
        applyDatas: '',
        applyNotDatas: '',
        applyRangeFrom: '',
        applyRangeTo: '',
        applyNotRangeFrom: '',
        applyNotRangeTo: ''
      };
      
      // 버튼 클릭시 이벤트: 조건 도움창 띄움 / 값 적용시 변경 / 버튼 변경
      btn.on('click', function(e){
        var dialog = dews.ui.dialog("H_PU_SEL_COND_INFO_X10005", {
          url: "~/codehelp/CX/H_PU_SEL_COND_INFO_X10005",
          title: label_text + ": 조건-선택",
          initData: btn.search_opt,
          ok: function (data, e) {
            btn.search_opt = module.X10005.com.setCodepickerData(type, from, to, data);
            module.X10005.com.changeButtonText($btn, data);
          }
        });
        dialog.open();
      });

      // 코드피커/드롭다운/텍스트박스 타입에 따른 값 변경시 이벤트 세팅.
      switch(type){
        case 'C':{
          from.on('setData', function(e, pickerData){
            var codefield = $(this).data('dews-code-field');
            if ((to.code() || '') != '') {
              btn.search_opt.applyRangeFrom = pickerData[codefield];
            }
            else {
              if (btn.search_opt.hasOwnProperty("applyDatas")) {
                tmp = btn.search_opt.applyDatas.split("|");
                if (pickerData[codefield] === '') {
                  tmp.shift();
                } else {
                  tmp[0] = pickerData[codefield];
                }
                btn.search_opt.applyDatas = tmp.join("|");
              }
              else {
                btn.search_opt.applyDatas = pickerData[codefield] + "|";
              }
            }
            btn.search_opt = module.X10005.com.setCodepickerData(type, from, to, btn.search_opt);
            module.X10005.com.changeButtonText($btn, btn.search_opt);
            if (!e.code) {
              e.preventDefault();
            }
          });

          to.on('setData', function(e, pickerData){
            var codefield = $(this).data('dews-code-field');
            if ((from.code() || '') != '') {
              if (pickerData[codefield] == '') {
                btn.search_opt.applyDatas = from.code() + "|";
                btn.search_opt.applyRangeFrom = pickerData[codefield];
              }
              else {
                btn.search_opt.applyRangeFrom = from.code();
                btn.search_opt.applyDatas = '';
              }
            }
            btn.search_opt.applyRangeTo = pickerData[codefield];
            module.X10005.com.changeButtonText($btn, btn.search_opt);
          });
          break;
        }
        case 'D':{
          from.on('change', function(e){
            if ((to.value() || '') != '') {
              btn.search_opt.applyRangeFrom = e.sender._old;
            }
            else {
              if (btn.search_opt.hasOwnProperty("applyDatas")) {
                tmp = btn.search_opt.applyDatas.split("|");
                if (e.sender._old === '') {
                  tmp.shift();
                } else {
                  tmp[0] = e.sender._old;
                }
                btn.search_opt.applyDatas = tmp.join("|");
              }
              else {
                btn.search_opt.applyDatas = e.sender._old + "|";
              }
            }
            btn.search_opt = module.X10005.com.setCodepickerData(type, from, to, btn.search_opt);
            module.X10005.com.changeButtonText($btn, btn.search_opt);
            if (!e.code) {
              e.preventDefault();
            }
          });

          to.on('change', function(e){
            if ((from.value() || '') != '') {
              if (e.sender._old == '') {
                btn.search_opt.applyDatas = from.value() + "|";
                btn.search_opt.applyRangeFrom = e.sender._old;
              }
              else {
                btn.search_opt.applyRangeFrom = from.value();
                btn.search_opt.applyDatas = '';
              }
            }
            btn.search_opt.applyRangeTo = e.sender._old;
            module.X10005.com.changeButtonText($btn, btn.search_opt);
          });
          break;
        }
        case 'T':{
          from.on('change', function (e) {
            if ((to.text() || '') != '') {
              btn.search_opt.applyRangeFrom = from.text(); 
            }
            else {
              if (btn.search_opt.hasOwnProperty("applyDatas")) {
                tmp = btn.search_opt.applyDatas.split("|");
                if ((from.text() || '') == '') {
                  tmp.shift();
                } else {
                  tmp[0] = from.text();
                }
                btn.search_opt.applyDatas = tmp.join("|");
              }
              else {
                btn.search_opt.applyDatas = from.text() + "|";
              }
            }
            btn.search_opt = puJS.X10005.com.setCodepickerData("T", from, to, btn.search_opt);
            module.X10005.com.changeButtonText($btn, btn.search_opt);
            if (!e.originalEvent.target.value) {
              e.preventDefault();
            }
          });

          to.on('change', function (e) {
            if ((from.text() || '') != '') {
              if ((to.text() || '') == '') {
                btn.search_opt.applyDatas = from.text() + "|";
                btn.search_opt.applyRangeFrom = '';
              }
              else {
                btn.search_opt.applyRangeFrom = from.text();
                btn.search_opt.applyDatas = '';
              }
            }
            btn.search_opt.applyRangeTo = to.text();
            module.X10005.com.changeButtonText($btn, btn.search_opt);
          });

          break;
        }
      }
    },
    getSearchOpt: function(btn){
      return btn.search_opt || {};
    }
  };
  module.X10005.api = {
    /* 구매문서유형 조회 메소드
       발주유형과 구매문서유형을 동일하게 처리한다.
     */
    list_purdoc_tp: function (p_flag_cd_pipe) {
      var v = null;
      dews.api.get(dews.url.getApiUrl("PU", "PuCommonService_X10005", 'list_purdoc_tp'), {
        async: false,
        data: {
          flag_cd_pipe: p_flag_cd_pipe    // 검색할 구분코드(FLAG)
        }
      }).done(function (data) {
        if (data.length > 0) {
          v = data;
        }
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });
      return v;
    },
    list_contMthdCd: function(){
      var v = null;
      // 계약방법
      dews.api.get(dews.url.getApiUrl('PU', 'PuCommonService_X10005', 'list_contMthdCd'), {
        async : false,
        data : {}
      }).done(function(data){
        v = data;
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });
      return v;
    }
  };
  //-------------------------------------------End-------------------------------------------


  /*********************************************************************************************
  *  @desc  js파일 상속
  *  @param {Object} targetJS [필수] js 객체 변수
  *  @ex
  * ------------------------------------------------------------------------------------------*/
  module.extendJS = function(targetJS){
    $.each(Object.keys(targetJS), function(idx, key){
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
        겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName){
        if(keyArr.indexOf(kName) >= 0){
          console.error("js 상속중 동일한 메소드 명이 존재합니다 - ", (key + '.' + kName));
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  }

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // pu.js 상속
  var puJS;
  dews.ajax.script('~/view/js/PU/pu.js', {
    once: true,
    async: false
  }).done(function() {
    puJS = gerp.PU;
  });
  module.extendJS(puJS);

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/PU/pu_x10005.js