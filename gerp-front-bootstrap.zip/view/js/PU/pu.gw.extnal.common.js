/*
 * @desc    PU 모듈 GroupWare 공통
 * @date    2023.04.17
 * @path    /view/js/PU/pu.gw.common.js
 */

(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'PU_GW';

  dews.ajax.script('~/view/js/HR/hr.gw.util.js', {
    once: true,
    async: false
  });

  let ma_cm_js;
  dews.ajax.script('~/view/js/MA/ma.cm.js', {
    once: true,
    async: false
  }).done(function () {
    ma_cm_js = gerp.MA;
  });

  module.gw = {
    GroupWareStore : function (dewself) {
      var store = new Map();
      var gw_properties = {};
      // 그룹웨어 설정여부
      let gwConfigSettings = {
        MA00037 : ma_cm_js.CODE.getMaCtrlConfig("MA", "MA00037"),
        PU00007 : ma_cm_js.CODE.getMaCtrlConfig("PU", "PU00007"),
        PU00011 : ma_cm_js.CODE.getMaCtrlConfig("PU", "PU00011")
      };

      // GroupWare Properties 가져오기
      dews.ajax.script('~/view/js/PU/pu.gw.properties.js', {
        once: true,
        async: false
      }).done(function () {
        if(gerp.PU_GW_PROPERTIES){
          gw_properties = gerp.PU_GW_PROPERTIES.gw;
          formId_properties = gerp.PU_GW_PROPERTIES.formId;
        }
      });

      var api = {
        public : {
          get : function(menuid) {
            return store.get(menuid);
          },
          /**
           * 전자결재 설정여부 체크
           * @param {string} ctrl_cd 회사환경설정등록의 통제코드
           * @param {object} param 회사환경설정등록 외 추가적인 설정확인이 필요할 때 사용할 추가파라미터
           * @returns {bool} 전자결재 사용설정 여부 return
           */
          isScmApprovalSetting : function(ctrl_cd, param){
            let result = false;
            if(gwConfigSettings["MA00037"] != "0" && gwConfigSettings[ctrl_cd] == "Y"){
              result = true;
            }

            return result;
          },
          getName : function(){
            return "PU_GW";
          }
        },
        private : {
          setup : function(formInfo){
            // var property = gw_properties[dewself.mainEnv.drsCode] || gw_properties["package"];
            var property = formId_properties[formInfo.FORM_ID] || formId_properties.package;

            /* GW구분
             * 0:사용안함  1:bizbox  2:기타  3:전자결재
            */
            if(gwConfigSettings["MA00037"] == "2") {
              // formInfo : FORM_ID, GW_FORM_ID, GW_PROC_CD
              property = $.extend({}, property, formInfo);
            }

            /* formId별 설정 */
            if(formId_properties[property.FORM_ID]){
              var formId_property = formId_properties[property.FORM_ID][dewself.mainEnv.drsCode] || formId_properties[property.FORM_ID].package;
              if(formId_property){
                property = $.extend({}, property, formId_property);
                if(!property.gwServerUrl){
                  property.gwServerUrl =  gerp.CM.EltrAthzUtil.getApprovalUrl(property.URL_TYPE);
                }
                store.set(formInfo.FORM_ID, this.extendsAttr(property));
              }
            }
          },
          extendsAttr : function(property) {
            return $.extend({}, property, {
              getUrl : function(athz_rpts_cd) {
                if(property.PROVIDER == "external") {
                  if(dewself.mainEnv.drsCode == "20057"){
                    return dewself.mainEnv.groupware.url;
                  }
                  else if(dewself.mainEnv.drsCode == "20102"){
                    return "http://gw.ananti.kr/common/sso?companyId=10&gosso=";
                  }
                  else{
                    return property.CONTENTS_URL;
                  }
                }
              return gerp.CM.EltrAthzUtil.getApprovalUrl(property.url_type);
            },
            approval : function(data) {
              var that = this;

              if(!property.GW_FORM_ID){
                dews.ui.loading.hide();
                dews.ui.snackbar.error(dews.localize.get("전자결재양식등록에 등록되지 않은 서식 ID입니다.", '', '', ''));
                return false;
              }

              dews.ui.loading.show({
                text : "결재신청 진행중입니다."
              });
              return dews.api.post(dews.url.getApiUrl("PU", property.SERVICE_NAME, "approval"), {
                async: true,
                data: {
                  form_id : property.GW_FORM_ID,
                  company_cd : data.company_cd,
                  key_no : data.key_no
                }
              }).fail(function (xhr, status, error) {
                dews.error(error);
              }).always(function(){
                dews.ui.loading.hide();
              }).then(function(res) {
                var response = { error : "", success : true};
                if(res.length > 0 && res.error_message) {
                  response.error = res.error_message;
                  response.success = false;
                  dews.error(response.error)
                } else {
                  response.athz_rpts_cd = res.data[0].ATHZ_RPTS_CD;
                  response.loginId = res.aes_key;
                  dews.ui.snackbar.ok("결재신청 되었습니다.");
                }
                return response;
              }).done(function(res){
                if (res.success) {
                  that.openView({
                    mode: "W",
                    docId : property.DOC_ID,
                    athz_rpts_cd: res.athz_rpts_cd,
                    loginId: res.loginId,
                    company_cd : data.company_cd
                  });
                }
              });
            },
            openView : function(data){
              var url = this.getUrl(data.athz_rpts_cd);
              if(property.PROVIDER == "external") {
                if(dewself.mainEnv.drsCode == "20102"){
                  var title = data.docId;

                  dews.api.get(dews.url.getApiUrl("PU", "Puoprq00200_GwContents_Service_x20102", "getAes_encode"), {
                    async: false,
                  }).done(function (aes_encode) {
                    url += aes_encode;
                  })

                  if (data.mode == "W") {
                    url = url +"&url=" + encodeURIComponent(this.APPROVAL_URI + api.private.toQueryString({
                      formCode: this.GW_FORM_ID,
                      dataId: data.athz_rpts_cd,
                      companyId: data.company_cd
                    }));
                    title += "APPROVAL";
                  }

                  api.private.createEltrAthz_external(url, title, "width=981, height=769", close = function () {
                    dews.ui.mainbuttons.search.click();
                  });
                }
                else{
                  var title = data.docId;
                  url = url + this.APPROVAL_URI + api.private.toQueryString({
                    COMPANYID : this.COMPANY_ID,
                    USERID : dewself.user.userid,
                    FORMID : this.GW_FORM_ID,
                    KEY : data.athz_rpts_cd
                  });
                  title += "APPROVAL";
                  api.private.createEltrAthz_external(url, title, "width=981, height=769", close = function () {
                    if(title == "PUVIVE_") {dews.ui.mainbuttons.search.click();}
                  });
                }
              }
            },
          });
        },
        createEltrAthz_external : function(url, title, size, callback) {
          var eltrAthzPopup;

          // 기존 loading 결제창 제거("전자결재 진행 중입니다." 라는 메세지로 보이도록)
          if(self.$('.dews-ui-loading').length > 0){
            dews.ui.loading.hide();
          }

          // loading show
          setTimeout(function () {
            dews.ui.loading.show({
              text: '전자결재 진행 중입니다.'
            })
          });

          eltrAthzPopup = window.open(url, title, size);

          var popupTick = setInterval(function() {
            if (eltrAthzPopup.closed) {
              clearInterval(popupTick);
              dews.ui.loading.hide();
              if(callback && $.isFunction(callback)){
                callback();
              }
            }
          }, 500);

          return eltrAthzPopup;
        },
        toQueryString : function(obj) {
          return Object.keys(obj).map(function(val) { return val+"="+obj[val]; }).join("&");
        }
      }
    }
      // 전자결재양식등록에 있는 해당 메뉴 서식ID 리스트
      var formInfoList = null;
      dews.api.get(dews.url.getApiUrl("PU", "COC_CommonGwService", "getListFormId"), {
        async: false,
        data: {
          menuId : dewself.menu.id
        }
      }).done(function (data){
        formInfoList = data;
      });

      // 전자결재 설정 setup
      if(formInfoList != null){
        $.each(formInfoList, function(idx, item){
          api.private.setup(item);
        });
      }

      return api.public;
    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/PU/pu.gw.extnal.common.js
