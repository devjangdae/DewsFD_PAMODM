/* HR 모듈 공통 함수
 * /view/js/hr.common.js
 * 2018-10-24 성승익 : 기존 hr.codeDtl.js, hr.getCodeData와 hr.common.js 통합작업.
 * 2018-11-08 성승익 : getCodebaseMstData, getCodebaseDtlData, getConfigMstData, getConfigDtlData 작성.
 * 2019-12-12 성승익 : Object.assign polyfill 추가.
 * 2020-05-25 문성훈 : Object.Array.includes() polyfill added.
 * 2020-09-15 문성훈 : 작성요령 getDescription API 호출 func 추가
 * 2020-09-16 박경서 : 작성요령 사용 관련 func 추가 (getWrtTip, setWrtTip)
 * 2020-10-23 박경서 : 메일알람등록 getMailAlarmList API 호출 func 추가
 * 2020-11-17 문성훈 : Object.String.replaceAll() 존재하지 않을 때 대응코드 추가(polyfill)
 * 2021-03-31 박경서 : 파일명다국어구분처리 (언어가 ko가 아니면 파일명 뒤에 _EN 을 붙인다.)
 * 2021-06-23 박경서 : 메일알람등록 담당자발신로직 추가 관련 arguments 로직 처리
 * 2022-01-27 최인효 : 채용) 모집공고, 모집부문 default값 셋팅 함수 추가 - setRecruitData()
 * 2022-02-22 최인효 : 출장) 출장 관련 메뉴 공통사용 JS 추가
 * 2023-06-05 임동주 : 근태) HR_CDAUTH_INFO 테이블 조회를 위한 JS추가
 * 2023-06-15 박형섭 : 평가) 성과관리메뉴 공통사용 함수 추가
 */

// Polyfill 정의구간
(function () {
  // Object.assign
  if (typeof Object.assign != 'function') {
    // Must be writable: true, enumerable: false, configurable: true
    Object.defineProperty(Object, "assign", {
      value: function assign(target, varArgs) { // .length of function is 2
        'use strict';
        if (target == null) { // TypeError if undefined or null
          throw new TypeError('Cannot convert undefined or null to object');
        }

        var to = Object(target);

        for (var index = 1; index < arguments.length; index++) {
          var nextSource = arguments[index];

          if (nextSource != null) { // Skip over if undefined or null
            for (var nextKey in nextSource) {
              // Avoid bugs when hasOwnProperty is shadowed
              if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
                to[nextKey] = nextSource[nextKey];
              }
            }
          }
        }
        return to;
      },
      writable: true,
      configurable: true
    });
  }
  if (typeof Math.trunc != 'function') {
    Math.trunc = Math.trunc || function (x) {
      if (isNaN(x)) {
        return NaN;
      }
      if (x > 0) {
        return Math.floor(x);
      }
      return Math.ceil(x);
    };
  }
  //2020-05-25 added
  if (!Array.prototype.includes) {
    Object.defineProperty(Array.prototype, 'includes', {
      value: function (searchElement, fromIndex) {

        if (this == null) {
          throw new TypeError('"this" is null or not defined');
        }

        // 1. Let O be ? ToObject(this value).
        var o = Object(this);

        // 2. Let len be ? ToLength(? Get(O, "length")).
        var len = o.length >>> 0;

        // 3. If len is 0, return false.
        if (len === 0) {
          return false;
        }

        // 4. Let n be ? ToInteger(fromIndex).
        //    (If fromIndex is undefined, this step produces the value 0.)
        var n = fromIndex | 0;

        // 5. If n ≥ 0, then
        //  a. Let k be n.
        // 6. Else n < 0,
        //  a. Let k be len + n.
        //  b. If k < 0, let k be 0.
        var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

        function sameValueZero(x, y) {
          return x === y || (typeof x === 'number' && typeof y === 'number' && isNaN(x) && isNaN(y));
        }

        // 7. Repeat, while k < len
        while (k < len) {
          // a. Let elementK be the result of ? Get(O, ! ToString(k)).
          // b. If SameValueZero(searchElement, elementK) is true, return true.
          if (sameValueZero(o[k], searchElement)) {
            return true;
          }
          // c. Increase k by 1.
          k++;
        }

        // 8. Return false
        return false;
      }
    });
  }

  // String.prototype.repeat() polyfill
  if (!String.prototype.repeat) {
    String.prototype.repeat = function (count) {
      'use strict';
      if (this == null) {
        throw new TypeError('can\'t convert ' + this + ' to object');
      }
      var str = '' + this;
      count = +count;
      if (count != count) {
        count = 0;
      }
      if (count < 0) {
        throw new RangeError('repeat count must be non-negative');
      }
      if (count == Infinity) {
        throw new RangeError('repeat count must be less than infinity');
      }
      count = Math.floor(count);
      if (str.length == 0 || count == 0) {
        return '';
      }
      // Ensuring count is a 31-bit integer allows us to heavily optimize the
      // main part. But anyway, most current (August 2014) browsers can't handle
      // strings 1 << 28 chars or longer, so:
      if (str.length * count >= 1 << 28) {
        throw new RangeError('repeat count must not overflow maximum string size');
      }
      var maxCount = str.length * count;
      count = Math.floor(Math.log(count) / Math.log(2));
      while (count) {
        str += str;
        count--;
      }
      str += str.substring(0, maxCount - str.length);
      return str;
    }
  }

  //String.prototype.replaceAll() polyfill
  if (!String.prototype.replaceAll) {
    String.prototype.replaceAll = function (reg, rplc) {
      'use strict';

      if (this == null) {
        throw new TypeError('can\'t convert ' + this + ' to object');
      }
      let str = this;
      if (str === "" || str == null || str == undefined)
        return str || "";

      while (true) {
        if (str.indexOf(reg) > -1) {
          str = str.replace(reg, rplc);
        } else {
          break;
        }

      }
      return str || "";
    }
  }
})();
// hr.common.js start
(function (dews, derp, $) {
  var module = {};
  var moduleCode = "HR";
  var newModule = {};
  var addSentence = "_A";
  var version = "1.0.220607.02";

  console.debug("hr.common.js", dews.string.format("[ LOAD START :: version={0} ]", version));

  /* START-- hr.common.js */

  // 동적 컬럼 생성
  module.ComponentUtil = {
    getInstance: function (dewself) {
      return {
        makeComponent: function (managedData) {
          var self = this;
          let companyCd = dewself.user.companyCode;
          $.each(managedData, function (i, data) {
            if (dewself.hasOwnProperty('std_' + data.MCLS_CD) === false) {
              let panelId;
              switch (data.TAB_FG) {
                case '1':
                  panelId = 'BasicInfo1FormPanel';
                  break;
                case '2':
                  panelId = 'BasicInfo2FormPanel';
                  break;
                case '3':
                  panelId = 'PayBaseFormPanel';
                  break;
                case '4':
                  panelId = 'PersonalInfoFormPanel';
                  break;
                case '5':
                  panelId = 'EtcInfoFormPanel';
                  break;
                default:
                  break;
              }
              let $li = $('<li></li>');
              let $label = $('<label>' + data.MCLS_NM + '</label>');
              let $span = $('<span></span>');
              // let $target = dewself.$content.find('#BasicInfo1FormPanel.dews-ui-form-panel>.dews-form-panel-form>ul');
              let $target = dewself.$content.find('#' + panelId + '.dews-ui-form-panel>.dews-form-panel-form>ul');
              let $component = self.makeComponentTag(data);

              $li.append($label);
              $li.append('\n');
              $li.append($span);
              $span.append($component);
              $target.append($li);
              dewself['std_' + data.MCLS_CD] = self.initComponent($component);
              dewself['$std_' + data.MCLS_CD] = $component;

              if (data.MCLS_TP === '8') {
                var ds = [{ MNGD_DTL_CD: '', MNGD_NM: '' }];
                $.each(data.items, function (index, d) {
                  if (d.DTL_APLY_RNG_FG === '2') { // '기준정보항목등록' 메뉴의 '기준정보항목내역등록'그리드의 '적용범위'가 '2.선택회사'이면
                    if(d.DTL_APLY_COMPANY_DC != null && d.DTL_APLY_COMPANY_DC != undefined) { // '기준정보항목등록' 메뉴의 '기준정보항목내역등록'그리드의 '적용회사'의 '회사코드'들이 null이 아니면
                      applyCompany = d.DTL_APLY_COMPANY_DC.replace(/ /gi, '').split(',');
                      isExist = applyCompany.indexOf(companyCd); // 현재 로그인한 회사가 있으면
                    }else {
                      isExist = -1;
                    }

                    if (isExist >= 0) { // 없으면 -1, 있으면 0 이상
                      ds.push({ MNGD_DTL_CD: d.MNGD_DTL_CD, MNGD_NM: d.MNGD_NM });
                    }
                  } else { // '기준정보항목등록' 메뉴의 '기준정보항목내역등록'그리드의 '적용범위'가 '1.전체회사'이면
                    ds.push({ MNGD_DTL_CD: d.MNGD_DTL_CD, MNGD_NM: d.MNGD_NM });
                  }
                });

                dewself['std_' + data.MCLS_CD].dataSource.data(ds);
                dewself['std_' + data.MCLS_CD].value(data.BASE_DC);
              }
            }
          });
        },
        initComponent: function (component) {
          'use strict';
          var dewsControl;
          var classes = component.prop('class').split(/\s+/);
          $.each(classes, function (idx, cls) {
            var componentType = 'dews.ui.formpanel';
            if (cls.indexOf('dews-ui-form-') > -1) {
              componentType = 'dews.ui.formpanel';
              dewsControl = eval(componentType + '(component)');
              return false;
            } else if (cls.indexOf('dews-ui-') > -1) {
              componentType = cls.replace(/-/g, '.');
              dewsControl = eval(componentType + '(component)');
              return false;
            }
          });
          return dewsControl;
        },
        makeComponentTag: function (data) {
          const FINAL = {
            'COMMON': '0',
            'DATE': '1',
            'AMT': '2',
            'QTY': '3',
            'RATE': '4',
            'PERIOD': '5',
            'EXRATE': '6',
            'NONE': '7',
            'DROPDOWN': '8',
            'NUMBER': '9',
          };
          let type1 = data.MCLS_TP;
          let type2 = data.TYPE_FG.substr(0, 2);
          let type3 = data.TYPE_FG.substr(0, 3);
          let $component;

          if (type1 === FINAL.DROPDOWN) {
            $component = $('<select class="dews-ui-dropdownlist mng-data" data-dews-value-field="MNGD_DTL_CD" data-dews-text-field="MNGD_NM"></select>');
          } else {
            let length = 0;
            switch (type2) {
              case 'CD':
                $component = $('<input class="dews-ui-codepicker mng-data" type="text" data-target="MNGD_CD" data-target-text="MNGD_NM">');
                break;
              case 'FG':
              case 'NM':
              case 'DC':
              case 'NO':
                length = data.TYPE_FG.slice(2);
                $component = $('<input type="text" class="dews-ui-textbox mng-data" data-target="MNGD_NM" maxlength=' + length + '>');
                break;
              case 'DT':
                $component = $('<input type="text" class="dews-ui-datepicker mng-data">');
                break;
              case 'AM':
              case 'CN':
              case 'QT':
              case 'UM':
                length = data.TYPE_FG.slice(4);
                $component = $('<input type="text" class="dews-ui-numerictextbox mng-data" data-target="MNGD_VN" maxlength="19">');
                break;
              case 'RT':
                $component = $('<input type="text" class="dews-ui-numerictextbox mng-data" data-target="MNGD_VN" data-dews-format="#,##0.00" maxlength="19">');
                break;
              default:
                if (type3 === 'CNT') {
                  length = data.TYPE_FG.slice(5);
                  $component = $('<input type="text" class="dews-ui-numerictextbox mng-data" data-target="MNGD_VN" data-dews-format="#,##0.00" maxlength=' + length + '>');
                } else {
                  $component = $(dews.localize.get('<span>허용되지 않은 입력타입</span>', 'D0002719'));
                }
            }
          }

          if ($component) {
            $component.attr('id', 'std_' + data.MCLS_CD);
            $component.attr('data-custom-bind-key', data.MCLS_CD);
            $component.attr('data-custom-bind-typefg', data.TYPE_FG);
            $component.attr('data-custom-bind-column', 'MNG_DC');
            $component.attr('data-custom-bind-table', 'HR_EMP_SDTL');
            if (data.MNDR_YN === 'Y') {
              $component.addClass('required');
            }
          }

          return $component;
        },
        getStandardConfig: function (menu_cd) {
          let emptyModel;
          dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getStandardInfoConfig'), {
            async: false,
            data: {
              menu_cd: menu_cd,
            }
          }).done(function (data) {
            if (data.length > 0) {
              emptyModel = data;
            }
          }).fail(function (xhr, status, error) {
            dews.error(xhr.responseJSON.message);
          });

          return emptyModel;
        }
      };
    }
  }

  // 주민등록번호로 부터 생년월일, 생일 추출
  module.extractDataFromResNo = function (resNo) {
    let century19 = ['1', '2', '5', '6'];
    let century20 = ['3', '4', '7', '8'];
    let maleArr = ['1', '3', '5', '7', '9'];
    let femaleArr = ['2', '4', '6', '8', '0'];
    let foreignArr = ['5', '6', '7', '8'];
    let localYn;
    let century;
    let sex;
    let result = {};
    if (century19.indexOf(resNo.substring(6, 7)) !== -1) {
      century = '19';
    } else if (century20.indexOf(resNo.substring(6, 7)) !== -1) {
      century = '20';
    } else {
      century = '18';
    }

    if (maleArr.indexOf(resNo.substring(6, 7)) !== -1) {
      sex = 'M';
    } else if (femaleArr.indexOf(resNo.substring(6, 7)) !== -1) {
      sex = 'F';
    }

    if (foreignArr.indexOf(resNo.substring(6, 7)) === -1) {
      localYn = 'Y';
    } else {
      localYn = 'N';
    }

    result.birth = century.concat(resNo.substring(0, 6));
    result.sex = sex;
    result.localYn = localYn;

    return result;
  }

  // objCodeDtl -> dews.ui.dataSource 객체로 변환
  module.makeDataSourceObject = function (objCodeDtl, endDate) {
    let result = {};
    let standardDate = endDate || dews.date.format(new Date(), 'yyyyMMdd');
    $.each(objCodeDtl, function (moduleCd, fieldCdArr) {
      result[moduleCd] = {};
      $.each(fieldCdArr, function (fieldCd, data) {
        $.each(data, function (i, o) {
          o.selectable = ((o.END_DT || 99991231) >= (standardDate || 0)) ? true : false;
        });
        result[moduleCd][fieldCd] = dews.ui.dataSource('', { data: data });
        result[moduleCd][fieldCd].getHideData = function (index) {
          if (index >= 0 && this._pristineData.length !== 0) {
            return this._pristineData[index];
          } else {
            return null;
          }
        };
        result[moduleCd][fieldCd].setNullData = function () {
          this.options.data.unshift({ SYSDEF_CD: "", SYSDEF_NM: "" });
        };
        result[moduleCd][fieldCd].setFilter = function (exp) {
          this._view = this.options.data.filter(exp);
          this._data = this.options.data.filter(exp);
          this.options.data = this.options.data.filter(exp);
          this.transport.data = this.options.data.filter(exp);
          this._pristineData = this._pristineData.filter(exp);
        };
      });
    });

    return result;
  }

  // makeDataSourceObject()의 리턴값을 통해 드롭다운 컴포넌트에 데이터소스 설정
  module.setDataSourceInComponent = function (dewself, dataSourceObject) {
    let targetArr = dewself.$content.find('[custom-dropdown-data-code]');
    let id;
    let moduleCd;
    let fieldCd;
    let dataSource;
    $.each(targetArr, function (i, o) {
      id = o.getAttribute('id');
      moduleCd = o.getAttribute('custom-dropdown-data-module');
      fieldCd = o.getAttribute('custom-dropdown-data-code');
      addAll = o.getAttribute('custom-dropdown-add-all');

      if (addAll === 'true') {
        let valueCd = o.getAttribute('data-dews-value-field');
        let valueNm = o.getAttribute('data-dews-text-field');
        let empty = {};
        empty[valueCd] = '';
        empty[valueNm] = '';
        dataSourceObject[moduleCd][fieldCd].transport.data.insert(0, empty);
      }
      dewself[id].setDataSource(dataSourceObject[moduleCd][fieldCd]);
    });
  }


  // 사용자별세부권한 값 조회
  module.getUserAuth = function (returnType) {
    let result;
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getDetailAuthByUser'), {
      async: false,
    }).done(function (data) {
      if (typeof returnType === 'string' && returnType === 'raw') {
        result = data;
      } else {
        let obj = {};
        $.each(data, function (i, o) {
          if (obj.hasOwnProperty(o.AUTHTBL_NM)) {
            obj[o.AUTHTBL_NM] = obj[o.AUTHTBL_NM].concat('|'.concat(o.AUTHASGN_CD));
          } else {
            obj[o.AUTHTBL_NM] = o.AUTHASGN_CD;
          }
        });
        result = obj;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });
    return result;
  }

  // 인사기초설정마스터 값 조회
  module.getCodebaseMstData = function (menu_cd, hr_cd, hr_dtl_cd, use_yn, flag) {
    let result;
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getCodebaseMstData'), {
      async: false,
      data: {
        menu_cd: menu_cd,
        hr_cd: hr_cd,
        hr_dtl_cd: hr_dtl_cd,
        use_yn: use_yn,
        flag: flag  // min, max 값이 필요할때 'min' 또는 'max'로 입력받음. 그 외는 null.
      }
    }).done(function (data) {
      result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });
    return result;
  }

  // 인사기초설정디테일 값 조회
  module.getCodebaseDtlData = function (menu_cd, hr_cd, hr_dtl_cd, use_yn, mcls_cd) {
    let result;
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getCodebaseDtlData'), {
      async: false,
      data: {
        menu_cd: menu_cd,
        hr_cd: hr_cd,
        hr_dtl_cd: hr_dtl_cd,
        use_yn: use_yn,
        mcls_cd: mcls_cd,
      }
    }).done(function (data) {
      result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });
    return result;
  }


  // 인사환경설정 마스터 조회
  module.getConfigMstData = function (config_cd_pipe) {
    let objConfig = {};
    $.each(config_cd_pipe.split('|'), function (i, v) {
      if (v != null && v != '') {
        objConfig[v] = [];
      }
    });
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getConfigMstData'), {
      async: false,
      data: {
        config_cd_pipe: config_cd_pipe
      }
    }).done(function (data) {
      $.each(data, function (i, obj) {
        objConfig[obj.CONFIG_CD].push(obj);
      });
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });
    return objConfig;
  }

  // 인사환경설정 디테일 조회
  module.getConfigDtlData = function (config_cd_pipe, mcls_cd, no_sq) {
    let objConfig = {};
    $.each(config_cd_pipe.split('|'), function (i, v) {
      if (v != null && v != '') {
        objConfig[v] = [];
      }
    });
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getConfigDtlData'), {
      async: false,
      data: {
        config_cd_pipe: config_cd_pipe,
        mcls_cd: mcls_cd,
        no_sq: no_sq
      }
    }).done(function (data) {
      $.each(data, function (i, obj) {
        objConfig[obj.CONFIG_CD].push(obj);
      });
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });
    return objConfig;
  }

  // 인사환경설정정보 단일 건 조회
  // config_cd : 구분코드 [ 파라미터 형태 -> ('A') ]
  // ctrl_clas_cds : 제거항목코드 [ 파라미터 형태 -> ('A|B|C') ] / 제거항목 없으면 null
  module.getConfigInfoData = function (config_cd, ctrl_clas_cds) {
    let objConfigInfo = {};
    objConfigInfo[config_cd] = [];

    if (ctrl_clas_cds == null || ctrl_clas_cds == undefined || ctrl_clas_cds == '') {
      ctrl_clas_cds = 'NOT';
    }

    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getConfigInfoData'), {
      async: false,
      data: {
        config_cd: config_cd,
        ctrl_clas_cds: ctrl_clas_cds,
      }
    }).done(function (data) {
      $.each(data, function (i, obj) {
        objConfigInfo[obj.CONFIG_CD].push(obj);
      });
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });
    return objConfigInfo;
  }

  // 중복된 값 확인하는 함수 checkDuplicatedCell(ManagedCodeGrid, e.row.index, "HR_CD")
  module.checkDuplicatedCell = function checkDuplicatedCell(grid, index, fieldsPipe) {
    // 개선예정 : 중복된 항목, 개수, true, false 값 반환할것
    var checker = 0;
    // var editstate = false;
    var compTarget = {};
    var data = fieldsPipe.split("|");
    $.each(data, function (i, o) {
      var value = grid.getCellValue(index, o);
      compTarget[o] = value;
    });

    $.each(grid.dataItems(), function (i, o) {
      var count = 0;
      $.each(compTarget, function (field, value) {
        if (value === o[field]) {
          count++;
        }
      });
      if (count === data.length) {
        checker++;
      }
    });

    return checker;
  }

  // 사용자별세부권한 값 조회
  module.getHrSessionData = function () {
    let result;
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getHrSessionData'), {
      async: false,
    }).done(function (data) {
      if (0 < data.length) {
        result = data[0];
      } else {
        result = {
          'GEMP_NO': '',
          'EMP_NO': '',
          'KOR_NM': ''
        };
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });

    result.hasOwnProperty("")
    result.hasOwnProperty("params")
    return result;
  }

  // 로그인 회사정보 조회
  module.getCompanySessionData = function () {
    let result;
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getCompanySessionData'), {
      async: false,
    }).done(function (data) {
      if (0 < data.length) {
        result = data[0];
      } else {
        result = {
          'COMPANY_CD': '',
          'COMPANY_NM': '',
          'NATION_CD': '',
          'LANG_CD': ''
        };
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });
    return result;
  }

  
  /**
   * getCdauthInfo
   * @description 인사코드별권한관리정보 조회
   * @param {*} menu_cd 
   * @param {*} emp_no 
   * @param {*} rcode_dc 
   * @param {*} config_cd 
   * @returns 
   */
  module.getCdauthInfo = function (menu_cd, emp_no, rcode_dc, config_cd) {
    let result;
    // 인사코드별 권한 정보 조회
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getCdauthInfo'), {
      async: false,
      data: {
        menu_cd: menu_cd,
        emp_no: emp_no,
        rcode_dc : rcode_dc,
        config_cd : config_cd
      }
    }).done(function (data) {
      
      if( data.length > 0 ) {
        result = data;
      } else {
        result = [];
      }
      
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });

    return result;
  }

  /**
   * getCdauthInfoCodeList
   * @description 인사코드별권한관리정보 코드 조회
   * @param {*} flag_cd  (공통코드인지 인사코드인지 (comm, hr))
   * @param {*} menu_cd 
   * @param {*} emp_no 
   * @param {*} rcode_dc 
   * @param {*} config_cd 
   * @returns 
   */
  module.getCdauthInfoCodeList = function (flag_cd, menu_cd, emp_no, rcode_dc, config_cd) {
    let result;
    // 인사코드별 권한 정보 조회
    dews.api.get(dews.url.getApiUrl('HR', 'HrCommonService', 'getCdauthInfoCodeList'), {
      async: false,
      data: {
        flag_cd : flag_cd,
        menu_cd : menu_cd,
        emp_no : emp_no,
        rcode_dc : rcode_dc,
        config_cd : config_cd
      }
    }).done(function (data) {
      
      if( data.length > 0 ) {
        result = data;
      } else {
        result = [];
      }
      
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.warning(error);
    });

    return result;
  }

  // 주민등록번호 유효성 검사
  module.isResNoValid = function (resNo) {
    var regExp = /^(?:[0-9]{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[1,2][0-9]|3[0,1]))[0-9][0-9]{6}$/;
    var tempArr = [];
    var tempSum = 0;
    var validKey = 2;
    var result = false;
    var noValid = new Date('2020-10-01');

    if (resNo.length === 13 && resNo.match(regExp) !== null) {
      for (var index = 0; index < resNo.length; index++) {
        tempArr.push(resNo.charAt(index));
      }

      var birth = resNo.substring(0,6);
      birth = (tempArr[6] > 2 ? '20' : '19').concat(birth);
      var birthDate = new Date(dews.date.format(birth, 'yyyy-MM-dd'));

      // 2020-10-01 이전 출생자만 주민등록번호 유효성 검사 실시
      if(noValid > birthDate) {
        for(var i = 0; i < resNo.length -1; i++) {
          if(validKey === 10) {
            validKey = 2;
          }
          tempSum += tempArr[i] * validKey;
          validKey++;
        }
        result = (11 - tempSum%11)%10 === Number(tempArr[12]);

        return result;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }

  // 생년월일(8자리) 에서 한국 나이 구하기
  module.getKoreanAgeFromBirth = function (birthDate) {
    let age = new Date().getFullYear() - Number(birthDate.substring(0, 4)) + 1;
    return age;
  }

  // 생년월일(8자리) 에서 만 나이 구하기
  module.getFullAgeFromBirth = function (birthDate) {
    let age = Math.trunc((((new Date() - new Date(birthDate.substring(0, 4), birthDate.substring(4, 6) - 1, birthDate.substring(6, 8))) / 1000) / 86400) / 365);
    return age;
  }

  /* START-- hr.codeDtl.js */
  /* options(options가 없는 경우 "사업장필수" 무조건 통제)
    self: self 사용 시 "사업장필수 통제여부"의 사용
    boolean: 사업장 필수 여부
    string: 사업장 필수 && 사용 메세지
    object: {
      self: self(dewself), // self 사용 시 "사업장필수 통제여부"의 사용
      useAlert: true/FALSE,
      msg: string
    }
   */
  module.setHrDetail = function (master, detail, param, options) {
    // default
    let isCtrlMst = true; // detail 제어 여부
    let useAlert = true;  // 메세지박스 사용 여부(false(미사용) 시 disable)
    let msg = ''; // 메세지박스 내용
    //
    let mainSelf; // self/dewself 등
    let deptMsg = dews.localize.get("사업장은 필수입력 항목입니다.", 'M0004673');
    let empMsg = dews.localize.get("부서는 필수입력 항목입니다.", 'M0002423');
    let elseMsg = dews.localize.get("필수값이 입력되지 않았습니다.", 'M0000807');
    let displayLog = false;

    if (detail.options.helpCode.indexOf("MA_DEPT_MST") > -1) {
      msg = deptMsg;
    } else if (detail.options.helpCode.indexOf("HR_EMP_MST") > -1) {
      msg = empMsg;
    } else {
      msg = elseMsg;
    }

    msg = deptMsg;

    if (displayLog) console.log(master, detail);

    if (options == null || options == undefined) { // null/undefined, 0제외
      // default
    } else if ($.isPlainObject(options)) {  // object 객체
      mainSelf = options.self ? options.self : null;
      if (options.useAlert === null || options.useAlert === undefined) {
        // useAlert = default
      } else {
        useAlert = options.useAlert;
      }
      msg = options.msg ? options.msg : msg;
      useAlert = (options.useAlert == undefined && options.msg) ? true : useAlert;
      isCtrlMst = (mainSelf && mainSelf.comEnv && mainSelf.comEnv.HR00002 && mainSelf.comEnv.HR00002.value === 'N') ? false : true;
      displayLog = options.displayLog;
    } else if (typeof options === 'object') { // self
      mainSelf = options;
      isCtrlMst = (mainSelf && mainSelf.comEnv && mainSelf.comEnv.HR00002 && mainSelf.comEnv.HR00002.value === 'N') ? false : true;
    } else if (typeof options === 'boolean') {
      isCtrlMst = options;
    } else if (typeof options === 'string') {
      useAlert = true;
      msg = options;
    } else if (typeof options === 'number') {
      // later
    } else if (typeof options === 'function') {
      // later
    }

    if (isCtrlMst && !useAlert) {
      detail.enable(false);
    } else {
      // detail.enable(false);
      detail.enable(true);
    }

    var prevMaster = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? master.codes().join("|") : master.code();
    master.subDetail = detail;

    var prevObj = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true
      ?
        typeof detail.options.helpParams === 'function'
        ? detail.options.helpParams()
        : detail.options.helpParams
      : {};

    if (prevObj === null) {prevObj = {}}

    if (typeof param === "string") {
      prevObj[param] = prevMaster
    } else {
      if (typeof (master.options.codeField)) {
        var prevAuth = 'auth_' + master.options.codeField.substring(0, master.options.codeField.length-3).toLowerCase();
        if (prevMaster != null && prevMaster != "") {
          prevObj[prevAuth] = prevMaster;
        }
      } else {
        return;
      }
    }

    if (displayLog) console.log('prevObj:', prevObj);

    detail.setHelpParams(prevObj);

    detail.setHelpParams = function (params) { // dews setHelpParams 재정의
      let helpParams;
      let detailHelpParams;

      if (typeof detail.options.helpParams === 'function') {
        detailHelpParams = detail.options.helpParams();
      } else {
        detailHelpParams = detail.options.helpParams;
      }

      if (displayLog) console.log('detailHelpParams(' + typeof detail.options.helpParams + ' to object):', JSON.stringify(detailHelpParams, null, '\t'));

      if (detail.options.helpParams != null) {
        // Object.assign(params, detailHelpParams);
        helpParams = $.extend(true, {}, detailHelpParams, params);
      }
      // defineDetailHelpParam = helpParams;
      // setHelpParams 코드 원본 : dews.ui.js ---------------------------
      var self = this;
      self.options.helpParams = helpParams;
      // ---------------------------------------------------------------
      if (displayLog) console.log('detail helpParams:', helpParams);
    };

    master.on("change", function (e) {
      // var obj = detail.options.helpParams === null ? {} : detail.options.helpParams;
      var obj;
      var curMaster = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? master.codes().join("|") : master.code();

      if (detail.options.helpParams === null) {
        obj = {};
      } else {
        if (typeof detail.options.helpParams === 'function') {
          obj = detail.options.helpParams();
        } else {
          obj = detail.options.helpParams;
        }
      }

      if (useAlert){
        detail.enable(true);
      } else{
        if (displayLog) console.log('curMaster:', curMaster);
        if (curMaster != "" && curMaster != null && curMaster != undefined) {
          // detail.enable(false);
          detail.enable(true);
        } else{
          detail.enable(false);
        }
      }

      if (typeof param === "string") {
        obj[param] = curMaster
      } else {
        var auth = 'auth_' + master.options.codeField.substring(0, master.options.codeField.length-3).toLowerCase();
        var cd = master.options.codeField.toLowerCase();

        obj[auth] = curMaster;
        obj[cd] = curMaster;
      }

      if (displayLog) console.log('>>>', curMaster, prevMaster.length, obj, obj.bizarea_cd, detail);
      if (curMaster != prevMaster) {
        if (curMaster.length <= prevMaster.length) {
          if (detail.target === undefined) {detail.clearData()} else {detail.clear()};
          clearDetail(detail, detail.subDetail);
        }
      }
      // console.log('obj:', obj, obj.auth_bizarea, obj.bizarea_cd, param, typeof param)
      detail.setHelpParams(obj);
      prevMaster = curMaster;
    });

    detail.on('codedialog', function(e){
      if (isCtrlMst) {
      // if(busiCode == undefined){
        // console.log("prevMaster", prevMaster);
        let masterCode = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? master.codes().join("|") : master.code();
        if (masterCode == null || masterCode == '') {
        // if (prevMaster == "" || prevMaster == null || prevMaster == undefined) {
          e.stopImmediatePropagation();
          dews.alert(msg, "warning");
          // if(e.code.indexOf("MA_DEPT_MST") > -1){
          //   dews.alert(msg, "warning");
          // } else {
          //   dews.alert(empMsg, "warning");
          // }
        }
      }
    });

    function clearDetail(detail, subdetail) {
      if (subdetail != undefined) {
        clearDetail(subdetail, subdetail.subDetail);
        if (subdetail.wrapper != undefined && $(subdetail.wrapper.context).hasClass("dews-ui-multicodepicker") === true) {
          subdetail.clear(); subdetail.setHelpParams({});
        } else {
          subdetail.clearData(); subdetail.setHelpParams({});
        }

        if (! useAlert){
          subdetail.enable(false);
        }
      }
      return;
    }
  }
  /* hr.codeDtl.js --END */

  /* START-- hr.getCodeData.js */
  module.codeData = function (module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
    var objCodeDtl = {};

    if (module_cd != undefined && field_cd_pipe != undefined) {
      module.setCodeData(objCodeDtl, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword);
    }

    objCodeDtl.getCodeData = function (module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
      if (module_cd != undefined && field_cd_pipe != undefined) {
        module.setCodeData(objCodeDtl, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword);
      }
    }

    objCodeDtl.addAll = function (module_cd, field_cd_pipe, name) {
      module.addAll(objCodeDtl, module_cd, field_cd_pipe, name);
    }

    return objCodeDtl;
  }

  module.setCodeData = function (objCodeDtl, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
    syscode_yn = syscode_yn === undefined ? null : syscode_yn;
    base_yn = base_yn === undefined ? null : base_yn;
    foreign_yn = foreign_yn === undefined ? null : foreign_yn;
    end_dt = end_dt === undefined ? null : end_dt;
    keyword = keyword === undefined ? null : keyword;

    if (!objCodeDtl.hasOwnProperty(module_cd)) {
      objCodeDtl[module_cd] = {};
    }

    $.each(field_cd_pipe.split("|"), function (i, v) {
      if (v != null && v != "") {
        objCodeDtl[module_cd][v] = [];
        objCodeDtl[module_cd][v + addSentence] = [];
      }
    });

    dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
      async: false,
      data: {
        module_cd: module_cd,
        field_cd_pipe: field_cd_pipe,
        syscode_yn: syscode_yn,
        base_yn: base_yn,
        foreign_yn: foreign_yn,
        end_dt: end_dt,
        keyword: keyword,
      }
    }).done(function (data) {
      if (data.length > 0) {
        $.each(data, function (i, obj) {
          objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
          objCodeDtl[module_cd][obj.FIELD_CD + addSentence].push(obj);
          if (objCodeDtl[module_cd][obj.FIELD_CD + addSentence][0].SYSDEF_CD != "") {
            module.addAll(objCodeDtl, module_cd, obj.FIELD_CD, "");
          }
        });
      }
    }).fail(function (xhr, status, error) {
      console.log(xhr, status, error);
    });
  }

  module.addAll = function (objCodeDtl, module_cd, field_cd_pipe, name) {
    $.each(field_cd_pipe.split("|"), function (i, v) {
      if (v != null && v != "") {
        if (objCodeDtl[module_cd][v + addSentence][0].SYSDEF_CD === "") {
          objCodeDtl[module_cd][v + addSentence].shift();
        }
        objCodeDtl[module_cd][v + addSentence].unshift({ FIELD_CD: objCodeDtl[module_cd][v][0].FIELD_CD, SYSDEF_CD: "", SYSDEF_NM: name === undefined ? "" : name, FLAG_CD: null });
      }
    });
  }
  /* hr.getCodeData.js --END */

  module.getHBS = function (type, cols, tab, cons, async) {
    var retList = [];
    var apiName = type.toLowerCase() === "o" ? 'getHrBasicSelectO' : 'getHrBasicSelectS';

    dews.api.post(dews.url.getApiUrl('HR', 'HrBasicService', apiName), {
      async: async ? async : false,
      data: {
        cols: JSON.stringify(cols),
        tab: tab,
        cons: JSON.stringify(cons),
      }
    }).done(function (data) {
      retList = data;
      // console.log("getHrBasicSelect:", data);
    }).fail(function (xhr, status, error) {
      console.log('getHrBasicSelect check:', xhr, status, error);
    });
    return retList;
  }

  module.tlog = function () {
    if (window.location.hostname === 'localhost') {
      console.log('【ＴＬＯＧ】', arguments);
    }
  }

  module.getStatusColor = function (self, target) {
    var hrObjStatusColor = {
      COMMENT: {
        url: 'http://dbs.douzone.com/docs/UI/Document/%EC%83%81%ED%83%9C%ED%91%9C%EC%8B%9C/docs/status_tutorial',
        C0: 'DEWS Status Color',
        C1: dews.localize.get('hex는 alpha(opacity)가 포함된 값으로 AARRGGBB로 설정되어 있습니다.', 'M0020401', '', 'PBMPAC00200_POP_SUM'),
        C2: dews.localize.get('alpha 포함된 hex 방식은 브라우저에 따라 다르게 보일 수 있습니다.', 'M0020402', '', 'PBMPAC00200_POP_SUM'),
        C3: dews.localize.get('hex값 보다 rgba값이 더 정확합니다.', 'M0020403', '', 'PBMPAC00200_POP_SUM'),
      }
    };
    var hrDewsStatusColor = '\
  <div id="hr-dews-status-color" >\
  <span id="hr-dews-status-color-progress">\
    <div class="status_progress_bgcolor">progress<input type="text" class="hex" readonly/><input type="text" class="hexa" readonly/><input type="text" class="rgb" readonly/></div>\
    <div class="status_progress_bgcolor1">progress 1<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_progress_bgcolor2">progress 2<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_progress_bgcolor3">progress 3<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_progress_bgcolor_opacity opacity">progress opacity<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
  </span>\
  <span id="hr-dews-status-color-positive">\
    <div class="status_positive_bgcolor">positive<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_positive_bgcolor1">positive 1<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_positive_bgcolor2">positive 2<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_positive_bgcolor3">positive 3<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_positive_bgcolor_opacity opacity">positive opacity<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
  </span>\
  <span id="hr-dews-status-color-pending">\
    <div class="status_pending_bgcolor">pending<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_pending_bgcolor1">pending 1<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_pending_bgcolor2">pending 2<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_pending_bgcolor3">pending 3<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_pending_bgcolor_opacity opacity">pending opacity<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
  </span>\
  <span id="hr-dews-status-color-negative">\
    <div class="status_negative_bgcolor">negative<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_negative_bgcolor1">negative 1<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_negative_bgcolor2">negative 2<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_negative_bgcolor3">negative 3<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_negative_bgcolor_opacity opacity">negative opacity<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
  </span>\
  <span id="hr-dews-status-color-neutral">\
    <div class="status_neutral_bgcolor">neutral<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_neutral_bgcolor1">neutral 1<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_neutral_bgcolor2">neutral 2<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_neutral_bgcolor3">neutral 3<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
    <div class="status_neutral_bgcolor_opacity opacity">neutral opacity<input type="text" class="hex"/><input type="text" class="hexa"/><input type="text" class="rgb"/></div>\
  </span>\
  </div>\
  <style>\
    #hr-dews-status-color div.opacity {\
      color: black !important;\
    }\
    #hr-dews-status-color div {\
      height: 27px;\
      color: white;\
    }\
    #hr-dews-status-color input.rgb {\
      width: 138px !important;\
    }\
    #hr-dews-status-color input {\
      margin-left: 3px;\
      width: 56px;\
      height: 25px;\
      float: right;\
      position: relative;\
      background-color: #f7f7f7;\
      border-width: 1px 1px 1px 1px;\
      border-color: #ccc !important;\
      padding: 0px 6px 0px 6px;\
      font-size: 12px;\
      color: #000;\
      font-family: \'Andale Mono\';\
    }\
    #hr-dews-status-color input:hover {\
      border-color: #a6a6a6 !important;\
    }\
    #hr-dews-status-color input:focus {\
      border-color: #a6a6a6 !important;\
    }\
    #hr-dews-status-color input:first-child {\
      margin-right: 10px;\
    }\
  </style>\
  '
    if (target) {
      target.append(hrDewsStatusColor);
    } else {
      self.$content.append(hrDewsStatusColor);
    }

    $.each(self.$content.find('#hr-dews-status-color > span'), function (i, span) {
      // console.log(i, span);
      let objSpan = {};
      $.each($(span).find('div'), function (j, div) {
        objSpan[$(div).text()] = {};
        objSpan[$(div).text()].rgba = $(div).css('background-color');
        objSpan[$(div).text()].hex = rgba2hex(objSpan[$(div).text()].rgba);
        if (target) {
          $(div).find('.rgb').val(objSpan[$(div).text()].rgba);
          $(div).find('.hex').val(rgba2hex(objSpan[$(div).text()].rgba));
          $(div).find('.hexa').val(rgba2hex(objSpan[$(div).text()].rgba, true));
        }
      });
      if (!$.isEmptyObject(objSpan)) {
        let id = $(span).prop('id').replace('hr-dews-status-color-', '').toUpperCase();
        hrObjStatusColor[id] = objSpan;
      }
    });
    // console.log('hrObjStatusColor:', hrObjStatusColor);
    // self.$content.remove('#hr-dews-status-color');

    if (!target) {
      self.$content.find('#hr-dews-status-color').remove();
    }

    return hrObjStatusColor;
  }

  module.checkSessionInfo = function (mSlef, warnTp) {  // self, s(nackbar)/m(essage box)
    var user = mSlef.user;
    var objRet = {
      result: true,
      code: 0,
      codeKey: null,
      message: null
    };

    if (user) {
      if (!user.companyCode) {
        objRet.result = false;
        objRet.code = 100;
        objRet.subCode = 'companyCode';
        objRet.message = '회사 정보가 없습니다.';
      } else if (!user.gEmpCode) {
        objRet.result = false;
        objRet.code = 120;
        objRet.subCode = 'gEmpCode';
        objRet.message = '통합사원번호가 없습니다.';
      } else if (!user.groupCode) {
        objRet.result = false;
        objRet.code = 140;
        objRet.subCode = 'groupCode';
        objRet.message = '사업장번호가 없습니다.';
      } else if (!user.empCode) {
        objRet.result = false;
        objRet.code = 160;
        objRet.subCode = 'empCode';
        objRet.message = '사원을 등록하세요. 통합사원번호: ' + user.gEmpCode;
      }
    } else {
      objRet.result = false;
      objRet.code = 900;
      objRet.message = '세션 정보가 없습니다.';
    }

    if (!objRet.result) {
      if (warnTp == 'm') {
        dews.alert(objRet.message, 'warning');
      } else {
        dews.ui.snackbar.warning(objRet.message, { exposureTime: 4000 });
      }

    }

    return objRet;
  }

  module.setSubTotalPrint = function (mSlef, grid, isDisplay) {
    var arrGroup = grid.options.group;
    var objGroupType = {};
    var cloneGrid, cloneDs;
    var compareIterator = null;
    var sortData, customData = [];
    var columns = $.extend(true, [], grid.getColumns());
    var firstBy = (function () {

      function identity(v) { return v; }

      function ignoreCase(v) { return typeof (v) === "string" ? v.toLowerCase() : v; }

      function makeCompareFunction(f, opt) {
        opt = typeof (opt) === "number" ? { direction: opt } : opt || {};
        if (typeof (f) != "function") {
          var prop = f;
          // make unary function
          f = function (v1) { return !!v1[prop] ? v1[prop] : ""; }
        }
        if (f.length === 1) {
          // f is a unary function mapping a single item to its sort score
          var uf = f;
          var preprocess = opt.ignoreCase ? ignoreCase : identity;
          var cmp = opt.cmp || function (v1, v2) { return v1 < v2 ? -1 : v1 > v2 ? 1 : 0; }
          f = function (v1, v2) { return cmp(preprocess(uf(v1)), preprocess(uf(v2))); }
        }
        if (opt.direction === -1) return function (v1, v2) { return -f(v1, v2) };
        return f;
      }

      function tb(func, opt) {
        var x = (typeof (this) == "function" && !this.firstBy) ? this : false;
        var y = makeCompareFunction(func, opt);
        var f = x ? function (a, b) {
          return x(a, b) || y(a, b);
        }
          : y;
        f.thenBy = tb;
        return f;
      }
      tb.firstBy = tb;
      return tb;
    })();

    $.each(grid.options.columns, function (i, o) {
      if (o.footer) {
        objGroupType[o.field] = o.footer;
      }
    });

    // console.log('objGroupType:', objGroupType);

    if (!arrGroup) {
      arrGroup = [];
      $.each(grid._grid.getGroupFieldNames(), function (i, v) {
        arrGroup.push({ field: v });
      });
    }

    $.each(arrGroup, function (i, o) {
      compareIterator = getComparator(compareIterator, o.field);
    })
    console.log('compareIterator:', compareIterator)
    sortData = grid.dataItems().sort(compareIterator);

    var dump = '';
    var objDump = {};
    var objSubTotal = {};
    var objTotal = {};

    $.each(objGroupType, function (k, gType) {
      if (!gType.expression) {
        objTotal[k] = gType.text;
      } else {
        objTotal[k] = 0;
      }
    });

    $.each(sortData, function (i, o) {
      if (i === 0) {
        dump = o[arrGroup[0].field];
        $.each(objGroupType, function (k, gType) {
          if (!gType.expression) {
            objDump[k] = gType.groupText;
          } else {
            objDump[k] = 0;
          }
        });
      }

      if (dump === o[arrGroup[0].field]) {
      } else {
        dump = o[arrGroup[0].field];
        objSubTotal = {};
        $.each(objGroupType, function (k, gType) {
          objSubTotal[k] = objDump[k];
          objDump[k] = 0;
        });
        customData.push(objSubTotal);
      }

      $.each(objGroupType, function (k, gType) {
        if (!gType.expression) {
          objTotal[k] = gType.text;
        } else if (gType.expression === 'sum') {
          objTotal[k] += o[k] ? o[k] : 0;
        } else if (gType.expression === 'count') {
          objTotal[k]++;
        } else if (gType.expression === 'avg') {
        } else if (gType.expression === 'max') {
          objTotal[k] = objTotal[k] > o[k] ? objTotal[k] : o[k];
        } else if (gType.expression === 'min') {
          objTotal[k] = objTotal[k] < o[k] ? objTotal[k] : o[k];
        }

        if (!gType.groupExpression) {
          objDump[k] = gType.groupText;
        } else if (gType.groupExpression === 'sum') {
          objDump[k] += o[k] ? o[k] : 0;
        } else if (gType.groupExpression === 'count') {
          objDump[k]++;
        } else if (gType.groupExpression === 'avg') {
        } else if (gType.groupExpression === 'max') {
          objDump[k] = objDump[k] > o[k] ? objDump[k] : o[k];
        } else if (gType.groupExpression === 'min') {
          objDump[k] = objDump[k] < o[k] ? objDump[k] : o[k];
        }
      });
      customData.push(o);
    });
    if (!$.isEmptyObject(objDump)) {
      objSubTotal = {};
      $.each(objGroupType, function (k, gType) {
        objSubTotal[k] = objDump[k];
      });
      customData.push(objSubTotal);
    }
    console.log('objTotal:', objTotal);
    if (!$.isEmptyObject(objTotal)) {
      $.each(objGroupType, function (k, gType) {
        if (gType.suffix) {
          objTotal[k] = objTotal[k] + gType.suffix;
        } else if (gType.prefix) {
          objTotal[k] = gType.prefix + objTotal[k];
        }
      });
      customData.push(objTotal);
    }
    // console.log(grid.dataItems(), customData);

    mSlef.$content.find('#subTotalPrintDiv').remove();
    mSlef.$content.append('<div id="subTotalPrintDiv" class="dews-container-panel" style=" ' + (!isDisplay ? 'display: none;' : '') + '"><div class="dews-container-item" ' + (isDisplay ? 'style="width: 100%;"' : '') + '><div class="dews-ui-grid" id="subTotalPrintGrid"></div></div></div>');

    cloneDs = dews.ui.dataSource("cloneDs", {
      grid: true,
      data: customData,
      schema: {
        model: {
          fields: grid.dataSource.options.field
        }
      }
    });

    $.each(columns, function (i, o) {
      if (o.footer) {
        delete o.footer.text;
        delete o.footer.type;
        delete o.footer.expression;
      }
    });
    console.log('columns:', columns)

    cloneGrid = dews.ui.grid(mSlef.$content.find('#subTotalPrintGrid'), {
      dataSource: cloneDs,
      rowNo: false,
      checkable: false,
      columns: columns
    });
    // cloneGrid.dataSource.data(sortData);

    // console.log('cloneGrid:', cloneGrid);

    dews.ui.mainbuttons.print.autoPrintOptions = {
      grid: cloneGrid,
      condition: mSlef.condition,
      schema: {
        model: {
          fields: grid.dataSource.options.field
        }
      }
    };

    function getComparator(iterator, compareFunction) {
      if (iterator === null) {
        return firstBy(compareFunction);
      } else {
        return iterator.thenBy(compareFunction);
      }
    }
  }

  /**
   * 프린트 API
   * @param {*} dewself this
   * @param {*} reportId 리포트ID
   * @param {*} objectId 오브젝트ID
   * @param {*} params 파라미터
   */
  module.invokePrint = function (dewself, reportId, objectId, params) {
    var items = [];

    $(params).each(function (idx, item) {
      items.push({
        RPRT_CD: reportId,
        OBJECT_CD: objectId,
        PARA_CD: item.name,
        PARA_TXT: item.value
      });
    });

    //파라미터 저장 요청
    dews.api.post(dews.url.getApiUrl("CM", "printService", "setPrintParam"), {
      async: false,
      data: {
        reportCode: reportId,
        items: JSON.stringify(items)
      }
    }).done(function (data) {
      var options = {
        reportId: reportId,
        parameterKey: data
      };
      dews.app.print(options);
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
  }
  /**
 * ESS 설명 텍스트 API
 * @param {*} _menu_id
 * @param {*} _dtl_fg_cd 예 '***'
 * @param {*} _fg_cd (공백일 때 전체조회)
 */
  module.getDescription = function (_memu_id, _dtl_fg_cd, _fg_cd) {
    let result;
    dews.api.get(dews.url.getApiUrl("HR", "HrCommonService", "getEssDescription"), {
      async: false,
      data: {
        dtl_fg_cd: _dtl_fg_cd,
        menu_id: _memu_id,
        fg_cd: (_fg_cd != null && _fg_cd != undefined) ? _fg_cd : ""
      }
    }).done(function (data) {
      result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  }

  /**
  * 가져온 작성요령등록 조회
  * @param {string} List_HR_DESCRIPTION : derp.HR.getDescription(...)
  * @param {string} strRtnColCode ("TITL_DESC_DC" or "WRT_INFO_TXT")
  * @param {string} fg_cd
  * @param {string} dtl_fg_cd
  * @param {string} isShowIdxZeroValue true or false
  * @returns {string}}
  */
  module.getWrtTip = function () {
    // ex.) derp.HR.getWrtTip(objWrtTips, "DC", "11", "***", true);
    if (arguments[0] == null || arguments[0] == undefined || arguments[0].length == 0) {
      return "";
    }
    if (arguments.length == 5) {
      let objects = arguments[0];
      let arrTITL_DESC_DC = { 0: "", TITLE: "", DESC: "", DC: "", TITL_DESC_DC: "" };
      let rtnColString = ((arguments[1] in arrTITL_DESC_DC) ? "TITL_DESC_DC" : "WRT_INFO_TXT");
      let fg_cd = arguments[2];
      let dtlFgCd = arguments[3] ? arguments[3] : '***';
      let isShowIdxZeroValue = arguments[4];
      let strRtnValue = "";

      let findeWt = objects.filter(function (o) {
        return (o.FG_CD === fg_cd && o.DTL_FG_CD === dtlFgCd);
      });
      if (findeWt != null && findeWt.length > 0) {
        //return findeWt[0].TITL_DESC_DC;
        strRtnValue = findeWt[0][rtnColString];
      }

      if (strRtnValue == null || strRtnValue == "") {
        //없는경우 [0]번쨰 항목 표시
        if (isShowIdxZeroValue) {
          findeWt = objects.filter(function (o) {
            return (o.FG_CD === fg_cd);
          });
          if (findeWt != null && findeWt.length > 0) {
            return findeWt[0][rtnColString];
          }
          else {
            return "";
          }
        }
        else {
          return "";
        }
      }
      else {
        return strRtnValue;
      }
    }
  }

  /**
  * 작성요령등록 referbox 셋팅
  * @param {string} List_HR_DESCRIPTION : derp.HR.getDescription(...)
  * @param {string} strRtnColCode ("TITL_DESC_DC" or "WRT_INFO_TXT")
  * @param {string} fg_cd
  * @param {string} dtl_fg_cd
  * @param {string} isShowIdxZeroValue true or false
  * @param {string} strElementID
  */
  module.setWrtTip = function () {
    // instructions : ex.) derp.HR.setWrtTip(objWrtTips, "TXT", fgCd, dtlFgCd, false, "wrtInfo");
    let curPage = (dews.ui.dialogPage && !dews.ui.dialogPage.dialog._closing) ?
      dews.ui.dialogPage : dews.ui.page;

    if (curPage["$" + arguments[5]] == undefined) {
      return;
    }

    let strCnUser = "user-WrtTip";
    let strCnRfContent = "dews-referbox-content";
    let arrTITL_DESC_DC = { 0: "", TITLE: "", DESC: "", DC: "", TITL_DESC_DC: "" };

    let objects = arguments[0];
    let rtnColString = ((arguments[1] in arrTITL_DESC_DC) ? "TITL_DESC_DC" : "WRT_INFO_TXT");
    let fgCd = arguments[2];
    let dtlFgCd = arguments[3] ? arguments[3] : '***';
    let isShowIdxZeroValue = arguments[4];
    let ctrInfo = curPage["$" + arguments[5]][0];

    let ctrInfoTxt;
    if (ctrInfo.getElementsByClassName(strCnRfContent).length == 0) {
      ctrInfoTxt = ctrInfo;
    }
    else {
      let crtReferBoxContent = ctrInfo.getElementsByClassName(strCnRfContent)[0];
      $(crtReferBoxContent).context.innerHTML = "";

      if (crtReferBoxContent.getElementsByClassName(strCnUser).length == 0) {
        $(crtReferBoxContent).context.insertAdjacentHTML('beforeend', '<p></p><div class="' + strCnUser + '"></div>');
      }
      ctrInfoTxt = ctrInfo.getElementsByClassName(strCnUser)[0];
    }

    setDescription(module.getWrtTip(objects, rtnColString, fgCd, dtlFgCd, isShowIdxZeroValue));

    function setDescription(description_data) {

      $(ctrInfoTxt).context.innerHTML = "";
      if (description_data == null || description_data == "") {
        ctrInfo.style.display = 'none';
      }
      else {
        let strTemp = description_data.split('<br />');
        $.each(strTemp, function (idx, item) {
          $(ctrInfoTxt).context.insertAdjacentHTML('beforeend', '<li>' + item + '</li>');
        });
        ctrInfo.style.display = 'block';
      }
    }
  }

  //소수점 적용
  module.decimalFormat = function () {
    let result = {
      format: '#,##0',
      round: 'round',
      decimal: '0'
    };

    dews.api.get(dews.url.getApiUrl("HR", "HrCommonService", "listMaCtrlconfig"), {
      async: false,
      data: {
        module_cd: 'HR',
        ctrl_cd: null,
      },
    }).done(function (data) {
      let obj = $.grep(data, function (d) {
        return d.CTRL_CD === 'HR00001';
      });
      if (obj.length === 1) {
        result.format = obj[0].FORMAT_VR;
        result.decimal = obj[0].CTRL_VR;
        switch (obj[0].RND_FG) {
          case '1': result.round = 'round'; break;
          case '2': result.round = 'ceil'; break;
          case '3': result.round = 'floor'; break;
        }
      }
    }).fail(function (xhr, status, error) {
      console.log(xhr.responseJSON.message);
    });

    return result;
  }

  /**
   * 버전정보 조회 API
   * @param {*} services ('|'로 구분)
   */
  module.dispServiceVersion = function (services) {
    $.each(services.split('|'), function (i, service) {
      if (service) {
        dews.api.get(dews.url.getApiUrl('CM', 'ServiceVersion'), {
          data: {
            service: service
          }
        }).done(function (data) {
          console.log('ServiceVersion@' + service + ': ', data);
        }).fail(function (xhr, status, error) {
          console.log('ServiceVersion error:', xhr, status, error);
        });
      }
    });
  }

  /**
   * 메일알람정보조회 API
   * @param {*} menu_cd
   * @param {*} fg_cd (공백일 때 전체조회) , '***'이면 1레벨임
   * @param {*} std_cd (공백일 때 전체조회) , '***'이면 3레벨이 아님
   * @param {*} tab_fg 1 : 담당자수신(기존) , 2 : 담당자발신(D20210621317)
   */
  module.getMailAlarmList = function () {
    let params = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      params[_i] = arguments[_i];
    }

    let result;
    dews.api.get(dews.url.getApiUrl("HR", "HrCommonService", "getMailAlarmList"), {
      async: false,
      data: {
        menu_cd: params[0] || "",
        fg_cd: params[1] || "",
        std_cd: params[2] || "",
        tab_fg: params[3] || "1"
      }
    }).done(function (data) {
      result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  }

  /**
   * 메일알람처리 API
   * @param {*} menu_cd
   * @param {*} fg_cd (공백일 때 전체조회) , '***'이면 1레벨임
   * @param {*} std_cd (공백일 때 전체조회) , '***'이면 3레벨이 아님
   * @param {*} tab_fg 1 : 담당자수신(기존) , 2 : 담당자발신(D20210621317)
   * @param {*} emp_no_pipe 사원번호
   */
  module.sendMailAlarmList = function () {
    let params = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      params[_i] = arguments[_i];
    }

    let result;
    dews.api.post(dews.url.getApiUrl("HR", "HrCommonService", "sendMailAlarmList"), {
      async: false,
      data: {
        menu_cd: params[0] || "",
        fg_cd: params[1] || "",
        std_cd: params[2] || "",
        tab_fg: params[3] || "1",
        emp_no_pipe: params[4] || ""
      }
    }).done(function (data) {
      result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  }

  /**
   * 메일알람처리 API2  로그인한 사원과 신청자 정보가 다를때 (신청자를 변경해서 신청할때)
   * @param {*} menu_cd
   * @param {*} fg_cd (공백일 때 전체조회) , '***'이면 1레벨임
   * @param {*} std_cd (공백일 때 전체조회) , '***'이면 3레벨이 아님
   * @param {*} emp_no 변경된 신청자 사원번호
   * @param {*} kor_nm 변경된 신청자 이름
   */
  module.sendMailAlarmList2 = function (menu_cd, fg_cd, std_cd, emp_no, kor_nm) {
    let result;
    dews.api.post(dews.url.getApiUrl("HR", "HrCommonService", "sendMailAlarmList2"), {
      async: false,
      data: {
        menu_cd: menu_cd,
        fg_cd: (fg_cd != null && fg_cd != undefined) ? fg_cd : "",
        std_cd: (std_cd != null && std_cd != undefined) ? std_cd : "",
        emp_no: emp_no,
        kor_nm: kor_nm
      }
    }).done(function (data) {
      result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  }

  /**
   * Armaranth 쪽지 알림(팝업) API
   * @param {*} menu_cd
   * @param {*} fg_cd (공백일 때 전체조회) , '***'이면 1레벨임
   * @param {*} std_cd (공백일 때 전체조회) , '***'이면 3레벨이 아님
   * @param {*} tab_fg 3 : 담당자수신() , 4 : 담당자발신(현재 해당기능 X)
   * @param {*} emp_no_pipe 사원번호
   */
   module.sendAmaranthPopList = function () {
    let params = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      params[_i] = arguments[_i];
    }

    let result;
    dews.api.post(dews.url.getApiUrl("HR", "HrCommonService", "sendAmaranthMessageList"), {
      async: false,
      data: {
        menu_cd: params[0] || "",
        fg_cd: params[1] || "",
        std_cd: params[2] || "",
        tab_fg: params[3] || "3",
        emp_no_pipe: params[4] || ""
      }
    }).done(function (data) {
      result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  }

  /**
   * Armaranth 쪽지(팝업) 알림 API2  로그인한 사원과 신청자 정보가 다를때 (신청자를 변경해서 신청할때)
   * @param {*} menu_cd
   * @param {*} fg_cd (공백일 때 전체조회) , '***'이면 1레벨임
   * @param {*} std_cd (공백일 때 전체조회) , '***'이면 3레벨이 아님
   * @param {*} emp_no 변경된 신청자 사원번호
   * @param {*} kor_nm 변경된 신청자 이름
   */
  module.sendAmaranthPopList2 = function (menu_cd, fg_cd, std_cd, emp_no, kor_nm) {
    let result;
    dews.api.post(dews.url.getApiUrl("HR", "HrCommonService", "sendAmaranthMessageList2"), {
      async: false,
      data: {
        menu_cd: menu_cd,
        fg_cd: (fg_cd != null && fg_cd != undefined) ? fg_cd : "",
        std_cd: (std_cd != null && std_cd != undefined) ? std_cd : "",
        emp_no: emp_no,
        kor_nm: kor_nm
      }
    }).done(function (data) {
      result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  }

  /**
   * 파일명다국어구분처리
   * : 언어가 ko가 아니면 파일명 뒤에 _EN 을 붙인다.
   * @param {*} fileName
   */
  module.getMultiLangFileName = function (fileName) {
    let appendLangStr = "";
    let isOtherLang = false;
    if (dews.localize.language().toUpperCase() != "KO") {
      appendLangStr = "_EN";
      isOtherLang = true;
    }
    let result;
    let fileLen = fileName.length;
    let lastDot = fileName.lastIndexOf('.');
    if (lastDot > -1) {
      let fileExt = fileName.substring(lastDot, fileLen).toLowerCase();
      if (fileExt.length > 4) {
        result = fileName + appendLangStr;
      } else {
        result = fileName.substring(0, fileLen - fileExt.length) + appendLangStr + fileExt;
      }
    } else {
      result = fileName + appendLangStr;
    }
    if (isOtherLang) {
      let http = new XMLHttpRequest();
      http.open('HEAD', result, false);
      http.send();
      if (http.status == 404) {
        result = fileName;
      }
    }
    return result;
  }

  /**
  * 단위처리
  * @param {Number} _amt 금액
  * @param {String} _unitProcCode 단위처리 코드
  */
  module.UnitProcessing = function (_amt, _unitProcCode) {
    let amt = _amt;
    switch (_unitProcCode){                                         // 16	정상
      case '11' : amt = Math.floor(amt); break;                     // 11	1원미만절사
      case '12' : amt = Math.ceil(amt); break;                      // 12	1원미만절상
      case '13' : amt = Math.floor(amt / 10 ) * 10; break;          // 13	10원미만절사
      case '14' : amt = Math.ceil(amt / 10 ) * 10; break;           // 14	10원미만절상
      case '15' : amt = Math.round(amt); break;                     // 15	반올림
      case '17' : amt = Math.floor(amt / 100 ) * 100; break;        // 17	100원미만절사
      case '18' : amt = Math.ceil(amt / 100 ) * 100; break;         // 18	100원미만절상
      case '19' : amt = Math.floor(amt / 1000 ) * 1000; break;      // 19	1000원미만절사
      case '20' : amt = Math.ceil(amt / 1000 ) * 1000; break;       // 20	1000원미만절상
      case '21' : amt = Math.floor(amt * 100 ) / 100; break;        // 21	소수점 셋째자리 절사
      case '22' : amt = Math.round(amt * 100 ) / 100; break;        // 22	소수점 셋째자리 반올림
      case '23' : amt = Math.ceil(amt * 100 ) / 100; break;         // 23	소수점 셋째자리 절상
      case '24' : amt = Math.floor(amt * 10 ) / 10; break;          // 24	소수점 둘째자리 절사
      case '25' : amt = Math.round(amt * 10 ) / 10; break;          // 25	소수점 둘째자리 반올림
      case '26' : amt = Math.ceil(amt * 10 ) / 10; break;           // 26	소수점 둘째자리 절상
      case '27' : amt = Math.floor(amt); break;                     // 27	소수점 첫째자리 절사
      case '28' : amt = Math.round(amt); break;                     // 28	소수점 첫째자리 반올림
      case '29' : amt = Math.ceil(amt); break;                      // 29	소수점 첫째자리 절상
      case '31' : amt = Math.floor(amt / 10000 ) * 10000; break;    // 31	10000원미만절사
      case '32' : amt = Math.ceil(amt / 10000 ) * 10000; break;     // 32	10000원미만절상
      case '33' : amt = Math.round(amt / 10 ) * 10; break;          // 33	10원미만반올림
      case '34' : amt = Math.round(amt / 100 ) * 100; break;        // 34	100원미만반올림
      case '35' : amt = Math.round(amt / 1000 ) * 1000; break;      // 35	1000원미만반올림
      case '36' : amt = Math.round(amt / 10000 ) * 10000; break;    // 36	10000원미만반올림
    }
    return amt;
  }

  /**
   * 채용)
   * 모집공고 default data 셋팅
   * @param {*} _recruit 모집공고
   * @param {*} _recruit_state 모집공고 코드피커 종류 (cp - 코드피커 / mcp - 멀티코드피커)
   * @param {*} _recpart 모집부문
   * @param {*} _recpart_state 모집부문 코드피커 종류 (cp - 코드피커 / mcp - 멀티코드피커)
   * @param {*} yy 년도
   * @returns 조회된 모집공고,모집부문
   */
  module.setRecruitData = function (_recruit, _recruit_state, _recpart, _recpart_state, yy) {
    let _recruitData = [];
    let _recpartData = [];
    let pblancNo = null;
    if (yy != "" && yy != null) {
      dews.api.get(dews.url.getApiUrl("HR","ReservationEnManagementRSTService","pblanc_no_setting"), {
        async: false,
        data : {
          pblanc_yy : yy
        }
      }).done(function(data) {
        if (data.length > 0) {
          pblancNo = data[0]["PBLANC_NO"];
          const obj = {
            PBLANC_NO: data[0]["PBLANC_NO"],
            PBLANCSJ_DC: data[0]["PBLANCSJ_DC"]
          };
          if(_recruit_state == "cp")_recruit.setData(obj);
          if(_recruit_state == "mcp")_recruit.setData([obj]);
          _recruitData = data;
        }
      });
    }

    if (pblancNo != "" && pblancNo != null) {
      dews.api.get(dews.url.getApiUrl("HR","ReservationEnManagementRSTService","rcrt_sect_no_setting"), {
        async: false,
        data : {
          pblanc_no : pblancNo
        }
      }).done(function(data) {
        if (data.length > 0) {
          const obj = {
            RCRT_SECT_NO: data[0]["RCRT_SECT_NO"],
            RCRT_SECT_DC: data[0]["RCRT_SECT_DC"]
          };
          if(_recpart_state == "cp")_recpart.setData(obj);
          if(_recpart_state == "mcp")_recpart.setData([obj]);
          _recpartData = data;
        }
      });
    }
    return {_recruitData : _recruitData, _recpartData : _recpartData}
  }

  /**
   * 출장)
   * 전자결재 상태 이미지
   * @returns {*}
   */
  module.getApprovalIcon = function () {
    return{
      "P01300":{ //전자결재상태코드[MA/P01300]
        "1":{"img":"/view/images/HR/hr.img_040_suspense.png", "color":"#A6A6A6"}, // 저장
        "2":{"img":"/view/images/HR/hr.img_040_write.png",    "color":"#0054FF"}, // 상신
        "3":{"img":"/view/images/HR/hr.img_040_suspense.png", "color":"#A6A6A6"}, // 진행
        "4":{"img":"/view/images/HR/hr.img_040_check.png",    "color":"#1DDB16"}, // 승인
        "5":{"img":"/view/images/HR/hr.img_040_cancel.png",   "color":"#FF0000"}, // 반려
        "6":{"img":"/view/images/HR/hr.img_040_cancel.png",   "color":"#FF0000"}, // 취소
        "7":{"img":"/view/images/HR/hr.img_040_suspense.png", "color":"#A6A6A6"}, // 보류
        "8":{"img":"/view/images/HR/hr.img_040_eva_write.png","color":"#CE723D"}, // 보관?
        "9":{"img":"/view/images/HR/hr.img_040_eva_write.png","color":"#CE723D"}  // 보관
      },
      "P00880":{ // 결재상태구분 [MA/P00880]
        "1":{"img":"/view/images/HR/hr.img_040_check.png",    "color":"#1DDB16"}, // 승인
        "2":{"img":"/view/images/HR/hr.img_040_suspense.png", "color":"#A6A6A6"}, // 미결
        "3":{"img":"/view/images/HR/hr.img_040_write.png",    "color":"#0054FF"}, // 신청
        "4":{"img":"/view/images/HR/hr.img_040_cancel.png",   "color":"#FF0000"}, // 반려
        "5":{"img":"/view/images/HR/hr.img_040_cancel.png",   "color":"#FF0000"}, // 승인취소
        "6":{"img":"/view/images/HR/hr.img_040_suspense.png", "color":"#A6A6A6"}  // 임시저장
      },
    };
  }

  /**
    * 출장)
    * 단위 설정 조회
    * @param {*} fp_cdBiztr 출장구분
    * @param {*} BST099_DC_VALUE BST099() 출장비항목분리여부
    */
  module.getUnitProcFgCd = function(fp_cdBiztr, BST099_DC_VALUE){
    var unitProcFgCdList
    dews.api.get(dews.url.getApiUrl('HR', 'PBMBST00100', 'pbmbst00100_get_unit_proc_fg_cd'), {
      async:false,
      data : {
        biztr_fg_cd : fp_cdBiztr,
        bst099 : BST099_DC_VALUE
      }
    }).done(function(data){
      unitProcFgCdList = data;
    })

    return unitProcFgCdList;
  }

  /**
    * 출장)
    * 단위처리
    * @param {*} e 그리드 정보
    * @param {*} unitProcFgCdList 단위처리 코드
    * @param {*} costItems 출장관리>출장신청>출장비항목 조회 ("HR", "PayrollBenefitsManagementBSTService", "pbmbst00200_biztr_costitem_list2")
  */
  module.amountUnitProcessing = function (e,unitProcFgCdList, costItems){
    var field = e.cell.field;
    var amt = e.row.data[e.cell.field];
    var class_cd;
    if(['OL_AMT','TRNSETC_AMT','TRNSCT_AMT'].indexOf(e.cell.field) > -1){
      var cost_item = costItems.filter(x => x.SETUP_DATA1_DC == '7');
      if(cost_item.length > 0){
        class_cd = cost_item[0].SYSDEF_CD;
      }
    }else {
      class_cd = e.cell.field.substring(12);
    }
    var UNIT_PROC_FG_arr = unitProcFgCdList.filter(x => x.BIZTREX_CLAS_CD == class_cd);
    var UNIT_PROC_FG_code

    if(UNIT_PROC_FG_arr.length > 0){
      UNIT_PROC_FG_code = UNIT_PROC_FG_arr[0].UNIT_PROC_FG_CD
    }else {
      UNIT_PROC_FG_code = '16'
    }
    switch (UNIT_PROC_FG_code){                                     // 16	정상
      case '11' : amt = Math.floor(amt); break;                     // 11	1원미만절사
      case '12' : amt = Math.ceil(amt); break;                      // 12	1원미만절상
      case '13' : amt = Math.floor(amt / 10 ) * 10; break;          // 13	10원미만절사
      case '14' : amt = Math.ceil(amt / 10 ) * 10; break;           // 14	10원미만절상
      case '15' : amt = Math.round(amt); break;                     // 15	반올림
      case '17' : amt = Math.floor(amt / 100 ) * 100; break;        // 17	100원미만절사
      case '18' : amt = Math.ceil(amt / 100 ) * 100; break;         // 18	100원미만절상
      case '19' : amt = Math.floor(amt / 1000 ) * 1000; break;      // 19	1000원미만절사
      case '20' : amt = Math.ceil(amt / 1000 ) * 1000; break;       // 20	1000원미만절상
      case '21' : amt = Math.floor(amt * 100 ) / 100; break;        // 21	소수점 셋째자리 절사
      case '22' : amt = Math.round(amt * 100 ) / 100; break;        // 22	소수점 셋째자리 반올림
      case '23' : amt = Math.ceil(amt * 100 ) / 100; break;         // 23	소수점 셋째자리 절상
      case '24' : amt = Math.floor(amt * 10 ) / 10; break;          // 24	소수점 둘째자리 절사
      case '25' : amt = Math.round(amt * 10 ) / 10; break;          // 25	소수점 둘째자리 반올림
      case '26' : amt = Math.ceil(amt * 10 ) / 10; break;           // 26	소수점 둘째자리 절상
      case '27' : amt = Math.floor(amt); break;                     // 27	소수점 첫째자리 절사
      case '28' : amt = Math.round(amt); break;                     // 28	소수점 첫째자리 반올림
      case '29' : amt = Math.ceil(amt); break;                      // 29	소수점 첫째자리 절상
      case '31' : amt = Math.floor(amt / 10000 ) * 10000; break;    // 31	10000원미만절사
      case '32' : amt = Math.ceil(amt / 10000 ) * 10000; break;     // 32	10000원미만절상
      case '33' : amt = Math.round(amt / 10 ) * 10; break;          // 33	10원미만반올림
      case '34' : amt = Math.round(amt / 100 ) * 100; break;        // 34	100원미만반올림
      case '35' : amt = Math.round(amt / 1000 ) * 1000; break;      // 35	1000원미만반올림
      case '36' : amt = Math.round(amt / 10000 ) * 10000; break;    // 36	10000원미만반올림
    }
    e.grid.setCellValue(e.row.index, field, amt, false);
  }

  /**
    * 출장)
    * 휴가 및 시간외근무 신청내역 존재여부 체크
    * @param {*} gridPayDetail gridPayDetail 그리드
  */
  module.checkOffday = function(gridPayDetail){
    var nm_list
    dews.api.post(dews.url.getApiUrl('HR', 'PBMBST00200', 'pbmbst00200_check_offdaily'), {
      async: false,
      data: {
        gridPayDetail : JSON.stringify(gridPayDetail)
        }
    }).done(function(data) {
      nm_list = data;
    }).fail(function (xhr, status, error) {
      nm_list = 'error';
      dews.error(error);
    });

    return nm_list;
  }

  /**
    * 출장)
    * 시간 포멧 변경
    * @param {*} time timepicker value
  */
  module.time60 = function(time){
    var hour = Number(time.substr(0,2));
    var minute = Number(time.substr(2,4));

    return ((hour * 60) + minute)
  }

  /**
    * 출장)
    * 날짜 포멧 변경
    * @param {*} date 날짜 데이터
  */
  module.DtToStr = function(date){
    if(typeof(date) == 'string'){
      if(date.length > 10){
        return dews.date.format(new Date(date),'yyyyMMdd');
      }else {
        return date.replace(/[^0-9]/g,'');
      }
    }else {
      return dews.date.format(date, 'yyyyMMdd');
    }
  }

  /**
    * 출장)
    * 숫자 null 체크
    * @param {*} checkNumber
  */
  module.isEmptyNumber = function(checkNumber){
    if(checkNumber == undefined || checkNumber == null || checkNumber == "") {
      return 0;
    }
    return Number(checkNumber);
  }

  /**
    * 출장)레드캡
    * 인증토큰 발급 - 자동로그인, 마이페이지와 같이 사원정보가 필요한 상황은 emp_no를 포함해 호출
    * @param {*} emp_no 사번 (null 가능)
  */
  module.getAccessTokenByRedcap = function(emp_no){
    let token;
    try {
      dews.api.post(dews.url.getApiUrl('HR', 'PBMBST_RedCap', 'access_token_by_redcap'), {
        async:false,
        data : {
          emp_no : emp_no || ""
        }
      }).done(function(data){
        token = JSON.parse(data);
        if(!token.access_token) throw new Error(`RedCap Tour :  ${token.error_description}`);
      }).fail(function (xhr, status, error) {
        dews.alert(error,"error");
        dews.ui.loading.hide();
      });
      return token.access_token
    } catch (error) {
      console.log(`RedCap Tour : ${token}`);
      dews.alert(error,'warning');
      dews.ui.loading.hide();
    }
  }

  /**
    * 출장)레드캡
    * 출장자, 신청자 정보 전송
    * @param {*} access_token getAccessTokenByRedcap()
    * @param {*} biztr_no 출장번호
    * @param {*} req_emp 사번
    * @param {*} biztr_data 출장관련 데이터
    * @param {*} menuID 메뉴명
   * */
  module.sendHRInfoByRedcap = function(access_token, biztr_no, req_emp, biztr_data, menuID){
    let token;
    try {
    dews.api.post(dews.url.getApiUrl("HR", "PBMBST_RedCap", "send_HR_info_by_redcap"),{
      async : false,
      data :{
        access_token : access_token,
        biztr_no : biztr_no,
        req_emp : req_emp, // 신청자
        biz_emp : biztr_data.EMP_NO, // 출장자
        biztr_st_dt : dews.date.format(biztr_data.BIZTR_START_DT, 'yyyyMMdd'), // 출장 시작일
        biztr_en_dt : dews.date.format(biztr_data.BIZTR_END_DT, 'yyyyMMdd'), // 출장 종료일
        biztr_doc_tp : biztr_data.BIZTR_DOC_TP, // 출장문서 유형
        biztr_req_fg : biztr_data.REQ_FG, // 신청구분
        biztr_sq_no : biztr_data.SQ_NO, // 순번번호
        menuID : menuID
      }
    }).done(function(result){

        token = JSON.parse(result);
        if(token.resultData.status === 'ERROR') throw new Error(`RedCap Tour에 문의하세요(${token.resultData.message.code}:${token.resultData.message.error_description})`);

    }).fail(function (message, status, error) {
      const error_msg = error.split(':');
      dews.ui.loading.hide();
      if(error_msg[0] == 'required error'){
        dews.alert( dews.string.format("RedCap Tour 이용에 필요한 정보가 부족합니다.\n{0}님의 정보(주민등록상생년월일, 비상연락)를 추가해 주세요",error_msg[1]),'warning');
      }else{
        dews.error({ message: error });
      }

    });
    /*
      {
        btms_access_token : '' -> 본인꺼 예약시 사용 및 예약 확인용
        obt_access_token : ''  -> 타인꺼 예약시 사용
      }
    */
    return token.resultData;
    }catch(error){
      console.log(`RedCap Tour : ${token}`);
      dews.alert(error,'warning');
      dews.ui.loading.hide();
    }
  }

  module.getEvaEmpInfo = function(eval_yy, gemp_no) {
    let info_list = new Array();
    dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_eval_emp_info2'), {
      async: false,
      data: {
        eval_yy: eval_yy,
        gemp_no: gemp_no
      }
    }).done(function (data) {
      if (data.length > 0) {
        info_list = data;
      }
    }).fail(function (xhr, status, error) {
      dews.error('평가사원정보를 불러오는데 실패하였습니다.');
    });
    return info_list;
  }

  /**
   * 성과관리
   * 평가환경설정
   * @returns object
   */
    module.getEvaConfig = function() {
      let config = {};
      dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_config'), {
        async: false
      }).done(function (data) {
        if (data.length > 0) {
          $.each(data, function(idx, obj) {
            if(!config.hasOwnProperty(obj.CONFIG_CD)) {
              config[obj.CONFIG_CD] = [];
            }
            config[obj.CONFIG_CD].push(obj);
          });
        }
      }).fail(function (xhr, status, error) {
        dews.error('평가환경설정을 불러오는데 실패하였습니다.');
      });
      return config;
    }
    /**
     * 성과관리
     * 평가연도 setting(평가계획등록 기준)
     * @returns String
     */
    module.setEvalYy = function(eval_tp_cd) {
      let eval_yy;
      dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'defalt_get_eval_yy'), {
        async: false,
        data: {
          eval_tp_cd: eval_tp_cd
        }
      }).done(function (data) {
        eval_yy = data;
      }).fail(function (xhr, status, error) {
        dews.error('평가연도를 불러오는데 실패하였습니다.');
      });
      return eval_yy;
    }
    /**
     * 성과관리
     * 평가시기 DDL setting(평가계획등록 기준)
     * @param {*} eval_tp_cd
     * @returns List<Map<String, Object>>
     */
    module.setEvalYm = function(eval_tp_cd) {
      let eval_ym
      dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_eval_ym_ddl'), {
        async: false,
        data: {
          eval_tp_cd: eval_tp_cd
        }
      }).done(function (data) {
        eval_ym = data;
      }).fail(function (xhr, status, error) {
        dews.error('평가시기를 불러오는데 실패하였습니다.');
      });
      return eval_ym;
    }
    /**
     * 성과관리
     * 평가시기 setting(오늘날짜 기준)
     * @param {*} eval_tp_cd 
     * @returns String
     */
    module.getEvalYm = function(eval_tp_cd) {
      present_month = Number(dews.date.format(new Date(),'MM'));
      let eval_ym;
      dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_eval_ym_ddl'), {
        async: false,
        data: {
              eval_tp_cd: eval_tp_cd
              }
        }).done(function (data) {
            const field_cd = data[0].FIELD_CD;
            switch(field_cd) {
              //연도
              case '1'  : eval_ym = '00';
                          break;
              //상반기-하반기
              case '2'  : if(1 <= present_month && present_month <= 6)        eval_ym = '06';
                          else if(7 <= present_month && present_month <= 12)  eval_ym = '12';
                          break;
              //1분기-2분기-3분기-4분기
              case '3'  : if(1 <= present_month && present_month <= 3)        eval_ym = '03';
                          else if(4 <= present_month && present_month <= 6)   eval_ym = '06';
                          else if(7 <= present_month && present_month <= 9)   eval_ym = '09';
                          else if(10 <= present_month && present_month <= 12) eval_ym = '12';
                          break;
              //월
              case '4'  : eval_ym = String(present_month);
                          break;
              default   : eval_ym = '';
            }
        }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error("평가주기를 불러오는데 실패하였습니다.");
        });
        return eval_ym;
    }
  /**
   * 성과관리 
   * 피평가자 검증
   */
  module.getEvalAuth = function(eval_yy, eval_ym, eval_tp_cd) {
    let auth_result = {auth:'NULL',auth_error_msg:'권한이 없는 사원입니다.'};
    dews.api.post(dews.url.getApiUrl('HR', 'HrEvalCommon', 'eval_authority'), {
      async: false,
      data: {
        eval_yy: eval_yy,
        eval_ym: eval_ym,
        eval_tp_cd: eval_tp_cd
      }
    }).done(function (data) {
      if (data.length > 0) {
        auth = data;
        auth_result = {auth:data, auth_error_msg:'error'};
      }
    }).fail(function (xhr, status, error) {
      auth_result = {auth:'NULL',auth_error_msg:error};
    });
    return auth_result;
  }

  /**
   * 성과관리 
   * 평가자(직책자) 검증
   */
  module.getEvlorAuth = function(eval_yy, eval_ym, eval_tp_cd) {
    let auth_result = {auth:'NULL',auth_error_msg:'권한이 없는 사원입니다.'};
    dews.api.post(dews.url.getApiUrl('HR', 'HrEvalCommon', 'evlor_authority'), {
      async: false,
      data: {
        eval_yy: eval_yy,
        eval_ym: eval_ym,
        eval_tp_cd: eval_tp_cd
      }
    }).done(function (data) {
      if (data.length > 0) {
        auth_result = {auth:data, auth_error_msg:'error'};
      }
    }).fail(function (xhr, status, error) {
      auth_result = {auth:'NULL',auth_error_msg:error};
    });
    return auth_result;
  }

  /**
   * 성과관리 
   * 평가사원정보
   */
  module.getEvaEmpUnit = function(eval_yy, gemp_no, eval_tp_cd) {
    let unit_list = new Array();
    dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_eval_unit_cd'), {
      async: false,
      data: {
        eval_yy: eval_yy,
        gemp_no: gemp_no,
        eval_tp_cd: eval_tp_cd
      }
    }).done(function (data) {
      if (data.length > 0) {
        unit_list = data;
      }
    }).fail(function (xhr, status, error) {
      dews.error('해당사원의 평가단위가 없습니다.');
    });
    return unit_list;
  }

  /**
   * 성과관리 
   * 평가사원정보
   */
  module.getEvaGroupUnit = function(eval_yy, eval_grp_cd, eval_tp_cd) {
    let unit_list = new Array();
    dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_eval_unit_cd2'), {
      async: false,
      data: {
        eval_yy: eval_yy,
        eval_grp_cd: eval_grp_cd,
        eval_tp_cd: eval_tp_cd
      }
    }).done(function (data) {
      if (data.length > 0) {
        unit_list = data;
      }
    }).fail(function (xhr, status, error) {
      dews.error('평가단위 조회중 오류가 발생하였습니다.');
    });
    return unit_list;
  }

  /**
   * 성과관리 
   * 평가사원정보
   */
  module.getEvaEmpInfo = function(eval_yy, gemp_no, eval_tp_cd, eval_unit_cd) {
    let info_list = new Array();
    dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_eval_emp_info2'), {
      async: false,
      data: {
        eval_yy: eval_yy,
        gemp_no: gemp_no,
        eval_tp_cd: eval_tp_cd,
        eval_unit_cd: eval_unit_cd
      }
    }).done(function (data) {
      if (data.length > 0) {
        info_list = data;
      }
    }).fail(function (xhr, status, error) {
      dews.error('평가사원정보를 불러오는데 실패하였습니다.');
    });
    return info_list;
  }

  /**
   * 성과관리
   * 목표차수, 실적차수, 대상자차수 MAX값만 찾아옴
   * @param {*} 
   * @returns 
   */
  module.getMaxSq = function(eval_yy, eval_ym, eval_tp_cd , emp_no, eval_unit_cd) {
    let max_sq_list
    dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_max_sq'), {
      async: false,
      data: {
        eval_yy: eval_yy,
        eval_ym: eval_ym,
        eval_tp_cd: eval_tp_cd,
        emp_no: emp_no,
        eval_unit_cd : eval_unit_cd
      }
    }).done(function (data) {
      max_sq_list = data;
    }).fail(function (xhr, status, error) {
      dews.error(error);
    });
    return max_sq_list;
  }
    /**
     * 성과관리
     * 평가유형별(척도별) 등급 가져옴.
     * @param {*} ydst_fg_cd 
     * @returns 
     */
    module.getGrade = function(ydst_fg_cd) {
      let grade_list
      dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_grade'), {
        async: false,
        data: {
          ydst_fg_cd: ydst_fg_cd
        }
      }).done(function (data) {
        if(data.length>0) {
          grade_list = data;
        } else {
          dews.error('척도기준이 입력되지 않았습니다. \n척도기준을 확인해주세요.');
        }
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });
      return grade_list;
    }
    /**
       * 성과관리
       * 단일 평가대상자의 평가자사원번호 가져옴
       * row순서대로 본인, 1차평가자, 2차평가자... 임
       * @param {*} eval_yy 
       * @param {*} emp_no 
       * @param {*} eval_tp_cd 
       * @param {*} eval_sq 
       * @returns 
       */
    module.getEvlorEmp = function(eval_yy, emp_no, eval_tp_cd, eval_sq) {
      let evlor
      dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'get_evlor_emp'), {
        async: false,
        data: {
          eval_yy: eval_yy,
          emp_no: emp_no,
          eval_tp_cd: eval_tp_cd,
          eval_sq: eval_sq
        }
      }).done(function (data) {
        if(data.length>0) {
          evlor = data;
        } 
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });
      return evlor;
    }
    /**
     * EVA013 -> 소수점단위 처리
     * @param {*} total_score 
     */
    module.scoreProcess = function(total_score) {
      let score = 0;
      dews.api.get(dews.url.getApiUrl('HR', 'HrEvalCommon', 'eva103_score_process'), {
        async : false,
        data : {
          score : total_score
        }
      }).done(function (data){
        score = data;
      }).fail(function (message) {
        dews.ui.snackbar.error(message + "총 점수계산 실패");
      });
      return score;
    }

  module.rgba2hex = function (orig) {
    return rgba2hex(orig);
  }

  newModule[moduleCode] = module;
  window.derp = $.extend(true, derp, newModule);

  console.debug("hr.common.js", dews.string.format("[ LOAD COMPLETE :: version={0} ]", version));

})(window.dews, window.derp || {}, jQuery);

function rgba2hex(orig) {
  let rgb = orig.replace(/\s/g, '').match(/^rgba?\((\d+),(\d+),(\d+),?([^,\s)]+)?/i);
  let alpha = (rgb && rgb[4] || '').trim();
  let hex = rgb ?
    ("0" + parseInt(rgb[1], 10).toString(16)).slice(-2) +
    ("0" + parseInt(rgb[2], 10).toString(16)).slice(-2) +
    ("0" + parseInt(rgb[3], 10).toString(16)).slice(-2) : orig;

  if (alpha == '') {
    alpha = 1;
  }
  // multiply before convert to HEX
  alpha = ((alpha * 255) | 1 << 8).toString(16).slice(1)
  hex = '#' + alpha + hex;

  return hex;
}

(function () {
  let gHrDbl = false;
  $(document).on("keydown", function (e) {
    // console.log(gHrDbl, e);
    if (e.altKey && e.ctrlKey && e.shiftKey && e.keyCode === 72) {
      gHrDbl = true;
    } else if (gHrDbl && e.altKey && e.ctrlKey && e.shiftKey && e.keyCode === 82) {
      gHrDbl = false;
      dews.ui.dialog("H_HR_BHS_C", {
        url: "~/codehelp/HR/H_HR_BHS_C",
        title: "ⓐ",
        width: 230,
        height: 120,
        initData: {},
      }).open();
    } else if (gHrDbl && e.altKey && e.ctrlKey && e.shiftKey && e.keyCode === 67) {
      gHrDbl = false;
      dews.ui.openCustomPage('PBMPAC00100_CP',
        {
          title: '코드조회',
          url: dews.url.getViewUrl('HR', 'PBMPAC00100_CP'),
          data: {},
          exists: function (cancelable) {
            return dews.confirm('이미 페이지가 열려있습니다.\n새로 여시겠습니까?')
              .no(function () {
                cancelable.cancel();
              })
          }
        });
    } else {
      gHrDbl = false;
    }
  })
})();
//# sourceURL=hr.common.js
