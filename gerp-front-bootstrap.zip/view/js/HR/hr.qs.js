/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
var hrQsObjSearch = {
  idx: 0,
  field: null,
};

(function (dews, gerp, $) {
  var module = {};
  var moduleCode = "HR";
  var newModule = {};

  dews.ready(function () {
    var dewsQsSelf = this;

    dews.ui.shortcuts.setup([
      {
        keyCode: 70,  // f
        shift: false,
        alt: false,
        ctrl: true,
        $target: dewsQsSelf.$content.find(".dews-ui-grid"),
        handler: function (e) {
          if (dewsQsSelf[e.currentTarget.id].options.qsUse) {
            e.preventDefault();
            gerp.HR.openQuickSearchDialog(dewsQsSelf[e.currentTarget.id]);
          }
        }
      }
    ]);

    console.log("[ hr.qs.js ]");
  });

  module.openQuickSearchDialog = function (qsGrid) {
    if ($("div#HR_QUICKSEARCH.dews-ui-dialog").length != 0) {
      $("div#HR_QUICKSEARCH.dews-ui-dialog button#btnCancel").trigger("click");
    }

    var qsGridTitle = qsGrid.options.qsTitle;

    var qsDialog = dews.ui.dialog("HR_QUICKSEARCH", {
      url: "/view/HR/HR_QUICKSEARCH",
      // url: "/view/HR/PBMPAC/HR_QUICKSEARCH.html",
      title: qsGridTitle != null ? qsGridTitle : "Quick Search",
      width: 390,
      height: 140,
      position: { left: 50, top: 100 },
      modal: false,
      initData: { grid: qsGrid },
      ok: function (data) {
      }
    });

    setTimeout(function () {
      qsDialog.open();
    }, 200);
  };

  module.setQsGrid = function (hrQsGrid, hrQsTitle) {
    hrQsGrid.findQsText = findQsText;
    hrQsGrid.setQsControl = setQsControl;
    hrQsGrid.options.qsUse = true;
    hrQsGrid.options.qsTitle = hrQsTitle != null ? hrQsTitle : null;
  }

  var setQsControl = function (hrQsCtrl) {
    var hrQsGrid = this;

    hrQsCtrl.on("keydown", function (e) {
      if (e.keyCode == 13) {
        e.preventDefault();
        hrQsGrid.findQsText(hrQsCtrl.text(), e.shiftKey ? -1 : 1);
      }
    });
  }

  var findQsText = function (hrQsSearchText, hrQsFgPNValue) {
    if (hrQsSearchText == null || $.trim(hrQsSearchText) == "") {
      return false;
    }

    var hrQsGrid = this;
    var hrQsArrText = hrQsSearchText.split("|");
    var hrQsReg;
    var hrQsTagetFields = $.grep(hrQsGrid.columns, function (d) {
      return d.visible != false;
    });
    var hrQsTagetField;
    var hrQsDataItems = hrQsGrid.dataItems();
    var hrQsDataItem;
    var hrQsIdx = -1;
    var hrQsField;
    var hrQsTmpI, hrQsTmpJ, hrQsTmpFieldName;
    var hrQsTmpIFrom, hrQsTmpITo;

    hrQsFgPNValue = hrQsFgPNValue != 1 && hrQsFgPNValue != -1 ? 1 : hrQsFgPNValue;

    hrQsTmpI = hrQsGrid.select();
    hrQsTmpFieldName = hrQsGrid._grid.getCurrent().fieldName;
    hrQsTmpJ = hrQsTagetFields.findIndex(function (data) {
      return data.field == hrQsTmpFieldName;
    });

    // if (hrQsFgPNValue == 1) {
    //   if (hrQsTmpJ == hrQsTagetFields.length - 1) {
    //     hrQsTmpJ = 0;
    //     if (hrQsTmpI == hrQsDataItems.length - 1) {
    //       hrQsTmpI = 0;
    //       dews.ui.snackbar.warning("일치하는 내용이 없습니다.");
    //       return false;
    //     } else {
    //       hrQsTmpI++;
    //     }
    //   } else {
    //     hrQsTmpJ++;
    //   }
    // } else {
    //   if (hrQsTmpJ == 0) {
    //     hrQsTmpJ = hrQsTagetFields.length - 1;
    //     if (hrQsTmpI == 0) {
    //       hrQsTmpI = hrQsDataItems.length - 1;
    //       dews.ui.snackbar.warning("일치하는 내용이 없습니다.");
    //       return false;
    //     } else {
    //       hrQsTmpI--;
    //     }
    //   } else {
    //     hrQsTmpJ--;
    //   }
    // }

    hrQsTmpIFrom = hrQsTmpI;
    if (hrQsFgPNValue == 1) {
      hrQsTmpITo = hrQsDataItems.length - 1;
    } else {
      hrQsTmpITo = 0;
    }

    hrQsTmpJFrom = hrQsTmpJ;
    if (hrQsFgPNValue == 1) {
      hrQsTmpJTo = hrQsTagetFields.length - 1;
    } else {
      hrQsTmpJTo = 0;
    }

    for (i = hrQsTmpIFrom; ((hrQsFgPNValue == 1 && i <= hrQsTmpITo) || (hrQsFgPNValue == -1 && i >= hrQsTmpITo)) && (hrQsIdx == -1); i += hrQsFgPNValue) {
      hrQsDataItem = hrQsDataItems[i];
      for (j = hrQsTmpJFrom; ((hrQsFgPNValue == 1 && j <= hrQsTmpJTo) || (hrQsFgPNValue == -1 && j >= hrQsTmpJTo)) && (hrQsIdx == -1); j += hrQsFgPNValue) {
        hrQsTagetField = hrQsTagetFields[j];
        $.each(hrQsArrText, function (k, v) {
          hrQsReg = new RegExp(v, "g");
          if (hrQsDataItem[hrQsTagetField.field] != null && hrQsDataItem[hrQsTagetField.field].match(hrQsReg) != null) {
            if (i != hrQsObjSearch.idx || hrQsTagetField.field != hrQsObjSearch.field) {
              hrQsIdx = i;
              hrQsField = hrQsTagetField.field;
              hrQsObjSearch.idx = hrQsIdx;
              hrQsObjSearch.field = hrQsField;
            }
          }

          if (hrQsIdx > -1) {
            return false;
          }
        });
      }

      if (hrQsFgPNValue == 1) {
        hrQsTmpJFrom = 0;
      } else {
        hrQsTmpJFrom = hrQsTagetFields.length - 1;
      }
    }

    if (hrQsIdx > -1) {
      hrQsGrid.select(hrQsIdx);
      hrQsGrid._grid.setSelection({
        style: "rows",
        startRow: hrQsIdx,
        startColumn: hrQsField,
        endRow: hrQsIdx,
        endColumn: hrQsField,
      });
    } else {
      dews.ui.snackbar.warning("일치하는 내용이 없습니다.");
    }
  }

  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);


//# sourceURL=hr.qs.js
