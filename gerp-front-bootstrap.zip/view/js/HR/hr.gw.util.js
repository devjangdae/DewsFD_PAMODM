(function (dews, gerp, $) {
  var module = {};
  var moduleCode = "CM";
  var version = "1.0.220607.02";

  console.debug("hr.gw.util.js", dews.string.format("[ LOAD START :: version={0} ]", version));

  module.EltrAthzUtil = {
    // contentsType : 본문Html 종류 (inner : 에디터에 넣는다 , outer : _DFINTER_ 가 먹는다)
    // 1.에디터 없는 경우 => 기안자가 결재본문를 수정 할 수 없는 경우(contentsType : "outer")
    //   기안 양식 => HTML 에 <TR><td>_DFINTER_</TD></TR> 로 되어 있어야 함
    // 2.에디터 있는 경우 => 기안자가 결재본문를 수정 해야 할 경우 (contentsType : "inner")
    //   기안 양식 => HTML 에 <TR><td style="font-family:굴림;font-size:9pt;color:rgb(0, 0, 0);line-height:1.2;" id="divFormContents">_DF11_</td></TR> 로 되어 있어야 함
    createEltrAthz: function (url, param, widthYn) {
      var callback;
      var width = 981;
      var height = 769;
      var dummyItem = "";

      if (param.hasOwnProperty("widthYn")) {
        widthYn = param.widthYn;
      }
      if (param.hasOwnProperty("width")) {
        width = param.width;
      }
      if (param.hasOwnProperty("height")) {
        height = param.height;
      }
      if (param.hasOwnProperty("close")) {
        callback = param.close;
      }
      if (param.hasOwnProperty("dummyItem")) {
        dummyItem = param.dummyItem;
      }
      if (param.hasOwnProperty("params")) {
        param = param.params;
      }

      var compCd = window.gerp.CM.EltrAthzUtil.getCompCd(param.compSeq);
      var eltrAthzPopup;
      var $eltrAthzForm = $("<form id=\"eltrAthzForm\" name=\"eltrAthzForm\" enctype=\"application/json\" method=\"POST\">").appendTo("body");
      if (param.aesKey === null || param.aesKey === undefined) {
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "aesKey", name: "aesKey" }).val("1023497555960596")); // 1023exe497555960596: bizBoxA default key
      } else {
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "aesKey", name: "aesKey" }).val(param.aesKey));
      }

      $eltrAthzForm.append($("<input>", { type: "hidden", id: "compSeq", name: "compSeq" }).val(param.compSeq));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "compCd", name: "compCd" }).val(compCd));

      $eltrAthzForm.append($("<input>", { type: "hidden", id: "approKey", name: "approKey" }).val(param.approKey));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "outProcessCode", name: "outProcessCode" }).val(param.outProcessCode));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "formId", name: "formId" }).val(param.formId));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "docId", name: "docId" }).val(param.docId));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "loginId", name: "loginId" }).val(param.loginId));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "mod", name: "mod" }).val(param.mod));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "X-Authenticate-Token", name: "X-Authenticate-Token" }).val(JSON.parse(dews.ui.page.token).access_token)); // 토큰정보 필수
      // 원복 contentsStr-subjectStr 값이 다른경우 제목바인딩이 안됨 에디터 내부의 값은값이 문제인 경우 contentsType:"outer"로 사용
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "contentsStr", name: "contentsStr" }).val(param.title));
      //그룹웨어에서 인코딩한걸로 받기로 수정
      // param.title 존재시 contentsEnc:'U' 필수.
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "subjectStr", name: "subjectStr" }).val(encodeURIComponent(param.title)));
      //$eltrAthzForm.append($("<input>",{type:"hidden",id:"subjectStr",name:"subjectStr"}).val(param.title));
      // 첨부파일
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "fileKey", name: "fileKey" }).val(param.fileKey));
      // 참조문서 (refDocId(배열구분자 :,(콤마))
      if (param.refDocId === null || param.refDocId === undefined) {
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "refDocId", name: "refDocId" }).val(""));
      } else {
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "refDocId", name: "refDocId" }).val(param.refDocId));
      }
      // 동서발전 전용 파람
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "appLineList", name: "appLineList" }).val(param.appLineList));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "receiveList", name: "receiveList" }).val(param.receiveList));
      if (param.mod == "W") {//작성
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "contentsEnc", name: "contentsEnc" }).val(param.contentsEnc));
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "contentsType", name: "contentsType" }).val(param.contentsType));
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "dummyItem", name: "dummyItem" }).val(dummyItem));
      } else if (param.mod == "V") {//보기,삭제
        // $eltrAthzForm.append($("<input>",{type:"hidden",id:"docId",name:"docId"}).val(param.docId));
      }
      if (widthYn) {
        eltrAthzPopup = window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");
      } else {
        eltrAthzPopup = window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");
      }
      try {
        eltrAthzPopup.focus();
      } catch (exception) {
        alert("그룹웨어 팝업이 차단되어있습니다.");
      }

      $("#eltrAthzForm").attr("target", "eltrAthzPopup");
      $("#eltrAthzForm").attr("action", url);
      $("#eltrAthzForm").submit();
      $("#eltrAthzForm").remove();

      if (self.$(".dews-ui-loading").length > 0) {
        dews.ui.loading.hide();
      }

      setTimeout(function () {
        dews.ui.loading.show({
          text: "전자결재 진행 중입니다."
        })
      });

      var popupTick = setInterval(function () {
        if (eltrAthzPopup.closed) {
          clearInterval(popupTick);
          dews.ui.loading.hide();
          if (callback && $.isFunction(callback)) {
            callback();
          }
        }
      }, 500);
      return eltrAthzPopup;
    },

    deletEltrAthz: function (url, param, widthYn) {
      var eltrAthzPopup;
      var callback;
      var width = 981;
      var height = 769;

      if (param.hasOwnProperty("widthYn")) {
        widthYn = param.widthYn;
      }
      if (param.hasOwnProperty("width")) {
        width = param.width;
      }
      if (param.hasOwnProperty("height")) {
        height = param.height;
      }
      if (param.hasOwnProperty("close")) {
        callback = param.close;
      }
      if (param.hasOwnProperty("params")) {
        param = param.params;
      }

      var compCd = window.gerp.CM.EltrAthzUtil.getCompCd(param.compSeq);
      var $eltrAthzForm = $("<form id=\"eltrAthzForm\" name=\"eltrAthzForm\" enctype=\"application/json\" method=\"POST\">").appendTo("body");

      if (param.aesKey === null || param.aesKey === undefined) {
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "aesKey", name: "aesKey" }).val("1023497555960596")); // 1023497555960596: bizBoxA default key
      } else {
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "aesKey", name: "aesKey" }).val(param.aesKey));
      }

      $eltrAthzForm.append($("<input>", { type: "hidden", id: "compSeq", name: "compSeq" }).val(param.compSeq)); // 그룹웨어 회사코드 조건필수
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "compCd", name: "compCd" }).val(compCd)); // 그룹웨어 회사코드 조건필수

      $eltrAthzForm.append($("<input>", { type: "hidden", id: "approKey", name: "approKey" }).val(param.approKey)); // approKey 필수
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "docId", name: "docId" }).val(param.docId)); // docId 선택
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "outProcessCode", name: "outProcessCode" }).val(param.outProcessCode)); // outProcessCode, formId 둘중 하나 필수
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "formId", name: "formId" }).val(param.formId));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "loginId", name: "loginId" }).val(param.loginId)); // loginId, empSeq, erpSeq 셋중 하나 필수
      // $eltrAthzForm.append($("<input>",{type:"hidden",id:"loginId",name:"loginId"}).val(param.empSeq));
      // $eltrAthzForm.append($("<input>",{type:"hidden",id:"loginId",name:"loginId"}).val(param.erpSeq));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "mod", name: "mod" }).val(param.mod)); // mod: "D" 필수
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "X-Authenticate-Token", name: "X-Authenticate-Token" }).val(JSON.parse(dews.ui.page.token).access_token)); // 토큰정보 필수

      if (param.mod == "D") {//삭제
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "contentsEnc", name: "contentsEnc" }).val(param.contentsEnc));
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "contentsStr", name: "contentsStr" }).val(param.contentsStr));
        $eltrAthzForm.append($("<input>", { type: "hidden", id: "contentsType", name: "contentsType" }).val(param.contentsType));
      }

      if (widthYn) {
        eltrAthzPopup = window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=981,height=769,scrollbars=yes");
      } else {
        eltrAthzPopup = window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=940,height=769,scrollbars=yes");
      }
      try {
        eltrAthzPopup.focus();
      } catch (exception) {
        alert("그룹웨어 팝업이 차단되어있습니다.");
      }

      $("#eltrAthzForm").attr("target", "eltrAthzPopup");
      $("#eltrAthzForm").attr("action", url);
      $("#eltrAthzForm").submit();
      $("#eltrAthzForm").remove();

      if (self.$(".dews-ui-loading").length > 0) {
        dews.ui.loading.hide();
      }


      setTimeout(function () {
        dews.ui.loading.show({
          text: "전자결재 진행 중입니다."
        })
      });

      var popupTick = setInterval(function () {
        if (eltrAthzPopup.closed) {
          clearInterval(popupTick);
          dews.ui.loading.hide();
          if (callback && $.isFunction(callback)) {
            callback();
          }
        }
      }, 500);

      return eltrAthzPopup;
    },

    createEltrAthz_amaranth: function (param, widthYn) {
      var callback;
      var eltrAthzPopup;

      var width = 981;
      var height = 769;

      if (param.hasOwnProperty("widthYn")) {
        widthYn = param.widthYn;
      }
      if (param.hasOwnProperty("width")) {
        width = param.width;
      }
      if (param.hasOwnProperty("height")) {
        height = param.height;
      }
      if (param.hasOwnProperty("close")) {
        callback = param.close;
      }
      if (param.hasOwnProperty("params")) {
        param = param.params;
      }

      var reqData = {
        loginId: param.loginId,
        groupSeq: param.groupSeq,
        outProcessCode: param.outProcessCode,
        approKey: param.approKey,
        formId: param.formId,
        docId: param.docId,
        mod: param.mod,
        fileKey: param.fileKey,
        contentsEnc: param.contentsEnc,
        contentsType: param.contentsType,
        appLineList: param.appLineList,
        receiveList: param.receiveList,
        itemList: param.itemList,
        contentsStr: param.contentsStr
      };

      // 기존 loading 결제창 제거("전자결재 진행 중입니다." 라는 메세지로 보이도록)
      if (self.$(".dews-ui-loading").length > 0) {
        dews.ui.loading.hide();
      }

      // loading show
      setTimeout(function () {
        dews.ui.loading.show({
          text: "전자결재 진행 중입니다."
        })
      });

      if(this.getCookieInfo(encodeURIComponent('am10:auth:token')) && false){//20230420 쿠키정보에 대한 portal.post 사용은 추가 테스트가 더 필요함
        // reqData['X-Authenticate-Token'] = access_token;
        dews.portal.post('/gw/gw016A01',
        {
          type:"popup",
          popupCode:"UBAP036",
          groupSeq:param.groupSeq,
          loginIdEnc:param.loginId,
          MicroModuleCode:"eap",
          appParams:reqData
        }
        ).then(data => {
          var url = data.resultData.fullUrl;
          eltrAthzPopup = window.open(url, "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");

          try {
            eltrAthzPopup.focus();
          } catch (exception) {
            dews.alert("그룹웨어 팝업이 차단되어있습니다.", "warning");
          }

          var popupTick = setInterval(function () {
            if (eltrAthzPopup.closed) {
              clearInterval(popupTick);
              dews.ui.loading.hide();
              if (callback && $.isFunction(callback)) {
                callback();
              }
            }
          }, 500);

          return eltrAthzPopup;
        });
      }else{

        dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getApprovalSsoUrl"), {
          async: false,
          data: {
            reqData: JSON.stringify(reqData)
          }
        }).done(function (res) {
          if (param.mod === "D") {
            if (res.resultCode === "0") {
              window.gerp.CM.EltrAthzUtil.eltrLoadingClosing();

              dews.alert("결재문서 삭제 완료");
            }
          } else {
            if(res.resultData == null){
              dews.ui.loading.hide();
              dews.error(res.resultMsg, false);
              return false;
            }
            var url = res.resultData.fullUrl;
            eltrAthzPopup = window.open(url, "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");

            try {
              eltrAthzPopup.focus();
            } catch (exception) {
              dews.alert("그룹웨어 팝업이 차단되어있습니다.", "warning");
            }

            var popupTick = setInterval(function () {
              if (eltrAthzPopup.closed) {
                clearInterval(popupTick);
                dews.ui.loading.hide();
                if (callback && $.isFunction(callback)) {
                  callback();
                }
              }
            }, 500);
          }

        }).fail(function (xhr, status, error) {
          window.gerp.CM.EltrAthzUtil.eltrLoadingClosing();
          dews.ui.snackbar.warning(error, false);
        });

        return eltrAthzPopup;
      }
    },
    getCookieInfo : function(key) {
      let idx = document.cookie.indexOf(`${key}=`);
      if (idx > -1) {
          let lastIdx = document.cookie.indexOf(';', idx);
          if (lastIdx === -1) {
              lastIdx = document.cookie.length;
          }
          return document.cookie.substring(idx, lastIdx).replace(`${key}=`, '');
      } else {
          return;
      }
    },
    eltrLoadingClosing: function () {
      var eltrLoadingTick = setInterval(function () {
        clearInterval(eltrLoadingTick);
        dews.ui.loading.hide();
      }, 500);
    },

    getCompCd:function(company_cd){
      var compCd;
      dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getCompCd"), {
        async: false,
        data: {
          company_cd: company_cd
        }
      }).done(function (data) {
        compCd = data;
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.warning(error, false);
      });
      return compCd;
    },

    getGwFormId: function (formId) {
      var returnGwFormId;
      if (formId === undefined || formId == "") {
        alert("getFormId의 form_id는 null일 수 없습니다.");
      }
      dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getGwFormId"), {
        async: false,
        data: {
          formId: formId,
        }
      }).done(function (data) {
        returnGwFormId = data;
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.warning(error, false);
      });
      return returnGwFormId;
    },

    getBizBoxLoginId: function () {
      var returnId;
      dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getBizBoxLoginId"), {
        async: false,
      }).done(function (data) {
        returnId = data;
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.warning("로그인 id 조회를 실패하였습니다.", false);
      });
      return returnId;
    },

    getApprovalUrl: function (gubun) {
      var returnUrl;
      dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getApprovalUrl"), {
        async: false,
        data: {
          gubun: gubun,
        }
      }).done(function (data) {
        returnUrl = data;
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.warning("호출 url 조회를 실패하였습니다.", false);
      });
      return returnUrl;
    },

    getGwProcessCode: function (formId) {
      var returnGwProcCd;
      if (formId === undefined || formId == "") {
        alert("getFormId의 form_id는 null일 수 없습니다.");
      }
      dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getGwProcCd"), {
        async: false,
        data: {
          formId: formId,
        }
      }).done(function (data) {
        returnGwProcCd = data;
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.warning(error, false);
      });
      return returnGwProcCd;
    },

    getGwFormInfo: function (formId) {
      var returnGwFormInfo;
      if (formId === undefined || formId == "") {
        alert("getFormId의 form_id는 null일 수 없습니다.");
      }
      dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "getGwFormInfo"), {
        async: false,
        data: {
          formId: formId,
        }
      }).done(function (data) {
        returnGwFormInfo = data[0];
      }).fail(function (xhr, status, error) {
        // dews.ui.snackbar.warning(error, false);
        console.error("%c■■■■■■■■■■ errorLog Start ■■■■■■■■■■\n" + error + "\n■■■■■■■■■■ errorLog End   ■■■■■■■■■■", "font-size: 12px; font-weight: bold; background-color: rgb(237,  80,  65); color: rgb(255,  255,  255)");
      });
      return returnGwFormInfo;
    },

    getFileKey: function (file_dc, delete_yn,multi_yn) {
      var returnFileKey;

      dews.api.post(dews.url.getApiUrl("HR", "GroupWareMultiPartFile", "uploadFile"), {
        async: false,
        data: {
          file_dc: file_dc,
          delete_yn: delete_yn,
          multi_yn : multi_yn||null
        }
      }).done(function (data) {
        returnFileKey = data;
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.warning("파일 전송에 실패하였습니다.", false);
      });
      return returnFileKey;
    },


    // checkUser : function(userid, comcode, url) {
    // $.post("https://gw.comet.duzon.net/gw/derp/checkUser.do",{
    //   userid : "stua92",
    //   comcode : "5000"
    // },function(e) {},"json")
    // .done(function(token) {
    //   console.log("token",token);
    // })
    // .error(function(request, status, error) {
    //   console.log(request, status, error);
    // })

    // $.post(url + "/gw/derp/checkUser.do",{
    //   userid : userid,
    //   comcode : comcode
    // },function(e) {},"json")
    // .done(function(token) {
    //   console.log("token",token);
    //   return true;
    // })
    // .error(function(request, status, error) {
    //   console.log(request, status, error);
    //   return false;
    // })
    // },

    createEltrAthz_nanum: function (recipient, jobID, docID, xmlString, url) {
      var url = "http://10.134.4.59:11089/nanum/nflow/job/site/ewp/xfdoc_duzon_create.jsp"
      $.ajax({
        type: "POST",
        url: url,
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({
          "protID": "createDoc",
          "employeeNumber": recipient,
          "organID": "B552070",
          "jobID": jobID,
          "docID": docID,
          "Document": xmlString
        }),
        async: true,
        success: function (response) {
          var retData = response;
          try {
            var resultData = trim(retData);
            var reponseJson = new XML2JSON(resultData);
            var resultData = reponseJson.parse(false);// xml parse alert 메시지를 안띄우게 하기위함.
            var openUrl = resultData.returnurl._cdata;
            goOpen(openUrl);
          }
          catch (e) {
            return false;
          }
        },
        error: function (response) {
          alert("나눔 기술 화면 호출 실패");
          console.log(response);
          // console.log(jqXHR.status);
          // console.log(jqXHR.textStatus);
          return false;
        }
      });

      function trim(_data) {
        var index = 0;
        for (var i = 0; i < _data.length; i++) {
          if (_data.charAt(i) == " " || _data.charAt(i) == "\r" || _data.charAt(i) == "\n" || _data.charAt(i) == "\t" || _data.charCodeAt(i) > 256) {
            index = i + 1;
          } else {
            break;
          }
        }

        return _data.substring(index, _data.length);
      }


      function goOpen(_url) {
        var sUrl = _url;
        window.open(_url);
      }
    },



    // createEltrAthz_nanum : function(recipient, jobID, docID, xmlString, url){
    //   var jqxhr = $.ajax({
    //     url : url,
    //     dataType : "html",
    //     // beforeSend : function(xhr){
    //     //   xhr.setRequestHeader("Origin", "http://10.134.9.70:11180");
    //     //   xhr.setRequestHeader("Host", "http://10.134.4.59:11180");
    //     // },
    //     xhrFields : {
    //       withCredentials : true
    //     },
    //     async : false,
    //     method : "POST",
    //     data : {
    //       "employeeNumber": recipient,
    //       "jobID": jobID,
    //       "docID": docID,
    //       "Document": xmlString
    //     },
    //   }).done(function(data) {
    //     var retData = data;
    //     try {
    //       var resultData = trim( retData );
    //       var reponseJson = new XML2JSON( resultData );
    //       var resultData = reponseJson.parse( false );// xml parse alert 메시지를 안띄우게 하기위함.
    //       var openUrl = resultData.returnurl._cdata;
    //       goOpen( openUrl );
    //     } catch( e ) {
    //       return false;
    //     }

    //   }).fail(function( jqXHR, textStatus ) {
    //     alert("나눔 기술 화면 호출 실패");
    //     console.log(jqXHR.status);
    //     console.log(jqXHR.textStatus);
    //     return false;
    //   });

    //   function trim( _data ) {
    //     var index = 0;
    //     for( var i = 0; i < _data.length; i++ ) {
    //       if( _data.charAt( i ) == " " || _data.charAt( i ) == "\r" || _data.charAt( i ) == "\n" || _data.charAt( i ) == "\t" || _data.charCodeAt( i ) > 256 ) {
    //         index = i + 1;
    //       } else {
    //         break;
    //       }
    //     }

    //     return _data.substring( index, _data.length );
    //   }

    //   function goOpen( _url ){
    //     var sUrl = _url;
    //     window.open(_url)
    //     // var openNewWindow = window.open("about:blank");
    //     // openNewWindow.location.href = "http://...";

    //   }
    // },


    createEltrAthz_x10034: function (url, title, size, callback) {
      var eltrAthzPopup;

      // 기존 loading 결제창 제거("전자결재 진행 중입니다." 라는 메세지로 보이도록)
      if (self.$(".dews-ui-loading").length > 0) {
        dews.ui.loading.hide();
      }

      // loading show
      setTimeout(function () {
        dews.ui.loading.show({
          text: "전자결재 진행 중입니다."
        })
      });

      eltrAthzPopup = window.open(url, title, size);

      var popupTick = setInterval(function () {
        if (eltrAthzPopup.closed) {
          clearInterval(popupTick);
          dews.ui.loading.hide();
          if (callback && $.isFunction(callback)) {
            callback();
          }
        }
      }, 500);

      return eltrAthzPopup;
    },
    
    //전표조회승인에서 사용함.
    createEltrAthz_x20141: function(param) {
      var callback;
      var width = 981;
      var height = 769;
      var dummyItem = "";

      var eltrAthzPopup;
      var $eltrAthzForm = $("<form id=\"eltrAthzForm\" name=\"eltrAthzForm\" enctype=\"multipart/form-data\" method=\"POST\" contentType=\"false\" processData=\"false\">").appendTo("body");

      $eltrAthzForm.append($("<input>", { type: "hidden", id: "token", name: "token" }).val(param.token));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "callback", name: "callback" }).val(param.callback));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "type", name: "type" }).val(param.type));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "formname", name: "formname" }).val(param.formname));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "subject", name: "subject" }).val(param.subject));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "content", name: "content" }).val(param.content));
     
      //if ('Y') {
        eltrAthzPopup = window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");
      //} else {
       // eltrAthzPopup = window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width + ",height=" + height + ",scrollbars=yes");
      //}
      try {
        eltrAthzPopup.focus();
      } catch (exception) {
        alert("그룹웨어 팝업이 차단되어있습니다.");
      }

      $("#eltrAthzForm").attr("target", "eltrAthzPopup");
      $("#eltrAthzForm").attr("action", param.url);
      $("#eltrAthzForm").submit();
      $("#eltrAthzForm").remove();

      if (self.$(".dews-ui-loading").length > 0) {
        dews.ui.loading.hide();
      }

      setTimeout(function () {
        dews.ui.loading.show({
          text: "전자결재 진행 중입니다."
        })
      });

      var popupTick = setInterval(function () {
        if (eltrAthzPopup.closed) {
          clearInterval(popupTick);
          dews.ui.loading.hide();
          if (callback && $.isFunction(callback)) {
            callback();
          }
        }
      }, 500);
      return eltrAthzPopup;
    },

    isUsableStatus_x10005: function (btn_type, athz_st_cd) {
      const Status = {
        SAVE: "1",             //저장
        APPROVAL: "2",         //상신
        PROGRESSING: "3",      //진행
        CLOSE: "4",            //종결
        RETURN: "5",           //반려
        CANCEL: "6",           //취소
        HOLD: "7",             //보류
        WITHDRAWL: "8"         //회수
      }

      const cancelCodes = [Status.APPROVAL, Status.PROGRESSING];
      const saveApprovalCodes = [Status.SAVE, Status.RETURN, Status.HOLD, Status.WITHDRAWL];
      const deleteCodes = [Status.SAVE, Status.RETURN, Status.CANCEL, Status.HOLD, Status.WITHDRAWL];

      btn_type = btn_type.toUpperCase();
      if (btn_type == "SAVE" || btn_type == "APPROVAL") {
        return (!athz_st_cd || saveApprovalCodes.includes(athz_st_cd));
      }

      if (btn_type == "CANCEL") {
        return athz_st_cd && cancelCodes.includes(athz_st_cd);
      }

      if (btn_type == "DELETE") {
        return athz_st_cd && deleteCodes.includes(athz_st_cd);
      }

      return false;
    }
  }

  module.canDeletEltrAthz = function (approval_key, user) {
    if (!user) {
      user = dews.ui.page.user;
    }
    let canDelete;
    if (dews.app.drsCode == "10005") {
      return module.canDeletEltrAthz_x10005(approval_key, user);
    }
    dews.api.post(dews.url.getApiUrl("HR", "HrGroupWareApprovalHistory", "gwApprovalHistoryData"), {
      async: false,
      data: {
        approkey: approval_key
      }
    }).done(function (data) {
      let dataList = data[0].result.docLineList;
      let index = 0;

      if (data[0].stat == "success" && dataList) {
        $.each(dataList, function (i, v) {
          if (v.empSeq == user.gEmpCode + "_" + user.userid) {
            index = i;
            return false;
          }
        })

        index = index + 1 <= dataList.length - 1 ? index + 1 : index;
        canDelete = dataList[index].appYn == "0" ? true : false;
      }
    }).fail(function (e) {
      console.error(e);
    });
    return canDelete;
  }

  module.canDeletEltrAthz_x10005 = function (approval_key, user) {
    if (!user) {
      user = dews.ui.page.user;
    }
    let canDelete;
    dews.api.post(dews.url.getApiUrl("HR", "HrGroupWareApprovalHistory", "gwApprovalHistoryData"), {
      async: false,
      data: {
        approkey: approval_key
      }
    }).done(function (data) {
      if (data[0].stat == "success" && data[0].result.docLineList) {
        let dataList = data[0].result.docLineList;
        var closedAppoval = true;
        for (var i = 0; i < dataList.length; i++) {
          var v = dataList[i];
          closedAppoval = (closedAppoval && v.appYn == "1");
        }
        if (closedAppoval && data[0].MA_GWINT_MST) {
          closedAppoval = (data[0].MA_GWINT_MST.GWAPRVLST_CD == "4");
        }
        canDelete = !closedAppoval;
      }
    }).fail(function (e) {
      console.error("canDeletEltrAthz_x10005.gwApprovalHistoryData", e);
    }).always(function (data) {
      console.log(data);
    });
    return canDelete;
  }

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);

  console.debug("hr.gw.util.js", dews.string.format("[ LOAD COMPLETE :: version={0} ]", version));

})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=hr.gw.util.js
