/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
  * 2018-05-03 조은성, 이평석 Ver 1.0 : 최초작성
  * 2018-05-09 조은성, 이평석 Ver 1.1 : 코드 정리
  * 2018-05-14 조은성, 이평석 Ver 1.2 : Between함수 추가
  * 2018-05-14 조은성, 이평석 Ver 1.2 : validateDate undefined, null 여부 체크
*/
(function (dews, derp, $) {
  var module = {};
  var moduleCode = "HR";
  var newModule = {};
  var version = "1.0.220607.02";
  
  console.debug("hr.dateUtil.js", dews.string.format("[ LOAD START :: version={0} ]", version));

  // 시작일을 포함시키지 않은 결과값입니다.

  module.dateUtil = function () {
    var dateUtil = {};
    dateUtil.getFirstDate = function (inputDate) {
      if (!inputDate) inputDate = module.dateToString(new Date());
      if (!validateDate(inputDate)) {return false;}
      return inputDate.substring(0, 4) + inputDate.substring(4, 6) + '01';
    }

    dateUtil.getLastDate = function (inputDate) {
      if (!inputDate) inputDate = module.dateToString(new Date());
      if (!validateDate(inputDate)) {return false;}
      return module.dateToString(new Date(inputDate.substring(0, 4), inputDate.substring(4, 6), 0));
    }

    dateUtil.addDate = function (inputDate, addDate) {
      if (typeof inputDate == "number") {addDate = inputDate; inputDate = module.dateToString(new Date());}
      if (!validateDate(inputDate)) {return false;}
      var year = inputDate.substring(0, 4);
      var month = inputDate.substring(4, 6);
      var day = inputDate.substring(6, 8);
      return module.dateToString(new Date(year, month - 1, day * 1 + addDate))
    }

    dateUtil.addMonth = function (inputDate, addMonth) {
      if (typeof inputDate == "number") {addMonth = inputDate; inputDate = module.dateToString(new Date());}
      if (!validateDate(inputDate)) {; return false;}
      var year = inputDate.substring(0, 4);
      var month = inputDate.substring(4, 6);
      var day = inputDate.substring(6, 8);
      if ((month-1 + addMonth) % 12 != new Date(year, month-1 + addMonth, day).getMonth()) {
        return dateUtil.getLastDate(module.dateToString(new Date(year, month - 1 + addMonth, 01)));
      } else {
        return module.dateToString(new Date(year, month - 1 + addMonth, day));
      }
    }

    dateUtil.betweenDate = function (startDate, endDate) {
      if (!validateDate(startDate)) {; return false;}
      if (!validateDate(endDate)) {; return false;}
      var start = new Date(startDate.substring(0, 4), startDate.substring(4, 6) - 1, startDate.substring(6, 8)).getTime()
      var end = new Date(endDate.substring(0, 4), endDate.substring(4, 6) - 1, endDate.substring(6, 8)).getTime()
      return (end - start) / 86400000;
    }
    dateUtil.betweenMonth = function (startDate, endDate) {
      if(startDate.length != 8) {startDate = startDate + "01"}
      if(endDate.length != 8) {endDate = endDate + "01"}
      if (!validateDate(startDate)) {; return false;}
      if (!validateDate(endDate)) {; return false;}
      var start = (startDate.substring(0, 4) * 12) + (startDate.substring(4, 6) * 1);
      var end = (endDate.substring(0, 4) * 12) + (endDate.substring(4, 6) * 1);
      return end - start;
    }
    dateUtil.betweenYear = function (startDate, endDate) {
      if(startDate.length != 8) {startDate = startDate + "0101"}
      if(endDate.length != 8) {endDate = endDate + "0101"}
      if (!validateDate(startDate)) {; return false;}
      if (!validateDate(endDate)) {; return false;}
      var start = (startDate.substring(0, 4) * 1);
      var end = (endDate.substring(0, 4) * 1);
      return end - start;
    }
    return dateUtil;
  }

  function lpad(number) {
    return number.toString().replace(/^(\d)$/, "0$1");
  }

  module.dateToString = function (date, format) {
    if (!date) date = new Date();
    if (!format) return new Date(date.getTime() + 32400000).toISOString().slice(0, 10).replace(/-/g, '');
    var ret_String = format.replace(/yyyy|yy|MM|dd|HH|hh|mm|ss|[a-z]+/gi, function ($1) {
      switch ($1) {
        case 'YYYY':
        case 'yyyy': return date.getFullYear(); break;
        case 'YY':
        case 'yy': return lpad(date.getYear() % 100); break;
        case 'MM': return lpad(date.getMonth()+1); break;
        case 'DD':
        case 'dd': return lpad(date.getDate()); break;
        case 'HH': return lpad(date.getHours()); break;
        case 'hh': return (date.getHours() < 12 ? 'A.M. ' : 'P.M. ') + lpad(date.getHours() % 12 == 0 ? 12 : date.getHours() % 12); break;
        case 'mm': return lpad(date.getMinutes()); break;
        case 'SS':
        case 'ss': return lpad(date.getSeconds()); break;
        default: return '&'; break;
      }
    })
    if (ret_String.indexOf('&') != -1) {console.log('InValid Date Format'); return false}
    return ret_String;
  }

  function validateDate(dateString) {
    if(dateString !== undefined && dateString !== null && dateString.length == 8 &&dateString == module.dateToString(new Date(dateString.substring(0, 4), dateString.substring(4, 6) -1, dateString.substring(6, 8)))){
      return true;
    }else{
      console.log("Invalid Date String");
      return false;
    }
  }

  newModule[moduleCode] = module;
  window.derp = $.extend(true, derp, newModule);
  
  console.debug("hr.dateUtil.js", dews.string.format("[ LOAD COMPLETE :: version={0} ]", version));

})(window.dews, window.derp || {}, jQuery);
//# sourceURL=hr.dateUtil.js
