/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
 * CODEDTL 호출
 */
function hrcmGetCodeData(hrcmGetCodeData_v_cd_module, hrcmGetCodeData_v_cd_field_pipe, hrcmGetCodeData_v_yn_sycode, hrcmGetCodeData_v_yn_default, hrcmGetCodeData_v_yn_foreign, hrcmGetCodeData_v_dt_end, hrcmGetCodeData_v_nm_keyword) {
  var hrcmGetCodeData_v_this = this;

  if (!hrcmGetCodeData_v_this.hasOwnProperty(hrcmGetCodeData_v_cd_module)) {
    hrcmGetCodeData_v_this[hrcmGetCodeData_v_cd_module] = {};
  }
  $.each(hrcmGetCodeData_v_cd_field_pipe.split("|"), function (i, v) {
    if (v != null && v != "") {
      hrcmGetCodeData_v_this[hrcmGetCodeData_v_cd_module][v] = [];
    }
  });

  dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
    async: false,
    data: {
      module_cd: hrcmGetCodeData_v_cd_module, // 모듈 /* #.# cd_module 변환됨 => module_cd */
      cd_field_pipe: hrcmGetCodeData_v_cd_field_pipe,   // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
      yn_sycode: hrcmGetCodeData_v_yn_sycode,   // 시스템코드 유무(Y,N)
      base_yn: hrcmGetCodeData_v_yn_default,   // 디폴트 코드구분(Y,N) /* #.# yn_default 변환됨 => base_yn */
      yn_foreign: hrcmGetCodeData_v_yn_foreign,   // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
      end_dt: hrcmGetCodeData_v_dt_end,   // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외 /* @.@ dt_end 변환 선택 => end_dt (end_dt,dept_end_dt) */
      nm_keyword: hrcmGetCodeData_v_nm_keyword,    // 검색할 코드 또는 명
    }
  }).done(function (data) {
    if (data.length > 0) {
      $.each(data, function (i, obj) {
        hrcmGetCodeData_v_this[hrcmGetCodeData_v_cd_module][obj.FIELD_CD].push(obj); /* @.@ CD_FIELD 변환 선택 => FIELD_CD (FIELD_CD,FIELD_FG_CD,CMUSEFLD_CD) */
      });
    } else {
      console.log("codeDtl check: ", hrcmGetCodeData_v_cd_module, hrcmGetCodeData_v_cd_field_pipe);
    }
  }).fail(function (xhr, status, error) {
    console.log(xhr, status, error);
    
  });
}

