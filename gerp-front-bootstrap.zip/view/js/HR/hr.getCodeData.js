/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
  * 2018-04-02 조은성, 이평석 Ver 1.0 : 최초작성
  * 2018-04-05 조은성, 이평석 ver 1.1 : 전체 넣는기능 추가
  * 2018-04-16 조은성, 이평석 ver 1.2 : 사용자정의 생성자함수로 수정
*/
(function (dews, derp, $) {
  var module = {};
  var moduleCode = "HR";
  var newModule = {};
  var addSentence = "_A";

  console.log("hr_getCodeData.js is loaded");

  module.codeData = function (module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
    var objCodeDtl = {};

    if (module_cd != undefined && field_cd_pipe != undefined) {
      module.setCodeData(objCodeDtl, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword);
    }

    objCodeDtl.getCodeData = function (module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
      if (module_cd != undefined && field_cd_pipe != undefined) {
        module.setCodeData(objCodeDtl, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword);
      }
    }

    objCodeDtl.addAll = function (module_cd, field_cd_pipe, name) {
      module.addAll(objCodeDtl, module_cd, field_cd_pipe, name);
    }

    return objCodeDtl;
  }

  module.setCodeData = function (objCodeDtl, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
    syscode_yn = syscode_yn === undefined ? null : syscode_yn;
    base_yn = base_yn === undefined ? null : base_yn;
    foreign_yn = foreign_yn === undefined ? null : foreign_yn;
    end_dt = end_dt === undefined ? null : end_dt;
    keyword = keyword === undefined ? null : keyword;

    if (!objCodeDtl.hasOwnProperty(module_cd)) {
      objCodeDtl[module_cd] = {};
    }

    $.each(field_cd_pipe.split("|"), function (i, v) {
      if (v != null && v != "") {
        objCodeDtl[module_cd][v] = [];
        objCodeDtl[module_cd][v + addSentence] = [];
      }

      if (v === "YN") {
        var arrYn = [
          {
            FIELD_CD: 'YN',
            SYSDEF_CD: 'Y',
            SYSDEF_NM: 'Yes'
          },
          {
            FIELD_CD: 'YN',
            SYSDEF_CD: 'N',
            SYSDEF_NM: 'No'
          }
        ];

        objCodeDtl[module_cd][v] = arrYn.slice(0);  // clone
        objCodeDtl[module_cd][v + addSentence] = arrYn.slice(0);  // clone
        if (objCodeDtl[module_cd][v + addSentence][0].SYSDEF_CD != "") {
          module.addAll(objCodeDtl, module_cd, "YN", "");
        }
      }
    });

    dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
      async: false,
      data: {
        module_cd: module_cd,
        field_cd_pipe: field_cd_pipe,
        syscode_yn: syscode_yn,
        base_yn: base_yn,
        foreign_yn: foreign_yn,
        end_dt: end_dt,
        keyword: keyword,
      }
    }).done(function (data) {
      if (data.length > 0) {
        $.each(data, function (i, obj) {
          objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
          objCodeDtl[module_cd][obj.FIELD_CD + addSentence].push(obj);
          if (objCodeDtl[module_cd][obj.FIELD_CD + addSentence][0].SYSDEF_CD != "") {
            module.addAll(objCodeDtl, module_cd, obj.FIELD_CD, "");
          }
        });
      }
    }).fail(function (xhr, status, error) {
      console.log(xhr, status, error);
    });
  }

  module.addAll = function (objCodeDtl, module_cd, field_cd_pipe, name) {
    $.each(field_cd_pipe.split("|"), function (i, v) {
      if (v != null && v != "") {
        if(objCodeDtl[module_cd][v + addSentence][0].SYSDEF_CD === ""){
          objCodeDtl[module_cd][v + addSentence].shift();
        }
        objCodeDtl[module_cd][v + addSentence].unshift({FIELD_CD: objCodeDtl[module_cd][v][0].FIELD_CD, SYSDEF_CD: "", SYSDEF_NM: name === undefined ? "" : name, FLAG_CD: null});
      }
    });
  }

  newModule[moduleCode] = module;
  window.derp = $.extend(true, derp, newModule);
})(window.dews, window.derp || {}, jQuery);
//# sourceURL=hr.getCodeData.js
