var p;
var servicename;
var g = {
  init: function (_p, _servicename) {
    p = _p;
    servicename = _servicename;
  },
  handlefail: function (res, stat, msg) {
    console.log(res);
    dews.ui.snackbar.error(msg);
  },
  dscodedtl: function (module_cd = "HR", configs = {}) {
    const url = dews.url.getApiUrl(
      "CM",
      "codehelp/CodeHelpDataService",
      "H_MA_CODEDTL_S"
    );
    for (let field_cd of Object.keys(configs)) {
      dews.api
        .get(url, {
          async: false,
          data: {
            company_cd: p.user.companyCode,
            module_cd: module_cd,
            field_cd: field_cd,
            flag_cd: "",
            std_dt: "",
            limit_cd_sysdef: "",
          },
        })
        .done(function (r) {
          configs[field_cd].data(r);
        })
        .fail(g.handlefail);
    }
  },
  apiget: function (endpoint, params, _servicename, module_cd = "HR") {
    _servicename = _servicename || servicename;
    const url = dews.url.getApiUrl(module_cd, _servicename, endpoint);
    const conf = { async: false, data: params };
    let result;
    dews.ui.loading.show();
    dews.api
      .get(url, conf)
      .done(function (response) {
        result = response;
      })
      .fail(g.handlefail)
      .always(function () {
        dews.ui.loading.hide();
      });
    return result;
  },
};
