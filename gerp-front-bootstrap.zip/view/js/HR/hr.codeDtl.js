/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
  * 2018-03-12 조은성, 이평석 Ver 1.0 : 최초작성
  * 2018-03-13 조은성, 이평석 Ver 1.1 : 하위객체 초기화 기능 추가
  * 2018-03-30 조은성, 이평석 Ver 1.2 : setHelpParams 재정의 추가
  * 2018-09-14 조은성, 이평석 Ver 1.2 : 메타변경으로 인한 master.options.codeField.length 서브스트링 구분 수정
  * 2019-09-18 조은성 Ver 1.3 : master값이 없는경우 detail선택불가처리
  * 2019-12-12 성승익 : Object.assign polyfill 추가.
  * 2021-10-19 강호석 : 사업장 필수 통제 여부 추가
*/
  /* options(options가 없는 경우 "사업장필수" 무조건 통제)
    self: self 사용 시 "사업장필수 통제여부"의 사용
    boolean: 사업장 필수 여부
    string: 사업장 필수 && 사용 메세지
    object: {
      self: self(dewself), // self 사용 시 "사업장필수 통제여부"의 사용
      useAlert: true/FALSE,
      msg: string
    }
   */
// (function() {
//   // Object.assign polyfill
//   if (typeof Object.assign != 'function') {
//     // Must be writable: true, enumerable: false, configurable: true
//     Object.defineProperty(Object, "assign", {
//       value: function assign(target, varArgs) { // .length of function is 2
//         'use strict';
//         if (target == null) { // TypeError if undefined or null
//           throw new TypeError('Cannot convert undefined or null to object');
//         }

//         var to = Object(target);

//         for (var index = 1; index < arguments.length; index++) {
//           var nextSource = arguments[index];

//           if (nextSource != null) { // Skip over if undefined or null
//             for (var nextKey in nextSource) {
//               // Avoid bugs when hasOwnProperty is shadowed
//               if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
//                 to[nextKey] = nextSource[nextKey];
//               }
//             }
//           }
//         }
//         return to;
//       },
//       writable: true,
//       configurable: true
//     });
//   }
// })();
(function (dews, derp, $) {
  var module = {};
  var moduleCode = "HR";
  var newModule = {};

  console.log("hr_codeDtl.js is loaded");

  module.setHrDetail = function (master, detail, param, options) {
    // default
    let isCtrlMst = true; // detail 제어 여부
    let useAlert = true;  // 메세지박스 사용 여부(false(미사용) 시 disable)
    let msg = ''; // 메세지박스 내용
    //
    let mainSelf; // self/dewself 등
    let deptMsg = dews.localize.get("사업장은 필수입력 항목입니다.", 'M0004673');
    let empMsg = dews.localize.get("부서는 필수입력 항목입니다.", 'M0002423');
    let elseMsg = dews.localize.get("필수값이 입력되지 않았습니다.", 'M0000807');
    let displayLog = false;

    if (detail.options.helpCode.indexOf("MA_DEPT_MST") > -1) {
      msg = deptMsg;
    } else if (detail.options.helpCode.indexOf("HR_EMP_MST") > -1) {
      msg = empMsg;
    } else {
      msg = elseMsg;
    }

    msg = deptMsg;

    if (displayLog) console.log(master, detail);

    if (options == null || options == undefined) { // null/undefined, 0제외
      // default
    } else if ($.isPlainObject(options)) {  // object 객체
      mainSelf = options.self ? options.self : null;
      if (options.useAlert === null || options.useAlert === undefined) {
        // useAlert = default
      } else {
        useAlert = options.useAlert;
      }
      msg = options.msg ? options.msg : msg;
      useAlert = (options.useAlert == undefined && options.msg) ? true : useAlert;
      isCtrlMst = (mainSelf && mainSelf.comEnv && mainSelf.comEnv.HR00002 && mainSelf.comEnv.HR00002.value === 'N') ? false : true;
      displayLog = options.displayLog;
    } else if (typeof options === 'object') { // self
      mainSelf = options;
      isCtrlMst = (mainSelf && mainSelf.comEnv && mainSelf.comEnv.HR00002 && mainSelf.comEnv.HR00002.value === 'N') ? false : true;
    } else if (typeof options === 'boolean') {
      isCtrlMst = options;
    } else if (typeof options === 'string') {
      useAlert = true;
      msg = options;
    } else if (typeof options === 'number') {
      // later
    } else if (typeof options === 'function') {
      // later
    }

    if (isCtrlMst && !useAlert) {
      detail.enable(false);
    } else {
      // detail.enable(false);
      detail.enable(true);
    }

    var prevMaster = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? master.codes().join("|") : master.code();
    master.subDetail = detail;

    var prevObj = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true
      ?
        typeof detail.options.helpParams === 'function'
        ? detail.options.helpParams()
        : detail.options.helpParams
      : {};

    if (prevObj === null) {prevObj = {}}

    if (typeof param === "string") {
      prevObj[param] = prevMaster
    } else {
      if (typeof (master.options.codeField)) {
        var prevAuth = 'auth_' + master.options.codeField.substring(0, master.options.codeField.length-3).toLowerCase();
        if (prevMaster != null && prevMaster != "") {
          prevObj[prevAuth] = prevMaster;
        }
      } else {
        return;
      }
    }

    if (displayLog) console.log('prevObj:', prevObj);

    detail.setHelpParams(prevObj);

    detail.setHelpParams = function (params) { // dews setHelpParams 재정의
      let helpParams;
      let detailHelpParams;

      if (typeof detail.options.helpParams === 'function') {
        detailHelpParams = detail.options.helpParams();
      } else {
        detailHelpParams = detail.options.helpParams;
      }

      if (displayLog) console.log('detailHelpParams(' + typeof detail.options.helpParams + ' to object):', JSON.stringify(detailHelpParams, null, '\t'));

      if (detail.options.helpParams != null) {
        // Object.assign(params, detailHelpParams);
        helpParams = $.extend(true, {}, detailHelpParams, params);
      }
      // defineDetailHelpParam = helpParams;
      // setHelpParams 코드 원본 : dews.ui.js ---------------------------
      var self = this;
      self.options.helpParams = helpParams;
      // ---------------------------------------------------------------
      if (displayLog) console.log('detail helpParams:', helpParams);
    };

    master.on("change", function (e) {
      // var obj = detail.options.helpParams === null ? {} : detail.options.helpParams;
      var obj;
      var curMaster = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? master.codes().join("|") : master.code();

      if (detail.options.helpParams === null) {
        obj = {};
      } else {
        if (typeof detail.options.helpParams === 'function') {
          obj = detail.options.helpParams();
        } else {
          obj = detail.options.helpParams;
        }
      }

      if (useAlert){
        detail.enable(true);
      } else{
        if (curMaster != "" && curMaster != null && curMaster != undefined) {
          // detail.enable(false);
          detail.enable(true);
        } else{
          detail.enable(false);
        }
      }

      if (typeof param === "string") {
        obj[param] = curMaster
      } else {
        var auth = 'auth_' + master.options.codeField.substring(0, master.options.codeField.length-3).toLowerCase();
        var cd = master.options.codeField.toLowerCase();

        obj[auth] = curMaster;
        obj[cd] = curMaster;
      }

      if (displayLog) console.log('>>>', curMaster, prevMaster, curMaster.length, prevMaster.length, obj, obj.bizarea_cd, detail);
      if (curMaster != prevMaster) {
        // console.log(curMaster, prevMaster.length, obj, obj.bizarea_cd);
        if (curMaster.length <= prevMaster.length) {
          if (detail.target === undefined) {detail.clearData()} else {detail.clear()};
          clearDetail(detail, detail.subDetail);
        }
      }
      // console.log('obj:', obj, obj.auth_bizarea, obj.bizarea_cd, param, typeof param)
      detail.setHelpParams(obj);
      prevMaster = curMaster;
    });

    detail.on('codedialog', function(e){
      if (isCtrlMst) {
      // if(busiCode == undefined){
        // console.log("prevMaster", prevMaster);
        let masterCode = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? master.codes().join("|") : master.code();
        if (masterCode == null || masterCode == '') {
        // if (prevMaster == "" || prevMaster == null || prevMaster == undefined) {
          e.stopImmediatePropagation();
          dews.alert(msg, "warning");
          // if(e.code.indexOf("MA_DEPT_MST") > -1){
          //   dews.alert(msg, "warning");
          // } else {
          //   dews.alert(empMsg, "warning");
          // }
        }
      }
    });

    function clearDetail(detail, subdetail) {
      if (subdetail != undefined) {
        clearDetail(subdetail, subdetail.subDetail);
        if (subdetail.wrapper != undefined && $(subdetail.wrapper.context).hasClass("dews-ui-multicodepicker") === true) {
          subdetail.clear(); subdetail.setHelpParams({});
        } else {
          subdetail.clearData(); subdetail.setHelpParams({});
        }

        if (! useAlert){
          subdetail.enable(false);
        }
      }
      return;
    }
  }

  newModule[moduleCode] = module;
  window.derp = $.extend(true, derp, newModule);
})(window.dews, window.derp || {}, jQuery);
//# sourceURL=hr.codeDtl.js
