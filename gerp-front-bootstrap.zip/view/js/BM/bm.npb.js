// /view/js/bm.npb.js
/*
 * {bm.npb} 비영리 모듈 공통 함수
 */
(function(dews, gerp, $) {
  var module = {};

  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'BM'; // 모듈 코드를 입력 해주세요.

  //////// Polyfill
  if (!Array.prototype.find) {
    Array.prototype.find = function (predicate) {
      'use strict';
      if (this == null) {
        throw new TypeError('Array.prototype.find called on null or undefined');
      }
      if (typeof predicate !== 'function') {
        throw new TypeError('predicate must be a function');
      }
      var list = Object(this);
      var length = list.length >>> 0;
      var thisArg = arguments[1];
      var value;

      for (var i = 0; i < length; i++) {
        value = list[i];
        if (predicate.call(thisArg, value, i, list)) {
          return value;
        }
      }
      return undefined;
    };
  }

  if (!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
      value: function (predicate) {
        'use strict';
        if (this == null) {
          throw new TypeError('Array.prototype.findIndex called on null or undefined');
        }
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }
        var list = Object(this);
        var length = list.length >>> 0;
        var thisArg = arguments[1];
        var value;

        for (var i = 0; i < length; i++) {
          value = list[i];
          if (predicate.call(thisArg, value, i, list)) {
            return i;
          }
        }
        return -1;
      },
      enumerable: false,
      configurable: false,
      writable: false
    });
  }

  ///// region 공통 메서드 /////

  /**
   * 코드도움 데이터 조회
   * @param {array} objCodeData 데이터 조회 대상 배열
   * @param {array} cd_module 모듈
   * @param {array} cd_field_pipe 코드디테일 코드(PIPE 사용)
   * @param {array} yn_sycode 시스템코드 유무(Y,N)
   * @param {array} yn_default 디폴트 코드구분(Y,N)
   * @param {array} yn_foreign 종료일
   * @param {array} nm_keyword 검색할 코드 또는 명
   */
  module.getCodeData = function(objCodeData, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
    if (!objCodeData.hasOwnProperty(module_cd)) {
      objCodeData[module_cd] = {};
    }
    $.each(field_cd_pipe.split("|"), function (i, v) {
      if (v != null && v != "") {
        objCodeData[module_cd][v] = [];
      }
    });
    dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
      async: false,
      data: {
        module_cd: module_cd,          // 모듈
        field_cd_pipe: field_cd_pipe,  // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
        syscode_yn: syscode_yn,        // 시스템코드 유무(Y,N)
        base_yn: base_yn,              // 디폴트 코드구분(Y,N)
        foreign_yn: foreign_yn,        // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
        end_dt: end_dt,                // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
        keyword: keyword,              // 검색할 코드 또는 명
      }
    }).done(function (data) {
      if (data.length > 0) {
        $.each(data, function (i, obj) {
          objCodeData[module_cd][obj.FIELD_CD].push(obj);
        });
      } else {
      }
    }).fail(function (xhr, status, error) {
      //dews.error("코드도움 데이터 조회 오류");
    });
  };

  /**
   * 코드도움 데이터에 전체 추가
   * @param {array} objCodeData 대상 배열
   */
  module.addCodeDataAll = function(objCodeData) {
    objCodeData.unshift({ SYSDEF_CD: '', SYSDEF_NM: '' });
  };

  /**
   * 코드도움 데이터에 전체 추가
   * @param {array} objCodeData 대상 배열
   * @returns {array} 설정된 새로운 배열
   */
  module.addCodeDataAllDeep = function(objCodeData) {
    var data = $.extend(true, [], objCodeData);
    data.unshift({ SYSDEF_CD: '', SYSDEF_NM: '' });
    return data;
  };

  /**
   * 예산구분 데이터 셋팅
   * @param {object} dewself this 객체
   * @param {string} lvbgacctId 예산구분 컨트롤 ID
   */
  module.setDataLV_BGACCT = function(dewself, lvbgacctId) {
    dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBPSService", "npbbps00700_list_level"), {
      async : false
    }).done(function(data){
      if (data.length > 0) {
        var lvbgacct = dewself[lvbgacctId];
        lvbgacct.setDataSource(data);
        lvbgacct.value(data[0].BGACCT_LV);
      }
    }).fail(function(xhr, status, error){
      dews.error(error);
    });
  };

  /**
   * 회계단위 데이터 셋팅
   * @param {object} dewself this 객체
   * @param {string} cdpcId 회계단위 컨트롤 ID
   */
  module.setDataCD_PC = function(dewself, cdpcId) {
    dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBPSService", "npbbps00100_list_pc"), {
      async : false
    }).done(function(data){
      var target = dewself[cdpcId];
      var $target = dewself['$' + cdpcId];
      if (target != undefined){
        if (target.options.name == "DropDownList") {
          target.setDataSource(data);
          target.value(dewself.user.profitCenterCode);
        } else if ($target.hasClass("dews-ui-codepicker") ||
                   $target.hasClass("dews-ui-multicodepicker")) {
          target.setData([{ PC_CD : dewself.user.profitCenterCode, PC_NM : dewself.user.profitCenterName }]);
        }
      }
    }).fail(function(xhr, status, error){
      dews.error(error);
    });
  };

  /**
   * 기수 데이터 셋팅
   * @param {object} dewself this 객체
   * @param {string} gisuId 기수 컨트롤 ID
   * @param {string} dateId 기수 일자 컨트롤 ID
   * @param {string} monthId 기수 월 컨트롤 ID (월기간, 월 모두가능)
   * @param {string} month_prevId 기수 이전월 컨트롤 ID (월기간, 월 모두가능)
   */
  module.setDataACCSEQ = function(dewself, gisuId, dateId, monthId, month_prevId) {
    dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBPSService", "npbbps00100_list_accseq"), {
      async : false,
    }).done(function(data){
      if (data.length > 0) {
        data.sort(function(a, b){
          a["ACCSEQ_SQ"] - b["ACCSEQ_SQ"]
        })
        var gisu = dewself[gisuId];
        var date = dewself[dateId];
        var month = dewself[monthId];
        var month_prev = dewself[month_prevId];
        gisu.setDataSource(data);
        var today = module.dateToString(new Date());
        var currentSeq = 0;
        $.each(data, function(idx){
          if(this.START_DT <= today && this.END_DT >= today){
            currentSeq = idx;
          }
        });
        gisu.value(data[currentSeq].ACCSEQ_SQ);
        // FROM - TO 기간 체크 때문에 먼저 빈값 셋팅
        date.setStartDate("");
        date.setEndDate("");
        date.setEndDate(data[currentSeq].END_DT);
        date.setStartDate(data[currentSeq].START_DT);
        if(month) {
          if (dewself['$' + monthId].hasClass("dews-ui-monthpicker")) {
            month.value(today.toString().substring(0, 6));
            dewself['$' + monthId].on('change', function (e) {
              var startDate = data[gisu.selectedIndex].START_DT;
              var endDate = data[gisu.selectedIndex].END_DT;

              if (startDate && endDate) {
                if (!(startDate.substring(0, 6) <= month.value() && endDate.substring(0, 6) >= month.value())) {
                  month.value(startDate.substring(0, 6));
                  // 위에서 월피커를 셋팅했음에도 불구하고 다시 셋팅
                  // 월피커에서 년도의 From, To 모두를 변경했을 때 셋팅하는 시점에 "undefined" 로 떨어지는 경우 처리
                  month.value(startDate.substring(0, 6));
                }
              }
            });

          } else if (dewself['$' + monthId].hasClass("dews-ui-monthperiodpicker")) {
            month.setStartDate("");
            month.setEndDate("");
            month.setEndDate(data[currentSeq].END_DT.toString().substring(0, 6));
            month.setStartDate(data[currentSeq].START_DT.toString().substring(0, 6));

            dewself['$' + monthId].on('change', function (e) {
              var startDate = data[gisu.selectedIndex].START_DT;
              var endDate = data[gisu.selectedIndex].END_DT;

              if (startDate && endDate) {
                if (!(startDate.substring(0, 6) <= month.getStartDate() && endDate.substring(0, 6) >= month.getEndDate())) {
                  month.setStartDate(startDate.substring(0, 6));
                  month.setEndDate(endDate.substring(0, 6));

                  // 위에서 월피커를 셋팅했음에도 불구하고 다시 셋팅
                  // 월피커에서 년도의 From, To 모두를 변경했을 때 셋팅하는 시점에 "undefined" 로 떨어지는 경우 처리
                  month.setStartDate(startDate.substring(0, 6));
                  month.setEndDate(endDate.substring(0, 6));
                }
              }
            });
          }
        }

        if(month_prev) {
          if (dewself['$' + month_prevId].hasClass("dews-ui-monthpicker")) {
            month_prev.value(today.toString().substring(0, 6));
            month_prev.value(data[currentSeq - 1].END_DT.toString().substring(0, 6));

            dewself['$' + month_prevId].on('change', function (e) {
              var startDate = data[gisu.selectedIndex - 1].START_DT;
              var endDate = data[gisu.selectedIndex - 1].END_DT;

              if (startDate && endDate) {
                if (!(startDate.substring(0, 6) <= month_prev.value() && endDate.substring(0, 6) >= month_prev.value())) {
                  month_prev.value(startDate.substring(0, 6));

                  // 위에서 월피커를 셋팅했음에도 불구하고 다시 셋팅
                  // 월피커에서 년도의 From, To 모두를 변경했을 때 셋팅하는 시점에 "undefined" 로 떨어지는 경우 처리
                  month_prev.value(startDate.substring(0, 6));
                }
              }
            });
          } else if (dewself['$' + month_prevId].hasClass("dews-ui-monthperiodpicker")) {
            month_prev.setStartDate("");
            month_prev.setEndDate("");
            month_prev.setEndDate(data[currentSeq - 1].END_DT.toString().substring(0, 6));
            month_prev.setStartDate(data[currentSeq - 1].START_DT.toString().substring(0, 6));

            dewself['$' + month_prevId].on('change', function (e) {
              var startDate = data[gisu.selectedIndex - 1].START_DT;
              var endDate = data[gisu.selectedIndex - 1].END_DT;

              if (startDate && endDate) {
                if (!(startDate.substring(0, 6) <= month_prev.getStartDate() && endDate.substring(0, 6) >= month_prev.getEndDate())) {
                month_prev.setStartDate(startDate.substring(0, 6));
                month_prev.setEndDate(endDate.substring(0, 6));

                // 위에서 월피커를 셋팅했음에도 불구하고 다시 셋팅
                // 월피커에서 년도의 From, To 모두를 변경했을 때 셋팅하는 시점에 "undefined" 로 떨어지는 경우 처리
                month_prev.setStartDate(startDate.substring(0, 6));
                month_prev.setEndDate(endDate.substring(0, 6));
              }
            }
          });
        }
      }

      dewself['$' + gisuId].on('change', function (e) {
          date.setStartDate("");
          date.setEndDate("");
          date.setEndDate(data[gisu.selectedIndex].END_DT);
          date.setStartDate(data[gisu.selectedIndex].START_DT);
          if(month) {
            if (dewself['$' + monthId].hasClass("dews-ui-monthpicker")) {
              month.value(data[gisu.selectedIndex].START_DT.toString().substring(0, 6));
            } else if (dewself['$' + monthId].hasClass("dews-ui-monthperiodpicker")) {
              month.setStartDate("");
              month.setEndDate("");
              month.setEndDate(data[gisu.selectedIndex].END_DT.toString().substring(0, 6));
              month.setStartDate(data[gisu.selectedIndex].START_DT.toString().substring(0, 6));
            }
          }
          if(month_prev) {
            if (dewself['$' + month_prevId].hasClass("dews-ui-monthpicker")) {
              month_prev.value(data[gisu.selectedIndex].START_DT.toString().substring(0, 6));
            } else if (dewself['$' + month_prevId].hasClass("dews-ui-monthperiodpicker")) {
              month_prev.setStartDate("");
              month_prev.setEndDate("");
              month_prev.setEndDate(data[gisu.selectedIndex - 1].END_DT.toString().substring(0, 6));
              month_prev.setStartDate(data[gisu.selectedIndex - 1].START_DT.toString().substring(0, 6));
            }
          }
        });
      }
      }).fail(function(xhr, status, error){
        dews.error(error);
      });
  };

  /**
   * 현재 기수 데이터 조회
   * @returns {array} [현재기수, 현재기수 초일, 현재기수 말일]
   */
  module.getCurACCSEQ = function() {
    dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBPSService", "npbbps00100_list_accseq"), {
      async : false,
    }).done(function(data){
      if (data.length > 0) {
        var today = module.dateToString(new Date());
        var currentSeq = 0;
        $.each(data, function(idx){
          if(this.START_DT <= today && this.END_DT >= today){
            currentSeq = idx;
          }
        });
        return [data[currentSeq].ACCSEQ_SQ, data[currentSeq].START_DT, data[currentSeq].END_DT];
      }
    }).fail(function(xhr, status, error){
      dews.error(error);
    });
  };

  /**
   * 서식명 데이터 셋팅
   * @param {object} dewself this 객체
   * @param {string} cdformId 서식명 컨트롤 ID
   */
  module.setDataCD_FORM = function(dewself, cdformId) {
    dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBRFService", "npbbrf00200_list_form"), {
      async : false
    }).done(function(data){
      var target = dewself[cdformId];
      var $target = dewself['$' + cdformId];
      if (target != undefined){
        if (target.options.name == "DropDownList") {
          target.setDataSource(data);
          target.value(dewself.user.profitCenterCode);
        //} else if ($target.hasClass("dews-ui-codepicker") ||
        //           $target.hasClass("dews-ui-multicodepicker")) {
        //  target.setData([{ CD_PC : dewself.user.profitCenterCode, NM_PC : dewself.user.profitCenterName }]);
        }
      }
    }).fail(function(xhr, status, error){
      dews.error(error);
    });
  };

  /**
   * 오늘 날짜 String
   * @returns {string} 오늘 날짜 String
   */
  module.getTodayString = function(){
    return module.dateToString(new Date());
  };

  /**
   * 오늘 년도 String
   * @returns {string} 오늘 년도 String
   */
  module.getYearString = function(){
    return new Date().getFullYear() + "";
  };

   /**
   * 오늘 년월 String
   * @returns {string} 오늘 년월 String
   */
  module.getYearMonthString = function(){
    var date = new Date();
    var year = date.getFullYear() + "",
        month = date.getMonth() + 1 + "";
    return year + module.padLeft(month , "0", 2)
  };

  /**
   * dateToString
   * @param {Date} date Date 객체
   * @returns {string} 변환된 값
   */
  module.dateToString = function(date){
    if (!date)
      return "";
    var year = date.getFullYear() + "",
      month = date.getMonth() + 1 + "",
      date = date.getDate() + "";
    return year + module.padLeft(month , "0", 2) + module.padLeft(date , "0", 2);
  };

    /**
   * 월말 가져오기
   * @param {string} date 기간
   * @returns {string} yyymmdd 변환된 값
   */
  module.lastYearMonthDayString = function(date){
    if(!date || date.length < 6) {
      var today = module.getTodayString();
      return "" + today.substring(0, 4) + today.substring(4, 6) + ( new Date( today.substring(0, 4), today.substring(4, 6), 0) ).getDate();
    }
    var lastDay = "" + date.substring(0, 4) + date.substring(4, 6) + ( new Date( date.substring(0, 4), date.substring(4, 6), 0) ).getDate();
    return lastDay;
  };

  /**
   * padLeft
   * @param {string} str 문자열
   * @param {string} padChar 문자
   * @param {int} totalLength 길이
   * @returns {string} 변환된 값
   */
  module.padLeft = function(str, padChar, totalLength){
    if(typeof str != "string"){
      str = str + "";
    }
    var padding = "";
    for(var i=0; i<totalLength; i++){
      padding += padChar;
    }
    return padding.substring(str.length) + "" + str;
  };

  /**
   * 숫자 컴마 추가
   * @param {object} x 설정대상 값
   * @returns {string} 변환된 값
   */
  module.numberWithCommas = function(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
  };

  /**
   * null, undefined, NaN, empty string (""), 0, false => zero
   * @param {object} x 설정대상 값
   * @returns {float} 변환된 값
   */
  module.emptyToZero = function(x) {
    if( x ) {
      return parseFloat(x);
    }
    else {
      return 0;
    }
  };

  /**
   * 소수점 지정자리 반올림
   * @param {object} n 설정대상 값
   * @param {int} pos 소수점 자리수
   * @returns {float} 소수점 설정 값
   */
  module.rounded = function(n, pos) {
    var digits = Math.pow(10, pos);
    var sign = 1;
    if (n < 0) {
      sign = -1;
    }
    // 음수이면 양수처리후 반올림 한 후 다시 음수처리
    n = n * sign;
    var num = Math.round(n * digits) / digits;
    num = num * sign;

    return parseFloat(num.toFixed(pos));
  };

  /**
   * 소수점 지정자리 절사
   * @param {object} n 설정대상 값
   * @param {int} pos 소수점 자리수
   * @returns {float} 소수점 설정 값
   */
  module.roundedDown = function(n, pos) {
    var digits = Math.pow(10, pos);
    var num = Math.floor(n * digits) / digits;
    return parseFloat(num.toFixed(pos));
  };

  /**
   * 소수점 지정자리 절상
   * @param {object} n 설정대상 값
   * @param {int} pos 소수점 자리수
   * @returns {float} 소수점 설정 값
   */
  module.roundedUp = function(n, pos) {
    var digits = Math.pow(10, pos);
    var num = Math.ceil(n * digits) / digits;
    return parseFloat(num.toFixed(pos));
  };

  /**
   * 소수점 지정자리 절상, 절사, 반올림
   * @param {object} n 설정대상 값
   * @param {int} pos 소수점 자리수
   * @param {string} round 절상 '2', 절사 '1', 반올림 '0' 처리
   * @returns {float} 소수점 설정 값
   */
  module.getRoundNumber = function(n, pos, round) {
    pos = parseInt(pos);
    if (round == "2") {
      return module.roundedUp(n, pos);
    }
    else if (round == "1") {
      return module.roundedDown(n, pos);
    }
    else {
      return module.rounded(n, pos);
    }
  };

  /**
   * 헤딩 자리수 포맷 설정
   * @param {int} pos 해당 자리수
   * @returns {string} 포맷 설정된 문자열
   */
  module.getFormatedText = function(pos) {
    var format = "#,##0";
    for (var i = 1; i <= pos; i++) {
      if (i == 1)
        format += ".";
      format += "0";
    }
    return format;
  };


  /**
   * 계산통제 공통
   * @param {object} amt 계산값
   * @param {object} ctrl_cd 통제코드
   * @returns {array} [ 산출근거, 금액 ]
   */
  module.getCtrlConfig = function (dewself, amt, ctrl_cd) {
    var result = 0;
    try {
      // round  1 반올림 2올림 3 버림
      // getRoundNumber 절상 '2', 절사 '1', 반올림 '0' 처리
      result = module.getRoundNumber(amt, dewself.env[ctrl_cd].value, dewself.env[ctrl_cd].round == "1" ? "0" : dewself.env[ctrl_cd].round == "3" ? "1" : dewself.env[ctrl_cd].round);
    }
    catch (err) {
      result = 0;
    }
    return result;
  };

  /**
   * 산출근거 공통
   * @param {object} str 산출근거-산식
   * @param {object} fg_bgacct2 수입수출구분
   * @returns {array} [ 산출근거, 금액 ]
   */
  module.getBGCalc = function (str, incomexpen_fg) {
    var result;
    try {
      var tp_unit, tp_unit2, tp_round, tp_round2, unit, round;
      var am = 0;
      var rst_amt = 0;
      var s = str.split('').filter(function (ch) { return /[\+\(\)*/-]|^([0-9]*)[\.]?([0-9])?$/.test(ch) }).join('');
      dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBPSService", "npbbps_common_bgcalc_list"), {
        async: false
      }).done(function (data) {
        if (data.length > 0) {
          tp_unit = data[0].TP_UNIT;
          tp_unit2 = data[0].TP_UNIT2;
          tp_round = data[0].TP_ROUND;
          tp_round2 = data[0].TP_ROUND2;
          unit = incomexpen_fg == "1" ? tp_unit : tp_unit2;
          round = incomexpen_fg == "1" ? tp_round : tp_round2;
          am = unit == "3" ? 1000 :
               unit == "4" ? 10000 :
               unit == "5" ? 100000 :
               unit == "6" ? 1000000 :
               unit == "7" ? 10000000 : 1;
          // 절상 '2', 절사 '1', 반올림 '0'
          round = round == "1" ? "0" : round == "3" ? "1" : "2";
          rst_amt = eval(s);
          rst_amt = rst_amt / am;
          rst_amt = module.getRoundNumber(rst_amt, 0, round);
          rst_amt = rst_amt * am;
          result = [s, rst_amt];
        }
        else {
          result = [s, eval(s)];
        }
      }).fail(function (xhr, status, error) {
        dews.error(error);
      });
    }
    catch (err) {
      result = [0, 0];
    }
    return result;
  };

  /**
   * 예산과목 레벨별 ROW style 설정
   * @param {object} e   그리드 데이터바운드 이벤트 객체
   * @param {string} colNameLV    예산 레벨 컬럼명 (기본 : "LV_BGACCT")
   * @param {string} colNameLast  최하위 레벨 컬럼명 (기본 : "YN_LAST")
   * @param {string} stringLast   최하위 설정 문자열 (기본 : "Y")
   */
  module.setRowStyleLV = function(e, colNameLV, colNameLast, stringLast){
    if (!colNameLV)
      colNameLV = "BGACCT_LV";
    if (!colNameLast)
      colNameLast = "LAST_YN"
    if (!stringLast)
      stringLast = "Y";

    var indexFirst = [];
    var indexLast = [];
    // 적용할 스타일
    var styleFirst = {
      background: '#cef3f7'
      //background: '#c6f3c6'
    };
    var styleLast = {
      background: '#effbff'
      //background: '#efffef'
    };
    var grid = e.grid ? e.grid : e.treegrid;
    var i = grid == e.grid ? 0 : 1;
    var length = grid == e.grid ? e.grid.dataItems().length : e.treegrid.dataSource.dataProvider.getRowCount()+1; // 그리드 전체 데이터 길이
    for (i; i < length; i += 1) {
      if (grid.dataItem(i)[colNameLV] == "1") {
        indexFirst.push(i);   // 변경할 행의 index를 설정합니다.
      } else if (grid.dataItem(i)[colNameLast] != stringLast) {
        indexLast.push(i);   // 변경할 행의 index를 설정합니다.
      }
    }

    grid.setRowStyle(indexFirst, styleFirst);
    grid.setRowStyle(indexLast, styleLast);
  };

  /**
   * null 이나 빈값을 기본값으로 변경
   * @param str       입력값
   * @param defaultVal    기본값(옵션)
   * @returns {String}    체크 결과값
   */
   module.nvl = function(str, defaultVal) {
       var defaultValue = "";

       if (typeof defaultVal != 'undefined') {
           defaultValue = defaultVal;
       }
       if (typeof str == "undefined" || str == null || str == '' || str == "undefined") {
           return defaultValue;
       }
       return str;
    }

  /**
  * 메인버튼 Disable
  */
  module.maimbtnDisable = function() {
    dews.ui.mainbuttons.add.disable(true);
    dews.ui.mainbuttons.delete.disable(true);
    dews.ui.mainbuttons.print.disable(true);
    dews.ui.mainbuttons.search.disable(true);
    dews.ui.mainbuttons.save.disable(true);
    dews.ui.mainbuttons.favorite.disable(true);
  }


   /**
    * drf 공통
    * @param {object} dewself this
    * @param {object} panelId 페이지의 PanelId
    * @param {object} searchParams 넘겨줄 파라미터 (조회조건)
    * @param {reportId} reportId 프린트 상위 카테코리
    * @param {object} objectId DRF 명
    */
   module.invokePrint = function(dewself, panelId, searchParams, reportId, objectId){
 	  var items = new Array();

 	  if(module.nvl(reportId, "") === ""){
 		  reportId = "R_" + dewself.menu.id + "_0";
       }

       searchParams = module.setParamsToJson(dewself, panelId, searchParams);

       $.each(searchParams, function(idx, data){
         items.push({
           RPRT_CD : reportId,
           OBJECT_CD : objectId,
           PARA_CD : data.name,
           PARA_TXT : data.value
         })
       });

       /* 파라미터 저장 요청 */
       dews.api.post(dews.url.getApiUrl("CM", "printService", "setPrintParam"), {
         async : false,
         data : {
           reportCode : reportId,
           items : JSON.stringify(items)
         }
       }).done(function(data){
         if(data != "" && data != null){
            dews.app.print({
              reportId : reportId,
              parameterKey : data
            });
         }
       }).fail(function (xhr, status, error) {
         dews.ui.snackbar.info("drf 실패!.")
       });
     }

   /**
    * 조회조건의 모든 파라미터들의 id/value 를 json 형태로 리턴한다.
    * @param {object} dewself this
    * @param {object} panelId 컨디션패널ID
    * @param {object} userParams 페이지단에서 세팅한 파라미터
    * @returns {json} 조회조건의 파라미터 (id, value) 형태 추가
    */
   module.setParamsToJson = function(dewself, panelId, userParams){
    //  var array_searchParams = module.nvl(userParams, "") === "" ? new Array() : userParams;
    var array_searchParams = new Array();
    var $Panel = dewself['$' + panelId];
    var prt_Total = msg_TOTAL;
    var msg_Year, msg_Month, msg_Day;

    if(dewself.user.language === 'ko'){
    	msg_Year = "년";
    	msg_Month = "월";
    	msg_Day = "일";
    }else{
    	msg_Year = msg_Month = msg_Day = ".";
    }

     $Panel.find('[class^="dews-ui"]').each(function (index, value) {
 	    var searchParam = new Object();
 	    var searchParam_nms = new Object();	// 멀티 피커 등등 그리드에 보여지는 조회조건들
 	    var $element = $(value);
       var id = $element.attr('id');
       var paramKey;
       var labelText = "";

       // 프론트에서 id를 oCond 로 쓰는 경우를 커버하기 위해 앞의 소문자 o를 제거
       if(module.nvl(id, "") !== ""){
         paramKey = id.charAt(0) === "o" ? id.replace('o', '').toLowerCase() : id.toLowerCase();
       }

       if( dewself.hasOwnProperty(id)) {
        searchParam.name = paramKey;
 	      searchParam_nms.name = 'prt_' + paramKey;
        labelText = dewself['$' + id].closest("li").children("label")[0].innerText + " : ";
        if(typeof dewself[id].codes === 'function' ) {
     	    searchParam.value = dewself[id].codes().join("|");
     	    // 멀티코드키퍼일때 프린트 용 추가
     	    searchParam_nms.value = labelText.concat(module.nvl(dewself[id].codes(), "") === "" ? prt_Total : "[" + dewself[id].codes()[0] + "] " + dewself[id].inputText.val());
         }else if(typeof dewself[id].code === 'function' ){
          searchParam.value = dewself[id].code();
          // 코드피커일때 프린트 용 추가
          searchParam_nms.value = labelText.concat(module.nvl(dewself[id].code(), "") === "" ? prt_Total : "[" + dewself[id].code() + "] " + dewself[id].text());
        }else if (typeof dewself[id].value === 'function'){
 	    	  searchParam.value = dewself[id].value();
 	        // 프린트 용 추가
     	    searchParam_nms.value = labelText.concat(module.nvl(dewself[id].value(), "") === "" ? prt_Total : "[" + dewself[id].value() + "] " + dewself[id].text());
 	      }else if (typeof dewself[id].getStartDate === 'function'){
 	        searchParam.name = paramKey + "_fr";
 	        searchParam.value = dewself[id].getStartDate();
 	        // 프린트 용 추가
 	        if(module.nvl(dewself[id].getStartDate(), "") !== "" && module.nvl(dewself[id].getEndDate(), "") !== "" &&
         		module.nvl(dewself[id].getStartDate(), "").length == 8	&& module.nvl(dewself[id].getEndDate(), "").length == 8){
 	        	searchParam_nms.value = labelText.concat(dewself[id].getStartDate().substring(0, 4) + msg_Year +
 										dewself[id].getStartDate().substring(4, 6) + msg_Month +
 										dewself[id].getStartDate().substring(6, 8) + msg_Day +
 										" ~ " +
 										dewself[id].getEndDate().substring(0, 4) + msg_Year +
 										dewself[id].getEndDate().substring(4, 6) + msg_Month +
 										dewself[id].getEndDate().substring(6, 8) + msg_Day);
 	        }else if(module.nvl(dewself[id].getStartDate(), "") !== "" && module.nvl(dewself[id].getEndDate(), "") !== "" &&
           module.nvl(dewself[id].getStartDate(), "").length == 6	&& module.nvl(dewself[id].getEndDate(), "").length == 6){
           searchParam_nms.value = labelText.concat(dewself[id].getStartDate().substring(0, 4) + msg_Year +
                   dewself[id].getStartDate().substring(4, 6) + msg_Month +
                   " ~ " +
                   dewself[id].getEndDate().substring(0, 4) + msg_Year +
                   dewself[id].getEndDate().substring(4, 6) + msg_Month);
         }else{
 	        	searchParam_nms.value = labelText + prt_Total;
 	        }
         }else if (typeof dewself[id].text === 'function'){
           searchParam.value = dewself[id].text();
           // 프린트 용 추가
     	    searchParam_nms.value = labelText.concat(module.nvl(dewself[id].text(), "") === "" ? prt_Total : dewself[id].text());
         }

        array_searchParams.push(searchParam);
 	      array_searchParams.push(searchParam_nms);

 	      if (typeof dewself[id].getEndDate === 'function'){
 	        searchParam = new Object();
 	        searchParam.name = paramKey + "_to";
 	        searchParam.value = dewself[id].getEndDate();
 	        array_searchParams.push(searchParam);
 	      }
 	    }
 	  })

    var userParams_cp = userParams;
    // 비교 후 같은 키일경우 값 변경
    for(var k = 0; k < array_searchParams.length; k += 1){
      array_searchParams[k].name = module.nvl(array_searchParams[k].name, "").replace(/\s/gi, "");   // 공백제거
      array_searchParams[k].value = module.nvl(array_searchParams[k].value, ""); 		// null 이 업뎃후 'null'로 들어가넹...

      for( var i = 0; i < userParams.length; i += 1 ) {
        if( userParams[i].name === array_searchParams[k].name ){
          array_searchParams[k].value = userParams[i].value;
          userParams_cp.splice(i, 1);
        }
      }
    }
    // 배열 병합
    if(module.nvl(userParams_cp, "") !== ""){
      array_searchParams = array_searchParams.concat(userParams_cp);
    }

 	  return array_searchParams;
   }

  /**
  * Panel Disable
  * @param {object} dewself this
  * @param {object} panelId Disable 시킬 패널 ID
  * @param {object} onlyClear Disable 하지 않고 패널 clear
  */
  module.disablePanel = function(dewself, panelId, onlyClear) {
    var $panel = dewself['$' + panelId];
    var $panelControl = $panel.find('*[class^=dews-ui-][id]');
    $panelControl.each(function (index, item) {
      var target = dewself[item.id];
      if (target != undefined && onlyClear != false){
        if (target.controlType != undefined) {
          switch (target.controlType) {
            case "input":
            target.text("");
            break;
          }
        } else {
          if (target.options.name != undefined) {
            switch (target.options.name) {
              case "DropDownList":
              target.value("");
              break;
              case "DatePicker":
              target.value("");
              break;
              case "NumericTextBox":
              target.value("");
              break;
              case "MaskedTextBox":
              target.raw("");
              break;
            }
          } else {
            if ($(item).hasClass("dews-ui-codepicker")) {
              target.clearData();
            }else if($(item).hasClass("dews-ui-monthperiodpicker")){
              target.setPeriod("","");
            }
          }
        }
      }
      if (!onlyClear)
        target.enable(false);
    });
  }

  /**
  * Panel enable
  * @param {object} dewself this
  * @param {object} panelId enable 시킬 패널 ID
  */
  module.enablePanel = function(dewself, panelId) {
    var $panel = dewself['$' + panelId];
    var $panelControl = $panel.find('*[class^=dews-ui-][id]');
    $panelControl.each(function (index, item) {
      var target = dewself[item.id];
      if (target != undefined){
        target.enable(true);
      }
    });
  }

  ///// endregion 공통 메서드 /////

  ///// region 공통 메세지 처리 /////

  /**
  * 메세지 ENUM
  * OK_SAVE - 저장 되었습니다. (snack)
  * OK_DELETE - 삭제 되었습니다. (snack)
  * NO_COND_DATA - 조건에 해당되는 데이터가 없습니다. (snack)
  * NO_SELECT_ROW - 선택된 행이 없습니다. (snack)
  * EXISTS_DATA - 존재하는 데이터 입니다. (snack)
  * AFTER_SELECT - 조회 후 진행 하십시오. (snack)
  * TOTAL - [ 전 체 ]
  */
  module.MsgEnum = {
    OK_SAVE : 0,
    OK_DELETE : 1,
    NO_COND_DATA : 2,
    NO_SELECT_ROW : 3,
    EXISTS_DATA : 4,
    AFTER_SELECT : 5,
    TOTAL : 6
  };

  /**
   * 스크립트 다국어 처리 지원하지 않아 최초 스크립트 로딩시에 직접 백단 호출 통해 다국어 처리
   */
  var msg_OK_SAVE = '저장 되었습니다.';
  dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBSSService", "npbbss_msg_common"), {
    async : false,
    data: {
      text: msg_OK_SAVE
    }
  }).done(function(data){
    msg_OK_SAVE = data;
  });
  var msg_OK_DELETE = '삭제 되었습니다.';
  dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBSSService", "npbbss_msg_common"), {
    async : false,
    data: {
      text: msg_OK_DELETE
    }
  }).done(function(data){
    msg_OK_DELETE = data;
  });
  var msg_NO_COND_DATA = '조건에 해당되는 데이터가 없습니다.';
  dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBSSService", "npbbss_msg_common"), {
    async : false,
    data: {
      text: msg_NO_COND_DATA
    }
  }).done(function(data){
    msg_NO_COND_DATA = data;
  });
  var msg_NO_SELECT_ROW = '선택된 행이 없습니다.';
  dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBSSService", "npbbss_msg_common"), {
    async : false,
    data: {
      text: msg_NO_SELECT_ROW
    }
  }).done(function(data){
    msg_NO_SELECT_ROW = data;
  });
  var msg_EXISTS_DATA = '존재하는 데이터 입니다.';
  dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBSSService", "npbbss_msg_common"), {
    async : false,
    data: {
      text: msg_EXISTS_DATA
    }
  }).done(function(data){
    msg_EXISTS_DATA = data;
  });
  var msg_AFTER_SELECT = '조회 후 진행 하십시오.';
  dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBSSService", "npbbss_msg_common"), {
    async : false,
    data: {
      text: msg_AFTER_SELECT
    }
  }).done(function(data){
    msg_AFTER_SELECT = data;
  });
  var msg_TOTAL = '[ 전 체 ]';
  dews.api.get(dews.url.getApiUrl("BM", "NonProfitBudgetBSSService", "npbbss_msg_common"), {
    async : false,
    data: {
      text: msg_TOTAL
    }
  }).done(function(data){
    msg_TOTAL = data;
  });

  /**
  * 메세지 SHOW
  * @param {MsgEnum} type 메세지 타입
  */
  module.showMsg = function(type) {
    if (type == module.MsgEnum.OK_SAVE) {
      dews.ui.snackbar.ok(msg_OK_SAVE);
    } else if (type == module.MsgEnum.OK_DELETE) {
      dews.ui.snackbar.ok(msg_OK_DELETE);
    } else if (type == module.MsgEnum.NO_COND_DATA) {
      dews.ui.snackbar.warning(msg_NO_COND_DATA);
    } else if (type == module.MsgEnum.NO_SELECT_ROW) {
      dews.ui.snackbar.warning(msg_NO_SELECT_ROW);
    } else if (type == module.MsgEnum.EXISTS_DATA) {
      dews.ui.snackbar.warning(msg_EXISTS_DATA);
    } else if (type == module.MsgEnum.AFTER_SELECT) {
      dews.ui.snackbar.warning(msg_AFTER_SELECT);
    }
  }

  ///// endregion 공통 메세지 처리 /////

  ///// region 공통 메뉴 호출 처리 /////

  /**
  * 메인버튼 Disable
   * 메뉴이동 공통
   * @param {object} initData 더블클릭한데이터
   * @param {object} fg_menu 메뉴구분 1 결의서입력, 2 품의서입력, 3 원인행위등록, 4 전표입력, 5 반제결의서
   */
  module.setOpenMenuParams = function (initData, menu_fg) {
    if (initData != null) {
      if (menu_fg == '1') {
        if (!initData.ABDOCU_DT) {
          return;
        }

        var menuParams = {
          ACCSEQ_SQ: initData.ACCSEQ_SQ,           //회계기수
          PC_CD: initData.PC_CD,                   //회계단위코드
          PC_NM: initData.PC_NM,                   //회계단위명
          ABDOCU_DT: module.getDateString(initData.ABDOCU_DT),           //결의일(날자포맷 그대로)
          ABDOCU_SQ: initData.ABDOCU_SQ,           //결의순번
          WRT_DEPT_CD: initData.WRT_DEPT_CD,             //작성부서코드
          WRT_DEPT_NM: initData.WRT_DEPT_NM,             //작성부서명
          WRT_EMP_NO: initData.WRT_EMP_NO,     //작성자 사원번호
          WRT_EMP_NM: initData.WRT_EMP_NM      //작성자명
        };
        dews.ui.openMenu('BM', 'NPBBES00300', menuParams);
      }
      else if (menu_fg == '2') {
        if (!initData.ABIN_DT) {
          return;
        }

        var menuParams = {
          ACCSEQ_SQ: initData.ACCSEQ_SQ,           //회계기수
          PC_CD: initData.PC_CD,                   //회계단위코드
          PC_NM: initData.PC_NM,                   //회계단위명
          ABIN_DT: module.getDateString(initData.ABIN_DT),               //품의일(날자포맷 그대로)
          ABIN_SQ: initData.ABIN_SQ,               //품의순번
          WRT_DEPT_CD: initData.WRT_DEPT_CD,             //작성부서코드
          WRT_DEPT_NM: initData.WRT_DEPT_NM,             //작성부서명
          WRT_EMP_NO: initData.WRT_EMP_NO,     //작성자 사원번호
          WRT_EMP_NM: initData.WRT_EMP_NM,      //작성자명
          ABIN_TP : initData.ABIN_TP
        };
        dews.ui.openMenu('BM', 'NPBBES00100', menuParams);
      }
      else if (menu_fg == '3') {
        if (!initData.ABIN_DT) {
          return;
        }

        var menuParams = {
          ACCSEQ_SQ: initData.ACCSEQ_SQ,           //회계기수
          ABIN_DT: module.getDateString(initData.ABIN_DT),               //품의일(날자포맷 그대로)
          ABIN_SQ: initData.ABIN_SQ,               //품의순번
          CAUSE_DT: module.getDateString(initData.CAUSE_DT),               //원인행위일(날자포맷 그대로)
          CAUSE_SQ: initData.CAUSE_SQ,               //원인행위순번
        };
        dews.ui.openMenu('BM', 'NPBBES00200', menuParams);
      }
      else if (menu_fg == '4') {
        if (!initData.ABDOCU_DT || !initData.DOCU_NO) {
          return;
        }

        var menuParams = {
          PC_CD: initData.PC_CD,                   //회계단위코드
          PC_NM: initData.PC_NM,                   //회계단위명
          WRT_DEPT_CD: initData.DOCU_WRT_DEPT_CD,        //작성부서코드
          WRT_DEPT_NM: initData.DOCU_WRT_DEPT_NM,        //작성부서명
          WRT_EMP_NO: initData.DOCU_WRT_EMP_NO,//작성자 사원번호
          WRT_KOR_NM: initData.DOCU_WRT_EMP_NM,//작성자명
          ACTG_DT: module.getDateString(initData.ACTG_DT),               //회계일
          WRT_DT: module.getDateString(initData.ABDOCU_DT),            //작성일
          DOCU_NO: initData.DOCU_NO,               //전표번호
        };
        dews.ui.openMenu('FI', 'GLDDOC00500', menuParams);
      }
      else if (menu_fg == '5') {
        if (!initData.ABDOCU_BAN_DT) {
          return;
        }

        var menuParams = {
          ACCSEQ_SQ: initData.ACCSEQ_SQ,           //회계기수
          PC_CD: initData.PC_CD,                   //회계단위코드
          PC_NM: initData.PC_NM,                   //회계단위명
          ABDOCU_DT: module.getDateString(initData.ABDOCU_BAN_DT),       //반제결의서일(날자포맷 그대로)
          ABDOCU_SQ: initData.ABDOCU_BAN_SQ,       //반제결의서순번
          WRT_DEPT_CD: initData.WRT_DEPT_CD,             //작성부서코드
          WRT_DEPT_NM: initData.WRT_DEPT_NM,             //작성부서명
          WRT_EMP_NO: initData.WRT_EMP_NO,     //작성자 사원번호
          WRT_EMP_NM: initData.WRT_EMP_NM      //작성자명
        };
        dews.ui.openMenu('BM', 'NPBBES00300', menuParams);
      }
      if (menu_fg == '6') {
        if (!initData.ABDOCU_DT) {
          return;
        }

        var menuParams = {
          ACCSEQ_SQ: initData.ACCSEQ_SQ,           //회계기수
          PC_CD: initData.PC_CD,                   //회계단위코드
          PC_NM: initData.PC_NM,                   //회계단위명
          ABDOCU_DT: module.getDateString(initData.ABDOCU_DT),           //결의일(날자포맷 그대로)
          ABDOCU_SQ: initData.ABDOCU_SQ,           //결의순번
          WRT_DEPT_CD: initData.WRT_DEPT_CD,             //작성부서코드
          WRT_DEPT_NM: initData.WRT_DEPT_NM,             //작성부서명
          WRT_EMP_NO: initData.WRT_EMP_NO,     //작성자 사원번호
          WRT_EMP_NM: initData.WRT_EMP_NM      //작성자명
        };
        dews.ui.openMenu('BM', 'NPBBES00600', menuParams);
      }
      if (menu_fg == '7') {
        if (!initData.ABDOCU_DT) {
          return;
        }

        var menuParams = {
          ACCSEQ_SQ: initData.ACCSEQ_SQ,           //회계기수
          PC_CD: initData.PC_CD,                   //회계단위코드
          PC_NM: initData.PC_NM,                   //회계단위명
          ABDOCU_DT: module.getDateString(initData.ABDOCU_DT),           //결의일(날자포맷 그대로)
          ABDOCU_SQ: initData.ABDOCU_SQ,           //결의순번
          WRT_DEPT_CD: initData.WRT_DEPT_CD,             //작성부서코드
          WRT_DEPT_NM: initData.WRT_DEPT_NM,             //작성부서명
          WRT_EMP_NO: initData.WRT_EMP_NO,     //작성자 사원번호
          WRT_EMP_NM: initData.WRT_EMP_NM,     //작성자명
          ABDOCU_TP: initData.ABDOCU_TP
        };
        dews.ui.openMenu('BM', 'NPBBES00500', menuParams);
      }

    }
  }

  module.getDateString = function (date) {
    if(!date) {
      return;
    }
    if (typeof date === 'string') {
      return date;
    }
    else {
      var abdocu_dt = "" + date.getFullYear() + dews.number.format(date.getMonth() + 1, "00") + dews.number.format(date.getDate(), "00");
      if(abdocu_dt.length < 8) {
        return;
      }

      return abdocu_dt;
    }
  }

  ///// endregion 공통 메뉴 호출 처리 /////

    ///// region 공통 관리항목 처리 /////

  /**
   * 관리항목 공통
   * @param {object} dewself this
   * @param {object} type_fg A.예산편성, B.예산집행
   * @param {object} bgexec_tp 100.품의서, 200.원인행위, 300.결의서, 400.수입/지출
   */
  var dictionaryData = {};
  module.mgmtPage = function(dewself, p_type_fg, p_bgexec_tp) {
    var mgmtUseYn = false;
    var mgmtGridDataSource;
    var type_fg = p_type_fg;
    var bgexec_tp = p_bgexec_tp;

    // 관리항목 사용여부
    dews.api.get(dews.url.getApiUrl('BM', 'NonProfitBudgetBPSService', 'npbbps00300_abgconfig_mst_list'), {
      async : false,
      data:{
        bgconfig_cd : 'BM01000',
      }}).done(function(data){
        if(data.length > 0){
          mgmtUseYn = data[0].USE_YN == 'Y' ? true : false;
        }
      }).fail(function(xhr, status, error){
        dews.error(error);
      });

    // jquery 확장함수
    // 컨트롤의 class 기능을 가져옴(ex) class="dews-ui-button")
    $.extend($.fn, {
      getDewsControl: function () {
        "use strict";
        var self = this;
        var dewsControl;
        try {
          var classes = this.prop("class").split(/\s+/);
          $.each(classes, function (idx, cls) {
            if (cls.indexOf("dews-ui-") > -1) {
              var controlType = cls.replace(/-/g, ".");
              dewsControl = eval(controlType + "(self)");
              return false
            }
          });
        }
        catch (ex) {
          throw ex;
        }
        return dewsControl;
      }
    });

    return{
      setMgmtInit : function(containerId, gridDetail, gridFocus, keyColumn1, keyColumn2, keyColumn3, keyColumn4, keyColumn5, keyColumn6, keyColumn7, keyColumn8, keyColumn9){
        // 관리항목 사용여부 체크
        if(!mgmtUseYn){
          return;
        }

        var BM = this;

        // 커스텀 그리드 생성
        var html =  '<div style="margin-bottom:5px; border-bottom:2px solid #666666;"></div>' +
                    '<span style="margin-left:5px; font-size:13px; color:#379DFB;">관리항목</span>' +
                    '<button class="dews-ui-button" id="btnSaveId" style="height:24px; float: right;">저장</button>' +
                    '<div style="margin-top:7px; border-bottom:3px solid #666666;"></div>' +
                    '<div class="dews-container-panel" style="margin-top:7px;">' +
                      '<div class="dews-container-item">' +
                        '<div class="dews-custom-ui" style="border: 1px solid #737173" id="controlItem">' +
                          '<div style="height:324px;">' +
                            '<table style="table-layout:fixed; border-collapse: collapse;">' +
                              '<thead style="display:block;">' +
                                '<tr>' +
                                  '<th class="dews-ui-multilingual">' +
                                    '항목명' +
                                  '</th>' +
                                  '<th class="dews-ui-multilingual">' +
                                    '내역명' +
                                  '</th>' +
                                '</tr>' +
                              '</thead>' +
                              '<tbody style="display:block;overflow-y: auto; overflow-x:hidden; height:324px;margin-top:-1px;">' +
                              '</tbody>' +
                            '</table>' +
                          '</div>' +
                        '</div>' +
                        '<div style="margin-top:5px; border-bottom:2px solid #666666;"></div>' +
                      '</div>' +
                    '</div>';

        // 관리항목 추가
        dewself['$' + containerId].append(html);

        var containerWidth = '273px';
        if(dewself.menu.id == "NPBBPS00500"){
          // 에산조정등록의 메뉴일 경우 스크롤이 생겨서 너비가 틀어져서 width 변경
          containerWidth = '293px';
        }

        dewself.$content.find('#' + containerId).css('width', containerWidth);
        $(window).trigger('resize');
        dewself.$content.find('#btnSaveId').getDewsControl();

        var $tbody = dewself.$content.find("#controlItem").find("tbody");
        $tbody.empty();

        // 관리항목 마스터 데이터 조회
        dews.api.get(dews.url.getApiUrl('BM', 'CommonAbmngService', 'common_fi_abmng_mst_list'), {
          data: {
            type_fg: type_fg
          }
        }).done(function (data) {
          $.each(data, function(idx, dataitem){
              // 테이블에 행 추가
              var $tr = $("<tr></tr>");
              $tbody.append($tr);
              $tr.append("<td style='text-align:right;'>" + dataitem.MCLS_NM + "</td>");
              $tr.append("<td></td>");

              // 컬럼에 컨트롤 생성
              var $tr2 = $($tbody.find("tr").get(idx));
              var $control;

              // MNGITEMCD_YN = Y.도움창, N.문자열/숫자
              // MNGITEMTP_CD = 0.일반, 1.날짜, 2.금액, 3.수량, 4.율(%), 5.기간(년월일), 6.환율(%), 7.내역없음, 8.목록, 9.번호
              // MA00001 = 수량 소수점 자리수
              // MA00002 = 단가 소수점 자리수
              // MA00003 = 금액 소수점 자리수
              // MA00004 = 외화단가 소수점 자리수
              // MA00005 = 외화금액 소수점 자리수
              // MA00006 = 환율 소수점 자리수
              // MA00007 = 연월일 포맷
              // MA00008 = 연월 포맷
              // MA00009 = 비율 소수점 자리수
              // MA00010 = 세율 소수점 자리수
             var formatType = dataitem.MNGITEMTP_CD === "1" ? 'MA00007' :
                              dataitem.MNGITEMTP_CD === "2" ? 'MA00003' :
                              dataitem.MNGITEMTP_CD === "3" ? 'MA00001' :
                              dataitem.MNGITEMTP_CD === "4" ? 'MA00006' :
                              dataitem.MNGITEMTP_CD === "6" ? 'MA00006' : {};

              $control = dataitem.MNGITEMCD_YN === "Y" ? $("<input id='control_" + (idx + 1) + "'" + "class='dews-ui-codepicker' type='text' data-target='MNGD_CD' data-target-text='MNGD_NM' data-dirty=false data-mcls-cd=" + dataitem.MCLS_CD + ">") :
                         ( dataitem.MNGITEMTP_CD === "2" || dataitem.MNGITEMTP_CD === "3" ||
                           dataitem.MNGITEMTP_CD === "4" || dataitem.MNGITEMTP_CD === "6") ? $("<input id= 'control_" + (idx + 1) + "'" + "class='dews-ui-numerictextbox' type='text' data-target='MNGD_VN' data-dews-format=" + "'" + formatType + "'" +  "data-dews-format-predefined='true' data-dirty=false data-mcls-cd=" + dataitem.MCLS_CD + ">") :
                         dataitem.MNGITEMTP_CD === "1" ? $("<input id='control_" + (idx + 1) + "'" + "class='dews-ui-datepicker' type='text' data-target='MNGD_NM' data-dirty=false data-mcls-cd=" + dataitem.MCLS_CD + ">") :
                                                        $("<input id='control_" + (idx + 1) + "'" + "class='dews-ui-textbox' type='text' data-target='MNGD_NM' data-dirty=false data-mcls-cd=" + dataitem.MCLS_CD + ">");

              var $td = $tr2.find("td:nth-child(2)");
              $td.append($control);
              $tr2.append($td);

              if($control){
                var dewsControl = $control.getDewsControl();
                if($control.hasClass("dews-ui-codepicker")){
                  dewsControl.setOptions($.extend({},dewsControl.options, { helpCode: "H_BM_ABMNG_DTL_S", helpParams: { type_fg: type_fg, mcls_cd: dataitem.MCLS_CD }, codeField: "MNGD_CD", textField: "MNGD_NM", helpSize: "medium" }));
                }
                else if($control.hasClass("dews-ui-datepicker")){
                }
                else if($control.hasClass("dews-ui-numerictextbox")){
                }
                else if($control.hasClass("dews-ui-textbox")){
                }

                if(dataitem.MNDR_YN == "Y"){
                  dewsControl.required(true);
                }
              }

              // 키처리 이벤트(문자열/숫자)
              $control.on("keydown", function(e){
                // Enter 키일 때
                if(e.keyCode == "13"){
                  var controlIndex = dewself.$content.find(".dews-custom-ui div table tbody tr td input[tabindex!='-1']:not(.readonly):not([readonly]):visible").index(this);
                  // 마지막 항목일 경우
                  if(controlIndex == dewself.$content.find(".dews-custom-ui div table tbody tr td input[tabindex!='-1']:not(.readonly):not([readonly]):visible").length - 1){
                    if(dewself.menu.id == "NPBBES00100"){
                      gridFocus.setFocus();
                      gridFocus.select(gridFocus.dataItems().length - 1);
                    }
                    else{
                      dewself.$content.find(".dews-custom-ui div table tbody tr td input[tabindex!='-1']:not(.readonly):not([readonly]):visible").get(0).focus();
                    }
                  }
                  else{
                    dewself.$content.find(".dews-custom-ui div table tbody tr td input[tabindex!='-1']:not(.readonly):not([readonly]):visible").get(controlIndex + 1).focus();
                  }
                }
              });

              // 키처리 이벤트(도움창)
              $control.next(".dews-codepicker-text").on("keydown", function(e){
                  // Enter 키일 때
                  if(e.keyCode == "13"){
                    var controlIndex = dewself.$content.find(".dews-custom-ui div table tbody tr td input[tabindex!='-1']:not(.readonly):not([readonly]):visible").index(this);
                    // 마지막 항목일 경우
                    if(controlIndex == dewself.$content.find(".dews-custom-ui div table tbody tr td input[tabindex!='-1']:not(.readonly):not([readonly]):visible").length - 1){
                      if(dewself.menu.id == "NPBBES00100"){
                        gridFocus.setFocus();
                        gridFocus.select(gridFocus.dataItems().length - 1);
                      }
                      else{
                        dewself.$content.find(".dews-custom-ui div table tbody tr td input[tabindex!='-1']:not(.readonly):not([readonly]):visible").get(0).focus();
                      }
                    }
                    else{
                      dewself.$content.find(".dews-custom-ui div table tbody tr td input[tabindex!='-1']:not(.readonly):not([readonly]):visible").get(controlIndex + 1).focus();
                    }
                  }
              });

              // 관리항목 변경될 때 이벤트(도움창)
              $control.on('setData', function(e){
                if(module.nvl(e.code, '') !== module.nvl(e.target.parentNode.getElementsByTagName('input')[1].getAttribute('data-original-title'), '')){
                  e.target.parentNode.getElementsByTagName('input')[0].setAttribute('data-dirty', 'true');
                }
                else{
                  e.target.parentNode.getElementsByTagName('input')[0].setAttribute('data-dirty', 'false');
                }
              });
          });

          // 테이블 스타일 적용
          dewself.$content.find('.dews-custom-ui table th').css({'font-size': '12px', 'text-align': 'center', 'background-color': '#f0f0f0', 'height': '23px', 'border': '1px solid #e1e1e1'});
          dewself.$content.find('.dews-custom-ui table thead tr th:nth-child(1)').css({'width': '100px'});
          dewself.$content.find('.dews-custom-ui table thead tr th:nth-child(2)').css({'width': '173px'});
          dewself.$content.find('.dews-custom-ui table tbody tr td').css({'border': '1px solid #e1e1e1'});
          dewself.$content.find('.dews-custom-ui table tbody tr td:nth-child(1)').css({'width': '100px'});
          dewself.$content.find('.dews-custom-ui table tbody tr td:nth-child(2)').css({'width': '173px'});

          BM.setMgmtEnabled(false);

        }).fail(function (xhr, status, error) {
          dews.error(error);
        });

        // 키 값 생성(메뉴마다 자기자신만의 데이터를 가지고 있어야 함)
        datasourceKey = 'datasourceKey' + '_' + dewself.menu.id;

        // 그리드 데이터소스 생성
        mgmtGridDataSource = BM.setGridDataSource(datasourceKey);

        // 키 값 저장
        if(datasourceKey in dictionaryData == false)
         dictionaryData[datasourceKey] = mgmtGridDataSource;

        // 저장 버튼
        dewself.$content.find('#btnSaveId').on('click', function (e) {
          BM.setMgmtSave(gridDetail, keyColumn1, keyColumn2, keyColumn3, keyColumn4, keyColumn5, keyColumn6, keyColumn7, keyColumn8, keyColumn9);
        });

        // 관리항목 변경될 때 이벤트(문자열/숫자)
        dewself.$content.find('#' + containerId).on('change', function (e) {
          if(e.target.className.startsWith('dews-codepicker-text')){
            return;
          }
          else if(e.target.className.startsWith('dews-ui-numerictextbox')){
            e.target.parentNode.getElementsByTagName('input')[1].setAttribute('data-dirty', 'true');
          }
          else if(e.target.className.startsWith('dews-ui-textbox')){
            e.target.parentNode.getElementsByTagName('input')[0].setAttribute('data-dirty', 'true');
          }
          else if(e.target.className.startsWith('dews-ui-datepicker')){
            e.target.parentNode.getElementsByTagName('input')[0].setAttribute('data-dirty', 'true');
          }
        });
      },
      setGridDataSource : function(datasourceKey){
        var returnGridDataSource = dews.ui.dataSource(datasourceKey, {
          schema: {
            model: {
              id: 'schema',
              fields: [
                { field: 'COMPANY_CD' },
                { field: 'ABDOCU_DT' },
                { field: 'ABDOCU_SQ' },
                { field: 'BGACCT_SQ' },
                { field: 'PARTNER_SQ' },
                { field: 'BGEXEC_TP' },
                { field: 'PC_CD' },
                { field: 'BG_CD' },
                { field: 'ACCSEQ_SQ' },
                { field: 'BG_SQ' },
                { field: 'BGACCT_CD' },
                { field: 'BGAPPLY_YM' },
                { field: 'BGBASIS_TP' },
                { field: 'PRINT_ADJT_SQ' },
                { field: 'PRINT_SQ' },
                { field: 'MCLS_CD' },
                { field: 'MCLS_NM' },
                { field: 'MNGD_CD' },
                { field: 'MNGD_NM' },
                { field: 'MNGD_VN' },
                { field: 'INSERT_ID' },
                { field: 'INSERT_DTS' },
                { field: 'UPDATE_ID' },
                { field: 'UPDATE_DTS' },
              ]
            }
          }
        });
        return returnGridDataSource;
      },
      selectList : function(keyColumn1, keyColumn2, keyColumn3, keyColumn4, keyColumn5, keyColumn6, keyColumn7, keyColumn8, keyColumn9){
        if(type_fg == 'A'){
          // 날짜 컬럼 체크
          if(module.nvl(keyColumn6, '') !== '' && keyColumn6.length !== 6){
            keyColumn6 = keyColumn6.getFullYear() + dews.number.format(keyColumn6.getMonth() + 1, '00');
          }

          dews.api.get(dews.url.getApiUrl('BM', 'CommonAbmngService', 'common_fi_abgt_info_list'), {
            async : false,
            data:{
              pc_cd : keyColumn1,
              bg_cd : keyColumn2,
              accseq_sq : keyColumn3,
              bg_sq : keyColumn4,
              bgacct_cd : keyColumn5,
              bgapply_ym : keyColumn6,
              bgbasis_tp : keyColumn7,
              print_adjt_sq : keyColumn8,
              print_sq : keyColumn9,
            }}).done(function(data){
              mgmtGridDataSource.data([]);
              mgmtGridDataSource.data(data);

              $.each(mgmtGridDataSource.data(), function(idx, dataItem){
                getMgmtData(idx, dataItem);
              });
            }).fail(function(xhr, status, error){
              dews.error(error);
            });
        }
        else if(type_fg == 'B'){
          // 날짜 컬럼 체크
          if(module.nvl(keyColumn1, '') !== '' && keyColumn1.length !== 8){
            keyColumn1 = module.dateToString(keyColumn1);
          }

          dews.api.get(dews.url.getApiUrl('BM', 'CommonAbmngService', 'common_fi_abdocu_info_list'), {
            async : false,
            data:{
              abdocu_dt : keyColumn1,
              abdocu_sq : keyColumn2,
              bgacct_sq : keyColumn3,
              partner_sq : keyColumn4,
              bgexec_tp : bgexec_tp
          }}).done(function(data){
            mgmtGridDataSource.data([]);
            mgmtGridDataSource.data(data);

            $.each(mgmtGridDataSource.data(), function(idx, dataItem){
              getMgmtData(idx, dataItem);
            });
          }).fail(function(xhr, status, error){
            dews.error(error);
          });
        }

        function getMgmtData(idx, dataItem){
          var $control = dewself.$content.find('#' + 'control_' + (idx + 1));
          if($control.length > 0){
            var dewsControl = $control.getDewsControl();
            if($control.hasClass('dews-ui-codepicker')){
              dewsControl.setData({ MNGD_CD: dataItem.MNGD_CD, MNGD_NM: dataItem.MNGD_NM }, false);
            }
            else if($control.hasClass('dews-ui-numerictextbox')){
              if(dataItem.MNGD_VN === 0){
                dataItem.MNGD_VN = null;
              }

              dewsControl.value(dataItem.MNGD_VN);
            }
            else if($control.hasClass('dews-ui-textbox')){
              dewsControl.text(dataItem.MNGD_NM);
            }
            else if($control.hasClass('dews-ui-datepicker')){
              if(module.nvl(dataItem.MNGD_NM, '') !== '' && dataItem.MNGD_NM.indexOf('-') !== -1){
                dewsControl.value(dataItem.MNGD_NM.replace(/-/gi, ''));
              }
              else{
                dewsControl.value(dataItem.MNGD_NM);
              }
            }

            dewsControl.enable(true);
          }
        }
      },
      getMgmtDirty : function(){
        var msgDirty = "NOT_SAVE";
        var $trs = dewself.$content.find('#controlItem tbody tr');

        $trs.each(function(idx){
          var $control = dewself.$content.find('#' + 'control_' + (idx + 1));
          var currowData = $control.data();

          var isControlTypeValue = $control.hasClass('dews-ui-codepicker') ? currowData.code :
                                   $control.hasClass('dews-ui-numerictextbox') ? module.emptyToZero(currowData.dewsControl.element.val()) :
                                   currowData.dewsControl.element.val();

          if($control.attr('data-dirty') === 'true'){
            msgDirty = "YES_SAVE";
          }

          if($control[0].className.indexOf('required') !== -1 && $control.attr('disabled') !== 'disabled' && module.nvl(isControlTypeValue, '') === ''){
            dews.alert('필수 값이 입력되지 않은 항목이 있습니다.', 'warning');
            msgDirty = "NOT_ACCEPT";
            return false;
          }
        });

        return msgDirty;
      },
      setMgmtSave : function(gridDetail, keyColumn1, keyColumn2, keyColumn3, keyColumn4, keyColumn5, keyColumn6, keyColumn7, keyColumn8, keyColumn9){
        var BM = this;

        if(BM.getMgmtDirty() == "NOT_SAVE" || BM.getMgmtDirty() == "NOT_ACCEPT"){
          return;
        }

        // 키 값 생성(메뉴마다 자기자신만의 데이터를 가지고 있어야 함)
        datasourceKey = 'datasourceKey' + '_' + dewself.menu.id;

        // 키 값 가져오기
        mgmtGridDataSource = dictionaryData[datasourceKey];
        mgmtGridDataSource.data([]);

        var $trs = dewself.$content.find("#controlItem tbody tr");

        $trs.each(function(idx){
          var $control = dewself.$content.find('#' + 'control_' + (idx + 1));
          var currowData = $control.data();
          var mngd_cd = $control.hasClass("dews-ui-codepicker") ? currowData.code : $control.hasClass("dews-ui-numerictextbox") ? "" : "";
          var mngd_nm = $control.hasClass("dews-ui-codepicker") ? currowData.text : $control.hasClass("dews-ui-numerictextbox") ? "" : currowData.dewsControl.element.val();
          var mngd_vn = $control.hasClass("dews-ui-codepicker") ? 0 : $control.hasClass("dews-ui-numerictextbox") ? module.emptyToZero(currowData.dewsControl.element.val()) : 0;

          // 화면에 그려진 컨트롤의 데이터 생성
          mgmtGridDataSource.data().push({ MCLS_CD: currowData.mclsCd,
                                           MNGD_CD: mngd_cd,
                                           MNGD_NM: mngd_nm,
                                           MNGD_VN: mngd_vn });

          // 모든 관리항목의 데이터를 수정없음으로 변경
          $control.attr('data-dirty', 'false');
        });

        if(type_fg == 'A'){
          var p_pc_cd = gridDetail.getCellValue(gridDetail.select(), keyColumn1);
          var p_bg_cd = gridDetail.getCellValue(gridDetail.select(), keyColumn2);
          var p_accseq_sq = gridDetail.getCellValue(gridDetail.select(), keyColumn3);
          var p_bg_sq = gridDetail.getCellValue(gridDetail.select(), keyColumn4);
          var p_bgacct_cd = gridDetail.getCellValue(gridDetail.select(), keyColumn5);

          // 날짜 컬럼 체크
          var p_bgapply_ym = gridDetail.getCellValue(gridDetail.select(), keyColumn6);
          if(module.nvl(p_bgapply_ym, "") !== "" && p_bgapply_ym.length != 6){
            p_bgapply_ym = p_bgapply_ym.getFullYear() + dews.number.format(p_bgapply_ym.getMonth() + 1, "00");
          }

          var p_bgbasis_tp = gridDetail.getCellValue(gridDetail.select(), keyColumn7);
          var p_print_adjt_sq = gridDetail.getCellValue(gridDetail.select(), keyColumn8);
          var p_print_sq = gridDetail.getCellValue(gridDetail.select(), keyColumn9);
            dews.api.batchSave(dews.url.getApiUrl("BM", "CommonAbmngService", "common_fi_abgt_info_save"), {
              data :{
                gridDataSource : JSON.stringify (mgmtGridDataSource.getDirtyData()),
                pc_cd : p_pc_cd,
                bg_cd : p_bg_cd,
                accseq_sq : p_accseq_sq,
                bg_sq : p_bg_sq,
                bgacct_cd : p_bgacct_cd,
                bgapply_ym : p_bgapply_ym,
                bgbasis_tp : p_bgbasis_tp,
                print_adjt_sq : p_print_adjt_sq,
                print_sq : p_print_sq,
              }
            }).done(function(data){
              dews.ui.snackbar.ok("저장되었습니다.");
              BM.selectList(p_pc_cd, p_bg_cd, p_accseq_sq, p_bg_sq, p_bgacct_cd, p_bgapply_ym, p_bgbasis_tp, p_print_adjt_sq, p_print_sq);
            }).fail(function(e){
              dews.ui.snackbar.error('데이터 저장 중 오류가 발생했습니다.', 'info');
            });
        }
        else if(type_fg == 'B'){
          // 날짜 컬럼 체크
          var p_abdocu_dt = gridDetail.getCellValue(gridDetail.select(), keyColumn1);
          if(module.nvl(p_abdocu_dt, "") !== "" && p_abdocu_dt.length != 8){
            p_abdocu_dt = module.dateToString(p_abdocu_dt);
          }

          var p_abdocu_sq = gridDetail.getCellValue(gridDetail.select(), keyColumn2);
          var p_bgacct_sq = gridDetail.getCellValue(gridDetail.select(), keyColumn3);
          var p_partner_sq = keyColumn4 == "1" ? keyColumn4 : gridDetail.getCellValue(gridDetail.select(), keyColumn4);
            dews.api.batchSave(dews.url.getApiUrl("BM", "CommonAbmngService", "common_fi_abdocu_info_save"), {
              data :{
                gridDataSource : JSON.stringify (mgmtGridDataSource.getDirtyData()),
                abdocu_dt : p_abdocu_dt,
                abdocu_sq : p_abdocu_sq,
                bgacct_sq : p_bgacct_sq,
                partner_sq : p_partner_sq,
                bgexec_tp : bgexec_tp
              }
            }).done(function(data){
              dews.ui.snackbar.ok("저장되었습니다.");
              BM.selectList(p_abdocu_dt, p_abdocu_sq, p_bgacct_sq, p_partner_sq);
            }).fail(function(e){
              dews.ui.snackbar.error('데이터 저장 중 오류가 발생했습니다.', 'info');
            });
        }
      },
      setMgmtDelete : function(gridH, gridC, gridD, keyColumn1, keyColumn2, keyColumn3, keyColumn4, keyColumn5, keyColumn6, keyColumn7, keyColumn8, keyColumn9){
        // 관리항목 사용여부 체크
        if(!mgmtUseYn){
          return;
        }

        var deletedH = {Deleted: []};
        var deletedC = {Deleted: []};
        var deletedD = {Deleted: []};
        var url;

        if(type_fg == 'A'){
          var bgapply_ym;

          if(gridC){
            $.each(gridC, function(idx, dataItem){
              bgapply_ym = dataItem[keyColumn6];
              if(module.nvl(bgapply_ym, "") !== "" && bgapply_ym.length != 6){
                bgapply_ym = module.dateToString(dataItem[keyColumn6]);
              }

              deletedC.Deleted.push({"PC_CD": dataItem[keyColumn1],
                                     "BG_CD": dataItem[keyColumn2],
                                     "ACCSEQ_SQ": dataItem[keyColumn3],
                                     "BG_SQ": dataItem[keyColumn4],
                                     "BGACCT_CD": dataItem[keyColumn5],
                                     "BGAPPLY_YM": bgapply_ym,
                                     "BGBASIS_TP": dataItem[keyColumn7],
                                     "PRINT_ADJT_SQ": dataItem[keyColumn8]});
            });
          }

          if(gridD){
            $.each(gridD, function(idx, dataItem){
              bgapply_ym = dataItem[keyColumn6];
              if(module.nvl(bgapply_ym, "") !== "" && bgapply_ym.length != 6){
                bgapply_ym = module.dateToString(dataItem[keyColumn6]);
              }

              deletedD.Deleted.push({"PC_CD": dataItem[keyColumn1],
                                     "BG_CD": dataItem[keyColumn2],
                                     "ACCSEQ_SQ": dataItem[keyColumn3],
                                     "BG_SQ": dataItem[keyColumn4],
                                     "BGACCT_CD": dataItem[keyColumn5],
                                     "BGAPPLY_YM": bgapply_ym,
                                     "BGBASIS_TP": dataItem[keyColumn7],
                                     "PRINT_ADJT_SQ": dataItem[keyColumn8],
                                     "PRINT_SQ": dataItem[keyColumn9]});
            });
          }

          url = "common_fi_abgt_info_delete";
        }
        else if(type_fg == 'B'){
          var abdocu_dt;

          if(gridH){
            $.each(gridH, function(idx, dataItem){
              abdocu_dt = dataItem[keyColumn1];
              if(module.nvl(abdocu_dt, "") !== "" && abdocu_dt.length != 8){
                abdocu_dt = module.dateToString(dataItem[keyColumn1]);
              }
              deletedH.Deleted.push({"ABDOCU_DT": abdocu_dt,
                                     "ABDOCU_SQ": dataItem[keyColumn2],
                                     "BGEXEC_TP": bgexec_tp});
            });
          }

          if(gridC){
            $.each(gridC, function(idx, dataItem){
              abdocu_dt = dataItem[keyColumn1];
              if(module.nvl(abdocu_dt, "") !== "" && abdocu_dt.length != 8){
                abdocu_dt = module.dateToString(dataItem[keyColumn1]);
              }
              deletedC.Deleted.push({"ABDOCU_DT": abdocu_dt,
                                     "ABDOCU_SQ": dataItem[keyColumn2],
                                     "BGEXEC_TP": bgexec_tp});
            });
          }

          if(gridD){
            $.each(gridD, function(idx, dataItem){
              abdocu_dt = dataItem[keyColumn1];
              if(module.nvl(abdocu_dt, "") !== "" && abdocu_dt.length != 8){
                abdocu_dt = module.dateToString(dataItem[keyColumn1]);
              }
              deletedD.Deleted.push({"ABDOCU_DT": abdocu_dt,
                                     "ABDOCU_SQ": dataItem[keyColumn2],
                                     "BGACCT_SQ": dataItem[keyColumn3],
                                     "PARTNER_SQ": keyColumn4 == "1" ? keyColumn4 : dataItem[keyColumn4],
                                     "BGEXEC_TP": bgexec_tp});
            });
          }

          url = "common_fi_abdocu_info_delete";
        }

        dews.api.post(dews.url.getApiUrl("BM", "CommonAbmngService", url), {
          data :{
            gridDataSourceH : JSON.stringify (deletedH),
            gridDataSourceC : JSON.stringify (deletedC),
            gridDataSourceD : JSON.stringify (deletedD)
          }
        }).done(function(data){
        }).fail(function(e){
          dews.ui.snackbar.error('데이터 삭제 중 오류가 발생했습니다.', 'info');
        });
      },
      setRowChange : function(gridHeader, aprvlColumn, rowData, keyColumn1, keyColumn2, keyColumn3, keyColumn4, keyColumn5, keyColumn6, keyColumn7, keyColumn8, keyColumn9) {
        // 관리항목 사용여부 체크
        if(!mgmtUseYn){
          return;
        }

        // 현재 행에 데이터가 없을 때 비활성화
        if(!rowData){
          this.setMgmtEnabled(false);
          return;
        }

        // 최하위 레벨이거나 승인 데이터일 때 읽기전용
        if(gridHeader){
          if(dewself.menu.id == "NPBBPS00300") {
            if(rowData[aprvlColumn] == '1'){
              this.setMgmtReadonly(false);
            }
            else{
              this.setMgmtReadonly(true);
            }
          }
          else{
            if(gridHeader.getCellValue(gridHeader.select(), aprvlColumn) == '0' ||
               gridHeader.getCellValue(gridHeader.select(), aprvlColumn) == '1' ||
               (dewself.menu.id == "NPBBES00500" && gridHeader.getCellValue(gridHeader.select(), aprvlColumn) == '2')){
                  this.setMgmtReadonly(false);
            }
            else{
              this.setMgmtReadonly(true);
            }
          }

          if(dewself.menu.id == "NPBBPS00100" || dewself.menu.id == "NPBBPS00300" || dewself.menu.id == "NPBBPS00500"){
            if(gridHeader.getCellValue(gridHeader.select(), "LAST_YN") != 'Y'){
              this.setMgmtReadonly(true);
            }
          }
        }

        // 현재 행에 대한 PK 값 셋팅
        if(type_fg == 'A'){
          var pc_cd, bg_cd, accseq_sq, bg_sq, bgacct_cd, bgapply_ym, bgbasis_tp, print_adjt_sq, print_sq;

          if (rowData) {
              pc_cd = rowData[keyColumn1];
              bg_cd = rowData[keyColumn2];
              accseq_sq = rowData[keyColumn3];
              bg_sq = rowData[keyColumn4];
              bgacct_cd = rowData[keyColumn5];
              bgapply_ym = rowData[keyColumn6];
              bgbasis_tp = rowData[keyColumn7];
              print_adjt_sq = rowData[keyColumn8];
              print_sq = rowData[keyColumn9];
          }

          // PK 값이 하나라도 없으면 비활성화
          if(module.nvl(pc_cd, "") === "" ||  module.nvl(bg_cd, "") === "" || module.nvl(accseq_sq, "") === "" || module.nvl(bg_sq, "") === "" || module.nvl(bgacct_cd, "") === "" ||
             module.nvl(bgapply_ym, "") === "" || module.nvl(bgbasis_tp, "") === "" || module.nvl(print_adjt_sq, "") === "" || module.nvl(print_sq, "") === ""){
              this.setMgmtEnabled(false);
              return;
          }
        }
        else if(type_fg == 'B'){
          var abdocu_dt, abdocu_sq, bgacct_sq, partner_sq;

          if (rowData) {
              abdocu_dt = rowData[keyColumn1];
              abdocu_sq = rowData[keyColumn2];
              bgacct_sq = rowData[keyColumn3];
              partner_sq = keyColumn4 == "1" ? keyColumn4 : rowData[keyColumn4];
          }

          // PK 값이 하나라도 없으면 비활성화
          if(module.nvl(abdocu_dt, "") === "" || module.nvl(abdocu_sq, "") === "" || module.nvl(bgacct_sq, "") === "" || module.nvl(partner_sq, "") === ""){
            this.setMgmtEnabled(false);
            return;
          }
        }

        // 키 값 가져오기
        mgmtGridDataSource = dictionaryData['datasourceKey' + '_' + dewself.menu.id];

        // 데이터 조회
        if(type_fg == 'A'){
          this.selectList(pc_cd, bg_cd, accseq_sq, bg_sq, bgacct_cd, bgapply_ym, bgbasis_tp, print_adjt_sq, print_sq);
        }
        else if(type_fg == 'B'){
          this.selectList(abdocu_dt, abdocu_sq, bgacct_sq, partner_sq);
        }
      },
      setMgmtEnabled : function(isEabled) {
        // 컨트롤 활성화 여부
        var $trs = dewself.$content.find('#controlItem tbody tr');
            $trs.each(function(idx){
              var $control = dewself.$content.find('#' + 'control_' + (idx + 1));
              if($control.length > 0){
                  var dewsControl = $control.getDewsControl();

                  if(isEabled){
                    dewsControl.enable(isEabled);
                    return;
                  }

                  if($control.hasClass('dews-ui-codepicker')){
                    dewsControl.setData({ MNGD_CD: '', MNGD_NM: '' }, false);
                  }
                  else if($control.hasClass('dews-ui-numerictextbox') || $control.hasClass('dews-ui-datepicker')){
                    dewsControl.value('');
                  }
                  else if($control.hasClass("dews-ui-textbox")){
                    dewsControl.text('');
                  }

                  dewsControl.enable(isEabled);
              }
            });

        if(isEabled){
          var firstDewsControl = dewself.$content.find('#' + 'control_1').getDewsControl();
          firstDewsControl.focus();
        }
      },
      setMgmtReadonly : function(isEabled) {
        // 컨트롤 읽기전용 여부
        var $trs = dewself.$content.find('#controlItem tbody tr');
            $trs.each(function(idx){
              var $control = dewself.$content.find('#' + 'control_' + (idx + 1));
              if($control.length > 0){
                  var dewsControl = $control.getDewsControl();
                  dewsControl.readonly(isEabled);
              }
            });
      },
      setMgmtKeyDown : function(e, keyColumn, isSave){
        // 관리항목 사용여부 체크
        if(!mgmtUseYn){
          return false;
        }

        e.grid.commitCell();

        // 필수 값 체크
        if(!e.grid.validate().result){
            return false;
        }

        // 순번 체크후에 저장
        if(!e.grid.getCellValue(e.grid.select(), keyColumn) || isSave){
            dews.ui.mainbuttons.save.click();
            return true;
        }

        e.preventDefault();
        // 포커스 이동
        this.setMgmtEnabled(true);
      },
      setMgmtDataBound : function(e){
        // 관리항목 사용여부 체크
        if(!mgmtUseYn){
          return;
        }

        if(e.grid.dataItems().length > 0) {
          e.grid.setFocus();
          e.grid.select(e.grid.dataItems().length - 1);

           // 포커스 이동
           this.setMgmtEnabled(true);
        }
      },
      closeMenu : function() {
        // 관리항목 사용여부 체크
        if(!mgmtUseYn){
          return;
        }

        // 메뉴 닫힐 때 키 값 제거
        delete dictionaryData['datasourceKey' + '_' + dewself.menu.id];
      },
      addMngdPanel : function(mngdId) {
        var $ul = dewself.$content.find("#" + mngdId);
        // 관리항목 마스터 데이터 조회
        dews.api.get(dews.url.getApiUrl('BM', 'CommonAbmngService', 'common_fi_abmng_mst_list'), {
          data: {
            type_fg: type_fg
          }
        }).done(function (data) {
          $.each(data, function(idx, dataitem){
              var $li = $("<li></li>");
              $ul.append($li);
              $li.append("<label>" + module.nvl(dataitem.MCLS_NM) + "</label>");
              $li.append("<span></span>");
              var $span = $($li.find("span").get(0));
              var $control;

              // MNGITEMCD_YN = Y.도움창, N.문자열/숫자
              // MNGITEMTP_CD = 0.일반, 1.날짜, 2.금액, 3.수량, 4.율(%), 5.기간(년월일), 6.환율(%), 7.내역없음, 8.목록, 9.번호
              // MA00001 = 수량 소수점 자리수
              // MA00002 = 단가 소수점 자리수
              // MA00003 = 금액 소수점 자리수
              // MA00004 = 외화단가 소수점 자리수
              // MA00005 = 외화금액 소수점 자리수
              // MA00006 = 환율 소수점 자리수
              // MA00007 = 연월일 포맷
              // MA00008 = 연월 포맷
              // MA00009 = 비율 소수점 자리수
              // MA00010 = 세율 소수점 자리수
             var formatType = dataitem.MNGITEMTP_CD === "1" ? 'MA00007' :
                              dataitem.MNGITEMTP_CD === "2" ? 'MA00003' :
                              dataitem.MNGITEMTP_CD === "3" ? 'MA00001' :
                              dataitem.MNGITEMTP_CD === "4" ? 'MA00006' :
                              dataitem.MNGITEMTP_CD === "6" ? 'MA00006' : {};

              $control = dataitem.MNGITEMCD_YN === "Y" ? $("<select id= 'control_" + (idx + 1) + "'" + "class='dews-ui-multicodepicker' type='text' data-dews-code-field='MNGD_CD' data-dews-text-field='MNGD_NM' data-dews-help-code='H_BM_ABMNG_DTL_S' data-dews-help-size='medium' data-dews-help-params='type_fg=" + type_fg + "&mcls_cd=" + dataitem.MCLS_CD + "'" + " >") :
                         ( dataitem.MNGITEMTP_CD === "2" || dataitem.MNGITEMTP_CD === "3" ||
                           dataitem.MNGITEMTP_CD === "4" || dataitem.MNGITEMTP_CD === "6") ? $("<input id= 'control_" + (idx + 1) + "'" + "class='dews-ui-numerictextbox' type='text' data-dews-format=" + "'" + formatType + "'" +  "data-dews-format-predefined='true' >") :
                         dataitem.MNGITEMTP_CD === "1" ? $("<input id= 'control_" + (idx + 1) + "'" + "class='dews-ui-datepicker' type='text' >") :
                                                        $("<input id= 'control_" + (idx + 1) + "'" + "class='dews-ui-textbox' type='text' >");
              $span.append($control);
              $li.append($span);
              if($control){
                var dewsControl = $control.getDewsControl();
                if(dataitem.MNDR_YN == "Y"){
                  dewsControl.required(true);
                }
              }
          });
        }).fail(function (xhr, status, error) {
          dews.error(error);
        });
      },
      getMngdString : function(controlId) {
        var $control = dewself.$content.find("#" + controlId);
        if ($control.hasClass("dews-ui-codepicker")) {
          return $control.data().dewsControl.code();
        }
        else if ($control.hasClass("dews-ui-multicodepicker")) {
          return $control.data().dewsControl.codes().join("|");
        }
        else if ($control.hasClass("dews-ui-numerictextbox")) {
          return $control.data().dewsControl.value();
        }
        else if($control.hasClass("dews-ui-datepicker")){
          return $control.data().dewsControl.value();
        }
        else if($control.hasClass("dews-ui-textbox")){
          return $control.data().dewsControl.text();
        }
      }
    }
  };

  ///// endregion 공통 관리항목 처리 /////

  console.log('## npb Module Script Loaded!!! ##');

  //////// 작성 영역 - 끝 ////////

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=bm.npb.js
