// /view/js/bm.cm.js
/*
 * {bm} 예산 모듈 공통 함수
 */
(function(dews, gerp, $) {
  var module = new Object();

  /* API START */ 
  var moduleCode = 'BM'; // 모듈 코드를 입력 해주세요

  //Array Polyfill
  if (!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
      value: function (predicate) {
        'use strict';
        if (this == null) {
          throw new TypeError('Array.prototype.findIndex called on null or undefined');
        }
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }
        var list = Object(this);
        var length = list.length >>> 0;
        var thisArg = arguments[1];
        var value;

        for (var i = 0; i < length; i++) {
          value = list[i];
          if (predicate.call(thisArg, value, i, list)) {
            return i;
          }
        }
        return -1;
      },
      enumerable: false,
      configurable: false,
      writable: false
    });
  }

  module.common = {

  }
  
  /** @method 코드정보 GET
    * @description 모듈코드과, 코드필드에 해당되는 코드정보를 불러온다
    * @param {string} cd_module 모듈코드
    * @param {string} field_cd_pipe 파이프 형태의 코드필드
    * @param {string} gap 공백입력 처리(true:false)
    * @param {array} syscode_yn 디폴트 코드구분(Y,N)
    * @param {array} base_yn 디폴트 코드구분(Y,N)
    * @param {array} foreign_yn 종료일
    * @param {array} keyword 검색할 코드 또는 명
   */
  module.getCodeDtl = function(module_cd, field_cd_pipe, gap, syscode_yn, base_yn, foreign_yn, keyword) { 
    var codeDtl = new Object();
    var codeFields = field_cd_pipe != null ? field_cd_pipe.split("|") : [];

    dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format('common_codeDtl_list')), {
      async: false,
      data: {
        module_cd: module_cd, 
        field_cd_pipe: field_cd_pipe,
        syscode_yn: typeof(syscode_yn) != "undefined" ? syscode_yn : "",
        base_yn: typeof(base_yn) != "undefined" ? base_yn : "", 
        foreign_yn: typeof(foreign_yn) != "undefined" ? foreign_yn : "",
        end_dt: '', 
        keyword: typeof(keyword) != "undefined" ? keyword : ""
      }
    }).done(function (data) {
      if (data.length > 0) {
        $.each(codeFields, function(idx, codeField){
          var codeDtls = new Array();
          if(typeof(gap) != "undefined" && gap) {
            codeDtls.insert(0, { FIELD_CD: codeField, SYSDEF_CD: '', SYSDEF_NM: '' }); 
          }
          codeDtl[codeField] = codeDtls;
          $.each(data, function (idx, item) {
            if (item.FIELD_CD === codeField) { 
              codeDtl[codeField].push(item);
            }
          });
        });
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

    return codeDtl;
  };

  /** @method 계정유형 GET
    * @description 계정유형 데이터 정보 불러오기
    * @param {string} gap 공백입력 처리(true:false)
   */
  module.getGaapCodes = function(gap) {
    var codeGaaps = new Array();

    dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', dews.string.format('common_multiGaap_list_company')), {
        async : false,
    }).done(function (data) {
      if (data.length > 0) {
        if(typeof(gap) != "undefined" && gap) {
          codeGaaps.insert(0, { SYSDEF_CD : '', SYSDEF_NM : ''}); 
        }
        $.each(data, function(idx ,item) {
          codeGaaps.push({
            SYSDEF_CD : item.SYSDEF_CD, 
            SYSDEF_NM : item.SYSDEF_NM, 
          });
        });
      }
    }).fail(function (xhr, status, error){
      dews.ui.snackbar.error(error);
    });

    return codeGaaps;
  }

  /** @method 회계단위 정보 GET
    * @description 회계단위 데이터 정보 불러오기
    * @param {string} yn_use 사용여부 처리("Y" : "N")
    * @param {string} gap 공백입력 처리(true:false)
   */
  module.getProfitCenterCodes = function(use_yn, gap) { 
    var profitCenterCodes = new Array();

    dews.api.get(dews.url.getApiUrl("BM","ProfitOrganizationBudgetBBSService","pobbbs_get_profitcentCodes"),{
      async: false, 
      data : {
        use_yn : use_yn             //사용여부 
      }
    }).done(function(data){
      if(data.length > 0) {
        if(typeof(gap) != "undefined" && gap) {
          profitCenterCodes.insert(0, { PC_CD : '', PC_NM : ''});  
        } 
        $.each(data, function(idx, item) {
          profitCenterCodes.push({
            PC_CD : item.PC_CD, 
            PC_NM : item.PC_NM, 
          });
        });
      }
    }).fail(function(xhr, status, error){
      dews.ui.snackbar.error(error);
    });

    return profitCenterCodes;
  }

  /** @method 회사환경설정 정보 GET
    * @description 회사환경설정 데이터 정보 불러오기
    * @param {string} cd_module 모듈코드
    * @param {string} ctrl_cd_pipe 통제코드(파이프 형식)
    * @param {string} use_yn 사용여부 처리("Y" : "N")
   */
  module.getControlConfig = function(module_cd, ctrl_cd_pipe, use_yn) { 
    var controlConfig = new Object();
    var codeCtrls = ctrl_cd_pipe != null ? ctrl_cd_pipe.split("|") : [];

    //화면설정 값 데이터소스
    dews.api.get(dews.url.getApiUrl("BM","ProfitOrganizationBudgetBBSService","pobbbs_get_controlConfig"), {
      async : false,
      data : {
        module_cd : module_cd, 
        ctrl_cd_pipe : ctrl_cd_pipe,
        use_yn : use_yn 
      }
    }).done(function(data){
      if(data.length > 0) {
        $.each(codeCtrls, function(idx, codeCtrl) {
          $.each(data, function(idx, item) {
            if(item.CTRL_CD === codeCtrl) { 
              controlConfig[codeCtrl] = item;
            }
          });
        });
      }
    }).fail(function(xhr,status,error){
      dews.ui.snackbar.error(error);
    });

    return controlConfig;
  }

  /**
    * @method  메인버튼 VISIBLE 처리 Method
    * @description   메인버튼 VISIBLE 처리
    * @param {string} target
        target :  add      - 추가
                  search   - 조회
                  save     - 저장
                  approval - 결재
                  delete   - 삭제
                  print    - 인쇄
                  favorite - 즐겨찾기
                  all      - 전체
            ex : "add|print" , "all"
    * @param {boolean} visible true or false
    * @param {boolean} hide true or false
    */
   module.setMainButtons = function(target, visible, hide) {
    if(!hide) {
      hide = false;
    }

    if(target != "all") {
      $(target.split("|")).each(function(idx,item) {
        if(visible  == true) {
          dews.ui.mainbuttons[item].show();
          dews.ui.mainbuttons[item].disable(false);
        } else {
          if(hide) {
            dews.ui.mainbuttons[item].hide();
          } else {
            dews.ui.mainbuttons[item].disable(true);
          }
        }
      });
    } else {    //전체를 보여주거나 disabled
      $.map(dews.ui.mainbuttons,function(idx,item) {
        if(typeof(dews.ui.mainbuttons[item].disable) != "undefined") {
          if(visible == true) {
            dews.ui.mainbuttons[item].show();
            dews.ui.mainbuttons[item].disable(false);
          } else {
            if(hide) {
              dews.ui.mainbuttons[item].hide();
            } else {
              dews.ui.mainbuttons[item].disable(true);
            }
          }
        } 
      });
    }
  }

  /** @method 회사정보조회 get
    * @description 회사정보를 조회하고 데이터를 반환한다.
   */
  module.getCompanyInfo = function() {
    var companyInfo = new Object();

    dews.api.get(dews.url.getApiUrl('BM', 'ProfitOrganizationBudgetBBSService', 'pobbbs_get_companyInfo'), {
      async : false
    }).done(function(data) {
      companyInfo = data[0];
    }).fail(function (xhr, status, error){
      dews.error(error);
    });
    return companyInfo;
  }

  /** @method 파이프형태의 문자열에 포함되는 문자여부 검사
    * @description 파이프형태의 스트링 값에 포함되는 문자를 검사한다. ex. "21|22|23" 안에 "21"이 있는지 검사
    * @param {string} compareText 비교할 문자
    * @param {number} pipeString 비교대상 문자(파이프형태)
   */
  module.isContain = function(compareText, pipeString) {
    try {
      if(compareText == null || pipeString == null) {
        throw "parameters is null";
      } else {
        var containString = pipeString.split("|");
        if($.inArray(compareText, containString) != -1) {
          return true;
        } else {
          return false;
        }
      }   
    } catch (error) {
      console.error(error);
    }
  }

  /* API END */ 

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=bm.cm.js
