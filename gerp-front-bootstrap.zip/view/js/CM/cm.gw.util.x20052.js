(function (dews, gerp, $) {
  var module = {};
  var moduleCode = "CM";
  var version = "1.0.230619.01";

  console.debug("cm.gw.util.x20052.js", dews.string.format("[ LOAD START :: version={0} ]", version));

  var bsApi;
  dews.ajax.script("/view/js/CM/cm.bscm.js", {
    once: true,
    async: false
  }).done(function () {
    bsApi = gerp.CM;
  }).fail(function (xhr, status, error) {
    console.error("cm.bscm.js", "Common API Service not found error");
  });

  module.EltrAthzUtil_X20052 = {
    Status: {
      /**
       * 저장 "1"
       */
      SAVE: "1",
      /**
       * 상신 "2"
       */
      APPROVAL: "2",
      /**
       * 진행 "3"
       */
      PROGRESSING: "3",
      /**
       * 종결 "4"
       */
      CLOSE: "4",
      /**
       * 반려 "5"
       */
      RETURN: "5",
      /**
       * 취소 "6"
       */
      CANCEL: "6",
      /**
       * 보류 "7"
       */
      HOLD: "7",
      /**
       * 회수 "8"
       */
      RECALL: "8"
    },

    /**
     * 결재상태코드에 따른 배경색상을 반환한다.
     * @param {String} gwaprvlst_cd 
     * @returns 
     */
    StatusBgColor: function (gwaprvlst_cd) {
      var bgColor = null;
      switch (gwaprvlst_cd) {
        case "1": bgColor = "#3fa684"; break; // 저장
        case "2": bgColor = "#1c90fb"; break; // 상신
        case "3": bgColor = "#1c90fb"; break; // 진행
        case "4": bgColor = "#3fa684"; break; // 종결
        case "5": bgColor = "#faa733"; break; // 반려
        case "6": bgColor = "#e85e30"; break; // 취소
        case "7": bgColor = "#808080"; break; // 보류
        case "8": bgColor = "#e85e30"; break; // 회수
      }
      return bgColor;
    },

    /**
     * 결재상태코드에 따른 배경색상을 반환한다.
     * @param {String} gwaprvlst_cd 
     * @returns 
     */
    StatusIconImage: function (gwaprvlst_cd) {
      
      // <img src="/view/images/icon-approve-neutral.png"><span class="fcolor_gray">저장</span>
      // <img src="/view/images/icon-noprogress-pending.png"><span class="fcolor_orange">상신</span>
      // <img src="/view/images/icon-progress-progress.png"><span class="fcolor_blue">진행</span>
      // <img src="/view/images/icon-approve-positive.png"><span class="fcolor_green">종결</span>
      // <img src="/view/images/icon-return-negative.png"><span class="fcolor_red">반려</span>
      // <img src="/view/images/icon-cancel-negative.png"><span class="fcolor_brick">취소</span>
      // <img src="/view/images/icon-hold-pending.png"><span class="fcolor_brown">보류</span>
      
      var image = null;
      switch (gwaprvlst_cd) {
        case "1": image = "/view/images/icon-approve-neutral.png"; break; // 저장
        case "2": image = "/view/images/icon-noprogress-pending.png"; break; // 상신
        case "3": image = "/view/images/icon-progress-progress.png"; break; // 진행
        case "4": image = "/view/images/icon-approve-positive.png"; break; // 종결
        case "5": image = "/view/images/icon-return-negative.png"; break; // 반려
        case "6": image = "/view/images/icon-cancel-negative.png"; break; // 취소
        case "7": image = "/view/images/icon-hold-pending.png"; break; // 보류
        case "8": image = "/view/images/icon-cancel-negative.png"; break; // 회수
      }
      return image;
    },

    /**
     * 결재상태코드에 따른 배경색상을 반환한다.
     * @param {String} gwaprvlst_cd 
     * @returns 
     */
    StatusIconClass: function (gwaprvlst_cd) {
      // <span class="icon-sign approvebg_gray">저장</span>
      // <span class="icon-sign noprogress bg_orange">상신</span>
      // <span class="icon-sign progress bg_blue">진행</span>
      // <span class="icon-sign approve bg_green">종결</span>
      // <span class="icon-sign return bg_red">반려</span>
      // <span class="icon-sign cancel bg_brick">취소</span>
      // <span class="icon-sign hold bg_brown">보류</span>

      var classNames = null;
      switch (gwaprvlst_cd) {
        case "1": classNames = "icon-sign approvebg_gray"; break; // 저장
        case "2": classNames = "icon-sign noprogress bg_orange"; break; // 상신
        case "3": classNames = "icon-sign progress bg_blue"; break; // 진행
        case "4": classNames = "icon-sign approve bg_green"; break; // 종결
        case "5": classNames = "icon-sign return bg_red"; break; // 반려
        case "6": classNames = "icon-sign cancel bg_brick"; break; // 취소
        case "7": classNames = "icon-sign hold bg_brown"; break; // 보류
        case "8": classNames = "icon-sign cancel bg_brick"; break; // 회수
      }
      return classNames;
    },

    /**
     * 서버 유형 획득(application.properties -> application.server.type. + {gubun})
     * @returns dev=개발, stage=품질, prod=운영
     */
    getServerType: function (gubun) {
      if (!gubun) gubun = "x20052";
      var result = "dev";
      dews.api.post(dews.url.getApiUrl("CM", "GroupwareService_X20052", "getServerType"), {
        async: false,
        data: {
          gubun: gubun,
        }
      }).done(function (data) {
        result = data;
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.warning("서버유형을 가져오지 못했습니다.");
      });
      return result;
    },

    /**
     * 전자결재 상신 URL주소 획득
     * @param {*} gubun : DRS 코드
     * @returns 
     */
    getApprovalUrl: function (gubun) {
      if (!gubun) gubun = "x20052";
      var result = "https://gwdev.dongasocio.com/ekp/service/openapi/ds/IF_OTSUKA_ERP_GW_001";
      dews.api.post(dews.url.getApiUrl("CM", "GroupwareService_X20052", "getApprovalUrl"), {
        async: false,
        data: {
          gubun: gubun,
        }
      }).done(function (data) {
        result = data;
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.warning("전자결재 URL을 가져오지 못했습니다.");
      });
      return result;
    },

    /**
     * 
     * @param {*} param 
     */
    Approval: function (param) {
      // 1. 파라메터 확인
      var param2 = {
        width: param.width,
        height: param.height,
        company_cd: param.company_cd,
        module_cd: param.module_cd,
        req_user_id: param.req_user_id,
        req_emp_no: param.req_emp_no,
        form_id: param.form_id,
        title_cd: param.title_cd,
        title: param.title,
        contents_txt: param.contents_txt,
        table_nm: param.table_nm,
        matkey_vr: param.matkey_vr,
        service_url: param.service_url,
        server_type: param.server_type,
        gwaprvlst_cd: param.gwaprvlst_cd,
        rmenu_cd: param.rmenu_cd,
        class_cd: param.class_cd,
        user_id: param.user_id,
        gwapproval_dt: param.gwapproval_dt,

        // 그룹웨어에서 선언되었지만 인터페이스에 사용되지 않는 것
        budgetEmpIds: param.budgetEmpIds,
        divSteps: param.divSteps,
        slipType: param.slipType,
        postingDate: param.postingDate,
        expirationDate: param.expirationDate,
      }

      if (!param2.req_user_id) {
        param2.req_user_id = dews.ui.page.user.userid;
      }

      if (!param2.req_emp_no) {
        param2.req_emp_no = dews.ui.page.user.empCode;
      }

      if (!param2.server_type) {
        param2.server_type = this.getServerType("x20052");
      }

      if (!param2.gwaprvlst_cd) {
        param2.gwaprvlst_cd = this.Status.SAVE;
      }

      if (!param2.rmenu_cd) {
        param2.rmenu_cd = dews.ui.page.menu.id;
      }

      if (!param2.user_id) {
        param2.user_id = dews.ui.page.user.userid;
      }

      if (!param2.gwapproval_dt) {
        param2.gwapproval_dt = dews.date.format(new Date(), "yyyyMMdd");
      }

      if (!param2.budgetEmpIds) {
        param2.budgetEmpIds = "";
      }

      if (!param2.divSteps) {
        param2.divSteps = "";
      }

      if (!param2.slipType) {
        param2.slipType = "";
      }

      if (!param2.postingDate) {
        param2.postingDate = dews.date.format(new Date(), "yyyyMMdd");
      }

      if (!param2.expirationDate) {
        param2.expirationDate = "29991231";
      }

      // 2-1. 콜백 이벤트
      /** [필수]
       * 2-1-1. APPROVAL_BEFORE : 상신 창이 뜨기 전에 실행한다.(필수)
       */
      var CALLBACK_APPROVAL_BEFORE = param.APPROVAL_BEFORE;
      delete param.APPROVAL_BEFORE;
      if (!CALLBACK_APPROVAL_BEFORE || $.isFunction(CALLBACK_APPROVAL_BEFORE) == false) {
        throw "전자결재 콜백 이벤트가 정의되지 않았습니다.(APPROVAL_BEFORE)";
      }

      /** [선택]
       * 2-1-2. APPROVAL_DONE : 상신 팝업창이 닫힐 때, 상신(2), 진행(3) 상태로 바뀐 경우에만 실행한다.
       */
      var CALLBACK_APPROVAL_DONE = param.APPROVAL_DONE;
      delete param.APPROVAL_DONE;
      // if (!CALLBACK_APPROVAL_DONE || $.isFunction(CALLBACK_APPROVAL_DONE) == false) {
      //   throw "전자결재 이벤트가 정의되지 않았습니다.(APPROVAL_DONE)";
      // }

      /** [선택]
       * 2-1-3. APPROVAL_FAIL : 상신 팝업창이 닫힐 때, 상신(2), 진행(3) 상태가 아닌 바뀐 경우에만 실행한다.
       */
      var CALLBACK_APPROVAL_FAIL = param.APPROVAL_FAIL;
      delete param.APPROVAL_FAIL;
      // if (!CALLBACK_APPROVAL_FAIL || $.isFunction(CALLBACK_APPROVAL_FAIL) == false) {
      //   throw "전자결재 이벤트가 정의되지 않았습니다.(APPROVAL_FAIL)";
      // }

      /** [선택]
       * 2-1-4. APPROVAL_CLOSE : 상신 팝업창이 닫힐 때 APPROVAL_DONE, APPROVAL_FAIL 이벤트 이후 실행한다.
       */
      var CALLBACK_APPROVAL_CLOSE = param.APPROVAL_CLOSE;
      delete param.APPROVAL_CLOSE;
      // if (!CALLBACK_APPROVAL_CLOSE || $.isFunction(CALLBACK_APPROVAL_CLOSE) == false) {
      //   throw "전자결재 이벤트가 정의되지 않았습니다.(APPROVAL_CLOSE)";
      // }

      try {
        var EltrAthzUtil_X20052 = gerp.CM.EltrAthzUtil_X20052;
        var bsApi = gerp.CM;
        var v_ATHZ_RPTS_CD = "";

        new Promise(function (resolve, reject) {  // 3. 상신 데이터 생성 및 저장
          dews.ui.loading.hide();
          dews.ui.loading.show({ type: "full", text: "기안 데이터를 생성 중입니다." }); // ERP10 전자결재 상신 공통 서비스 호출
          dews.api.post(dews.url.getApiUrl("CM", "GroupwareService_X20052", "approval"), {
            data: param2
          }).done(function (data) {
            if (data && data.ATHZ_RPTS_CD) {
              v_ATHZ_RPTS_CD = data.ATHZ_RPTS_CD;
              resolve(data);
            } else {
              console.error(data);
              reject("전자결재 데이터 생성 중 오류가 발생하였습니다.");
            }
          }).fail(function (error) {
            console.error("상신 데이터 저장 실패!");
            reject(error.responseJSON.message);   // 3. 상신 데이터 저장 - 실패
          });
        }).then(function (data) {                 // 4. 상신 데이터 저장 - 성공
          console.debug("GroupwareService_X20052.approval(data)", data);

          // 5. APPROVAL_BEFORE 이벤트 호출
          // -> 업무 테이블에 저장할 수 있도록.
          return CALLBACK_APPROVAL_BEFORE(data); // data = MA_GWINT_MST에 저장된 정보.

        }).then(function (args) { // args = APPROVAL_BEFORE 이벤트에서 반환된 정보.

          // 저장된 정보를 D-Portal로 전달한다.
          return new Promise(function (resolve, reject) {

            dews.ui.loading.hide();
            dews.ui.loading.show({ type: "full", text: "D-Portal 서비스 호출..." });

            var data = EltrAthzUtil_X20052.getAthzDoc(v_ATHZ_RPTS_CD);
            var server_type = EltrAthzUtil_X20052.getServerType("x20052");    // 서버 유형
            server_type = dews.string.format("{0}_{1}", server_type, "11");   // 요청시스템구분(11:ERP10 Web, 13:ERP10 Mobile)

            // var company_cd = bsApi.getString(data.COMPANY_CD);
            var req_user_id = bsApi.getString(data.REQ_USER_ID);
            var req_emp_no = bsApi.getString(data.REQ_EMP_NO);
            var form_id = bsApi.getString(data.FORM_ID);
            var title = bsApi.getString(data.DOC_TITL_NM);
            var athz_doc_cd = bsApi.getString(data.ATHZ_RPTS_CD);   // 채번된 전자결재문서번호
            // var athz_st_cd = bsApi.getString(data.GWAPRVLST_CD);
            var contents_txt = bsApi.getString(data.CONTENTS_TXT);
            var title_cd = bsApi.getString(data.GW_FORM_ID);
            var matkey_vr = bsApi.getString(data.MATKEY_VR);
            var pks = matkey_vr.split("|");

            // 저장된 정보를 D-Portal로 전달한다.
            var url = EltrAthzUtil_X20052.getApprovalUrl("x20052");
            EltrAthzUtil_X20052.createEltrAthz(url, {
              // empNo: req_emp_no,              // 사원번호
              empNo: req_user_id,             // 사용자ID
              formId: form_id,                // 양식고유번호
              orgApprDocNo: athz_doc_cd,      // 요청시스템문서번호
              apprTitle: title,               // 제목
              formEditorData: contents_txt,   // 본문데이터
              docTitleCode: title_cd,         // 양식 문서 제목 구분
              reqSystemType: server_type,     // 요청시스템구분
              closed: function () {           // D-Portal 전자결재 창을 닫은 후 액션을 정의한다.(상신이 완료된 경우, 그냥 닫은 경우 모두 호출 됨)
                // 상태가 변경된 최종 전자결재 데이터 조회
                var mst_data = EltrAthzUtil_X20052.getAthzDoc(v_ATHZ_RPTS_CD);
                console.debug("mst_data=", mst_data);

                var approval_done = false;
                switch (mst_data.GWAPRVLST_CD) {
                  default:
                  case EltrAthzUtil_X20052.Status.SAVE: // 저장
                    break;
                  case EltrAthzUtil_X20052.Status.APPROVAL: // 상신
                  case EltrAthzUtil_X20052.Status.PROGRESSING: // 진행
                    approval_done = true;
                    break;
                  case EltrAthzUtil_X20052.Status.CLOSE: // 종결
                    break;
                  case EltrAthzUtil_X20052.Status.RETURN: // 반려
                    break;
                  case EltrAthzUtil_X20052.Status.CANCEL: // 취소(상신취소)
                  case EltrAthzUtil_X20052.Status.RECALL: // 회수
                    break;
                  case EltrAthzUtil_X20052.Status.HOLD: // 보류
                    break;
                }
                console.debug("mst_data.GWAPRVLST_CD=", mst_data.GWAPRVLST_CD);

                var debug_msg = "";
                if (approval_done) {
                  debug_msg = "전자결재 종료(성공)";
                  if (CALLBACK_APPROVAL_DONE && $.isFunction(CALLBACK_APPROVAL_DONE)) {
                    console.debug("CALLBACK_APPROVAL_DONE - START", debug_msg);
                    CALLBACK_APPROVAL_DONE(mst_data, args)
                    console.debug("CALLBACK_APPROVAL_DONE - END", debug_msg);
                  }
                } else {
                  debug_msg = "전자결재 종료(실패)";
                  if (CALLBACK_APPROVAL_FAIL && $.isFunction(CALLBACK_APPROVAL_FAIL)) {
                    console.debug("CALLBACK_APPROVAL_FAIL - START", debug_msg);
                    CALLBACK_APPROVAL_FAIL(mst_data, args)
                    console.debug("CALLBACK_APPROVAL_FAIL - END", debug_msg);
                  }
                }

                if (CALLBACK_APPROVAL_CLOSE && $.isFunction(CALLBACK_APPROVAL_CLOSE)) {
                  console.debug("CALLBACK_APPROVAL_CLOSE - START", debug_msg);
                  CALLBACK_APPROVAL_CLOSE(mst_data, args)
                  console.debug("CALLBACK_APPROVAL_CLOSE - END", debug_msg);
                }

                debug_msg = "전자결재 종료";
                console.debug(debug_msg);

              },
            });

          });

          // }).then(function (data) {
          //   return new Promise(function (resolve, reject) {
          //   });

        }).catch(function (error) {
          dews.ui.loading.hide();
          var msg = error;
          if (error && error.responseJSON) {
            msg = error.responseJSON.message;
          }
          // dews.ui.snackbar.error(msg);
          dews.error(msg);
        });

      } catch (error) {
        dews.ui.loading.hide();
      }

    },

    // contentsType : 본문Html 종류 (inner : 에디터에 넣는다 , outer : _DFINTER_ 가 먹는다)
    // 1.에디터 없는 경우 => 기안자가 결재본문를 수정 할 수 없는 경우(contentsType : "outer")
    //   기안 양식 => HTML 에 <TR><td>_DFINTER_</TD></TR> 로 되어 있어야 함
    // 2.에디터 있는 경우 => 기안자가 결재본문를 수정 해야 할 경우 (contentsType : "inner")
    //   기안 양식 => HTML 에 <TR><td style="font-family:굴림;font-size:9pt;color:rgb(0, 0, 0);line-height:1.2;" id="divFormContents">_DF11_</td></TR> 로 되어 있어야 함
    createEltrAthz: function (url, param) {
      var callback_closed;
      var left = 1, top = 1;
      // var width = 981;
      // var height = 769;
      var width = (screen.width / 2);
      var height = screen.height;
      var widthYn = "", dummyItem = "";

      if (!url) {
        url = getApprovalUrl("x20052");
      }
      if (param.hasOwnProperty("widthYn")) {
        widthYn = param.widthYn;
      }
      if (param.hasOwnProperty("width")) {
        width = param.width;
      }
      if (param.hasOwnProperty("height")) {
        height = param.height;
      }
      if (param.hasOwnProperty("closed")) {
        callback_closed = param.closed;
      }
      if (param.hasOwnProperty("dummyItem")) {
        dummyItem = param.dummyItem;
      }
      if (param.hasOwnProperty("params")) {
        param = param.params;
      }

      var $eltrAthzForm = $("<meta charset=\"utf-8\"><form id=\"eltrAthzForm\" name=\"eltrAthzForm\" enctype=\"application/json; charset=utf-8\" method=\"POST\">").appendTo("body");

      // if (param.aesKey === null || param.aesKey === undefined) {
      //   $eltrAthzForm.append($("<input>", { type: "hidden", id: "aesKey", name: "aesKey" }).val("1023497555960596")); // 1023exe497555960596: bizBoxA default key
      // } else {
      //   $eltrAthzForm.append($("<input>", { type: "hidden", id: "aesKey", name: "aesKey" }).val(param.aesKey));
      // }

      $eltrAthzForm.append($("<input>", { type: "hidden", id: "reqSystemType", name: "reqSystemType" }).val(param.reqSystemType));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "empNo", name: "empNo" }).val(param.empNo));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "orgApprDocNo", name: "orgApprDocNo" }).val(param.orgApprDocNo)); // ERP10 결재문서번호
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "apprTitle", name: "apprTitle" }).val(param.apprTitle));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "formEditorData", name: "formEditorData" }).val(param.formEditorData));
      // 그룹웨어에서 인코딩 한 것을 받을 경우.
      // $eltrAthzForm.append($("<input>", { type: "hidden", id: "apprTitle", name: "apprTitle" }).val(encodeURIComponent(param.apprTitle)));
      // $eltrAthzForm.append($("<input>", { type: "hidden", id: "formEditorData", name: "formEditorData" }).val(encodeURIComponent(param.formEditorData)));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "formId", name: "formId" }).val(param.formId));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "docTitleCode", name: "docTitleCode" }).val(param.docTitleCode));

      // 그룹웨어에서 선언되었지만 인터페이스에 사용되지 않는 것
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "budgetType", name: "budgetType" }).val(param.budgetType));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "budgetEmpIds", name: "budgetEmpIds" }).val(param.budgetEmpIds));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "divSteps", name: "divSteps" }).val(param.divSteps));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "slipType", name: "slipType" }).val(param.slipType));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "postingDate", name: "postingDate" }).val(param.postingDate));
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "expirationDate", name: "expirationDate" }).val(param.expirationDate));

      // 더미
      $eltrAthzForm.append($("<input>", { type: "hidden", id: "dummyItem", name: "dummyItem" }).val(dummyItem));

      // // 토큰
      // $eltrAthzForm.append($("<input>", { type: "hidden", id: "X-Authenticate-Token", name: "X-Authenticate-Token" }).val(JSON.parse(dews.ui.page.token).access_token)); // 토큰정보 필수

      // const windowFeatures = dews.string.format("width={0},height={1},scrollbars=yes", width, height);
      const windowFeatures = dews.string.format("left={0},top={1},width={2},height={3},scrollbars=yes,status=yes,titlebar=no,menubar=no,location=no", left, top, width, height);
      const eltrAthzPopup = window.open("headers=Content-Disposition: attachment;", "eltrAthzPopup", windowFeatures);

      try {
        // 소유한 창의 beforeunload 이벤트에 핸들러 추가
        window.addEventListener('beforeunload', function (event) {
          if (eltrAthzPopup && !eltrAthzPopup.closed) {
            eltrAthzPopup.location.reload();
            eltrAthzPopup.close();
          }
        });
        eltrAthzPopup.focus();
        if (window.opener && !window.opener.closed) {
          window.opener.location.reload();
          window.close();
        }
        // $(window).on("onbeforeunload", function () {
        //   // self.close();
        //   eltrAthzPopup.close();
        // });
        
                    // eltrAthzPopup.onbeforeunload = function () {
                    //     searchData(true);
                    // };
    
      } catch (exception) {
        dews.alert("그룹웨어 팝업이 차단되어 있습니다.", "ico2");
      }

      $("#eltrAthzForm").attr("target", "eltrAthzPopup");
      $("#eltrAthzForm").attr("action", url);
      $("#eltrAthzForm").submit();
      $("#eltrAthzForm").remove();

      if (self.$(".dews-ui-loading").length > 0) {
        dews.ui.loading.hide();
      }

      setTimeout(function () {
        dews.ui.loading.show({
          type: "full",
          text: "전자결재 진행 중입니다."
        })
      });

      var popupTick = setInterval(function () {
        if (eltrAthzPopup.closed) {
          clearInterval(popupTick);
          dews.ui.loading.hide();
          if (callback_closed && $.isFunction(callback_closed)) {
            callback_closed();
          }
        }
      }, 500);
      return eltrAthzPopup;
    },

    eltrLoadingClosing: function () {
      var eltrLoadingTick = setInterval(function () {
        clearInterval(eltrLoadingTick);
        dews.ui.loading.hide();
      }, 500);
    },

    getGwFormId: function (formId) {
      var returnGwFormId;
      if (!formId) {
        alert("formId는 null일 수 없습니다.");
        return;
      }
      dews.api.post(dews.url.getApiUrl("CM", "GroupwareService_X20052", "getGwFormId"), {
        async: false,
        data: {
          formId: formId,
        }
      }).done(function (data) {
        returnGwFormId = data;
      }).fail(function (xhr, status, error) {
        // dews.ui.snackbar.warning(error, false);
        dews.error(error.responseJSON.message);
      });
      return returnGwFormId;
    },

    getGwProcessCode: function (formId) {
      var result;
      if (!formId) {
        dews.alert("formId는 null일 수 없습니다.");
        return;
      }
      dews.api.post(dews.url.getApiUrl("CM", "GroupwareService_X20052", "getGwProcCd"), {
        async: false,
        data: {
          formId: formId,
        }
      }).done(function (data) {
        result = data;
      }).fail(function (xhr, status, error) {
        // dews.ui.snackbar.warning(error, false);
        dews.error(error.responseJSON.message);
      });
      return result;
    },

    getAthzDoc: function (athz_rpts_cd) {
      var result;
      if (!athz_rpts_cd) {
        dews.alert("전자결재문서번호(athz_rpts_cd)는 null일 수 없습니다.");
        return;
      }
      dews.api.post(dews.url.getApiUrl("CM", "GroupwareService_X20052", "get_athz_doc"), {
        async: false,
        data: {
          athz_rpts_cd: athz_rpts_cd,
        }
      }).done(function (data) {
        result = data;
      }).fail(function (xhr, status, error) {
        // dews.ui.snackbar.warning(error, false);
        dews.error(error.responseJSON.message);
      });
      return result;
    },

    getAthzHistory: function (athz_rpts_cd, no_sq) {
      var result;
      if (!athz_rpts_cd) {
        dews.alert("전자결재문서번호(athz_rpts_cd)는 null일 수 없습니다.");
        return;
      }
      dews.api.post(dews.url.getApiUrl("CM", "GroupwareService_X20052", "get_ma_gwint_hst"), {
        async: false,
        data: {
          athz_rpts_cd: athz_rpts_cd,
          no_sq: no_sq,
        }
      }).done(function (data) {
        result = data;
        if (no_sq >= 0 && data && data.length > 0) {
          result = data[0];
        }
      }).fail(function (xhr, status, error) {
        // dews.ui.snackbar.warning(error, false);
        dews.error(error.responseJSON.message);
      });
      return result;
    },

    isUsableStatus: function (btn_type, athz_st_cd) {
      // const Status = {
      //   SAVE: "1",             //저장
      //   APPROVAL: "2",         //상신
      //   PROGRESSING: "3",      //진행
      //   CLOSE: "4",            //종결
      //   RETURN: "5",           //반려
      //   CANCEL: "6",           //취소
      //   HOLD: "7",             //보류
      //   RECALL: "8"            //회수
      // }

      const cancelCodes = [EltrAthzUtil_X20052.Status.APPROVAL, EltrAthzUtil_X20052.Status.PROGRESSING];
      const saveApprovalCodes = [EltrAthzUtil_X20052.Status.SAVE, EltrAthzUtil_X20052.Status.RETURN, EltrAthzUtil_X20052.Status.HOLD, EltrAthzUtil_X20052.Status.RECALL];
      const deleteCodes = [EltrAthzUtil_X20052.Status.SAVE, EltrAthzUtil_X20052.Status.RETURN, EltrAthzUtil_X20052.Status.CANCEL, EltrAthzUtil_X20052.Status.HOLD, EltrAthzUtil_X20052.Status.RECALL];

      btn_type = btn_type.toUpperCase();
      switch (btn_type) {
        case "SAVE":
        case "APPROVAL":
          return (!athz_st_cd || saveApprovalCodes.includes(athz_st_cd));
        case "CANCEL":
          return athz_st_cd && cancelCodes.includes(athz_st_cd);
        case "DELETE":
          return athz_st_cd && deleteCodes.includes(athz_st_cd);
        default:
          return false;
      }

    }
  }

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);

  console.debug("cm.gw.util.x20052.js", dews.string.format("[ LOAD COMPLETE :: version={0} ]", version));

})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=cm.gw.util.x20052.js
