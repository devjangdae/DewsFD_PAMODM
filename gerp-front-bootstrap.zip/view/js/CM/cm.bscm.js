(function (dews, gerp, $) {
    var module = {};
    var moduleCode = "CM";
    var version = "1.0.230619.02";

    console.debug("cm.bscm.js", dews.string.format("[ LOAD START :: version={0} ]", version));

    setIEObjectPrototypeAndMethod();

    // 공통 메시지 기본값
    module.MSG = {
        // 닫기
        CLOSE_CONFIRM: "저장하지 않은 데이터가 있습니다." + "\n" + "닫기를 계속 하시겠습니까?",         // 종료 확인 메세지
        // 조회
        SEARCH_AGAIN_CONFIRM: "저장하지 않은 데이터가 있습니다." + "\n" + "조회를 계속 하시겠습니까?",  // 재조회 확인 메세지
        // 삭제
        DELETE_CONFIRM: "삭제 하시겠습니까?" + "\n" + "(반드시 저장을 하셔야 반영이 됩니다.)",          // 삭제 확인 메세지(화면상에서 삭제)
        DELETE_IMME_CONFIRM: "삭제 하시겠습니까?",                                                      // 삭제 확인 메세지(DB 삭제)
        DELETE_DONE_ALERT: "삭제 하였습니다.",                                                          // 삭제 완료 메세지
        // 저장
        SAVE_NO_CHANGED_ALERT: "변경된 데이터가 없습니다.",                                             // 변경된 데이터가 없는 메세지
        SAVE_NO_DATA_ALERT: "저장할 데이터가 없습니다.",                                                // 저장할 데이터 없는 메세지
        SAVE_VALID_ALERT: "필수항목을 입력하지 않았습니다.",                                            // 저장 필수값 메세지
        SAVE_VALID_GRID_ALERT: "입력은 필수입니다.",                                                    // 필수값 누락 (그리드)
        SAVE_CONFIRM: "저장 하시겠습니까?",                                                             // 저장 확인 메세지
        SAVE_DONE_ALERT: "저장이 완료 되었습니다.",                                                     // 저장 완료 메세지
        NEED_SAVE_ALERT: "변경된 데이터가 있습니다." + "\n" + "저장 후 진행하세요.",                    // 저장하지 않은채 다른 작업 진행 시 표출.
        // 로딩
        PROCESSING_LOADING: "처리하는 중입니다.",                                                       // 공통 처리 로딩 메세지
        SEARCH_LOADING: "조회하는 중입니다.",                                                           // 조회 로딩 메세지
        SAVE_LOADING: "저장하는 중입니다.",                                                             // 저장 로딩 메세지
        DELETE_LOADING: "삭제하는 중입니다.",                                                           // 삭제 로딩 메세지(DB 삭제)
        EXCEL_IMPORTING: "엑셀 내용을 불러오는 중입니다.",                                              // 엑셀 데이터 로딩 메세지
        // 예외처리
        PROCESS_FAIL_ALERT: "작업이 실패하였습니다.",
        // 선택
        CHECK_NO_DATA_ALERT: "선택한 데이터가 없습니다.",                                               // 선택 데이터 없음
        // 확인
        CHANGED_CONFIRM: "변경된 데이터가 있습니다." + "\n" + "계속 하시겠습니까?",                     // 변경된 데이터가 있을때 다른 작업을 진행 할 시 확인 메시지.
        NO_DATA: "데이터가 없습니다.",                                                                  // 데이터 없는 메세지(noDataMessage)
    };

    // ma.cm.msg.js
    if (!gerp.MA.MSG) {
        dews.ajax.script("/view/js/MA/ma.cm.msg.js", {
            once: true,
            async: false,
        }).done(function () {
            // cmMsg = gerp.MA.MSG;
            // 공통 메시지(MA.MSG)와 병합(상단에 선언된 메시지 우선)
            module.MSG = $.extend(true, {}, gerp.MA.MSG, module.MSG); // 마지막 값이 최종 값
        }).fail(function (xhr, status, error) {
            console.error("ma.cm.msg.js", "Common JS not found error");
        });
    }

    // xlsx.js
    module.XLSX = null;
    loadExcelCommonJS();

    // hr.common.js
    dews.ajax.script("/view/js/HR/hr.common.js", {
        once: true,
        async: false,
    }).done(function () {
        //hrComm = gerp.HR;
    }).fail(function (xhr, status, error) {
        console.error("hr.common.js", "Common JS not found error", error);
    });

    // hr.dateUtil.js
    dews.ajax.script("/view/js/HR/hr.dateUtil.js", {
        once: true,
        async: false,
    }).done(function () {
        // hrDateUtil = gerp.HR;
    }).fail(function (xhr, status, error) {
        console.error("hr.dateUtil.js", "Common JS not found error", error);
    });

    var dataSourceRepository = {
        createMenu: function () {
            var self = module.getPage();
            var menuId = getPageId(self);
            if (dataSourceRepository.hasOwnProperty(menuId)) {
                return;
            }

            dataSourceRepository[menuId] = {};

            if (self === dews.ui.page) {
                self.closing.on(function () {
                    dataSourceRepository.deleteMenu(menuId);
                });
                return;
            }

            dews.ui.dialog(menuId).on("closed", function (e) {
                dataSourceRepository.deleteMenu(menuId);
            });
        },
        deleteMenu: function (menuId) {
            delete dataSourceRepository[menuId];
        },
        existsMenuDataSource: function (target) {
            return dataSourceRepository.hasOwnProperty(target.menuId)
                && dataSourceRepository[target.menuId].hasOwnProperty(target.controlId);
        },
        addMenuDataSource: function (target, dataSource) {
            if (dataSourceRepository.hasOwnProperty(target.menuId)) {
                dataSourceRepository[target.menuId][target.controlId] = dataSource;
            }
        },
        getMenuDataSource: function (target) {
            return dataSourceRepository[target.menuId][target.controlId];
        }
    };

    /**
     * dataSourceRepository => MenuId 생성
     */
    module.createMenuDataSourceRepository = function () {
        dataSourceRepository.createMenu();
    };

    /**
     * dataSourceRepository => MenuId 삭제
     * @param {string} menuId 삭제할 MenuId
     */
    module.deleteMenuDataSourceRepository = function (menuId) {
        dataSourceRepository.deleteMenu(menuId);
    };

    /**
     * SaveConditions => 조회조건을 DB에 저장.
     * @param {object} self 화면 객체
     */
    module.SaveConditions = function (self) {
        if (!self) {
            self = module.getPage();
        }
        let pageId = getPageId(self);
        var tmpArgs = $.extend({}, self);
        tmpArgs = $.extend(tmpArgs, { id: pageId });
        if (tmpArgs.id) {
            console.debug("SaveConditions", "조회조건을 저장합니다.", self);
            gerp.MA.setMenuDefaultValue(tmpArgs, false);
            self.SavedConditions = true;
        } else {
            console.debug("SaveConditions", "화면ID가 존재하지 않아 저장할 수 없습니다.", self);
        }
    };

    /**
     * LoadConditions => 저장된 조회조건 화면에 설정.
     * @param {object} self 화면 객체
     */
    module.LoadConditions = function (self) {
        if (!self) {
            self = module.getPage();
        }
        let pageId = getPageId(self);
        var tmpArgs = $.extend({}, self);
        tmpArgs = $.extend(tmpArgs, { id: pageId });
        if (tmpArgs.id) {
            console.debug("LoadConditions", "조회조건을 불러옵니다.", tmpArgs);
            gerp.MA.getMenuDefaultValue(tmpArgs, false);
            self.LoadedConditions = true;
        } else {
            console.debug("LoadConditions", "화면ID가 존재하지 않아 불러올 수 없습니다.", self);
        }
    };

    /**
     * 활성화된 Page Object 반환
     * @return {object} 활성화된 Page Object(dews.ui.page | dews.ui.dialogPage)
     */
    module.getPage = function () {
        if (dews.ui.dialogPage && !dews.ui.dialogPage.dialog._closing) {
            return dews.ui.dialogPage;
        }

        return dews.ui.page;
    };

    /**
     * 활성화된 Page 버전정보 팝업
     * @return {object} 활성화된 Page Object(dews.ui.page | dews.ui.dialogPage)
     */
    module.showVersionPopup = function (self) {
        if (!self) {
            self = module.getPage();
        }

        var id, name, pageModule;
        if (self === dews.ui.dialogPage) {
            id = self.id;
            name = self.options.title;
            pageModule = ""; //dews.ui.page.menu.module;
        } else {
            id = self.menu.id;
            name = self.menu.name;
            pageModule = self.menu.module;
        }

        // Back-end Service
        dews.api.get(dews.url.getApiUrl("CM", "ServiceVersion"), {
            async: false,
            data: {
                service: self.version.service
            }
        }).done(function (data) {
            self.version.serviceVersion = data;
        }).fail(function (xhr, status, error) {
        });

        // API Back-end Service
        var hasApiService = module.isNotNull(self.version.apiService);
        if (hasApiService) {
            dews.api.get(dews.url.getApiUrl("CM", "ServiceVersion"), {
                async: false,
                data: {
                    service: self.version.apiService
                }
            }).done(function (data) {
                self.version.apiVersion = data;
            }).fail(function (xhr, status, error) {
            });
        }

        var infohtml = "";
        infohtml += "<div class=\"menu-information-contents-area\">";
        infohtml += "  <h4 class=\"dews-ui-title\" id=\"basic-info\">기본 정보</h4>";
        infohtml += "  <table>";
        infohtml += "    <colgroup>";
        infohtml += "      <col style=\"width:33.333%\" span=\"3\">";
        infohtml += "    </colgroup>";
        infohtml += "    <thead>";
        infohtml += "      <tr>";
        infohtml += "        <th id=\"menu-id\">메뉴 ID</th>";
        infohtml += "        <th id=\"menu-name\">메뉴</th>";
        infohtml += "        <th id=\"module\">모듈</th>";
        infohtml += "      </tr>";
        infohtml += "    </thead>";
        infohtml += "    <tbody>";
        infohtml += "      <tr id=\"menu-info\">";
        infohtml += "        <td>" + id + "</td>";
        infohtml += "        <td>" + name + "</td>";
        infohtml += "        <td>" + pageModule + "</td>";
        infohtml += "      </tr>";
        infohtml += "    </tbody>";
        infohtml += "  </table>";
        if (hasApiService) {
            infohtml += "  <h4 class=\"dews-ui-title\" id=\"version-title\">Front-end / Back-end(Menu, Api) 정보</h4>";
        } else {
            infohtml += "  <h4 class=\"dews-ui-title\" id=\"version-title\">Front/Back-end 정보</h4>";
        }
        infohtml += "  <table>";
        infohtml += "    <colgroup>";
        if (hasApiService) {
            infohtml += "      <col style=\"width:30%\">";
            infohtml += "      <col style=\"width:35%\">";
            infohtml += "      <col style=\"width:35%\">";
        } else {
            infohtml += "      <col style=\"width:50% span=\"2\" \">";
        }
        infohtml += "    </colgroup>";
        infohtml += "    <thead>";
        infohtml += "    <tr>";
        infohtml += "      <th>Front-end</th>";
        infohtml += "      <th>Back-end</th>";
        if (hasApiService) {
            infohtml += "      <th>Api</th>";
        }
        infohtml += "    </tr>";
        infohtml += "    </thead>";
        infohtml += "    <tbody>";
        infohtml += "      <tr>";
        infohtml += "        <td class=\"algL\">";
        infohtml += "          <ul id=\"frontend-version\">";
        infohtml += "            <li><strong>" + dews.string.format("파일명: {0}.html", id) + "</strong></li>";
        infohtml += "            <li><strong>버전 정보:</strong> " + self.version.view + "</li>";
        infohtml += "          </ul>";
        infohtml += "        </td>";
        infohtml += "        <td class=\"algL\">";
        infohtml += "          <ul id=\"backend-version\">";
        infohtml += "            <li><strong>서비스명:</strong> " + self.version.service + "</li>";
        infohtml += "            <li><strong>버전 정보:</strong> " + self.version.serviceVersion + "</li>";
        infohtml += "          </ul>";
        infohtml += "        </td>";
        if (hasApiService) {
            infohtml += "        <td class=\"algL\">";
            infohtml += "          <ul id=\"common-version\">";
            infohtml += "            <li><strong>서비스명:</strong> " + self.version.apiService + "</li>";
            infohtml += "            <li><strong>(내부용) 버전 정보:</strong> " + self.version.apiVersion + "</li>";
            infohtml += "          </ul>";
            infohtml += "        </td>";
        }
        infohtml += "      </tr>";
        infohtml += "    </tbody>";
        infohtml += "  </table>";
        infohtml += "</div>";

        dews.ui.dialog(id + "_INFORMATION", {
            content: infohtml,
            title: dews.localize.get("ERP 10 메뉴정보", "D0088709", "", id),
            width: (hasApiService ? 900 : 560),
            height: 370,
            buttons: "close",
        }).open();
    }

    function getPageId(self) {
        if (!self) {
            self = module.getPage();
        }

        if (self === dews.ui.page) {
            return self.menu.id;
        }

        return self === dews.ui.dialogPage ? self.id : null;
    }

    function getAccessToken() {
        return JSON.parse(dews.ui.page.token).access_token;
    }

    function findDataSourceByControl(control, self) {
        var target = {
            menuId: getPageId(self),
            controlId: control.$element[0].id
        };

        if (dataSourceRepository.existsMenuDataSource(target)) {
            return dataSourceRepository.getMenuDataSource(target);
        }

        if (!self) {
            self = module.getPage();
        }

        var dataSource = validateControlDataSource(control);
        return addMenuDataSource(target, getBaseDataSource(dataSource, self));
    }

	/**
	 * 구조 변경 테스트를 위한 findDataSourceByControl 프로토타입
     */
    function protoFindDataSourceByControl(control, self) {
        var target = {
            menuId: getPageId(self),
            controlId: control.$element[0].id
        };

        if (dataSourceRepository.existsMenuDataSource(target)) {
            return dataSourceRepository.getMenuDataSource(target);
        }

        if (!self) {
            self = module.getPage();
        }

        var dataSource = validateControlDataSource(control);
        return addMenuDataSource(target, protoGetBaseDataSource(dataSource, self));
    }

    function validateControlDataSource(control) {
        var dataSource = control.options.dataSource;
        if (!dataSource) {
            var controlId = control.$element.hasClass("dews-ui-cardlist") ? control.$element[0].id
                : control.userOptions._dewsGridID;

            throw new Error("데이터 컨트롤 " + controlId + "\ndataSource가 설정되어 있지 않습니다.");
        }

        return dataSource;
    }

    function getBaseDataSource(dataSource, self) {
        var dataSourceId = dataSource.options.id;
        if (!isDetailDataSource(dataSource) || !dataSourceId.startsWith("__ds_")) {
            return dataSource;
        }

        if (dataSource.options._baseDataSource) {
            return dataSource.options._baseDataSource;
        }

        if (isOrginDataSourceId(dataSourceId)) {
            return self[dataSourceId.substr(6)];
        }

        var detailDataSources = getDetailDataSources(dataSource.options.masterDataSource);
        var huid = dataSourceId.substr(5);

        return self[Object.keys(detailDataSources).find(function (id) {
            return (self[id].options.lineDataSources[huid] === dataSource);
        })];
    }
	
	/**
	 * 구조 변경 테스트를 위한 getBaseDataSource 프로토타입
     */
	function protoGetBaseDataSource(dataSource, self) {
        var dataSourceId = dataSource.options.id;
        if (isOrginDataSourceId(dataSourceId)) {
            return self[dataSourceId.substr(6)];
        }

        if (!isDetailDataSource(dataSource) || !dataSourceId.startsWith("__ds_")) {
            return dataSource;
        }

        if (dataSource.options._baseDataSource) {
            return dataSource.options._baseDataSource;
        }

        var detailDataSources = getDetailDataSources(dataSource.options.masterDataSource);
        var huid = dataSourceId.substr(5);

        return self[Object.keys(detailDataSources).find(function (id) {
            return (self[id].options.lineDataSources[huid] === dataSource);
        })];
    }

    function isDetailDataSource(dataSource) {
        return (dataSource.options.detail && dataSource.options.lineDataSources);
    }

    function isOrginDataSourceId(id) {
        return id ? id.startsWith("orgin_") : false;
    }

    function getDetailDataSources(dataSource) {
        if (!dataSource) {
            return null;
        }

        var detailDataSources = dataSource.options.master;
        if (!detailDataSources) {
            return null;
        }

        $.each(detailDataSources, function (id) {
            if (!isOrginDataSourceId(id)) {
                return false;
            }
            delete detailDataSources[id];
        });

        return detailDataSources;
    }

    function addMenuDataSource(target, dataSource) {
        dataSourceRepository.addMenuDataSource(target, dataSource);
        return dataSource;
    }

    function existsDetailDataSources(detailDataSources) {
        return (detailDataSources && Object.keys(detailDataSources).length > 0);
    }

    function getDataSourceData(dataSource, isDetail, huids) {
        if (!dataSource) {
            return null;
        }

        if (!isBoolean(isDetail)) {
            isDetail = isDetailDataSource(dataSource);
        }

        if (!isDetail) {
            return dataSource.data();
        }

        if (!huids && dataSource.options.lineDataSources) {
            huids = Object.keys(dataSource.options.lineDataSources);
        }

        var data = [];
        huids.forEach(function (huid) {
            var lineDataSource = dataSource.options.lineDataSources[huid].data();
            lineDataSource.forEach(function (row) {
                row._huid = huid;
                data.push(row);
            });
        });

        return data;
    }

    /*********************************************************************************************************************
     * 그리드 관련 시작
    **********************************************************************************************************************/
    module.grid = {
        /**
         * 그리드 데이터 유효성 검사
         * autoDeleteKey => 설정한 필드들 모두 값이 없을 때 자동 행 삭제(행이 추가상태일 경우에만)
         * primaryKey => 설정한 필드들 기본키 검사
         * duplicateKey => 설정한 필드 각각 중복값 검사
         * @param {object} grid 검사 대상 그리드
         * @param {array} masters 마스터&디테일 관계시 검사 대상 그리드의 master grid
         * @return {boolean} 유효성 검사 결과
         */
        verify: function (grid, masters) {
            if (!grid) {
                return false;
            }

            var dataSource = findDataSourceByControl(grid);
            if (!dataSource) {
                return false;
            }

            var verifyKeys = validateVerifyKeys(grid);
            var dirtyData = verifyAutoDeleteRows(dataSource, grid.autoDeleteKey, verifyKeys.autoDeleteKey);
            if (dirtyData.length === 0) {
                return true;
            }

            var huids = null;
            if (dataSource.options.lineDataSources) {
                huids = dirtyData.map(function (row) { return row._huid; })
                    .filter(function (value, index, self) {
                        return self.indexOf(value) == index;
                    });
            }

            var isDetail = isDetailDataSource(dataSource);
            var dataSourceData = getDataSourceData(dataSource, isDetail, huids, grid);

            return verifyRequiredValues(grid, dirtyData, dataSource, masters)
                && verifyPrimaryKeyValues(grid, dataSourceData, dataSource, masters, verifyKeys.primaryKey)
                && verifyDuplicateValues(grid, dataSourceData, huids, isDetail, dataSource, masters, verifyKeys.duplicateKey);
        },
		/**
         * 그리드 데이터 유효성 검사
         * autoDeleteKey => 설정한 필드들 모두 값이 없을 때 자동 행 삭제(행이 추가상태일 경우에만)
         * primaryKey => 설정한 필드들 기본키 검사
         * duplicateKey => 설정한 필드 각각 중복값 검사
		 * 구조 변경 테스트를 위한 verify 프로토타입
         * @param {object} grid 검사 대상 그리드
         * @param {array} masters 마스터&디테일 관계시 검사 대상 그리드의 master grid
         * @return {boolean} 유효성 검사 결과
         */
        protoVerify: function (grid, masters) {
            if (!grid) {
                return false;
            }

            var dataSource = protoFindDataSourceByControl(grid);
            if (!dataSource) {
                return false;
            }

            var verifyKeys = validateVerifyKeys(grid);
            var dirtyData = verifyAutoDeleteRows(dataSource, grid.autoDeleteKey, verifyKeys.autoDeleteKey);
            if (dirtyData.length === 0) {
                return true;
            }

            var huids = null;
            if (dataSource.options.lineDataSources) {
                huids = dirtyData.map(function (row) { return row._huid; })
                    .filter(function (value, index, self) {
                        return self.indexOf(value) == index;
                    });
            }

            var isDetail = isDetailDataSource(dataSource);
            var dataSourceData = getDataSourceData(dataSource, isDetail, huids, grid);

            return verifyRequiredValues(grid, dirtyData, dataSource, masters)
                && verifyPrimaryKeyValues(grid, dataSourceData, dataSource, masters, verifyKeys.primaryKey)
                && verifyDuplicateValues(grid, dataSourceData, huids, isDetail, dataSource, masters, verifyKeys.duplicateKey);
        },
        /**
         * dataSource RowState 초기화
         * @param {object} dataSource 대상 dataSource
         */
        acceptChanges: function (dataSource) {
            if (!dataSource && !dataSource.dataProvider) {
                return;
            }

            function clearRowStates(dataSource) {
                if (dataSource && dataSource.dataProvider) {
                    dataSource.options._destroy = [];
                    dataSource.dataProvider.clearRowStates();
                }
            }

            if (!dataSource.options.lineDataSources) {
                clearRowStates(dataSource);
                return;
            }

            $.each(dataSource.options.lineDataSources, function (id, lineDataSource) {
                clearRowStates(lineDataSource);
            });
        },
        /**
         * 체크된 행 삭제
         * @param {array} checkedRows 체크된 행
         * @param {object} dataSource 대상 dataSource
         * @param {boolean} isDelete lineDataSource delete & remove 여부(기본값 true)
         */
        removeRow: function (checkedRows, dataSource, isDelete) {
            if (checkedRows && dataSource) {
                removeGridRowsOrCardListRows(checkedRows, dataSource, isDelete === undefined ? true : isDelete);
            }
        },
        /**
         * 디테일 그리드 dataSource 재조회
         * @param {object} grid 그리드
         * @param {string} huid 부모 uid
         */
        initLineDataSources: function (grid, huid) {
            if (!grid || !huid) {
                return;
            }

            var dataSource = findDataSourceByControl(grid);
            clearLineDataSources(dataSource);

            dataSource.options.lineDataSources[huid] = dews.ui.dataSource("__ds_" + huid, dataSource.options);
            dataSource.options.lineDataSources[huid].options.master = {};
            dataSource.options.id = dataSource.id;

            grid.setDataSource(dataSource.options.lineDataSources[huid]);
            dataSource.options.lineDataSources[huid].read();
        },
        /**
         * 프리바인딩 초기화
         * - 마스터 그리드(디테일 그리드 포함) 데이터 초기화
         * - 컨디션패널 또는 폼패널의 폼 컨트롤 값 초기화 및 disable 또는 readOnly 해제
         * - 마스터 그리드 행 추가
         * @param {object} mastertGrid 마스터 그리드
         * @param {object | array} panels 컨디션패널 | 폼패널
         * @param {boolean} isEnablePanel enable 여부(false일 경우 readOnly 해제)
         */
        clearFreebinding: function (mastertGrid, panels, isEnablePanel) {
            if (!mastertGrid || !panels) {
                return;
            }

            if (!isBoolean(isEnablePanel)) {
                isEnablePanel = true;
            }

            var self = module.getPage();
            var dataSource = findDataSourceByControl(mastertGrid, self);
            dataSource.data([]);

            function clear(panel) {
                module.clearPanel(panel);
                module[isEnablePanel ? "enablePanel" : "readOnlyPanel"](panel, isEnablePanel);
            }

            if (existsArrayElement(panels)) {
                panels.forEach(function (panel) {
                    clear(panel);
                });
            } else {
                clear(panels);
            }

            mastertGrid.setDataSource(dataSource);
            clearLineDataSources(dataSource);
            mastertGrid.addRow();
        },
        /**
         * 마스터 & 디테일 그리드 설정(전체 데이터 필터)
         * @param {object} mastertGrid 마스터 그리드
         * @param {object} detailGrid 디테일 그리드
         * @param {array} detailData 디테일 데이터
         * @param {array} primaryKey 마스터 기본키
         */
        setDetail: function (mastertGrid, detailGrid, detailData, primaryKey) {
            if (!mastertGrid || !detailGrid || !existsArrayElement(detailData) || !existsArrayElement(primaryKey)) {
                return;
            }

            var self = module.getPage();
            var masterDataSource = findDataSourceByControl(mastertGrid, self);
            var detailDataSource = findDataSourceByControl(detailGrid, self);
            var masterRows = getDataSourceData(masterDataSource);
            var firstUID = "";
            if (masterRows.length > 0) {
                firstUID = masterRows[0]._uid;
            }

            detailDataSource.options.lineDataSources = {};

            for (var i = 0; i < masterRows.length; i++) {
                var masterRow = masterRows[i];
                var uid = masterRow._uid;
                var filterData = detailData.filter(function (row) {
                    return existsDuplicateValues(masterRow, row, primaryKey);
                });

                detailDataSource.options.lineDataSources[uid] = dews.ui.dataSource("__ds_" + uid, detailDataSource.options);
                detailDataSource.options.lineDataSources[uid].options.master = {};
                detailGrid.setDataSource(detailDataSource.options.lineDataSources[uid]);
                detailDataSource.options.lineDataSources[uid].data(filterData);
            }
            detailGrid.setDataSource(detailDataSource.options.lineDataSources[firstUID]);
        },
        /**
        * 그리드 컬럼 사이즈 자동 설정 (fit-content)
        * @author 심재근 연구원
        * @since  2020-06-09
        * @desc : 컬럼 사이즈 컨텐츠에 맞게 재설정
        *         그리드 컬럼 visible:true, 그룹해더가 아닌거에 대해서 fit-contents설정
        * @param : targetGrid:self.grid_ID, setColumns:{limit:[String...], except:[String...]}
        * targetGrid : (필수) 적용시킬 그리드 (self.grid)
        * setColumns : 제외하거나 해당 컬럼만 설정이 필요할 시 setColumns 사용
        * 			       설정할 컬럼이 정해져있지 않고 전체 사용 설정 시 setColumns 파라미터 필요 X
        * 			     : parameterKey는 반드시 [limit, except]를 사용하고 둘 중에 하나만 설정
        * limit [한정]  : 특정컬럼만 자동설정
        * except [제외] : 전체자동설정(특정컬럼 제외)
        * execute_limitFiltering : limit 옵션에서만 적용가능
        * optionValue : default(true), false(특정컬럼외에 나머지 자동설정) - 특정컬럼만 maxsize지정할때
        * 함수 사용 위치 : dataBound 권장.
        * ※참고사항
        * 셀 크기조정이 의외로 많은 시간을 소모 => 데이터가 많을경우 테스트 후 판단.
        */
        setAutoColumnSize: function (targetGrid, setColumns, execute_limitFiltering) {
            /**
            * inner-property : default verify
            * @desc : 그리드 컬럼 (visible:true), 그룹해더 X
            */
            function defaultVerify(item) {
                return item.visible != false && typeof item.columns != "object";
            }
            /**
            * inner-property : option-filter
            * @desc : 옵션의 필터
            */
            function OptionFiltering(optionValue, displayField, whichFilter) {
                var result = false;
                $.each(optionValue, function (idx, col) {
                    if (col.field == displayField) {
                        result = true;
                        return false;
                    }
                });
                return whichFilter == "except" ? !result : result;
            }
            /**
            * inner-property : maxWidth존재 시 세팅
            * @desc : limit에 한해서 - maxWidth 여부
            */
            function maxWidthSetting(setColumns, targetFiled) {
                var maxWidth = 0;
                if (typeof setColumns == "object" && setColumns.limit != undefined) {
                    var optionValue = Object.values(setColumns).pop();
                    $.each(optionValue, function (idx, item) {
                        if (item.field == targetFiled) {
                            maxWidth = item.maxWidth;
                            return false;
                        }
                    });
                }
                return (typeof maxWidth == undefined) ? 0 : maxWidth;
            }

            function parameterVerify(targetGrid, setColumns, execute_limitFiltering) {
                if (typeof setColumns == "object" && Object.keys(setColumns).length == 0) {
                    throw new Error("Function Error\n"
                        + "setAutoColumnSize(1, 2, 3)\n"
                        + "2번째 인자 : 옵션이 비워져있습니다.\n"
                        + "만약 전체설정이라면 2,3번째 인자를 제거해주십시오.");
                }

                if (typeof setColumns == "object" && Object.keys(setColumns).length > 1) {
                    throw new Error("Function Error\n"
                        + "setAutoColumnSize(1, 2, 3)\n"
                        + "2번째 인자 : [limit, except] 한개의 옵션만 가능합니다.\n");
                }

                if (typeof setColumns == "object" && setColumns.except != undefined && setColumns.limit != undefined) {
                    throw new Error("Function Error\n"
                        + "setAutoColumnSize(1, 2, 3)\n"
                        + "2번째 인자 : 키값으로 limit, except 설정만 가능합니다.\n");
                }

                if (typeof setColumns == "object" && setColumns.except != undefined && execute_limitFiltering != undefined) {
                    throw new Error("Function Parameter Error\n"
                        + "setAutoColumnSize(1, 2, 3)\n"
                        + "3번째 인자 : limit옵션만 가능합니다.\n"
                        + "hint : 3번째 인자 제거");
                }
            }

            try {
                parameterVerify(targetGrid, setColumns, execute_limitFiltering); //검증 및 에러처리.

                var displayColumns = targetGrid.options.displayColumns;
                var filteredColumns;
                var execute_limitFiltering = (typeof execute_limitFiltering == "undefined") ? true : execute_limitFiltering;

                // visible : true && groupHead제외
                if (typeof setColumns == "object" && execute_limitFiltering) { // 제외, 제한컬럼 필터링
                    var optionKey = Object.keys(setColumns).pop();
                    var optionValue = Object.values(setColumns).pop();
                    filteredColumns = displayColumns.filter(function (item) {
                        return defaultVerify(item) && OptionFiltering(optionValue, item.field, optionKey);
                    });
                }
                else { // 전체 컬럼 필터링
                    filteredColumns = displayColumns.filter(function (item) {
                        return defaultVerify(item);
                    });
                }

                /**
                 * 사이즈 설정 메소드 (fitColumnWidth)
                * @param : fitColumnWidth("ColumnName", max-width, min-width)
                * max-width, min-width : 0일경우 자동설정
                * ※주의사항
                 * min-width : 0 일경우 헤더사이즈로 조정됨 (틀어질 수 있습니다.)
                */
                // $.each(filteredColumns, function (idx, item) {
                for (var idx = 0; idx < filteredColumns.length; idx++) {
                    var item = filteredColumns[idx];
                    var fieldMaxWidth = maxWidthSetting(setColumns, item.field);
                    // console.debug(dews.string.format("item.field={0}, fieldMaxWidth={1},  item.width={2}", item.field, fieldMaxWidth, item.width));
                    try {
                        targetGrid._grid.fitColumnWidth(item.field, fieldMaxWidth, item.width);
                    }
                    catch (error) {
                        console.error(error);
                    }
                }
                // );

                /**
                 * @desc scorll-x 사라지는 현상 처리
                */
                setTimeout(function () {
                    targetGrid.refresh();
                }, 100);
            } catch (e) {
                // module.showErrorMessage(e);
                console.error(e);
            }
        },
        /**
        * 그리드 행 라디오 타입 체인지
        * @author 심재근 연구원
        * @since  2020-06-10
        * @param : targetGrid = self.gridID,
        *          isChange = true(defualt)
        * @desc : 그리드 row radio type
        *       : 그리드 한 개씩만 선택됨
        *       : 옵션 checkable : true (필수)
        */
        setRowStyleRadioType: function (targetGrid, isChange) {
            if (typeof isChange != undefined) isChange = true;
            targetGrid._grid.setCheckBar({
                exclusive: isChange
            });
        },
        /**
        * 그리드 컬럼 툴팁 지정
        * @author 심재근 연구원
        * @since  2020-06-10
        * @desc : 지정한 컬럼들의 셀에 툴팁설정.
        *         내역과 같은 긴경우에 사용 (화면 이질감 X)
        * @param : targetGrid:self.grid_ID, setColumns: Array[...String]}
        * targetGrid : (필수) 적용시킬 그리드 ( self.grid )
        * setColumns : (필수) 툴팁을 설정할 컬럼명을 설정 ( ["FieldName", "", ""...] )
        * isUsed : true (default) 툴팁설정
        *          false일 시 툴팁설정 해제.
        * ※참고사항 : setAutoColumnSize()함수 함께 사용시 이후에 사용 권장.
        */
        setTooltip: function (targetGrid, setColumns, isUsed) {
            try {
                parameterVerify(setColumns, isUsed); //검증 및 에러처리.

                if (typeof isUsed == "undefined") isUsed = true;
                $.each(setColumns, function (index, columnName) {
                    targetGrid._grid.setColumnProperty(columnName, "renderer", { showTooltip: isUsed });
                });
            } catch (e) {
                module.showErrorMessage(e);
            }

            function parameterVerify(setColumns, isUsed) {
                if (typeof setColumns == "undefined") {
                    throw new Error("Function Error\n"
                        + "setTooltip(1, 2, 3)\n"
                        + "2번째 인자 : 필수 설정값입니다.\n"
                        + "hint : Array[...String]");
                }
                if (typeof setColumns == "object" && Object.keys(setColumns).length == 0) {
                    throw new Error("Function Error\n"
                        + "setTooltip(1, 2, 3)\n"
                        + "2번째 인자 : 옵션이 비워져있습니다.\n"
                        + "hint : Array[...String]");
                }
                if (typeof isUsed != "undefined" && typeof isUsed != "boolean") {
                    throw new Error("Function Error\n"
                        + "setTooltip(1, 2, 3)\n"
                        + "3번째 인자 : type mismatch.\n"
                        + "hint : boolean type (default=true)");
                }
            }
        },
        /**
         * @author 최기석 연구원
         * @since  2021-11-26
         * @desc : 그리드 지정 컬럼들에 셀 구분자릿수별 행바꿈("\n") 툴팁 설정.
         * @param {object} targetGrid 적용 그리드
         * @param {array} setColumns 적용 컬럼
         * @param {int} textLength 구분자릿수
         */
        setEnterTooltip: function (targetGrid, setColumns, textLength) {
            try {
                var columnOption = { renderer: { showTooltip: true } };

                $.each(setColumns, function (index, columnName) {
                    targetGrid.setColumn(columnName, columnOption);
                });

                // 구분자릿수(textLength) 인자를 받지 않은 경우 일괄 구분자릿수 적용
                var textEnterGubun = arguments.length < 3 ? 999 : textLength;

                targetGrid._grid.onShowTooltip = function (grid, index, value) {
                    var column = index.column;
                    // var itemIndex = index.itemIndex;
                    var tooltip = "";
                    // replace 정규식 규칙
                    var regexp = new RegExp("(.{" + textEnterGubun + "})", "g");

                    tooltip =
                        "<div><span style=\"font-size: 13px\">"
                        + value.replace(regexp, "$1\n");
                    + "</span></div>";

                    return tooltip;
                }
            } catch (e) {
                module.showErrorMessage(e);
            }
        },
        /**
         * 그리드 행 삭제 공용로직
         * @param {grid} grid 행 삭제 대상 그리드
         * @param {JSON} options 삭제 옵션
         * - {string} message_prefix : 삭제 메시지 선행문구
         * - {string} message : 삭제 메시지 문구
         * - {string} message_suffix : 삭제 메시지 후행문구
         * - {function} yes(grid, deleteTargets) : 예 버튼의 이벤트
         * - {function} no(grid, deleteTargets) : 아니오 버튼의 이벤트
         * @returns
         */
        deleteConfirm: function (grid, options) {
            if (!grid) {
                throw "대상 그리드가 정의되지 않았습니다.";
            }
            if (options) {
                if (!module.isNotNull(options.message_prefix)) {
                    options.message_prefix = "";
                }
                if (!module.isNotNull(options.message_suffix)) {
                    options.message_suffix = "";
                }
            } else {
                console.debug("기본 옵션으로 그리드 행 삭제 프로세스를 진행합니다.");
                options = {
                    message_prefix: "",
                    message: "",
                    message_suffix: "",
                    yes: null,
                    no: null,
                };
            }

            function default_YES(_targetGrid, deleteTargets) {
                console.debug("YES", deleteTargets, _targetGrid);
                _targetGrid.removeRow(deleteTargets);
            }
            function default_NO(_targetGrid, deleteTargets) {
                console.debug("NO", deleteTargets, _targetGrid);
            }

            // 멀티체크 여부에 따라 삭제 대상 선정.
            let deleteTargets = [];
            if (grid.options.checkBar.visible) {
                deleteTargets = grid.getCheckedIndex();
            } else {
                if (grid.select() >= 0) {
                    deleteTargets.push(grid.select());
                }
            }

            if (!deleteTargets || deleteTargets.length == 0) {
                dews.alert(module.MSG.CHECK_NO_DATA_ALERT, "ico1"); // "선택된 데이터가 없습니다."
                return;
            }

            // 삭제 확인문구 생성
            var confirmMessage = options.message;
            if (!module.isNotNull(confirmMessage)) {
                // 메시지가 정의되지 않은 경우 - 기본 메시지 생성
                // Added 이외의 행을 삭제할 때는 DB에 삭제내역 반영을 위해 저장을 필요로 함.
                let notIncludeAdded = false;
                for (var i = 0; !notIncludeAdded && i < deleteTargets.length; i++) {
                    notIncludeAdded = (notIncludeAdded || (grid.getRowState(deleteTargets[i]) != "added"));
                }
                confirmMessage = (notIncludeAdded ? module.MSG.DELETE_CONFIRM : module.MSG.DELETE_IMME_CONFIRM); // added="삭제 하시겠습니까?" / etc="삭제 하시겠습니까?\n(반드시 저장을 하셔야 반영이 됩니다.)"
            }
            confirmMessage = dews.string.format("{0}{1}{2}", options.message_prefix, confirmMessage, options.message_suffix);

            dews.confirm(confirmMessage, "ico2")
                .yes(function (dialog) {
                    dialog.on("closed", function () {
                        if (options.yes && $.isFunction(options.yes)) {
                            options.yes(grid, deleteTargets);
                        } else {
                            default_YES(grid, deleteTargets);
                        }
                    });
                })
                .no(function (dialog) {
                    dialog.on("closed", function () {
                        if (options.no && $.isFunction(options.no)) {
                            options.no(grid, deleteTargets);
                        } else {
                            default_NO(grid, deleteTargets);
                        }
                    });
                });
        },

        /**
         * 엑셀 임포트를 진행한다.
         * 
         * @param {file} file
         * @param {JSON array} arrOptions
         * -options 임포트 대상 그리드 및 시트명, done(), fail(), always() 함수를 지정합니다.
         */
        excelImports: function (file, arrOptions) {
            loadExcelCommonJS(false);
            $.each(arrOptions, function (index, importOption) {
                if (importOption.grid) {
                    importOption = $.extend(true, { file: file, sheetName: targetSheetName, }, importOption);
                    var targetGrid = importOption.grid;
                    var targetSheetName = (importOption.sheetName ? importOption.sheetName : ("Sheet" + index));

                    targetGrid.importExcel(importOption)
                        .done(function (result) {
                            targetGrid.excelImported = true;
                            console.debug(index, targetGrid._onegrid._gridID + ".done(result)", result);
                            if (importOption.done && $.isFunction(importOption.done)) {
                                importOption.done(result);
                            }
                        })
                        .fail(function (error) {
                            targetGrid.excelImported = false;
                            console.debug(index, targetGrid._onegrid._gridID + ".fail(error)", error);
                            if (importOption.fail && $.isFunction(importOption.fail)) {
                                importOption.fail(error);
                            }
                        })
                        .always(function (result) {
                            console.debug(index, targetGrid._onegrid._gridID + ".always(result)", result);
                            if (importOption.always && $.isFunction(importOption.always)) {
                                importOption.always(result);
                            }
                        });
                } else {
                    console.error("엑셀 Import 대상 Grid가 지정되지 않았습니다.");
                }
            });
        },
    };

    function verifyAutoDeleteRows(dataSource, autoDeleteKey, hasAutoDeleteKey) {
        var dirtyData = dataSource.getDirtyData();
        if (!hasAutoDeleteKey) {
            return dirtyData.Added.concat(dirtyData.Updated);
        }

        var addedDirtyData = dirtyData.Added;
        for (var i = addedDirtyData.length - 1; i >= 0; i--) {
            var rowData = addedDirtyData[i];
            if (!isAutoDeleteRow(rowData, autoDeleteKey)) {
                continue;
            }

            var removeDataSource = rowData._huid ? dataSource.options.lineDataSources[rowData._huid] : dataSource;
            var index = findRowIndex(removeDataSource.data(), "__UUID", rowData.__UUID);
            removeDataSource.remove(index);
            addedDirtyData.splice(i, 1);
        }

        return addedDirtyData.concat(dirtyData.Updated);
    }

    function isAutoDeleteRow(rowData, autoDeleteKey) {
        var count = 0;
        for (var i = 0; i < autoDeleteKey.length; i++) {
            var column = autoDeleteKey[i];
            if ($.type(rowData[column]) === "number" && rowData[column] === 0) {
                continue;
            }

            if (!rowData[column]) {
                count++;
            }
        }

        return (count == autoDeleteKey.length);
    }

    function verifyRequiredValues(grid, dirtyData, dataSource, masters) {
        var columns = grid.columns;
        var requiredColumns = getRequiredColumns(columns, grid.primaryKey);
        if (requiredColumns.length === 0) {
            return true;
        }

        for (var i = 0; i < dirtyData.length; i++) {
            var rowData = dirtyData[i];
            var emptyColumn = requiredColumns.find(function (column) {
                if ($.type(rowData[column]) === "number" && rowData[column] === 0) {
                    return false;
                }

                return !rowData[column];
            });

            if (!emptyColumn) {
                continue;
            }

            var messageInfo = createGridMessageInfo(emptyColumn, columns, "은(는) 필수입력항목 입니다.");
            selectMasterControlRowAndShowMessage(grid, rowData, messageInfo, dataSource, masters);

            return false;
        }

        return true;
    }

    function getRequiredColumns(columns, primaryKeys) {
        var requiredColumns = [];
        $.each(columns, function (name, info) {
            if (info.attributes && info.attributes.class == "required") {
                requiredColumns.push(name);
            }
        });

        if (!primaryKeys) {
            return requiredColumns;
        }

        for (var i = 0; i < primaryKeys.length; i++) {
            var column = primaryKeys[i];
            if (requiredColumns.indexOf(column) == -1) {
                requiredColumns.push(column);
            }
        }

        return requiredColumns;
    }

    function verifyPrimaryKeyValues(grid, dataSourceData, dataSource, masters, hasPrimaryKey) {
        if (!hasPrimaryKey) {
            return true;
        }

        var duplicateRow = getDuplicateRow(dataSourceData, grid.primaryKey);
        if (duplicateRow.index === -1) {
            return true;
        }

        var messageInfo = createGridMessageInfo(grid.primaryKey, grid.columns, " 값이 중복되었습니다.");
        selectMasterControlRowAndShowMessage(grid, duplicateRow.data, messageInfo, dataSource, masters);

        return false;
    }

    function getDuplicateRow(dataSourceData, field) {
        if (existsArrayElement(field)) {
            var duplicateKeys = [];
            for (var i = 0; i < dataSourceData.length; i++) {
                var rowData = dataSourceData[i];
                var existsDuplicateKey = duplicateKeys.find(function (duplicateKey) {
                    return existsDuplicateValues(duplicateKey, rowData, field);
                });

                if (existsDuplicateKey) {
                    return { index: i, data: rowData };
                }

                duplicateKeys.push(rowData);
            }

            return { index: -1, data: null };
        }

        var duplicateValueIndex = dataSourceData.map(function (row) {
            if ($.type(row[field]) === "date") {
                return dews.date.toString(row[field]);
            }

            return row[field] ? row[field] : "";
        }).findIndex(function (value, index, self) {
            return self.indexOf(value) != index;
        });

        return { index: duplicateValueIndex, data: dataSourceData[duplicateValueIndex] };
    }

    function existsDuplicateValues(duplicateKeyValues, checkValues, duplicateKey) {
        for (var i = 0; i < duplicateKey.length; i++) {
            var duplicateKeyValue = duplicateKeyValues[duplicateKey[i]];
            var checkValue = checkValues[duplicateKey[i]];

            if ($.type(duplicateKeyValue) === "date") {
                duplicateKeyValue = dews.date.toString(duplicateKeyValue);
                checkValue = dews.date.toString(checkValue);
            }

            if (module.nvl(duplicateKeyValue, "") !== module.nvl(checkValue, "")) {
                return false;
            }
        }

        return true;
    }

    function createGridMessageInfo(keys, columns, suffixMessage) {
        var codePickers = findCodePickersByHiddenFields(keys, columns);
        if (!existsArrayElement(keys)) {
            var column = findGridColumnBy(keys, columns, codePickers);
            return { fieldName: column.field, message: column.title + suffixMessage };
        }

        var titles = [];
        keys.forEach(function (key) {
            var column = findGridColumnBy(key, columns, codePickers);
            if (column.visible === undefined || column.visible) {
                fieldName = column.field;
                titles.push(column.title);
            }
        });

        return { fieldName: fieldName, message: titles.join("+") + suffixMessage };
    }

    function findCodePickersByHiddenFields(keys, columns) {
        var result = [];
        var hiddenFields = getHiddenFields(keys, columns);
        if (!existsArrayElement(hiddenFields)) {
            return result;
        }

        $.each(columns, function (key, column) {
            if (!column.editor || column.editor.type != "codepicker") {
                return true;
            }

            var findIndex = hiddenFields.findIndex(function (hiddenField) {
                return hiddenField == column.editor.gridCodeField;
            });

            if (findIndex == -1) {
                return true;
            }

            result.push(column);

            hiddenFields.splice(findIndex, 1);
            if (hiddenFields.length == 0) {
                return false;
            }
        });

        return result;
    }

    function getHiddenFields(keys, columns) {
        if ($.type(keys) === "string") {
            return columns[keys].visible === false ? [keys] : [];
        }

        return keys.filter(function (key) {
            return columns[key].visible === false;
        });
    }

    function findGridColumnBy(target, columns, codePickers) {
        if (!existsArrayElement(codePickers)) {
            return columns[target];
        }

        var findField = codePickers.find(function (field) {
            return target == field.editor.gridCodeField;
        });

        return findField ? findField : columns[target];
    }

    function verifyDuplicateValues(grid, dataSourceData, huids, isDetail, dataSource, masters, hasDuplicateKey) {
        if (!hasDuplicateKey) {
            return true;
        }

        for (var i = 0; i < grid.duplicateKey.length; i++) {
            var key = grid.duplicateKey[i];
            var duplicateRow = isDetail ? getDuplicateRowForHUID(huids, dataSourceData, key) : getDuplicateRow(dataSourceData, key);
            if (duplicateRow.index === -1) {
                continue;
            }

            var messageInfo = createGridMessageInfo(key, grid.columns, " 값이 중복되었습니다.");
            selectMasterControlRowAndShowMessage(grid, duplicateRow.data, messageInfo, dataSource, masters);
            return false;
        }

        return true;
    }

    function getDuplicateRowForHUID(huids, dataSourceData, key) {
        for (var i = 0; i < huids.length; i++) {
            var huid = huids[i];
            var detailData = dataSourceData.filter(function (row) {
                return row._huid == huid;
            });

            var duplicateRow = getDuplicateRow(detailData, key);
            if (duplicateRow.index > -1) {
                return duplicateRow;
            }
        }

        return { index: -1, data: null };
    }

    function existsArrayElement(array) {
        return (Array.isArray(array) && array.length > 0);
    }

    function validateVerifyKeys(control) {
        var findInvalidField = getFindInvalidFieldFunction(control.$element.hasClass("dews-ui-cardlist"));
        return {
            primaryKey: hasVerifyKey(control, control.primaryKey, findInvalidField),
            duplicateKey: hasVerifyKey(control, control.duplicateKey, findInvalidField),
            autoDeleteKey: hasVerifyKey(control, control.autoDeleteKey, findInvalidField)
        };
    }

    function getFindInvalidFieldFunction(isCardList) {
        if (isCardList) {
            return function (cardList, fields) {
                var columns = cardList._card.columns;
                var invalidGroupField = "";
                var invalidField = fields.find(function (field) {
                    if (!existsArrayElement(field)) {
                        return !columns.find(function (column) {
                            return column.field == field;
                        });
                    }

                    invalidGroupField = field.find(function (col) {
                        return !columns.find(function (column) {
                            return column.field == col;
                        });
                    });

                    return invalidGroupField;
                });

                return invalidGroupField ? invalidGroupField : invalidField;
            };
        }

        return function (grid, fields) {
            var invalidGroupField = "";
            var invalidField = fields.find(function (field) {
                if (field == "_huid") {
                    return false;
                }

                if (!existsArrayElement(field)) {
                    return !grid.columns[field];
                }

                invalidGroupField = field.find(function (col) {
                    return !grid.columns[col];
                });

                return invalidGroupField;
            });

            return invalidGroupField ? invalidGroupField : invalidField;
        };
    }

    function hasVerifyKey(control, verifyKey, findInvalidField) {
        if (!existsArrayElement(verifyKey)) {
            return false;
        }

        var invalidField = findInvalidField(control, verifyKey);
        if (invalidField) {
            throw new Error(invalidField + " 필드가 존재하지 않습니다.");
        }
        return true;
    }

    function clearLineDataSources(dataSource) {
        var detailDataSources = getDetailDataSources(dataSource);
        if (!existsDetailDataSources(detailDataSources)) {
            if (isDetailDataSource(dataSource)) {
                dataSource.options.lineDataSources = {};
            }
            return;
        }

        $.each(detailDataSources, function (id, detailDataSource) {
            clearLineDataSources(detailDataSource);
        });

        dataSource.options.lineDataSources = {};
    }

    function findRowIndex(data, field, value) {
        if (!Array.isArray(data)) {
            data = Array.from(data);
        }

        return data.findIndex(function (row) {
            return row[field] == value;
        });
    }

    function selectMasterControlRowAndShowMessage(grid, rowData, messageInfo, dataSource, masters) {
        if (existsArrayElement(masters)) {
            selectMasterControlRow(dataSource, masters, rowData._huid);
        }

        var index = grid.searchCell({ fields: ["__UUID"], value: rowData.__UUID });
        selectParentPanelItemsAndGridRow(grid, index, messageInfo.fieldName);
        dews.alert(messageInfo.message, "warning");
    }

    function selectMasterControlRow(dataSource, masters, huid) {
        var master = masters.shift();
        if (!master) {
            return;
        }

        var uid = huid;
        var masterDataSource = dataSource.options.masterDataSource;
        if (isDetailDataSource(masterDataSource)) {
            var lineDataSources = getDataSourceData(masterDataSource, true);
            huid = lineDataSources.find(function (row) { return row._uid == huid; })._huid;
            selectMasterControlRow(masterDataSource, masters, huid);
        }

        var hIndex = findRowIndex(master.sortDataItems(), "_uid", uid);
        master.select(hIndex);
    }

    function selectParentPanelItemsAndGridRow(grid, rowIndex, field) {
        selectParentPanelItems(grid.$element);

        grid.setFocus();
        grid.select(rowIndex, field);
    }

    function selectParentPanelItems(target) {
        var parents = target.parents(".dews-tab-item, .dews-ui-tab-panel, .dews-arcodien-item, .dews-ui-arcodien, .dews-popup-item, .dews-popup-panel");
        var self = module.getPage();

        for (var i = parents.length - 1; i >= 0; i -= 2) {
            var panelId = parents[i].id;
            var itemId = parents[i - 1].id;

            if (!panelId || !itemId) {
                continue;
            }

            if (self["$" + panelId].hasClass("dews-ui-tab-panel")) {
                self[panelId].items.getById(itemId).select();
            } else if (self["$" + panelId].hasClass("dews-ui-arcodien")) {
                self[panelId].items.getById(itemId).open();
            } else if (self["$" + panelId].hasClass("dews-popup-panel")) {
                var popupPanel = dews.ui.popuppanel(self["$" + panelId]);
                popupPanel.show();
                popupPanel.items.getById(itemId).select();
            }
        }
    }

    function removeGridRowsOrCardListRows(checkedRows, dataSource, isDelete) {
        var data = null;
        var isDetail = isDetailDataSource(dataSource);
        if (!isDetail) {
            data = dataSource.data();
            if (!Array.isArray(data)) {
                data = Array.from(data);
            }
        }

        var targetField = dataSource.options.grid ? "__UUID" : "uid";
        var detailDataSources = getDetailDataSources(dataSource);
        for (var i = checkedRows.length - 1; i >= 0; i--) {
            var key = checkedRows[i][targetField];
            var uid = checkedRows[i]._uid;
            var index = -1;

            $.each(detailDataSources, function (id, detailDataSource) {
                if (isDelete) {
                    deleteLineDataSources(detailDataSource, uid);
                } else {
                    removeAllDetailData(detailDataSource, uid);
                }
            });

            if (isDetail) {
                $.each(dataSource.options.lineDataSources, function (huid, lineDataSource) {
                    data = lineDataSource.data();
                    index = findRowIndex(data, "__UUID", key);
                    if (index > -1) {
                        removeDataSourceData(lineDataSource, data[index], index);
                    }
                });
                continue;
            }

            index = findRowIndex(data, targetField, key);
            if (!dataSource.options.grid) {
                return index;
            }
            removeDataSourceData(dataSource, data[index], index);
        }
    }

    function deleteLineDataSources(dataSource, huid) {
        if (!dataSource || !dataSource.options.lineDataSources[huid]) {
            return;
        }

        var lineDataSources = dataSource.options.lineDataSources;
        var detailDataSources = getDetailDataSources(dataSource);
        if (!existsDetailDataSources(detailDataSources)) {
            delete lineDataSources[huid];
            return;
        }

        var data = lineDataSources[huid].data();
        for (var i = 0; i < data.length; i++) {
            var uid = data[i]._uid;

            $.each(detailDataSources, function (id, detailDataSource) {
                deleteLineDataSources(detailDataSource, uid);
            });
        }
        delete lineDataSources[huid];
    }

    function removeAllDetailData(dataSource, huid) {
        if (!dataSource || !dataSource.options.lineDataSources[huid]) {
            return;
        }

        var lineDataSource = dataSource.options.lineDataSources[huid];
        var data = lineDataSource.data();
        var detailDataSources = getDetailDataSources(dataSource);
        if (existsDetailDataSources(detailDataSources)) {
            for (var i = 0; i < data.length; i++) {
                var uid = data[i]._uid;

                $.each(detailDataSources, function (id, detailDataSource) {
                    removeAllDetailData(detailDataSource, uid);
                });
            }
        }

        for (var i = data.length - 1; i >= 0; i--) {
            removeDataSourceData(lineDataSource, data[i], i);
        }
    }

    function removeDataSourceData(dataSource, data, index) {
        if (!dataSource.dataProvider) {
            dataSource.remove(data);
            return;
        }

        if (dataSource.dataProvider.getRowState(index) != "created") {
            dataSource.options._destroy.push(data);
        }
        dataSource.remove(index);
    }
    /*********************************************************************************************************************
     * 그리드 관련 끝
    **********************************************************************************************************************/


    /*********************************************************************************************************************
     * 카드리스트 관련 시작
    **********************************************************************************************************************/
    module.cardlist = {
        /**
         * 카드리스트 데이터 유효성 검사
         * autoDeleteKey => 설정한 필드들 모두 값이 없을 때 자동 행 삭제(행이 추가상태일 경우에만)
         * primaryKey => 설정한 필드들 기본키 검사
         * duplicateKey => 설정한 필드 각각 중복값 검사
         * @param {object} cardlist 검사 대상 카드리스트
         * @param {array} formPanels 검사할 FormPanels(입력 안할 경우 화면 모든 FormPanel 검사)
         * @return {boolean} 유효성 검사 결과
         */
        verify: function (cardlist, formPanels) {
            if (!cardlist) {
                return false;
            }

            var verifyKeys = validateVerifyKeys(cardlist);
            // autodelete 처리 및 처리 남은 데이터 생성 (그리드와 동일)
            var dataItems = cardlistValidateAutoDeleteRows(cardlist, verifyKeys.autoDeleteKey);
            if (dataItems.length === 0) {
                return true;
            }

            var page = module.getPage();
            return cardlistValidateRequiredValues(cardlist, page, formPanels, dataItems)
                && cardlistValidatePrimaryKeyValues(cardlist, page, dataItems, verifyKeys.primaryKey)
                && cardlistValidateDuplicateValues(cardlist, page, dataItems, verifyKeys.duplicateKey);
        },
        /**
         * dataSource RowState Clear
         * @param {object} dataSource 대상 dataSource
         */
        acceptChanges: function (dataSource) {
            if (!dataSource || !dataSource._data || !dataSource._destroyed) {
                return;
            }

            //삭제 상태 초기화
            dataSource._destroyed = [];
            for (var i = 0; i < dataSource._data.length; i++) {
                //추가상태 상태 초기화
                dataSource._data[i].id = dataSource._data[i][dataSource.options.schema.model.id];

                //추가 및 수정상태 초기화
                dataSource._data[i].dirty = false;
                dataSource._data[i].dirtyFields = {};
            }
        },
        /**
         * 체크된 행 삭제
         * @param {array} checkedRows 체크된 행
         * @param {object} cardList 대상 cardList
         * @param {boolean} isDelete lineDataSource delete & remove 여부(기본값 true)
         */
        removeRow: function (checkedRows, cardList, isDelete) {
            if (checkedRows && cardList) {
                var index = removeGridRowsOrCardListRows(checkedRows, findDataSourceByControl(cardList), isDelete === undefined ? true : isDelete);
                cardList.removeRow(index);
            }
        },
        /**
         * 이벤트 바인드
         * @param {object} cardList 적용 카드리스트
         * @param {object} events 카드리스트 이벤트 object
         */
        bindEvents: function (cardList, events) {
            if (!cardList || !events) {
                return;
            }

            if (events.dataBound) {
                cardList.dataBound = events.dataBound;
                delete events.dataBound;
            }

            if (events.change) {
                cardList.change = events.change;
                delete events.change;
            }

            cardList.setOptions(events);
        }
    };

    function cardlistValidateAutoDeleteRows(cardlist, hasAutoDeleteKey) {
        var dataItems = cardlist.sortDataItems();
        if (hasAutoDeleteKey === false) {
            return dataItems;
        }

        var autoDeleteKey = cardlist.autoDeleteKey;
        for (var i = dataItems.length - 1; i >= 0; i--) {
            if (cardlist.getRowState(i) != "added") {
                continue;
            }

            var rowData = dataItems[i];
            if (isAutoDeleteRow(rowData, autoDeleteKey)) {
                cardlist.removeRow(i);

                var removeIndex = dataItems.findIndex(function (row) {
                    return row.uid == rowData.uid;
                });
                dataItems.splice(removeIndex, 1);
            }
        }
        return dataItems;
    }

    // 카드리스트 필수 값 체크
    // 검증 방법은 일반그리드와 동일하지만 문제처리방법이 다르다.
    function cardlistValidateRequiredValues(cardlist, page, formPanels, dataItems) {
        var requiredColumns = cardlistCreateRequiredColumns(page, formPanels, cardlist.primaryKey);
        if (requiredColumns.length === 0) {
            return true;
        }

        for (var i = 0; i < dataItems.length; i++) {
            if (cardlist.getRowState(i) == "none") {
                continue;
            }

            var rowData = dataItems[i];
            for (var j = 0; j < requiredColumns.length; j++) {
                var column = requiredColumns[j];
                if ($.type(rowData[column]) === "number" && rowData[column] === 0) {
                    continue;
                }

                if (!rowData[column]) {
                    var control = page["$" + column];
                    selectCardListRowAndParentPanelItems(cardlist, i, control);

                    dews.ui.snackbar.warning("필수 항목을 입력하세요", "ico3");
                    control.parents(".dews-form-panel").data("dews-control").validate();
                    return false;
                }
            }
        }
        return true;
    }

    // 카드리스트 PrimaryKey 체크
    // 검증 방법은 일반그리드와 동일하지만 문제처리방법이 다르다.
    function cardlistValidatePrimaryKeyValues(cardlist, page, dataItems, hasPrimaryKey) {
        if (!hasPrimaryKey) {
            return true;
        }

        var duplicateRow = getDuplicateRow(dataItems, cardlist.primaryKey);
        if (duplicateRow.index === -1) {
            return true;
        }

        selectCardListRowAndParentPanelItems(cardlist, duplicateRow.index, page["$" + cardlist.primaryKey[0]]);

        var titles = cardlist.primaryKey.map(function (key) {
            return getControlTitle(page["$" + key]);
        });
        dews.alert(titles.join("+") + " 값이 중복되었습니다.", "warning");
        return false;
    }

    // 카드리스트 칼럼중복체크
    // 검증 방법은 동일하지만 일반그리드와 문제처리방법이 다르다.
    function cardlistValidateDuplicateValues(cardlist, page, dataItems, hasDuplicateKey) {
        if (!hasDuplicateKey) {
            return true;
        }

        for (var i = 0; i < cardlist.duplicateKey.length; i++) {
            var field = cardlist.duplicateKey[i];
            var duplicateRow = getDuplicateRow(dataItems, field);
            if (duplicateRow.index === -1) {
                continue;
            }

            var control = existsArrayElement(field) ? page["$" + field[field.length - 1]] : page["$" + field];
            selectCardListRowAndParentPanelItems(cardlist, duplicateRow.index, control);

            if (!existsArrayElement(field)) {
                dews.alert(getControlTitle(control) + " 값이 중복되었습니다.", "warning");
                return false;
            }

            var titles = field.map(function (key) {
                return getControlTitle(page["$" + key]);
            });
            dews.alert(titles + " 값이 중복되었습니다.", "warning");
            return false;
        }

        return true;
    }

    // 카드리스트 필수 칼럼값 배열생성 (폼패널 내에 required 속성 컨트롤과 primaryKeys)
    function cardlistCreateRequiredColumns(page, formPanels, primaryKeys) {
        var requiredColumns = getFormPanelRequiredControls(page, formPanels);
        if (!primaryKeys) {
            return requiredColumns;
        }

        // 사용자가 설정한 primaryKeys도 배열에 추가한다.
        for (var i = 0; i < primaryKeys.length; i++) {
            var column = primaryKeys[i];
            if (requiredColumns.indexOf(column) == -1) {
                requiredColumns.push(column);
            }
        }

        return requiredColumns;
    }

    function getFormPanelRequiredControls(page, formPanels) {
        var requiredColumns = [];
        var controls = null;

        if (!existsArrayElement(formPanels)) {
            controls = page.$content.find(".dews-form-panel *[class^=\"dews-ui-\"].dews-form-control");
            addFormPanelRequiredControls(requiredColumns, controls);
            return requiredColumns;
        }

        for (var i = 0; i < formPanels.length; i++) {
            controls = formPanels[i].find("*[class^=\"dews-ui-\"].dews-form-control");
            addFormPanelRequiredControls(requiredColumns, controls);
        }
        return requiredColumns;
    }

    function addFormPanelRequiredControls(requiredColumns, controls) {
        $.each(controls, function (idx, control) {
            if (control.attributes && control.attributes.class.value.indexOf("required") != -1) {
                requiredColumns.push(control.id);
            }
        });
    }

    function selectCardListRowAndParentPanelItems(cardList, index, control) {
        cardList.select(index);
        selectParentPanelItems(control);
    }

    function getControlTitle(element) {
        var parents = element.parents();
        for (var i = 0; i < parents.length; i++) {
            var parent = parents[i];
            if (parent.previousElementSibling && parent.previousElementSibling.tagName == "LABEL") {
                return parent.previousElementSibling.textContent;
            }
        }

        return null;
    }
    /*********************************************************************************************************************
     * 카드리스트 관련 끝
    **********************************************************************************************************************/



   /*********************************************************************************************************************
    * 트리그리드 관련 시작
   **********************************************************************************************************************/
    module.treegrid = {
        /**
         * 트리그리드 데이터 유효성 검사
         * autoDeleteKey => 설정한 필드들 모두 값이 없을 때 자동 행 삭제(행이 추가상태일 경우에만)
         * primaryKey => 설정한 필드들 기본키 검사
         * duplicateKey => 설정한 필드 각각 중복값 검사
         * @param {object} treegrid 검사 대상 트리그리드
         * @return {boolean} 유효성 검사 결과
         */
        verify: function (treegrid) {
            if (!treegrid) {
                return false;
            }

            var verifyKeys = validateVerifyKeys(treegrid);
            // autodelete 처리
            treeGridValidateAutoDeleteRows(treegrid, verifyKeys.autoDeleteKey);

            // autodelete 처리가 완료되면 트리그리드 구조의 데이터를 일반그리드 구조로 만든다.
            var dataItems = treegrid.sortDataItems();
            var options = {
                fields: ["__UUID"],
                value: ""
            };

            return treeGridValidateRequiredValues(treegrid, options)
                && treeGridValidatePrimaryKeyValues(treegrid, verifyKeys.primaryKey, dataItems, options)
                && treeGridValidateDuplicateValues(treegrid, verifyKeys.duplicateKey, dataItems, options);
        }
    };

    // 트리그리드 autoDelete 칼럼삭제
    function treeGridValidateAutoDeleteRows(grid, hasAutoDeleteKey) {
        if (hasAutoDeleteKey === false) {
            return;
        }

        // 칼럼삭제는 added 상태의 row만 처리하기 때문에 added 값만 가져온다.
        var addDataItems = grid.dataSource.getDirtyData().Added;

        // 트리그리드는 부모 안에 자식이 items로 뭉쳐서 들어가 있기 때문에 index 구조가 일반그리드랑 다르다.
        // 그래서 고유의 index 정보를 가져오기 위해선 uuid 값을 통해 searchCell 함수를 사용한다.
        var options = {
            fields: ["__UUID"],
            value: ""
        };

        for (var i = 0; i < addDataItems.length; i++) {
            var dataItem = addDataItems[i];

            // row를 삭제해야하는 경우
            if (isAutoDeleteRow(dataItem, grid.autoDeleteKey)) {
                // 문제되는 row의 uuid를 option에 설정
                options.value = dataItem.__UUID;
                // searchCell을 이용하여 문제되는 index 를 가져온다.
                var removeIndex = grid.searchCell(options);

                // 삭제 시 자식 row들도 삭제를 해야하기 deleteTreeGridItems 함수를 통해 자식 row를 일괄 삭제한다.
                deleteTreeGridItems(grid, removeIndex);
                // 문제되는 row를 삭제한다.
                grid.remove(removeIndex);
            }
        }
    }

    // 트리그리드 자식노드 삭제
    function deleteTreeGridItems(grid, index) {
        var deleteChildren = grid.getChildrenIndex(index);

        if (deleteChildren) {
            for (var i = 0; i < deleteChildren.length; i++) {
                var deleteIndex = deleteChildren[i];
                deleteTreeGridItems(deleteIndex);
                grid.remove(deleteIndex);
            }
        }
    }

    // 트리그리드 필수 값 체크
    function treeGridValidateRequiredValues(grid, options) {
        var columns = grid.columns;
        var requiredColumns = getRequiredColumns(columns, grid.primaryKey);
        if (requiredColumns.length === 0) {
            return true;
        }

        var targetItems = [];

        // 필수값 체크시에는 added 정보와 updated 정보만 비교하면 되기 때문에 해당 데이터를 만들어준다.
        $.each(grid.dataSource.getDirtyData().Added, function (i, data) {
            targetItems.push(data);
        });

        $.each(grid.dataSource.getDirtyData().Updated, function (i, data) {
            targetItems.push(data);
        });

        for (var i = 0; i < targetItems.length; i++) {
            var rowData = targetItems[i];
            for (var j = 0; j < requiredColumns.length; j++) {
                var column = requiredColumns[j];
                if ($.type(rowData[column]) === "number" && rowData[column] === 0) {
                    continue;
                }

                // 필수 항목 누락 시
                if (!rowData[column]) {
                    // 문제 되는 row의 uuid 값으로 해당 index를 찾는다.
                    options.value = rowData.__UUID;
                    var nullIndex = grid.searchCell(options);
                    // row 선택을 위해 트리그리드 전체를 펼쳐준다.
                    grid.expandAll();
                    // row의 column 선택
                    selectParentPanelItemsAndGridRow(grid, nullIndex, column);
                    dews.alert(columns[column].header.text + "는 필수입력항목입니다.", "warning");
                    return false;
                }
            }
        }

        return true;
    }

    // 트리그리드 PrimaryKey 체크
    // 트리그리드를 일반 그리드화 시켰기 때문에 일반그리드와 처리방법은 동일하다
    function treeGridValidatePrimaryKeyValues(grid, hasPrimaryKey, dataItems, options) {
        if (hasPrimaryKey === false) {
            return true;
        }

        var primaryKeys = [];
        var columns = grid.columns;

        for (var i = 0; i < dataItems.length; i++) {
            var dataItem = dataItems[i];
            var existsKey = primaryKeys.find(function (row) {
                for (var j = 0; j < grid.primaryKey.length; j++) {
                    if (dataItem[grid.primaryKey[j]] !== row[grid.primaryKey[j]]) {
                        return false;
                    }
                }
                return true;
            });

            if (existsKey) {
                var title = columns[grid.primaryKey[0]].header.text;
                for (var j = 1; j < grid.primaryKey.length; j++) {
                    title += " + " + columns[grid.primaryKey[j]].header.text;
                }

                // 문제 되는 row의 uuid 값으로 해당 index를 찾아 row의 column 선택처리
                options.value = dataItem.__UUID;
                var pIndex = grid.searchCell(options);
                grid.expandAll();
                selectParentPanelItemsAndGridRow(grid, pIndex, grid.primaryKey[0]);
                dews.alert(title + " 값이 중복되었습니다.", "warning");
                return false;
            }

            primaryKeys.push(dataItem);
        }

        return true;
    }

    // 트리그리드 칼럼중복체크
    // 트리그리드를 일반 그리드화 시켰기 때문에 일반그리드와 처리방법은 동일하다
    function treeGridValidateDuplicateValues(grid, hasDuplicateKey, dataItems, options) {
        if (hasDuplicateKey === false) {
            return true;
        }

        for (var i = 0; i < grid.duplicateKey.length; i++) {
            var field = grid.duplicateKey[i].trim();

            var targetColValues = dataItems.map(function (row) {
                return row[field] ? row[field] : "";
            });
            for (var j = 0; j < targetColValues.length; j++) {
                if (targetColValues.indexOf(targetColValues[j]) != j) {

                    // 문제 되는 row의 uuid 값으로 해당 index를 찾아 row의 column 선택처리
                    options.value = dataItems[j].__UUID;
                    var pIndex = grid.searchCell(options);
                    grid.expandAll();
                    selectParentPanelItemsAndGridRow(grid, pIndex, field);
                    dews.alert(grid.columns[field].header.text + " 값이 중복되었습니다.", "warning");
                    return false;
                }
            }
        }
        return true;
    }
    /*********************************************************************************************************************
     * 트리그리드 관련 끝
    **********************************************************************************************************************/



   /*********************************************************************************************************************
    * 트리 관련 시작
   **********************************************************************************************************************/
    module.tree = {
        /**
         * TreeNode N레벨까지 확장
         * @author 심재근 연구원
         * @since  2020-06-09
         * @desc Service에서 LEVEL값 세팅(필수) => 서비스 메소드(levelSetting) OR 재귀쿼리구현
         * @param {object} treeview 대상 treeview
         * @param {object} treegrid 대상 treegrid
         * @param {int} level 확장설정레벨 (default:1)
         */
        expandToLevel: function (treeview, treegrid, level) {
            try {
                if (typeof level == "undefined" || typeof level == "null") level = 1;

                var rootItem = treegrid.dataItems().pop();
                if (!rootItem) { //undefined일시
                    treeview.select(".k-item:first");
                    return;
                }
                // intial tree has leaf nodes data

                // do conversion
                var array = convertTreeToList(rootItem);

                // converts to list of data
                // removes duplicates and preserves order

                var searchGridItems = array;
                var filterItems = searchGridItems.filter(function (item) {
                    return item.LEVEL < level;
                });

                treeview.expandPath([]); //첫노드 확장.

                $.each(filterItems, function (idx, item) {
                    treeview.select("input[id=\"" + item.__UUID + "\"]");
                    treeview.expand(treeview.select());
                });

            } catch (error) {
                module.showErrorMessage(error);
            }
        },
        /**
        * 트리뷰 ♻️ 트리그리드 : 연동
        * @author 심재근 연구원
        * @since  2020-06-18
        * @desc : 트리뷰 선택 시 선택된 노드와 동일한 노드를 트리그리드도 선택되게 처리 (필수)
        *         같은 조회 데이터를 가져와서 트리뷰, 트리그리드에 세팅했기 때문에
        *         동일한 __UUID를 가지고 있어서 가능한 로직.
        * @param {object} treeview 대상 treeview
        * @param {object} treegrid 대상 treegrid
        */
        selectBinding: function (treeview, treegrid) {
            try {
                var isSearch = treegrid.searchCell({
                    fields: ["__UUID"],
                    value: treeview.dataItem(treeview._current).__UUID,
                    startIndex: treegrid.select()
                });
            } catch (error) {
                module.showErrorMessage(error);
            }
        },
        /**
        * 트리 검색기능
        * @author 심재근 연구원
        * @since  2020-06-26
        * @desc : 검색 그리드 활용
        *         검색 결과 존재 시  : 해당 노드까지 오픈 후 검색된 노드선택 및 노드 Scroll위치값으로 이동
        *         존재 X시 : 검색 결과X 메세지 표시
        * @param {object} treeview  대상 treeview
        * @param {object} treegrid  대상 treegrid
        * @param {object} textBox  대상 textBox
        * @param {string} keyword  검색할 TEXT 값
        * @param {object} searchArrayList  검색할 컬럼키 ["grp_cd","grp_nm",....]
        */
        searchTreeView: function (treeview, treegrid, textBox, keyword, searchArrayList) {
            try {
                /**
                 * searchCell(option) - 그리드에서 셀을 검색.
                 * @param object
                 * @param {array} fields : 검색할 field명 설정
                 * @param {string} value : 검색 키워드
                 * @param {number} startIndex : n번째 행부터 검색 (기본값:현재 선택된 행) (생략 O)
                 * @param {boolean} wrap : 해당 글자가 없으면 다시 검색 설정 (기본값:true) (생략 O)
                 * @param {boolean} caseMatch : 대소문자 구분 (기본값:false) (생략 O)
                 * @param {boolean} partialMatch : 일치 하는 문구만 검색 (기본값:true) false로 설정시 완벽히 일치 하는 문구만 검색 설정 (생략 O)
                 * @return {number} : 선택된 행 index값
                 */
                keyword = (typeof keyword == "undefined") ? textBox.text() : keyword;

                var isSearch = treegrid.searchCell({ fields: searchArrayList, value: keyword, startIndex: treegrid.select() });
                // 조회된 row가 있을 경우
                if (isSearch != undefined) {
                    var treeGridData = treegrid.dataItems(isSearch);
                    var searchKey = treeGridData.__UUID;
                    treeview.select("input[id=\"" + searchKey + "\"]");
                    var targetNode = treeview.select();

                    //검색시 펼쳐짐
                    var $parents = $(targetNode).parents("li");
                    $.each($parents, function (idx, node) {
                        var $node = $(node);
                        treeview.expand(node);
                    });

                    // 해당 노드위치의 Scroll 이동
                    // tree expand 속도가 느리기 때문에 비동기처리 해야됨.
                    setTimeout(function () {
                        treeview.scrollTo(treeview.select());
                    }, 200);

                    // 키워드 검색 재 포커싱.
                    if (keyword && textBox) {
                        textBox.focus();
                    }
                } else { //조회결과가 없을 경우
                    dews.ui.snackbar.warning("검색된 데이터가 없습니다.");
                }
            } catch (error) {
                module.showErrorMessage(error);
            }
        },
        /**
         * @method : 노드삭제 (자식포함)
         * @author : 심재근 연구원
         * @since  :  2020-06-19
         * @desc   : 선택한 트리의 노드와 관련된 데이터 삭제 처리
         *           1. 선택한 트리그리드의 노드삭제 (자식노드포함)
         *           2. 연결된 트리뷰의 노드삭제 (부모만) - 관리를 안하기 때문
         *           3. 삭제후 노드 선택처리 (트리그리드의 선택된 노드 기준 -> 트리뷰반영)
         * @param {object} treeview : 대상 treeview
         * @param {object} treegrid : 대상 treegrid
        */
        removeRows: function (treeview, treegrid) {
            try {
                //childs rowId (선택한 트리그리드노드의 자식노드)
                var index = treegrid.select();
                var childsRowsId = treegrid.dataSource.dataProvider.getDescendants(index);
                childsRowsId = (childsRowsId == null) ? [] : childsRowsId; //자식이 없을 경우 자신만 세팅
                childsRowsId.push(index);

                // dirtyData"s delete에 담기
                $.each(childsRowsId, function (idx, item) {
                    treegrid.dataSource.options._destroy.push(treegrid.dataItem(item));
                });
                // display remove 처리 (트리그리드)
                treegrid._grid._dataSource.removeRows(childsRowsId);

                // display remove 처리 (트리뷰) - 관리안하기 때문에 부모노드(선택한노드)만 remove 처리
                treeview.remove(treeview._current);

                // 화면에서 지운후 선택될 노드 = 트리그리드가 지운후 선택된 노드 설정
                // 주의 사항 - treeview 템플릿 설정 시 hidden에 부여하는 input 태그값 id에 __UUID 설정 반드시 필요.
                treeview.select("input[id=\"" + treegrid.dataItem(treegrid.select()).__UUID + "\"]");
            } catch (error) {
                module.showErrorMessage(error);
            }
        },
        /**
         * @method : 유효성 검증
         * @author : 심재근 연구원
         * @since  :  2020-09-24
         * @desc   : 트리그리드 verify 적용 후 선택된 트리그리드 id로 treeview 검색
         * @param {object} treeview : 대상 treeview
         * @param {object} treegrid : 대상 treegrid
        */
        verify: function (treeview, treegrid) {
            try {
                var result = module.treegrid.verify(treegrid);

                // 주의 사항 - treeview 템플릿 설정 시 hidden에 부여하는 input 태그값 id에 __UUID 설정 반드시 필요.
                treeview.select("input[id=\"" + treegrid.dataItem(treegrid.select()).__UUID + "\"]");
                return result;
            } catch (error) {
                module.showErrorMessage(error);
            }
        }
    };

    /**
     * @method : 트리데이터 구조 -> list 구조 변경(flat)
     * @author : 심재근 연구원
     * @since  : 2020-06-19
     * @param  {object} root : Object{[...]}
    */
    function convertTreeToList(root) {
        try {
            var stack = [], array = [], hashMap = {};
            stack.push(root);

            while (stack.length !== 0) {
                var node = stack.pop();
                visitNode(node, hashMap, array);
                if (node.items) {
                    for (var i = node.items.length - 1; i >= 0; i--) {
                        stack.push(node.items[i]);
                    }
                }
            }
            return array;
        } catch (error) {
            module.showErrorMessage(error);
        }
    }
    /**
     * @method : 접근노드 추가 -> list 구조 변경(flat)
     * @author : 심재근 연구원
     * @since  : 2020-06-19
     * @param  {object} node : 접근노드
     * @param  {object} hashMap : 검증용 hashmap
     * @param  {object} array : 검증 완료된 노드를 담을 객체
    */
    function visitNode(node, hashMap, array) {
        if (!hashMap[node.__UUID]) {
            hashMap[node.__UUID] = true;
            array.push(node);
        }
    }
    /*********************************************************************************************************************
     * 트리 관련 끝
    **********************************************************************************************************************/


    /**
     * 일 수 차이 계산
     * @param {string} date1 기준일1
     * @param {string} date2 기준일2
     * @return {string} 차이 일 수
     */
    module.getDateDiff = function (date1, date2) {
        var diffDate_1 = dateParse(date1),
            diffDate_2 = dateParse(date2);

        var diff = (diffDate_2.getTime() - diffDate_1.getTime());
        diff = Math.ceil(diff / (1000 * 3600 * 24));

        return String(diff);
    };

    function dateParse(str) {
        var y = str.substr(0, 4),
            m = str.substr(4, 2) - 1,
            d = str.substr(6, 2);
        var D = new Date(y, m, d);
        return (D.getFullYear() == y && D.getMonth() == m && D.getDate() == d) ? D : "invalid date";
    }

    /**
     * 시작일, 종료일 유효성 검증
     * @param {string} startDate 시작일
     * @param {string} endDate 종료일
     * @return {boolean} 시작일 <= 종료일 true, 그외 false
     */
    module.getDateCheck = function (startDate, endDate) {
        return (startDate && endDate) && startDate <= endDate;
    };

    /**
     * 공통코드 데이터소스 조회
     * @param {string} module_cd 모듈 코드
     * @param {string} field_cd_pipe 코드디테일 코드(| 구분자, ; 공백 데이터 추가)
     * @param {string} syscode_yn 시스템코드 유무
     * @param {string} base_yn 디폴트 코드구분
     * @param {string} foreign_yn 외국언어적용 유무
     * @param {string} end_dt 종료일
     * @param {string} keyword 검색할 코드 또는 명
     * @return {object} 공통코드 데이터소스
     */
    module.getCodeDtlDataSource = function (module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
        if (!module_cd || !field_cd_pipe) {
            return null;
        }

        var codeDataSources = {};
        codeDataSources[module_cd] = {};

        dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", "common_codeDtl_list"), {
            async: false,
            data: {
                module_cd: module_cd,
                field_cd_pipe: field_cd_pipe.replace(/;/g, ""),
                syscode_yn: syscode_yn,
                base_yn: base_yn,
                foreign_yn: foreign_yn,
                end_dt: end_dt,
                keyword: keyword,
            }
        }).done(function (data) {
            field_cd_pipe.split("|").forEach(function (fieldCd) {
                var isAddEmpty = fieldCd.startsWith(";");
                fieldCd = fieldCd.replace(";", "");
                codeDataSources[module_cd][fieldCd] = createCodeDtlDataSource(fieldCd, data, isAddEmpty);
            });
        }).fail(function (error) {
            dews.error(error.responseJSON.message);
        });

        return codeDataSources;
    };

    function createCodeDtlDataSource(fieldCd, data, isAddEmpty) {
        var filterData = data.filter(function (row) { return row.FIELD_CD == fieldCd; });
        if (isAddEmpty) {
            filterData.unshift({ FIELD_CD: fieldCd, SYSDEF_CD: "", SYSDEF_NM: "", FLAG_CD: "", END_DT: "", SYSCODE_YN: "" });
        }

        var dataSource = dews.ui.dataSource(fieldCd, {
            data: filterData,
            schema: {
                model: { id: "SYSDEF_CD" }
            }
        });
        dataSource.read();

        return dataSource;
    }

    /**
     * 코드디테일 초기화
     * - 공백 추가
     * - 데이터 필터
     * @param {array | object} data 코드디테일 데이터
     * @param {boolean} addEmpty 공백 데이터 추가 여부
     * @param {array | function} filter 필터 조건
     * @param {boolean} isContains filter 값이 Array 일 경우 데이터 포함 여부
     * @param {string} primaryKey 데이터소스 PK 필드
     * @return {object} 코드 데이터소스
     */
    module.initCodeDtl = function (data, addEmpty, filter, isContains, primaryKey) {
        try {
            if (!data) {
                return null;
            }

            if (!isBoolean(addEmpty)) {
                addEmpty = false;
            }

            if (!(existsArrayElement(data) || ($.type(data) === "object" && data.options.data.length > 0))
                || (!addEmpty && !filter)
                || (filter && !existsArrayElement(filter) && $.type(filter) !== "function")) {
                return createNewCodeDtlDataSource(data, Array.isArray(data) ? data : data.options.data, primaryKey);
            }

            if (!isBoolean(isContains)) {
                isContains = true;
            }

            var newData = copyCodeDtlData(data);
            var keys = Object.keys(newData[0]);

            newData = filterCodeDtlData(newData, filter, isContains);

            addEmptyCodeDtlData(newData, addEmpty, keys);

            return createNewCodeDtlDataSource(data, newData, primaryKey);
        } catch (error) {
            module.showErrorMessage(error);
        }
    };

    function createNewCodeDtlDataSource(origin, newData, primaryKey) {
        var options = { data: newData };
        if (primaryKey) {
            options.schema = { model: { id: primaryKey } };
        } else if ($.type(origin) === "object" && origin.options.schema.model && origin.options.schema.model.id) {
            options.schema = { model: { id: origin.options.schema.model.id } };
        }

        var dataSource = dews.ui.dataSource("_dsNew" + createFilterCodeDtlSeq(), options);
        dataSource.read();

        return dataSource;
    }

    function copyCodeDtlData(data) {
        if ($.type(data) === "object") {
            data = data.options.data;
        }

        return Array.isArray(data) ? JSON.parse(JSON.stringify(data)) : null;
    }

    function filterCodeDtlData(data, filter, isContains) {
        if (!filter) {
            return data;
        }

        if ($.type(filter) === "function") {
            return data.filter(filter);
        }

        for (var i = data.length - 1; i >= 0; i--) {
            var index = filter.findIndex(function (element) {
                return element == i;
            });
            if ((isContains && index == -1) || (!isContains && index >= 0)) {
                data.splice(i, 1);
            }
        }
        return data;
    }

    function addEmptyCodeDtlData(data, addEmpty, keys) {
        if (addEmpty !== true) {
            return;
        }

        var emptyData = {};
        for (var i = 0; i < keys.length; i++) {
            emptyData[keys[i]] = "";
        }

        data.unshift(emptyData);
    }

    function createFilterCodeDtlSeq() {
        return "xxxxx-xxxx".replace(/[xy]/g,
            function (c) {
                var r = Math.random() * 16 | 0, v = c === "x" ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
    }

    module.getString = function (value) {
        try {
            if (value) {
                return String(value);
            }
        } catch (error) {
            module.showErrorMessage(error);
        }
        return "";
    };

    module.getInt = function (value) {
        try {
            if (module.isNumber(value)) {
                return parseInt(value);
            }
        } catch (error) {
            module.showErrorMessage(error);
        }
        return 0;
    };

    module.getFloat = function (value) {
        try {
            return module.getNumber(value) === 0 ? 0.0 : module.getNumber(value);
        } catch (error) {
            module.showErrorMessage(error);
        }
        return 0.0;
    };

    module.getNumber = function (value) {
        var parsedValue = Number(value);
        if (!isNaN(parsedValue) && parsedValue !== undefined) {
            return parsedValue;
        }
        return 0;
    };

    module.isNumber = function (value) {
        if (value) {
            var number = Number(value);
            if (!isNaN(number)) {
                return true;
            }
        }
        return false;
    };

    /**
     * value 가 null, undefined, 공백이 아니라면 true 를 리턴
     * @param {*} value 체크객체
     * @return {boolean} Not Null 인지 여부
     */
    module.isNotNull = function (value) {
        return (value !== null && value !== undefined && value !== "");
    };

    /**
     * value 가 null, undefined, 공백이라면 true 를 리턴
     * @param {*} value 체크객체
     * @return {boolean} Null 인지 여부
     */
    module.isNull = function (value) {
        return !module.isNotNull(value);
    };

    /**
     * 문자열에 데이터가 존재하는지 아닌지 체크하는 함수
     * @param {*} value 입력값
     * @param {*} values 비교값
     * @return true/false
     */
    module.isIn = function (value, values) {
        try {
            if (module.isNotNull(values.match(new RegExp(value)))) {
                return true;
            }
            return false;
        } catch (error) {
            module.showErrorMessage(error);
        }
    };

    /**
     * Oracle NVL 유사함수.
     * value 가 공백문자("") 혹은 null 혹은 undefined 라면 nullValue 를 반환한다.
     * @param {* | Array} value 체크 값
     * @param {*} nullValue null/undefined 기본값
     * @return {*} value 혹은 nullValue
     */
    module.nvl = function (value, nullValue) {
        try {
            var selectedValue = null;
            if (Array.isArray(value) && module.isNotNull(value) && value.length > 0) {
                for (var i = 0; !module.isNotNull(selectedValue) && i < value.length; i++) {
                    selectedValue = module.nvl(value[i], null);
                }
            } else if (module.isNotNull(value)) {
                selectedValue = value;
            } else {
                selectedValue = nullValue;
            }
            return selectedValue;
        } catch (error) {
            module.showErrorMessage(error);
        }
    };

    /**
     * Panel 내부 컨트롤 값 초기화
     * @param {object} panel 패널 컨트롤
     * @param {array} excludeItems 제외 컨트롤(기본값 [])
     */
    module.clearPanel = function (panel, excludeItems) {
        try {
            executeActionOfFormControlsForPanel(panel, excludeItems, function (control, className) {
                if (   className.startsWith("dews-ui-dropdownlist") || className.startsWith("dews-ui-maskedtextbox")
                    || className.startsWith("dews-ui-datepicker") || className.startsWith("dews-ui-timepicker")
                    || className.startsWith("dews-ui-monthpicker") || className.startsWith("dews-ui-yearpicker")
                    || className.startsWith("dews-ui-datetimepicker") || className.startsWith("dews-ui-zipcodepicker")
                    || className.startsWith("dews-ui-combobox") || className.startsWith("dews-ui-editor")) {
                    control.value("");
                    if (typeof (control.text) == "function") {
                        control.text("");
                    }
                } else if (className.startsWith("dews-ui-numerictextbox")) {
                    control.value(null);
                } else if (className.startsWith("dews-ui-textbox")) {
                    control.reset();
                } else if (className.startsWith("dews-ui-monthperiodpicker") || className.startsWith("dews-ui-weekperiodpicker")) {
                    control.setPeriod("", "");
                } else if (className.startsWith("dews-ui-periodpicker")) {
                    control.setStartDate("");
                    control.setEndDate("");
                } else if (className.startsWith("dews-ui-codepicker")) {
                    control.clearData();
                } else if (className.startsWith("dews-ui-multicodepicker")) {
                    control.clear();
                } else if (className.startsWith("dews-ui-checkbox")) {
                    control.target[0].checked = false;
                } else if (className.startsWith("dews-ui-radio-group")) {
                    control.select(0);
                } else if (className.startsWith("dews-ui-multidropdownlist")) {
                    control.deselectAll();
                }
            });
        } catch (error) {
            module.showErrorMessage(error);
        }
    };

    /**
     * Panel 내부 컨트롤 활성화 여부 설정
     * @param {object} panel 패널 컨트롤
     * @param {boolean} state 활성화 여부(기본값 false)
     * @param {array} excludeItems 제외 컨트롤(기본값 [])
     */
    module.enablePanel = function (panel, state, excludeItems) {
        try {
            if (!isBoolean(state)) {
                state = false;
            }

            executeActionOfFormControlsForPanel(panel, excludeItems, function (control, className, state) {
                if (className.startsWith("dews-ui-checkbox") || className.startsWith("dews-ui-radio")) {
                    control.disable(!state);
                } else {
                    control.enable(state);
                }
            }, state);
        } catch (error) {
            module.showErrorMessage(error);
        }
    };

    function executeActionOfFormControlsForPanel(panel, excludeItems, action, state) {
        if (!panel) {
            return;
        }

        var formControls = getFormControls(panel, excludeItems);
        formControls.forEach(function (target) {
            action(target.control, target.className, state);
        });
    }

    function getFormControls(panel, excludeItems) {
        let dewsControlSelector = "*[class^=\"dews-ui-\"].dews-form-control, .dews-ui-button";
        var resultItems = [];
        var excludeControlIds = "";
        if (existsArrayElement(excludeItems)) {
            var tmpExcludeItems = []; excludeItems.forEach(function (itm, idx, arr) { tmpExcludeItems.push(itm); });  // excludeItems 파라메터의 원본 유지를 위해 임시 변수를 할당하여 사용.
            var excludePanels = panel.find(".dews-ui-container-panel, .dews-container-panel");
            for (var i = 0; i < excludePanels.length; i++) {
                // 예외 항목 중 패널이 있는지 확인
                var pnlIdx = tmpExcludeItems.indexOf(excludePanels[i].id);
                if (pnlIdx >= 0) {
                    // 예외항목의 패널 내에 컨트롤 획득.
                    var childControls = $(excludePanels[i]).find(dewsControlSelector).map(function (idx, con) { return con.id; }).toArray();

                    if (existsArrayElement(childControls)) {
                        // 예외 항목의 패널명 제거.
                        tmpExcludeItems.splice(pnlIdx, 1);

                        // 예외 항목 패널의 자식 컨트롤을 예외 항목으로 추가.
                        for (var j = 0; childControls && j < childControls.length; j++) {
                            if (tmpExcludeItems.indexOf(childControls[j]) == -1) {
                                tmpExcludeItems.push(childControls[j]);
                            }
                        }
                    }
                }
            }
            excludeControlIds = tmpExcludeItems.map(function (id) {
                return ("#" + id);
            }).join(",");
        }

        panel.find(dewsControlSelector).not(excludeControlIds).each(function () {
            resultItems.push({
                control: $(this).data("dews-control"),
                className: $(this).attr("class")
            });
        });
        return resultItems;
    }

    /**
     * Panel 내부 컨트롤 읽기전용 여부 설정
     * 예외) 버튼, 체크박스, 라디오버튼, 라디오그룹은 enable 처리
     * @param {object} panel 패널 컨트롤
     * @param {boolean} state 읽기전용 여부(기본값 true)
     * @param {array} excludeItems 제외 컨트롤(기본값 [])
     */
    module.readOnlyPanel = function (panel, state, excludeItems) {
        try {
            if (!isBoolean(state)) {
                state = true;
            }

            executeActionOfFormControlsForPanel(panel, excludeItems, function (control, className, state) {
                if (className.startsWith("dews-ui-checkbox") || className.startsWith("dews-ui-radio")) {
                    control.disable(state);
                } else if (className.startsWith("dews-ui-button")) {
                    control.enable(!state);
                } else {
                    control.readonly(state);
                }
            }, state);
        } catch (error) {
            module.showErrorMessage(error);
        }
    };

    /**
     * 해당 ID의 폼 컨트롤 값 리턴
     * @param {string} targetId 폼 컨트롤 ID
     * @return {string | boolean | object} 폼 컨트롤 값
     */
    module.getValue = function (targetId) {
        try {
            if (!targetId) {
                return "";
            }

            var self = module.getPage();
            var element = self["$" + targetId];
            if (!element) {
                return "";
            }

            var control = element.data("dews-control");
            if (!control) {
                return "";
            }

            if (element.hasClass("dews-ui-dropdownlist") || element.hasClass("dews-ui-numerictextbox")
                || element.hasClass("dews-ui-datepicker")
                || element.hasClass("dews-ui-timepicker") || element.hasClass("dews-ui-monthpicker")
                || element.hasClass("dews-ui-yearpicker") || element.hasClass("dews-ui-datetimepicker")
                || element.hasClass("dews-ui-zipcodepicker") || element.hasClass("dews-ui-combobox")
                || element.hasClass("dews-ui-editor")) {
                return module.getString(control.value());
            } else if (element.hasClass("dews-ui-maskedtextbox")) {
                return module.getString(control.raw());
            } else if (element.hasClass("dews-ui-textbox")) {
                return module.getString(control.text());
            } else if (element.hasClass("dews-ui-weekperiodpicker")) {
                return { "startWeek": module.getString(control.getStartWeek()), "endWeek": module.getString(control.getEndWeek()) };
            } else if (element.hasClass("dews-ui-monthperiodpicker") || element.hasClass("dews-ui-periodpicker")) {
                return { "startDate": module.getString(control.getStartDate()), "endDate": module.getString(control.getEndDate()) };
            } else if (element.hasClass("dews-ui-codepicker")) {
                return module.getString(control.code());
            } else if (element.hasClass("dews-ui-multicodepicker")) {
                return control.codes();
            } else if (element.hasClass("dews-ui-checkbox")) {
                return control.value();
            } else if (element.hasClass("dews-ui-radio")) {
                return element[0].checked;
            } else if (element.hasClass("dews-ui-radio-group")) {
                return element[0].value;
            } else if (element.hasClass("dews-ui-multidropdownlist")) {
                return control.values();
            }
        } catch (error) {
            module.showErrorMessage(error);
        }
        return "";
    };

    /**
     * 화면의 모든 그리드, 트리그리드, 카드리스트, 멀티파일 컨트롤의 데이터소스 DirtyData 체크
     * @param {array} excludeDataSources 제외 dataSource
     * @return {boolean} 변경여부
     */
    module.hasDirty = function (excludeDataSources) {
        var options = {
            existsExcludeDataSources: existsArrayElement(excludeDataSources),
            excludeDataSources: excludeDataSources
        };

        return executeActionOfDataControls(function (control, self, options) {
            var dataSource = findDataSourceByControl(control, self);
            if (options.existsExcludeDataSources && options.excludeDataSources.indexOf(dataSource) > -1) {
                return false;
            }

            if (dataSource.getDirtyDataCount() > 0) {
                return true;
            }
        }, ["cardlist", "multifile"], options);
    };

    /**
     * 화면의 모든 그리드, 트리그리드 commitCell() 호출
     */
    module.commitCells = function () {
        executeActionOfDataControls(function (control) {
            control.commitCell();
        });
    };

    /**
     * 화면의 모든 그리드, 트리그리드, 카드리스트의 데이터소스 RowState 초기화
     */
    module.acceptChanges = function () {
        executeActionOfDataControls(function (control, self) {
            var dataSource = findDataSourceByControl(control, self);
            if (dataSource.getDirtyDataCount() > 0) {
                module[control.$element.hasClass("dews-ui-cardlist") ? "cardlist" : "grid"].acceptChanges(dataSource);
            }
        }, ["cardlist"]);
    };

    function executeActionOfDataControls(action, targets, options) {
        var self = module.getPage();
        var result = false;

        var classNames = getTargetClassNames(targets);
        self.$content.find(classNames).each(function () {
            var control = $(this).data("dews-control");
            if (control && action(control, self, options)) {
                result = true;
                return false;
            }
        });

        return result;
    }

    function getTargetClassNames(targets) {
        var classNames = ".dews-ui-grid, .dews-ui-treegrid";
        if (!existsArrayElement(targets)) {
            return classNames;
        }

        targets.forEach(function (target) {
            classNames += ", .dews-ui-" + target;
        });

        return classNames;
    }

    /**
     * 인쇄 호출
     * @param {string} reportId 리포트코드
     * @param {array} printInfos 출력물 정보
     */
    module.executePrint = function (reportId, printInfos) {
        var items = [];
        printInfos.forEach(function (printInfo) {
            var objectId = Object.keys(printInfo)[0];
            printInfo[objectId].forEach(function (param) {
                items.push({
                    REPORT_CD: reportId,
                    OBJECT_CD: objectId,
                    PARA_CD: param.name,
                    PARA_TXT: param.value
                });
            });
        });

        dews.api.post(dews.url.getApiUrl("CM", "printService", "setPrintParam"), {
            async: false,
            data: {
                reportCode: reportId,
                items: JSON.stringify(items)
            }
        }).done(function (data) {
            if (!data) {
                return;
            }

            dews.app.print({ reportId: reportId, parameterKey: data });
        }).fail(function (error) {
            dews.error(error.responseJSON.message);
        });
    };

    /**
     * 자동인쇄 호출
     * @param {object} conditionPanel 조회조건
     * @param {object} grid 그리드
     * @param {string} title 출력물 명칭
     * @param {object} options 추가옵션
     * { nonVisibleColumns: {array} 출력할 때 숨길 컬럼명,
         orientation: {string} 프린트 용지방향 설정 (기본값: "portrait" / 설정가능값: "portrait"|"landscape"),
         headerText: {string} 머리글,
         footerText: {string} 바닥글,
         headerTextPosition: {number} 머리글 위치 (기본값: 1 / 설정가능값: 0(상단좌측) | 1(상단중앙) | 2(상단우측)),
         footerTextPosition: {number} 바닥글 위치 (생략가능 / 기본값: 1 / 설정가능값: 0(하단좌측) | 1(하단중앙) | 2(하단우측)) }
     */
    module.autoPrint = function (condition, grid, title, options) {
        if (!grid) {
            return;
        }

        var self = module.getPage();
        var n = "";
        if (title) {
            n = title;
        } else {
            n = "content_preview" === self.$content.prop("id") ? self.pageInfo.title : self.menu.name;
        }

        var i = JSON.stringify(condition ? condition._getParamsForPrint() : []), a = location.protocol + "//" + location.host;
        grid._getExcelUrlForPrint(n, null).done((function (o) {
            var s = [];
            if (options) {
                var nonVisibleColumns = options.nonVisibleColumns;
                var orientation = options.orientation;
                var headerText = options.headerText;
                var footerText = options.footerText;
                var headerTextPosition = options.headerTextPosition;
                var footerTextPosition = options.footerTextPosition;
            }

            if (grid.columns && existsArrayElement(nonVisibleColumns)) {
                for (var column in grid.columns) {
                    var findField = nonVisibleColumns.findIndex(function (fieldName) {
                        return column === fieldName;
                    });

                    if (findField > -1) {
                        s.push(grid.columns[column].title);
                    }
                }
            }

            var u = {
                IsUseTree: 0 !== grid.$element.parent(".dews-ui-grid").length ? "false" : "true",
                NonVisibleColumns: s.length > 0 ? s.toString() : "",
                LandScape: "landscape" === orientation ? "true" : "false",
                LeadText: headerText,
                TailText: footerText,
                LeadTextVisible: void 0 !== headerText ? "true" : "false",
                TailTextVisible: void 0 !== footerText ? "true" : "false",
                LeadTextPosition: void 0 !== headerTextPosition ? headerTextPosition.toString() : 1,
                TailTextPosition: void 0 !== footerTextPosition ? footerTextPosition.toString() : 1
            };

            dews.app.print("GERP://AUTO_DRF?title=" + encodeURIComponent(n) + "&condition=" + encodeURIComponent(i)
                + "&excel=" + encodeURIComponent(a) + encodeURIComponent(o) + "&options=" + encodeURIComponent(JSON.stringify(u))
                + "&authToken=" + getAccessToken() + "&MenuId=" + getPageId(self)
            );
        }));
    };

    /**
     * 파일 다운로드
     * @param {string} fileKey 파일키
     */
    module.downloadFile = function (fileKey) {
        if (!fileKey) {
            return;
        }

        dews.api.get("/auth/temporary/token", {
            header: getAccessToken()
        }).done(function (token) {
            var downloadIframe = createDownloadIframe(fileKey);
            downloadIframe.src = dews.string.format("/download/file?key={0}&token={1}", encodeURIComponent(fileKey), encodeURIComponent(token));
        }).fail(function (error) {
            dews.error(error.responseJSON.message);
        });
    };

    function createDownloadIframe(fileKey) {
        var self = module.getPage();
        var iframeId = getPageId(self) + (fileKey ? "_" + fileKey : "") + "_downloadIframe";

        var downloadIframe = document.getElementById(iframeId);
        if (downloadIframe) {
            return downloadIframe;
        }

        self.$content.append("<iframe id=\"" + iframeId + "\" style=\"display: none;\"></iframe>");
        return document.getElementById(iframeId);
    }

    /**
     * 숫자 포맷 변환
     * @param {number} value 변환 대상 값
     * @param {string} format 변환 포맷
     * @param {string} mathType 올림 구분(r 반올림 / c 올림 / f 내림)
     * @return {number} 변환 값
     */
    module.getNumberFormatValue = function (value, format, mathType) {
        try {
            return getFormatValue(value, format, mathType, false);
        } catch (error) {
            module.showErrorMessage(error);
        }
    };

    /**
     * 숫자 포맷 변환
     * @param {number} value 변환 대상 값
     * @param {string} format 변환 포맷
     * @param {string} mathType 올림 구분(r 반올림 / c 올림 / f 내림)
     * @return {string} 변환 값
     */
    module.getStringFormatValue = function (value, format, mathType) {
        try {
            return getFormatValue(value, format, mathType, true);
        } catch (error) {
            module.showErrorMessage(error);
        }
    };

    function getFormatValue(value, format, mathType, convert) {
        if (!module.isNumber(value)) {
            value = module.getNumber(value);
        }

        if (!value) {
            return 0;
        }

        var options = convertOptions(format, mathType);
        if (!options) {
            return value;
        }
        return getCalcValue(value, options.format, options.mathType, options.digit, convert);
    }

    function convertOptions(format, mathType) {
        if (!format) {
            return null;
        }

        var formatAndMathType = getFormatAndMathType(format, mathType);
        if (!formatAndMathType) {
            return null;
        }

        format = formatAndMathType.format;
        mathType = formatAndMathType.mathType;

        var point = format.split(".");
        var digit = 0;
        if (point.length == 2) {
            digit = point[1].length;
        }

        var newOptions = {
            format: format,
            mathType: mathType,
            digit: digit
        };
        return newOptions;
    }

    function getFormatAndMathType(format, mathType) {
        if (!format.startsWith("MA")) {
            return { format: format, mathType: mathType ? mathType.toLowerCase() : "f" };
        }

        var formatInfo = dews.ui.page.env[format];
        if (!formatInfo) {
            return null;
        }

        var seq = module.getNumber(format.substr(2, format.length - 2));
        if (seq == 7 || seq == 8) {
            return null;
        }

        format = formatInfo.format;
        if (!format) {
            return null;
        }

        return { format: format, mathType: dews.mathType[formatInfo.round].substr(0, 1) };
    }

    function getCalcValue(value, format, mathType, digit, convert) {
        if (mathType == "r") {
            return getConvertValue(module.getNumber(value.toFixed(digit)), format, convert);
        }

        if (mathType == "c") {
            if (digit > 0) {
                return getConvertValue(getMathTypeValue(value, mathType, digit), format, convert);
            }

            if (Number.isInteger(value)) {
                value += 0.1;
            }
            return getConvertValue(Math.ceil(value), format, convert);
        }

        if (mathType == "f") {
            if (digit > 0) {
                return getConvertValue(getMathTypeValue(value, mathType, digit), format, convert);
            }
            return getConvertValue(Math.floor(value), format, convert);
        }
        return getConvertValue(getMathTypeValue(value, "f", digit), format, convert);
    }

    function getMathTypeValue(value, mathType, digit) {
        digit = Math.pow(10, digit);

        if (mathType == "c") {
            return Math.ceil(value * digit) / digit;
        }
        return Math.floor(value * digit) / digit;
    }

    function getConvertValue(value, format, convert) {
        return convert ? dews.number.format(value, format) : value;
    }

    /**
     * 포맷 및 개인정보암호화 세팅
     * 주민등록번호, 사업자등록번호 포맷 지원
     * [개인정보마스킹기준설정], [개인정보마스킹설정] 메뉴에 설정된 데이터 기준
     * @author 이호현 선임연구원
     * @since  2020-08-26 최초개발
     * @example bsApi.getMaskingFormats(formatCode, masking, formatCharactor);
    */
    module.getMaskingFormat = function (formatCode, masking, formatCharactor) {
        try {
            formatCode = formatCode.toUpperCase();
            var mask = "";
            masking = typeof masking === "undefined" ? true : masking;
            if (!dews.ui.page || !dews.ui.page.env || !dews.ui.page.env.mask) {
                masking = false;
            }
            switch (formatCode) {
                case "RES_NO":
                    if (masking) {
                        mask = dews.string.secureMask("0000000000000", "RES_NO", true);
                        mask = mask.length >= 13 ? mask.substring(0, 6) + "-" + mask.substring(mask.length - 7) : mask;
                    } else {
                        mask = "000000-0000000";
                    }
                    break;
                case "BIZR_NO":
                    mask = "000-00-00000";
                    break;
            }
            if (formatCharactor && formatCharactor.length > 0) {
                mask = mask.replace(/0/g, formatCharactor);
            }
            return mask;
        } catch (error) {
            console.error(error);
            return "";
        }
    };

    module.chart = {
        /**
         * 크로스탭 그리드 데이터 기준 차트 바인딩
         * @param {object} chart 바인딩 대상 차트
         * @param {object} grid 그리드
         * @param {object} options 차트 바인딩에 관한 옵션 값들(removeCols, removeRows, unit, digit)
         */
        bindByGrid: function (chart, grid, options) {
            var data = getGridData(chart, grid);
            if (!data) {
                return;
            }

            var fields = copyGridColumns(grid.columns);
            var resultOptions = executeOptions(data, fields, options);

            var categoryField = chart.options.series[0].categoryField;
            var series = chart.options.series.map(function (series) {
                return series.field;
            });

            var chartData = createChartData(data, fields, series, categoryField, resultOptions);
            chart.setDataSource(createChartDataSource(chart, chartData, categoryField, resultOptions.fieldKeys));
            chart.redraw();
        },
        /**
         * 데이터 기준 차트 바인딩
         * @param {object} chart 바인딩 대상 차트
         * @param {object} data 바인딩 데이터
         * @param {object} options 차트 바인딩에 관한 옵션 값들(removeCols, removeRows, unit, digit)
         */
        bindByData: function (chart, data, options) {
            if (!chart) {
                return;
            }

            if (!data || data.length === 0) {
                chart.setDataSource(null);
                return;
            }

            var fields = Object.keys(data[0]);
            var resultOptions = executeOptions2(data, fields, options);

            var categoryField = chart.options.series[0].categoryField;
            var series = chart.options.series.map(function (series) {
                return series.field;
            });

            var chartData = createChartData2(data, fields, series, categoryField, resultOptions);
            chart.setDataSource(createChartDataSource(chart, chartData, categoryField, fields));
            chart.redraw();
        }
    };

    function getGridData(chart, grid) {
        if (!checkRequiredArgs(chart, grid)) {
            return null;
        }

        var gridData = grid.dataSource.data();
        if (!gridData || gridData.length === 0) {
            chart.setDataSource(null);
            return null;
        }
        return gridData;
    }

    function checkRequiredArgs(chart, grid) {
        if (!chart) {
            return false;
        }

        if (!grid) {
            chart.setDataSource(null);
            return false;
        }
        return true;
    }

    function copyGridColumns(columns) {
        columns = $.extend(true, {}, columns);
        if (columns.__UUID) {
            delete columns.__UUID;
        }

        return columns;
    }

    function executeOptions(data, fields, options) {
        var fieldKeys = null;
        var firstField = "";

        if (!options) {
            fieldKeys = Object.keys(fields);
            firstField = fieldKeys[0];
            return { fieldKeys: fieldKeys, firstField: firstField, round: false, unit: 1, digit: 0 };
        }

        var round = isBoolean(options.round) ? options.round : false;

        var unit = options.unit ? options.unit : 1;
        if (!module.isNumber(unit)) {
            unit = 1;
        }

        var digit = options.digit ? options.digit : 0;
        if (!module.isNumber(digit)) {
            digit = 0;
        }

        removeChartFields(fields, options.removeCols);

        fieldKeys = Object.keys(fields);
        firstField = fieldKeys[0];
        removeChartRows(data, options.removeRows, firstField);

        return { fieldKeys: fieldKeys, firstField: firstField, round: round, unit: unit, digit: digit };
    }

    function removeChartFields(fields, removeCols) {
        if (!existsArrayElement(removeCols)) {
            return;
        }

        $.each(removeCols, function (index, removeCol) {
            if (fields[removeCol]) {
                delete fields[removeCol];
            }
        });
    }

    function removeChartRows(data, removeRows, firstField) {
        if (!existsArrayElement(removeRows)) {
            return;
        }

        $.each(removeRows, function (index, removeRow) {
            var removeIndex = data.findIndex(function (row) {
                return row[firstField] == removeRow;
            });
            data.splice(removeIndex, 1);
        });
    }

    function createChartData(data, fields, series, categoryField, options) {
        var fieldKeys = options.fieldKeys;
        var firstField = options.firstField;

        var round = options.round;
        var unit = options.unit;
        var digit = options.digit;

        var chartData = createChartCategories(fields, fieldKeys, categoryField);
        for (var i = 0; i < series.length; i++) {
            var seriesField = series[i];
            var target = data.find(function (row) {
                return row[firstField] == seriesField;
            });

            if (!target) {
                continue;
            }

            for (var j = 1; j < fieldKeys.length; j++) {
                var value = target[fields[fieldKeys[j]].field] / unit;
                chartData[j - 1][seriesField] = round ? getCalcValue(value, null, "r", digit) : value;
            }
        }
        return chartData;
    }

    function createChartCategories(fields, fieldKeys, categoryField) {
        var charCategories = [];
        for (var i = 1; i < fieldKeys.length; i++) {
            var category = {};
            category[categoryField] = fields[fieldKeys[i]].title;
            charCategories.push(category);
        }
        return charCategories;
    }

    function executeOptions2(options) {
        if (!options) {
            return { round: false, unit: 1, digit: 0 };
        }

        var round = isBoolean(options.round) ? options.round : false;

        var unit = options.unit ? options.unit : 1;
        if (!module.isNumber(unit)) {
            unit = 1;
        }

        var digit = options.digit ? options.digit : 0;
        if (!module.isNumber(digit)) {
            digit = 0;
        }

        return { round: round, unit: unit, digit: digit };
    }

    function createChartData2(data, fields, series, categoryField, options) {
        var firstField = fields[0];
        var round = options.round;
        var unit = options.unit;
        var digit = options.digit;

        var chartData = createChartCategories2(fields, categoryField);
        for (var i = 0; i < series.length; i++) {
            var seriesField = series[i];
            var target = data.find(function (row) {
                return row[firstField] == seriesField;
            });

            if (!target) {
                continue;
            }

            for (var j = 1; j < fields.length; j++) {
                var value = target[fields[j]] / unit;
                chartData[j - 1][seriesField] = round ? getCalcValue(value, null, "r", digit) : value;
            }
        }
        return chartData;
    }

    function createChartCategories2(fields, categoryField) {
        var charCategories = [];
        for (var i = 1; i < fields.length; i++) {
            var category = {};
            category[categoryField] = fields[i];
            charCategories.push(category);
        }
        return charCategories;
    }

    function createChartDataSource(chart, data, id, fields) {
        return dews.ui.dataSource("dataSource" + chart._$element[0].getAttribute("id"), {
            data: data,
            schema: {
                model: {
                    id: id,
                    fields: [fields]
                }
            }
        });
    }

    function isBoolean(value) {
        return ($.type(value) === "boolean");
    }

    function isConnectIE() {
        return (navigator.appName == "Netscape" && navigator.userAgent.indexOf("Trident") != -1);
    }

    function setIEObjectPrototypeAndMethod() {
        if (!isConnectIE()) {
            return;
        }
        setArray();
        setString();
        setNumber();
    }

    function setArray() {
        if (!Array.prototype.find) {
            Object.defineProperty(Array.prototype, "find", {
                value: function (predicate) {
                    if (this == null) {
                        throw new TypeError("\"this\" is null or not defined");
                    }

                    var o = Object(this);
                    var len = o.length >>> 0;

                    if (typeof predicate !== "function") {
                        throw new TypeError("predicate must be a function");
                    }

                    var thisArg = arguments[1];
                    var k = 0;

                    while (k < len) {
                        var kValue = o[k];
                        if (predicate.call(thisArg, kValue, k, o)) {
                            return kValue;
                        }
                        k++;
                    }
                    return undefined;
                },
                configurable: true,
                writable: true
            });
        }

        if (!Array.prototype.findIndex) {
            Object.defineProperty(Array.prototype, "findIndex", {
                value: function (predicate) {
                    "use strict";
                    if (this == null) {
                        throw new TypeError("Array.prototype.findIndex called on null or undefined");
                    }
                    if (typeof predicate !== "function") {
                        throw new TypeError("predicate must be a function");
                    }
                    var list = Object(this);
                    var length = list.length >>> 0;
                    var thisArg = arguments[1];
                    var value;

                    for (var i = 0; i < length; i++) {
                        value = list[i];
                        if (predicate.call(thisArg, value, i, list)) {
                            return i;
                        }
                    }
                    return -1;
                },
                enumerable: false,
                configurable: false,
                writable: false
            });
        }

        if (!Array.from) {
            Array.from = (function () {
                var toStr = Object.prototype.toString;
                var isCallable = function (fn) {
                    return typeof fn === "function" || toStr.call(fn) === "[object Function]";
                };
                var toInteger = function (value) {
                    var number = Number(value);
                    if (isNaN(number)) { return 0; }
                    if (number === 0 || !isFinite(number)) { return number; }
                    return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
                };
                var maxSafeInteger = Math.pow(2, 53) - 1;
                var toLength = function (value) {
                    var len = toInteger(value);
                    return Math.min(Math.max(len, 0), maxSafeInteger);
                };

                return function from(arrayLike) {
                    var C = this;
                    var items = Object(arrayLike);

                    if (arrayLike == null) {
                        throw new TypeError("Array.from requires an array-like object - not null or undefined");
                    }

                    var mapFn = arguments.length > 1 ? arguments[1] : void undefined;
                    var T;
                    if (typeof mapFn !== "undefined") {
                        if (!isCallable(mapFn)) {
                            throw new TypeError("Array.from: when provided, the second argument must be a function");
                        }

                        if (arguments.length > 2) {
                            T = arguments[2];
                        }
                    }

                    var len = toLength(items.length);
                    var A = isCallable(C) ? Object(new C(len)) : new Array(len);
                    var k = 0;
                    var kValue;
                    while (k < len) {
                        kValue = items[k];
                        if (mapFn) {
                            A[k] = typeof T === "undefined" ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
                        } else {
                            A[k] = kValue;
                        }
                        k += 1;
                    }
                    A.length = len;
                    return A;
                };
            }());
        }

        if (!Array.prototype.includes) {
            Object.defineProperty(Array.prototype, "includes", {
                value: function (searchElement, fromIndex) {

                    if (this == null) {
                        throw new TypeError("\"this\" is null or not defined");
                    }

                    var o = Object(this);
                    var len = o.length >>> 0;

                    if (len === 0) {
                        return false;
                    }

                    var n = fromIndex | 0;
                    var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

                    function sameValueZero(x, y) {
                        return x === y || (typeof x === "number" && typeof y === "number" && isNaN(x) && isNaN(y));
                    }

                    while (k < len) {
                        if (sameValueZero(o[k], searchElement)) {
                            return true;
                        }
                        k++;
                    }
                    return false;
                }
            });
        }
    }

    function setString() {
        if (!String.prototype.repeat) {
            String.prototype.repeat = function (count) {
                "use strict";
                if (this == null) {
                    throw new TypeError("can\"t convert " + this + " to object");
                }
                var str = "" + this;
                count = +count;
                if (count != count) {
                    count = 0;
                }
                if (count < 0) {
                    throw new RangeError("repeat count must be non-negative");
                }
                if (count == Infinity) {
                    throw new RangeError("repeat count must be less than infinity");
                }
                count = Math.floor(count);
                if (str.length == 0 || count == 0) {
                    return "";
                }

                if (str.length * count >= 1 << 28) {
                    throw new RangeError("repeat count must not overflow maximum string size");
                }
                var maxCount = str.length * count;
                count = Math.floor(Math.log(count) / Math.log(2));
                while (count) {
                    str += str;
                    count--;
                }
                str += str.substring(0, maxCount - str.length);
                return str;
            }
        }

        let padLeft = function (targetLength, padString) {
            targetLength = targetLength >> 0;
            padString = String((typeof padString !== "undefined" ? padString : " "));
            if (this.length > targetLength) {
                return String(this);
            }
            else {
                targetLength = targetLength - this.length;
                if (targetLength > padString.length) {
                    padString += padString.repeat(targetLength / padString.length);
                }
                return padString.slice(0, targetLength) + String(this);
            }
        };
        if (!String.prototype.padLeft) {
            String.prototype.padLeft = padLeft;
        }
        if (!String.prototype.padStart) {
            String.prototype.padStart = padLeft;
        }

        let padRight = function (targetLength, padString) {
            targetLength = targetLength >> 0;
            padString = String((typeof padString !== "undefined" ? padString : " "));
            if (this.length > targetLength) {
                return String(this);
            }
            else {
                targetLength = targetLength - this.length;
                if (targetLength > padString.length) {
                    padString += padString.repeat(targetLength / padString.length);
                }
                return String(this) + padString.slice(0, targetLength);
            }
        };
        if (!String.prototype.padRight) {
            String.prototype.padRight = padRight;
        }
        if (!String.prototype.padEnd) {
            String.prototype.padEnd = padRight;
        }

        if (!String.prototype.includes) {
            String.prototype.includes = function (search, start) {
                "use strict";
                if (typeof start !== "number") {
                    start = 0;
                }

                if (start + search.length > this.length) {
                    return false;
                } else {
                    return this.indexOf(search, start) !== -1;
                }
            };
        }
    }

    function setNumber() {
        Number.isInteger = Number.isInteger || function (value) {
            return (typeof value === "number" && isFinite(value) && Math.floor(value) === value);
        };
    }

    function loadExcelCommonJS(isAsync) {
        if (!window.XLSX) {
            const path_xlsxJs = (dews._environments.scriptBase + "xlsx.js");
            console.debug("xlsx.js", dews.string.format("[ LOAD START :: {0} ]", path_xlsxJs));
            dews.ajax.script(path_xlsxJs, {
                once: true,
                async: isAsync
            }).done(function () {
                if (window.XLSX) {
                    XLSX = window.XLSX;
                    console.debug("xlsx.js", dews.string.format("[ LOAD COMPLETE :: version={0} ]", window.XLSX.version));
                }
            }).fail(function (xhr, status, error) {
                console.error("xlsx.js", "Common JS not found error");
            });
        }
    }


    /**
     * 오류 메시지를 팝업 메시지로 보여주고, 오류 로그를 찍는다.
     * @param {string | JSON} error
     */
    module.showErrorMessage = function (error) {
        var errMsg = "";
        var argsType = (typeof error);
        console.debug(dews.string.format("error type is {0}", argsType));
        switch (argsType) {
            default:
            case "object":
                if (module.isNotNull(error)) {
                    // 1. Request 오류에서 메시지 추출.
                    if (error.responseJSON && error.responseJSON.message) {
                        errMsg = error.responseJSON.message;
                    }
                    // 2. "ERR" 문자가 들어간 Key의 Value 추출.
                    if (!module.isNotNull(errMsg)) {
                        var keys = Object.keys(error);
                        for (var n = 0; !errMsg && n < keys.length; n++) {
                            var field = keys[n];
                            if (field.toUpperCase().indexOf("ERR") >= 0 && argsType[field] === "string") {
                                errMsg = error[field];
                                break;
                            }
                        }
                    }
                    if (!module.isNotNull(errMsg)) {
                        errMsg = dews.string.format("{0}", error);
                    }
                    break;
                }
            case "string":
                if (module.isNotNull(error)) {
                    errMsg = error;
                    break;
                }
            case "undefined":
                break;
        }
        if (!module.isNotNull(errMsg)) {
            // 에러가 지정되지 않은 경우는 스택을 찍어준다.
            Error.captureStackTrace(error = {});
            errMsg = dews.string.format("Undefined error." + "\n" + error.stack.split("\n").splice(2).join("\n"));
        }
        console.error(errMsg);
        dews.error(errMsg);
    };

    module.setGridDataSource = function (mapData, targetGrid, hiddenColumns, dsName) {
        // 데이터 소스 내에 데이터 초기화.
        var targetDataSource = targetGrid.dataSource;
        if (!targetDataSource) {
            targetDataSource = dews.ui.dataSource(dsName ? dsName : "dsTemp", {
                grid: true,
                schema: {
                    model: {
                        fields: [
                            { field: "CD", editable: false, dataType: "string" },
                            { field: "NM", editable: false, dataType: "string" },
                        ]
                    }
                },
                data: [
                    { CD: "CD1", NM: "NM1" },
                    { CD: "CD2", NM: "NM2" },
                    { CD: "CD3", NM: "NM3" },
                    { CD: "CD4", NM: "NM4" },
                ],
                error: function (e) {
                    dews.ui.loading.hide();
                    console.error(e);
                    dews.error(e);
                    // e.error 에러
                    // e.message 에러 메시지
                    // e.state 에러 상태 (ex) 400
                }
            });
        }
        targetDataSource.data([]);

        // Grid Column 초기화.
        var colArr = [];
        for (var idxCols1 = 0; idxCols1 < targetGrid.getColumns().length; idxCols1++) {
            colArr.push(targetGrid.getColumns()[idxCols1].field);
        }
        for (var idxCols2 = 0; idxCols2 < colArr.length; idxCols2++) {
            targetGrid.deleteColumn(colArr[idxCols2]);
        }

        // 데이터에서 Field 획득 및 dataSource 적용.
        if (mapData && mapData.length > 0) {
            // var hiddenColumns = ["TABLE_NAME", "IS_PK", "IS_UK", "COL_ID"];
            // const whoColumns = ["INSERT_ID", "INSERT_IP", "INSERT_MCADDR_NM", "INSERT_DTS", "UPDATE_ID", "UPDATE_IP", "UPDATE_MCADDR_NM", "UPDATE_DTS"];
            var fieldArr = [];
            var keys = Object.keys(mapData[0]); // 첫 행의 데이터로 컬럼명을 획득 함.
            // keys.forEach(function (field, n) {
            for (var n = 0; n < keys.length; n++) {
                var field = keys[n];
                if (fieldArr.indexOf(field) < 0) {
                    // fieldArr.push({ field: field, editable: false, dataType: "string", fieldName: field });
                    fieldArr.push({
                        field: field,
                        fieldName: field,
                        editable: false,
                        dataType: "string", //(field.startsWith("'") || field.endsWith("'")) ? field.substring(1, field.length - 2) : typeof (eval(dews.string.format("mapData[0].{0}", field))),
                        visible: hiddenColumns ? !hiddenColumns.includes(field) : true,
                    });
                }
                // });
            }
            targetDataSource.setFields(fieldArr);

            // Grid Column 추가.
            for (var idxCols3 = 0; idxCols3 < fieldArr.length; idxCols3++) {
                targetGrid.addColumn({
                    field: fieldArr[idxCols3].field,
                    title: fieldArr[idxCols3].field,
                    footer: {
                        type: "count",
                        suffix: " 건",
                        align: "right"
                    }
                });
                targetGrid.setColumn(fieldArr[idxCols3].fieldName, {
                    editable: false,
                    // formats: { type: "number", format: "##0.00" },
                    attributes: { class: fieldArr[idxCols3].fieldName == "COLUMN_NAME" ? "readonly" : "" },
                    visible: fieldArr[idxCols3].visible,
                    align: (fieldArr[idxCols3].dataType == "number" ? "right" : "left"),
                });
            }

            // 데이터 소스 반영.
            targetDataSource.data(mapData);
            targetGrid.setDataSource(targetDataSource);
            targetGrid.refresh();
        }
        return targetDataSource;
    }

    /**
     * 파일 선택창을 보여주고 선택 시 이벤트를 발생시킵니다.
     * 
     * @param {function} selected_callback : 파일 선택 시 발생시킬 콜백 이벤트
     * @param {string} acceptFormat : 파일 선택을 허용할 포맷
     */
    module.showFileSelector = function (selected_callback, acceptFormat) {
        if (!selected_callback || !$.isFunction(selected_callback)) {
            throw "파일 선택 콜백이벤트가 지정되지 않았습니다.";
        }
        var input = document.createElement("input");
        input.setAttribute("type", "file");
        if (module.isNotNull(acceptFormat)) {
            /* 엑셀 파일 예시 
            확장자 지정(.xlsx 또는 .xls): ".xlsx,.xls"
            MIME Type(.xlsx만): "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            MIME Type(.xlsx 또는 .xls): "application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            //*/

            /* 이미지파일 예시 
            확장자 지정(.jpg 또는 .jpeg 또는 .png) : ".jpg,.jpeg,.png"
            MIME Type(.jpg 또는 .jpeg 또는 .png): "image/jpeg,image/png"
            //*/
            input.setAttribute("accept", acceptFormat);
        }

        input.click();
        input.addEventListener("change", function (e) {
            selected_callback(e);
        });
    }

    /**
     * 배열(batchDatas)을 일정 개수(batchSize)로 나누어 처리(processBatch)하는 Promise 객체를 반환합니다.
     * 
     * @param {Array} batchDatas : 배치 처리할 데이터 배열
     * @param {function} processBatch : 배치처리 함수
     * @param {Number} batchSize : 배치로 나눌 데이터 수
     */
    module.DatasSplitBatchProcessing = function (batchDatas, processBatch, batchSize) {
        if (!batchDatas || batchDatas.length == 0) {
            throw "배치처리 할 데이터(batchDatas)가 존재하지 않습니다.";
        }
        if (!processBatch || !$.isFunction(processBatch)) {
            throw "배치처리 함수(processBatch)가 지정되지 않았습니다.";
        }

        if (!batchSize || batchSize < 0) batchSize = 100;
        const promises = [];
        do {
            let capa = (batchDatas.length > batchSize ? batchSize : batchDatas.length);
            const batchTargets = batchDatas.splice(0, capa);
            const promise = processBatch(batchTargets);
            promises.push(promise);
        }
        while (batchDatas && batchDatas.length > 0);


        // Promise.all을 사용하여 모든 처리가 완료될 때까지 기다립니다.
        return Promise.all(promises)
        /*
        .then(results => {
            // 각 처리 결과에 대한 메시지를 출력합니다.
            results.forEach((result, index) => {
                const start = index * batchSize + 1;
                const end = start + batchSize - 1;
                console.log(`Processed data from ${start} to ${end}:`, result);
            });
        })
        .catch(error => {
            console.error('Error occurred during processing:', error);
        })
        //*/
        ;
    }

    /*
    // Pager 관련 변수
    var totalPageCount = 1;
    var currentPage = 1;
    var beforePage, pager

    // 페이저 정보를 설정하는 함수
    module.initPager = function (pagerId) {
        // 페이지 수가 없다면, 1로 변경
        if (totalPageCount == 0) totalPageCount = 1;

        // 페이저가 존재할 경우 새로운 옵션으로 세팅
        if (pager) {
            if (totalPageCount == 0) totalPageCount = 1;
            var options = pager.getOptions();
            options.total = totalPageCount;
            pager.setOptions(options);
        }
        // 존재하지 않는다면 새로운 페이저 생성
        else {
            pager = dews.ui.simplepager("#" + pagerId, {
                total: totalPageCount,
                buttonCount: 10
            });
        }

        // 머무르고 있는 페이지가 최대 페이지 수보다 크다면 최대 페이지로 이동
        if (pager.getPage() > totalPageCount) {
            pager.setPage(totalPageCount);
        }

        // 검색어가 존재한다면 페이저의 포커스를 1페이지로 이동
        if (self.cicdPjtNm.text().trim() != "") {
            pager.setPage(1);
        }

        // 페이저가 변경될 때 발생하는 이벤트
        pager.on('change', function (e) {
            // 이전 페이지 값을 보관
            beforePage = currentPage;
            // 새로운 페이지 값 갱신
            currentPage = pager.getPage();
            // 페이지에 변화가 있을 때만 정보 조회
            if (beforePage != currentPage) {
                readProject();
            }
        });

        return pager;
    }
    //*/

    /*********************************************************************************************
    *  @desc  js파일 상속
    *  @param {Object} targetJS [필수] js 객체 변수
    *  @ex
    * ------------------------------------------------------------------------------------------*/
    module.extendJS = function (targetJS) {
        $.each(Object.keys(targetJS), function (idx, key) {
            var keyArr = module[key] ? Object.keys(module[key]) : [];
            /* 겹치는 메소드가 있는지 확인,
               겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
            $.each(Object.keys(targetJS[key]), function (idx, kName) {
                if (keyArr.indexOf(kName) >= 0) {
                    console.error("js 상속 중 동일한 메소드 명이 존재합니다 - ", (key + '.' + kName));
                }
            });
            module[key] = $.extend({}, module[key], targetJS[key]);
        });
    }
    /**********************************************************************************************/

    var newModule = {};
    newModule[moduleCode] = module;
    window.gerp = $.extend(true, gerp, newModule);

    console.debug("cm.bscm.js", dews.string.format("[ LOAD COMPLETE :: version={0} ]", version));

})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/view/js/CM/cm.bscm.js