(function (dews, gerp, $) {
  var module = {};
  var moduleCode = "CM";
  var version = "1.0.220607.02";

  console.debug("cm.util.x10005.js", dews.string.format("[ LOAD START :: version={0} ]", version));

  var DateEnum = {
    DATE: 1,   //일
    MONTH: 2,  //월
    YEAR: 3,   //년
    HOUR: 4,   //시
    MINUTE: 5, //분
    SECOND: 6, //초
    LAST_DAY_OF_MONTH: 7,  //월 마지막 일
    WEEK_OF_MONTH: 8,      //월의 주
    WEEK_OF_YEAR: 9,       //년의 주
    DAY_OF_WEEK: 10        //요일
  };
  var MessageEnum = {
    SEARCH_AGAIN_CONFIRM: "저장하지 않은 데이터가 있습니다.\n조회를 계속하시겠습니까?",  //재조회 확인 메세지
    CLOSE_CONFIRM: "저장하지 않은 데이터가 있습니다.\n닫기를 계속하시겠습니까?",         //종료 확인 메세지
    SAVE_CONFIRM: "저장하시겠습니까?",                                                   //저장 확인 메세지
    SAVE_DONE_ALERT: "저장이 완료되었습니다.",                                           //저장 완료 메세지
    SAVE_NO_DATA_ALERT: "저장할 데이터가 없습니다.",                                     //저장할 데이터 없는 메세지
    SAVE_VALID_ALERT: "필수항목을 입력하지 않았습니다.",                                 //저장 필수값 메세지
    DELETE_CONFIRM: "삭제 하시겠습니까?\n(반드시 저장을 하셔야 반영이 됩니다.)",         //삭제 확인 메세지(화면상에서 삭제)
    DELETE_IMME_CONFIRM: "삭제 하시겠습니까?",                                           //삭제 확인 메세지(DB 삭제)
    DELETE_DONE_ALERT: "삭제 되었습니다.",                                               //삭제 완료 메세지
    SEARCH_LOADING: "조회하는 중입니다.",                                                //조회 로딩 메세지
    SAVE_LOADING: "저장하는 중입니다.",                                                  //저장 로딩 메세지
    DELETE_LOADING: "삭제하는 중입니다."                                                 //삭제 로딩 메세지
  }
  var NotiTemplateEnum = {
    A: 10258,	//자금이체(배치)
    B: 10259,	//자금이체(실시간)
    C: 10260,	//자금만기
    D: 10261,	//채권회수모니터링
    E: 10262,	//신규법률집행접수 안내
    F: 10263		//법률집행해제 안내
  }

  var bsApi;
  dews.ajax.script("/view/js/CM/cm.bscm.js", {
    once: true,
    async: false
  }).done(function () {
    bsApi = gerp.CM;
  }).fail(function (xhr, status, error) {
    console.error("cm.bscm.js", "Common API Service not found");
  });

  var eltrAthzUtil;
  dews.ajax.script("/view/js/HR/hr.gw.util.js", {
    once: true,
    async: false
  }).done(function () {
    eltrAthzUtil = gerp.CM.EltrAthzUtil;
  }).fail(function (xhr, status, error) {
    console.error("hr.gw.util.js", "Common API Service not found");
  });

  module.StringUtil = {
    /**
     * @section Description
     * @details 입력 받은 padChar 문자를 문자열 sourceString의 왼쪽에 문자열 길이가 totalLength 만큼 되도록 문자를 덧댄다.
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param String sourceString 입력 문자열
     * @param String padChar 덧댈 문자
     * @param Number totalLength 문자열 전체 길이
     * - @return String 변환 문자열
     * @example var dateString = stringUtil.padLeft("abcd", "*", 6);
     */
    padLeft: function (sourceString, padChar, totalLength) {
      if (typeof sourceString != "string") {
        sourceString = sourceString + "";
      }
      var padding = "";
      for (var i = 0; i < totalLength; i++) {
        padding += padChar;
      }
      return padding.substring(sourceString.length) + "" + sourceString;
    }
  }

  module.ConvertUtil = {
    Date: {
      DateEnum: DateEnum,
      /**
       * @section Description
       * @details Date 타입을 입력 받아 "yyyyMMdd" 포맷의 문자열로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param Date sourceDate 입력 날짜
       * - @return String 변환 문자열
       * @example var dateString = convertUtil.Date.toString(new Date());
       */
      toString: function (sourceDate) {
        var year = module.DateUtil.get(sourceDate, this.DateEnum.YEAR),
          month = module.DateUtil.get(sourceDate, this.DateEnum.MONTH),
          date = module.DateUtil.get(sourceDate, this.DateEnum.DATE);
        return year + module.StringUtil.padLeft(month, "0", 2) + module.StringUtil.padLeft(date, "0", 2);
      }
    },
    String: {
      /**
       * @section Description
       * @details String타입을 입력 받아 정수형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return Number 변환 값
       * @example var intValue = convertUtil.String.toInteger("123");
       */
      toInteger: function (sourceValue) {
        return parseInt(sourceValue);
      },
      /**
       * @section Description
       * @details String타입을 입력 받아 실수형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return  변환 값
       * @example var doubleValue = convertUtil.String.toDouble("123.123");
       */
      toDouble: function (sourceValue) {
        return parseFloat(sourceValue);
      },
      /**
       * @section Description
       * @details yyyyMMdd 포맷의 String 타입을 입력 받아 Date 형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return Date 변환 값
       * @example var dateValue = convertUtil.String.toDate("20181012");
       */
      toDate: function (sourceValue) {
        if (sourceValue.length == 8) {
          return new Date(sourceValue.substring(0, 4) + "/" + sourceValue.substring(4, 6) + "/" + sourceValue.substring(6, 8));
        } else {
          return undefined;
        }
      },
      /**
       * @section Description
       * @details 숫자를 입력받아, 3자리 마다 "," 찍은 금액 문자열 반환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 값
       * - @return String 변환 값
       * @example var dateValue = convertUtil.String.toAmount("123123");
       */
      toAmount: function (sourceValue) {
        if (isNaN(sourceValue)) {
          console.log("ConvertUtil toAmount Call : sourceValue is not Number Type");
          return undefined
        } else {
          return sourceValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
      }
    },
    Array: {
      /**
       * @section Description
       * @details Array 형 데이터를 입력 받아 JSON 문자열로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 배열
       * - @return String 변환 문자열
       * @example var stringValue = convertUtil.Array.toJsonString([1, 2, 3]);
       */
      toJsonString: function (sourceValue) {
        return JSON.stringify(sourceValue);
      },
      /**
       * @section Description
       * @details Array 형 데이터를 입력 받아 구분자를 "|" 문자로 하는 문자열 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 배열
       * - @return String 변환 문자열
       * @example var stringValue = convertUtil.Array.toPipeString([1, 2, 3]);
       */
      toPipeString: function (sourceValue) {
        return sourceValue.join("|");
      }
    }
  }

  module.DateUtil = {
    DateEnum: DateEnum,
    /**
     * @section Description
     * @details Date 형 데이터와 날짜 필드(정수형)를 입력 받아 날짜 필드 반환
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.get(new Date(), dateUtil.DateEnum.DATE);
     */
    get: function (sourceDate, dateEnum) {
      var returnValue = undefined;
      if (!sourceDate instanceof Date) {
        console.log("DateUtil get Call : sourceDate is not Date Object Type");
      } else if (!dateEnum instanceof Number) {
        console.log("DateUtil get Call : dateEnum is not DateEnum Type");
      } else {
        switch (dateEnum) {
          case this.DateEnum.DATE:
            returnValue = sourceDate.getDate();
            break;
          case this.DateEnum.MONTH:
            returnValue = sourceDate.getMonth() + 1;
            break;
          case this.DateEnum.YEAR:
            returnValue = sourceDate.getFullYear();
            break;
          case this.DateEnum.HOUR:
            returnValue = sourceDate.getHours();
            break;
          case this.DateEnum.MINUTE:
            returnValue = sourceDate.getMinutes();
            break;
          case this.DateEnum.SECOND:
            returnValue = sourceDate.getSeconds();
            break;
          case this.DateEnum.LAST_DAY_OF_MONTH:
            var year = this.get(sourceDate, this.DateEnum.YEAR);
            var month = this.get(sourceDate, this.DateEnum.MONTH);
            returnValue = (new Date(year, month, 0)).getDate();
            break;
          case this.DateEnum.DAY_OF_WEEK:
            returnValue = sourceDate.getDay();
            break;
          case this.DateEnum.WEEK_OF_MONTH:
            var date = this.get(sourceDate, this.DateEnum.DATE);
            var day = this.get(sourceDate, this.DateEnum.DAY_OF_WEEK);
            returnValue = parseInt((6 + date - day) / 7) + 1;
            break;
          case this.DateEnum.WEEK_OF_YEAR:
            var year = this.get(sourceDate, this.DateEnum.YEAR);
            var month = this.get(sourceDate, this.DateEnum.MONTH);

            var totalWeek = 0;
            for (var i = month - 1; i > 0; i--) {
              totalWeek += this.get(new Date(year, month, 0), this.DateEnum.WEEK_OF_MONTH);
            }
            totalWeek += this.get(sourceDate, this.WEEK_OF_MONTH);
            returnValue = totalWeek;
            break;
          default:
            console.log("DateUtil get Call : dateEnum is invalid");
            break;
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터와 날짜 필드(정수형), 증가 값을 입력 받아, 입력 날짜의 날짜 필드를 증가 값 만큼 더한 날짜 데이터 반환
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * @param Number value 증가 값
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.add(new Date(), dateUtil.DateEnum.DATE, 2);
     */
    add: function (sourceDate, dateEnum, value) {
      var returnValue = undefined;
      if (!sourceDate instanceof Date) {
        console.log("DateUtil add Call : sourceDate is not Date Object Type");
      } else if (!dateEnum instanceof Number) {
        console.log("DateUtil add Call : dateEnum is not DateEnum Type");
      } else if (!value instanceof Number) {
        console.log("DateUtil add Call : value is not Number Type");
      } else {
        switch (dateEnum) {
          case this.DateEnum.DATE:
            returnValue = new Date(sourceDate.setDate(sourceDate.getDate() + value));
            break;
          case this.DateEnum.MONTH:
            returnValue = new Date(sourceDate.setMonth(sourceDate.getMonth() + value));
            break;
          case this.DateEnum.YEAR:
            returnValue = new Date(sourceDate.setFullYear(sourceDate.getFullYear() + value));
            break;
          case this.DateEnum.HOUR:
            returnValue = new Date(sourceDate.setHours(sourceDate.getHours() + value));
            break;
          case this.DateEnum.MINUTE:
            returnValue = new Date(sourceDate.setMinutes(sourceDate.getMinutes() + value));
            break;
          case this.DateEnum.SECOND:
            returnValue = new Date(sourceDate.setSeconds(sourceDate.getSeconds() + value));
            break;
          default:
            console.log("DateUtil get Call : dateEnum is invalid");
            break;
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터를 2개와 날짜 필드(정수형)을 입력 받아, 해당 날짜 필드에 대해 두 날짜의 차이 값을 반환
     * @details sourceDate2 - sourceDate1
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate1 입력 날짜
     * @param Date sourceDate2 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.differenceBetween(new Date(2018, 9, 1), new Date(), dateUtil.DateEnum.DATE);
     */
    differenceBetween: function (sourceDate1, sourceDate2, dateEnum) {
      var returnValue = undefined;
      if (!sourceDate1 instanceof Date) {
        console.log("DateUtil differenceBetween Call : sourceDate1 is not Date Object Type");
      } else if (!sourceDate2 instanceof Date) {
        console.log("DateUtil differenceBetween Call : sourceDate2 is not Date Object Type");
      } else if (!dateEnum instanceof Number) {
        console.log("DateUtil get Call : dateEnum is not DateEnum Type");
      } else {
        switch (dateEnum) {
          case this.DateEnum.DATE:
          case this.DateEnum.MONTH:
          case this.DateEnum.YEAR:
          case this.DateEnum.HOUR:
          case this.DateEnum.MINUTE:
          case this.DateEnum.SECOND:
            var val1 = this.get(sourceDate1, dateEnum);
            var val2 = this.get(sourceDate2, dateEnum);
            returnValue = val2 - val1;
            break;
          default:
            console.log("DateUtil differenceBetween Call : dateEnum is invalid");
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터를 2개와 날짜 필드(정수형)을 입력 받아, 크기 비교
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate1 입력 날짜
     * @param Date sourceDate2 입력 날짜
     * - @return Number 반환 값(if sourceDate1 > sourceDate2 than return 1, else if sourceDate1 == sourceDate2 than return 0, else if sourceDate1 < sourceDate2 than return -1)
     * @example var compareValue = dateUtil.compareWith(new Date(2018, 9, 1), new Date());
     */
    compareWith: function (sourceDate1, sourceDate2) {
      var returnValue = undefined;
      if (!sourceDate1 instanceof Date) {
        console.log("DateUtil compareWith Call : sourceDate1 is not Date Object Type");
      } else if (!sourceDate2 instanceof Date) {
        console.log("DateUtil compareWith Call : sourceDate2 is not Date Object Type");
      } else {
        if (sourceDate1.getTime() == sourceDate2.getTime()) {
          returnValue = 0;
        } else if (sourceDate1.getTime() > sourceDate2.getTime()) {
          returnValue = 1;
        } else {
          returnValue = -1;
        }
      }
      return returnValue;
    }
  };

  module.ExcelUtil = {
    /**
     * @section Description
     * @details fileButton에서 선택한 파일과 처리할 API URL, 서버단 처리 완료시 작업할 CallBack 함수를 정의하여 선택한 엑셀파일 서버로 전송
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Object e 파일 탐색기에서 선택한 파일 객체
     * @param String url 업로드 처리할 서버 API URL
     * @param function callback 업로드 처리 이후 동작 로직
     * @example  excelUtil.upload(e, dews.url.getApiUrl("FI", "SampleService", "sample00700_list_excel_upload"), function(data){
     *             self.gridDataSource.data(data);
     *             self.grid.setDatSource(gridDataSource);
     *           })
     */
    upload: function (e, url, callback, apiParams) {
      var formData = new FormData();
      formData.append("file", e.target.files[0]);
      formData.append("isText", "false");
      formData.append("token", JSON.parse(dews.ui.page.token).access_token);

      var xhr = new XMLHttpRequest();
      xhr.open("POST", "/upload/file", true);

      var completeHandler = function (e) {
        var fileData = {};
        if (this.status === 200) {
          var data = JSON.parse(this.responseText);

          if (data.success === "true") {
            data = data.data;
            fileData.NEW_FILE_DC = data.newFilename;
            fileData.ORGL_FILE_DC = data.originalFilename;
            fileData.ORGL_FEXTSN_DC = data.originalExtension;
            fileData.FILE_VR = parseInt(data.fileSize, 10);

            newParams = {
              fileModel: JSON.stringify(fileData)
            };

            if (apiParams != undefined) {
              $.each(Object.keys(apiParams), function (idx, data) {
                newParams[data] = apiParams[data];
              });
            }
            dews.api.post(url, {
              async: false,
              data: newParams
            }).done(function (data) {
              callback(data);
            }).fail(function (xhr, status, error) {
              var err = {
                xhr: xhr,
                status: status,
                error: error
              };
              callback(err);
            });
          }
        }
      };

      xhr.addEventListener("load", completeHandler);
      xhr.send(formData);
    },
    /**
     * @section Description
     * @details 서버에서 작성된 Excel 파일을 다운
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Object data 서버에서 작성한 Excel 파일. DzDownloadModel
     * @example
     *  dews.api.get(dews.url.getApiUrl("FI", "SampleService", "sample00800_excel_download"), {
     *    async : false
     *  }).done(function(data){
     *    excelUtil.download(data);
     *  });
     */
    download: function (data) {
      var fileData = new Blob([new Uint8Array(data.file)], { type: data.contentType });
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(fileData, data.fileName);
      } else {
        var anchorTag = window.document.createElement("a");
        anchorTag.href = window.URL.createObjectURL(fileData);
        anchorTag.download = data.fileName;
        document.body.appendChild(anchorTag);
        anchorTag.click();
        document.body.removeChild(anchorTag);
      }
    }
  }

  module.GridUtil = {
    validateDetailGrid: function (masterGrid, detailGrid) {
      var mDs = masterGrid.dataSource;
      var dDs = mDs.options.detailDataSource;

      var detailData = dDs.getDirtyData();
      var addArr = detailData.Added;
      var upArr = detailData.Updated;

      // 1. 필수컬럼 필드명 가져오기
      var colArr = [];
      $.each(detailGrid.columns, function (idx, item) {
        if (item.attributes != undefined) {
          if (item.attributes.class == "required") {
            colArr.push(item.field);
          }
        }
      });

      if (colArr.length <= 0) {
        return true;
      }

      var detailUid = undefined;
      var nullColumn = undefined;

      $.each(addArr, function (idx, item) {
        for (var i = 0; i < colArr.length; i++) {
          if (item[colArr[i]] == undefined || item[colArr[i]] == null) {
            detailUid = item._huid;
            nullColumn = colArr[i];
            return false;
          }
        }
      });

      if (detailUid == undefined) {
        $.each(upArr, function (idx, item) {
          for (var i = 0; i < colArr.length; i++) {
            if (item[colArr[i]] == undefined || item[colArr[i]] == null) {
              detailUid = item._huid;
              nullColumn = colArr[i];
              return false;
            }
          }
        });
      }

      if (detailUid != undefined) {
        var targetIdx = undefined;
        $.each(mDs.data(), function (idx, item) {
          if (item["_uid"] == detailUid) {
            targetIdx = idx;
            return false;
          }
        });

        if (targetIdx != undefined) {
          masterGrid.select(targetIdx);
          return false;
        }
      }
      return true;
    },

    // 	grid fixed 변경 시 사용 (grid._grid.setFixedOptions()사용으로 필요없음)
    //		setTempData : function(grid, callback)
    //		{
    //			//	data
    //			var tempData = grid.options.dataSource.data();
    //
    //			//	로우 상태
    //			var rowState = grid.dataSource.dataProvider._dp._rowStates;
    //			var newState = new Array();
    //
    //			$.extend(newState, rowState);
    //
    //			//	컬럼 정보
    //			var columns	= new Array();
    //
    //			$.extend(columns, grid.options.columns);
    //
    //			if (typeof(callback) == "function") callback(tempData, newState, columns);
    //		},
    // 	grid column visible - 이벤트
    setGridColumnVisible: function (grid, columns, visible) {
      if (visible) {
        for (var i = 0; i < columns.length; i++) {
          grid.showColumn(columns[i]);
        }
      }
      else if (!visible) {
        for (var i = 0; i < columns.length; i++) {
          grid.hideColumn(columns[i]);
        }
      }
    },
    // 그리드에 context메뉴 정의 - 틀고정
    setGridContextMenuFixed: function (grid) {
      grid.setContextMenu([
        {
          id: "fixed",
          text: "틀고정 변경",
          handler: function (e) {
            // 셀데이타 : e.cell.data, 행데이타 : e.row.data, 필드명 : e.cell.field
            var selColIdx = e.grid._grid.columnByField(e.cell.field).displayIndex;

            //						if (e.grid._grid._gv._focusedIndex._column.parent().displayIndex() == -1 )
            //						{
            //							selColIdx = e.grid._grid._gv._focusedIndex._column.displayIndex();
            //						}
            //						else
            //						{
            //							selColIdx = e.grid._grid._gv._focusedIndex._column.parent().displayIndex()
            //						}

            module.GridUtil.changeGridFixed(e.grid, selColIdx + 1);
          },
          display: function (e) {
            return true;
          }
        },
        {
          id: "fixedCancel",
          text: "틀고정 제거",
          handler: function (e) {
            module.GridUtil.removeGridFixed(e.grid);
          },
          display: function (e) {
            return e.grid._grid.getFixedOptions().colCount > 0;
          }
        }
      ]);
    },
		/*****************************************************
		* created by  : 최정훈
		* method      :	changeGridFixed
		* description :	그리드 Fixed Index 변경
		* parameters  :	grid		= 그리드
		* parameters  :	idx			= 변경할 index
		* parameters  :	callback	= callback function
		*****************************************************/
    changeGridFixed: function (grid, idx, callback) {
      if (grid == null || idx < 0) return false;

      grid._grid.setFixedOptions({ colCount: idx });

      //			var gridOptions = {fixed : {colBarWidth : 1, colCount : idx, rightColCount : 0}};

      //			module.GridUtil.setTempData(grid, function(data, newState, columns) {
      //				grid.setOptions(gridOptions);
      //				grid.setColumns(columns);
      //				grid.options.dataSource.data(data);
      //				grid.dataSource.dataProvider._dp._rowStates = newState;
      //			});

      if (callback != null && typeof (callback) == "function") callback();
    },
		/*****************************************************
		* created by  : 최정훈
		* method      :	removeGridFixed
		* description :	그리드 Fixed 제거
		* parameters  :	grid		= 그리드
		* parameters  :	callback	= callback function
		*****************************************************/
    removeGridFixed: function (grid, callback) {
      if (grid == null || grid.options.fixed.colCount == null) return false;

      grid._grid.setFixedOptions({ colCount: 0 });

      //			var gridOptions = {fixed : {colBarWidth : 0, colCount : 0, rightColCount : 0}};

      //			module.GridUtil.setTempData(grid, function(data, newState, columns) {
      //				grid.setOptions(gridOptions);
      //				grid.setColumns(columns);
      //				grid.options.dataSource.data(data);
      //				grid.dataSource.dataProvider._dp._rowStates = newState;
      //			});

      if (callback != null && typeof (callback) == "function") callback();
    },
		/*****************************************************
		* created by  : 최정훈
		* method      :	getGridFixedIndex
		* description :	그리드 Fixed Index 구하기
		* parameters  :	grid = 그리드
		*****************************************************/
    getGridFixedIndex: function (grid) {
      if (grid == null || grid._grid.getFixedOptions() == null || grid._grid.getFixedOptions().colCount == null) return 0;

      return grid._grid.getFixedOptions().colCount;
    },
		/*****************************************************
		* created by  : 이창훈
		* method      :	마스터 & 디테일 구조 2그리드 validation
		* description :	2그리드 이상은 안됨
		* parameters  :	mstGrid 		> mst 그리드
		* parameters  :	dtlGrid 		> dtl 그리드
		*****************************************************/
    validationDtlGrid: function (mstGrid, dtlGrid) {
      var mstItems = mstGrid.sortDataItems();
      var dsDetail = mstGrid.dataSource.options.detailDataSource;
      var dtlItems = dsDetail.getDirtyData().Added.concat(dsDetail.getDirtyData().Updated);

      //	컬럼 집계
      var colArr = [];

      $.each(dtlGrid.columns, function (idx, item) {
        if (item.attributes != undefined) {
          if (item.attributes.class == "required") {
            colArr.push(item.field);
          }
        }
      });

      //	null값 체크
      var validationData = { result: true };

      if (colArr.length > 0 && dtlItems.length > 0) {
        a: for (var x = 0; x < dtlItems.length; x++) {
          var row = dtlItems[x];

          b: for (var xx = 0; xx < colArr.length; xx++) {
            var colnm = colArr[xx];
            var value = row[colnm];

            if (module.util.isNull(value)) {
              validationData.column = colnm;
              validationData.result = false;
              validationData._huid = row["_huid"];

              break a;
            }
          }
        }
      }

      //	Grid row selection
      if (validationData.result == false) {
        //	mst grid selection
        for (var x = 0; x < mstItems.length; x++) {
          var mstRow = mstItems[x];

          if (mstRow["_uid"] == validationData["_huid"]) {
            mstGrid.select(x);
            validationData.masterRowIndex = x;

            break;
          }
        }

        //	dtl grid selection
        for (var x = 0; x < dtlGrid.dataItems().length; x++) {
          var dtlRow = dtlGrid.dataItem(x);

          if (module.util.isNull(dtlRow[validationData.column])) {
            dtlGrid.setFocus();
            dtlGrid.select(x, validationData.column);
            validationData.detailRowIndex = x;

            break;
          }
        }
      }

      return validationData;
    }
  }

  module.MessageUtil = MessageEnum;

  module.util = {
    /*취소 경고창 handler */
    cancelAlert: false,
		/*****************************************************
		* created by  : 이창훈
		* method      :	null value 체크
		* description :	입력받은 값이 빈값인지 체크
		* parameters  :	value > 체크대상 입력값
		*****************************************************/
    isNull: function (value) {
      //	undefined || null  = null
      if (value == undefined || value == null) return true;

      //	문자열 빈값 = null
      if (typeof value == "string" && value == "") return true;

      //	Object type( Array,Object)
      if (typeof value == "object") {
        if (value.constructor == Object)	// 변수 = 객체인경우 요소 여부만 체크
        {
          var keys = Object.keys(value);

          if (keys.length == 0) return true;
        }
        else if (value.constructor == Array)	// 변수 = 배열인경우 배열 갯수 체크
        {
          if (value.length == 0) return true;
        }
      }

      return false;
    },
		/*****************************************************
		* created by  : 이창훈
		* method      :	곱하기
		* description :	입력받은 두 수의 곱 리턴
						입력받은 두 수중 소수점이 존재할 경우 float 계산
		* parameters  :	dAmt 		> 좌변 숫자
		* parameters  :	cAmt 		> 우변 숫자
		* parameters  :	decimal > 소수점 자리수(float 계산시 소수점 / default 4)
		*****************************************************/
    multiply: function (dAmt, cAmt, decimal) {
      if (this.isNull(dAmt) || parseFloat(dAmt) == NaN) dAmt = 0;
      if (this.isNull(cAmt) || parseFloat(cAmt) == NaN) cAmt = 0;
      if (this.isNull(decimal) || parseFloat(decimal) == NaN) decimal = 4;

      var result = 0;
      var float = false;

      var dAmts = dAmt.toString().split(".");

      // 좌변 숫자 체크
      if (dAmts.legnth > 2)		//  소수점이 2개이상이면 잘못된 값으로 0처리 함
        dAmt = 0;
      else if (dAmts.legnth == 2)	//  소수점인지 체크
        float = true;

      var cAmts = cAmt.toString().split(".");

      // 우변 숫자 체크
      if (cAmts.legnth > 2)		//  소수점이 2개이상이면 잘못된 값으로 0처리 함
        cAmt = 0;
      else if (cAmts.legnth == 2)	//  소수점인지 체크
        float = true;

      if (float) {
        result = parseFloat(dAmt * cAmt).toFixed(decimal);
      }
      else {
        result = dAmt * cAmt;
      }

      return result;
    },
		/*****************************************************
		* created by  : 이창훈
		* method      :	로딩바 출력
		* description :	로딩바 출력
		* parameters  :	option 		> 로딩바 출력시 출력 옵션
		* parameters  :	callback 	> 로딩바 출력후 실행 함수
		* parameters  :	params	 	> 함수 실행시 전달 인수
		*****************************************************/
    showLoding: function (option, callback, params) {
      //	option(dews API 기준) 예
      //	{type: "tiny",	text: "내용을 더 불러오고 있습니다."  }
      //	{type: "full",	text: "화면 로딩중입니다." }
      //	{target: "#loadingtestdiv1"	}
      if (this.isNull(option))
        option = { text: module.message("1000") };
      else
        option = { text: option.text };
      //option	=	{type: "tiny",	text: module.message("1000") };

      dews.ui.loading.show(option);

      setTimeout(function () {
        if (typeof (callback) == "function") callback(params);
      }, 100);
    }
  };

	/*****************************************************
	* created by  : 이창훈
	* method      :	공통메세지 관리 함수
	* description :	메세지 리턴
	* parameters  :	type 		> 호출유형
	*****************************************************/
  module.message = function (type) {
    var msg;
    switch (type) {
      case "1000": msg = "조회하는 중입니다."; break;
      case "2000": msg = "저장하는 중입니다."; break;
      case "2001": msg = "저장하시겠습니까?"; break;
      case "2002": msg = "저장이 완료되었습니다."; break;
      case "3000": msg = "삭제하는 중입니다."; break;
      case "3001": msg = "삭제하시겠습니까?"; break;
      case "3002": msg = "삭제할 데이터가 없습니다."; break;
      case "3003": msg = "\n(반드시 저장을 하셔야 반영이 됩니다.)"; break;
      case "4000": msg = "필수입력항목"; break;
      case "4001": msg = "변경된 데이터가 없습니다."; break;
      case "4002": msg = "상세내역에 필수항목을 입력하지 않았습니다."; break;
      case "4003": msg = "필수항목을 입력하지 않았습니다."; break;
      case "4004": msg = "상세내역이 등록된 데이터는 삭제 할 수 없습니다."; break;
      case "5000": msg = "취소되었습니다."; break;
      case "6000": msg = "저장하지 않은 데이터가 있습니다.\n닫기를 계속하시겠습니까?"; break;
      case "6001": msg = "저장하지 않은 데이터가 있습니다.\n조회를 계속하시겠습니까?"; break;
      case "7000": msg = "전표처리 하시겠습니까?"; break;
      case "7001": msg = "전표생성하는 중입니다."; break;
      case "7002": msg = "전표데이터가 생성되지 않았습니다."; break;
      case "7003": msg = "전표저장하는 중입니다."; break;
      case "7004": msg = "전표처리 되었습니다."; break;
      case "7005": msg = "전표취소 하시겠습니까?"; break;
      case "7006": msg = "전표취소 되었습니다."; break;
      case "7007": msg = "전표처리되지 않은 데이터 입니다."; break;
      case "7008": msg = "이미 처리된 데이터 입니다."; break;
      case "7009": msg = "전표취소하는 중입니다."; break;
      case "8000": msg = "선택된 데이터가 없습니다."; break;
      default: msg = "잘못 입력된 유형 코드 입니다."; break;
    }
    return msg;
  }

  /**
   * 동서발전 트리그리드 UI
   */
  module.treegrid = {
    /*취소 경고창 handler */
    cancelAlert: false,
		/*****************************************************
		* created by  : 심재근
		* method      :	트리그리드 -> 트리뷰 UI 설정
		*****************************************************/
    ui: {
      /**
      * 트리그리드 내부 트리뷰 UI설정
      * @author 심재근 연구원
      * @since  2021-02-03
      * @param {String} treegrid 트리그리드ID
      * @param {String} viewColumn 트리그리드 visible 메인컬럼
      */
      initInner: function (treegrid, viewColumn) {
        var self = bsApi.getPage();
        var target = self[treegrid];

        // 그리드 선택방법 미지정
        target._grid.setSelectOptions({
          style: "none"
        });

        // Row Selection 시 투명
        target._grid.setDisplayOptions({
          rowFocusVisible: true,
          // rowFocusBackground:"#00ffffff",
          heightMeasurer: "fixed",
          rowResizable: true,
          rowHeight: 25
        });
        // 트리 관련 UI 조정 //
        target._grid.setStyles(
          {
            "grid": {
              "border": "#ffffff,1",
              "background": "#ffffff"
            },
            "body": {
              "border": "#ffffff,1",
              "borderBottom": "#ffffff,1",
              "borderRight": "#ffffff,1",
              "borderLeft": "#ffffff,1",
              "line": "#ffffffff, 1"
            }
          }
        );

        target._grid.setTreeOptions({
          lineVisible: false,
          expandImage: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAHCAYAAAAvZezQAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkRGQTgzMTg2QzgwNzExRTc5ODg3OTRCRkM2NjMyRjBDIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkRGQTgzMTg3QzgwNzExRTc5ODg3OTRCRkM2NjMyRjBDIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6REZBODMxODRDODA3MTFFNzk4ODc5NEJGQzY2MzJGMEMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6REZBODMxODVDODA3MTFFNzk4ODc5NEJGQzY2MzJGMEMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5VoYguAAAAOElEQVR42mLs7e39X1zEycgABUwgorfv+3+4AEwWJsjI8H8aA7IAihaQauZePic4B64C2RaAAAMAFD8XFOZeISUAAAAASUVORK5CYII=",
          collapseImage: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAECAYAAABCxiV9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkNDNUM2Nzg4QzgwNzExRTc4NjNEOUZBMUJBRTFFMkY1IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkNDNUM2Nzg5QzgwNzExRTc4NjNEOUZBMUJBRTFFMkY1Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Q0M1QzY3ODZDODA3MTFFNzg2M0Q5RkExQkFFMUUyRjUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Q0M1QzY3ODdDODA3MTFFNzg2M0Q5RkExQkFFMUUyRjUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz49PepjAAAAM0lEQVR42mLs7e39zwAExUWcjAxQ0Nv3HSzGBBOECcBokDgjw/9pKKqRTWFCF0A2HiDAABsmFiCndrzWAAAAAElFTkSuQmCC",
          expanderWidth: "12"
        }
        );

        //////////////////////

        var imageList = new RealGridJS.ImageList(treegrid, "");
        imageList.addUrls([
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozNzU4QTYyMjNBMjA2ODExODIyQUU2QzQ2QjIzOEVDRiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpDRDcyQUFBOEM4MUIxMUU3QTBCMkExRjhDMDk3NEY2NiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpDRDcyQUFBN0M4MUIxMUU3QTBCMkExRjhDMDk3NEY2NiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RkE0Rjc3NzM0QjIwNjgxMTgyMkFFNkM0NkIyMzhFQ0YiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Mzc1OEE2MjIzQTIwNjgxMTgyMkFFNkM0NkIyMzhFQ0YiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7Bhm9NAAAAbklEQVR42mL8//8/AyWAkWID/Hd9x2ZCwwZXjkZiDGABEQGKbHCBn3//M9z48LchYPcPBmIMAbsA2QAkQxjuf/qHUyPQcEa4C9ABOzMjg74wCxDj0Hz/F5zNxEAhGDVgMBjAgh6v9M9MlBoAEGAArWot5lPU49wAAAAASUVORK5CYII=",
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozNzU4QTYyMjNBMjA2ODExODIyQUU2QzQ2QjIzOEVDRiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpENTM4NjYwOEM4MUIxMUU3QTBCMkExRjhDMDk3NEY2NiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpENTM4NjYwN0M4MUIxMUU3QTBCMkExRjhDMDk3NEY2NiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RkE0Rjc3NzM0QjIwNjgxMTgyMkFFNkM0NkIyMzhFQ0YiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Mzc1OEE2MjIzQTIwNjgxMTgyMkFFNkM0NkIyMzhFQ0YiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6CNDbvAAAApUlEQVR42mL8//8/AyWAiYFCwBKw+we6Exo2uHI0Em2C/67v/1//+A/Gdz/9+99/5dd/oFg9yGvEYBZkw/jYGBn85MBCDUCXNeCzGOhKRrAX0CVAhsSosIIxLpBy6Af1ApFiAxhBgUim3tfAcBADh0GAIhtJOt8AY/7I89/XyPbC519gR5NvwKff/0DUFQpcwAB3ATgMNtz/RY45V8GxMOC5ESDAAOTRXqJJvYkbAAAAAElFTkSuQmCC"
        ]);
        target._grid.registerImageList(imageList);

        target._grid.setColumnProperty(viewColumn, "imageList", treegrid);
        target._grid.setColumnProperty(viewColumn, "renderer", {
          type: "icon",
          // 텍스트 표시 여부
          textVisible: true
        });

        target._grid.setColumnProperty(viewColumn, "styles", {
          iconLocation: "left",
          iconAlignment: "center",
          iconPadding: 7
        });

        target._grid.setColumnProperty(viewColumn, "dynamicStyles", function (tree, index, value) {
          var extended = true;
          var expanded = target._grid.getModel(index.itemIndex, extended).expanded;
          var isChild = target.getChildrenIndex(index.dataRow) != null ? true : false;
          var ret = {};
          // "0":닫힘 | "1":열림
          ret.iconIndex = expanded ? (isChild ? "1" : "0") : "0";

          return ret;

        });
      },
      /**
      * 트리그리드 외부 트리뷰 UI설정 및 확장/축소 이벤트 노드선택처리
      * @author 심재근 연구원
      * @since  2021-02-03
      * @param {String} treegrid 트리그리드ID
      */
      initOuter: function (treegrid) {

        var self = bsApi.getPage();
        var $target = self["$" + treegrid];
        var target = self[treegrid];

        //트리 패널 UI조정
        // $($target.children()[0]).css("paddingTop", "10px");
        $($target.children()[0]).css("paddingLeft", "10px");
        $($target.children()[0]).css("borderStyle", "solid");
        $($target.children()[0]).css("borderColor", "rgb(100, 100, 100) rgb(224, 224, 224) rgb(224, 224, 224)");
        target._grid.setHeader({ visible: false }); //헤더숨김
        // 최초 그리드 배경색 제거 //
        target._grid.setStyles(
          {
            "grid": {
              "border": "#ffffff,1",
              "background": "#ffffff"
            }
          }
        );

        /** 트리 축소아이콘 - 상위노드 혹은 현재노드 유지 */
        target._grid.onTreeItemCollapsing = function (tree, itemIndex, rowId) {
          target.options.previous = tree.getCurrent();
          target.options.previousData = target.dataItem(target.select());
        }
        target._grid.onTreeItemCollapsed = function (tree, itemIndex, rowId) {
          if (itemIndex < 1) return;

          var flag = false;
          var parentIndex;
          var parentsIndex = target.getParentsIndex(target.options.previous.dataRow, true);
          $.each(parentsIndex, function (idx, item) {
            if (item == rowId) {
              flag = true;
              parentIndex = item;
              return false;
            }
          });

          var displayColumn = target.options.displayColumns[0].field;

          if (flag) {
            target.select(parentIndex, displayColumn);
          } else {
            if (target.options.previousData) {
              var selectedItem = target.dataItem(target.options.previous.dataRow);
              target.select(
                target.searchCell({
                  field: ["__UUID"],
                  value: selectedItem.__UUID
                })
                , displayColumn);
            }
          }
        }
        /** 트리 확장아이콘 - 노드 유지 */
        target._grid.onTreeItemExpanding = function (tree, itemIndex, rowId) {
          target.options.previous = tree.getCurrent();
          target.options.previousData = target.dataItem(target.select());
        }
        target._grid.onTreeItemExpanded = function (tree, itemIndex, rowId) {
          if (itemIndex < 1) return;

          var selectedItem = target.dataItem(target.options.previous.dataRow);
          search_UUID(target, selectedItem.__UUID);
        }

      },
      /**
      * 트리그리드 외부 트리뷰 UI설정 / CustomImages
      * @author 심재근 연구원
      * @since  2021-02-03
      * @param {String} treegrid 트리그리드ID
      * @param {String} viewColumn 트리그리드 visible 메인컬럼
      * @param {Object} info CustomSetting 정보
      * @param {Array} info.images 이미지 Url
      * @param {Function} info.setting(treegrid, viewColumn, info)
      */
      initInnerCustom: function (treegrid, viewColumn, info) {
        var self = bsApi.getPage();
        var target = self[treegrid];

        // 그리드 선택방법 미지정
        target._grid.setSelectOptions({
          style: "none"
        });

        // Row Selection 시 투명
        target._grid.setDisplayOptions({
          rowFocusVisible: true,
          // rowFocusBackground:"#00ffffff",
          heightMeasurer: "fixed",
          rowResizable: true,
          rowHeight: 25
        });
        // 트리 관련 UI 조정 //
        target._grid.setStyles(
          {
            "grid": {
              "border": "#ffffff,1",
              "background": "#ffffff"
            },
            "body": {
              "border": "#ffffff,1",
              "borderBottom": "#ffffff,1",
              "borderRight": "#ffffff,1",
              "borderLeft": "#ffffff,1",
              "line": "#ffffffff, 1"
            }
          }
        );

        target._grid.setTreeOptions(
          {
            lineVisible: false,
            expandImage: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAHCAYAAAAvZezQAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkRGQTgzMTg2QzgwNzExRTc5ODg3OTRCRkM2NjMyRjBDIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkRGQTgzMTg3QzgwNzExRTc5ODg3OTRCRkM2NjMyRjBDIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6REZBODMxODRDODA3MTFFNzk4ODc5NEJGQzY2MzJGMEMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6REZBODMxODVDODA3MTFFNzk4ODc5NEJGQzY2MzJGMEMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5VoYguAAAAOElEQVR42mLs7e39X1zEycgABUwgorfv+3+4AEwWJsjI8H8aA7IAihaQauZePic4B64C2RaAAAMAFD8XFOZeISUAAAAASUVORK5CYII=",
            collapseImage: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAECAYAAABCxiV9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkNDNUM2Nzg4QzgwNzExRTc4NjNEOUZBMUJBRTFFMkY1IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkNDNUM2Nzg5QzgwNzExRTc4NjNEOUZBMUJBRTFFMkY1Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Q0M1QzY3ODZDODA3MTFFNzg2M0Q5RkExQkFFMUUyRjUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Q0M1QzY3ODdDODA3MTFFNzg2M0Q5RkExQkFFMUUyRjUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz49PepjAAAAM0lEQVR42mLs7e39zwAExUWcjAxQ0Nv3HSzGBBOECcBokDgjw/9pKKqRTWFCF0A2HiDAABsmFiCndrzWAAAAAElFTkSuQmCC",
            expanderWidth: "12"
          }
        );

        //////////////////////

        var imageList = new RealGridJS.ImageList(treegrid, "");
        imageList.addUrls(info.images);
        target._grid.registerImageList(imageList);

        target._grid.setColumnProperty(viewColumn, "imageList", treegrid);
        target._grid.setColumnProperty(viewColumn, "renderer", {
          type: "icon",
          // 텍스트 표시 여부
          textVisible: true
        });

        target._grid.setColumnProperty(viewColumn, "styles", {
          iconLocation: "left",
          iconAlignment: "center",
          iconPadding: 7
        });

        target._grid.setColumnProperty(viewColumn, "dynamicStyles", function (tree, index, value) {
          return info.setting(tree, index, value);
        });
      }
    }
  };

  function search_UUID(target, keyword) {
    if (!keyword) return;

    var value = keyword;
    var fields = ["__UUID"];
    var gridView = target._grid;
    var dataProvider = target.dataSource.dataProvider;
    var startFieldIndex = fields.indexOf("__UUID") + 1;
    var options = {
      fields: fields,
      value: value,
      startIndex: target.select(),
      startFieldIndex: startFieldIndex,
      wrap: true,
      // caseSensitive : false, //default:false
      partialMatch: true //like
    };

    if (dataProvider.searchData(options) != undefined &&
      dataProvider.searchData(options) != null &&
      dataProvider.searchData(options).dataRow != null) {
      var displayColumn = target.options.displayColumns[0].field;
      target.select(dataProvider.searchData(options).dataRow, displayColumn);
    }
  }

  module.openDocumentMenu = function (docuNo, pcCd) {
    dews.api.post(dews.url.getApiUrl("HR", "HrCommonService_X10005", "get_docu_info"), {
      data: {
        docu_no: bsApi.getString(docuNo),
        pc_cd: bsApi.getString(pcCd)
      }
    }).done(function (data) {
      if (!data) {
        var msg = dews.string.format("전표[{0}]의 정보가 존재하지 않습니다.\n(회계단위:{1})", bsApi.getString(docuNo), bsApi.getString(pcCd));
        console.error(msg);
        dews.ui.snackbar.warning(msg);
      } else {
        if (bsApi.getString(pcCd) != data.PC_CD) {
          var msg = dews.string.format("경고! 회계단위가 다릅니다.(입력:{0}, 전표:{1})", bsApi.getString(pcCd), data.PC_CD);
          console.warn(msg);
        }
        dews.ui.openMenu("FI", "GLDDOC00500", {
          PC_CD: data.PC_CD,                      //회계단위코드
          PC_NM: data.PC_NM,                      //회계단위명
          WRT_DEPT_CD: data.DOCU_DEPT_CD,         //작성부서코드
          WRT_DEPT_NM: data.DOCU_DEPT_NM,         //작성부서명
          WRT_EMP_NO: data.DOCU_EMP_NO,           //작성자 사원번호
          WRT_KOR_NM: data.DOCU_KOR_NM,           //작성자명
          ACTG_DT: data.ACTG_DT,                  //회계일
          WRT_DT: data.WRT_DT,                    //작성일
          DOCU_NO: data.DOCU_NO,                  //전표번호
        });
      }
    }).fail(function (error) {
      dews.error(error.responseJSON.message);
    });
  }

  module.HR = {
    /**
      * 인사카드 도움창 오픈
      * @param {string} empNo 사원번호
      */
    openEmpCard: function (empNo) {
      console.debug("openEmpCard.OPEN", empNo);
      var popId = "PAMESR01700_X10005_DLG_EMPINFO";
      dews.ui.dialog(popId, {
        url: "/view/CX/" + popId,
        title: "사원정보",
        width: 1250,
        height: 700,
        initData: bsApi.getString(empNo),
        close: function (data) {
          console.debug("openEmpCard.CLOSE", empNo);
        },
      }).open();
    },
    /**
      * 전자결재 이력 팝업 오픈
      * @param {string} athz_doc_cd 전자결재문서번호
      */
    openAthzHistory: function (athz_doc_cd) {
      console.debug("openAthzHistory.OPEN", athz_doc_cd);
      var popId = "H_HR_GWHISTORY_POP_X10005";
      dews.ui.dialog(popId, {
        url: "/codehelp/CX/" + popId,
        title: "결재 이력",
        width: 400,
        height: 270,
        initData: {
          approkey: bsApi.getString(athz_doc_cd),
        },
        close: function (data) {
          console.debug("openAthzHistory.CLOSE", athz_doc_cd);
        },
      }).open();
    },
    /**
     * 결재라인정보 호출
     * @param {string} approkey 승인키
     * @return {object object} 변환 값
     */
    getEaDocLineInfo: function (approkey) {
      try {
        return new Promise(function (resolve, reject) {
          dews.api.post(dews.url.getApiUrl("HR", "HrCommonWorkflowAPI_X10005", "getEaDocLineList"), {
            data: {
              approkey: approkey
            }
          }).done(function (info) {
            resolve(info);
          }).fail(function (error) {
            reject(error);
          });
        });
      } catch (error) {
        bsApi.showErrorMessage(error);
      }
    },
    /**
     * 전자결재문서 삭제
     * @param {string} approkey 결재상신코드
     * @param {string} outProcessCode 외부시스템연동코드
     * @param {string} userId 암호화된 로그인 아이디
     * @return {object} 결과 값
     */
    removeGroupWareDocu: function (approkey, outProcessCode, userId) {
      var result;
      var url = eltrAthzUtil.getApprovalUrl("x10005d");
      if (!bsApi.isNotNull(url) || url.includes("duzon")) {
        url = "http://10.10.16.46/CustomPEwp/eai/outProcessEncLogOn.do";
      }

      dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "removeGroupWareDocument"), {
        async: false,
        data: {
          url: url,
          approKey: approkey,
          outProcessCode: outProcessCode,
          loginId: userId ? userId : eltrAthzUtil.getBizBoxLoginId()
        }
      }).done(function (data) {
        result = data;
      }).fail(function (error) {
        bsApi.showErrorMessage(error);
      });

      return result;
    }
  };

  // 설비 커스텀 도움창 (동서발전)
  module.PM = {
    custom_help: function (event, helpName, conditionObj) {
      try {
        switch (helpName) {
          case "H_PM_ORDER_MST_C_X10005":
            h_pm_custom_help_open(
              event,
              conditionObj,
              "H_PM_ORDER_MST_C_X10005",
              1200,
              700,
              "~/codehelp/CX/H_PM_ORDER_MST_C_X10005",
              "설비오더 도움창",
              "pm_ord_plant_cd"
            );
            break;
          case "H_PM_PLNTSTR_MST_C_X10005":
            h_pm_custom_help_open(
              event,
              conditionObj,
              "H_PM_PLNTSTR_MST_C_X10005",
              1000,
              650,
              "~/codehelp/CX/H_PM_PLNTSTR_MST_C_X10005",
              "기능위치 도움창",
              "pm_plntstr_plant_cd"
            );
            break;
          case "H_PM_EQ_DTL_C_X10005":
            h_pm_custom_help_open(
              event,
              conditionObj,
              "H_PM_EQ_DTL_C_X10005",
              1000,
              680,
              "~/codehelp/CX/H_PM_EQ_DTL_C_X10005",
              "설비 도움창",
              "pm_eq_plant_cd"
            );
            break;
        }
      } catch (error) {
        bsApi.showErrorMessage(error);
      }
    },
    custom_help_enter: function (helpName, targetArray) {
      try {
        var self = bsApi.getPage();

        // 211221 공지사항 dialogPage 제외
        if (self.id == "notice-list") { // 공지사항 dialogPage 고유 Id
          self = dews.ui.page;
        }

        for (var i = 0; i < targetArray.length; i++) {
          var targetId = targetArray[i];
          var txtTarget_fun = self["$" + targetId + "_text"];

          txtTarget_fun.keydown(function (e) {
            if (e.keyCode == 13) {
              var eTarget = e.target;

              // 210928 custom_help_enter 코드 대문자 치환
              self["$" + e.target.id][0].value = self["$" + e.target.id][0].value.toUpperCase();

              var eValue = self["$" + e.target.id][0].value;
              if (eValue == "") {
                return;
              }

              resultData = getCustomHelpData(eValue, helpName);

              if (resultData.length != 0) {
                var orgId = eTarget.id.replace("_text", "");
                var oTarget = self[orgId];
                oTarget.setData(resultData[0]);
              } else {
                dews.ui.snackbar.warning("코드가 없습니다.");
              }
            }
          });
        }
      } catch (error) {
        bsApi.showErrorMessage(error);
      }
    },
    get_plant_info: function (type, code) {
      try {
        var returnData = {};
        // var self = bsApi.getPage();

        var apiUrl = "";
        switch (type) {
          case "O":
            apiUrl = "pm_ord_plant_cd";
            break;
          case "P":
            apiUrl = "pm_plntstr_plant_cd";
            break;
          case "E":
            apiUrl = "pm_eq_plant_cd";
            break;
        }

        dews.api.post(dews.url.getApiUrl("PM", "PmCommonService_X10005", apiUrl), {
          async: false,
          data: {
            param: code
          }
        }).done(function (data) {
          if (bsApi.isNotNull(data)) {
            returnData = data;
          } else {
            returnData = {
              plant_cd: dews.ui.page.user.bizAreaCode,
              plant_nm: dews.ui.page.user.bizAreaName
            };
          }
        });

        return returnData;
      } catch (error) {
        bsApi.showErrorMessage(error);
        return {};
      }
    }
  };

  function getCustomHelpData(eValue, helpName) {
    try {
      var self = bsApi.getPage();
      var resultData = [];
      var pApiUrl;
      var paramData;

      switch (helpName) {
        case "H_PM_ORDER_MST_C_X10005":
          pApiUrl = "get_enter_pm_order_no";
          paramData = {
            enter_pm_ord_no: eValue
          }
          break;
        case "H_PM_PLNTSTR_MST_C_X10005":
          pApiUrl = "pm_plntstr_mst_list";
          paramData = {
            lvl: "",
            plntstr_nm: "",
            plntstr_cd: eValue,
            plant_cd: ""
          }
          break;
        case "H_PM_EQ_DTL_C_X10005":
          pApiUrl = "pm_eq_dtl_list";
          paramData = {
            lvl: "",
            eqp_cd: eValue,
            plant_cd: "",
            eqp_nm: "",
            plntstr_cd: ""
          }
          break;
      }

      dews.api.post(dews.url.getApiUrl("PM", "PmCommonService_X10005", pApiUrl), {
        async: false,
        data: paramData
      }).done(function (data) {
        resultData = data;
      });

      return resultData;
    } catch (error) {
      bsApi.showErrorMessage(error);
    }
  }

  // 커스텀 도움창 오픈
  function h_pm_custom_help_open(event, conditionObj, pcode, pwidth, pheight, purl, ptitle, papiurl) {
    try {
      var self = bsApi.getPage();
      var element = self["$" + event.target.id];
      var control = element.data("dews-control");

      event.code = pcode;
      event.width = pwidth;
      event.height = pheight;
      event.custom = true;
      event.viewUrl = purl;
      event.title = ptitle;
      event.params = get_pm_parameter_plant_cd(event, conditionObj, papiurl);

      if (element.hasClass("dews-ui-multicodepicker")) {
        event.callback = function (e) {
          control.clear();
          control.setData(e);
        };
      }
    } catch (error) {
      bsApi.showErrorMessage(error);
    }
  }

  // 커스텀 도움창 파라미터 공장코드 생성
  function get_pm_parameter_plant_cd(event, conditionObj, apiUrl) {
    try {
      var returnData = conditionObj;
      var self = bsApi.getPage();
      var element = self["$" + event.target.id];
      var control = element.data("dews-control");

      var codeData = "";
      if (element.hasClass("dews-ui-codepicker")) {
        codeData = bsApi.getString(control.code());
      } else if (element.hasClass("dews-ui-multicodepicker")) {
        if (control.codes().length > 0) {
          codeData = bsApi.getString(control.code(0));
        }
      } else {
        dews.error("커스텀 도움창을 사용할 수 없습니다");
      }

      // 현재 지정된 값 (파라미터 우선순위 1번째)
      if (codeData != "") {
        dews.api.post(dews.url.getApiUrl("PM", "PmCommonService_X10005", apiUrl), {
          async: false,
          data: {
            param: codeData
          }
        }).done(function (data) {
          var plant_cd = "";
          var plant_nm = "";

          if (bsApi.isNotNull(data)) {
            plant_cd = data.PLANT_CD;
            plant_nm = data.PLANT_NM;
          }

          if (bsApi.isNotNull(conditionObj) == false) {
            returnData = {
              plant_cd: plant_cd,
              plant_nm: plant_nm
            }
          } else {
            returnData.plant_cd = plant_cd;
            returnData.plant_nm = plant_nm;
          }

          if (element.hasClass("dews-ui-codepicker")) {
            returnData.param_cd = codeData;
          } else if (element.hasClass("dews-ui-multicodepicker")) {
            returnData.param_cd_m = control.codes().join("|");
          }
        });
      }
      // 파라미터 공장코드가 없는 경우 사원마스터 공장코드
      else if (bsApi.isNotNull(conditionObj) == false || bsApi.isNotNull(conditionObj.plant_cd) == false) {
        var temp = getEmpMst_plant_cd();
        if (bsApi.isNotNull(conditionObj) == false) {
          returnData = {
            plant_cd: temp.plant_cd,
            plant_nm: temp.plant_nm
          }
        } else {
          returnData.plant_cd = temp.plant_cd;
          returnData.plant_nm = temp.plant_nm;
        }
      }

      return returnData;
    } catch (error) {
      bsApi.showErrorMessage(error);
      return {};
    }
  }

  function getEmpMst_plant_cd() {
    try {
      var returnData;
      /*
            dews.api.post(dews.url.getApiUrl("PM", "PmCommonService_X10005", "pm_emp_plant_cd"), {
              async: false
            }).done(function (data) {
              var plant_cd = "";
              var plant_nm = "";
              if (bsApi.isNotNull(data)) {
                plant_cd = data.PLANT_CD;
                plant_nm = data.PLANT_NM;
              }
              returnData = {
                plant_cd : plant_cd,
                plant_nm : plant_nm
              };
            });
      */
      //      var self = bsApi.getPage();

      returnData = {
        plant_cd: dews.ui.page.user.bizAreaCode,
        plant_nm: dews.ui.page.user.bizAreaName
      };

      return returnData;
    } catch (error) {
      bsApi.showErrorMessage(error);
      return {};
    }
  }

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);

  console.debug("cm.util.x10005.js", dews.string.format("[ LOAD COMPLETE :: version={0} ]", version));

})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=cm.util.x10005.js