(function(dews, gerp, $) {
  var module = {};
  var moduleCode = 'CM';
  var DateEnum = {
    DATE : 1,   //일
    MONTH : 2,  //월
    YEAR : 3,   //년
    HOUR : 4,   //시
    MINUTE : 5, //분
    SECOND : 6, //초
    LAST_DAY_OF_MONTH : 7,  //월 마지막 일
    WEEK_OF_MONTH : 8,      //월의 주
    WEEK_OF_YEAR : 9,       //년의 주
    DAY_OF_WEEK : 10        //요일
  };
  var MessageEnum = {
    SEARCH_AGAIN_CONFIRM : '저장하지 않은 데이터가 있습니다.\n조회를 계속하시겠습니까?',   //재조회 확인 메세지
    CLOSE_CONFIRM : '저장하지 않은 데이터가 있습니다.\n닫기를 계속하시겠습니까?',          //종료 확인 메세지
    SAVE_CONFIRM : '저장하시겠습니까?',                                                 //저장 확인 메세지
    SAVE_DONE_ALERT : '저장이 완료되었습니다.',                                         //저장 완료 메세지
    SAVE_NO_DATA_ALERT : '저장할 데이터가 없습니다.',                                   //저장할 데이터 없는 메세지
    SAVE_VALID_ALERT : '필수항목을 입력하지 않았습니다.',                                //저장 필수값 메세지
    DELETE_CONFIRM : '삭제 하시겠습니까?\n(반드시 저장을 하셔야 반영이 됩니다.)',         //삭제 확인 메세지(화면상에서 삭제)
    DELETE_IMME_CONFIRM : '삭제 하시겠습니까?',                                         //삭제 확인 메세지(DB 삭제)
    DELETE_DONE_ALERT : '삭제 되었습니다.',                                             //삭제 완료 메세지
    SEARCH_LOADING : '조회하는 중입니다.',                                              //조회 로딩 메세지
    SAVE_LOADING : '저장하는 중입니다.',                                                //저장 로딩 메세지
    DELETE_LOADING : '삭제하는 중입니다.'                                               //삭제 로딩 메세지
  }
  var NotiTemplateEnum = {
    A : 10258,	//자금이체(배치)
    B : 10259,	//자금이체(실시간)
    C : 10260,	//자금만기
    D : 10261,	//채권회수모니터링
    E : 10262,	//신규법률집행접수 안내
    F : 10263,	//법률집행해제 안내
    G : 10264   //회계시스템 ID 생성 및 권한부여 요청서 
  }
  module.StringUtil = {
    /**
     * @section Description
     * @details 입력 받은 padChar 문자를 문자열 sourceString의 왼쪽에 문자열 길이가 totalLength 만큼 되도록 문자를 덧댄다.
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param String sourceString 입력 문자열
     * @param String padChar 덧댈 문자
     * @param Number totalLength 문자열 전체 길이
     * - @return String 변환 문자열
     * @example var dateString = stringUtil.padLeft("abcd", "*", 6);
     */
    padLeft : function(sourceString, padChar, totalLength){
      if(typeof sourceString != "string"){
        sourceString = sourceString + "";
      }
      var padding = "";
      for(var i = 0 ; i < totalLength ; i++){
        padding += padChar;
      }
      return padding.substring(sourceString.length) + "" + sourceString;
    }
  }

  module.ConvertUtil = {
    Date : {
      DateEnum : DateEnum,
      /**
       * @section Description
       * @details Date 타입을 입력 받아 'yyyyMMdd' 포맷의 문자열로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param Date sourceDate 입력 날짜
       * - @return String 변환 문자열
       * @example var dateString = convertUtil.Date.toString(new Date());
       */
      toString : function(sourceDate){
        var year = module.DateUtil.get(sourceDate, this.DateEnum.YEAR),
            month = module.DateUtil.get(sourceDate, this.DateEnum.MONTH),
            date = module.DateUtil.get(sourceDate, this.DateEnum.DATE);
        return year + module.StringUtil.padLeft(month, "0", 2) + module.StringUtil.padLeft(date, "0", 2);
      }
    },
    String : {
      /**
       * @section Description
       * @details String타입을 입력 받아 정수형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return Number 변환 값
       * @example var intValue = convertUtil.String.toInteger("123");
       */
      toInteger : function(sourceValue){
        return parseInt(sourceValue);
      },
      /**
       * @section Description
       * @details String타입을 입력 받아 실수형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return  변환 값
       * @example var doubleValue = convertUtil.String.toDouble("123.123");
       */
      toDouble : function(sourceValue){
        return parseFloat(sourceValue);
      },
      /**
       * @section Description
       * @details yyyyMMdd 포맷의 String 타입을 입력 받아 Date 형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return Date 변환 값
       * @example var dateValue = convertUtil.String.toDate("20181012");
       */
      toDate : function(sourceValue){
        if(sourceValue.length == 8){
          return new Date(sourceValue.substring(0, 4) + "/" + sourceValue.substring(4, 6) + "/" + sourceValue.substring(6, 8));
        } else {
          return undefined;
        }
      },
      /**
       * @section Description
       * @details 숫자를 입력받아, 3자리 마다 ',' 찍은 금액 문자열 반환 
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 값
       * - @return String 변환 값
       * @example var dateValue = convertUtil.String.toAmount("123123");
       */
      toAmount : function(sourceValue){
    	  if(isNaN(sourceValue)){
    		  console.log("ConvertUtil toAmount Call : sourceValue is not Number Type");
    		  return undefined
    	  } else {
    		  return sourceValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    	  }
      }
    },
    Array : {
      /**
       * @section Description
       * @details Array 형 데이터를 입력 받아 JSON 문자열로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 배열
       * - @return String 변환 문자열
       * @example var stringValue = convertUtil.Array.toJsonString([1, 2, 3]);
       */
      toJsonString : function(sourceValue){
        return JSON.stringify(sourceValue);
      },
      /**
       * @section Description
       * @details Array 형 데이터를 입력 받아 구분자를 '|' 문자로 하는 문자열 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 배열
       * - @return String 변환 문자열
       * @example var stringValue = convertUtil.Array.toPipeString([1, 2, 3]);
       */
      toPipeString : function(sourceValue){
        return sourceValue.join('|');
      }
    }
  }

  module.DateUtil = {
    DateEnum : DateEnum,
    /**
     * @section Description
     * @details Date 형 데이터와 날짜 필드(정수형)를 입력 받아 날짜 필드 반환
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.get(new Date(), dateUtil.DateEnum.DATE);
     */
    get : function(sourceDate, dateEnum){
      var returnValue = undefined;
      if(!sourceDate instanceof Date){
        console.log('DateUtil get Call : sourceDate is not Date Object Type');
      } else if (!dateEnum instanceof Number){
        console.log('DateUtil get Call : dateEnum is not DateEnum Type');
      } else {
        switch(dateEnum){
          case this.DateEnum.DATE :
            returnValue = sourceDate.getDate();
            break;
          case this.DateEnum.MONTH :
            returnValue = sourceDate.getMonth() + 1;
            break;
          case this.DateEnum.YEAR :
            returnValue = sourceDate.getFullYear();
            break;
          case this.DateEnum.HOUR :
            returnValue = sourceDate.getHours();
            break;
          case this.DateEnum.MINUTE :
            returnValue = sourceDate.getMinutes();
            break;
          case this.DateEnum.SECOND :
            returnValue = sourceDate.getSeconds();
            break;
          case this.DateEnum.LAST_DAY_OF_MONTH :
            var year = this.get(sourceDate, this.DateEnum.YEAR);
            var month = this.get(sourceDate, this.DateEnum.MONTH);
            returnValue = (new Date(year, month, 0)).getDate();
            break;
          case this.DateEnum.DAY_OF_WEEK :
            returnValue = sourceDate.getDay();
            break;
          case this.DateEnum.WEEK_OF_MONTH :
            var date = this.get(sourceDate, this.DateEnum.DATE);
         	  var day = this.get(sourceDate, this.DateEnum.DAY_OF_WEEK);
         	  returnValue =  parseInt((6 + date - day) / 7) + 1;
            break;
          case this.DateEnum.WEEK_OF_YEAR :
            var year = this.get(sourceDate, this.DateEnum.YEAR);
            var month = this.get(sourceDate, this.DateEnum.MONTH);

            var totalWeek = 0;
            for(var i = month - 1; i > 0 ; i--){
              totalWeek += this.get(new Date(year, month, 0), this.DateEnum.WEEK_OF_MONTH);
            }
            totalWeek += this.get(sourceDate, this.WEEK_OF_MONTH);
            returnValue = totalWeek;
            break;
          default :
            console.log('DateUtil get Call : dateEnum is invalid');
            break;
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터와 날짜 필드(정수형), 증가 값을 입력 받아, 입력 날짜의 날짜 필드를 증가 값 만큼 더한 날짜 데이터 반환
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * @param Number value 증가 값
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.add(new Date(), dateUtil.DateEnum.DATE, 2);
     */
    add : function(sourceDate, dateEnum, value){
      var returnValue = undefined;
      if(!sourceDate instanceof Date){
        console.log('DateUtil add Call : sourceDate is not Date Object Type');
      } else if(!dateEnum instanceof Number){
        console.log('DateUtil add Call : dateEnum is not DateEnum Type');
      } else if(!value instanceof Number){
        console.log('DateUtil add Call : value is not Number Type');
      } else {
        switch(dateEnum){
          case this.DateEnum.DATE :
            returnValue = new Date(sourceDate.setDate(sourceDate.getDate() + value));
            break;
          case this.DateEnum.MONTH :
            returnValue = new Date(sourceDate.setMonth(sourceDate.getMonth() + value));
            break;
          case this.DateEnum.YEAR :
            returnValue = new Date(sourceDate.setFullYear(sourceDate.getFullYear() + value));
            break;
          case this.DateEnum.HOUR :
            returnValue = new Date(sourceDate.setHours(sourceDate.getHours() + value));
            break;
          case this.DateEnum.MINUTE :
            returnValue = new Date(sourceDate.setMinutes(sourceDate.getMinutes() + value));
            break;
          case this.DateEnum.SECOND :
            returnValue = new Date(sourceDate.setSeconds(sourceDate.getSeconds() + value));
          break;
          default :
            console.log('DateUtil get Call : dateEnum is invalid');
          break;
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터를 2개와 날짜 필드(정수형)을 입력 받아, 해당 날짜 필드에 대해 두 날짜의 차이 값을 반환
     * @details sourceDate2 - sourceDate1
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate1 입력 날짜
     * @param Date sourceDate2 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.differenceBetween(new Date(2018, 9, 1), new Date(), dateUtil.DateEnum.DATE);
     */
    differenceBetween : function(sourceDate1, sourceDate2, dateEnum){
      var returnValue = undefined;
      if(!sourceDate1 instanceof Date){
        console.log('DateUtil differenceBetween Call : sourceDate1 is not Date Object Type');
      } else if(!sourceDate2 instanceof Date){
        console.log('DateUtil differenceBetween Call : sourceDate2 is not Date Object Type');
      } else if (!dateEnum instanceof Number){
        console.log('DateUtil get Call : dateEnum is not DateEnum Type');
      } else {
        switch(dateEnum){
          case this.DateEnum.DATE :
          case this.DateEnum.MONTH :
          case this.DateEnum.YEAR :
          case this.DateEnum.HOUR :
          case this.DateEnum.MINUTE :
          case this.DateEnum.SECOND :
            var val1 = this.get(sourceDate1, dateEnum);
            var val2 = this.get(sourceDate2, dateEnum);
            returnValue = val2 - val1;
          break;
          default :
            console.log('DateUtil differenceBetween Call : dateEnum is invalid');
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터를 2개와 날짜 필드(정수형)을 입력 받아, 크기 비교
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate1 입력 날짜
     * @param Date sourceDate2 입력 날짜
     * - @return Number 반환 값(if sourceDate1 > sourceDate2 than return 1, else if sourceDate1 == sourceDate2 than return 0, else if sourceDate1 < sourceDate2 than return -1)
     * @example var compareValue = dateUtil.compareWith(new Date(2018, 9, 1), new Date());
     */
    compareWith : function(sourceDate1, sourceDate2){
      var returnValue = undefined;
      if(!sourceDate1 instanceof Date){
        console.log('DateUtil compareWith Call : sourceDate1 is not Date Object Type');
      } else if(!sourceDate2 instanceof Date){
        console.log('DateUtil compareWith Call : sourceDate2 is not Date Object Type');
      } else {
        if(sourceDate1.getTime() == sourceDate2.getTime()){
          returnValue = 0;
        } else if(sourceDate1.getTime() > sourceDate2.getTime()){
          returnValue = 1;
        } else {
          returnValue = -1;
        }
      }
      return returnValue;
    }
  };
  module.ExcelUtil ={
    /**
     * @section Description
     * @details fileButton에서 선택한 파일과 처리할 API URL, 서버단 처리 완료시 작업할 CallBack 함수를 정의하여 선택한 엑셀파일 서버로 전송
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Object e 파일 탐색기에서 선택한 파일 객체
     * @param String url 업로드 처리할 서버 API URL
     * @param function callback 업로드 처리 이후 동작 로직
     * @example  excelUtil.upload(e, dews.url.getApiUrl("FI", "SampleService", "sample00700_list_excel_upload"), function(data){
     *             self.gridDataSource.data(data);
     *             self.grid.setDatSource(gridDataSource);
     *           })
     */
    upload : function(e, url, callback, apiParams){
    	var formData = new FormData();
    	formData.append('file', e.target.files[0]);
    	formData.append('isText', 'false');
    	formData.append('token', JSON.parse(dews.ui.page.token).access_token);
    	
    	var xhr = new XMLHttpRequest();
        xhr.open('POST', "/upload/file", true);
        
        var completeHandler = function (e) {
            var fileData = {};
            if (this.status === 200) {
                var data = JSON.parse(this.responseText);

                if (data.success === 'true') {
                    data = data.data;
                    fileData.NEW_FILE_DC = data.newFilename;
                    fileData.ORGL_FILE_DC = data.originalFilename;
                    fileData.ORGL_FEXTSN_DC = data.originalExtension;
                    fileData.FILE_VR = parseInt(data.fileSize, 10);
                    
                    newParams = {
                      fileModel : JSON.stringify(fileData)
                    };

                    if(apiParams != undefined){
                      $.each(Object.keys(apiParams), function(idx, data){
                        newParams[data] = apiParams[data];
                      });
                    }
                    dews.api.post(url, {
                    	async : false,
                    	data : newParams
                    }).done(function(data){
                    	callback(data);
                    }).fail(function (xhr, status, error) {
                      var err = {
                        xhr : xhr,
                        status: status,
                        error : error
                      };
                      callback(err);
                    });
                }
            }
        };
        
        xhr.addEventListener('load', completeHandler);
        xhr.send(formData);
    },
    /**
     * @section Description
     * @details 서버에서 작성된 Excel 파일을 다운
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Object data 서버에서 작성한 Excel 파일. DzDownloadModel
     * @example  
     *  dews.api.get(dews.url.getApiUrl("FI", "SampleService", "sample00800_excel_download"), {
     *    async : false
     *  }).done(function(data){
     *    excelUtil.download(data);
     *  });
     */
  	download : function(data){
      var fileData = new Blob([new Uint8Array(data.file)], {type : data.contentType});
      if(window.navigator && window.navigator.msSaveOrOpenBlob){
        window.navigator.msSaveOrOpenBlob(fileData, data.fileName);
      } else {
        var anchorTag = window.document.createElement('a');
        anchorTag.href = window.URL.createObjectURL(fileData);
        anchorTag.download = data.fileName;
        document.body.appendChild(anchorTag);
        anchorTag.click();
        document.body.removeChild(anchorTag);
      }
  	}  
  }
  
  module.GridUtil = {
	validateDetailGrid : function(masterGrid, detailGrid){
		var mDs = masterGrid.dataSource;
		var dDs = mDs.options.detailDataSource;
		
		var detailData = dDs.getDirtyData();
		var addArr = detailData.Added;
		var upArr = detailData.Updated;
		
		// 1. 필수컬럼 필드명 가져오기
		var colArr = [];
		$.each(detailGrid.columns, function(idx, item) {
			if (item.attributes != undefined) {
				if (item.attributes.class == "required") {
					colArr.push(item.field);	
				}
			}
		});
		
		if (colArr.length <= 0) {
			return true;
		}
		
		var detailUid = undefined;
		var nullColumn = undefined;
		
		$.each(addArr, function(idx, item) {
			for(var i=0; i<colArr.length; i++) {
				if (item[colArr[i]] == undefined || item[colArr[i]] == null) {
					detailUid = item._huid;
					nullColumn = colArr[i];
					return false;
				}
			}
		});
		
		if (detailUid == undefined) {
			$.each(upArr, function(idx, item) {
				for(var i=0; i<colArr.length; i++) {
					if (item[colArr[i]] == undefined || item[colArr[i]] == null) {
						detailUid = item._huid;
						nullColumn = colArr[i];
						return false;
					}
				}
			});
		}
		
		if (detailUid != undefined) {
			var targetIdx = undefined;
			$.each(mDs.data(), function(idx, item) {
				if (item["_uid"] == detailUid) {
					targetIdx = idx;
					return false;
				}
		    });

		    if (targetIdx != undefined) {
		    	masterGrid.select(targetIdx);
		    	return false;
		    }
	    }
		return true;
	}
  }
  module.HrInboundLoadDialog = {
    open : function() {
      var loadDialog = dews.ui.dialog("CUSTOM", {
        url : "~/codehelp/CM/H_IH_HREMP_INFO_IB_LOAD_C",
        width : 1100,
        height : 600,
        buttons : 'close',
        initData : {
        },
        ok : function(data){
          
        }
      });
      loadDialog.open();
    }
  }
  
  module.NotiDialogUtil = {
    templateEnum : NotiTemplateEnum,
    open : function(userInfo, inputFlag, contentTemplate, callback){
      if(contentTemplate != undefined && contentTemplate != null){
        var content = this.getContent(contentTemplate);
      } else {
        contentTemplate = {
          templateCode : undefined
        };
        content = undefined
      }
      var notiDialog = dews.ui.dialog("CUSTOM", {
        url : "~/codehelp/CM/CommonNotiDialog",
        width : 660,
        height : 500,
        buttons : 'applyAndClose',
        initData : {
          params : {
            userInfo : userInfo,
            inputFlag : inputFlag,
            templateCode : contentTemplate.templateCode,
            content : content
          }
        },
        ok : function(data){
          if(callback instanceof Function){
            callback();
          }
        }
      });
      notiDialog.open();
    },
    getContent : function(contentTemplate){
      var content = contentTemplate.content;
      var param = contentTemplate.param;

      if(param != undefined){
        $.each(Object.keys(param), function(idx, data){
          content = content.replace(new RegExp("#{" + data + "}", 'g'), param[data]);
        });
      }
      return content;
    },
    getTemplate : function(template){
      resultObject = {
        templateCode : undefined,
        content : undefined,
        param : undefined
      }
      if(typeof template == 'string'){
        resultObject.content = template;
      } else {
        resultObject.templateCode = template;
        switch(template){
          case 10258 : 
            resultObject.content = 
              "1. 배치이체\n" + 
              " - #{COMPANY}_#{BANK}은행(지급이체) 파일수신 완료\n" + 
              "완료:[#{SEND_CNT}건],[#{SEND_AMT}원]\n" + 
              "#{YYYY}년 #{MM}월 #{DD}일 이체 예정";
  
            resultObject.param = {
              COMPANY : undefined,
              BANK : undefined,
              SEND_CNT : undefined,
              SEND_AMT : undefined,
              YYYY : undefined,
              MM : undefined,
              DD : undefined
            };
  
          break;
          case 10259:
            resultObject.content = 
              "1.실시간 이체\n" +
              "- #{COMPANY}_#{BANK}은행(지급이체) 이체 완료\n" + 
              "완료: [#{SEND_CNT}건],[#{SEND_AMT}원]";
            resultObject.param = {
              COMPANY : undefined,
              BANK : undefined,
              SEND_CNT : undefined,
              SEND_AMT : undefined
            };
          break;
          case 10260:
            resultObject.content = 
              "#{COMPANY}_#{FUND_GUBUN}금융상품 만기 예정일(이자지급일) #{YYYY}년 #{MM}월 #{DD}일 알림\n" + 
              "금액 : [#{AMT}원], 금리 : #{PERCENT}, 기간 : #{PERIOD}일, 이자금액(이자지급액): #{INTEREST}원";
            resultObject.param = {
              COMPANY : undefined,
              FUND_GUBUN : undefined,
              YYYY : undefined,
              MM : undefined,
              DD : undefined,
              AMT : undefined,
              PERCENT : undefined,
              PERIOD : undefined,
              INTEREST : undefined
            };
          break;
          case 10261:
            resultObject.content = 
              "1. 해당 부서의 장기 미회수 채권에 대하여 아래와 같이 알려드리오니 확인후 정산 요청드립니다.\n" + 
              "- 사업자번호 : #{BIZR_NO} 外\n" + 
              "- 사업자명 : #{BIZR_NM}\n" +
              "- 발생월 : #{OCRN_YY}\n" + 
              "- 경과월수 : #{MON_PROGRESS}\n" + 
              "- 금액 : #{AMT}\n" + 
              "- 발생사유 : #{REASON}\n" + 
              "#{LINK}\n\n" +
              "2. 발생월 기준 경과기간에 따라 해당 규정에 의거, 처리되오니 조속한 협조 부탁드립니다.\n" + 
              "①3개월 경과 : 재경팀→해당 부서 공문발송\n" + 
              "②6개월 경과 : 해당 부서 장기미수내역 담당임원결재\n" + 
              "③7개월 경과 : 담당 시말서 / 부서장 경고\n" + 
              "[※6개월 이상 경과시 미수처리방안 재경팀 공유必]";
  
            resultObject.param = {
              BIZR_NO : undefined,
              BIZR_NM : undefined,
              BRAND_NM : undefined,
              OCRN_YY : undefined,
              MON_PROGRESS : undefined,
              AMT : undefined,
              REASON : undefined,
              LINK : undefined
            };
          break;
          case 10262:
            resultObject.content =
              "<신규법률집행접수 안내>\n" +
              "- 사건번호 : #{NO}\n" +
              "- 접수일자 : #{YYYYMMDD}\n" + 
              "- 채무자 : #{DEBTOR}\n" + 
              "(법인번호 : #{CORP_NO}\n" + 
              "/ 사업자번호 : #{BIZR_NO})\n" +
              "- 채권자 : #{CREDITOR}\n" + 
              "- 유형 : #{UPGU}\n" +
              "- 금액 : #{AMT}\n" +
              "- 각점별 보류처리를 진행해야 하므로 담당자께서는 각별히 유의바랍니다.";
            
            resultObject.param = {
              NO : undefined,
              YYYYMMDD : undefined,
              DEBTOR : undefined,
              CORP_NO : undefined,
              BIZR_NO : undefined,
              CREDITOR : undefined,
              UPGU : undefined,
              AMT : undefined
            };
          break;
          case 10263:
            resultObject.content = 
              "<법률집행해제 안내>\n" +
              "- 사건번호 : #{NO}\n" +
              "- 해제일자 : #{END_DT}\n" + 
              "(접수일자 : #{RECEIPT_DT})\n" + 
              "- 채무자 : #{DEBTOR}\n" +
              "(법인번호:#{CORP_NO}\n" +
              "/사업자번호:#{BIZR_NO})\n" +
              "- 채권자 : #{CREDITOR}\n" +
              "- 지불대상 : #{PAYMENT_TAGET}\n" +
              "- 금액 : #{AMT}\n" +
              "- 각 점별 보류해제를 진행해야하므로 담당자께서는 각별히 유의바랍니다.";
            resultObject.param = {
              NO : undefined,
              END_DT : undefined,
              RECEIPT_DT : undefined,
              DEBTOR : undefined,
              CORP_NO : undefined,
              BIZR_NO : undefined,
              CREDITOR : undefined,
              PAYMENT_TAGET : undefined,
              AMT : undefined
            }  
          break;
          case 10264:
          	resultObject.content = 
              "회계시스템 ID 생성 및 권한부여 요청서"; 
          	 resultObject.param = {
              G_USER_ID : undefined,
              G_USER_NM : undefined,
              G_MENUGRP_CD : undefined,
              G_GRP_NM : undefined,
              G_GRANT_MAGN_USER_ID : undefined,
              G_GRANT_MAGN_USER_NM : undefined,
              G_RMK_DC : undefined,
              U_USER_ID : undefined,
              U_USER_NM : undefined,
              U_MENUGRP_CD : undefined,
              U_GRP_NM : undefined,
              U_MENU_NM : undefined,
              U_GRANT_FG : undefined,
              U_GRANT_LV : undefined,
              U_CREATE_TP : undefined,
              U_READ_TP : undefined,
              U_SAVE_TP : undefined,
              U_DELETE_TP : undefined,
              U_PRINT_TP : undefined,
              U_RMK_DC : undefined,
              I_EMP_NO : undefined,
              I_KOR_NM : undefined,
              I_SYS_NM : undefined,
              I_INT_TSK_CLASS_NM : undefined,
              I_TSK_TP_FG_NM : undefined,
              I_RMK_DC : undefined
            }  
          break;
        }
      }
    	return resultObject;
    }
  }

  module.MessageUtil = MessageEnum;
  module.PrintDialogUtil = {
    openFlag : true,
    filterReportList : undefined,
    setReportList : function(reportList){
      this.filterReportList = reportList
    },
    open : function(menuCode, dataSetFunc, paramSetFunc, encodeFlag, windowOption, callBackFunc){
      if(windowOption == undefined || windowOption == null){
        windowOption = this.newOptionInstance();
      }
      enodeFlag = encodeFlag == undefined ? false : encodeFlag;
      var printDialog = dews.ui.dialog("CUSTOM", {
        url : "~/codehelp/CM/H_MA_REPORT_INFO_C",
        buttons : "applyAndClose",
        width : 470,
        height : 210,
        initData : {
          menuCode : menuCode,
          dataSetFunc : dataSetFunc,
          paramSetFunc : paramSetFunc,
          encodeFlag : encodeFlag,
          windowOption : windowOption,
          printDialogUtil : this,
          filterReportList : this.filterReportList
        },
        ok : function(data){
          if(callBackFunc != undefined){
            callBackFunc();  
          }
        }
      });
      this.filterReportList = undefined;
      this.openFlag = true;
      printDialog.open();
    },
    blockOpenViewer : function(){
      this.openFlag = false;
    },
    newOptionInstance : function() {
      return {
        width : '900',
        height : '700',
        toolbar : false,
        menubar : false,
        location : false,
        scrollbars : false,
        status : false,
        resizable : false,
        fullscreen : false,
        channelmode : false,
        left : '0',
        top : '0'
      }
    }
  }
  module.TaxUtil = {
    setReeaFieldStyle : function(e){
      var self = this;
      if(self.isReeaValue(e)){
        return {
          background : '#fef4f4'
        }
      } else {
        return null;
      }
    },
    isReeaValue : function(e){
      var type = e.grid.getCellValue(e.row.index, "TAXAFS_ADJT_TP");
      var code = e.grid.getCellValue(e.row.index, "IMPR_DSPS_CD");
      if((type == 'T01' && code == '400') || (type == 'T02' && code == '100')){
        return true;
      } else {
        return false;
      }
    },
    checkFn : function (rowData) {
      try {
        if (((rowData["TAXAFS_ADJT_TP"] == 'T01' && rowData["IMPR_DSPS_CD"] === '400') ||  (rowData["TAXAFS_ADJT_TP"] == 'T02' && rowData["IMPR_DSPS_CD"] === '100')) && !rowData["REEA_CD"]) {
          throw dews.string.format("유보코드를 선택하십시오.\n{0}", rowData["TAXAFS_ADJT_SBJECT_NM"]);
        }
      } catch (e) {
        dews.alert(e);
        return false;
      }
    },
    getValidCheckMsg : function (tabName, gridEl) {
      var requiredFieldInfo = {
        TAXAFS_ADJT_SBJECT_CD: "과목"
        , TAXAFS_ADJT_SBJECT_NM: "과목"
        , IMPR_DSPS_CD: "처분"
        , IMPR_DSPS_CD_NM : "처분"
        , TAXAFS_ADJT_AMT: "금액"
      };
  
      var requiredCheckMsg = MessageEnum.SAVE_VALID_ALERT.concat("\n{0} [{1}]");// "필수항목을 입력하지 않았습니다.\n{0} [{1}]";
  
      var validResult = gridEl.validate();
  
      if (!validResult.result) {
  
        try {
  
          if (validResult.fields[0].columnName === "TAXAFS_ADJT_SBJECT_CD" || validResult.fields[0].columnName === "TAXAFS_ADJT_SBJECT_NM") {
            dews.alert(dews.string.format(requiredCheckMsg, "과목", tabName));
          } else {
            dews.alert(dews.string.format(requiredCheckMsg
              , gridEl.getCellValue(validResult.fields[0].rowIndex, "TAXAFS_ADJT_SBJECT_NM") + " : " + requiredFieldInfo[validResult.fields[0].columnName]
              , tabName
            ));
          }
        } catch (e) {
          requiredCheckMsg = MessageEnum.SAVE_VALID_ALERT.concat("\n[{0}]");
          dews.alert(dews.string.format(requiredCheckMsg, tabName));
        }
        return false;
      }
  
      return true;
    },
    gridValidate : function(grid, dataSource){
      var self = this;
      if (!self.getValidCheckMsg("익금산입 및 손금불산입", grid)) { return false; }
    
      dataSource.getDirtyData().Added.forEach(function (rowData, rowIdx) {
        console.log("Save Function Validate Check Row %d", rowIdx);
        self.checkFn(rowData, "익금산입 및 손금불산입")
      });
    
      dataSource.getDirtyData().Updated.forEach(function (rowData, rowIdx) {
        console.log("Save Function Validate Check Row %d", rowIdx);
        self.checkFn(rowData, "익금산입 및 손금불산입")
      });
      return true;
    }
  }
  module.EltrAthzUtil = {
	// contentsType : 본문Html 종류 (inner : 에디터에 넣는다 , outer : _DFINTER_ 가 먹는다)
	// 1.에디터 없는 경우 => 기안자가 결재본문를 수정 할 수 없는 경우(contentsType : 'outer')
	//   기안 양식 => HTML 에 <TR><td>_DFINTER_</TD></TR> 로 되어 있어야 함
	// 2.에디터 있는 경우 => 기안자가 결재본문를 수정 해야 할 경우 (contentsType : 'inner')
	//   기안 양식 => HTML 에 <TR><td style="font-family:굴림;font-size:9pt;color:rgb(0, 0, 0);line-height:1.2;" id="divFormContents">_DF11_</td></TR> 로 되어 있어야 함
    createEltrAthz : function(url, param, widthYn){
      var eltrAthzPopup;
      var $eltrAthzForm = $('<form id="eltrAthzForm" name="eltrAthzForm" enctype="application/json" method="POST">').appendTo("body");
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'compSeq',name:'compSeq'}).val(param.compSeq));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'approKey',name:'approKey'}).val(param.approKey));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'outProcessCode',name:'outProcessCode'}).val(param.outProcessCode));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'formId',name:'formId'}).val(param.formId));
      if(param.empSeq != undefined && param.empSeq != "" && param.empSeq != null){
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'empSeq',name:'empSeq'}).val(param.empSeq));			
      }else{
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'loginId',name:'loginId'}).val(param.loginId));			
      }
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'fileKey',name:'fileKey'}).val(param.fileKey));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'mod',name:'mod'}).val(param.mod));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'X-Authenticate-Token',name:'X-Authenticate-Token'}).val(JSON.parse(dews.ui.page.token).access_token));
      if(param.mod=='W'){//작성
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'contentsEnc',name:'contentsEnc'}).val(param.contentsEnc));
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'contentsStr',name:'contentsStr'}).val(param.contentsStr));
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'contentsType',name:'contentsType'}).val(param.contentsType));
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'appLineList',name:'appLineList'}).val(param.appLineList));
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'receiveList',name:'receiveList'}).val(param.receiveList));
      }else if(param.mod=='V') {//보기,삭제
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'docId',name:'docId'}).val(param.docId));
      }
      
      if(widthYn){
        eltrAthzPopup =  window.open("", "eltrAthzPopup", "width=981,height=769,scrollbars=yes");
        
      }else{
        eltrAthzPopup =  window.open("", "eltrAthzPopup", "width=940,height=769,scrollbars=yes");
      }
      eltrAthzPopup.focus();
      
      $('#eltrAthzForm').attr("target", "eltrAthzPopup");
      $('#eltrAthzForm').attr("action", url + "/gw/outProcessEncLogOn.do");
      $('#eltrAthzForm').submit();
      $('#eltrAthzForm').remove();
      
      return eltrAthzPopup;
    },
    createEltrAthz2 : function(url, param, widthYn, width){
      var eltrAthzPopup;
      var baseWidth = '940';
      if(width == undefined || width == null || width == ""){
        width = baseWidth;  
      }
      var $eltrAthzForm = $('<form id="eltrAthzForm" name="eltrAthzForm" enctype="application/json" method="POST">').appendTo("body");
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'compSeq',name:'compSeq'}).val(param.compSeq));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'approKey',name:'approKey'}).val(param.approKey));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'outProcessCode',name:'outProcessCode'}).val(param.outProcessCode));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'formId',name:'formId'}).val(param.formId));
      if(param.empSeq != undefined && param.empSeq != "" && param.empSeq != null){
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'empSeq',name:'empSeq'}).val(param.empSeq));			
      }else{
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'loginId',name:'loginId'}).val(param.loginId));			
      }
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'fileKey',name:'fileKey'}).val(param.fileKey));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'mod',name:'mod'}).val(param.mod));
      $eltrAthzForm.append($('<input>',{type:'hidden',id:'X-Authenticate-Token',name:'X-Authenticate-Token'}).val(JSON.parse(dews.ui.page.token).access_token));
      if(param.mod=='W'){//작성
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'contentsEnc',name:'contentsEnc'}).val(param.contentsEnc));
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'contentsStr',name:'contentsStr'}).val(param.contentsStr));
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'contentsType',name:'contentsType'}).val(param.contentsType));
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'appLineList',name:'appLineList'}).val(param.appLineList));
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'receiveList',name:'receiveList'}).val(param.receiveList));
      }else if(param.mod=='V') {//보기,삭제
        $eltrAthzForm.append($('<input>',{type:'hidden',id:'docId',name:'docId'}).val(param.docId));
      }
      
      if(widthYn){
        eltrAthzPopup =  window.open("", "eltrAthzPopup", "width=" + (parseInt(width) + 41) + ",height=769,scrollbars=yes");
        
      }else{
        eltrAthzPopup =  window.open("", "eltrAthzPopup", "width=" + width + ",height=769,scrollbars=yes");
      }
      eltrAthzPopup.focus();
      
      $('#eltrAthzForm').attr("target", "eltrAthzPopup");
      $('#eltrAthzForm').attr("action", url + "/gw/outProcessEncLogOn.do");
      $('#eltrAthzForm').submit();
      $('#eltrAthzForm').remove();
      
      return eltrAthzPopup;
    }
  }
  
  function OcrUtil(){
    this.url;
    this.key;
    this.fileInfo;
    this.binFile;
  }
  OcrUtil.prototype.init = function(){
    var self = this;
    dews.api.get(dews.url.getApiUrl("CM", "OcrApiProvider", "getOcrInfo"), {
      async : false
    }).done(function(data){
      var infoMap = JSON.parse(data);
      self.url = infoMap.url;
      self.key = infoMap.key;
    }).fail(function(xhr, status, error){
      dews.error(error);
    }).always(function(){

    });
  }
  OcrUtil.prototype.setFileInfo = function(fileInfo){
    var self = this;
    self.fileInfo = fileInfo;
  }
  OcrUtil.prototype.asyncRequest = function(){
    var self = this;
    var deferred = $.Deferred();
    var param = self.getParam(self.fileInfo)
    $.ajax({
      url : self.url,
      type : "POST",
      dataType : "json",
      contentType : 'application/json',
      headers : {
        "X-OCR-SECRET" : self.key
      },
      data : JSON.stringify(param),
      success : function(data){
        deferred.resolve(data);
      },
      error : function(xhr, status, error){
        deferred.reject(xhr, status, error);
      }
    })
    return deferred.promise();
  }
  OcrUtil.prototype.request = function(){
    var self = this;
    var result;

    var param = self.getParam(self.fileInfo)
    $.ajax({
      url : self.url,
      async : true,
      type : "POST",
      dataType : "json",
      contentType : 'application/json',
      headers : {
        "X-OCR-SECRET" : self.key
      },
      data : JSON.stringify(param),
      success : function(data){
        result = data;
      },
      error : function(xhr, status, error){
        dews.error(error);
      }
    })
    return result;
  }
  OcrUtil.prototype.isValidFile = function(){
    var self = this;
    return true;
  }
  OcrUtil.prototype.resultDialog = function(result, fields, callback){
    var self = this;
    var returnObj;
    dews.ui.dialog('OCR_RESULT', {
      url : '~/codehelp/CM/OCR_RESULT',
      buttons : 'applyAndClose',
      title : '문자 추출 결과',
      width : '1000',
      height : '800',
      initData : {
        result : result,
        fields : fields,
        file : self.fileInfo
      },
      ok : callback
    }).open();
    return returnObj;
  }
  OcrUtil.prototype.getParam = function(){
    var self = this;
    if(!self.isValidFile(self.fileInfo)){
      return undefined
    }
    return {
      version : "V1",
      requestId : "string",
      timestamp : 0,
      lang : "ko",
      images : [
        {
          format : self.fileInfo.extension,
          name : self.fileInfo.filename,
          data : self.getFile()
        }
      ]
    }    
  }
  OcrUtil.prototype.getFile = function(){
    var self = this;
    var fileString;

    var url = self.fileInfo.extension.toLowerCase() == 'pdf' ? 'convertToImage' : 'getFile'
    dews.api.get(dews.url.getApiUrl("CM", "OcrApiProvider", url), {
      async : false,
      data : {
        //fileKey : '45a245fc7657422194d76a7ea41fd9fb'
        fileKey : self.fileInfo.fileKey
      }
    }).done(function(data){
      fileString = data;
      self.binFile = fileString;
    }).fail(function(xhr, status, error){
      dews.error(error);
    }).always(function(){

    })
    
    return fileString;
  }
  OcrUtil.prototype.getBinFile = function(){
    var self = this;
    return self.binFile;
  }
  module.OcrUtil = new OcrUtil();

  function isNull(value){
    return value == null || value == undefined || value == '';
  }
  function ReplyUtil(replyTree, masterGrid, buttons){
    this.masterGrid = masterGrid;               //조회한 게시글 
    this.replyTree = replyTree;                 //댓글 트리
    this.replySq = undefined;                               //게시글 순번      
    
    this.reply_dc = buttons.reply_dc;         //댓글입력 텍스트창
    this.reply_summit = buttons.reply_summit; //입력 버튼
    this.reply_cancel = buttons.reply_cancel; //취소 버튼

    this.$reply_dc = buttons.reply_dc.element;
    this.$reply_summit = buttons.reply_summit.element;
    this.$reply_cancel = buttons.reply_cancel.element;

    this.init();
  }
  ReplyUtil.prototype.init = function(){
    let self = this;
    // define tree
    self.replyTree = dews.ui.treeview(self.replyTree, {
      dataTextField: 'REPLY_DC',
      dataSpriteCssClassField: 'cssClass',
      loadOnDemand: true,
      treePadding: 10,
      template: 
        '#= (item.REPLYUP_SQ != null ? "↪re :" : "") + item.KOR_NM + "(" + item.INSERT_ID + ") :" + item.REPLY_DC + " (" + item.INSERT_DTS + ")"# ' +
        '#if(item.REPLYUP_SQ == null){#' +
        '  <button class = "reply-reply" data-key = "#=item.REPLY_SQ#"></button>' +
        '#}#' +
        '#if(item.AUTHOR_YN == "Y") {#' +
        '  <button class = "reply-update" data-key = "#=item.REPLY_SQ#" data-txt = "#=item.REPLY_DC#"></button>' +
        '  <button class = "reply-delete" data-key = "#=item.REPLY_SQ#" data-child = "#=item.hasChild#"></button>' +
        '#}#'
    });

    // event binding
    // 입력창 엔터, esc 이벤트
    self.$reply_dc.on('keyup', function(e){
      let code = e.keyCode;
      if (code == 13) {
        self.$reply_summit.click();
      } else if (code == 27 && self.$reply_cancel.css('display') != 'none') {
        self.$reply_cancel.click();
      }
    })

    // 댓글입력 버튼 클릭 이벤트
    self.$reply_summit.on('click', function () {
      var idx = self.masterGrid.select();
      if (idx == -1) {
        dews.alert('선택된 행이 없습니다..', 'warning');
        return
      }
      var row = self.masterGrid.dataItems(idx);
      var txt = self.reply_dc.text();
      if (isNull(txt)) {
        dews.alert('댓글이 입력되지 않았습니다.', 'warning');
        return;
      }
      if (self.$reply_summit.text() == '수정입력') {
        self.replySq = self.replyTree.items().length == 0 ? undefined : self.replySq;
        self.updateReply(row.NUM, txt, self.replySq);
      } else {
        self.insertReply(row.NUM, txt, self.replySq);
      }
    });
    // 댓글취소 버튼 클릭 이벤트
    self.$reply_cancel.on('click', function () {
      dews.alert('작성을 취소합니다.');
      self.hideReplyReply();
      self.replySq = undefined;
    });
  }
  ReplyUtil.prototype.getReply = function(num){
    let self = this;
    self.replySq = undefined;
    self.hideReplyReply();
    dews.api.get(dews.url.getApiUrl('CM', 'ReplyService', 'list_reply'), {
      async: false,
      data: {
        num: num
      }
    }).done(function (data) {
      self.replyTree.dataSource.data(data);
      self.replyTree.expandAll();
      self.replyTree.element.find('.k-item').css('padding', '0 0 0 21px');
      //축소 불가능하게 
      self.replyTree.element.find('.k-i-collapse').css('display', 'none')
      self.replyTree.element.off('dblclick');
      self.replyTree.element.off('keydown');
      //버튼 이벤트 핸들러
      self.replyTree.element.find('.reply-reply').click({self : self}, self.replyEventHandler);
      self.replyTree.element.find('.reply-update').click({self : self}, self.updateEventHandler);
      self.replyTree.element.find('.reply-delete').click({self : self}, self.deleteEventHandler);
    }).fail(function (xhr, status, error) {
      dews.ui.loading.hide();
      dews.error(error);
    });
  }
  ReplyUtil.prototype.replyEventHandler = function(e){
    let self = e.data.self;
    self.replySq = e.currentTarget.getAttribute("data-key");
    self.showReplyReply();
    self.reply_dc.focus();
  }
  ReplyUtil.prototype.updateEventHandler = function(e){
    let self = e.data.self;
    self.replySq = e.currentTarget.getAttribute("data-key");
    self.reply_dc.text(e.currentTarget.getAttribute("data-txt"));
    self.$reply_cancel.css('display', 'inline');
    self.$reply_summit.text('수정입력');
    self.reply_dc.focus();
  }
  ReplyUtil.prototype.deleteEventHandler = function(e){
    let self = e.data.self;
    self.replySq = e.currentTarget.getAttribute("data-key");
    let hasChild = e.currentTarget.getAttribute("data-child");
    let row = self.masterGrid.dataItems(self.masterGrid.select());
    if (hasChild == 'true') {
      dews.alert('하위 댓글이 있어서 삭제할 수 없습니다.', 'warning');
      return;
    }
    self.deleteReply(row.NUM, self.replySq);
  }
  ReplyUtil.prototype.hideReplyReply = function(){
    let self = this;
    self.$reply_cancel.css('display', 'none');
    self.$reply_summit.text('입력');
    self.reply_dc.text('');
  }
  ReplyUtil.prototype.showReplyReply = function(){
    let self = this;
    self.$reply_cancel.css('display', 'inline');
    self.$reply_summit.text('댓글입력');
  }
  ReplyUtil.prototype.insertReply = function(num, reply_dc, replyup_sq){
    let self = this;

    dews.confirm('댓글을 등록하시겠습니까?').yes(function () {
      dews.ui.loading.show({ text: '등록중입니다.' });
      dews.api.post(dews.url.getApiUrl('CM', 'ReplyService', 'insert_reply'), {
        async: false,
        data: {
          num: num,
          reply_dc: reply_dc,
          replyup_sq: replyup_sq
        }
      }).done(function () {
        self.hideReplyReply();
        self.getReply(num);
      }).fail(function (xhr, status, error) {
        dews.error(error);
      }).always(function () {
        dews.ui.loading.hide();
      })
    })
  }
  ReplyUtil.prototype.updateReply = function(num, reply_dc, reply_sq){
    let self = this;

    dews.confirm('댓글을 수정하시겠습니까?').yes(function () {
      dews.ui.loading.show({ text: '등록중입니다.' });
      dews.api.post(dews.url.getApiUrl("CM", "ReplyService", "update_reply"), {
        async: false,
        data: {
          num: num,
          reply_dc: reply_dc,
          reply_sq: reply_sq
        }
      }).done(function (data) {
        self.hideReplyReply();
        self.getReply(num);
      }).fail(function (xhr, status, error) {
        dews.error(error);
      }).always(function () {
        dews.ui.loading.hide();
      })
    })
  }
  ReplyUtil.prototype.deleteReply = function(num, reply_sq) {
    let self = this;
    dews.confirm('댓글을 삭제하시겠습니까?').yes(function () {
      dews.ui.loading.show({ text: '삭제중입니다.' });
      dews.api.post(dews.url.getApiUrl("CM", "ReplyService", "delete_reply"), {
        async: false,
        data: {
          num: num,
          reply_sq: reply_sq
        }
      }).done(function (data) {
        self.getReply(num);
      }).fail(function (xhr, status, error) {
        dews.error(error);
      }).always(function () {
        dews.ui.loading.hide();
      })
    })
  }

  module.ReplyUtil = ReplyUtil;

  console.log('## HDG COMMON UTIL Script Loaded!!! ##');

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=cm.util.js
