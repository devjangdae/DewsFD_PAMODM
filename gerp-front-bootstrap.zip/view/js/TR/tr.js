// /view/js/tr.js
/*
 * {tr} 자금관리 모듈 공통 함수
 */
(function(dews, gerp, $) {
  var module = new Object();

  /* API START */
  var moduleCode = 'TR'; // 모듈 코드를 입력 해주세요

  module = (function(){
    return {

      /** @method 코드정보 GET
        * @description 모듈코드과, 코드필드에 해당되는 코드정보를 불러온다
        * @param {string} cd_module 모듈코드
        * @param {string} field_cd_pipe 파이프 형태의 코드필드
        * @param {string} gap 공백입력 처리(true:false)
        * @param {array} syscode_yn 디폴트 코드구분(Y,N)
        * @param {array} base_yn 디폴트 코드구분(Y,N)
        * @param {array} foreign_yn 종료일
        * @param {array} keyword 검색할 코드 또는 명
      */
      getCodeDtl : function(module_cd, field_cd_pipe, gap, syscode_yn, base_yn, foreign_yn, keyword) {
        var codeDtl = new Object();
        var codeFields = field_cd_pipe != null ? field_cd_pipe.split("|") : [];

        dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format('common_codeDtl_list')), {
          async: false,
          data: {
            module_cd: module_cd,
            field_cd_pipe: field_cd_pipe,
            syscode_yn: typeof(syscode_yn) != "undefined" ? syscode_yn : "",
            base_yn: typeof(base_yn) != "undefined" ? base_yn : "",
            foreign_yn: typeof(foreign_yn) != "undefined" ? foreign_yn : "",
            end_dt: '',
            keyword: typeof(keyword) != "undefined" ? keyword : ""
          }
        }).done(function (data) {
          if (data.length > 0) {
            $.each(codeFields, function(idx, codeField){
              var codeDtls = [];
              if(typeof(gap) != "undefined" && gap) {
                codeDtls.insert(0, { FIELD_CD: codeField, SYSDEF_CD: '', SYSDEF_NM: '' });
              }
              codeDtl[codeField] = codeDtls;
              $.each(data, function (idx, item) {
                if (item.FIELD_CD === codeField) {
                  codeDtl[codeField].push(item);
                }
              });
            });
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });

        return codeDtl;
      },

      /** @method 계정유형 GET
        * @description 계정유형 데이터 정보 불러오기
        * @param {string} gap 공백입력 처리(true:false)
      */
      getGaapCodes : function(gap) {
        var codeGaaps = [];

        dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', dews.string.format('common_multiGaap_list_company')), {
            async : false,
        }).done(function (data) {
          if (data.length > 0) {
            if(typeof(gap) != "undefined" && gap) {
              codeGaaps.insert(0, { SYSDEF_CD : '', SYSDEF_NM : ''});
            }
            $.each(data, function(idx ,item) {
              codeGaaps.push({
                SYSDEF_CD : item.SYSDEF_CD,
                SYSDEF_NM : item.SYSDEF_NM,
              });
            });
          }
        }).fail(function (xhr, status, error){
          dews.ui.snackbar.error(error);
        });

        return codeGaaps;
      },

      /** @method 회계단위 정보 GET
        * @description 회계단위 데이터 정보 불러오기
        * @param {string} yn_use 사용여부 처리("Y" : "N")
        * @param {string} gap 공백입력 처리(true:false)
      */
      getProfitCenterCodes : function(use_yn, gap) {
        var profitCenterCodes = [];

        dews.api.get(dews.url.getApiUrl("TR", "TreasuryCommonService", "accountingUnits"),{
          async: false,
          data : {
            use_yn : use_yn             //사용여부
          }
        }).done(function(data){
          if(data.length > 0) {
            if(typeof(gap) != "undefined" && gap) {
              profitCenterCodes.insert(0, { PC_CD : '', PC_NM : ''});
            }
            $.each(data, function(idx, item) {
              profitCenterCodes.push({
                PC_CD : item.PC_CD,
                PC_NM : item.PC_NM,
              });
            });
          }
        }).fail(function(xhr, status, error){
          dews.ui.snackbar.error(error);
        });

        return profitCenterCodes;
      },

      /** @method 회사환경설정 정보 GET
        * @description 회사환경설정 데이터 정보 불러오기
        * @param {string} cd_module 모듈코드
        * @param {string} ctrl_cd_pipe 통제코드(파이프 형식)
        * @param {string} use_yn 사용여부 처리("Y" : "N")
      */
      getControlConfig : function(module_cd, ctrl_cd_pipe, use_yn) {
        var controlConfig = {};
        var codeCtrls = ctrl_cd_pipe != null ? ctrl_cd_pipe.split("|") : [];

        //화면설정 값 데이터소스
        dews.api.get(dews.url.getApiUrl("TR", "TreasuryCommonService", "controlConfig"), {
          async : false,
          data : {
            module_cd : module_cd,
            ctrl_cd_pipe : ctrl_cd_pipe,
            use_yn : use_yn
          }
        }).done(function(data){
          if(data.length > 0) {
            $.each(codeCtrls, function(idx, codeCtrl) {
              $.each(data, function(idx, item) {
                if(item.CTRL_CD === codeCtrl) {
                  controlConfig[codeCtrl] = item;
                }
              });
            });
          }
        }).fail(function(xhr,status,error){
          dews.ui.snackbar.error(error);
        });

        return controlConfig;
      },

      /** @method 캘린더정보
        * @description 달력정보 정보 불러오기
        * @param {string} bwrk_fg_cd 근무구분코드(1:휴일, 2:근무)
        * @param {string} start_dt 시작일
        * @param {string} end_dt 종료일
      */
     getCalendar : function(bwrk_fg_cd, start_dt, end_dt) {
      var calendar = [];

      if(bwrk_fg_cd != null) {
        dews.api.get(dews.url.getApiUrl("TR", "TreasuryCommonService", "calendar"), {
          async: false,
          data : {
            bwrk_fg_cd : bwrk_fg_cd,
            start_dt : start_dt ? start_dt : "",
            end_dt : end_dt ? end_dt : ""
          }
        }).done(function (data) {
          calendar = data;
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
      }

      return calendar;
    },

      /** @method 공휴일 제외한 날짜 반환 함수
        * @description 현재 날짜가 공유일인경우 공유일이 아닌 다음날짜로 재계산하여 반환하는 함수
        * @param {date} targetDate 날짜
      */
      getWeekday : function(targetDate, prev) {
        prev == null ? false : prev;
        var holidays = this.getCalendar("1");   //bwrk_fg_cd : 1(휴일)

        try {
          if(typeof(targetDate) == "undefined") {
            throw "parameter is undefined";
          } else {
            if(!(targetDate instanceof Date)) {
              targetDate = dews.date.parse(targetDate);
            }
              $.each(holidays, function (idx, item) {
                if (dews.date.format(targetDate,"yyyyMMdd") == item.CLND_DT) {

                  prev ? targetDate.setDate(targetDate.getDate() - 1) : targetDate.setDate(targetDate.getDate() + 1) ;
                }
              });
          }
        } catch (error) {
          console.error(error);
        }
        return dews.date.format(targetDate,"yyyyMMdd");;
      },

      invokePrint : function(dewself, reportId, objectId, params) {
        var items = [];

        $(params).each(function(idx, item) {
          items.push( {
            RPRT_CD : reportId,
            OBJECT_CD : objectId,
            PARA_CD : item.name,
            PARA_TXT : item.value
          });
        });

        //파라미터 저장 요청
        dews.api.post(dews.url.getApiUrl("CM","printService","setPrintParam"), {
          async : false,
          data : {
            reportCode : reportId,
            items : JSON.stringify(items)
          }
        }).done(function(data){
          if(data != null && data != "") {
            dews.app.print({
              reportId : reportId,
              parameterKey : data
            });
          }
        }).fail(function(xhr,status, error) {
          dews.ui.snackbar.error(error);
        });
      },

      /**
      * @method  메인버튼 VISIBLE 처리 Method
      * @description   메인버튼 VISIBLE 처리
      * @param {string} target
          target :  add      - 추가
                    search   - 조회
                    save     - 저장
                    approval - 결재
                    delete   - 삭제
                    print    - 인쇄
                    favorite - 즐겨찾기
                    all      - 전체
              ex : "add|print" , "all"
      * @param {boolean} visible true or false
      * @param {boolean} hide true or false
      */
      setMainButtons : function(target, visible, hide) {
        if(!hide) {
          hide = false;
        }

        if(target != "all") {
          $(target.split("|")).each(function(idx,item) {
            if(visible  == true) {
              dews.ui.mainbuttons[item].show();
              dews.ui.mainbuttons[item].disable(false);
            } else {
              if(hide) {
                dews.ui.mainbuttons[item].hide();
              } else {
                dews.ui.mainbuttons[item].disable(true);
              }
            }
          });
        } else {    //전체를 보여주거나 disabled
          $.map(dews.ui.mainbuttons,function(idx,item) {
            if(typeof(dews.ui.mainbuttons[item].disable) != "undefined") {
              if(visible == true) {
                dews.ui.mainbuttons[item].show();
                dews.ui.mainbuttons[item].disable(false);
              } else {
                if(hide) {
                  dews.ui.mainbuttons[item].hide();
                } else {
                  dews.ui.mainbuttons[item].disable(true);
                }
              }
            }
          });
        }
      },

      /** @method 숫자 왼쪽에 원하는 길이만큼 0 채우기
        * @description 기준 문자열 왼쪽에 원하는 길이 만큼 text를 채워 반환하는 함수
        * @param {string} text 채울문자열
        * @param {number} num 기준 숫자
        * @param {number} totalLength 전체길이
      */
      getPadLeft : function(text, num, totalLength) {
        num = num + '';
        return num.length >= totalLength ? num : new Array(totalLength - num.length + 1).join(text) + num;
      },

      /** @method 회사정보조회 get
        * @description 회사정보를 조회하고 데이터를 반환한다.
      */
      getCompanyInfo : function() {
        var companyInfo = {};
        dews.api.get(dews.url.getApiUrl('TR', 'TreasuryCommonService', 'company'), {
          async : false
        }).done(function(data) {
          companyInfo = data[0];
        }).fail(function (xhr, status, error){
          dews.error(error);
        });
        return companyInfo;
      },

      /**
       * @method 계정정보
       * @param {*} company_cd 회사코드
       * @param {*} gaap_cd 계정유형코드
       * @param {*} acctattr_cd 계정코드
       */
      getAccountMaster : function(company_cd, gaap_cd, acct_cd) {
        var rows = [];

        dews.api.get(dews.url.getApiUrl('TR', 'TreasuryCommonService', 'accountMaster'), {
          async : false,
          data : {
            company_cd : company_cd,
            gaap_cd : gaap_cd,
            acct_cd : acct_cd,
          }
        }).done(function(data) {
          if(data.length > 0){
            rows = data;
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });

        return rows;
      },
      /**
       * @method 계정정보
       * @param {*} acct_cd 계정코드
       */
        getAccountMaster : function(acct_cd) {
          var rows = [];

          dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'accountMaster'), {
            async : false,
            data : {
              acct_cd : acct_cd
            }
          }).done(function(data) {
            if(data.length > 0){
              rows = data;
            }
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error(error);
          });
          return rows;
        },
      /**
       * @method 계정정보
       * @param {*} acctattr_cd 계정속성코드
       */
      getAccountMasterHasAttr : function(acctattr_cd) {
        var rows = [];

        dews.api.get(dews.url.getApiUrl('TR', 'TreasuryCommonService', 'accountMasterHasAttr'), {
          async : false,
          data : {
            acctattr_cd : acctattr_cd
          }
        }).done(function(data) {
          if(data.length > 0){
            rows = data;
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });

        return rows;
      },

      /** @method 파이프형태의 문자열에 포함되는 문자여부 검사
        * @description 파이프형태의 스트링 값에 포함되는 문자를 검사한다. ex. "21|22|23" 안에 "21"이 있는지 검사
        * @param {string} compareText 비교할 문자
        * @param {number} pipeString 비교대상 문자(파이프형태)
      */
      isContain : function(compareText, pipeString) {
        try {
          if(compareText == null || pipeString == null) {
            throw "parameters is null";
          } else {
            var containString = pipeString.split("|");
            if($.inArray(compareText, containString) != -1) {
              return true;
            } else {
              return false;
            }
          }
        } catch (error) {
          console.error(error);
        }
      },

      /**
       * @method 바이트 크기를 파일사이즈로 변환
       * @param {*} bytes 바이트크기
       */
      getByteToSize : function(bytes) {
        var bytes=parseInt(bytes);

        var s = ['bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
        var e = Math.floor(Math.log(bytes)/Math.log(1024));

        if(typeof s[e] == 'undefined') {
          s[e] = 'KB';
        }
        if(e < 0) {
          return "0 "+s[e];
        } else {
          return (bytes/Math.pow(1024,Math.floor(e))).toFixed(2)+s[e];
        }
      },

      /**
       * @method 채번
       * @param {*} module_cd 모듈코드
       * @param {*} class_cd 항목코드
       * @param {*} ymd 날짜
       */
      getSequenceNumber : function(module_cd, class_cd, ymd) {
        var sequenceNumber;

        dews.api.get(dews.url.getApiUrl('TR', 'TreasuryCommonService', 'sequenceNumber'), {
          async : false,
          dataType : "text",
          data : {
            module_cd : module_cd,
            class_cd : class_cd,
            ymd : dews.date.format(ymd, "yyyyMMdd")
          }
        }).done(function(data) {
          if(data.length > 0){
            sequenceNumber = data;
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
        return sequenceNumber;
      },

      /**
       * @method 예산금액 정보
       * @param {*} bg_cd 예산코드
       * @param {*} bizplan_cd 사업계획코드
       * @param {*} bgacct_cd 예산계정코드
       * @param {*} ym 실행년월
       * @param {*} request_amt 신청금액
       */
      getBmControl : function(bg_cd, bizplan_cd, bgacct_cd, ym, request_amt) {
        var bmControl = {};
        if(ym instanceof Date) {
          ym = dews.date.format(ym, 'yyyyMMdd');
        }
        dews.api.get(dews.url.getApiUrl("TR", "TreasuryCommonService", "bmControl"),{
          async : false,
          data : {
            bg_cd : bg_cd,
            bizplan_cd : bizplan_cd,
            bgacct_cd : bgacct_cd,
            ym : ym,
            am_request : request_amt
          }
        }).done(function(data){
          if(data != null) {
            bmControl = data;
          }
        }).fail(function(e){        	
        	if(e && e.responseJSON && e.responseJSON.message)
          	  dews.ui.snackbar.error(e.responseJSON.message);	      	  
	        else
	      	  dews.ui.snackbar.error(dews.localize.get("예산 정보를 가져 올 수 없습니다.", "M0004190", '', 'FI_COMDIC'));
        });
        return bmControl;
      },

      /**
       * @method 어음정보
       * @description 연동항목코드에 따른 어음정보
       * @param {company_cd, relation_cd, bil_no} params
       */
      getBilMaster : function(params) {
        var bilDocument = {};

        try {
          if($.isEmptyObject(params)) {
            throw "parameter is undefined";
          }
          dews.api.get(dews.url.getApiUrl('TR', "TreasuryCommonService", "bill"), {
            async : false,
            data : {
              company_cd : params.company_cd,
              relation_cd : params.relation_cd,
              bil_no : params.bil_no
            }
          }).done(function(data) {
            if(data.length > 0){
              bilDocument = JSON.parse(data);
            }
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error(error);
          });

        } catch (error) {
          console.error(error)
        }
        return bilDocument;
      },
      /**
       * @method 회사모듈정보
       * @description 회사모듈정보
       * @param {*} module_cd
       */
      getCompanyModuleInfo : function(module_cd) {
        var list = [];

        dews.api.get(dews.url.getApiUrl("TR", "TreasuryCommonService", "company-module-info"), {
          async : false,
          data : {
            module_cd : module_cd || ""
          }
        }).done(function(data){
          if(data.length > 0) {
            list = data;
          }
        }).fail(function(xhr, status, error){
          dews.ui.snackbar.error(error);
        });
        if(list.length == 1) {
          return list[0];
        }
        return list;
      },
      /**
       * @method 암호화사용여부
       * @description 암호화사용여부
       * @param {*} encrypt_st
       */
       isUseBlackBoxPolicy : function(encrypt_st) {
        var isUseBlackBoxPolicy;

        dews.api.get(dews.url.getApiUrl("TR", "TreasuryCommonService", "isUseBlackBoxPolicy"), {
          async : false,
          data : {
            encrypt_st : encrypt_st
          }
        }).done(function(data){
          isUseBlackBoxPolicy = data;
        }).fail(function(xhr, status, error){
          dews.ui.snackbar.error(error);
        });
        return isUseBlackBoxPolicy;
      },
    };
  })();

  module.dateUtil = {
    lastDate : function(date) {
      var lastDate;
      if(date) {
        date = date instanceof Date ? date : dews.date.parse(date, "yyyyMMdd");
        date.setMonth(date.getMonth() + 1);
        date.setDate(0);
        lastDate = dews.date.format(date, "yyyyMMdd");
      }
      return lastDate;
    },

    timeFormat : function(date) {
      if(date instanceof Date) {
        return kendo.toString(date, "HH:mm:ss");
      } else if(date.length == 6) {
        return dews.string.format("{0}:{1}:{2}", date.substring(0,2), date.substring(2,4), date.substring(4,6));
      }
    }
  }

  module.polyFill = (function() {
    //Array Polyfill
    if (!Array.prototype.findIndex) {
      Object.defineProperty(Array.prototype, 'findIndex', {
        value: function (predicate) {
          'use strict';
          if (this == null) {
            throw new TypeError('Array.prototype.findIndex called on null or undefined');
          }
          if (typeof predicate !== 'function') {
            throw new TypeError('predicate must be a function');
          }
          var list = Object(this);
          var length = list.length >>> 0;
          var thisArg = arguments[1];
          var value;

          for (var i = 0; i < length; i++) {
            value = list[i];
            if (predicate.call(thisArg, value, i, list)) {
              return i;
            }
          }
          return -1;
        },
        enumerable: false,
        configurable: false,
        writable: false
      });
    }

    if (!Array.prototype.find) {
      Object.defineProperty(Array.prototype, 'find', {
        value: function(predicate) {
        // 1. Let O be ? ToObject(this value).
          if (this == null) {
            throw new TypeError('"this" is null or not defined');
          }

          var o = Object(this);

          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;

          // 3. If IsCallable(predicate) is false, throw a TypeError exception.
          if (typeof predicate !== 'function') {
            throw new TypeError('predicate must be a function');
          }

          // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
          var thisArg = arguments[1];

          // 5. Let k be 0.
          var k = 0;

          // 6. Repeat, while k < len
          while (k < len) {
            // a. Let Pk be ! ToString(k).
            // b. Let kValue be ? Get(O, Pk).
            // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
            // d. If testResult is true, return kValue.
            var kValue = o[k];
            if (predicate.call(thisArg, kValue, k, o)) {
              return kValue;
            }
            // e. Increase k by 1.
            k++;
          }

          // 7. Return undefined.
          return undefined;
        },
        configurable: true,
        writable: true
      });
    }

    if (!Array.prototype.includes) {
      Object.defineProperty(Array.prototype, 'includes', {
        value: function(searchElement, fromIndex) {

          if (this == null) {
            throw new TypeError('"this" is null or not defined');
          }

          // 1. Let O be ? ToObject(this value).
          var o = Object(this);

          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;

          // 3. If len is 0, return false.
          if (len === 0) {
            return false;
          }

          // 4. Let n be ? ToInteger(fromIndex).
          //    (If fromIndex is undefined, this step produces the value 0.)
          var n = fromIndex | 0;

          // 5. If n ≥ 0, then
          //  a. Let k be n.
          // 6. Else n < 0,
          //  a. Let k be len + n.
          //  b. If k < 0, let k be 0.
          var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

          function sameValueZero(x, y) {
            return x === y || (typeof x === 'number' && typeof y === 'number' && isNaN(x) && isNaN(y));
          }

          // 7. Repeat, while k < len
          while (k < len) {
            // a. Let elementK be the result of ? Get(O, ! ToString(k)).
            // b. If SameValueZero(searchElement, elementK) is true, return true.
            if (sameValueZero(o[k], searchElement)) {
              return true;
            }
            // c. Increase k by 1.
            k++;
          }

          // 8. Return false
          return false;
        }
      });
    }
    if (!Array.prototype.flat != 'function') {
      Object.defineProperty(Array.prototype, "flat", {
        configurable: !0,
        value: function r() {
          var t = isNaN(arguments[0]) ? 1 : Number(arguments[0]);
          return t ? Array.prototype.reduce.call(this, function (a, e) {
            return Array.isArray(e) ? a.push.apply(a, r.call(e, t - 1)) : a.push(e), a;
          }, []) : Array.prototype.slice.call(this);
        },
        writable: !0
      });
    }

    if (!Array.prototype.flatMap != 'function') {
      Object.defineProperty(Array.prototype, "flatMap", {
        configurable: !0,
        value: function (r) {
          return Array.prototype.map.apply(this, arguments).flat();
        },
        writable: !0
      });
    }
  })();

  /* API END */

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=tr.js
