/*********************************************************************************************
  @desc   SS 모듈 공통 함수
  @author landameizer
  @date   2019.07.09
  @path   /view/js/sd.js
  @notice 상속할 js파일은 최하단에 기술 할 것
  var sdJS;
  dews.ajax.script('~/view/js/SS/ss.js', {
    once: true,
    async: false
  }).done(function() {
    sdJS = gerp.SS;
  });
**********************************************************************************************/
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'SS';  // 모듈코드

  //공통
  module.com = {
    /*********************************************************************************************
     *  @desc  에러 상세현황 팝업창 오픈
     *  @param {Object} error [필수] 에러객체
     *  @ex  sdJS.com.detailErrorPop(error);
     * ------------------------------------------------------------------------------------------*/
    detailErrorPop: function(error){
      if(module.com.isNull(error)){
        console.error("sdJS - detailErrorPop: 오류 파라미터가 없습니다.", error);
      } else if(!error.hasOwnProperty('errorMessage')){ // Back단(sd-common)의 SdCommonUtilError를 파라미터로 받을것.
        console.error("sdJS - detailErrorPop: 오류 파라미터가 SS-오류객체가 아닙니다.", error);
        dews.error(dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
      } else{
        var dialog = dews.ui.dialog("H_SD_ERROR_PAGE_C",{
          url: "~/codehelp/SD/H_SD_ERROR_PAGE_C",
          title: "오류",
          width: "700",
          height: "300"
        });
        dialog.setInitData({
          error: error
        });
        dialog.open();
      }
    },
    /*********************************************************************************************
     *  @desc  분기에 따라 해당메뉴로 이동하는 메소드
     *  @param {Object} orgMenu  데이터 보내는 메뉴명
     *  @param {string} doctp    문서 구분코드(분기)
     *  @param {string} docno    문서 번호
     *  @ex    sdJS.com.linkToSdMenu("SLSSOR00100", data[0].doctp, data[0].docno);
     * ------------------------------------------------------------------------------------------*/
    linkToSdMenu: function(orgMenu, doctp, docno, dt, otherParams){
      var date = dt || dews.date.format(new Date(), 'yyyyMMdd');
      var strMenuNm = ""; //catch문에서 사용될 메뉴명
      try{
        if(docno){
          switch(doctp){
            case "SO1":{ //수주
              strMenuNm = '수주현황';
              var param = { menuID: orgMenu, sodoc_no: docno, so_dt: date};
              dews.ui.openMenu("SS", "SSOSOR00100", true, param);
              break;
            }
            case "PR1":  //구매요청
            case "PR2":{ //구매요청(직납)
              strMenuNm = '구매요청현황';
              var param = { menuID: orgMenu, purreq_no: docno };
              dews.ui.openMenu("PU", "PUOPRQ00300", true, param);
              break;
            }
            case "DLV":{ //납품지시
              strMenuNm = '납품지시현황';
              var param = { menuID: orgMenu, dlvdoc_no: docno, do_dt: date };
              dews.ui.openMenu("SD", "SHPSDR00300", true, param);
              break;
            }
            case "DLV2":{ //반품지시
              strMenuNm = '반품지시현황';
              var param = { menuID: orgMenu, dlvdoc_no: docno, do_dt: date };
              dews.ui.openMenu("SD", "SHPSDR00800", true, param);
              break;
            }
            case "GI1":{ //출고
              strMenuNm = '출고현황';
              var param = { menuID: orgMenu, gidoc_no: docno, invtrx_dt: date };
              dews.ui.openMenu("SD", "SHPDLV00400", true, param);
              break;
            }
            case "GI2":{ //반품
              strMenuNm = '출고반품현황';
              var param = { menuID: orgMenu, gidoc_no: docno, invtrx_dt: date };
              dews.ui.openMenu("SD", "SHPDLV00500", true, param);
              break;
            }
            case "BIL":{ //매출
              strMenuNm = '매출현황';
              var param = { menuID: orgMenu, billdoc_no: docno };
              dews.ui.openMenu("SD", "BILBIV00300", true, param);
              break;
            }
            case "FI":{ //FI전표
              strMenuNm = '전표조회승인';
              var param = { menuID: orgMenu, docu_no: docno , pc_cd: otherParams.pc_cd};
              dews.ui.openMenu("FI", "GLDDOC00700", true, param);
              break;
            }
            case "CO":{ //CO전표
              strMenuNm = '수익성전표조회';
              var param = { menuID: orgMenu,
                            padoc_no: docno,
                            yyyyMMstart: otherParams.yyyyMMstart,
                            yyyyMMend:otherParams.yyyyMMend };
              dews.ui.openMenu("CO", "PANPIA00100", true, param);
              break;
            }
            case "TRX":{ //수불
              strMenuNm = '재고전기내역조회';
              var param = {
                trans_menu_id: orgMenu,
                trans_no_mtldoc: docno
              };
              dews.ui.openMenu("IM", "IMARTP00200", true, param);
              break;
            }
            case "MTR":{ //자재원장
              strMenuNm = '자재원장문서조회';
              var param = {
                menuID: orgMenu,
                yyyyMMstart: date,
                yyyyMMend: date,
                mldoc_no: docno,
                plant_cd : otherParams.plant_cd
              };
              dews.ui.openMenu("CO", "MLEMIA00100", true, param);
              break;
            }
            default : {
              dews.alert("분기에 없는 파라미터가 입력되었습니다.","warning");
            }
          }
        }
      }catch(e){
        dews.alert(strMenuNm+" 메뉴의 권한이 없습니다.","warning");
      }
    },
    /*********************************************************************************************
     *  @desc  에러 발생시 에러 내용 띄워주는 팝업
     *  @param {Array}  errList  에러 리스트
     *  @param {String} title    에러 팝업창 타이틀
     *  @ex  sdJS.com.openErrPop(errList);
     * ------------------------------------------------------------------------------------------*/
    openErrPop: function(errList, title){
      var dialog = dews.ui.dialog("H_SD_ERROR_C2",{
        url: "/codehelp/SD/H_SD_ERROR_C2",
        title: title || '저장실패',
        width: "700",
        height: "300"
      });
      dialog.setInitData(errList);
      dialog.open();
    },
    /*********************************************************************************************
     *  @desc  문자열의 byte를 체크하는 메소드
     *  @param {char} ch    byte를 체크할 문자열
     *  @ex    sdJS.com.charByteSize("A");
     * ------------------------------------------------------------------------------------------*/
    charByteSize: function (ch) {
      var charCode = ch.charCodeAt(0);
      if (ch == null || ch.length == 0) {
        return 0;
      }
      if (charCode <= 0x00007F) {
        return 1;
      } else if (charCode <= 0x0007FF) {
        return 2;
      } else if (charCode <= 0x00FFFF) {
        return 3;
      } else {
        return 4;
      }
    },
    /*********************************************************************************************
     *  @desc  그리드 데이터를 단순히 보여주기위한 도움창 오픈
     *  @param {Object} grid    [필수]그리드 객체
     *  @param {Array}  columns [필수]도움창에서 보여줄 그리드의 컬럼명 배열(String-Array)
     *  @param {Object} options 옵션객체 - rowNo, title, size, rowData, footer
     *  @ex    sdJS.com.openView(self.mstGrid, ['COMP_CD', 'COMP_NM', 'ITEM_QT'], {});
     * ------------------------------------------------------------------------------------------*/
    openView: function(grid, columns, options){
      var dialog = dews.ui.dialog("H_SD_VIEW_C", {
        helpCustom: true,
        url: "/codehelp/SD/H_SD_VIEW_C",
        title: "자세히",
        size: 'medium'
      });

      // 파라미터 세팅
      dialog.setInitData({
        grid: grid,
        columns: columns,
        options: options,
        flag: true
      });

      dialog.open(); // 도움창 오픈
    },
    /*********************************************************************************************
     *  @desc  그리드 데이터를 단순히 보여주기위한 도움창 오픈
     *  @param {String} code   [필수]js내 sdPreDefinedColumns변수에 미리 선언해둔 컬럼 정보 사용.
     *  @param {Array}  data   [필수]도움창에서 보여줄 그리드 데이터
     *  @param {Object} options 옵션객체 - rowNo, title, size
     *  @ex    sdJS.com.openView('SC', [{SCALE_SQ: 1, SCALE_QT: 5, UNIT_CD: 'EA', PRC_AMT: '5000'}], {});
     * ------------------------------------------------------------------------------------------*/
    openDefinedView: function(code, data, options){
      var codeBool = sdPreDefinedColumns.hasOwnProperty(code);
      var dataBool = data && Array.isArray(data);
      var bool = false;

      if(!codeBool){
        console.error("sdJS - openDefinedView: 선언된 코드값이 없습니다.", code);
      } else if(!dataBool){
        console.error("sdJS - openDefinedView: 표시할 데이터가 없습니다.", data);
      } else{
        var dialog = dews.ui.dialog("H_SD_VIEW_C", {
          helpCustom: true,
          url: "/codehelp/SD/H_SD_VIEW_C",
          title: "자세히",
          size: 'medium'
        });

        // 파라미터 세팅
        dialog.setInitData({
          preDefinedColumns: sdPreDefinedColumns[code],
          data: data,
          options: options,
          flag: false
        });

        dialog.open(); // 도움창 오픈
        bool = true;
      }
      return bool;
    },
    /*********************************************************************************************
     * @desc   날짜 계산(+, -) 함수
     * @param  {Date/String} date      [필수] 날짜
     * @param  {String}      format    [필수] 날짜포맷 - DT : 날짜&시간 (예: yyyyMMddHHmmss), D : 날짜 (예: yyyyMMdd), M : 월 (예: yyyyMM), Y : 년 (예: yyyy)
     *                                                  DT2 : 날짜&시간 (예: yyyy-MM-dd HH:mm:ss), D2 : 날짜 (예: yyyy-MM-dd), M2 : 월 (예: yyyy-MM)
     * @param  {object}      calculate [필수] 날짜 계산  -  [1, 0, -1] ] - 년도 +1, 월 +0, 일 -1
     * @return {String}      계산된 날짜 반환 ex] - "20200120"
     * @ex     sdJS.com.makeDate(new Date(), 'D');
     * ------------------------------------------------------------------------------------------*/
    makeDate: function(p_date, format, calculate){
      var dataFormat;
      var dataFormat2;
      var flag = true;
      var day2;
      calculate = (calculate == undefined ? [0,0,0] : calculate);
      if(!p_date || !calculate){
        console.error("sdJS - dateMake: 함수 인자가 잘못되었습니다 -");
        return '';
      } else{
        if(format == 'DT' || format == 'D' || format == 'M' || format == 'Y'){ // 날짜포맷 유효성 체크
          dataFormat = dews.getFormatFromAlias(format, flag);
        } else if(format == 'DT2' || format == 'D2' || format == 'M2'){
            if(format == 'DT2') format = 'DT'
            else if(format == 'D2') format = 'D'
            else if(format == 'M2') format = 'M'
            flag = false;
          dataFormat = dews.getFormatFromAlias(format, flag);
        } else {
          console.error("sdJS - dateCalculate: 함수 인자(format)가 잘못되었습니다.", format);
          return '';
        }

        if(typeof p_date === 'object' && p_date instanceof Date){ // date의 타입이 Date
          date = dews.date.format(p_date, dataFormat);
          if(!flag){
            dataFormat2 = dews.getFormatFromAlias(format, !flag);
            day2 = dews.date.format(p_date, dataFormat2);
          }
        } else{
          console.error("sdJS - dateCalculate: 함수 인자(p_date)가 잘못되었습니다.", p_date);
          return '';
        }

        var day;
        var dateChange = [];

        dateChange.push(dews.date.parse(p_date, dataFormat).getFullYear());
        dateChange.push(dews.date.parse(p_date, dataFormat).getMonth());
        dateChange.push(dews.date.parse(p_date, dataFormat).getDate());
        dateChange.push(dews.date.parse(p_date, dataFormat).getHours());
        dateChange.push(dews.date.parse(p_date, dataFormat).getMinutes());
        dateChange.push(dews.date.parse(p_date, dataFormat).getSeconds());

        if(calculate[0]) dateChange[0] += calculate[0]
        if(calculate[1]) dateChange[1] += calculate[1]
        if(calculate[2]) dateChange[2] += calculate[2]

        for(var i=0;i<dateChange.length;i++){
          if(i != 0){
            if(i == 1){
              if(dateChange[i] < 10) dateChange[i] = '0' + (dateChange[i] + 1).toString();
              else dateChange[i] = (dateChange[i] + 1).toString();

              if(flag) day += dateChange[i];

              if(format == 'M') {
                if(!flag) day += dateChange[i];
                break;
              }
              if(!flag) day += dateChange[i] + '-';
            } else {
              if(dateChange[i] < 10) dateChange[i] = '0' + dateChange[i].toString();
              else dateChange[i] = dateChange[i].toString();

              if(flag) day += dateChange[i];
              else {
                if(i <= 3) day += dateChange[i];
                else day += ':' + dateChange[i];
              }

              if(i == 2){
                if(format == 'D') break;
                if(!flag) day += ' '
              }
            }
          } else {
            day = dateChange[i];
            if(format == 'Y') break;
            if(!flag) day = dateChange[i] + '-';
          }
        }
      }
      return day.toString();
    },
    /*********************************************************************************************
     * @desc   그리드 현재행의 null여부확인용 함수
     * @param  {String}      self      [필수]해당 메뉴의 this(dewself/self)
     * @param  {String}      gridNm    [필수] 그리드
     * @param  {String}      colNm     [필수] 칼럼
     * @return {String}      그리드의 칼럼값
     * @ex     sdJS.com.gridValNullCheck("claimGrid","_uid")
     * ------------------------------------------------------------------------------------------*/
    gridValNullCheck: function(self, gridNm, colNm){
      if(!self || !gridNm || !colNm){
        console.error("sdJS - gridValNullCheck: 함수 인자가 잘못되었습니다 -");
        return "";
      }

      var colValue = self[gridNm].getCellValue(self[gridNm].select(),colNm);
      if(colValue == undefined || colValue == null || colValue == ""){
        return "";
      }else{
        return colValue;
      }
    },
    calculateItemUm: function(v1, v2) { // 판매단가 계산식
      // v1: 판매단가, v2: 수량
      let item_um = Math.round(v1);             // 판매단가
      let sell_amt = item_um * v2;              // 판매금액
      let tax_amt = Math.ceil(sell_amt * 0.1);  // 세액
      let sum_am_item = sell_amt + tax_amt;     // 합계금액

      let array = new Array();
      array.push(item_um); array.push(sell_amt); array.push(tax_amt); array.push(sum_am_item);
      return array;
    },
    calculateSellAmt: function(v1, v2) { // 판매금액 계산식
      // v1: 판매금액, v2: 수량
      let sell_amt = Math.round(v1);            // 판매금액
      let item_um = Math.round(v1 / v2);        // 판매단가
      let tax_amt = Math.ceil(sell_amt * 0.1);  // 세액
      let sum_am_item = sell_amt + tax_amt;     // 합계금액

      let array = new Array();
      array.push(item_um); array.push(sell_amt); array.push(tax_amt); array.push(sum_am_item);
      return array;
    },
    calculateSumAmItem: function(v1, v2) { // 합계금액 계산식
      // v1: 합계금액, v2: 수량
      let sum_am_item = Math.round(v1);             // 합계금액
      let sell_amt = Math.round(sum_am_item / 1.1); // 판매금액
      let tax_amt = sum_am_item - sell_amt;         // 세액
      let item_um = Math.round(sell_amt / v2);      // 판매단가

      let array = new Array();
      array.push(item_um); array.push(sell_amt); array.push(tax_amt); array.push(sum_am_item);
      return array;
    },
    getCloseYn: function(v1, callback) { // 마감여부 조회
      // v1: SO_DT(수주일) - String
      let so_dt;

      if(typeof(v1) == "string") { // 수주일이 string형이면, 그대로 사용
        so_dt = v1;
      }
      else if(typeof(v1) == "object") { // 수주일이 object형(Date)이면, string으로 변환 작업
        if((v1.getMonth() + 1).toString().length == 1) {
          so_dt = v1.getFullYear().toString() + "0" + (v1.getMonth() + 1).toString();

          if(v1.getDate().toString().length == 1) {
            so_dt += "0" + v1.getDate().toString();
          }
          else {
            so_dt += v1.getDate().toString();
          }
        }
        else {
          so_dt = v1.getFullYear().toString() + (v1.getMonth() + 1).toString() + v1.getDate().toString();

          if(v1.getDate().toString().length == 1) {
            so_dt += "0" + v1.getDate().toString();
          }
          else {
            so_dt += v1.getDate().toString();
          }
        }
      }

      dews.api.get(dews.url.getApiUrl("SS", "SsCommonService", "get_close_yn"), {
        async: false,
        data: {
          so_dt: so_dt
        }
      }).done(function (data) {
        if(data) { // 마감
          dews.alert(data.substring(0, 4) + "년도 " + data.substring(4, 6) + "월은 마감되어 마감취소 이후\n입력/수정/삭제 가능합니다.", "warning");
          callback();
        }
      }).fail(function (xhr, status, error) {
      }).always(function () {
      });
    },
    getCloseYnMulti: function(v1, callback) { // 마감여부 조회(다중 처리)
      // v1: SO_DT(수주일) - List<String>
      let so_dt_list = new Array();
      let temp;

      for(let i = 0; i < v1.length; i++) {
        temp = v1[i].SO_DT

        if(typeof(temp) == "string") { // 수주일이 string형이면, 그대로 사용
          so_dt_list.push(temp);
        }
        else if(typeof(temp) == "object") { // 수주일이 object형(Date)이면, string으로 변환 작업
          if((temp.getMonth() + 1).toString().length == 1) {
            if(temp.getDate().toString().length == 1) {
              so_dt_list.push(temp.getFullYear().toString() + "0" + (temp.getMonth() + 1).toString() + "0" + temp.getDate().toString());
            }
            else {
              so_dt_list.push(temp.getFullYear().toString() + "0" + (temp.getMonth() + 1).toString() + temp.getDate().toString());
            }
          }
          else {
            if(temp.getDate().toString().length == 1) {
              so_dt_list.push(temp.getFullYear().toString() + (temp.getMonth() + 1).getMonth().toString() + "0" + temp.getDate().toString());
            }
            else {
              so_dt_list.push(temp.getFullYear().toString() + (temp.getMonth() + 1).getMonth().toString() + temp.getDate().toString());
            }
          }
        }
      }

      dews.api.post(dews.url.getApiUrl("SS", "SsCommonService", "get_close_yn_multi"), {
        async: false,
        data: {
          so_dt_list: JSON.stringify(so_dt_list)
        }
      }).done(function (data) {
        if(data) { // 마감
          dews.alert(data.substring(0, 4) + "년도 " + data.substring(4, 6) + "월은 마감되어 마감취소 이후\n입력/수정/삭제 가능합니다.", "warning");
          callback();
        }
      }).fail(function (xhr, status, error) {
      }).always(function () {
      });
    }
  };

  //API
  module.api = {
    /* --------------------------------------------------------------------------------------------
      *  @desc           그리드용 중복체크 함수
      *  @param          - parameters : 테이블 및 컬럼 정보 객체(table_nm, column_cd, column_nm, pk_cd)
      *                    >> 리턴받올 column_nm의 값이 없다면 공백('')으로 넘길것
      *                  - grid       : grid 객체
      *                  - flag       : 1/2/3 - 1: front만 체크, 2: back만 체크, 3:front, back 모두 체크
      *  @return         중복되는 코드가 있을시 : 중복데이터 object(pk_cd, pk_nm)
      *                                 없을시 : null
      *
      *  @ex             var parameters = {               |              var parameters = {
      *                    table_nm: 'IE_ECI_MST',        |               table_nm: 'LE_ROUTE_MST',
      *                    column_cd: 'INVC_NO',          |               column_cd: 'TRNSPROUTE_CD',
      *                    column_nm: '',                 |               column_nm: 'TRNSPROUTE_NM',
      *                    pk_cd: 'INVC-20190709-01'      |                pk_cd: 'SP001'
      *                  };                               |             };
      *
      *                  var result = sdJS.api.dupleChk(parameters, mstGrid, 2);
      * ------------------------------------------------------------------------------------------*/
    dupleChk : function (parameters, grid, flag){
      {
        flag = (flag == undefined ? 3 : flag);
        var result = null; // return 값(null or 객체)
        var table_nm = parameters.table_nm.toUpperCase();
        var column_cd = parameters.column_cd.toUpperCase();
        var column_nm = parameters.column_nm.toUpperCase();
        var pk_cd = parameters.pk_cd;
        var deleted_list = grid.dataSource.getDirtyData().Deleted;
        var grid_list = grid.dataItems();
        var msg = "sdJS - dupleChk 함수의 중복체크를 위한 파라미터가 부족합니다.\n";
      }
      // parameter 누락 체크
      if(!parameters.hasOwnProperty('column_cd')){
        console.error(msg + "parameters.column_cd");
        return null;
      } else if(!parameters.hasOwnProperty('column_nm')){
        column_nm = '';
        // console.error(msg + "parameters.column_nm");
        // return null;
      } else if(!parameters.hasOwnProperty('pk_cd')){
        console.error(msg + "parameters.pk_cd");
        return null;
      } else if(!parameters.hasOwnProperty('table_nm') && (flag == 2 || flag == 3)){
        console.error(msg + "parameters.table_nm");
        return null;
      }
      // Front단 체크
      // - 프론트 그리드 내에서 데이터 중복 체크
      if(flag == 1 || flag == 3){
        if(grid_list.length > 0){
          $.each(grid_list, function(idx, item){
            if(grid.dataItem(grid.select()).__UUID != item.__UUID){ // 자기자신과 비교 X
              if(item[column_cd] == pk_cd){
                result = {
                  pk_cd: item[column_cd],
                  pk_nm: item[column_nm]
                };
                return false;
              }
            }
          });
          if(result){
            return result;
          }
        }
        // - 프론트에서 삭제된 행 중 동일한 코드 있다면 조기 리턴
        if(deleted_list.length > 0){
          $.each(deleted_list, function(idx, item){
            if(item[column_cd] == pk_cd){
              result = null;
              return false;
            }
          });
          if(!result){
            return null;
          }
        }
      }
      // Back단 체크
      if(flag == 2 || flag == 3){
        dews.api.get(dews.url.getApiUrl("SS", "SsCommonService", "SdCommon_DupleChk"), {
          async: false,
          data: {
            table_nm: table_nm,
            column_cd: column_cd,
            column_nm: column_nm == null ? null : column_nm,
            pk_cd: pk_cd
          }
        }).done(function (data) {
          if(data.length > 0){
            // 데이터가 한 개만 있다고 가정(PK)
            result = {
              pk_cd: data[0].PK_CD,
              pk_nm: data[0].PK_NM
            };
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
      }
      return (result ? result : null);
    },
    /* --------------------------------------------------------------------------------------------
      *  @desc           그리드용 중복체크 함수
      *  @param          - parameters : 테이블 및 컬럼 정보 객체(table_nm, column_cd, column_nm, pk_cd)
      *                    >> 리턴받올 column_nm의 값이 없다면 공백('')으로 넘길것
      *                  - grid       : grid 객체
      *                  - flag       : 1/2/3 - 1: front만 체크, 2: back만 체크, 3:front, back 모두 체크
      *  @return         없을시 : 0
      *                  front에서 중복되는 코드가 있을시 :  1
      *                  back에서 중복되는 코드가 있을시 : 2
      *
      *  @ ex  front     var parameters = {
      *                    menuID: 'CLMCMD00400',
      *                    pk_cd: {
      *                      CSF_CD: e.grid.getCellValue(e.grid.select(), 'CSF_CD'),
      *                      TRMT_MANUAL_CD: e.grid.getCellValue(e.grid.select(), 'TRMT_MANUAL_CD')
      *                    }
      *                  };
      *                  var result = sdJS.api.dupleCheck(parameters, self.dtlGrid);
      *
      *        back      => SdCommon_dupleCheck_Enum 클래스에서 [메뉴, 테이블, 칼럼, 칼럼명] 매핑시켜줘야 함
      * ------------------------------------------------------------------------------------------*/
     dupleCheck : function (parameters, grid, flag){
      {
        flag = (flag == undefined ? 3 : flag);
        var result = null;
        var menuID = parameters.menuID;
        var pk_cd = parameters.pk_cd;
        var deleted_list = grid.dataSource.getDirtyData().Deleted;
        var grid_list = grid.dataItems();
        var msg = "sdJS - dupleChk 함수의 중복체크를 위한 파라미터가 부족합니다.\n";
      }
      // parameter 누락 체크
      if(!parameters.hasOwnProperty('menuID') && (flag == 2 || flag == 3)){
        console.error(msg + "parameters.menuID");
        return null;
      }
      // Front단 체크
      // - 프론트 그리드 내에서 데이터 중복 체크
      if(flag == 1 || flag == 3){
        if(grid_list.length > 0){
          $.each(grid_list, function(idx, item){
            if(grid.dataItem(grid.select()).__UUID != item.__UUID){ // 자기자신과 비교 X
              var cnt=0;
              for(var key in pk_cd){
                if(item[key] == pk_cd[key]){
                  cnt++;
                  if(cnt == Object.keys(pk_cd).length){
                    result = 1;
                    return result;
                  }
                }
              }
            }
          });
          if(result){
            return result;
          }
        }
        // - 프론트에서 삭제된 행 중 동일한 코드 있다면 조기 리턴
        if(deleted_list.length > 0){
          $.each(deleted_list, function(idx, item){
            for(var key in pk_cd){
              if(item[key] == pk_cd[key]){
                cnt++;
                if(cnt == Object.keys(pk_cd).length){
                  result = 1;
                  return result;
                }
              }
            }
          });
          if(result){
            return result;
          }
        }
      }

      // Back단 체크
      if(flag == 2 || flag == 3){
        dews.api.post(dews.url.getApiUrl("SS", "SsCommonService", "SdCommon_dupleCheck"), {
          async: false,
          data: {
            menuID: menuID,
            pk_cd: JSON.stringify(pk_cd)
          }
        }).done(function (data) {
          if(data.tp == "F"){
            result = 2;
            var initData = data.errorList;
            dialog = dews.ui.dialog("H_SD_ERROR_C2", {
              url: "/codehelp/SD/H_SD_ERROR_C2",
              title: dews.localize.get("오류메세지", 'D0007709'),
              width: "700",
              height: "300",
              ok: function (d, e) {
              }
            });
            dialog.setInitData(initData);
            dialog.open();
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
      }
      return (result ? result : null);
    },
    /*********************************************************************************************
     *  @desc   데이터소스를 반환
     *  @param  {string}  flag      [필수]어떤 데이터소스를 가져올지 플래그 값
     *  @param  {Boolean} addNull   배열 맨 앞에 공백값 추가 여부
     *  @param  {Object}  params    API에 넘길 파라미터
     *  @param  {Object}  returnArr 단순 배열로 받을 것인지 여부
     *  @return {Object}            데이터소스 객체
     *  @ex     var clasCdDataSource = sdJS.api.getDataSource('DOC_NO', false);
                - 경우에 따라서 addNull, params, returnArr 파라미터는 없어도 됨
                - 해당 데이터에는 clasCdDataSource.options.data로 접근 가능(Array형태)

     ## api 추가시 - 필수 파라미터가 필요하며 누락된 경우, case문에서 apiCall 변수를 false로 줄 것 ##
     * ------------------------------------------------------------------------------------------*/
    getDataSource: function(flag, addNull, params, returnArr){
      var returnDataSource;  // 최종 리턴 데이터소스
      var apiCall = true;    // api호출/비호출 제어를 위한 변수
      var resultArray  = []; // 리턴될 배열
      var dataSourceName = ''; // 리턴될 데이터소스의 명칭
      returnArr = returnArr || false; // 단순 배열로 반환할 것인지 여부값

      // API 변수
      var module_cd = '';
      var serviceName = '';
      var url = '';

      // 넘어온 파라미터값 없으면 빈객체로 초기화
      if(params && !(typeof params == 'object')){
        apiCall = false;
        console.error("sdJS - getDataSource 함수의 파라미터[params]가 object형이 아닙니다.");
      }
      params = params || {};

      // 공백 객체 추가 여부 - 파라미터 없으면 false로 초기화
      addNull = addNull ? true : false;

      /*********************** api분기 *********************/

      switch(flag){
        case 'SO': // 수주유형 - BIZ_DOC_CTGRY_CD를 PARAM으로 받는 API로 수정?
        case 'SO_TP':{
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_SD_SODTYPE_MST_integration";
          dataSourceName = 'soTpCdDataSource';
          break;
        }
        case 'DLV': // 납품유형
        case 'DLV_TP':{
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SD_DLVTYPE_INFO_list';
          dataSourceName = 'dlvTpDataSource';
          break;
        }
        case 'GI': // 출고유형
        case 'GI_TP':{
          // params.gubun = (params.hasOwnProperty('gi_tp') ? params.gi_tp : '');
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SD_GITYPE_INFO_list';
          dataSourceName = 'giTpDataSource';
          break;
        }
        case 'BIL': // 매출유형
        case 'BIL_TP':{
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SD_BILTYPE_INFO_list';
          dataSourceName = 'billTpDataSource';
          break;
        }
        case 'CMNY_TP': // 수금유형 - 파라미터 없을시 전체 조회
        case 'CMNY_INFO':{
          params.gubun      = (params.hasOwnProperty('gubun')      ? params.gubun      : ''); // 메뉴ID[dewself.menu.id]
          params.cmny_tp_cd = (params.hasOwnProperty('cmny_tp_cd') ? params.cmny_tp_cd : ''); // 수금유형코드
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_SD_CMNYTYPE_MST';
          dataSourceName = 'cmnyTpDataSource';
          break;
        }
        case 'CMNY_INFO_new':{ // 수금유형 - 수금종류코드로 조회시 사용
          params.gubun      = (params.hasOwnProperty('gubun')      ? params.gubun      : ''); // 메뉴ID[dewself.menu.id]
          params.cmny_tp_cd = (params.hasOwnProperty('cmny_tp_cd') ? params.cmny_tp_cd : ''); // 수금유형코드
          params.cmny_knd_cd = (params.hasOwnProperty('cmny_knd_cd') ? params.cmny_knd_cd : ''); // 수금종류코드
          params.cmny_fg_cd = (params.hasOwnProperty('cmny_fg_cd') ? params.cmny_fg_cd : ''); // 수금구분코드
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_SD_CMNYTYPE_MST_new';
          dataSourceName = 'cmnyTpDataSource';
          break;
        }
        case 'EC': // EC유형
        case 'EC_TP':{
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_SD_ECTYPE_MST';
          dataSourceName = 'ecTpDataSource';
          break;
        }
        case 'DOC_NO':{ // 자동채번 - module_cd_multi를 파라미터로 받는 API(파라미터 없을시 전모듈 조회)
          params.module_cd_multi = (params.hasOwnProperty('module_cd_multi') ? params.module_cd_multi : '');
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'MA_DOCUCTRL_MST_list_by_params';
          dataSourceName = 'clasCdDataSource';
          break;
        }
        case 'DOC_NO2':{ // 자동채번 - 'SD' 모듈의 채번규칙만 가져옴
          params = {}; // 해당 API의 파라미터 고정
          module_cd   = 'SD';
          serviceName = 'SalesImplementationGuideORTService';
          url         = 'MA_DOCUCTRL_MST_list';
          dataSourceName = 'sdClasCdDataSource';
          break;
        }
        case 'MA_PC':{ // 회계단위
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_MA_PC_MST';
          dataSourceName = 'pcCdDataSource';
          break;
        }
        case 'PRTNRFN_INFO':{ // 영업거래처형태
          if(!params.partner_cd){ // 필수값
            apiCall = false;
            console.error("sdJS - getDataSource[PRTNRFN_INFO] 함수의 파라미터[partner_cd]가 부족합니다.");
            break;
          } else{
            params.partner_cd  = (params.hasOwnProperty('partner_cd')  ? params.partner_cd  : ''); // 거래처코드
            params.use_yn      = (params.hasOwnProperty('use_yn')      ? params.use_yn      : ''); // 사용여부
            params.prtnr_fn_cd = (params.hasOwnProperty('prtnr_fn_cd') ? params.prtnr_fn_cd : ''); // 거래처형태
          }
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_MA_PARTNERFN_INFO';
          dataSourceName = 'prtnrFnDataSource';
          break;
        }
        case 'SAORG_INFO':{ // 영업조직 리스트
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_MA_SAORG_MST";
          dataSourceName = 'saorgCdDataSource';
          break;
        }
        case 'SAOFF_INFO':{ // 사업부 리스트 - 영업영역에 속한 사업부
          params.salesorgn_cd = (params.salesorgn_cd ? params.salesorgn_cd : '');
          params.disch_cd     = (params.disch_cd     ? params.disch_cd     : '');
          params.prductgrp_cd = (params.prductgrp_cd ? params.prductgrp_cd : '');
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_MA_AREAOFF_MST";
          dataSourceName = 'saoffCdDataSource';
          break;
        }
        case 'SALEGRP_INFO':{ // 영업그룹 리스트 - 영업영역에 속한 영업그룹만
          params.salesorgn_cd = (params.salesorgn_cd ? params.salesorgn_cd : '');
          params.disch_cd     = (params.disch_cd     ? params.disch_cd     : '');
          params.prductgrp_cd = (params.prductgrp_cd ? params.prductgrp_cd : '');
          params.saoff_cd     = (params.saoff_cd     ? params.saoff_cd     : '');
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_MA_OFFSGRP_MST";
          dataSourceName = 'salegrpCdDataSource';
          break;
        }
        case 'PAY_INFO':{ // 결제조건마스터
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_MA_PAYMENT_MST";
          dataSourceName = 'terpayCdDataSource';
          break;
        }
        case 'COMM_INFO':{ // 회사환경설정 - 자리수통제 리스트
          module_cd   = 'IM';
          serviceName = 'SCMCommonService';
          url         = "SCMApiProvider_MA_COMMON_CODE_list";
          dataSourceName = 'commonCodeDataSource';
          break;
        }
        case 'IF_INFO':{ // 연동시스템 마스터 중, 해당 RELATION_CD를 갖고있는 데이터 조회(PIPE 다중선택('|'))
          params.relation_cd = module.com.replaceNull(params.relation_cd);
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_CI_SYSTEMIF_MST";
          dataSourceName = 'intlSysCdDataSource';
          break;
        }
        case 'CTRL_CONFIG':{ // module_cd 파라미터 없을시, 'MA'로 가져옴
          params.module_cd = module.com.replaceNull(params.relation_cd, 'MA');
          params.ctrl_cd_pipe = module.com.replaceNull(params.ctrl_cd_pipe);
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_MA_CTRLCONFIG';
          dataSourceName = 'ctrlConfigDataSource';
          break;
        }
        case 'ACCGRP_INFO':{ // 계정처리유형-포스팅유형 리스트
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_getMA_ACCGRP_MST';
          dataSourceName = 'accgrpPostingTpCdDataSource';
          break;
        }
        case 'YN': { // YES/NO 데이터소스
          apiCall = false;
          dataSourceName = 'ynUseDataSource';
          resultArray = [
            { SYSDEF_CD: 'Y', SYSDEF_NM: 'Yes' },
            { SYSDEF_CD: 'N', SYSDEF_NM: 'No'  }
          ];
          break;
        }
        case 'CREDIT_GRP_CD': { // 여신그룹 리스트 (영업거래처등록 메뉴(MA)에서도 사용됨)
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_SD_CREDITGRP_INFO';
          dataSourceName = 'creditGrpCdDataSource';
          break;
        }
        default :{
          apiCall = false;
          console.error("sdJS - getDataSource 함수 인자의 구분값이 잘못되었습니다. flag : ", flag);
          break;
        }
      }
      /*********************** api분기 끝 *********************/

      // ynDataSource가 아니고 api를 태울 필수값을 충족하지 않을시, 리턴할 데이터 세팅
      if(!flag == 'YN' && !apiCall){
        dataSourceName = 'null';
        resultArray = [];
      }

      // API호출 - flag값이 넘어왔으며 API를 호출해야할 경우에만
      if(flag && apiCall && (module_cd || serviceName || url)){
        dews.api.get(dews.url.getApiUrl(module_cd, serviceName, url), {
          async: false,
          data: params
        }).done(function (data) {
          resultArray = data;
        }).fail(function (xhr, status, error) {
          dews.error(error || "데이터소스 호출에 실패했습니다.");
        });
      } else if(flag && apiCall && (!module_cd || !serviceName || !url)){
        console.error("sdJS - getDataSource 함수의 api를 호출할 수 없습니다.");
        if(!module_cd){console.error("- module_cd 없음");}
        if(!serviceName){console.error("- serviceName 없음");}
        if(!url){console.error("- url 없음");}
      }

      // 공백객체 추가
      if(addNull && resultArray.length){module.com.addNullObject(resultArray);}

      // 데이터소스 생성
      if(!returnArr){
        returnDataSource = dews.ui.dataSource(dataSourceName, {
          data: ( resultArray && Array.isArray(resultArray) && resultArray.length > 0 ? resultArray : [] )
        });
      } else{ // 단순 배열로 리턴
        returnDataSource = resultArray;
      }

      return returnDataSource;
    },
    getCreditBalance: function(ctrl_time_cd, credit_no, saleprtn_cd, exch_cd){
      var returnData;
      if(ctrl_time_cd && credit_no){
        dews.api.get(dews.url.getApiUrl("SS", "SsCommonService", "SdCommon_getCreditBalanceInfo"), {
          async: false,
          data: {
            ctrl_time_cd: ctrl_time_cd,
            credit_no: credit_no,
            saleprtn_cd: saleprtn_cd,
            exch_cd: exch_cd
          }
        }).done(function (data) {
          returnData = data;
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get("여신잔액 조회중 에러가 발생하였습니다."));
          return [];
        });
      }else{
        if(!ctrl_time_cd){
          dews.ui.snackbar.warning("여신통제시점코드가 없습니다.");
          return [];
        }else if(!credit_no){
          dews.ui.snackbar.warning("여신관리번호가 없습니다.");
          return [];
        }
      }
      return returnData;
    },
    /*********************************************************************************************
     *  @desc   파라미터로 받은 날짜를 결제조건(MA_PAYMENT_MST)에 따라 계산하여 반환
     *  @param  {String} terpay_cd   [필수] 결제조건 코드
     *  @param  {String} std_dt      [필수] 계산될 날짜. String 또는 Date
     *  @param  {String} calendar_yn 카렌다 사용여부(없을시 기본값 'Y')
     *  @return {String} 계산된 날짜
     *  @ex     var exrt_rt = scmJS.api.getExrt('C000', '20200101', 'N');
     * ------------------------------------------------------------------------------------------*/
    getPaymentDate: function(terpay_cd, std_dt, calendar_yn){
      var rtn_date = ""; // 리턴값.
      var param_date = (typeof std_dt === 'object' && std_dt instanceof Date) ? dews.date.format(std_dt, 'yyyyMMdd') : std_dt;
      calendar_yn = module.com.isNull(calendar_yn) ? 'Y' : calendar_yn; // 없을시 기본값 'Y'
      if(module.com.isNull(terpay_cd) || module.com.isNull(std_dt)){
        console.error("sdJS - getPaymentDate: 함수 인자가 부족합니다.");
      } else if(!(typeof param_date === 'string' && param_date.length === 8 && param_date !== "")){
        console.error("sdJS - getPaymentDate: 날짜 파라미터가 부적절합니다.", std_dt);
      } else{
        dews.api.get(dews.url.getApiUrl("SS", "SsCommonService", "SdCommon_getPaymentDate"), {
          async: false,
          data: {
            terpay_cd   : terpay_cd,
            std_dt      : param_date,
            calendar_yn : calendar_yn
          }
        }).done(function (data) {
          rtn_date = data;
        }).fail(function(xhr, status, error){
          rtn_date = "";
          console.error("sdJS - getPaymentDate: 일치하는 결제조건코드가 없습니다.", terpay_cd);
        });
        return rtn_date;
      }
    }
  };

  //공통 - BAFSDC (여신관리)
  module.bafsdc = {
    /*********************************************************************************************
     *  @desc  (여신관리) 여신통제시점, 여신통제방법, 여신정보테이블 조회 ▶ 라벨 텍스트 셋팅 ▶ 여신정보테이블 코드피커 셋팅
     *  @param {String}  strCreditGrpCd  여신그룹코드
     *  @param {Object}  objSelf         호출되는 메뉴의 this
     *  @return none
     *  @ex  sdJS.bafsdc.getCreditGrpInfo(dewself.s_credit_grp_cd.value(), dewself);
     * ------------------------------------------------------------------------------------------*/
    getCreditGrpInfo: function(strCreditGrpCd, objSelf){
      try{
        if(strCreditGrpCd){
          dews.api.get(dews.url.getApiUrl("SS", "SsCommonService", "SdCommon_SD_CREDITGRP_INFO_ctrl"), {
            async: false,
            data: {
              credit_grp_cd : strCreditGrpCd
            }
          }).done(function (data) {
            if(data.length > 0){
              if(data[0].COND_TABLE_NO == null || data[0].COND_TABLE_NO == ""){
                dews.alert('여신정보테이블 데이터가 없습니다. \r\n여신그룹등록 메뉴에서 등록해주세요.', 'warning');
                return false;
              }

              eval('lbl_time_'+objSelf.menu.id).innerText  = '여신통제시점 : ' + data[0].CTRL_TIME_NM + " | ";
              eval('lbl_method_'+objSelf.menu.id).innerText  = '여신통제방법 : ' + data[0].CTRL_MTHD_NM;
              objSelf.s_cond_table_no.setData({ COND_TABLE_NO: data[0].COND_TABLE_NO, PRC_TABLE_DC: data[0].PRC_TABLE_DC }); //여신정보테이블 셋팅
              dews.ui.mainbuttons.search.click(); //조회
            }
          }).fail(function (xhr, status, error) {
            dews.error(error || dews.localize.get(dews.localize.get("작업이 실패하였습니다.", "M0000055")));
          });
        }
      }catch(e){
        dews.alert('여신부가정보 조회 도중 오류가 발생했습니다.','warning');
        return false;
      }
    },
    /*********************************************************************************************
     *  @desc   (여신관리) 조건테이블에 등록된 여신요소 조회 ▶ 배열변수 생성 및 리턴 (grid 컬럼 동적으로 생성하기 위함)
     *  @param  {String}  strCondTableNo      여신정보테이블 코드
     *  @param  {Boolean} boolSetArea         optional-aera 셋팅 여부
     *  @param  {String}  strMenuId           메뉴ID
     *  @return {Arrays}
     *  @ex  sdJS.bafsdc.getGridColumns(dewself.s_cond_table_no.code(), true, dewself.menu.id)
     * ------------------------------------------------------------------------------------------*/
    getGridColumns: function (strCondTableNo, boolSetArea, strMenuId){
      try{
        var arrRtnColumns = []; //리턴용 배열
        if(strCondTableNo){
          dews.api.get(dews.url.getApiUrl("SD", "BasicFunctionsandMasterDataSDCService", "list_SD_CREDITELE_INFO_forMstGrid"), {
            async: false,
            data: {
              cond_table_no: strCondTableNo
            }
          }).done(function (data) {
            if(data.length>0){
              if(boolSetArea){ //case 1 : optional-aera셋팅함
                if(!strMenuId){
                  dews.alert('그리드 컬럼셋팅을 위한 \r\n여신요소 조회에 실패하였습니다.','warning');
                  return false;
                }
                $.each(data, function (index, item){
                  var tempID = strMenuId.toLowerCase()+'_li_'+item.ELEMENT_FIELD_CD.toLowerCase();
                  $('#'+strMenuId+'_condition').find('#'+strMenuId.toLowerCase()+'_optional_area').find('li:eq('+index+')').before($('#'+tempID));
                  $('#'+strMenuId+'_condition').find("[id="+tempID+"]").css("display", "block");

                  arrRtnColumns.push({ field : item.ELEMENT_FIELD_CD_RE , title : item.ELEMENT_FIELD_NM, align: "left"});
                });
              }else{ //case 2 : optional-aera셋팅안함
                $.each(data, function (index, item){
                  arrRtnColumns.push({ field : item.ELEMENT_FIELD_CD_RE , title : item.ELEMENT_FIELD_NM, align: "left", attributes: { class: "readonly" } });
                });
              }
            }
          }).fail(function (xhr, status, error) {
            dews.error(error || dews.localize.get(dews.localize.get("작업이 실패하였습니다.", "M0000055")));
          });
        }
        return arrRtnColumns;
      }catch(e){
        dews.alert('여신요소 조회 도중 오류가 발생했습니다.','warning');
        return false;
      }
    }
  };

  //공통 - BILCMM (수금관리)
  module.bilcmm = {
    /*********************************************************************************************
     *  @desc  (수금관리) 수금관련 GRID 컬럼 리셋 공통함수 (colArr배열 startIdx 이후의 모든 컬럼 리셋처리)
     *  @param {Object}  objSelf            호출되는 메뉴의 this
    *   @param {String}  strStartFieldNm    기준이 되는 컬럼 이름
     *  @return none
     *  @ex  sdJS.bilcmm.setCellValueInit(self, e.cell.field);
     * ------------------------------------------------------------------------------------------*/
    setCellValueInit: function(objSelf, strStartFieldNm){
      try{
        var colArr = [  'STLM_MTHD_CD',    /*결제방법코드*/   'STLM_MTHD_NM',    /*결제방법명*/
                        'CMNY_ACCT_CD',    /*수금계정코드*/   'CMNY_ACCT_NM',    /*수금계정명*/
                        'CMNY_MNG_NO',     /*수금관리번호*/   'CMNY_MNG_NO_TXT', /*수금관리번호텍스트*/
                        'NATION_CD',       /*국가코드*/       'BANK_CD',         /*은행코드*/
                        'FNLT_NM',         /*금융기관명*/     'FINPRODUCT_FG',   /*금융상품구분*/
                        'FNCPARTNER_CD',   /*금융기관코드*/   'FNCPARTNER_NM',   /*금융기관명*/
                        'FINPRODUCT_NO',   /*금융계좌번호*/   'SELF_ISSUE_YN',   /*자수*/
                        'ISSUE_ISTN_CD',   /*발행기관코드*/   'ISSUE_ISTN_NM',   /*발행기관명*/
                        'PBLISR_NM',       /*발행인*/         'BIL_ST',          /*어음상태*/
                        'BIL_ISSUE_DT',    /*어음발행일*/     'EXPRTN_DT',       /*만기일*/
                        'EXPRTN_DY'        /*어음기간*/
                      ];
        var startIdx = -1; //startIdx 이후의 모든 컬럼 리셋처리
        $.each(colArr, function (index, item){
          if(startIdx > -1){
            objSelf.mstGrid.setCellValue(objSelf.mstGrid.select(), item, '', false);
          }
          if(startIdx == -1 && item == strStartFieldNm){
            startIdx = index;
          }
        });
      }catch(e){
        dews.alert('그리드 컬럼 초기화 작업 도중 오류가 발생했습니다.','warning');
        console.log(e);
        return false;
      }
    },
    /*********************************************************************************************
     *  @desc  (수금관리) 어음기간 계산
     *  @param {Object}  objSelf         호출되는 메뉴의 this
    *   @param {String}  strFieldNm      기준이 되는 컬럼 이름
     *  @return none
     *  @ex  sdJS.bilcmm.setCellValueInit(self, e.cell.field);
     * ------------------------------------------------------------------------------------------*/
    calcExprtnDt: function(strCmnyDt, strExprtnDt){
      try{
        var fDate = dews.date.format( strCmnyDt,   'yyyy-MM-dd').split("-");
        var tDate = dews.date.format( strExprtnDt, 'yyyy-MM-dd').split("-");
        var dateObjFrom = new Date(fDate[0], Number(fDate[1])-1, fDate[2]);
        var dateObjTo = new Date(tDate[0], Number(tDate[1])-1, tDate[2]);
        var betweenDay = (dateObjTo.getTime() - dateObjFrom.getTime())/1000/60/60/24;

        return Math.round(betweenDay);
      }catch(e){
        dews.alert('어음기간 계산 도중 오류가 발생했습니다.','warning');
        console.log(e);
        return false;
      }
    },
    /*********************************************************************************************
     *  @desc  (수금관리) 그리드 유효검사 (1~7)
     *  @param {Object}   objSelf    호출되는 메뉴의 this
     *  @param {Object}   item       유효검사 대상이 되는 그리드 행의 객체
     *  @param {Number}   index      유효검사 대상이 되는 그리드 seq
     *  @return Boolean
     *  @ex  sdJS.bilcmm.validationGridBilcmm(item, 0, self);
     * ------------------------------------------------------------------------------------------*/
    validationGridBilcmm: function(item, index, objSelf){
      try{
        var rtnObj = {}; //리턴용 객체

        //1. 결제방법
        if(!item.STLM_MTHD_CD){
          dews.alert(index+1+" 번째 행의 결제방법은 필수값 입니다.","warning");
          objSelf.mstGrid.select(index, 'STLM_MTHD_NM');
          return false;
        }

        //2. 수금계정
        if(!item.CMNY_ACCT_CD){
          dews.alert(index+1+" 번째 행의 수금계정은 필수값 입니다.","warning");
          objSelf.mstGrid.select(index, 'CMNY_ACCT_NM');
          return false;
        }

        //3. 수금관리번호 (결제방법 in ('12'(예금(뱅킹)),'13'(예금(자동이체)),'15'(어음),'16'(전자어음))일때
        if((item.STLM_MTHD_CD == '12' || item.STLM_MTHD_CD == '13'|| item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && !item.CMNY_MNG_NO){
          dews.alert(index+1+" 번째 행의 수금관리번호는 필수값입니다.","warning");
          if(item.STLM_MTHD_CD == '12' || item.STLM_MTHD_CD == '13'){
            objSelf.mstGrid.select(index, 'CMNY_MNG_NO');
          }else{
            objSelf.mstGrid.select(index, 'CMNY_MNG_NO_TXT');
          }
          return false;
        }

        //4. 자수 (결제방법 in ('15'(어음),'16'(전자어음))일때
        if((item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && (!item.SELF_ISSUE_YN)){
          dews.alert(index+1+" 번째 행의 자수는 필수값입니다.","warning");
          objSelf.mstGrid.select(index, 'SELF_ISSUE_YN');
          return false;
        }

        //5. 발행기관 (결제방법 in ('15'(어음),'16'(전자어음))일때
        if((item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && (!item.ISSUE_ISTN_NM)){
          dews.alert(index+1+" 번째 행의 발행기관은 필수값입니다.","warning");
          objSelf.mstGrid.select(index, 'ISSUE_ISTN_NM');
          return false;
        }

        //6. 발행인 (결제방법 in ('15'(어음),'16'(전자어음))일때
        if((item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && (!item.PBLISR_NM)){
          dews.alert(index+1+" 번째 행의 발행인은 필수값입니다.","warning");
          objSelf.mstGrid.select(index, 'PBLISR_NM');
          return false;
        }

        //7. 만기일 (결제방법 in ('15'(어음),'16'(전자어음))일때
        if((item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && (!item.EXPRTN_DT)){
          dews.alert(index+1+" 번째 행의 만기일은 필수값입니다.","warning");
          objSelf.mstGrid.select(index, 'EXPRTN_DT');
          return false;
        }

        return true;
      }catch(e){
        dews.alert('수금관리 그리드 유효검사 도중 오류가 발생했습니다.','warning');
        console.log(e);
        return false;
      }
    }
  };

  // openDefinedView 메소드 등에서 사용하기 위한 컬럼 미리 선언.
  const sdPreDefinedColumns = {
    SC: { //Scale Info Defined(스케일정보)
      fields: [
        { field: "_uid" },
        { field: "SCALE_SQ" },
        { field: "SCALE_QT" },
        { field: "UNIT_CD" },
        { field: "PRC_AMT" }
      ],
      columns: [
        { field: "SCALE_SQ", title: "순번", width: 40, align: "center" },
        { field: "SCALE_QT", title: "수량", width: 60, align: "right", formats: { type: "number", predefined: true, format: "MA00001"}},
        { field: "UNIT_CD", title: "단위", width: 50, align: "left" },
        { field: "PRC_AMT", title: "가격", width: 120, align: "right" , formats: { type: "number", predefined: true, format: "MA00003"}}
      ]
    }
  };

  // 에러 다이얼로그(sdJS.com의 openErrorPopup 함수) 사용을 위한 에러 리스트
  // 임시로 sql, java라고 명명
  module.errorList = {
    sql: {
      'ORA-00001': "PK 컬럼이 중복 됩니다.",
      'ORA-00904': "존재하지 않는 컬럼 입니다. (부적합한 식별자)",
      'ORA-00911': "문자가 부적합 합니다(';', ',' 등)",
      'ORA-00917': "콤마(,)가 누락되었습니다.",
      'ORA-00923': "FROM 키워드가 필요한 위치에 없습니다",
      'ORA-00933': "SQL 명령어가 올바르게 종료되지 않았습니다",
      'ORA-00936': "누락된 표현식(기호, 괄호, 띄어쓰기 등)",
      'ORA-00942': "테이블 또는 뷰가 존재하지 않습니다.",
      'ORA-00947': "INSERT문의 인자가 충분하지 않습니다.",
      'ORA-01722': "NUMBER 타입에 문자가 삽입되었습니다.",
      'ORA-12899': "컬럼에 설정된 길이보다 긴 값 삽입되었습니다.",
      'ORA-01438': "컬럼에 설정된 길이보다 긴 값 삽입되었습니다.",
      'ORA-01400': "NOT NULL 컬럼에 NULL이 삽입되었습니다.",
      'ORA-01407': "NOT NULL 컬럼에 NULL이 삽입되었습니다.",
      'ORA-01861': "컬럼의 데이터 타입과 인자 타입이 일치하지 않습니다."
    },
    java: {
      'null': "NullPointerException 발생",
      '/ by zero': "0으로 나눌 수 없습니다.",
      'Mapped Statements collection does not contain': "쿼리를 찾을수 없습니다.", // 경우가 여러가지 - namespace 잘못, mybatis id 중복
      'Error converting' : "형변환을 할 수 없습니다."
    }
  };

  /*********************************************************************************************
  *  @desc  js파일 상속
  *  @param {Object} targetJS [필수] js 객체 변수
  *  @ex
  * ------------------------------------------------------------------------------------------*/
  module.extendJS = function(targetJS){
    $.each(Object.keys(targetJS), function(idx, key){
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
         겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName){
        if(keyArr.indexOf(kName) >= 0){
          console.error("js 상속중 동일한 메소드 명이 존재합니다 - ", (key + '.' + kName));
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  }

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  var scmJS;
  dews.ajax.script('~/view/js/MA/ma.scm.js', {
    once: true,
    async: false
  }).done(function() {
    scmJS = gerp.MA;
  });
  module.extendJS(scmJS);

  // ma.scm.msg.js 상속
  // dews.ajax.script('~/view/js/MA/ma.scm.msg.js', {
  //   once: true,
  //   async: false
  // }).done(function() {
  // });
  // module.extendJS(window.gerp.SCM);

  /**********************************************************************************************/

  //-------------------------------------------End-------------------------------------------
  var newModule = {};
  newModule[moduleCode] = module;
  module.formatList = module.api.getCommonFormat(); // 회사환경설정-포맷리스트 세팅(sdJS.formatList)
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/SD/sd.js
