/*
version = '1.0.23072601';
*/
(function(dews, gerp, $) {
  var module = {};
  var lastSelectedControl;
  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'CA'; // 모듈 코드를 입력 해주세요.

  var gridForm;

  module.getNoteCodeData = function(objCodeData, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
    if (!objCodeData.hasOwnProperty(module_cd)) {
      objCodeData[module_cd] = {};
    }
    $.each(field_cd_pipe.split("|"), function (i, v) {
      if (v != null && v != "") {
        objCodeData[module_cd][v] = [];
      }
    });
    dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_ci_codeDtl_list")), {
      async: false,
      data: {
        module_cd: module_cd,          // 모듈
        field_cd_pipe: field_cd_pipe,  // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
        syscode_yn: syscode_yn,        // 시스템코드 유무(Y,N)
        base_yn: base_yn,              // 디폴트 코드구분(Y,N)
        foreign_yn: foreign_yn,        // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
        end_dt: end_dt,                // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
        keyword: keyword,              // 검색할 코드 또는 명
      }
    }).done(function (data) {
      if (data.length > 0) {
        $.each(data, function (i, obj) {
          objCodeData[module_cd][obj.FIELD_CD].push(obj);
        });
      } else {
      }
    }).fail(function (xhr, status, error) {
      //dews.error("코드도움 데이터 조회 오류");
    });
  };

  // 주석메뉴 구분
  module.enumNoteMenuType = {
    MT_CONNOE00400 : 0,       //주석서식설정
    MT_COPNOE00100 : 1,       //법인주석작성
    MT_CONNOE00100 : 2,       //연결주석작성
    MT_GLDFSM01000 : 3,       //개별주석입력
  };

  // 주석 아이템 타입 구분
  module.enumNoteControlType = {
    CT_GRID: 0,               // 그리드
    CT_TEXT: 1,               // 텍스트박스
  };

  // 주석아이템 상태변경 구분
  module.enumNoteItemState = {
    ST_NORMAL: -1,
    ST_ADD: 0,
    ST_UPDATE: 1,
  }

  // 주석조회방식 구분 (연결주석입력 메뉴 해당)
  module.enumNoteConFilter = {
    CF_ALL: 0,                // 전체
    CF_CON: 1,                // 연결주석
    CF_CORP: 2                // 법인별 조회
  }

  // 주석메타 구분
  module.enumNoteMetaType = {
    eMeta_Code: "11",         // 코드도움
    eMeta_CellProp: "12",     // 셀속성
    eMeta_Gi: "13",           // 전/당기
    eMeta_Sisan: "14",        // 시산표
    eMeta_Cash: "15",         // 현금흐름표
    eMeta_Balance1: "16",     // (미사용)
    eMeta_Balance2: "17",     // 조정분개
    eMeta_InTrade: "18",      // (미사용)
    eMeta_Calc: "31",         // 계산식
    eMeta_Validate: "32",     // 검증
    eMeta_RefLink: "33",      // 주석간참조
  }

  // 주석 작성상태 구분
  module.enumNoteState = {
    ST_READY: 1,              // 작성대기
    ST_WRITING: 2,            // 작성중
    ST_COMPLETE: 3,           // 작성완료
    ST_VERIFY: 4              // 승인
  }

  module.enumNoteButtonCommand = {
    BC_NONE: '0',             // N/A
    BC_INIT: '1',             // 새로작성 처리
    BC_COMPLETE: '2',         // 작성완료 처리 
    BC_COMPLETE_CANCEL: '3',  // 작성완료취소 처리
    BC_APPROVE: '4',          // 승인 처리   
    BC_APPROVE_CANCEL: '5',   // 승인취소 처리
    BC_TRANS: '6',            // 이관 처리
    BC_TRANS_CANCEL: '7'      // 이관취소 처리
  }  

  // 최종선택된 아이템 리턴함수
  module.getLastFocusedItem = function(self){
    var selectedList = self._item.find('.comments-grid-container.selected');
    return selectedList.length > 0 ? selectedList[0].id : "";
  }

  // 주석아이템 초기화
  module.initNoteControl = function(self, menuType, enabled, data, idKey) {
    if(self._tabPanel) {
      self._tabPanel.on('click', function(e){
        var selectedList = $(self._tabPanel)[0]._element.find('.selected')
        if(selectedList.length > 0) {
          for(var idx = 0;idx < selectedList.length; idx++) {
            $(selectedList[idx]).removeClass("selected");
          }
        }
      })

      // tab panel인 경우 아이템을 검사할것
      let controls_area = self._item.find(".comments-container-designer");

      if(self._item && self._item.hasClass("dews-tab-item")) {
        $(self._item).css("height", "100%");

        if(self._item.find(".dews-tab-content").length > 0) {
          self._item.find(".dews-tab-content").css("height", "100%");
        }
      }

      let controls = [];
      if(controls_area.length > 0) {
        $.each(controls_area, function(idx, area) {
          var designer = new CA_NoteDesigner(area, menuType, enabled, data, idKey);
          designer.owner = self;

          if(dews.ui.page.menu) {
            designer.menuId = dews.ui.page.menu.id;
          }

          controls.push(designer);
        });
      }

      if(controls.length === 1) {
        self.noteDesigner = controls[0];
      } else {
        if(controls.length > 0) {
          self.noteDesigner = controls;
        }
      }
    }
  }

  // 데이터 유무 체크함수
  module.isEmpty = function(data) {
    if(typeof data === 'undefined' || data === undefined || data === null || data === ""){
      return true;
    } else {
      return false;
    }
  }

  // 문자열 비교
  module.strcmp = function( str1, str2 ) {
    return ( ( str1 == str2 ) ? 0 : ( ( str1 > str2 ) ? 1 : -1 ) );
  }

  // 그리드 cell 높이
  module.noteGridHeight = function() { return 24; }

  // desigener 객체 초기화
  function CA_NoteDesigner($selector, menuType, enabled, treeData, idKey) {
    if(!(this instanceof CA_NoteDesigner) ) {
      return new CA_NoteDesigner($selector, menuType, enabled, treeData, idKey);
    }

    this.container = $selector;
    this.caControls = [];
    this.menuData = treeData;   //treeData
    this.menuType = menuType;
    this.enabled = enabled;
    this._autoScroll = false;
    this._idKey = idKey;
    this.deletedItems = [];

    CA_NoteDesigner.prototype.autoScroll = function(scrollYn) {
      if(typeof scrollYn === 'undefined' || scrollYn === undefined) {
        return this._autoScroll;
      } else {
        this._autoScroll = scrollYn;
      }
    }

    // 텍스트 아이템 생성
    CA_NoteDesigner.prototype.createNewTextPanel = function(data) {
      var self = this;
      self.createTextPanel(data);

      var control = self.caControls[self.caControls.length - 1];
      control.STATE = module.enumNoteItemState.ST_ADD;
    }

    // 그리드 아이템 생성
    CA_NoteDesigner.prototype.createGridPanel = function(data, idx, total) {
      var self = this;
      var control = new componentGrid(self, data, idx, total);

      if(self.menuType === module.enumNoteMenuType.MT_COPNOE00100) {
        self.setCellStyle(control, data.metas);
      }

      self.caControls.push(control);
    }

    // 메타별 그리드 색상 적용 (연결주석입력 메뉴상에서의 호출)
    CA_NoteDesigner.prototype.setCellStyle2 = function(control) {
      var grid = control.grid;
      var metaColor = {};

      metaColor[gerp.CA.enumNoteMetaType.eMeta_CellProp] = '#f5f5f5';   // 셀속성
      metaColor[gerp.CA.enumNoteMetaType.eMeta_Calc] = '#fff1d6';       // 계산식
      metaColor[gerp.CA.enumNoteMetaType.eMeta_Sisan] = '#feeaff';      // 시산표
      metaColor[gerp.CA.enumNoteMetaType.eMeta_Cash] = '#daf9f1';       // 현금흐름표
      metaColor[gerp.CA.enumNoteMetaType.eMeta_Gi] = '#e2f6fd';         // 전/당기
      metaColor[gerp.CA.enumNoteMetaType.eMeta_RefLink] = '#eeecff';    // 주석간참조

      for(var key in control.metaData){
        var metas = control.metaData[key];
        for(var mIdx = 0; mIdx < metas.length; mIdx++){
          var meta = metas[mIdx];
          if(typeof(metaColor[meta.META_TP]) != 'undefined'){
            var rowCode = meta.ROW_CD;
            var colCode = meta.COL_CD;
            if(meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_Calc || meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_Validate){
              if(meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_Calc && meta.VRFC_ST == "N"){
                continue;
              }
              rowCode = meta.RST_ROW_CD;
              colCode = meta.RST_COL_CD;
            } else if(meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_CellProp){
              if(meta.REL1_CD != 2){
                if(meta.REL2_CD && meta.REL2_CD != ''){
                  // 셀속성메타 중 셀 색상 지정의 경우 해당 색상 적용
                  metaColor[gerp.CA.enumNoteMetaType.eMeta_CellProp] = meta.REL2_CD;
                } else {
                  // 셀속성메타 중 비활성의 경우 readonly 색상 적용
                  metaColor[gerp.CA.enumNoteMetaType.eMeta_CellProp] = '#ffffff';
                }
              }
            }

            var existColumns = $.grep(control.itemData.col, function(data, idx){
              return data.COL_CD == colCode;
            })
            if(!existColumns || existColumns.length == 0){
              continue;
            }

            var startIndex = grid.dataSource.data().map(function(e) {return e.ROW_CD; }).indexOf(rowCode);
            var endIndex = grid.dataSource.data().map(function(e) {return e.ROW_CD; }).lastIndexOf(rowCode);
            if(startIndex > -1){
              for(var idx = startIndex; idx <= endIndex; idx++){
                grid.setCellStyle(idx, colCode, {'background' : metaColor[meta.META_TP] });
              }
            }
          }
        }
      }

      if(control.menuType === module.enumNoteMenuType.MT_CONNOE00100){
        var arrHeaderYN = grid.dataSource.data().map(function(e) {return e.SET_COLOR; });
        for(var idx = 0; idx < arrHeaderYN.length; idx++){
          if(arrHeaderYN[idx] == "Y"){
            for(var cIdx = 0; cIdx < control.itemData.col.length; cIdx++){
              grid.setCellStyle(idx, control.itemData.col[cIdx].COL_CD, {'background' : '#f7deb5' });
            }
          }
        }
      }
    }

    // 메타별 그리드 색상 적용
    CA_NoteDesigner.prototype.setCellStyle = function(control, metas) {
      var grid = control.grid;
      var metaColor = {};

      metaColor[gerp.CA.enumNoteMetaType.eMeta_CellProp] = '#f5f5f5';   // 셀속성
      metaColor[gerp.CA.enumNoteMetaType.eMeta_Calc] = '#fff1d6';       // 계산식
      metaColor[gerp.CA.enumNoteMetaType.eMeta_Sisan] = '#feeaff';      // 시산표
      metaColor[gerp.CA.enumNoteMetaType.eMeta_Cash] = '#daf9f1';       // 현금흐름표
      metaColor[gerp.CA.enumNoteMetaType.eMeta_Gi] = '#e2f6fd';         // 전/당기
      metaColor[gerp.CA.enumNoteMetaType.eMeta_RefLink] = '#eeecff';    // 주석간참조

      var metaTypeList = [];
      metaTypeList.push(gerp.CA.enumNoteMetaType.eMeta_CellProp);
      metaTypeList.push(gerp.CA.enumNoteMetaType.eMeta_Calc);
      metaTypeList.push(gerp.CA.enumNoteMetaType.eMeta_Sisan);
      metaTypeList.push(gerp.CA.enumNoteMetaType.eMeta_Cash);
      metaTypeList.push(gerp.CA.enumNoteMetaType.eMeta_Gi);
      metaTypeList.push(gerp.CA.enumNoteMetaType.eMeta_RefLink);

      for(var metaIdx = 0; metaIdx < metaTypeList.length; metaIdx++){
        var metaType = metaTypeList[metaIdx];
        for(var mIdx = 0; mIdx < metas.length; mIdx++){
          metaColor[gerp.CA.enumNoteMetaType.eMeta_CellProp] = '#f5f5f5';
          var meta = metas[mIdx];

          if(metaType === meta.META_TP) {
            if(typeof(metaColor[meta.META_TP]) != 'undefined'){
              var rowCode = meta.ROW_CD;
              var colCode = meta.COL_CD;
              if(meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_Calc || meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_Validate){
                if(meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_Calc && meta.VRFC_ST == "N"){
                  continue;
                }
                rowCode = meta.RST_ROW_CD;
                colCode = meta.RST_COL_CD;
              } else if(meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_CellProp){
                if(meta.REL1_CD != 2){
                  if(meta.REL2_CD && meta.REL2_CD != ''){
                    // 셀속성메타 중 셀 색상 지정의 경우 해당 색상 적용
                    metaColor[gerp.CA.enumNoteMetaType.eMeta_CellProp] = meta.REL2_CD;
                  } else {
                    // 셀속성메타 중 비활성의 경우 readonly 색상 적용
                    metaColor[gerp.CA.enumNoteMetaType.eMeta_CellProp] = '#ffffff';
                  }
                }
              }

              var existColumns = $.grep(control.itemData.col, function(data, idx){
                return data.COL_CD == colCode;
              })
              if(!existColumns || existColumns.length == 0){
                continue;
              }

              var startIndex = grid.dataSource.data().map(function(e) {return e.ROW_CD; }).indexOf(rowCode);
              var endIndex = grid.dataSource.data().map(function(e) {return e.ROW_CD; }).lastIndexOf(rowCode);

              if(startIndex > -1){
                for(var idx = startIndex; idx <= endIndex; idx++){
                  grid.setCellStyle(idx, colCode, {'background' : metaColor[meta.META_TP] });
                }
              }
            }
          }
        }
      }

      if(control.menuType === module.enumNoteMenuType.MT_COPNOE00100){
        var arrReptRowYn = grid.dataSource.options.data.map(function(e) {return e.REPT_ROW_YN});
        for(var idx = 0; idx < arrReptRowYn.length; idx++){
          if(arrReptRowYn[idx] == "Y"){
            grid.setCellStyle(idx, control.itemData.col[0].COL_CD, {'background' : '#da9694' });
          }
        }
      }

      if(control.menuType === module.enumNoteMenuType.MT_CONNOE00100){
        var arrHeaderYN = grid.dataSource.data().map(function(e) {return e.HEADER_ROW_YN; });
        for(var idx = 0; idx < arrHeaderYN.length; idx++){
          if(arrHeaderYN[idx] == "Y"){
            for(var cIdx = 0; cIdx < control.itemData.col.length; cIdx++){
              grid.setCellStyle(idx, control.itemData.col[cIdx].COL_CD, {'background' : '#f7deb5' });
            }
          }
        }
      }
    }

    // 그리드의 스타일 적용 reset 함수
    CA_NoteDesigner.prototype.clearCellStyle = function(control, metas, rowIndex) {
      var grid = control.grid;
      var emptyColor = '#ffffff';

      for(var mIdx = 0; mIdx < metas.length; mIdx++){
        var meta = metas[mIdx];
        var rowCode = meta.ROW_CD;
        var colCode = meta.COL_CD;
        if(meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_Calc || meta.META_TP == gerp.CA.enumNoteMetaType.eMeta_Validate){
          rowCode = meta.RST_ROW_CD;
          colCode = meta.RST_COL_CD;
        }

        var startIndex = grid.dataSource.data().map(function(e) {return e.ROW_CD; }).indexOf(rowCode);
        var endIndex = grid.dataSource.data().map(function(e) {return e.ROW_CD; }).lastIndexOf(rowCode);
        if(startIndex > -1){
          for(var idx = startIndex; idx <= endIndex; idx++){
            if(idx >= rowIndex){
              grid.setCellStyle(idx - 1, colCode, {'background' : emptyColor });
            } else{
              grid.setCellStyle(idx, colCode, {'background' : emptyColor });
            }
          }
        }
      }
    }

    // 텍스트박스 아이템 생성
    CA_NoteDesigner.prototype.createTextPanel = function(data) {
      var self = this;
      if(typeof data === 'undefined') {
        data = {};
        data.EXRT_TP = "1";
        data.ITEM_CD = createguid("T");
        data.ITEM_NM = data.ITEM_CD;
        data.ITEM_TP = "2";
        data.START_DT = self.menuData.START_DT;
        data.col = [];
        data.data = [];
        data.row = [];
        data.text = "";
      }

      var control = new componentText(self, data);
      self.caControls.push(control);
    }

    /*
      DESC : CA_NoteDesigner 객체에 포함된 컨트롤목록 조회
      PARAM : N/A
      RETURN : control 객체 list
    */
    CA_NoteDesigner.prototype.getControls = function() {
      var self = this;
      return self.caControls;
    }

    /*
      DESC : CA_NoteDesigner 객체의 컨트롤 검색 (id)
      PARAM : control ID
      RETURN : control 객체
    */
    CA_NoteDesigner.prototype.findControl = function(controlId) {
      var self = this;

      for(var idx = 0;idx < self.caControls.length;idx++) {
        if(self.caControls[idx].controlId === controlId) {
          return self.caControls[idx];
        }
      }

      return null;
    }

    /*
      DESC : CA_NoteDesigner 객체의 컨트롤 인덱스검색 (id)
      PARAM : control ID
      RETURN : control Index
    */
    CA_NoteDesigner.prototype.findControlIndex = function(controlId) {
      var self = this;

      for(var idx = 0;idx < self.caControls.length;idx++) {
        if(self.caControls[idx].controlId === controlId) {
          return idx;
        }
      }

      return -1;
    }

    /*
      DESC : CA_NoteDesigner 객체의 컨트롤 순번 변경
      PARAM : [control]
      RETURN : N/A
    */
    CA_NoteDesigner.prototype.changeOrder = function(controls) {
      var self = this;

      for(var idx = 0;idx < controls.length - 1; idx++) {
        switchControl(controls[idx], controls[idx + 1]);
      }

      var newControls = [];
      for(var idx = 0;idx < controls.length; idx++) {
        var ctrl = self.findControl(controls[idx].CTRL_ID);
        if(ctrl.itemData.LINE_SQ !== idx + 1) {
          ctrl.itemData.LINE_SQ = idx + 1;

          if(ctrl.state() !== module.enumNoteItemState.ST_ADD) {
            ctrl.state(module.enumNoteItemState.ST_UPDATE);
          }
        }

        newControls.push(ctrl);
      }
      self.caControls = newControls;

      function switchControl(id1, id2) {
        var c1 = self.findControl(controls[idx].CTRL_ID);
        c1.name(controls[idx].CTRL_NM);

        var c2 = self.findControl(controls[idx + 1].CTRL_ID);
        c2.name(controls[idx + 1].CTRL_NM);

        $(c2.container).insertAfter($(c1.container));
      }
    }

    /*
      DESC : CA_NoteDesigner 객체의 현재 선택된 컨트롤 조회
      PARAM : N/A
      RETURN : control
    */
    CA_NoteDesigner.prototype.getCurrentControl = function() {
      var self = this;
      var controls = self.getControls();

      for(var idx = 0;idx < controls.length; idx++) {
        var control = controls[idx];
        if(control.container.hasClass("comments-grid-container selected")) {
          return control;
        }
      }
      return null;
    }

    /*
      DESC : CA_NoteDesigner 객체의 마지막으로 선택된 컨트롤 조회
      PARAM : N/A
      RETURN : control
    */
    CA_NoteDesigner.prototype.getLastSelectedItem = function() {
      var designer = this;
      var result;
      if(typeof(lastSelectedControl) == 'undefined'){
        return null;
      } else {
        for(var i = 0; i < designer.caControls.length; i++){
          if(lastSelectedControl == this.caControls[i].controlId){
            result = this.caControls[i];
            break;
          }
        }
        return result;
      }
    }

    /*
      DESC : CA_NoteDesigner 객체 clear
      PARAM : N/A
      RETURN : N/A
    */
    CA_NoteDesigner.prototype.clear = function() {
      var self = this;

      self.caControls = [];
      self.deletedItems = [];

      var $parentPanel = $(self.container);
      $parentPanel.empty();
    }

    /*
      DESC : CA_NoteDesigner 객체의 control들을 화면에 출력
      PARAM : data - 조회데이터 (행/열/메타/데이터/기타), na_yn - 해당사항여부, schdul_st - 작성상태, close_yn - 마감여부
      RETURN : N/A
      options: 연결주석 표시를 위해 별도로 제공 - 확장을 위해 options로 제공
      options 구조: { filterMode: module.enumNoteConFilter, corpCd: optional }
    */
    CA_NoteDesigner.prototype.drawControls = function(data, na_yn, schdul_st, close_yn) {
      var result = { result : true, itemInfo : [] };
      var self = this;
      this._caData = data;

      if(typeof na_yn != 'undefined'){
        this._na_yn = na_yn;
        this._schdul_st = schdul_st;
        this._close_yn = close_yn;
      }

      if(typeof data === 'undefined' || data === null) {
        return;
      }

      var controlData;
      if($.isArray(data)) {
        controlData = data;
      } else {
        controlData = data.items;
      }

      for(var idx = 0;idx < controlData.length;idx++) {
        var tp = controlData[idx].ITEM_TP;
        if(controlData[idx].PARNT_ITEM_MTCH_YN && controlData[idx].PARNT_ITEM_MTCH_YN == 'N'){
          result.result = false;
          result.itemInfo.push(controlData[idx]);
        }
        if(tp === "1") {
          self.createGridPanel(controlData[idx], idx, controlData.length);
        } else if(tp === "2") {
          self.createTextPanel(controlData[idx], idx, controlData.length);
        }
      }

      return result;
    }

    /*
      DESC : 저장등의 이벤트 발생 이후 CA_NoteDesigner 객체의 control들을 화면에 재출력
      PARAM : controlId - 컨트롤 id, data - 조회데이터 (행/열/메타/데이터/기타)
      RETURN : N/A
    */
    CA_NoteDesigner.prototype.redrawControl = function(controlId, data) {
      var self = this;

      this._caData = data;

      var control = self.findControl(controlId);
      if(control && data) {
        control.redraw(data);
      }
    }

    /*
      DESC : CA_NoteDesigner 객체의 컨트롤에 상태값 적용 (enumNoteItemState)
      PARAM : controlId - 컨트롤 id, data - 조회데이터 (행/열/메타/데이터/기타)
      RETURN : N/A
    */
    CA_NoteDesigner.prototype.setControlStateById = function(controlId, state) {
      var self = this;

      var control = self.findControl(controlId);
      if(control) {
        control.setState(data, state);
      }
    }

    /*
      DESC : CA_NoteDesigner 객체의 컨트롤에 상태값 적용2 (enumNoteItemState)
      PARAM : control - 컨트롤객체, data - 조회데이터 (행/열/메타/데이터/기타)
      RETURN : N/A
    */
    CA_NoteDesigner.prototype.setControlState = function(control, state) {
      var self = this;

      if(control) {
        control.setState(data, state);
      }
    }

    /*
      DESC : CA_NoteDesigner 객체의 컨트롤 삭제
      PARAM : control - 컨트롤객체
      RETURN : N/A
    */
    CA_NoteDesigner.prototype.deleteControl = function(control) {
      var self = this;

      var item_cd = control.itemData.ITEM_CD;
      var findControl = false;

      if(control && control.state() !== module.enumNoteItemState.ST_ADD) {
        self.deletedItems.push(getComponentData(control.itemData));
      }

      var findIndex = -1;
      for(var idx = 0;idx < self.caControls.length;idx++) {
        if(self.caControls[idx] === control) {
          self.caControls.splice(idx, 1);
          $(control.container).remove();

          findIndex = idx;
        }
      }

      if(findIndex > -1) {
        for(var idx = findIndex;idx < self.caControls.length;idx++) {
          self.caControls[idx].itemData.LINE_SQ = Number(self.caControls[idx].itemData.LINE_SQ) - 1;
          if(self.caControls[idx].state() !== module.enumNoteItemState.ST_ADD) {
            self.caControls[idx].state(module.enumNoteItemState.ST_UPDATE);
          }
        }
      }
    }

    /*
      DESC : CA_NoteDesigner 객체의 변경사항 조회
      PARAM : N/A
      RETURN : { added : [], updated : [], deleted : [] }
      데이터의 변경을 판단하는게 아닌 컨트롤의 추가, 변경, 삭제를 의미한다는 점에 주의.
      각 콤포넌트 별 data를 판단하기 위해서는 component.getDirtyData를 사용할 것.
      componentGrid 클래스의 경우 상/하단 텍스트를 가지고 있으므로 이에 대한 dirtyData 사용에 주의
    */
    CA_NoteDesigner.prototype.getDirtyData = function() {
      var self = this;
      var dirtyData = { added:[], updated:[], deleted: self.deletedItems };
      $.each(self.caControls, function(idx, control) {
        var state = control.state();

        if(state === module.enumNoteItemState.ST_ADD) {
          dirtyData.added.push(getComponentData(control.itemData));
        } else if(state === module.enumNoteItemState.ST_UPDATE) {
          dirtyData.updated.push(getComponentData(control.itemData));
        }
      });
      return dirtyData;
    }

    /*
      DESC : CA_NoteDesigner 객체의 변경사항 전체 초기화
      PARAM : N/A
      RETURN : N/A
    */
    CA_NoteDesigner.prototype.clearState = function() {
      var self = this;

      $.each(self.caControls, function(idx, control) {
        control.state(module.enumNoteItemState.ST_NORMAL);
      });

      self.deletedItems = [];
    }

    /*
      DESC : 컨트롤정보 조회
      PARAM : data - control data
      RETURN : { ITEM_CD : '', ITEM_NM : '', ITEM_TP : '', START_DT : '', LINE_SQ : '', EXRT_TP : '' }
      dirtyData로 관리될 값들만 저장
    */
    function getComponentData(data) {
      return {
        ITEM_CD: data.ITEM_CD,
        ITEM_NM: data.ITEM_NM,
        ITEM_TP: data.ITEM_TP,
        START_DT: data.START_DT,
        LINE_SQ: data.LINE_SQ,
        EXRT_TP: data.EXRT_TP
      }
    }

    var mself = this;

    /*
      DESC : TextBox 컨트롤
      PARAM : ca_self - CA_NoteDesigner 객체, data - 텍스트박스 컨트롤 정보
      RETURN : N/A
    */
    function componentText(ca_self, data) {
      this._caContainer = ca_self.container;

      this.controlType = module.enumNoteControlType.CT_TEXT;
      this.itemData = data;
      this._enabled = ca_self.enabled;
      this._designer = ca_self;
      this._options = {};

      var $parentPanel = $(ca_self.container);

      this.controlId = data.ITEM_CD;
      this.controlName = data.ITEM_NM;
      var objectId = module.isEmpty(ca_self._idKey) ? data.ITEM_CD : data.ITEM_CD + "_" + ca_self._idKey;

      this._state = module.enumNoteItemState.ST_NORMAL;

      var $panel = $("<div></div>").addClass("comments-container comments-grid-container").attr("id", objectId).css("resize", "none");
      var $resizer = $("<div></div>").css("display", "block");//.addClass("resizer");
      var $label = $("<input/>").attr({ "type": "text", "value": "텍스트상자", disabled: "true" }).addClass("componentTitle");

      var $itemTextArea = $("<textarea readonly/>").addClass("dews-ui-grid component").attr({id: objectId + "_itemTextArea"})
        .css({ 'width': '100%', 'height':'23px', "resize": 'none', 'margin-bottom': '-4px', 'border':'0px', 'font-weight':'bold', 'font-family':'Geogia'});

      var $text = $("<textarea/>").addClass("dews-ui-textbox component", "boxText").attr({ id: objectId + "_textbox" })
        .css({ 'width': '100%', "resize": 'none', "max-height": "inherit", "min-height": "fit-content" });

      if(this._enabled === false) {
          $text.attr("disabled", "disabled");
      }

      clearFocus(ca_self);

      $resizer.append($text);

      if(mself.menuType === module.enumNoteMenuType.MT_CONNOE00400) {
        $($itemTextArea).text(" " + this.controlName);
        $text.before($itemTextArea);
      }
      $panel.append($resizer);
      $parentPanel.append($panel);

      this.container = $panel;

      focusProc($panel, ca_self, this);

      if(this._enabled) {
        $panel.css("border", "none");
      }

      $panel.attr("disabled", true);

      createDefaultText(this, $panel.find(".dews-ui-textbox")[0]); // 기본 텍스트박스 생성

      if(ca_self.autoScroll()) {
        $parentPanel.scrollTop($parentPanel[0].scrollHeight);
      }

      if(data) {
        this.textbox.text(data.text);
      }

      /*
        DESC : TextBox 컨트롤 text 설정함수
        PARAM : text - 설정하고자 하는 텍스트
        RETURN : N/A
      */
      componentText.prototype.setText = function(text) {
        this.textbox.text(text);
      }

      /*
        DESC : TextBox 컨트롤 text 조회함수
        PARAM : N/A
        RETURN : text - 컨트롤에 설정되어 있는 텍스트
      */
      componentText.prototype.getText = function() {
        return this.textbox.text();
      }

      /*
        DESC : TextBox 컨트롤 text 재조회
        PARAM : text_data - textbox 컨트롤
        RETURN : N/A
      */
      componentText.prototype.redraw = function(text_data) {
        if(text_data.items[0].hasOwnProperty("text")) {
          this.textbox.text(text_data.items[0].text);
        }
      }

      /*
        DESC : TextBox 컨트롤 상태값 설정
        PARAM : state - 상태값 (enumNoteItemState)
        RETURN : N/A
      */
      componentText.prototype.state = function(state) {
        if(typeof state === 'undefined' || state === undefined) { return this._state; }
        this._state = state;
      }

      /*
        DESC : TextBox 컨트롤 명칭 설정
        PARAM : name - 명칭
        RETURN : N/A
      */
      componentText.prototype.name = function(name) {
        if(typeof name === 'undefined' || name === undefined) { return this.itemData.ITEM_NM; }
        if(this.itemData.ITEM_NM !== name) {
          this.itemData.ITEM_NM = name;
          // 상태값이 추가(ST_ADD)가 아닌경우 ST_UPDATE로 변경
          if(this._state !== module.enumNoteItemState.ST_ADD) {
            this._state = module.enumNoteItemState.ST_UPDATE;
          }
        }
      }

      /*
        DESC : TextBox 컨트롤의 option 조회
        PARAM : N/A
        RETURN : textbox options 객체
      */
      componentText.prototype.getOptions = function() {
        return this._options;
      }

      /*
        DESC : TextBox 컨트롤의 option 설정
        PARAM : options - textbox options 객체
        RETURN : N/A
      */
      componentText.prototype.setOptions = function(options) {
        this._options = options;
      }

      /*
        DESC : TextBox 컨트롤의 변경사항 조회
        PARAM : N/A
        RETURN : 텍스트 변경시 변경된 텍스트, 변경사항 없을경우 null
      */
      componentText.prototype.getDirtyData = function() {
        if(this.itemData.text !== this.getText()) {
          return this.getText();
        }
        return null;
      }
    }

    /*
      DESC : Grid 컨트롤
      PARAM : ca_self - CA_NoteDesigner 객체, data - 그리드 컨트롤 정보
      RETURN : N/A
    */
    function componentGrid(ca_self, data, idx, total) {
      this._caContainer = ca_self.container;
      this.controlType = module.enumNoteControlType.CT_GRID;
      this.menuType = ca_self.menuType;
      this._ca_dictionary = new NoteHashMap();
      this._designer = ca_self;
      this._enabled = ca_self.enabled;
      this._options = {};
      this.itemData = data;
      this._filter = {};

      var $parentPanel = $(ca_self.container)

      this.controlName = data.ITEM_NM;
      this.controlId = data.ITEM_CD;
      var objectId = module.isEmpty(ca_self._idKey) ? data.ITEM_CD : data.ITEM_CD + "_" + ca_self._idKey;

      this._state = module.enumNoteItemState.ST_NORMAL;

      var $panel = $("<div></div>").addClass("comments-container comments-grid-container").attr("id", objectId).css("resize", "none");
      var $li_1 = $("<li></li>");
      var $Tlabel = $("<label class='comments-grid-title'></label>").css("float", "left").text(dews.localize.get("제목", 'D0005550')).css({"margin-right": "50px", "margin-top":"4px"});
      var $li_2 = $("<li></li>").css({ "display": "inline", "text-align": "right", "float": "right" }).attr("id", objectId + "_unit_span");
      var $div2 = $("<div></div>").css({ "height": "25px", "width": "inherit" });
      var $Ulabel = $("<label></label>").text(dews.localize.get("단위", 'D0000040')).css({"float":"right", "margin-top":"4px"});

      var $select = $("<select class=\"dews-ui-dropdownlist\" style='width:50px;float:right;margin-right:4px;'><option value=0>" + dews.localize.get("원", 'D0004347') + "</option></select>");
      if(this._enabled === false) {
        $select.attr("disabled", "disabled");
      }
      var textReadonly = mself.menuType == module.enumNoteMenuType.MT_COPNOE00100 ? true : false;
      var $textTop = $("<textarea/>").addClass("dews-ui-textbox component").attr({ id: objectId + "_textTop", readonly : textReadonly })
        .css({ 'width': '100%', 'height':'80px', "resize": 'none', 'display': 'none', 'margin-bottom': '4px' });

      var $itemTextArea = $("<textarea readonly/>").addClass("dews-ui-grid component").attr({id: objectId + "_itemTextArea"})
        .css({ 'width': '100%', 'height':'23px', "resize": 'none', 'margin-bottom': '-4px', 'border':'0px', 'font-weight':'bold', 'font-family':'Geogia'});
      var $grid = $("<div></div>").addClass("dews-ui-grid component").attr("id", objectId + "_grid");
      var $textBottom = $("<textarea/>").addClass("dews-ui-textbox component").attr({ id: objectId + "_textBottom", readonly : textReadonly })
        .css({ 'width': '100%', 'height':'120px', "resize": 'none', 'margin-top': '4px', 'display': 'none' });
      var $resizer = $("<div></div>").css("display", "block").addClass("resizer");

      clearFocus(ca_self);

      $div2.append($li_1);
      $resizer.append($textTop);
      $resizer.append($grid);

      if(mself.menuType === module.enumNoteMenuType.MT_CONNOE00400 || mself.menuType === module.enumNoteMenuType.MT_GLDFSM01000) {
        $grid.append($itemTextArea);
        $($itemTextArea).text(" " + "[" + this.controlId + "]" + this.controlName);
      }

      $resizer.append($textBottom);
      $panel.append($resizer);
      $parentPanel.append($panel);

      this.container = $panel;

      if(this.menuType === module.enumNoteMenuType.MT_GLDFSM01000 || this.menuType === module.enumNoteMenuType.MT_CONNOE00400) {
        if(data.EDITABLE_YN === "N") {
          $($grid[0]).css('border', '2px #2601c6 solid');
        }
      }

      focusProc($panel, ca_self, this);

      if(this._enabled) {
        $panel.css("border", "none");
      }

      this.dropdown = dews.ui.dropdownlist($panel.find(".dews-ui-dropdownlist"));

      var textObject = $panel.find(".dews-ui-textbox");
      if(textObject.length === 2) {
        this.textboxTop = dews.ui.textbox($(textObject[0]));
        this.textboxBottom = dews.ui.textbox($(textObject[1]));
      }
      this.metaData = null;

      if(data.textBottom && this.textboxBottom) {
        this.textboxBottom.text(data.textBottom);
      }

      if(data.textTop && this.textboxTop) {
        this.textboxTop.text(data.textTop);
      }

      if(data.metas) {
        //주석작성의 경우 metas 정보를 통해 메타정보가 전달된다
        var metaInfo = {};
        $.each(data.metas, function(idx, meta) {
          var tp = meta.META_TP;
          if(!metaInfo.hasOwnProperty(tp)) {
            metaInfo[tp] = [];
          }

          metaInfo[tp].push(meta);
        });

        this.metaData = metaInfo;
      }

      if(typeof data === 'undefined' || data === undefined || data === null || !data.hasOwnProperty("ITEM_CD")) {
        createDefaultGrid(this, data, $panel.find(".dews-ui-grid")[0], idx, total); // 기본 그리드 생성
      } else {
        createGrid(this, data, $panel.find(".dews-ui-grid")[0], idx, total);

        var grid = this.grid;

        var self = this;
        grid.on('dblClicked', function(e) {
          var dblClickEvent = new $.Event('gridDblClicked', { designer: ca_self, control:self, gridEvent:e });
          $(ca_self).trigger(dblClickEvent);
        });

        // 법인주석입력의 그리드 이벤트 설정
        if(self.menuType === module.enumNoteMenuType.MT_COPNOE00100) {
          // 반복행 여부에 따른 mainbuttons.add 활성화 처리
          grid.on('click', function(e) {
            var rowCode = grid.dataItem(grid.select()).ROW_CD;
            var orgRowCode = rowCode.indexOf('(') >= 0 ? rowCode.substring(0, rowCode.indexOf('(')) : rowCode;
            var addableRow = $.grep(data.row, function(data, idx){
              return orgRowCode == data.ROW_CD && data.REPT_ROW_YN == 'Y'
            })

            if($.type(addableRow) != 'undefined' && addableRow.length > 0) {
              dews.ui.page.mainButtons.add.disable(false);
            } else {
              dews.ui.page.mainButtons.add.disable(true);
            }
          });

          // 셀 데이터 변경시 계산식메타 유무에 따른 계산처리
          grid.on('save', function(e) {
            var calcMetas = $.grep(data.metas, function(data, idx){
              return data.META_TP == '31' && data.VRFC_ST == 'Y';
            });

            if(calcMetas){
              for(var i = 0; i < calcMetas.length; i++){
                // 계산식메타에 설정된 계산식 수행
                if(calcMetas[i].CAL_TP == '1' || calcMetas[i].CAL_TP == '3'){
                  var calcMeta = calcMetas[i];
                  setCalcedValue(e, calcMeta, false);
                }
              }
            }

            grid.commitCell();

            // 김진영
            gridForm = grid;

            setRowHeight();
          });

          // 엑셀 붙여넣기 이벤트
          grid.on('pasting', function(e) {
            e.preventDefault();
            var colIndex = 0;
            for(var colIdx = 0; colIdx < data.col.length; colIdx++){
              if(data.col[colIdx].COL_CD == e.start.column){
                colIndex = colIdx;
                break;
              }
            }

            for(var rIdx = 0; rIdx < e.copyData.length; rIdx++){
              if(e.start.index + rIdx >= e.grid.dataItems().length) {
                return;
              }
              var rowCode = e.grid.dataItem(e.start.index + rIdx).ROW_CD;
              for(var cIdx = 0; cIdx < e.copyData[rIdx].length; cIdx++){
                if(colIndex + cIdx >= data.col.length){
                  break;
                }
                var colCode = data.col[colIndex + cIdx].COL_CD;
                var result = true;
                var result_c = false;

                for(var mIdx = 0; mIdx < data.metas.length; mIdx++){
                  var meta = data.metas[mIdx];
                  var metaType = data.metas[mIdx].META_TP;
                  if(metaType == gerp.CA.enumNoteMetaType.eMeta_Validate || metaType == gerp.CA.enumNoteMetaType.eMeta_Balance2){
                    continue;
                  }

                  var metaRowCode = meta.ROW_CD;
                  var metaColCode = meta.COL_CD;
                  if(metaType == gerp.CA.enumNoteMetaType.eMeta_Calc){
                    metaRowCode = meta.RST_ROW_CD;
                    metaColCode = meta.RST_COL_CD;
                  }

                  if(metaRowCode == rowCode && colCode == metaColCode){
                    if(metaType == gerp.CA.enumNoteMetaType.eMeta_CellProp){
                      if(meta.REL1_CD == '2'){
                        result = false;
                        break;
                      }
                    } else if(metaType == gerp.CA.enumNoteMetaType.eMeta_Code){ // 김진영
                      result = true;
                      result_c = true;
                      break;
                    } else {
                      result = false;
                      break;
                    }
                  }
                }

                result = result && self._designer._na_yn == 'N' && self._designer._close_yn == 'N' && self._designer._schdul_st <= 2;

                e.copyData[rIdx][cIdx] = e.copyData[rIdx][cIdx].trim();
                if(e.copyData[rIdx][cIdx].indexOf('(') >= 0 && !isNaN(e.copyData[rIdx][cIdx].split('(').join('').split(')').join(''))){
                  e.copyData[rIdx][cIdx] = '-' + e.copyData[rIdx][cIdx].replace('(', '').replace(')', '');
                }

                if(result && !result_c){
                  e.grid.setCellValue(e.start.index + rIdx, colCode, e.copyData[rIdx][cIdx].trim().split(',').join(''));
                } else if(result_c) { // 김진영
                  e.grid.setCellValue(e.start.index + rIdx, colCode, e.copyData[rIdx][cIdx]);
                }
              }
            }
          });
        } else if(self.menuType === module.enumNoteMenuType.MT_CONNOE00100) {
          // 연결주석인 경우는 입력 행의 값이 바뀌면 상단 연결주석행에 합산처리
          grid.on('save', function(e) {
            grid.commitCell();

            for(var idx = 0; idx < data.data.length; idx++){
              var findData = data.data[idx];
              if(findData.ROW_CD == e.row.data.ROW_CD && findData.CORP_CD == e.row.data.CORP_CD && findData.HEADER_ROW_YN == e.row.data.REPT_ROW_YN && findData.TYPE == '2') {
                findData[e.cell.field] = e.row.data[e.cell.field];
                break;
              }
            }

            var calcMetas = $.grep(data.metas, function(data, idx){
              return data.META_TP == '31' && data.VRFC_ST == 'Y';
            });

            var column = e.grid.columns[e.cell.field];

            var targetCol = $.grep(data.col, function(col, cIdx){
              return col.COL_CD == e.cell.field && col.DATA_TP == '4';
            });

            if(column.editor && column.editor.type === "number" && targetCol.length == 0) {
              var calcData = 0;
              var targetRow;
              var fsRow = $.grep(e.grid.dataItems(), function(data, idx){
                return data.CORP_CD == e.row.data.CORP_CD && data.ROW_CD == e.row.data.ROW_CD && data.HEADER_ROW_YN != 'Y' && $.type(data.SET_COLOR) != 'undefined';
              });

              for(var rowIndex = e.row.index; rowIndex >= 0;rowIndex--) {
                var rowData = e.grid.dataItem(rowIndex);

                if((fsRow.length <= 0 || rowData.CORP_CD == e.row.data.CORP_CD) && rowData.HEADER_ROW_YN !== 'Y') {
                  var fieldValue = rowData[e.cell.field];
                  if(fieldValue !== undefined) {
                    calcData += Number(rowData[e.cell.field]);
                  }
                } else {
                  if(e.row.data.CORP_CD == rowData.CORP_CD){
                    targetRow = rowIndex;
                    break;
                  }
                }
              }

              for(var rowIndex = e.row.index + 1; rowIndex < e.grid.dataItems().length; rowIndex++) {
                var rowData = e.grid.dataItem(rowIndex);
                if(rowData.HEADER_ROW_YN !== 'Y') {
                  var fieldValue = rowData[e.cell.field];
                  if(fieldValue !== undefined) {
                    calcData += Number(rowData[e.cell.field]);
                  }
                } else {
                  break;
                }
              }

              if(targetRow >= 0){
                e.grid.setCellValue(targetRow, e.cell.field, calcData, true);
              }
            }

            if(e.row.data.HEADER_ROW_YN != 'Y' && calcMetas){
              var cellCode = e.row.data.ROW_CD + ":" + e.cell.field;
              for(var i = 0; i < calcMetas.length; i++){
                if(calcMetas[i].CAL_TP == '2' || calcMetas[i].CAL_TP == '3'){
                  var calcMeta = calcMetas[i];
                  if(calcMetas[i].CALCFOR_TXT.indexOf(cellCode) >= 0){
                    setCalcedValueForConsNote(e, calcMeta, true, data.WRT_FG);
                  }
                }
              }
            }
            e.grid.commitCell();
          });
        // 중위표기법 계산식 적용 - 권영욱 (개별주석)
        } else if(self.menuType === module.enumNoteMenuType.MT_GLDFSM01000) {
          grid.on('save', function(e) {
            var calcMetas = data.metas["31"];
            if(calcMetas){
              for(var i = 0; i < calcMetas.length; i++){
                var calcMeta = calcMetas[i];
                if(calcMeta.VRFC_ST == 'Y'){
                  setCalcedValue(e, calcMeta, false);
                }
              }
            }
            grid.commitCell();
          });

          // 메타에 따른 editor 표시여부
          grid._grid.onShowEditor = function(gv, index){
            var result = true;
            var gridItem = grid.dataItem(index.dataRow);
            outer : for(metaType in data.metas){
              if(metaType == gerp.CA.enumNoteMetaType.eMeta_Validate){
                continue;
              }
              var metaList = data.metas[metaType];
              for(var mIdx = 0; mIdx < metaList.length; mIdx++){
                var meta = metaList[mIdx];
                var rowCode = meta.ROW_CD;
                var colCode = meta.COL_CD;
                if(metaType == gerp.CA.enumNoteMetaType.eMeta_Calc){
                  rowCode = meta.RST_ROW_CD;
                  colCode = meta.RST_COL_CD;
                }

                if(gridItem.ROW_CD == rowCode && colCode == index.column){
                  if(metaType == gerp.CA.enumNoteMetaType.eMeta_Code) {
                    result = false;
                    break outer;
                  } else if(metaType == gerp.CA.enumNoteMetaType.eMeta_CellProp){
                    if(meta.REL1_CD == '2'){
                      result = false;
                      break outer;
                    } else {
                      result = true;
                      break outer;
                    }
                  } else if(metaType == gerp.CA.enumNoteMetaType.eMeta_RefLink) {
                    result = false;
                    break outer;
                  } else if(metaType == gerp.CA.enumNoteMetaType.eMeta_Calc) {
                    if(meta.VRFC_ST == 'N'){
                      result = true;
                      break outer;
                    } else {
                      result = false;
                      break outer;
                    }
                  } else {
                    result = true;
                    break outer;
                  }
                }
              }
            }
            return result;
          };

          // 코드도움 메타가 설정된 cell의 경우 더블클릭을 통해 해당 도움창 open
          grid._grid.onDataCellDblClicked = function(gv, index){
            var codeDataMeta = data.metas[gerp.CA.enumNoteMetaType.eMeta_Code];
            if(codeDataMeta && codeDataMeta.length > 0){
              var rowData = grid.dataItem(index.dataRow);
              for(var metaIdx = 0; metaIdx < codeDataMeta.length; metaIdx++){
                var meta = codeDataMeta[metaIdx];
                if(meta.ROW_CD == rowData.ROW_CD && meta.COL_CD == index.column){
                  var initData = {};
                  initData['field_cd'] = meta.REL1_CD;
                  initData['company_cd'] = meta.COMPANY_CD;

                  var dialog = dews.ui.dialog("COPNOE00100_CODEDTL_DIALOG", {
                    url: "/view/CA/COPNOE00100_CODEDTL_DIALOG",
                    title: dews.localize.get("코드도움창", 'D0009885'),
                    width: 500,
                    height: 400,
                    buttons: 'applyAndClose',
                    initData : initData,
                  ok: function(data) {
                    grid.setCellValue(index.dataRow, index.column, data.SYSDEF_NM, false);
                  }
                });
                dialog.open();
                return;
                }
              }
            }
          }
        }

        /*
          DESC : 계산식 결과값 조회 함수
          PARAM : e - grid.save이벤트, meta - 그리에 설정된 메타, isConsNode - 연결주석여부, wrt_fg - 주석작성구분 (연결/법인)
          RETURN : calcedValue (숫자타입)
        */
        function setCalcedValue(e, meta, isConsNote, wrt_fg){
          var consgrpCd = e.row.data.CORP_CD;
          var cellCode = '';
          if(typeof(e.row.data.ROW_CD) != 'undefined' && e.row.data.ROW_CD != ''){
            cellCode = e.row.data.ROW_CD + ":" + e.cell.field;
          } else {
            for(var idx = e.row.index; idx >= 0; idx--){
              if(typeof(e.grid.dataItem(idx).ROW_CD) != 'undefined'){
                cellCode = e.grid.dataItem(idx).ROW_CD + ":" + e.cell.field;
                break;
              }
            }
          }

          var thisValue = e.row.data[e.cell.field];
          var fomular = meta.CALCFOR_TXT;
          var targetColIdx;

          if(fomular.indexOf(cellCode) != -1){
            var mapCellData = {};

            for(var i = 0; i < data.col.length; i++){
              if(data.col[i].COL_CD == e.cell.field) {
                if(data.col[i].DATA_TP == '1' || data.col[i].DATA_TP == '7' || data.col[i].DATA_TP == '8'){
                  thisValue = 0;
                } else {
                  thisValue = e.row.data[e.cell.field];
                }
              }
            }

            mapCellData[cellCode] = (typeof(thisValue) == 'undefined' || thisValue == '' || isNaN(thisValue)) ? 0 : thisValue;

            // 그리드 셀별 금액 합산
            for(var ridx = 0; ridx < e.grid.dataItems().length; ridx++){
              var dataItem = e.grid.dataItems()[ridx];

              if($.type(wrt_fg) == 'undefined' || wrt_fg != '2'){
                if(isConsNote && (dataItem.CORP_CD != consgrpCd || dataItem.HEADER_ROW_YN != 'Y')) {
                  continue;
                }
              }

              if(typeof(dataItem.ROW_CD) != 'undefined' && !targetColIdx && dataItem.ROW_CD == meta.RST_ROW_CD){
                targetColIdx = ridx;
              }

              var orgRowCd = '';
              if(typeof(dataItem.ROW_CD) != 'undefined'){
                orgRowCd = dataItem.ROW_CD;
              } else {
                for(var inIdx = ridx; inIdx >= 0; inIdx--){
                  if(typeof(e.grid.dataItem(inIdx).ROW_CD) != 'undefined'){
                    orgRowCd = e.grid.dataItem(inIdx).ROW_CD;
                    break;
                  }
                }
              }

              for(var idx = 0; idx < data.col.length; idx++){
                var col = data.col[idx];
                var cellCode = orgRowCd + ":" + col.COL_CD;
                var cellValue;

                if(col.DATA_TP == '1' || col.DATA_TP == '7' || col.DATA_TP == '8'){
                  cellValue = 0;
                } else {
                  if(typeof(dataItem[col.COL_CD]) != 'undefined' && dataItem[col.COL_CD] != '' && !isNaN(dataItem[col.COL_CD])){
                    cellValue = dataItem[col.COL_CD];
                  } else {
                    cellValue = 0;
                  }
                }

                if(typeof(mapCellData[cellCode]) != 'undefined'){
                  if(e.row.index != ridx || e.cell.field != col.COL_CD){
                    mapCellData[cellCode] = Number(mapCellData[cellCode]) + Number(cellValue);
                  }
                } else {
                  mapCellData[cellCode] = Number(cellValue);
                }
              }
            }

            for(var cell in mapCellData){
              if(fomular.indexOf(cell) != -1){
                fomular = fomular.replace(cell, "(" + mapCellData[cell] + ")");
              }
            }

            fomular = fomular.replace("ROUND", "Math.round");
            fomular = fomular.replace("TRUNC", "Math.trunc");
            fomular = fomular.replace("CEIL", "Math.ceil");
            fomular = fomular.replace("FLOOR", "Math.floor");

            if ($.type(e.grid._grid.getEditValue()) !== 'undefined') {
              e.grid.commitCell();
            }

            e.grid.setCellValue(targetColIdx, meta.RST_COL_CD, eval(fomular).toFixed(6));
          }
          e.grid.commitCell();
        }

        /*
          DESC : 연결주석의 <입력>행 값 수정에 따른 연결주석 헤더 행 값 합산
          PARAM : e - grid.save이벤트, meta - 그리에 설정된 메타, isConsNode - 연결주석여부, wrt_fg - 주석작성구분 (연결/법인)
          RETURN : calcedValue (숫자타입)
        */
        function setCalcedValueForConsNote(e, meta, isConsNote, wrt_fg){
          var consgrpCd = e.row.data.CORP_CD;
          var cellCode = '';
          if(typeof(e.row.data.ROW_CD) != 'undefined' && e.row.data.ROW_CD != ''){
            cellCode = e.row.data.ROW_CD + ":" + e.cell.field;
          }

          var thisValue = e.row.data[e.cell.field];
          var fomular = meta.CALCFOR_TXT;
          var targetColIdx;
          var mapCellData = {};

          for(var i = 0; i < data.col.length; i++){
            if(data.col[i].COL_CD == e.cell.field) {
              if(data.col[i].DATA_TP == '1' || data.col[i].DATA_TP == '7' || data.col[i].DATA_TP == '8'){
                thisValue = 0;
              } else {
                thisValue = e.row.data[e.cell.field];
              }
            }
          }

          mapCellData[cellCode] = (typeof(thisValue) == 'undefined' || thisValue == '') ? 0 : thisValue;

          var consInputRows = $.grep(e.grid.dataItems(), function(data, idx){
            return data.CORP_CD == consgrpCd && (!data.HEADER_ROW_YN || data.HEADER_ROW_YN == 'N') && (!data.SET_COLOR || data.SET_COLOR == 'N');
          });

          // 그리드 셀별 금액 합산
          for(var ridx = 0; ridx < e.grid.dataItems().length; ridx++){
            var rowData = e.grid.dataItems()[ridx];
            var dataItem;

            if(wrt_fg == "1") {
              if(rowData.CORP_CD == consgrpCd && (!rowData.HEADER_ROW_YN || rowData.HEADER_ROW_YN == 'Y') && (!rowData.SET_COLOR || rowData.SET_COLOR == 'Y')
                 || ((rowData.ROW_CD).indexOf('(') != -1)){
                dataItem = rowData;
              } else {
                continue;
              }
            } else {
              if(rowData.CORP_CD == consgrpCd && (!rowData.HEADER_ROW_YN || rowData.HEADER_ROW_YN == 'N') && (!rowData.SET_COLOR || rowData.SET_COLOR == 'N')){
                dataItem = rowData;
              } else {
                continue;
              }
            }
            // var dataItem = consInputRows[ridx];

            if(typeof(dataItem.ROW_CD) != 'undefined' && !targetColIdx && dataItem.ROW_CD == meta.RST_ROW_CD){
              //2020.06.24 정원준: 입력행 값 입력시 합계행에 반영안되는 오류 수정
              targetColIdx = ridx;
            }

            var orgRowCd = '';
            if(typeof(dataItem.ROW_CD) != 'undefined'){
              orgRowCd = dataItem.ROW_CD;
            } else {
              for(var inIdx = ridx; inIdx >= 0; inIdx--){
                if(typeof(e.grid.dataItem(inIdx).ROW_CD) != 'undefined'){
                  orgRowCd = e.grid.dataItem(inIdx).ROW_CD;
                  break;
                }
              }
            }

            for(var idx = 0; idx < data.col.length; idx++){
              var col = data.col[idx];
              var cellCode = orgRowCd + ":" + col.COL_CD;
              var cellValue;

              if(col.DATA_TP == '1' || col.DATA_TP == '7' || col.DATA_TP == '8'){
                cellValue = 0;
              } else {
                if(typeof(dataItem[col.COL_CD]) != 'undefined' && dataItem[col.COL_CD] != ''){
                  cellValue = dataItem[col.COL_CD];
                } else {
                  cellValue = 0;
                }
              }
              mapCellData[cellCode] = Number(cellValue);
            }
          }

          for(var cell in mapCellData){
            if(fomular.indexOf(cell) != -1){
              if(wrt_fg == "1") {
                if(cell.indexOf('(') != -1) {
                  fomular = fomular.replace(cell, "(0)");
                } else {
                  fomular = fomular.replace(cell, "(" + mapCellData[cell] + ")");
                }
              } else {
                fomular = fomular.replace(cell, "(" + mapCellData[cell] + ")");
              }
            }
          }

          fomular = fomular.replace("ROUND", "Math.round");
          fomular = fomular.replace("TRUNC", "Math.trunc");
          fomular = fomular.replace("CEIL", "Math.ceil");
          fomular = fomular.replace("FLOOR", "Math.floor");

          e.grid.setCellValue(targetColIdx, meta.RST_COL_CD, eval(fomular).toFixed(6));
        }
      }

      if(ca_self.autoScroll()) {
        $parentPanel.scrollTop($parentPanel[0].scrollHeight);
      }

      /*
        DESC : 그리드 재구성 함수
        PARAM : data - 그리드정보, filterOption - 그리드 필터 옵션 (enumNoteConFilter), wrt_fg - 작성구분 (연결/법인)
        RETURN : N/A
      */
      componentGrid.prototype.redraw = function(data, filterOption, wrt_fg) {
        if(this.menuType === module.enumNoteMenuType.MT_CONNOE00400 || this.menuType === module.enumNoteMenuType.MT_GLDFSM01000) {
          this.itemData = data;
        } else {
          this._designer._caData = data;
          if(data.items.length === 0) { return };
          this.itemData = data.items[0];
        }

        this._ca_dictionary.RemoveAll();

        setGridColumns(this, this.grid, this.itemData.col);
        setGridData(this, this.grid, this.itemData.row, this.itemData.data);

        if(this.menuType == module.enumNoteMenuType.MT_CONNOE00100){
          if(($.type(wrt_fg) != 'undefined' && wrt_fg == '2') || filterOption.filterMode === module.enumNoteConFilter.CF_CON) {
            grid.hideColumn("CORP_NM");
          } else {
            grid.showColumn("CORP_NM");
          }
        }

        if(this.menuType == module.enumNoteMenuType.MT_COPNOE00100){// || this.menuType == module.enumNoteMenuType.MT_CONNOE00100){
          this._designer.__proto__.setCellStyle(this, this.itemData.metas);
        }
        fitGrid(this.grid);

        // 김진영
        gridForm = grid;

        setRowHeight();
      }

      /*
        DESC : 그리드 컨트롤 상태 설정
        PARAM : state - 컨트롤 상태 (enumNoteItemState)
        RETURN : N/A
      */
      componentGrid.prototype.state = function(state) {
        if(typeof state === 'undefined' || state === undefined) { return this._state; }
        this._state = state;
      }

      /*
        DESC : 그리드 컨트롤 명칭 설정
        PARAM : name - 컨트롤 명칭
        RETURN : N/A
      */
      componentGrid.prototype.name = function(name) {
        if(typeof name === 'undefined' || name === undefined) { return this.itemData.ITEM_NM; }
        if(this.itemData.ITEM_NM !== name) {
          this.itemData.ITEM_NM = name;
          if(this._state !== module.enumNoteItemState.ST_ADD) {
            this._state = module.enumNoteItemState.ST_UPDATE;
          }
        }
      }

      /*
        DESC : 그리드 컨트롤 높이 설정
        PARAM : N/A
        RETURN : N/A
      */
      componentGrid.prototype.fitSize = function() {
        fitGrid(this.grid);
      }

      /*
        DESC : 그리드 컨트롤 options 조회
        PARAM : N/A
        RETURN : 그리드 컨트롤 option 객체
      */
      componentGrid.prototype.getOptions = function() {
        return this._options;
      }

      /*
        DESC : 그리드 컨트롤 options 설정
        PARAM : 그리드 컨트롤 option 객체
        RETURN : N/A
      */
      componentGrid.prototype.setOptions = function(options) {
        this._options = options;
      }

      /*
        DESC : 그리드 컨트롤 filter 변경 (연결주석입력)
        PARAM : filterOption - 필터 옵션, wrt_fg - 작성구분 (연결/법인)
        RETURN : N/A
      */
      componentGrid.prototype.changeFilter = function(filterOption, wrt_fg) {
        var self = this;

        if(self._filter === filterOption){
          return;
        }

        setFilteredData.call(self, this.grid, filterOption, wrt_fg);
      }

      /*
        DESC : 그리드 컨트롤 상단 텍스트박스 표시
        PARAM : visible - 표시여부
        RETURN : N/A
      */
      componentGrid.prototype.showTopTextbox = function(visible) {
        var self = this;
        if(self.textboxTop) {
          if(visible) {
            self.textboxTop.element.css("display", "block");
          } else {
            self.textboxTop.element.css("display", "none");
          }
        }
      }

      /*
        DESC : 그리드 컨트롤 하단 텍스트박스 표시
        PARAM : visible - 표시여부
        RETURN : N/A
      */
      componentGrid.prototype.showBottomTextbox = function(visible) {
        var self = this;
        if(self.textboxBottom) {
          if(visible) {
            self.textboxBottom.element.css("display", "block");
          } else {
            self.textboxBottom.element.css("display", "none");
          }
        }
      }

      /*
        DESC : 그리드 컨트롤 텍스트박스 표시 (상/하단)
        PARAM : visible - 표시여부
        RETURN : N/A
      */
      componentGrid.prototype.showTextbox = function(visible) {
        var self = this;

        self.showTopTextbox(visible);
        self.showBottomTextbox(visible);
      }

      /*
        DESC : 그리드 컨트롤 변경사항 조회
        PARAM : N/A
        RETURN : dirtyData { Added : [], Updated : [], Deleted : [] }
      */
      componentGrid.prototype.getDirtyData = function() {
        var self = this;
        if(self.menuType === module.enumNoteMenuType.MT_CONNOE00100) {
          var dirtyData = {
            Updated: [],
            Deleted: [],
            Added: [],
            length: 0
          };

          dirtyData.length = 0;

          var keys = self._ca_dictionary.AllKeys();

          $.each(keys, function(i, key){
            var grid_datasource =self._ca_dictionary.Get(key);

            var added = grid_datasource.getDirtyData().Added;
            var updated = grid_datasource.getDirtyData().Updated;
            var deleted = grid_datasource.getDirtyData().Deleted;

            $.merge(dirtyData.Added, added);
            $.merge(dirtyData.Updated, updated);
            $.merge(dirtyData.Deleted, deleted);

            dirtyData.length = dirtyData.Updated.length + dirtyData.Deleted.length + dirtyData.Added.length;
          });
          return dirtyData;
        } else {
          self.grid.dataSource.getDirtyData();
        }
      }
    }

    /*
      DESC : CA_NoteDesigner 객체의 focus reset
      PARAM : ca_self - CA_NoteDesigner
      RETURN : N/A
    */
    function clearFocus(ca_self) {
      var $parentPanel = $(ca_self.container);
      var selectedList = $parentPanel.find(".comments-grid-container.selected");
      if(selectedList.length > 0) {
        for(var idx = 0;idx < selectedList.length; idx++) {
          $(selectedList[idx]).removeClass("selected");
        }
      }
    }

    /*
      DESC : CA_NoteDesigner 객체의 focus 변경
      PARAM : $panel - CA_NoteDesigner 객체의 컨트롤을 포함하는 panel, ca_self - CA_NoteDesigner, control - 선택된 컨트롤
      RETURN : N/A
    */
    function focusProc($panel, ca_self, control) {
      var self = this;
      $panel.on('click', function(e) {
        if($(this).hasClass("selected")) {
          return;
        }

        var $parentPanel = $(ca_self.container);
        var selectedList = $parentPanel.find(".comments-grid-container.selected");
        if(selectedList.length > 0) {
          for(var idx = 0;idx < selectedList.length; idx++) {
            $(selectedList[idx]).removeClass("selected");
          }
        }

        lastSelectedControl = $(this)[0].id;
        $(this).addClass("selected");
        if(ca_self.enabled) {
          $(this).css("border", "none");
        }
        e.stopPropagation();
      });

      if(!ca_self.enabled) {
        $panel.on('dblclick', function(e) {
          var dblClickEvent = new $.Event('dblClicked', { designer: ca_self, control:control });
          $(ca_self).trigger(dblClickEvent);
        });
      }
    }

    /*
      DESC : GUID 생성 (미사용)
      PARAM : data - 컨트롤정보
      RETURN : 컨트롤 ID
    */
    function createguid(data) {
      var guid = uuid();
      var controlId = data + guid;
      return controlId;
    }

    /*
      DESC : UUID 생성 (미사용)
      PARAM : N/A
      RETURN : UUID
    */
    function uuid() {
      var chars = '0123456789abcdef'.split('');

      var uuid = [], rnd = Math.random, r;
      uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
      uuid[14] = '4'; // version 4

      for (var i = 0; i < 36; i++) {
        if (!uuid[i]) {
          r = 0 | rnd() * 16;

          uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r & 0xf];
        }
      }
      var guid = uuid.join('');
      return guid.replace(/\-/g, '').toUpperCase();
    }

    /*
      DESC : 기본형태의 텍스트박스 (DewsControl) 생성
      PARAM : thisControl - textbox 컨트롤, textboxObject - textbox HTML 객체
      RETURN : N/A
    */
    function createDefaultText(thisControl, textboxObject, idx, total) {
      thisControl.textbox = dews.ui.textbox($(textboxObject));
    }

    /*
      DESC : DEWS 그리드 생성
      PARAM : thisControl - CA_NoteDesigner 객체, data - 컨트롤 데이터, gridObject - grid HTML 객체
      RETURN : N/A
    */
    function createGrid(thisControl, data, gridObject, idx, total) {
      var dataSource = dews.ui.dataSource('dataSource', {
        grid: true,
        schema: {
          model: {
            fields: []
          }
        }
      });

      $thisGrid = gridObject; //assembleGrid() 에서 $grid

      //그리드위치
      var grid = dews.ui.grid($(gridObject), {
        dataSource: dataSource,
        selectable: true,
        checkable: false,
        fillWidth: false,
        editSkip: true,
        editable: thisControl._designer.enabled,
        sortable: false,
        rowNo: false,
        copyMode: 'row',
        paste: { numberChars: ',' },
        autoBind: false,
        context: {
          excelFileNameSuffixDate: true // 엑셀 내보내기의 파일 이름뒤에 날짜포맷 적용여부 (※ 생략가능 / 기본값 : false)          
        },
        columns: [],
        editingMergedRow: false,
        changing: function (e) {
          //TITLE 컬럼의 선택을 불가능하게 만든다.
          if (e.cell.next.field === "TITLE" || e.cell.next.field === "ROW_CD" || e.cell.next.field === "ROW_NM") {
            e.preventDefault();
          }
        }
      });

      thisControl.grid = grid;

      // 그리드 컬럼세팅
      setGridColumns(thisControl, grid, data.col);

      // 그리드 데이터소스 세팅
      setGridData(thisControl, grid, data.row, data.data);

      // 그리드 높이 설정
      fitGrid(grid, idx, total);

      // 김진영
      gridForm = grid;

      setTimeout(function(e) {
        setRowHeight();
      }, 50);
    }

    // 김진영
    function setRowHeight() {
      var max = 0;
      
      $.each(gridForm.sortDataItems(), function(i, item) {
        $.each(Object.values(item), function(ii, iItem) {
          if(iItem && String(iItem).split('\n').length !== 1) {
            if(max < 16*String(iItem).split('\n').length) {
              max = 16*String(iItem).split('\n').length;
            }
            gridForm.setRowHeight('custom', i, max);
          }
        });
      });
    }

    /*
      DESC : 그리드 컬럼정보 설정
      PARAM : container - CA_NoteDesigner, grid - 그리드 객체, col - 컬럼정보
      RETURN : N/A
    */
    function setGridColumns(container, grid, col) {
      var columns = [];
      var fields = []; // field 배열

      var maxCaption = 1;
      $.each(col, function(idx, colInfo) {
        if(colInfo.COL2_NM !== null && maxCaption < 2) { maxCaption = 2; }
        if(colInfo.COL3_NM !== null && maxCaption < 3) { maxCaption = 3; }
        if(maxCaption === 3) {
          return false;
        }
      });

      var columnR = {};
      columnR.field = "ROW_CD";
      columnR.title = dews.localize.get("행코드", 'D0009410');
      if(container.menuType === module.enumNoteMenuType.MT_CONNOE00100 ||
        container.menuType === module.enumNoteMenuType.MT_COPNOE00100 ||
        container.menuType === module.enumNoteMenuType.MT_GLDFSM01000) {
        columnR.visible = false;
      } else {
        columnR.width = 85;
        columnR.editable = false;
      }
      columns.push(columnR);

      var columnR2 = {};
      columnR2.field = "ROW_NM";
      columnR2.title = dews.localize.get("구분", 'D0000024');
      columnR2.visible = false;
      columns.push(columnR2);

      fields.push({field:"ROW_CD"});
      fields.push({field:"ROW_NM"});

      if(container.menuType === module.enumNoteMenuType.MT_CONNOE00100) {
        columns.push({
          field: "COMPANY_CD",
          title: dews.localize.get("회사코드", 'D0000004'),
          visible: false
        });
        fields.push({field:"COMPANY_CD"});

        columns.push({
          field: "CORP_CD",
          title: dews.localize.get("법인코드", 'D0002108'),
          visible: false
        });
        fields.push({field:"CORP_CD"});

        columns.push({
          field: "CORP_NM",
          title: dews.localize.get('법인명', 'D0002107', dews.localize.language(), "CASENV00100"),
          width: 120,
          align: "left",
          editable: false,
          style : function(e) {
            return {background:"#f0f0f0"};
          }
        });
        fields.push({field:"CORP_NM"});

        columns.push({
          field: "HEADER_ROW_YN",
          title: dews.localize.get("헤더여부", 'D0090423'),
          visible: false
        });
        fields.push({field:"HEADER_ROW_YN"});

        columns.push({
          field: "SET_COLOR",
          title: dews.localize.get("배경색여부", 'D0090424'),
          visible: false
        });
        fields.push({field:"SET_COLOR"});

        columns.push({
          field: "REPT_ROW_YN",
          title: dews.localize.get("반복여부", 'D0090425'),
          visible: false
        });
        fields.push({field:"REPT_ROW_YN"});

        columns.push({
          field: "ITEM_CD",
          title: dews.localize.get("아이템코드", 'D0009459'),
          visible: false
        });
        fields.push({field:"ITEM_CD"});

        columns.push({
          field: "START_DT",
          title: dews.localize.get("시작일", 'D0000015'),
          visible: false
        });
        fields.push({field:"START_DT"});
      }

      var subColumns = [];
      var prevDepth = 0;

      for(var colIndex = 0;colIndex < col.length;colIndex++) {
        var curr = col[colIndex];
        var prev = null;

        if(colIndex > 0) { prev = col[colIndex - 1]; }
        prevDepth = genColumnInfo(subColumns, prev, curr, prevDepth);
      }

      for(var idx = 0;idx < subColumns.length;idx++) {
        var column = subColumns[idx];
        if(column.columns) {
          var visible = false;
          var totalWidth = 0;
          for(var idx2 = 0;idx2 < column.columns.length;idx2++) {
            var subVisible = false;
            var subColumn = column.columns[idx2];
            var subWidth = 0;
            if(subColumn.columns) {
              for(var idx3 = 0;idx3 < subColumn.columns.length;idx3++) {
                if(subColumn.columns[idx3].visible) {
                  subWidth += Number(subColumn.columns[idx3].width);
                }
                subVisible = subVisible || subColumn.columns[idx3].visible;
              }
              subColumn.width = subWidth;
              totalWidth += subWidth;
              subColumn.visible = subVisible;
            } else {
              if(subColumn.visible) {
                totalWidth += Number(subColumn.width);
              }
            }

            visible = visible || subColumn.visible;
          }
          column.visible = visible;
          column.width = totalWidth;
        }
      }

      for(var idx = 0;idx < subColumns.length;idx++) {
        columns.push(subColumns[idx]);
        fields = fields.concat(getFieldList(subColumns[idx]));
      }

      /*
        DESC : 그리드 컬럼정보 설정 (전체 컬럼)
        PARAM : allColumns - 다중헤더의 경우 sub컬럼정보, prevColInfo - 이전 열, colInfo - 해당 열, prevDepth - 다중헤더 수
        RETURN : N/A
      */
      function genColumnInfo(allColumns, prevColInfo, colInfo, prevDepth) {
        var colDef = {};
        var colDepth = generateColumn(colDef, colInfo);

        if(prevColInfo === null) {
          allColumns.push(colDef);
          return colDepth;
        } else {
          if(colDepth === 1) {
            allColumns.push(colDef);
            prevDepth = colDepth;
          } else {
            if(prevDepth !== colDepth) {
              allColumns.push(colDef);
            } else {
              if(colDepth === 3) {
                if(prevColInfo.COL3_NM !== colInfo.COL3_NM) {
                  allColumns.push(colDef);
                } else {
                  var childColumn = allColumns[allColumns.length - 1];
                  if(!childColumn.hasOwnProperty("columns")) {
                    childColumn.columns = [];
                  }
                  if(prevColInfo.COL2_NM !== colInfo.COL2_NM){
                    childColumn.columns.push(colDef.columns[0]);
                  } else {
                    if(module.isEmpty(colInfo.COL2_NM)) {
                      childColumn.columns.push(colDef.columns[0]);
                    }else {
                      if(!childColumn.columns[childColumn.columns.length - 1].hasOwnProperty("columns")) {
                        childColumn.columns[childColumn.columns.length - 1].columns = [];
                      }
                      childColumn.columns[childColumn.columns.length - 1].columns.push(colDef.columns[0].columns[0]);
                    }
                  }
                }
              } else if(colDepth === 2) {
                if(prevColInfo.COL2_NM !== colInfo.COL2_NM) {
                  allColumns.push(colDef);
                } else {
                  var childColumn = allColumns[allColumns.length - 1];
                  if(!childColumn.hasOwnProperty("columns")) {
                    childColumn.columns = [];
                  }
                  childColumn.columns.push(colDef.columns[0]);
                }
              }
            }
          }
        }
        return colDepth;

      /*
        DESC : 그리드 컬럼정보 설정 (단일 컬럼)
        PARAM : colDef, columnInfo - 단일컬럼정보
        RETURN : 다중헤더 높이
      */
        function generateColumn(colDef, columnInfo) {
          var colDepth = 0;
          if(columnInfo.COL3_NM !== "" && columnInfo.COL3_NM !== null) {
            colDef.title = columnInfo.COL3_NM;
            colDef.columns = [];
            colDepth = 3;
          }

          if(colDepth === 3) {
            if(columnInfo.COL2_NM !== "" && columnInfo.COL2_NM !== null) {
              colDef.columns.push({
                title: columnInfo.COL2_NM,
                columns : []
              });
              colDef.columns[0].columns.push(getFieldInfo(container, columnInfo, 1));
            } else {
              colDef.columns.push(getFieldInfo(container, columnInfo, 1));
            }
          } else {
            if(columnInfo.COL2_NM !== "" && columnInfo.COL2_NM !== null) {
              colDef.title = columnInfo.COL2_NM;
              colDef.columns = [];
              colDef.columns.push(getFieldInfo(container, columnInfo, 1));
              colDepth = 2;
            } else {
              var info = getFieldInfo(container, columnInfo, 1);
              $.each(Object.keys(info), function(idx, key) {
                colDef[key] = info[key];
              });
              colDepth = 1;
            }
          }
          return colDepth;
        }
      }

      //2021.03.03 정원준: 서식등록 주석조회시 무한로딩 오류 수정
      if(grid.dataSource.data().length == 0) {
        grid.dataSource.data();
      } else {
        grid.dataSource.data([]);
      }

      grid.setColumns([]);

      var gridDatasource = dews.ui.dataSource("gridDatasource", {
        grid: true,
        schema: {
          model: {
            fields: fields
          }
        }
      });

      grid.setDataSource(gridDatasource);
      grid.setColumns(columns);

      var gridHeight = module.noteGridHeight();
      grid.setStyles({height:{header:32 * maxCaption, row:gridHeight}});

      /*
        DESC : 그리드 컬럼정보 에서 field 추출 (다중헤더)
        PARAM : column - 그리드 컬럼
        RETURN : field 배열
      */
      function getFieldList(column) {
        var fields = [];

        if(column.columns) {
          if($.isArray(column.columns)) {
            $.each(column.columns, function(idx, col) {
              fields = fields.concat(getFieldList(col));
            });
          } else {
            fields.push({field: column.field});
          }
        } else {
          fields.push({field: column.field});
        }

        return fields;
      }

      /*
        DESC : 그리드 컬럼정보를 통한 grid field 생성
        PARAM : container - CA_NoteDesigner, info - 컬럼정보, captionIndex - 캡션 인덱스
        RETURN : field
      */
      function getFieldInfo(container, info, captionIndex){
        var colDef = {};

        colDef.title = info["COL" + captionIndex + "_NM"];
        colDef.width = info.WIDTH_QT;
        if(captionIndex === 1){
          var title = "";
          if(info["COL" + captionIndex + "_NM"] !== null) {
            title = info["COL" + captionIndex + "_NM"];
          }
          colDef.field = info.COL_CD;
          if(container.menuType == module.enumNoteMenuType.MT_CONNOE00400) {
            colDef.title = "(" + info.COL_CD + ") " + title;
          }

          colDef.visible = info.DISP_YN == 'Y' ? true : false;

          colDef.width = info.WIDTH_QT;
          if (container.menuType == module.enumNoteMenuType.MT_COPNOE00100 || container.menuType == module.enumNoteMenuType.MT_CONNOE00100){
            colDef.renderer = { showTooltip: true };
          }

          if(info.DATA_TP !== undefined && info.DATA_TP !== null) {
            var editor = {};
            var formats = {};
            if(info.DATA_TP === "7" || info.DATA_TP === "8") {
              editor["type"] = "date";
              formats.type = "date";
            } else if(info.DATA_TP === "2" || info.DATA_TP === "3" || info.DATA_TP === "4" || info.DATA_TP === "5" || info.DATA_TP === "6") {
              editor["type"] = "number";
              formats.type="number";
            } else {
              editor["type"] = "multiline";
            }

            // 연결주석입력만 열정보의 컬럼속성이 금액인 경우 소수점 제거(현대차는 소수점 별도처리)
            if(dews.app.drsCode != '10084' && info.DATA_TP == "2" && editor["type"] == "number" && container.menuType == module.enumNoteMenuType.MT_CONNOE00100) {
              editor["format"] = "#,###";
              formats.format = "#,###";
            } else {
              editor["format"] = (info.FORMAT_VR == "#,###.##" && dews.app.drsCode == '10084') ? "#,###.00" : info.FORMAT_VR;
              formats.format = (info.FORMAT_VR == "#,###.##"  && dews.app.drsCode == '10084') ? "#,###.00" : info.FORMAT_VR;
            }

            colDef.editor = editor;

            if(info.DATA_TP !== "1") {
              colDef.formats = formats; //텍스트인 경우 format을 줄 수 없다
            }
          }

          if(info.SORT_TP !== null){
            if(info.SORT_TP === "1") { colDef.align = "left"; }
            else if(info.SORT_TP === "2") { colDef.align = "center"; }
            else if(info.SORT_TP === "3") { colDef.align = "right"; }
          }

          if(container.menuType !== module.enumNoteMenuType.MT_CONNOE00100) {
            if(info.UPDATE_YN === "N") {
              if(colDef.editor) {
                colDef.editor.editable = function(e) { return false; }
              } else {
                colDef.editable = false;
              }
            }
          } else {
            var editable = function(e) {
              if(e.row.data.HEADER_ROW_YN && e.row.data.HEADER_ROW_YN === "Y") { return false; }
              else {
                var corpCode = e.row.data.CORP_CD;
                var lastCorpCode = "";
                for(var rowIndex = e.row.index - 1;rowIndex >= 0; rowIndex--) {
                  var rowData = e.grid.dataItem(rowIndex);
                  if(rowData.HEADER_ROW_YN === "Y") {
                    lastCorpCode = rowData.CORP_CD;
                    break;
                  }
                }

                if(corpCode === lastCorpCode || (e.row.data.HEADER_ROW_YN && e.row.data.HEADER_ROW_YN === "N")) {
                  return true;
                }
                return false;
              }
            }

            if(colDef.editor) {
              colDef.editor.editable = editable;
            } else {
              colDef.editable = editable;
            }
          }

          if(info.MERGE_YN === "Y") {
            colDef.merge = true;
          }
        } else {
          var columns = [];
          columns.push(getFieldInfo(container, info, captionIndex - 1));

          colDef.columns = columns;
        }

        return colDef;
      }
    }

    /*
      DESC : 그리드 데이터 설정
      PARAM : container - CA_NoteDesigner, grid - 그리드 객체, rows - 행정보, data - 데이터
      RETURN : field
    */
    function setGridData(container, grid, rows, data) {
      var fields = [];
      var existCorpNm = false;
      $.each(grid.dataSource.options.field, function(i, field) {
        fields.push(field.field);
        if( !existCorpNm && field === "CORP_NM") { existCorpNm = true; }
      });

      var dataMap = new NoteHashMap();
      if(container.menuType !== module.enumNoteMenuType.MT_CONNOE00100) {
        if(data !== undefined && data.length > 0) {
          $.each(data, function(rowIndex, rowData) {
            dataMap.Set(rowData.ROW_CD, rowData);
          });
        }
      }

      var ds = [];
      var createRowArr = container.menuType == module.enumNoteMenuType.MT_CONNOE00100 ? rows : data;
      if(createRowArr.length == 0) {
        createRowArr = rows;
      }

      for(var idx = 0;idx < createRowArr.length;idx++) {
        var isContains = false;
        var row = createRowArr[idx];
        if(!row.REPT_ROW_YN){
          for(var rIdx = 0; rIdx < rows.length; rIdx++){
            var rawRow = rows[rIdx];
            if(row.ROW_CD == rawRow.ROW_CD){
              isContains = true;
              row.REPT_ROW_YN = rawRow.REPT_ROW_YN;
              row.DISP_YN = rawRow.DISP_YN;
              break;
            }
          }
        }

        if(!row.REPT_ROW_YN && !isContains){
          row.REPT_ROW_YN = 'Y';
        }

        if(container.menuType !== module.MT_CONNOE00400 && row.DISP_YN && row.DISP_YN === "N") {
          continue;
          // 서식설정 메뉴를 제외하고 DISP_YN이 'N'인 경우는 ROW를 생성하지 않는다
        }

        var rowData = {};
        $.each(Object.keys(row), function(keyIndex, key) {
          if($.inArray(key, fields) > -1) {
            rowData[key] = row[key];
          }
        });

        var row2;
        if(container.menuType !== module.enumNoteMenuType.MT_CONNOE00100) {
          row2 = dataMap.Get(rowData.ROW_CD);
        } else {
          row2 = data[idx];
        }

        if(row2 !== undefined) {
          $.each(Object.keys(row2), function(i2, key) {
            rowData[key] = row2[key];
          });
        }
        ds.push(rowData);
      }

      if(container.menuType === module.enumNoteMenuType.MT_CONNOE00100) {
        //연결주석 데이터소스 관리를 위해
        var filterKey = "ALL";
        var dataSource2 = grid.options.dataSource;
        var dataSourceTemplate = dews.ui.dataSource("__ds_" + filterKey, dataSource2.options);
        grid.setDataSource(dataSourceTemplate);

        dataSourceTemplate.data(ds);
        container._ca_dictionary.Add(filterKey, dataSourceTemplate);
      } else {
        grid.dataSource.data(ds);
      }
    }

    /*
      DESC : 그리드 필터 적용
      PARAM : grid - 그리드 객체,filterOption - 필터옵션, wrt_fg - 작성구분 (연결/법인)
      RETURN : N/A
    */
    function setFilteredData(grid, filterOption, wrt_fg) {
      var self = this;
      var dataSource2 = grid.options.dataSource;

      var filterKey;
      if(filterOption.filterMode === module.enumNoteConFilter.CF_ALL) { filterKey = "ALL"; }
      else if(filterOption.filterMode === module.enumNoteConFilter.CF_CON) { filterKey = "CA_SUM"; }
      else { filterKey = filterOption.corpCode; }

      if(filterKey === undefined) {
        return;
      }

      if(filterKey !== "ALL" && this._ca_dictionary.Exist(filterKey)) {
        this._ca_dictionary.Remove(filterKey);
      }

      if(!this._ca_dictionary.Exist(filterKey)) {
        var dataSourceTemplate = dews.ui.dataSource("__ds_" + filterKey, dataSource2.options);
        grid.setDataSource(dataSourceTemplate);
        dataSourceTemplate.data(getDetailData(wrt_fg));
        this._ca_dictionary.Add(filterKey, dataSourceTemplate);
      } else {
        grid.setDataSource(this._ca_dictionary.Get(filterKey));
      }

      grid.hideColumn("ROW_CD");

      if(wrt_fg == '2' || filterOption.filterMode === module.enumNoteConFilter.CF_CON) {
        grid.hideColumn("CORP_NM");
      } else {
        grid.showColumn("CORP_NM");
      }

      fitGrid(grid);

      /*
        DESC : 작성구분에 따른 실제 표시해야할 데이터 필터링
        PARAM : wrt_fg - 작성구분 (연결/법인)
        RETURN : datasource
      */
      function getDetailData(wrt_fg){
        var data = self._designer._caData;

        var allData = self._ca_dictionary.Get("ALL");
        var ds = [];

        if(wrt_fg == '2'){
          ds = allData.data();
        } else {
          if(filterOption.filterMode === module.enumNoteConFilter.CF_CON) {
            $.each(allData.data(), function(rowIndex, rowData) {
              if(rowData.HEADER_ROW_YN === "Y" || (rowData.REPT_ROW_YN === "Y" && isExistCopiedRow(rowData, allData.data(), filterOption.corpCode))) {
                ds.push(rowData);
              }
            });
          } else {
            var corpCode = filterOption.corpCode;
            $.each(allData.data(), function(rowIndex, rowData) {
              if(rowData.CORP_CD === corpCode) {
                ds.push(rowData);
              }
            });
          }
        }

        return ds;
      }
    }

    /*
      DESC : 반복행 존재여부
      PARAM : rowData - 행정보, allData - 전체 datasource, consgrpCode - 연결그룹코드
      RETURN : true/false
    */
    function isExistCopiedRow(rowData, allData, consgrpCode) {
      var result = false;
      var corpRow = $.grep(allData, function(data, idx){
        var chkRowCode = '';
        if(rowData.ROW_CD) {
          chkRowCode = rowData.ROW_CD.indexOf('(') > 0 ? rowData.ROW_CD.substring(0, rowData.ROW_CD.indexOf('(')) : rowData.ROW_CD;
        }
        return $.type(data.ROW_CD) == 'undefined' || (data.CORP_CD == rowData.CORP_CD && data.ROW_CD != rowData.ROW_CD && data.ROW_CD.indexOf(chkRowCode) != -1);
      });

      //2020.06.08 정원준 : 작성구분 '법인'에서 보기가 연결주석일때 법인주석데이터 보이는 오류 수정
      if(rowData.CORP_NM != '<' + dews.localize.get("입력", 'D0002918') + '>' && rowData.CORP_CD != consgrpCode && rowData.ROW_CD.indexOf('(') > 0 && corpRow.length > 0 ||
         rowData.CORP_NM != '<' + dews.localize.get("입력", 'D0002918') + '>' && rowData.REPT_ROW_YN == 'Y') {
        result = true;
      }

      return result;
    }

    /*
      DESC : 그리드 높이 설정
      PARAM : grid - 그리드 객체
      RETURN : N/A
    */
    function fitGrid(grid, idx, total) {
      var headerHeight = grid.options.gridStyle.header.height; //grid header 높이
      var bodyHeight = grid.options.gridStyle.body.height; // grid body 높이

      if(grid.options.styles) {
        if(grid.options.styles.height) {
          if(grid.options.styles.height.row) {
            headerHeight = bodyHeight = grid.options.styles.height.row;
          }
          if(grid.options.styles.height.header) {
            headerHeight = grid.options.styles.height.header;
          }
        }
      }

      //해당메뉴가 주석서식등록이거나 comments-container-designer(tab하위 디자인영역) 하위에 comments-container(아이템별 콘트롤 영역)가 1개 이상인 경우      
      if((mself.menuType === module.enumNoteMenuType.MT_CONNOE00400) || total > 1 || (mself.menuType === module.enumNoteMenuType.MT_GLDFSM01000)){ 
        var margin_value = grid.dataItems().length === 0 ? 1 : grid.dataItems().length;
        var gridHeight = Number(headerHeight) + Number(bodyHeight) * (margin_value) + 16 + 4; //scroll bar의 높이를 더한다

        //아이템의 max height 을 635(기본값) 으로 제한
        grid.$element.css("height", gridHeight > 635 ? 635 : gridHeight); 

      } else{
        //1개 또는 보기(연결주석/전체.. ) 변경인 경우 
        
        //그리드 높이를 별도로 지정하지 않고 상위 comments-container-designer의 스크롤을 숨김
        // if(grid.$element.closest('.comments-container-designer').length > 0) {
        //   grid.$element.closest('.comments-container-designer').css("overflow", "hidden");
        // }

        grid.$element.css("height", grid.$element.closest('.comments-container-designer').height() - 22 );  // scroll bar의 높이를 빼준다.
      }

      grid.$element.parent().css("margin-bottom", "0px");
    }
  }

  function NoteHashMap() {
    this.content = {};

    NoteHashMap.prototype.Add = function(key, value) {
      this.content[key] = value;
    };
    NoteHashMap.prototype.Set = function(key, value) {
      this.content[key] = value;
    };
    NoteHashMap.prototype.Get = function(key) {
      if (!this.content.hasOwnProperty(key)) { return undefined };
      return this.content[key];
    };
    NoteHashMap.prototype.AllKeys = function() {
      var keys = [];
      for (a in this.content) {
        keys.push(a);
      }
      return keys;
    };
    NoteHashMap.prototype.Exist = function(key) {
      return this.content.hasOwnProperty(key);
    };
    NoteHashMap.prototype.Remove = function(key) {
      if (this.content.hasOwnProperty(key)) {
        delete this.content[key];
      }
    };
    NoteHashMap.prototype.RemoveAll = function() {
      this.content = {};
    };
    NoteHashMap.prototype.Count = function() {
      return Object.keys(this.content).length;
    }
  }

  //////// 작성 영역 - 끝 ////////

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=ca.note.js