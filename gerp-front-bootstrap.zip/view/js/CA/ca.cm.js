/*
version = '1.0.23071701';
*/
(function (dews, gerp, $) {
  var module = {};
  //# sourceURL=ca.cm.js
  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'CA'; // 모듈 코드를 입력 해주세요.
  var btnUpImage = 'url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAARCAYAAAA7bUf6AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyRkY4OTAzQTdGNzcxMUU3ODQzN0UwMTNDNzNBOTRERCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyRTk1MDg4QzdGN0IxMUU3ODQzN0UwMTNDNzNBOTRERCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjJGRjg5MDM4N0Y3NzExRTc4NDM3RTAxM0M3M0E5NEREIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjJGRjg5MDM5N0Y3NzExRTc4NDM3RTAxM0M3M0E5NEREIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+h+WqnAAAADhJREFUeNpi/P//PwOlgImBCmDUEDIMaWxs/E+RITADCBnERKwL8BnERIoXcIkzjqbY4W4IQIABACmKF6khPcUtAAAAAElFTkSuQmCC") no-repeat center';
  var btnDownImage = 'url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAARCAYAAAA7bUf6AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyRkY4OTAzNjdGNzcxMUU3ODQzN0UwMTNDNzNBOTRERCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyRkY4OTAzNzdGNzcxMUU3ODQzN0UwMTNDNzNBOTRERCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjJGRjg5MDM0N0Y3NzExRTc4NDM3RTAxM0M3M0E5NEREIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjJGRjg5MDM1N0Y3NzExRTc4NDM3RTAxM0M3M0E5NEREIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Wjl95gAAAEdJREFUeNpi/P//PwOlgImBCmDUEBoZwoJNsLGxEWe819fXMxLlEmwK8YkzEWsjLgPAAJRi8eGGhob/hNQwjib7QWwIQIABADUIQmLvSoKkAAAAAElFTkSuQmCC") no-repeat center';

  //MARK: initPage --------------------------------

  //설정  페이지 초기화 컨트롤 법인 입수단.
  module.initPage = function (dewself) {
    // //if(!_dewself[dewself.id]) _dewself[dewself.id] = dewself;

    // var acpe = dewself.$content.find('input.ca-acpe');
    // var corp = dewself.$content.find('input.ca-corp');
    // var crnc = dewself.$content.find('input.ca-crnc');

    // if(!corp.length){
    //   corp = dewself.$content.find('select.ca-corp');
    // }

    // // var acpe_dews = (acpe.length) ? dews.ui.codepicker(acpe) : '';
    // // var corp_dews = (corp.length) ? dews.ui.codepicker(corp) : '';
    // // var crnc_dews = (crnc.length) ? dews.ui.textbox(crnc) : '';

    // var acpe_dews = (acpe.length) ? dewself[acpe[0].id] : '';
    // var corp_dews = (corp.length) ? dewself[corp[0].id] : '';
    // var crnc_dews = (crnc.length) ? dewself[crnc[0].id] : '';

    // var auth_yn = 'N';

    // var data = module.getLastAcpe();
    // if (data) {
    //   var temp;
    //   if (dews.ui.page.env.MA00008.format == "MM-yyyy") {
    //     temp = data.SETTL_YM.substr(4, 2) + '-' + data.SETTL_YM.substr(0, 4);
    //   }
    //   else {
    //     temp = data.SETTL_YM.substr(0, 4) + '-' + data.SETTL_YM.substr(4, 2);
    //   }

    //   if (acpe_dews) {
    //     acpe_dews.setData({ SETTL_YM: data.SETTL_YM, SETTL_NM: temp });
    //   }

    //   if($(corp).hasClass('ca-auth') ){
    //     auth_yn = 'Y';
    //   }

    //   _setPageAcpeControls(dewself, data.SETTL_YM, "", auth_yn, "corpInAcpe", "first");

    //   if(corp_dews){
    //     var acpeCode = !acpe_dews ? "" : acpe_dews.code();
    //     //최초 1회 셋팅
    //     corp_dews.setHelpParams(function () {
    //       return {
    //         settl_ym: acpeCode,
    //         corp_fg: "1",
    //         auth_yn : auth_yn
    //       };
    //     });
    //   }

    // }

    // if (acpe_dews) {
    //   acpe_dews.on('setData', function (e) {

    //     if (e.code)
    //       _setPageAcpeControls(dewself, e.code, "", auth_yn, "corpInAcpe", "");
    //     else {
    //       _setPageAcpeControls(dewself, '', "", auth_yn, "corpInAcpe", "");
    //     }

    //     if(corp_dews){
    //       corp_dews.setHelpParams(function () {
    //         return {
    //           settl_ym: e.code,
    //           corp_fg: "1",
    //           auth_yn : auth_yn
    //         };
    //       });
    //     }

    //   });
    // }

    // if (corp_dews && !$(corp).hasClass('dews-ui-multicodepicker')) {

    //   corp_dews.on('setData', function (e, data) {
    //     if (crnc_dews) {
    //       if (e.code) {
    //         crnc_dews.text(data.CRNC_CD);
    //       }
    //       else {
    //         crnc_dews.text("");
    //       }
    //     }

    //   });
    // }
    var $acpe = dewself.$content.find('input.ca-acpe');
    var $corp = (dewself.$content.find('input.ca-corp').length) ? dewself.$content.find('input.ca-corp') : dewself.$content.find('select.ca-corp');
    var $crnc = dewself.$content.find('input.ca-crnc');

    var dewsAcpe = ($acpe.length) ? dewself[$acpe[0].id] : '';
    var dewsCorp = ($corp.length) ? dewself[$corp[0].id] : '';
    var dewsCrnc = ($crnc.length) ? dewself[$crnc[0].id] : '';

    var auth_yn = 'N';
    var corpName;
    var data = module.getLastAcpe();
    var chkTime = "first";

    if($corp.hasClass("ca-auth") ){
      auth_yn = 'Y';
    }

    if(data && dewsAcpe){
      if(dews.ui.page.env.MA00008.format == "MM-yyyy"){
        corpName = data.SETTL_YM.substr(4, 2) + '-' + data.SETTL_YM.substr(0, 4);
      }
      else{
        corpName = data.SETTL_YM.substr(0, 4) + '-' + data.SETTL_YM.substr(4, 2);
      }
    }

    if(dewsAcpe){
      dewsAcpe.on('setData', function (e) {
        setPageControls(dewself, "corpInAcpe", e.code, "", auth_yn, chkTime);
        clearMainGrid(dewself);

        if(dewsCorp){
          dewsCorp.setHelpParams(function () {
            return {
              settl_ym: e.code,
              corp_fg: "1",
              auth_yn: auth_yn
            };
          });
        }
      });
    }

    if(dewsCorp){
      dewsCorp.on('setData', function (e, data) {
        clearMainGrid(dewself);
        if(dewsCrnc && !($corp.hasClass("dews-ui-multicodepicker"))){
          dewsCrnc.text(data.CRNC_CD ? data.CRNC_CD : "");
        }
      });

      if($corp.hasClass("dews-ui-multicodepicker")){
        dewsCorp.on("itemDelete", function(e){
          if(e.mode == "item"){
            clearMainGrid(dewself);
          }
        });
      }
    }

    if(dewsAcpe){
      dewsAcpe.setData({ SETTL_YM: data.SETTL_YM, SETTL_NM: corpName }, true);
    }
    chkTime = "";
  };

  //설정 페이지 초기화 연결그룹, 법인
  // 2019.12.09 방민섭 : initpage2 수정개발
  module.initPage2 = function (dewself) {

    // var acpe = dewself.$content.find('input.ca-acpe');
    // var grcorp = dewself.$content.find('input.ca-gr-corp');
    // var corp = dewself.$content.find('input.ca-corp');
    // var crnc = dewself.$content.find('input.ca-crnc');
    // var grcrnc = dewself.$content.find('input.ca-gr-crnc');

    // if(!grcorp.length){
    //   grcorp = dewself.$content.find('select.ca-gr-corp');
    // }

    // if(!corp.length){
    //   corp = dewself.$content.find('select.ca-corp');
    // }

    // var acpe_dews = (acpe.length) ? dewself[acpe[0].id] : '';
    // var grcorp_dews = (grcorp.length) ? dewself[grcorp[0].id] : '';
    // var corp_dews = (corp.length) ? dewself[corp[0].id] : '';
    // var crnc_dews = (crnc.length) ? dewself[crnc[0].id] : '';
    // var grcrnc_dews = (grcrnc.length) ? dewself[grcrnc[0].id] : '';

    // var psrelcode = "1|2|3|4|5";

    // if (dewself.$content.find('.ca-corp.ca-corp-sub').length) {
    //   psrelcode = "2|3|4|5";
    // }

    // var consgrp_auth_yn = 'N';
    // var corp_auth_yn = 'N';
    // var acpeCode = "";
    // var groupCode = "";

    // var data = module.getLastAcpe();

    // if(data){
    //   //날짜포맷적용
    //   var temp;
    //   if (dews.ui.page.env.MA00008.format == "MM-yyyy") {
    //     temp = data.SETTL_YM.substr(4, 2) + '-' + data.SETTL_YM.substr(0, 4);
    //   }
    //   else {
    //     temp = data.SETTL_YM.substr(0, 4) + '-' + data.SETTL_YM.substr(4, 2);
    //   }

    //   // 기본값 셋팅
    //   if (acpe_dews){acpe_dews.setData({ SETTL_YM: data.SETTL_YM, SETTL_NM: temp });}
    //   acpeCode = !acpe_dews ? "" : acpe_dews.code();

    //   // 연결그룹셋팅
    //   if(grcorp_dews){
    //     if(dewself.$content.find('.ca-gr-corp.ca-auth').length > 0){
    //       consgrp_auth_yn = 'Y';
    //     }

    //     _setPageAcpeControls(dewself, data.SETTL_YM, "", consgrp_auth_yn, "groupInAcpe");

    //     //최초 1회 셋팅
    //     grcorp_dews.setHelpParams(function () {
    //       return {
    //         settl_ym: acpeCode,
    //         corp_fg: "2",
    //         auth_yn : consgrp_auth_yn
    //       };
    //     });
    //   }

    //   // 연결법인셋팅
    //   if(corp_dews){
    //     if(dewself.$content.find('.ca-corp.ca-auth').length > 0){
    //       corp_auth_yn = 'Y';
    //     }

    //     if(grcorp_dews){
    //       if(dewself.$content.find('input.ca-gr-corp').length > 0){
    //         groupCode = grcorp_dews.code();
    //       }
    //       else if(dewself.$content.find('select.ca-gr-corp').length > 0){
    //         groupCode = grcorp_dews.codes().join("|");
    //       }
    //     }

    //     _setPageAcpeControls(dewself, data.SETTL_YM, groupCode, corp_auth_yn, "corpInGroup", "first");

    //     //최초 1회 셋팅
    //     corp_dews.setHelpParams(function () {
    //       return {
    //         settl_ym: acpeCode,
    //         consgrp_cd: groupCode,
    //         corp_fg: "1",
    //         psrel_cd: psrelcode,
    //         auth_yn : corp_auth_yn
    //       };
    //     });
    //   }

    //   // 코드피커 셋팅
    //   if (acpe_dews) {
    //     acpe_dews.on('change', function (e) {
    //       if (e.code){
    //         _setPageAcpeControls(dewself, e.code, "", consgrp_auth_yn, "groupInAcpe");
    //       }
    //       else {
    //         _setPageAcpeControls(dewself, '', "", consgrp_auth_yn, "groupInAcpe");
    //       }

    //       acpeCode = e.code;

    //       if(grcorp_dews){
    //         grcorp_dews.setHelpParams(function () {
    //           return {
    //             settl_ym: acpeCode,
    //             corp_fg: "2",
    //             auth_yn : consgrp_auth_yn
    //           };
    //         });
    //       }
    //     });
    //   }

    //   if (grcorp_dews) {
    //     grcorp_dews.on('setData', function (e, data) {

    //       _setPageAcpeControls(dewself, acpe_dews.code(), e.code, corp_auth_yn, "corpInGroup", "");

    //       if(corp_dews){
    //         corp_dews.setHelpParams(function () {
    //           return {
    //             settl_ym: acpeCode,
    //             consgrp_cd: e.code,
    //             corp_fg: "1",
    //             psrel_cd: psrelcode,
    //             auth_yn : corp_auth_yn
    //           };
    //         });
    //       }

    //       if (grcrnc_dews) {
    //         if (e.code) {
    //           grcrnc_dews.text(data.CRNC_CD);
    //         }
    //         else {
    //           grcrnc_dews.text("");
    //         }
    //       }

    //     });
    //   }

    // }//end LastAcpe

    // if (dewself.$content.find('.ca-acpe').length && data) {
    //   var temp;
    //   if (dews.ui.page.env.MA00008.format == "MM-yyyy") {
    //     temp = data.SETTL_YM.substr(4, 2) + '-' + data.SETTL_YM.substr(0, 4);
    //   }
    //   else {
    //     temp = data.SETTL_YM.substr(0, 4) + '-' + data.SETTL_YM.substr(4, 2);
    //   }

    //   if (dewself.$content.find('.ca-acpe').length) acpe.setData({ SETTL_YM: data.SETTL_YM, SETTL_NM: temp });

    //   if (dewself.$content.find('.ca-gr-corp').length) {

    //     var consgrp_auth_yn = 'N';
    //     if(dewself.$content.find('.ca-gr-corp.ca-auth').length > 0){
    //       consgrp_auth_yn = 'Y';
    //     }
    //     var g = module.getConsgrpInAcpe(data.SETTL_YM, consgrp_auth_yn);

    //     if (dewself.$content.find('select.dews-ui-multicodepicker.ca-gr-corp').length) {
    //       if (g.length > 0) {
    //         var grlist = [];
    //         $.each(g, function (i, d) {
    //           grlist.push({ CORP_CD: d.CONSGRP_CD, CORP_NM: d.CONSGRP_NM });
    //         });
    //         grcorps.setData(grlist);
    //       }
    //       else {
    //         grcorps.clear();
    //       }

    //       grcorps.setHelpParams(function () {
    //         return {
    //           settl_ym: acpe.code(),
    //           corp_fg: "2",
    //           auth_yn : consgrp_auth_yn
    //         };
    //       });

    //     } else {
    //       if (g.length > 0) {
    //         g = g[0];
    //         grcorp.setData({ CORP_CD: g.CONSGRP_CD, CORP_NM: g.CONSGRP_NM });
    //       }
    //       else {
    //         grcorp.clearData();
    //       }

    //       grcorp.setHelpParams(function () {
    //         return {
    //           settl_ym: acpe.code(),
    //           corp_fg: "2",
    //           auth_yn : consgrp_auth_yn
    //         };
    //       });
    //     }
    //   }//end ca-gr-corp

    //   if (dewself.$content.find('.ca-corp').length) {
    //     var corp_auth_yn = 'N';
    //     if(dewself.$content.find('.ca-corp.ca-auth').length > 0){
    //       corp_auth_yn = 'Y';
    //     }
    //     var data = module.getCorpInConsgrp(acpe.code(), grcorp.code(), psrelcode, corp_auth_yn);//법인이 있을 경우 연결법인은 싱글

    //     if (dewself.$content.find('select.dews-ui-multicodepicker.ca-corp').length) {
    //       corps.clear();
    //       if (data && data.length) {
    //          //2019.12.09 허기정 : 법인코드가 멀티코드피커인 경우 한 개만 설정
    //         corps.setData(data.slice(0, 1));
    //       }

    //       corps.setHelpParams(function () {
    //         return {
    //           settl_ym: acpe.code(),
    //           consgrp_cd: grcorp.code(),
    //           corp_fg: "1",
    //           psrel_cd: psrelcode,
    //           auth_yn : corp_auth_yn
    //         };
    //       });
    //     }
    //     else {
    //       corp.clearData();
    //       if (data && data.length) { corp.setData({ CORP_CD: data[0].CORP_CD, CORP_NM: data[0].CORP_NM }); }
    //       corp.setHelpParams(function () {
    //         return {
    //           settl_ym: acpe.code(),
    //           consgrp_cd: grcorp.code(),
    //           corp_fg: "1",
    //           psrel_cd: psrelcode,
    //           auth_yn : corp_auth_yn
    //         };
    //       });
    //     }
    //   }//end ca-corp

    //   acpe.on('change', function (e) {

    //     if (dewself.$content.find('.ca-gr-corp').length) {

    //       var consgrp_auth_yn = 'N';
    //       if(dewself.$content.find('.ca-gr-corp.ca-auth').length > 0){
    //         consgrp_auth_yn = 'Y';
    //       }
    //       var g = module.getConsgrpInAcpe(e.code, consgrp_auth_yn);

    //       if (dewself.$content.find('select.dews-ui-multicodepicker.ca-gr-corp').length) {
    //         if (g.length > 0) {
    //           var grlist = [];
    //           $.each(g, function (i, d) {
    //             // 기존코드가 해당 결산연월에 있을 경우 없는 그룹을 제외한 나머지를 set
    //             if (grcorps.codes().length > 0) {
    //               $.each(grcorps.codes(), function (j, row) {
    //                 if (d.CONSGRP_CD == row) {
    //                   grlist.push({ CORP_CD: row, CORP_NM: grcorps.texts()[j] });
    //                 }
    //               });
    //             }
    //             else {
    //               grlist.push({ CORP_CD: d.CONSGRP_CD, CORP_NM: d.CONSGRP_NM });
    //             }
    //           });
    //           grcorps.clear();
    //           grcorps.setData(grlist);
    //         }
    //         else {
    //           grcorps.clear();
    //         }

    //         grcorps.setHelpParams(function () {
    //           return {
    //             settl_ym: e.code,
    //             corp_fg: "2",
    //             auth_yn : consgrp_auth_yn
    //           };
    //         });
    //       }
    //       else {
    //         if (g.length > 0) {
    //           // 기존코드가 해당 결산연월에 있을 경우 도움창 값 변경 x
    //           if (grcorp.code()) {
    //             var confirm = $.grep(g, function (row, i) {
    //               return grcorp.code() == row.CONSGRP_CD;
    //             });

    //             if (confirm.length > 0) {
    //               g = confirm[0];
    //             }
    //             else {
    //               g = g[0];
    //             }
    //           }
    //           else {
    //             g = g[0];
    //           }

    //           grcorp.setData({ CORP_CD: g.CONSGRP_CD, CORP_NM: g.CONSGRP_NM });
    //         }
    //         else {
    //           grcorp.clearData();
    //           if (dewself.$content.find('.ca-corp').length) {
    //             if (dewself.$content.find('select.dews-ui-multicodepicker.ca-corp').length) {
    //               corps.clear();
    //             }
    //             else {
    //               corp.clearData();
    //             }
    //           }
    //         }
    //         grcorp.setHelpParams(function () {
    //           return {
    //             settl_ym: e.code,
    //             corp_fg: "2",
    //             auth_yn: consgrp_auth_yn
    //           };
    //         });
    //       }
    //     }
    //   });// end acpe

    //   grcorp.on('change', function (e) {
    //     if (dewself.$content.find('.ca-corp').length) {
    //       var psrelcode = "1|2|3|4|5";
    //       if (dewself.$content.find('.ca-corp.ca-corp-sub').length) {
    //         psrelcode = "2|3|4|5";
    //       }

    //       var corp_auth_yn  = 'N';
    //       if(dewself.$content.find('.ca-corp.ca-auth').length > 0){
    //         corp_auth_yn = 'Y';
    //       }
    //       var data = module.getCorpInConsgrp(acpe.code(), e.code, psrelcode, corp_auth_yn);

    //       if (dewself.$content.find('select.dews-ui-multicodepicker.ca-corp').length) {
    //         corps.clear();
    //         if (data && data.length) {
    //           corps.setData(data.slice(0, 1));
    //         }

    //         corps.setHelpParams(function () {
    //           return {
    //             settl_ym: acpe.code(),
    //             consgrp_cd: e.code,
    //             corp_fg: "1",
    //             psrel_cd: psrelcode,
    //             auth_yn: corp_auth_yn
    //           };
    //         });
    //       }
    //       else {
    //         corp.clearData();
    //         if (data && data.length) {
    //           if (corp.code()) {
    //             var confirm = $.grep(data, function (row, i) {
    //               return corp.code() == row.CORP_CD;
    //             });

    //             if (confirm.length > 0) {
    //               data = confirm[0];
    //             }
    //             else {
    //               data = data[0];
    //             }
    //           }
    //           else {
    //             data = data[0];
    //           }
    //           corp.setData({ CORP_CD: data.CORP_CD, CORP_NM: data.CORP_NM });
    //         }

    //         corp.setHelpParams(function () {
    //           return {
    //             settl_ym: acpe.code(),
    //             consgrp_cd: e.code,
    //             corp_fg: "1",
    //             psrel_cd: psrelcode,
    //             auth_yn: corp_auth_yn
    //           };
    //         });
    //       }
    //     }
    //   });

    // }//end LastAcpe

    var $acpe = dewself.$content.find('input.ca-acpe');
    var $grpcorp = (dewself.$content.find('input.ca-gr-corp').length) ? dewself.$content.find('input.ca-gr-corp') : dewself.$content.find('select.ca-gr-corp');
    var $grpcrnc = dewself.$content.find('input.ca-gr-crnc');
    var $corp = (dewself.$content.find('input.ca-corp').length) ? dewself.$content.find('input.ca-corp') : dewself.$content.find('select.ca-corp');
    var $crnc = dewself.$content.find('input.ca-crnc');

    var dewsAcpe = ($acpe.length) ? dewself[$acpe[0].id] : '';
    var dewsGrpCorp = ($grpcorp.length) ? dewself[$grpcorp[0].id] : '';
    var dewsGrpCrnc = ($grpcrnc.length) ? dewself[$grpcrnc[0].id] : '';
    var dewsCorp = ($corp.length) ? dewself[$corp[0].id] : '';
    var dewsCrnc = ($crnc.length) ? dewself[$crnc[0].id] : '';

    var corpName;
    var data = module.getLastAcpe();
    var grp_auth_yn = 'N';
    var auth_yn = 'N';
    var psrelcode = "1|2|3|4|5";
    var chkTime = "first";

    if(dewself.$content.find('.ca-corp.ca-corp-sub').length){
      psrelcode = "2|3|4|5";
    }

    if($grpcorp.hasClass("ca-auth")){
      grp_auth_yn = 'Y';
    }

    if($corp.hasClass("ca-auth")){
      auth_yn = 'Y';
    }

    if(data && dewsAcpe){
      if(dews.ui.page.env.MA00008.format == "MM-yyyy"){
        corpName = data.SETTL_YM.substr(4, 2) + '-' + data.SETTL_YM.substr(0, 4);
      }
      else{
        corpName = data.SETTL_YM.substr(0, 4) + '-' + data.SETTL_YM.substr(4, 2);
      }
    }

    if(dewsAcpe){
      dewsAcpe.on('setData', function(e){
        setPageControls(dewself, "consgrpInAcpe", e.code, "", grp_auth_yn, chkTime);
        clearMainGrid(dewself);

        if(dewsGrpCorp){
          dewsGrpCorp.setHelpParams(function(){
            return {
              settl_ym: e.code,
              corp_fg: "2",
              auth_yn: grp_auth_yn
            };
          });
        }
      });
    }

    if(dewsGrpCorp){
      dewsGrpCorp.on('setData', function(e, data){
        setPageControls(dewself, "corpInConsgrp", dewsAcpe.code(), e.code, auth_yn, chkTime);
        clearMainGrid(dewself);
        if(dewsGrpCrnc && !($grpcorp.hasClass("dews-ui-multicodepicker"))){
          dewsGrpCrnc.text(data.CRNC_CD ? data.CRNC_CD : "");
        }

        if(dewsCorp){
          dewsCorp.setHelpParams(function () {
            return {
              settl_ym: dewsAcpe.code(),
              consgrp_cd: e.code,
              corp_fg: "1",
              psrel_cd: psrelcode,
              auth_yn: auth_yn
            };
          });
        }
      });
    }

    if(dewsCorp){
      dewsCorp.on('setData', function (e, data) {
        clearMainGrid(dewself);
        if(dewsCrnc && !($corp.hasClass("dews-ui-multicodepicker"))){
          dewsCrnc.text(data.CRNC_CD ? data.CRNC_CD : "");
        }
      });

      if($corp.hasClass("dews-ui-multicodepicker")){
        dewsCorp.on("itemDelete", function(e){
          if(e.mode == "item"){
            clearMainGrid(dewself);
          }
        });
      }
    }

    if(dewsAcpe){
      dewsAcpe.setData({ SETTL_YM: data.SETTL_YM, SETTL_NM: corpName }, true);
    }
    chkTime = "";
  };

  module.initPage3 = function (dewself) {
    var conditionControls = dewself.$content.find('.dews-ui-condition-panel .dews-form-control');
    if (conditionControls.length) {
      var acpeControl, consgrpControl, corpControl;
      var psrelcode = "1|2|3|4|5";
      var controlInfoList = [];

      $(conditionControls).each(function (index, node) {
        if (!$(node).hasClass("disabled") && node.id) {
          var auth = "N"

          var controlInfo = {};
          controlInfo.ID = node.id;

          if($(node).hasClass("ca-acpe")) {
            acpeControl = $(node);
            controlInfo.TYPE = "SETTL_YM";
          } else if($(node).hasClass("ca-gr-corp")) {
            consgrpControl = $(node);
            if($(node).hasClass("ca-auth")) {
              auth = "Y";
            }

            controlInfo.TYPE = "CONSGRP_CD";
            controlInfo.AUTH = auth;
          } else if($(node).hasClass("ca-corp")) {
            corpControl = $(node);

            if($(node).hasClass("ca-auth")) {
              auth = "Y";
            }

            if($(node).hasClass("ca-corp-sub")) {
              psrelcode = "2|3|4|5";
            }

            controlInfo.TYPE = "CORP_CD";
            controlInfo.AUTH = auth;
          } else if($(node).hasClass("ca-prevYear")) {
            controlInfo.TYPE = "SETTL_YM_PY";
            prevYearControl = $(node);
          } else if($(node).hasClass("ca-prevMonth")) {
            controlInfo.TYPE = "SETTL_YM_PM";
            prevMonthControl = $(node);
          }

          controlInfoList = controlInfoList.concat(controlInfo);
        }
      })

      dews.api.post(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getControlDefaultValue')), {
        async: false,
        data: {
          controlInfoList: JSON.stringify(controlInfoList),
          psrel_cd : psrelcode
        }
      }).done(function (data) {
        if (data) {
          var settl_ym = '';

          if(acpeControl){
            var controlId = acpeControl[0].id;
            settl_ym = data[controlId];
            var settl_nm = '';
            if (dews.ui.page.env.MA00008.format == "MM-yyyy") {
              settl_nm = settl_ym.substr(4, 2) + '-' + settl_ym.substr(0, 4);
            }
            else {
              settl_nm = settl_ym.substr(0, 4) + '-' + settl_ym.substr(4, 2);
            }

            dewself[controlId].setData({ SETTL_YM: settl_ym, SETTL_NM: settl_nm });
            delete data[controlId];
          } else {
            settl_ym = module.getLastAcpe().SETTL_YM;
          }

          if(settl_ym) {
            var consgrp_cd = '';

            if(consgrpControl) {
              var controlId = consgrpControl[0].id;
              var controlInfo = $.grep(controlInfoList, function(data, idx) { return data.ID == controlId });
              var authYn = (typeof(controlInfo) != "undefined" && controlInfo.length > 0) ? controlInfo[0].AUTH : '';

              if(consgrpControl.hasClass('dews-ui-multicodepicker')){
                dewself[controlId].setData(data[controlId]);
                consgrp_cd = dewself[controlId].codes().join("|");
              } else {
                dewself[controlId].setData(data[controlId].slice(0,1));
                consgrp_cd = dewself[controlId].code();
              }

              delete data[controlId];

              dewself[controlId].setHelpParams(function () {
                return {
                  settl_ym: settl_ym,
                  corp_fg: "2",
                  auth_yn: authYn
                };
              });
            }

            if(corpControl){
              var controlId = corpControl[0].id;
              var controlInfo = $.grep(controlInfoList, function(data, idx) { return data.ID == controlId });
              var authYn = (typeof(controlInfo) != "undefined" && controlInfo.length > 0) ? controlInfo[0].AUTH : '';

              if(corpControl.hasClass('dews-ui-multicodepicker')){
                dewself[controlId].setData(data[controlId]);
              } else {
                dewself[controlId].setData(data[controlId].slice(0,1));
              }

              delete data[controlId];

              dewself[controlId].setHelpParams(function () {
                return {
                  settl_ym: settl_ym,
                  consgrp_cd: consgrp_cd,
                  corp_fg: "1",
                  psrel_cd: psrelcode,
                  auth_yn: authYn
                };
              });
            }
          }

          $.each(Object.keys(data), function(idx, key) {
            var id = "#" + key;
            var findControl = dewself.$content.find(id);
            var dewsControl = $(findControl).data('dews-control');

            if(findControl.hasClass("dews-ui-monthperiodpicker") || findControl.hasClass("dews-ui-weekperiodpicker")) {
              if(data[key].length > 1) {
                dewsControl.setPeriod(data[key][0].code, data[key][1].code);
              }
            } else if (findControl.hasClass("dews-ui-periodpicker")) {
              if(data[key].length > 1) {
                dewsControl.setStartDate(data[key][0].code);
                dewsControl.setEndDate(data[key][1].code);
              }
            } else if(findControl.hasClass('dews-ui-codepicker')){
              var obj = {};
              obj[dewsControl.options.codeField] = data[key][0].code;
              obj[dewsControl.options.textField] = data[key][0].name;
              dewsControl.setData(obj);
            } else if (findControl.hasClass("dews-ui-textbox")) {
              dewsControl.text(data[key][0].code);
            } else if(findControl.hasClass('dews-ui-multicodepicker')){
              var datasource = [];
              for(var i = 0; i < data[key].length; i++){
                var obj = {};
                obj[dewsControl.options.codeField] = data[key][i].code;
                obj[dewsControl.options.textField] = data[key][i].name;
                datasource.push(obj);
              }

              dewsControl.setData(datasource);
            } else {
              dewsControl.value(data[key][0].code);
              if (typeof (dewsControl.text) == "function") {
                dewsControl.text(data[key][0].name);
              }
            }
          });
        }
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.error(error);
      });
    }
  };

  //설정 검증 팝업, 도움창, 버튼
  module.initVerify = function (verifyoption, callback) {
    _initPopupGrid(verifyoption).setpopup();
    _getVerifyDialog(verifyoption, callback);
  };

  //설정 로그인 사용자 법인
  module.setCompanyCorp = function (ctl) {
    var data = module.getCompanyCorp();
    if (data) {
      if (ctl.inputText.context.className.indexOf('dews-ui-codepicker') < 0) {
        ctl.setData([{ CORP_CD: data.CORP_CD, CORP_NM: data.CORP_NM }]);
      }
      else {
        ctl.setData({ CORP_CD: data.CORP_CD, CORP_NM: data.CORP_NM });
      }
    }
  };

  //설정 마지막 결산년월 등록
  module.setLastAcpe = function (ctl) {
    var data = module.getLastAcpe();
    if (data) {
      var temp = data.SETTL_YM.substr(0, 4) + '-' + data.SETTL_YM.substr(4, 2);

      ctl.setData({ SETTL_YM: data.SETTL_YM, SETTL_NM: temp });
    }
  };

  //설정 결산년월에 있는 법인 (single)
  // 2022.02.08 방민섭 : 권한이 있는 법인이 다수일 경우 선택x
  module.setCorpInAcpe = function (ctl, YmDate, crnc, auth_yn, time) {
    var result;
    if (ctl) {
      if (ctl.code()) {
        result = module.getCorpInAcpeCorpList(YmDate, ctl.code(), auth_yn);
      }
      else {
        if(time == "first"){
          result = module.getCorpInAcpe(YmDate, auth_yn);
        }
      }

      if(result){
        if(time == "first"){
          if(result.length == 1){
            ctl.setData({ CORP_CD: result[0].CORP_CD, CORP_NM: result[0].CORP_NM, CRNC_CD: result[0].CRNC_CD });
            if(crnc){ crnc.text(result[0].CRNC_CD); }
          }
          else {
            ctl.setData({ CORP_CD: '', CORP_NM: '' });
            if(crnc){ crnc.text(""); }
          }
        }
        else {
          ctl.setData({ CORP_CD: result[0].CORP_CD, CORP_NM: result[0].CORP_NM, CRNC_CD: result[0].CRNC_CD });
        }
      }
      else {
        ctl.setData({ CORP_CD: '', CORP_NM: '' });
      }
    }
  };

  //설정 결산년월에 있는 법인 (multi)
  module.setMultiCorpInAcpe = function (ctl, YmDate, auth_yn, time) {
    var result;
    if (ctl) {
      var codes = ctl.codes().join("|");
      if (codes != '') {
        ctl.clear();
        result = module.getCorpInAcpeCorpList(YmDate, codes, auth_yn);
      }
      else {
        if(time == "first"){
          result = module.getCorpInAcpe(YmDate, auth_yn);
        }
      }

      //2019.12.09 허기정 : 법인코드가 멀티코드피커인 경우 한 개만 설정
      // 2022.01.13 방민섭 : 권한이 있는 법인이 다수일 경우 선택x
      if(result){
        if(time == "first"){
          if(result.length == 1){
            ctl.setData(result.slice(0,1));
          }
          else {
            ctl.setData({});
          }
        }
        else {
          ctl.setData(result);
        }
      }
    }
  };

  //설정 결산년월에 있는 그룹 (single)
  // 2019.12.09 방민섭 : 결산연월에 있는 연결그룹 조회 API 생성
  // 2022.02.08 방민섭 : 권한이 있는 법인이 다수일 경우 선택x
  module.setConsgrpInAcpe = function (ctl, YmDate, crnc, auth_yn) {
    var result;
    if (ctl) {
      if (ctl.code()) {
        result = module.getConsgrpInAcpeConsgrpList(YmDate, ctl.code(), auth_yn);
      }
      else {
        result = module.getConsgrpInAcpe(YmDate, auth_yn);
      }

      if(result){
        if(result.length == 1){
          ctl.setData({ CORP_CD: result[0].CONSGRP_CD, CORP_NM: result[0].CONSGRP_NM });
          if(crnc){ crnc.text(result[0].CRNC_CD); }
        }
        else {
          ctl.setData({ CORP_CD: '', CORP_NM: '' });
          if(crnc){ crnc.text(""); }
        }
      }
      else {
        ctl.setData({ CORP_CD: '', CORP_NM: '' });
      }
    }
  };

  //설정 결산년월에 있는 그룹 (multi)
  // 2019.12.09 방민섭 : 결산연월에 있는 연결그룹 조회 API 생성
  module.setMultiConsgrpInAcpe = function (ctl, YmDate, auth_yn) {
    var result;
    if (ctl) {
      var codes = ctl.codes().join("|");
      if (codes != '') {
        ctl.clear();
        result = module.getConsgrpInAcpeConsgrpList(YmDate, codes, auth_yn);
      }
      else {
        result = module.getConsgrpInAcpe(YmDate, auth_yn);
      }

      //2019.12.09 허기정 : 법인코드가 멀티코드피커인 경우 한 개만 설정
      // 2022.01.13 방민섭 : 권한이 있는 법인이 다수일 경우 선택x
      if(result){
        if(result.length == 1){
          ctl.setData(result.slice(0,1));
        }
        else {
          ctl.setData({});
        }
      }
    }
  };

  //설정 결산년월 & 연결그룹에 있는 법인 (single)
  // 2019.12.09 방민섭 : 결산년월 & 연결그룹에 있는 연결법인 조회 API 생성
  // 2022.02.08 방민섭 : 권한이 있는 법인이 다수일 경우 선택x
  module.setCorpInConsgrp = function (ctl, YmDate, groupCode, psrelCode, crnc, auth_yn, time) {
    var result;
    if (ctl) {
      if (ctl.code()) {
        result = module.getCorpInConsgrpCorpList(YmDate, groupCode, ctl.code(), psrelCode, auth_yn);
      }
      else {
        if(time == "first"){
          result = module.getCorpInConsgrp(YmDate, groupCode, psrelCode, auth_yn);
        }
      }

      if(result){
        if(time == "first"){
          if(result.length == 1){
            ctl.setData({ CORP_CD: result[0].CORP_CD, CORP_NM: result[0].CORP_NM });
            if(crnc){ crnc.text(result[0].CRNC_CD); }
          }
          else {
            ctl.setData({ CORP_CD: '', CORP_NM: '' });
            if(crnc){ crnc.text(""); }
          }
        }
        else {
          ctl.setData({ CORP_CD: result[0].CORP_CD, CORP_NM: result[0].CORP_NM });
        }
      }
      else {
        ctl.setData({ CORP_CD: '', CORP_NM: '' });
      }
    }
  };

  //설정 결산년월 & 연결그룹에 있는 법인 (multi)
  // 2019.12.09 방민섭 : 결산년월 & 연결그룹에 있는 연결법인 조회 API 생성
  // 2022.01.13 방민섭 : 권한이 있는 법인이 다수일 경우 선택x
  module.setMultiCorpInConsgrp = function (ctl, YmDate, groupCode, psrelCode, auth_yn, time) {
    var result;
    if (ctl) {
      var codes = ctl.codes().join("|");
      if (codes != '') {
        ctl.clear();
        result = module.getCorpInConsgrpCorpList(YmDate, groupCode, codes, psrelCode, auth_yn);
      }
      else {
        if(time == "first"){
          result = module.getCorpInConsgrp(YmDate, groupCode, psrelCode, auth_yn);
        }
      }

      if(result){
        if(time == "first"){
          if(result.length == 1){
            ctl.setData(result.slice(0,1));
          }
          else {
            ctl.setData({});
          }
        }
        else {
          ctl.setData(result);
        }
      }

      // if(result && result.length > 0){
      //   if(time == "first"){
      //     ctl.setData(result.slice(0,1));
      //   }
      //   else{
      //     ctl.setData(result);
      //   }
      // }
    }
  };

  //설정 전기, 전월 설정
  module.setPrevAcpe = function (ctl1, ctl2, YmDate) {
    var result = module.getPrevInfo(YmDate);
    if (result) {
      ctl1.value(result.LYSETTL_YM);
      ctl2.value(result.LMSETTL_YM);
    }
  };

  /**
   * 검증패널 보이기/숨기기
   * @param dewself  : dewself 객체
   * @param show : visble true/false
   */
  module.showPopup = function (dewself, show) {

    var $btnimg = dewself.$content.find('.ca-btn-err>.ca-btn-img');

    // btn 버튼의 click 이벤트 프로세스를 사용하기 위해 인위적으로 셋팅
    if ($btnimg.hasClass('ca-img-up')) {
      $btnimg.removeClass('ca-img-up');
      $btnimg[0].style.background = btnUpImage;
    }

     if (show) {
      var $btn = dewself.$content.find('.ca-btn-err');
      $btn.click();
    } else {
      dews.ui.popuppanel(dewself.$content.find('#popUpPanel')).hide();
    }
  };

  //END: initPage --------------------------------

  //MARK: pageUtil --------------------------------

  //조회 코드 결산년월 class .ca-acpe
  module.getAcpeCode = function (dewself) {
    return _getAcpeCode(dewself);
  };

  //조회 코드 그룹법인 class .ca-grcorp
  module.getGrcorpCode = function (dewself) {
    return _getGrcorpCode(dewself);
  };

  //조회 코드 결산년월 class .ca-corp
  module.getCorpCode = function (dewself) {
    return _getCorpCode(dewself);
  };

  //팝업 CA 작성상태 변경 도움창
  function _getVerifyDialog(verifyoption, callback) {
    var $btn = verifyoption.dewself.$content.find('.dews-button-group>.ca-btn-state');
    // /$btn.text('완료/승인');

    $btn.click(function () {
      // 그리드가 한 개인 경우
      if (verifyoption.dewself.$content.find('.dews-ui-grid').length < 3) {
        var maingrid = dews.ui.grid(verifyoption.dewself.$content.find('.dews-ui-grid:first'));
        if (maingrid.dataSource.getDirtyDataCount() > 0) {
          dews.alert(dews.localize.get('저장되지 않은 데이터가 있습니다.', 'M0000751', dews.localize.language(), "CASENV00100"), "ico3");
        }
        else {
          dews.ui.dialog(verifyoption.dewself.menu.id + '_POP', {
            // url: '/view/CA/' + verifyoption.dewself.menu.id + '_POP',
            url: verifyoption.dewself.menu.url + '_POP',
            title: dews.localize.get('완료/승인', 'D0009714', dews.localize.language(), "CASENV00100"),
            width: 743,
            height: 497,
            initData: { acpe: _getAcpeCode(verifyoption.dewself), acpenm: _getAcpeText(verifyoption.dewself), corps: _getCorpCode(verifyoption.dewself), verifyoption: verifyoption },
            ok: function (data) {
              if (typeof callback === 'function') {
                if (data)
                  callback(true);
                else
                  callback(false);
              }
            }
          }).open();
        }
      }
      // 그리드가 두 개인 경우
      else {
        var maingrid = dews.ui.grid(verifyoption.dewself.$content.find('.dews-ui-grid:first'));
        var subgrid = dews.ui.grid(verifyoption.dewself.$content.find('.dews-ui-grid:eq(1)'));
        if (maingrid.dataSource.getDirtyDataCount() > 0 || subgrid.dataSource.getDirtyDataCount() > 0) {
          dews.alert(dews.localize.get('저장되지 않은 데이터가 있습니다.', 'M0000751', dews.localize.language(), "CASENV00100"), "ico3");
        }
        else {
          dews.ui.dialog(verifyoption.dewself.menu.id + '_POP', {
            // url: '/view/CA/' + verifyoption.dewself.menu.id + '_POP',
            url: verifyoption.dewself.menu.url + '_POP',
            title: dews.localize.get('완료/승인', 'D0009714', dews.localize.language(), "CASENV00100"),
            width: 743,
            height: 497,
            initData: { acpe: _getAcpeCode(verifyoption.dewself), acpenm: _getAcpeText(verifyoption.dewself), corps: _getCorpCode(verifyoption.dewself), verifyoption: verifyoption },
            ok: function (data) {
              if (typeof callback === 'function') {
                if (data)
                  callback(true);
                else
                  callback(false);
              }
            }
          }).open();
        }
      }
    });
  }

  //팝업 페널 / 그리드 / 버튼 설정
  function _initPopupGrid(verifyoption) {
    if (verifyoption.dewself == undefined) return;

    verifyoption.vrfc_fg = verifyoption.vrfc_fg || '';
    verifyoption.filecode = verifyoption.filecode || '';
    verifyoption.grcorp =  verifyoption.grcorp || '';

    var _popSource;
    var _popGrid;

    return {
      setpopup: function () {
        var $btn = verifyoption.dewself.$content.find('.ca-btn-err');
        if (!$btn.hasClass('ca-img')) {
          $btn.addClass('ca-img');
          $btn.html('<div class = "ca-btn-img" style = "width:17px!important;height:17px!important"></div>');
          var popup = '<div class="dews-popup-panel" id="popUpPanel" style = "height:350px;display: none">' +
            '<div class="dews-popup-item">' +
            '<div class="dews-ui-grid" id="popGrid"></div>' +
            '</div>' +
            '</div>';
          verifyoption.dewself.$content.append(popup);
        }

        _popSource = this.setPopGridSource();
        _popGrid = this.setpopGrid();

        var $btnimg = verifyoption.dewself.$content.find('.ca-btn-err>.ca-btn-img');
        $btnimg[0].style.background = btnUpImage;

        $btn.on('click', function () {
          if ($btnimg.hasClass('ca-img-up')) {
            $btnimg.removeClass('ca-img-up');
            $btnimg[0].style.background = btnUpImage;
            dews.ui.popuppanel(verifyoption.dewself.$content.find('#popUpPanel')).hide();
          }
          else {
            // 그리드가 한 개인 경우
            if(dews.ui.grid(verifyoption.dewself.$content.find('.dews-ui-grid')).length < 3){
              var maingrid = dews.ui.grid(verifyoption.dewself.$content.find('.dews-ui-grid:first'));
              if (!maingrid.dataItems().length) {
                dews.alert(dews.localize.get('조회된 데이터가 없습니다.', 'M0000003', dews.localize.language(), "CASENV00100"), "ico3");
              }
              else {
                $btnimg.addClass('ca-img-up');
                $btnimg[0].style.background = btnDownImage;
                dews.ui.popuppanel(verifyoption.dewself.$content.find('#popUpPanel')).show();

                // dews.ui.loading.show({
                //   target:'#popUpPanel',
                //   type: 'tiny',
                //   text: '조회중입니다.'
                // });
                _popSource.read();
                //dews.ui.loading.hide();

                var $btnPopupClose = verifyoption.dewself.$content.find('#popUpPanel > button.dews-popup-close-button');
                $btnPopupClose.on('click', function () {
                  if ($btnimg.hasClass('ca-img-up')) {
                    $btnimg.removeClass('ca-img-up');
                  }
                  $btnimg[0].style.background = btnUpImage;
                });
              }
            }
            // 그리드가 두 개인 경우
            else{
              var maingrid = dews.ui.grid(verifyoption.dewself.$content.find('.dews-ui-grid:first'));
              var subgrid = dews.ui.grid(verifyoption.dewself.$content.find('.dews-ui-grid:eq(1)'));
              if (!maingrid.dataItems().length && !subgrid.dataItems().length) {
                dews.alert(dews.localize.get('조회된 데이터가 없습니다.', 'M0000003', dews.localize.language(), "CASENV00100"), "ico3");
              }
              else {
                $btnimg.addClass('ca-img-up');
                $btnimg[0].style.background = btnDownImage;
                dews.ui.popuppanel(verifyoption.dewself.$content.find('#popUpPanel')).show();

                // dews.ui.loading.show({
                //   target:'#popUpPanel',
                //   type: 'tiny',
                //   text: '조회중입니다.'
                // });
                _popSource.read();
                //dews.ui.loading.hide();

                var $btnPopupClose = verifyoption.dewself.$content.find('#popUpPanel > button.dews-popup-close-button');
                $btnPopupClose.on('click', function () {
                  if ($btnimg.hasClass('ca-img-up')) {
                    $btnimg.removeClass('ca-img-up');
                  }
                  $btnimg[0].style.background = btnUpImage;
                });
              }
            }
          }
        });
      },
      setPopGridSource: function () {
        var url = verifyoption.vrfc_fg == ""? "getMultiCorpVerifyMessage" : "getMultiCorpVerifyMessage2";
        var popSource = dews.ui.dataSource('popSource', {
          grid: true,
          transport: {
            read: {
              url: dews.url.getApiUrl('CA', 'CaCommonService', url),
              data: function (e) {
                var CorpCode = '';
                var YmDate = '';
                var acpe = dews.ui.codepicker(verifyoption.dewself.$content.find('.ca-acpe'));
                var corp = dews.ui.codepicker(verifyoption.dewself.$content.find('.ca-corp'));
                if (verifyoption.dewself.$content.find('.ca-acpe').length) { YmDate = acpe.code(); }
                if (verifyoption.dewself.$content.find('.ca-corp').length) {
                  if (verifyoption.dewself.$content.find('select.dews-ui-multicodepicker.ca-corp').length) {
                    CorpCode = corp.codes().join('|');
                  }
                  else {
                    CorpCode = corp.code();
                  }
                }
                return {
                  vrfc_fg: verifyoption.vrfc_fg,
                  CorpCode: CorpCode,
                  FileCode: verifyoption.filecode,
                  YmDate: YmDate,
                  GrCorp: verifyoption.grcorp
                };
              }
            }
          },
          schema: {
            model: {
              id: "CORP_CD",
              fields: [
                { field: "CORP_CD" },
                { field: "CORP_NM" },
                { field: "VRFC_FG" },
                { field: "VRFC_NM" },
                { field: "ERR_NM" },
                { field: "ERR_CD" },
                { field: "ERR_MSG" },
                { field: "ERR_TP" },
                { field: "LINE_SQ" },
              ]
            }
          },
          error: function (e) {
            if (e) {
              dews.error({
                message: e.message || dews.localize.get("데이터를 전송받지 못하였습니다.", 'M0000084'),
                error: e.error || ''
              });
            }
          }
        });
        return popSource;
      },
      setpopGrid: function () {
        var popGrid =
          dews.ui.grid(verifyoption.dewself.$content.find('#popGrid'), {
            dataSource: _popSource,
            selectable: true,
            autoBind: false,
            editable: false,
            checkable: false,
            sortable: false,
            height: 320,
            columns: [
              {
                field: "CORP_CD",
                title: dews.localize.get('법인코드', 'D0002108', dews.localize.language(), verifyoption.dewself.menu.id),
                width: 25,
                align: "left"
              },
              {
                field: "CORP_NM",
                title: dews.localize.get('법인명', 'D0002107', dews.localize.language(), verifyoption.dewself.menu.id),
                width: 25,
                align: "left"
              },
              {
                field: "VRFC_NM",
                title: dews.localize.get('검증구분', 'D0008525', dews.localize.language(), verifyoption.dewself.menu.id),
                width: 25,
                align: "center",
              },
              {
                field: "ERR_NM",
                title: dews.localize.get('오류구분', 'D0006722', dews.localize.language(), verifyoption.dewself.menu.id),
                width: 25,
                align: "center"
              },
              {
                field: "ERR_CD",
                title: dews.localize.get('오류코드', 'D0006716', dews.localize.language(), verifyoption.dewself.menu.id),
                width: 20,
                align: "center"
              },
              {
                field: "ERR_MSG",
                title: dews.localize.get('오류메시지', 'D0006723', dews.localize.language(), verifyoption.dewself.menu.id),
                width: 250,
                align: "left"
              },
              { field: "VRFC_FG", title: dews.localize.get("오류구분코드", 'D0006724'), visible: false },
              { field: "ERR_TP", title: dews.localize.get("오류구분코드", 'D0006724'), visible: false },
              { field: "LINE_SQ", title: dews.localize.get("라인순번", 'D0003400'), visible: false }
            ],
            clicked: function (e) {
              if (e.row.data != null && e.row.data.LINE_SQ) {
                var maingrid = dews.ui.grid(verifyoption.dewself.$content.find('.dews-ui-grid:first'));

                var option = {
                  fields: ['LINE_SQ'],
                  value: e.row.data.LINE_SQ,
                  startIndex: 1,
                  partialMatch: false
                };
                maingrid.searchCell(option);
              }
            }
          });

          popGrid.hideColumn('VRFC_NM');

        return popGrid;
      }
    };
  }

  //메뉴 컨트롤 등록 API
  function _setPageAcpeControls(dewself, settl_ym, consgrp_cd, auth_yn, flag, time) {

    if (settl_ym) {

      var grCorp = dewself.$content.find('input.ca-gr-corp');
      var corp = dewself.$content.find('input.ca-corp');
      var crnc = dewself.$content.find('input.ca-crnc');
      var grcrnc = dewself.$content.find('input.ca-gr-crnc');
      var prevYear = dewself.$content.find('input.ca-prevYear');
      var prevMonth = dewself.$content.find('input.ca-prevMonth');

      if(!grCorp.length){
        grCorp = dewself.$content.find('select.ca-gr-corp');
      }

      if(!corp.length){
        corp = dewself.$content.find('select.ca-corp');
      }

      var grCorp_dews = (grCorp.length) ? dewself[grCorp[0].id] : '';
      var corp_dews = (corp.length) ? dewself[corp[0].id] : '';
      var crnc_dews = (crnc.length) ? dewself[crnc[0].id] : '';
      var grcrnc_dews = (grcrnc.length) ? dewself[grcrnc[0].id] : '';
      var prevYear_dews = (prevYear.length) ? dewself[prevYear[0].id] : '';
      var prevMonth_dews = (prevMonth.length) ? dewself[prevMonth[0].id] : '';

      var psrelcode = "1|2|3|4|5";
      var groupCode = "";
      if (dewself.$content.find('.ca-corp.ca-corp-sub').length) {
        psrelcode = "2|3|4|5";
      }

      if(grCorp_dews){
        groupCode = consgrp_cd;
      }

      // 2019.12.09 방민섭 : 각 컨트롤에 따른 분기처리
      var prevInfo = module.getPrevInfo(settl_ym);
      if (prevInfo) {
        if (prevYear_dews) prevYear_dews.value(prevInfo.LYSETTL_YM);
        if (prevMonth_dews) prevMonth_dews.value(prevInfo.LMSETTL_YM);

        if(flag == "groupInAcpe"){
          if(grCorp_dews){
            if($(grCorp).hasClass('dews-ui-multicodepicker')){
              module.setMultiConsgrpInAcpe(grCorp_dews, prevInfo.SETTL_YM, auth_yn);
            }
            else{
              module.setConsgrpInAcpe(grCorp_dews, prevInfo.SETTL_YM, grcrnc_dews, auth_yn);
            }
          }
        }
        else if(flag == "corpInGroup"){
          if(corp_dews){
            if($(corp).hasClass('dews-ui-multicodepicker')){
              module.setMultiCorpInConsgrp(corp_dews, prevInfo.SETTL_YM, groupCode, psrelcode, auth_yn, time);
            }
            else{
              module.setCorpInConsgrp(corp_dews, prevInfo.SETTL_YM, groupCode, psrelcode, crnc_dews, auth_yn, time);
            }
          }
        }
        else if(flag == "corpInAcpe"){
          if (corp_dews) {
            if($(corp).hasClass('dews-ui-multicodepicker')){
              module.setMultiCorpInAcpe(corp_dews, prevInfo.SETTL_YM, auth_yn, time);
            } else {
              module.setCorpInAcpe(corp_dews, prevInfo.SETTL_YM, crnc_dews, auth_yn, time);
            }
          }
        }
      } //if
      else {
        //전기 정보가 없는 경우 입력을 차단한다.

        if (prevYear_dews) prevYear_dews.value('');
        if (prevMonth_dews) prevMonth_dews.value('');

        if(grCorp_dews){
          if ($(grCorp).hasClass('dews-ui-multicodepicker')){
            grCorp_dews.clear();
          } else {
            grCorp_dews.setData({ CORP_CD: '', CORP_NM: '' });
          }
        }

        if (corp_dews) {
          if ($(corp).hasClass('dews-ui-multicodepicker')){
            corp_dews.clear();
          } else {
            corp_dews.setData({ CORP_CD: '', CORP_NM: '' });
          }
        }

        if(crnc_dews){
          crnc_dews.text('');
        }

      } //else
    }
  }

  function _getAcpeCode(dewself) {
    var acpe = dews.ui.codepicker(dewself.$content.find('.ca-acpe'));
    if (dewself.$content.find('.ca-acpe').length) return acpe.code();
    else return '';
  }

  function _getAcpeText(dewself) {
    var acpe = dews.ui.codepicker(dewself.$content.find('.ca-acpe'));
    if (dewself.$content.find('.ca-acpe').length) return acpe.text();
    else return '';
  }

  function _getGrcorpCode(dewself) {
    var grcorp = dews.ui.codepicker(dewself.$content.find('.ca-grcorp'));
    if (dewself.$content.find('.ca-grcorp').length) return grcorp.code();
    else return '';
  }

  function _getCorpCode(dewself) {
    var corp = dews.ui.codepicker(dewself.$content.find('.ca-corp'));
    if (dewself.$content.find('.ca-corp').length) {
      if (dewself.$content.find('select.dews-ui-multicodepicker.ca-corp').length) {
        return corp.codes().join('|');
      }
      else {
        return corp.code();
      }
    }
    else return '';
  }

  //END: pageUtil --------------------------------

  //MARK: commonService  --------------------------------

	//*************************************************************************************************
	//* GAAP_CD 조회
	//*************************************************************************************************

  // module.getGaap = function () {
  //   var result = "1";
  //   dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getGaap')), {
  //     async: false,
  //   }).done(function (data) {
  //     if (data) {
  //       result = data;
  //     }
  //   }).fail(function (xhr, status, error) {
  //     dews.ui.snackbar.error(error);
  //   });
  //   return result;
  // };

	/**
	 * Gaap Code 조회
	 * @param corp_cd
	 * @return
	 * @throws Exception
	 */
  module.getGaapCode = function (corp_cd) {
    var result = "1";
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getGaapCode')), {
      async: false,
      data: {
        corp_cd: corp_cd || ""
      }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	/**
	 * 로그인한 회사코드와 매팽된 연결법인 조회
	 * @return
	 * @throws Exception
	 */
  module.getCompanyCorp = function () {
    var CorpCode = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCompanyCorp')), {
      async: false,
    }).done(function (data) {
      if (data) {
        CorpCode = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return CorpCode;
  };

  /**
	 * 법인의 통화코드 조회 API
	 * @return
	 * @throws Exception
	 */
  module.getCorpCurrencyCode = function (corp_cd) {
    var crnc_cd = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCorpCurrencyCode')), {
      async: false,
      data: {
        corp_cd: corp_cd
      }
    }).done(function (data) {
      if (data) {
        crnc_cd = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return crnc_cd;
  };

  /**
	 * 금액 format 적용 API
	 * @return
	 * @throws Exception
	 */
  module.getCurrencyFormatAmt = function (consgrp_cd, corp_cd, format_amt, exch_rt) {
    var result = 0;

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCurrencyFormatAmt')), {
      async: false,
      data: {
        consgrp_cd: consgrp_cd ? consgrp_cd : "*",
        corp_cd: corp_cd,
        format_amt: format_amt,
        exch_rt: exch_rt ? exch_rt : 0
      }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

    return result;
  };

	//*************************************************************************************************
	//* 연결결산권한
  //*************************************************************************************************

	/**
	 * 로그인한 사용자의 권한레벨 조회
	 * @param settl_ym (생략 가능)
	 * @param corp_cd
	 * @return 1:연결결산담당자, 2:법인승인자, 3:법인담당자, 4:검토자
	 * @throws Exception
	 */
  module.getAuthLevel = function (settl_ym, corp_cd) {
    var result = '';
    if (corp_cd) {
      dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getAuthLevel')), {
        async: false,
        data: {settl_ym: settl_ym, corp_cd: corp_cd}
      }).done(function (data) {
        if (data) {
          result = data;
        }
      }).fail(function (xhr, status, error) {

      });
    }
    return result;
  };


	//*************************************************************************************************
	//* 결산연월 관리
	//*************************************************************************************************

	/**
	 * 가장 최근 결산연월 조회
	 * @return
	 * @throws Exception
	 */
  module.getLastAcpe = function () {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getLastAcpe')), {
      async: false,
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	/**
	 * 회계기간을 기준으로 결산기 말월 조회
	 * @param settl_ym
	 * @return
	 * @throws Exception
	 */
  module.getPrevConfig = function (settl_ym) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getPrevConfig')), {
      async: false,
      data: { settl_ym: settl_ym }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	/**
	 * 회계기간을 기준으로 전기말 결산연월 조회
	 * @param settl_ym
	 * @return
	 * @throws Exception
	 */
  module.getPrevYear = function (settl_ym) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getPrevYear')), {
      async: false,
      data: { settl_ym: settl_ym }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	/**
	 * 이월정보 (CA_PREV_INFO) + 전년동 조회
	 * @param settl_ym
	 * @return
	 * @throws Exception
	 */
  module.getPrevInfo = function (settl_ym) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getPrevInfo')), {
      async: false,
      data: { settl_ym: settl_ym }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	//*************************************************************************************************
	//* 연결그룹조직구조
	//*************************************************************************************************

  /**
   * 배열을 원하는 카운트데로 자르는 함수
   * @param  maxLength (자르고자하는 갯수)
   * @param  result (List)
   * @return
   */
  module.getListSlice = function (maxLength, list) {
    var result = [];
    if (list.length >= maxLength) {
      for (var i = 0; i < list.length; i += maxLength) {
        var listData;
        listData = list.slice(i, i + maxLength);
        result.push(listData);
      }
    } else {
      result.push(list);
    }

    return result;
  },
    /**
     *
     * @param {*} SCHDUL_ST (작성상태)
     * @param {*} POSITION (정렬)
     * @returns
     */
    module.getSchduleIcon = function (schdul_st, position) {
      var styles = {};
      if (schdul_st == "1") {
        styles.icon = {
          image: "/view/images/CA/pending.png",
          position: this.isEmpty(position) ? "left" : position,
        };
        // styles.color = "#faa733";
      } else if (schdul_st == "2") {
        styles.icon = {
          image: "/view/images/CA/write.png",
          position: this.isEmpty(position) ? "left" : position,
        };
        // styles.color = "#3071e8";
      } else if (schdul_st == "3") {
        styles.icon = {
          image: "/view/images/CA/comp.png",
          position: this.isEmpty(position) ? "left" : position,
        };
        // styles.color = "#1249a1";
      } else if (schdul_st == "4") {
        styles.icon = {
          image: "/view/images/CA/confirm.png",
          position: this.isEmpty(position) ? "left" : position,
        };
        // styles.color = "#3fa684";
      } else if (schdul_st == "5") {
        styles.icon = {
          image: "/view/images/CA/transfer.png",
          position: this.isEmpty(position) ? "left" : position,
        };
        // styles.color = "#318164";
      } else if (schdul_st === null) {
        //일정없음
        styles.icon = {
          image: "/view/images/CA/noschedule.png",
          position: this.isEmpty(position) ? "left" : position,
        };
      } else if (schdul_st === '전송') {
        //전송
        styles.icon = {
          image: "/view/images/CA/confirm.png",
          position: this.isEmpty(position) ? "left" : position,
        };
      }
      return styles;
    };
  /**
   * null Check
   * @returns
   */
  module.isEmpty = function (data) {
    if (
      data === "" ||
      data === undefined ||
      data === null ||
      data.length === 0
    ) {
      return true;
    } else {
      return false;
    }
  };

	/**
	 * 결산연월에 존재하는 연결법인, 연결그룹 조회
	 * @param settl_ym
	 * @param auth_yn
	 * @return
	 * @throws Exception
	 */
  module.getCorpInAcpe = function (settl_ym, auth_yn) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCorpInAcpe')), {
      async: false,
      data: { settl_ym: settl_ym, auth_yn: auth_yn}
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	/**
	 * 결산연월에 존재하는 연결법인만 필터링
	 * @param settl_ym
	 * @param corp_cd_pipe
	 * @param auth_yn
	 * @return
	 * @throws Exception
	 */
  module.getCorpInAcpeCorpList = function (settl_ym, corp_cd_pipe, auth_yn) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCorpInAcpeCorpList')), {
      async: false,
      data: { settl_ym: settl_ym, corp_cd_pipe: corp_cd_pipe, auth_yn: auth_yn }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	/**
	 * 결산연월에 존재하는 연결법인만 필터링하여 스트링으로 조회
	 * @param settl_ym
	 * @param corp_cd_pipe
	 * @param auth_yn
	 * @return
	 * @throws Exception
	 */
  module.getCorpStringInAcpeCorpList = function (settl_ym, corp_cd_pipe, auth_yn) {
    var result = '';
    if (CorpCode) {
      dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCorpStringInAcpeCorpList')), {
        async: false,
        data: { settl_ym: settl_ym, corp_cd_pipe: corp_cd_pipe, auth_yn: auth_yn }
      }).done(function (data) {
        if (data) {
          result = data;
        }
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.error(error);
      });
    }
    return result;
  };

	/**
	 * 결산연월에 존재하는 연결그룹만 필터링
	 * @param settl_ym
	 * @param corp_cd_pipe
	 * @param auth_yn
	 * @return
	 * @throws Exception
   * @modify : 2019.12.09 방민섭 : 결산연월에 존재하는 연결그룹만 조회(필터) API 생성
	 */
  module.getConsgrpInAcpeConsgrpList = function (settl_ym, corp_cd_pipe, auth_yn) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getConsgrpInAcpeConsgrpList')), {
      async: false,
      data: { settl_ym: settl_ym, corp_cd_pipe: corp_cd_pipe, auth_yn: auth_yn }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	/**
	 * 결산년월&연결그룹 에 존재하는 연결법인 조회
	 * @param settl_ym
	 * @param consgrp_cd
	 * @param psrel_cd
	 * @param auth_yn
	 * @return
	 * @throws Exception
   * @modify : 2019.12.09 방민섭 : 결산년월 & 연결그룹에 있는 연결법인 조회(필터) API 생성
	 */
  module.getCorpInConsgrp = function (settl_ym, consgrp_cd, psrel_cd, auth_yn) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCorpInConsgrp')), {
      async: false,
      data: { settl_ym: settl_ym, consgrp_cd: consgrp_cd, psrel_cd: psrel_cd, auth_yn: auth_yn }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

  /**
	 * 결산년월&연결그룹 에 존재하는 연결법인 조회
	 * @param settl_ym
	 * @param consgrp_cd
   * @param corp_cd_pipe
	 * @param psrel_cd
	 * @param auth_yn
	 * @return
	 * @throws Exception
   * @modify : 2019.12.09 방민섭 : 결산년월 & 연결그룹에 있는 연결법인 조회(필터) API 생성
	 */
  module.getCorpInConsgrpCorpList = function (settl_ym, consgrp_cd, corp_cd_pipe, psrel_cd, auth_yn) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCorpInConsgrpCorpList')), {
      async: false,
      data: { settl_ym: settl_ym, consgrp_cd: consgrp_cd, corp_cd_pipe: corp_cd_pipe, psrel_cd: psrel_cd, auth_yn: auth_yn }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

	/**
	 * 결산연월에 존재하는 연결그룹 조회
	 * @param settl_ym
	 * @param auth_yn
	 * @return
	 * @throws Exception
	 */
  module.getConsgrpInAcpe = function (settl_ym, auth_yn) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getConsgrpInAcpe')), {
      async: false,
      data: { settl_ym: settl_ym, auth_yn: auth_yn }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };


	//*************************************************************************************************
	//* 결산일정/작성상태
	//*************************************************************************************************

  module.getCorpSchedule = function (CorpCode, FileCode, YmDate) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCorpSchedule')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

  //조회 결산년월에 등록되어 있는 법인 List<Schedulemodel>
  module.getCorpsInSchedule = function (CorpCode, FileCode, YmDate) {
    var result = '';
    if (CorpCode) {
      dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCorpsInSchedule')), {
        async: false,
        data: { CorpCodePipe: CorpCode, FileCode: FileCode, YmDate: YmDate }
      }).done(function (data) {
        if (data) {
          result = data;
        }
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.error(error);
      });
    }
    return result;
  };

  //조회 결산년월 일정 조회 멀티 List<Schedulemodel>
  module.getMultiCorpSchedule = function (CorpCode, FileCode, YmDate) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getMultiCorpSchedule')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

  //조회 결산년월 일정 멀티 List<Schedulemodel>
  module.getMultiCorpScheduleFilterSate = function (CorpCode, FileCode, YmDate, State) {
    var result = '';
    if (CorpCode) {
      dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getMultiCorpScheduleFilterSate')), {
        async: false,
        data: { CorpCodePipe: CorpCode, FileCode: FileCode, YmDate: YmDate, State: State }
      }).done(function (data) {
        if (data) {
          result = data;
        }
      }).fail(function (xhr, status, error) {
        dews.ui.snackbar.error(error);
      });
    }
    return result;
  };

    //조회 결산년월에 등록되어 있는 법인 도움창 전용 String
    module.getHelpCorpsInSchedule = function (CorpCode, FileCode, YmDate) {
      var result = '';
      if (CorpCode) {
        dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getHelpCorpsInSchedule')), {
          async: false,
          data: { CorpCodePipe: CorpCode, FileCode: FileCode, YmDate: YmDate }
        }).done(function (data) {
          if (data) {
            result = data;
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
      }
      return result;
    };

	//*************************************************************************************************
	//* 검증 메시지
	//*************************************************************************************************


  //업데이트 작성대기
  module.setStateReset = function (CorpCode, FileCode, YmDate, GrCorp) {
    var acpe = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setStateReset')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };
  //업데이트 작성중
  module.setStateEditing = function (CorpCode, FileCode, YmDate, GrCorp) {
    var result = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setStateEditing')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };
  //업데이트 Multi 작성중
  module.setMultiStateEditing = function (dataSource, FileCode, YmDate, GrCorp, vrfc_fg) {
    var result = '';
    var CorpCode = '';
    GrCorp = GrCorp || '';
    $.each(dataSource.getDirtyData().Added, function (index, data) {
      if (CorpCode.indexOf(data.CORP_CD) == -1)
        CorpCode += data.CORP_CD + '|';
    });
    $.each(dataSource.getDirtyData().Deleted, function (index, data) {
      if (CorpCode.indexOf(data.CORP_CD) == -1)
        CorpCode += data.CORP_CD + '|';
    });
    $.each(dataSource.getDirtyData().Updated, function (index, data) {
      if (CorpCode.indexOf(data.CORP_CD) == -1)
        CorpCode += data.CORP_CD + '|';
    });

    module.setMultiVerifyReset(CorpCode, FileCode, YmDate, GrCorp, vrfc_fg || "1");

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setMultiStateEditing')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
      if (data) {
        // $.each(data, function(i,d){
        //   if(d.ResultCode != 'SUCCESS')
        //     result = data;
        // });
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

  //업데이트 Multi 작성중 작성상태가 변경된 법인 CorpCode
  module.setMultiCorpStateEditing = function (CorpCode, FileCode, YmDate, GrCorp, vrfc_fg) {
    var result = '';
    GrCorp = GrCorp || '';

    module.setMultiVerifyReset(CorpCode, FileCode, YmDate, GrCorp, vrfc_fg || "1");

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setMultiStateEditing')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
      if (data) {
        // $.each(data, function(i,d){
        //   if(d.ResultCode != 'SUCCESS')
        //     result = data;
        // });
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };
  //조회 검증 List<VerifyModel>
  module.getVerifyMessage = function (CorpCode, FileCode, YmDate, GrCorp, vrfc_fg) {
    var acpe = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getVerifyMessage')), {
      async: false,
      data: { vrfc_fg: vrfc_fg || "1", CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };
  //   //조회 검증 List<VerifyModel> (자료코드가 멀티인 경우)
  // module.getVerifyMessage = function (CorpCode, FileCode, YmDate, GrCorp, vrfc_fg) {
  //   var acpe = '';
  //   dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getVerifyMessage_multi')), {
  //     async: false,
  //     data: { vrfc_fg: vrfc_fg || "1", CorpCode: CorpCode, FileCode_pipe: FileCode, YmDate: YmDate, GrCorp: GrCorp }
  //   }).done(function (data) {
  //     if (data) {
  //       result = data;
  //     }
  //   }).fail(function (xhr, status, error) {
  //     dews.ui.snackbar.error(error);
  //   });
  //   return result;
  // };
  //업데이트 작성완료
  module.setStateComplete = function (CorpCode, FileCode, YmDate, GrCorp) {
    var acpe = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setStateComplete')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };
  //업데이트 승인
  module.setStateApprove = function (CorpCode, FileCode, YmDate, GrCorp) {
    var acpe = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setStateApprove')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };
  //업데이트 이관
  module.setStateTransfer = function (CorpCode, FileCode, YmDate, GrCorp) {
    var acpe = '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setStateTransfer')), {
      async: false,
      data: { CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
    return result;
  };

  //이관 재검증
  module.getTransInfo = function (settl_ym, consgrp_cd, corp_cd, data_cd, isApply) {
    var result = '';

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getTransInfo')), {
      async: false,
      data: { settl_ym: settl_ym, consgrp_cd: consgrp_cd, corp_cd: corp_cd, data_cd: data_cd, isApply: isApply }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

    return result;
  };

  //업데이트 스케줄 검증
  module.insertScheduleVerifyCode = function (CorpCode, FileCode, YmDate, vrfc_fg) {
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('insertScheduleVerifyCode')), {
      async: false,
      data: { vrfc_fg: vrfc_fg || "1", CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate }
    }).done(function (data) {
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
  };
  //업데이트 초기화 검증
  module.setMultiVerifyReset = function (CorpCode, FileCode, YmDate, GrCorp, vrfc_fg) {
    GrCorp = GrCorp || '';
    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setMultiVerifyReset')), {
      async: false,
      data: { vrfc_fg: vrfc_fg || "", CorpCode: CorpCode, FileCode: FileCode, YmDate: YmDate, GrCorp: GrCorp }
    }).done(function (data) {
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
  };

  /**
    * 계정속성에 따른 환율 조회
    * @example var exchagerate = CA.getAcctExchangeRate('201809', '100000', '20000', '412410', null)
    * @param {*} settl_ym 결산년월
    * @param {*} consgrp_cd 연결그룹코드
    * @param {*} corp_cd 법인코드
    * @param {*} acct_cd 연결계정코드
    * @param {*} acct_dt 계정금액발생일자 (있으면 yyyyMMdd, 없으면 null or "") : 자금 관련이 아니면 대부분 null
    * @return {*} 성공하면 환율을 리턴
    * @return {*} 실패하면 0을 리턴
    * 로직설명 :
	  *     (1). 연결그룹통화, 법인통화를 가져온다. (비교해서 같으면 1리턴, 다르면 (2)진행)
	  *     (2). 연결계정의 구분값을 가져온다. (현행환율, 역사적환율 구분)
	  *     (3). 계정환율 구분값에 따라 환율을 가져온다. (환산환율 : 1.기말(base), 2.누적평균(sale), 3.월평균(buy))
    */
  module.getAcctExchangeRate = function (settl_ym, consgrp_cd, corp_cd, acct_cd, acct_dt) {

    var result = 0;

    dews.api.get(dews.url.getApiUrl('CA', 'ExchangeRateService', 'getAcctExchangeRate'), {
      async: false,
      data: {
        settl_ym: settl_ym,
        consgrp_cd: consgrp_cd,
        corp_cd: corp_cd,
        acct_cd: acct_cd,
        acct_dt: acct_dt
      }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    });

    return result;
  };

  /**
    * 환율유형별 환율 조회
    * @example var exchagerate = CA.getAcctExchangeRate('201809', '100000', '20000', '1')
    * @param {*} settl_ym 결산년월
    * @param {*} consgrp_cd 연결그룹코드
    * @param {*} corp_cd 법인코드
    * @param {*} exrt_tp : 환율유형 (1:기말환율, 2:누계평균환율, 3:월평균환율)
    * @return {*} 성공하면 환율을 리턴
    * @return {*} 실패하면 0을 리턴
    * 로직설명 :
	  *     (1). 연결그룹통화, 법인통화를 가져온다. (비교해서 같으면 1리턴, 다르면 (2)진행)
	  *     (2). 계정환율 구분값에 따라 환율을 가져온다. (환산환율 : 1.기말(base), 2.누적평균(sale), 3.월평균(buy))
    */
  module.getExchangeRate = function (settl_ym, consgrp_cd, corp_cd, exrt_tp) {

    var result = 0;

    dews.api.get(dews.url.getApiUrl('CA', 'ExchangeRateService', 'getExchangeRate'), {
      async: false,
      data: {
        settl_ym: settl_ym,
        consgrp_cd: consgrp_cd,
        corp_cd: corp_cd,
        exrt_tp: exrt_tp
      }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    });

    return result;
  };

  module.getDocuState = function(settl_ym, consgrp_cd, corp_cd, tcorp_cd, module_no) {

    var result = 0;

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', 'getDocuState'), {
      async : false,
      data: {
        settl_ym: settl_ym,
        consgrp_cd: consgrp_cd,
        corp_cd: corp_cd,
        tcorp_cd: tcorp_cd,
        module_no: module_no
      }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    });

    return result;
  };

  module.getAcctFullNameUsable = function() {

    var result = "N";

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', 'getAcctFullNameUsable'), {
      async : false
    })
    .done(function (data) {
      if(data){
        result = data;
      }
    });

    return result;
  };

  module.getAcgrpFg = function() {

    var result = [];

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', 'getAcgrpFg'), {
      async : false
    })
    .done(function (data) {
      if(data){
        result = data;
      }
    });

    return result;
  };


  /**
	 * 연결모듈 결산마감 상태 조회
	 * @param settl_ym
	 * @param consgrp_cd
	 * @return 마감유형코드
	 * @throws Exception
	 */
  module.getCloseState = function (settl_ym, consgrp_cd) {
    var result = '';

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCloseState')), {
      async: false,
      data: { settl_ym: settl_ym, consgrp_cd: consgrp_cd }
    }).done(function (data) {
      if (data) {
        result = data;
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

    return result;
  }


  /**
	 * 연결모듈 결산마감 상태 설정
	 * @param settl_ym
	 * @param consgrp_cd
	 * @param state
	 * @return 상태값
	 * @throws Exception
	 */
  module.setCloseState = function (settl_ym, consgrp_cd, state) {

    dews.api.post(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('setCloseState')), {
      async: false,
      data: { settl_ym: settl_ym, consgrp_cd: consgrp_cd, state: state }
    }).done(function (data) {
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

  }

  /**
	 * 연결모듈 결산마감 상태 설정
	 * @param settl_ym
	 * @param consgrp_cd
	 * @param corp_cd
   * @param data_cd
	 * @return 상태값(배열)
	 * @throws Exception
	 */
  module.getDocuStateAll = function (settl_ym, consgrp_cd, corp_cd, data_cd) {

    var authState;
    var closingState;
    var docuState;
    var returnVal = {};

    authState = module.getAuthLevel(settl_ym, consgrp_cd);
    closingState = module.getCloseState(settl_ym, consgrp_cd);

    if(data_cd){
      if(data_cd == '11'){
        docuState = module.getDocuState(settl_ym, consgrp_cd, corp_cd, corp_cd, data_cd);
      }
      else {
        docuState = module.getDocuState(settl_ym, consgrp_cd, corp_cd, "*", data_cd);
      }
    }

    returnVal = {
      AUTH: authState,
      CLOSING: closingState,
      DOCU: docuState
    };

    return returnVal;
  }

  /**
	 * 연결모듈 결산마감 상태 설정
	 * @return String (DB스키마)
	 * @throws Exception
	 */
  module.getCurrentSchema = function () {

    var returnVal = "";

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCurrentSchema')), {
      async: false
    })
    .done(function (data) {
      returnVal = data;
    })
    .fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

    return returnVal;
  }

  /**
	 * 연결모듈 통합환경 설정
   * @param module_cd
   * @param ctrl_cd
	 * @return String (DB스키마)
	 * @throws Exception
	 */
  module.getCtrlConfig = function (module_cd, ctrl_cd) {

    var returnVal = "";

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getCtrlConfig')), {
      async: false,
      data: {
        module_cd: module_cd,
        ctrl_cd: ctrl_cd
      }
    })
    .done(function (data) {
      returnVal = data;
    })
    .fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

    return returnVal;
  }

  module.verifyResetAll = function(settl_ym, consgrp_cd, corp_cd_pipe, data_cd, vrfc_fg){
    dews.api.post(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('verifyResetAll')), {
      async: false,
      data: { settl_ym: settl_ym, consgrp_cd: consgrp_cd, corp_cd_pipe: corp_cd_pipe, data_cd: data_cd, vrfc_fg: vrfc_fg }
    })
    .done(function (data) {

    })
    .fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
  }

  module.updateVerifyResult = function(settl_ym, corp_cd_pipe, data_cd){
    dews.api.post(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('updateVerifyResult')), {
      async: false,
      data: { settl_ym: settl_ym, corp_cd_pipe: corp_cd_pipe, data_cd: data_cd }
    })
    .done(function (data) {

    })
    .fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });
  }

  module.getDocuType = function(docu_cd_pipe){
    var result;

    dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', dews.string.format('getDocuType')), {
      async: false,
      data: { docu_cd_pipe: docu_cd_pipe != null ? docu_cd_pipe : ""}
    })
    .done(function (data) {
      result = data;
    })
    .fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

    return result;
  }

  function setPageControls(dewself, flag, settl_ym, consgrp_cd, auth_yn, time){

    var $grcorp = (dewself.$content.find('input.ca-gr-corp').length) ? dewself.$content.find('input.ca-gr-corp') : dewself.$content.find('select.ca-gr-corp');
    var $grcrnc = dewself.$content.find('input.ca-gr-crnc');
    var $corp = (dewself.$content.find('input.ca-corp').length) ? dewself.$content.find('input.ca-corp') : dewself.$content.find('select.ca-corp');
    var $crnc = dewself.$content.find('input.ca-crnc');
    var $prevYear = dewself.$content.find('input.ca-prevYear');
    var $prevMonth = dewself.$content.find('input.ca-prevMonth');

    var dewsGrcorp = ($grcorp.length) ? dewself[$grcorp[0].id] : '';
    var dewsGrcrnc = ($grcrnc.length) ? dewself[$grcrnc[0].id] : '';
    var dewsCorp = ($corp.length) ? dewself[$corp[0].id] : '';
    var dewsCrnc = ($crnc.length) ? dewself[$crnc[0].id] : '';
    var dewsPrevYear = ($prevYear.length) ? dewself[$prevYear[0].id] : '';
    var dewsPrevMonth = ($prevMonth.length) ? dewself[$prevMonth[0].id] : '';
    var prevInfo;

    var psrelcode = "1|2|3|4|5";
    if(dewself.$content.find('.ca-corp.ca-corp-sub').length){
      psrelcode = "2|3|4|5";
    }

    if(settl_ym){
      prevInfo = module.getPrevInfo(settl_ym);

      var $ctrl = "";
      var ctrl = "";
      var crncCtrl = "";

      if(flag == "corpInAcpe"){
        $ctrl = $corp;
        ctrl = dewsCorp;
        crncCtrl = dewsCrnc;
      }
      else if(flag == "consgrpInAcpe"){
        $ctrl = $grcorp;
        ctrl = dewsGrcorp;
        crncCtrl = dewsGrcrnc;
      }
      else if(flag == "corpInConsgrp"){
        $ctrl = $corp;
        ctrl = dewsCorp;
        crncCtrl = dewsCrnc;
      }

      // 2022.03.25 허기정 : 누락된 psrelcode 적용
      setControlsValue(flag, $ctrl, ctrl, crncCtrl, settl_ym, consgrp_cd, auth_yn, psrelcode, time);
    }

    if(dewsPrevYear){
      dewsPrevYear.value(prevInfo ? prevInfo.LYSETTL_YM : "");
    }

    if(dewsPrevMonth){
      dewsPrevMonth.value(prevInfo ? prevInfo.LMSETTL_YM : "");
    }
  }

  // 컨트롤 데이터 셋팅 함수
  // 2022.02.15 방민섭 :ㅣ신규추가
  function setControlsValue(flag, $ctrl, ctrl, crncCtrl, settl_ym, consgrp_cd, auth_yn, psrel_cd, time){
    if(ctrl){
      var multiChk = $ctrl.hasClass("dews-ui-multicodepicker");
      var corps = multiChk ? ctrl.codes().join("|") : ctrl.code();
      var corpData, setData;

      if(corps != ""){
        if(flag == "corpInAcpe"){
          corpData = module.getCorpInAcpeCorpList(settl_ym, corps, auth_yn);
        }
        else if(flag == "consgrpInAcpe"){
          corpData = module.getConsgrpInAcpeConsgrpList(settl_ym, corps, auth_yn);
        }
        else if(flag == "corpInConsgrp"){
          corpData = module.getCorpInConsgrpCorpList(settl_ym, consgrp_cd, corps, psrel_cd, auth_yn);
        }
      }
      else {
        if(time == "first"){
          if(flag == "corpInAcpe"){
            corpData = module.getCorpInAcpe(settl_ym, auth_yn);
          }
          else if(flag == "consgrpInAcpe"){
            corpData = module.getConsgrpInAcpe(settl_ym, auth_yn);
          }
          else if(flag == "corpInConsgrp"){
            corpData = module.getCorpInConsgrp(settl_ym, consgrp_cd, psrel_cd, auth_yn);
          }
        }
      }

      var code = "", name = "", crnc = "";
      if(corpData && corpData.length > 0){
        code = (flag == "consgrpInAcpe") ? corpData[0].CONSGRP_CD : corpData[0].CORP_CD;
        name = (flag == "consgrpInAcpe") ? corpData[0].CONSGRP_NM : corpData[0].CORP_NM;
        crnc = corpData[0].CRNC_CD;

        // 2022.03.24 허기정 : 연결그룹은 제외
        if(time == "first" && flag != "consgrpInAcpe"){
          if(corpData.length == 1){
            setData = { CORP_CD: code, CORP_NM: name, CRNC_CD: crnc }
            if(multiChk){
              setData = [setData];
            }
          }
          else {
            setData = {}
            crnc = "";
          }
        }
        else {
          setData = multiChk ? corpData : { CORP_CD: code, CORP_NM: name, CRNC_CD: crnc };
        }
      }
      else {
        setData = multiChk ? [] : { CORP_CD: code, CORP_NM: name, CRNC_CD: crnc };
      }

      if(multiChk){
        ctrl.clear();
      }

      ctrl.setData(setData, true);
      if(crncCtrl){
        crncCtrl.text(crnc);
      }
    }
  }

  // 그리드 clear 함수
  // 2022.02.15 방민섭 : 신규생성
  function clearMainGrid(dewself){
    var $grid = dewself.$content.find('.ca-main-grid');

    for(var i = 0; i < $grid.length; i++){
      var dewsGrid = dewself[$grid[i].id];
      if(dewsGrid){
        dewsGrid.clearRows();
      }
    }
  }

  module.corpScheduleCheck = function(dataRow, authConfig, flag){
    var result = false;

    if(flag == "complete"){
      if((dataRow.SCHDUL_ST == "1" || dataRow.SCHDUL_ST == "2") && dataRow.CLOSE_YN != 'Y' && dataRow.AUTH_TP <= '3' && !(authConfig == "N" && dataRow.AUTH_TP == '2')){
        result = true;
      }
    }
    else if(flag == "completeCancel"){
      if(dataRow.SCHDUL_ST == "3" && dataRow.CLOSE_YN != 'Y' && dataRow.AUTH_TP <= '3' && !(authConfig == "N" && dataRow.AUTH_TP == '2')){
        result = true;
      }
    }
    else if(flag == "approve"){
      if(dataRow.SCHDUL_ST == "3" && dataRow.CLOSE_YN != 'Y' && dataRow.AUTH_TP <= '2'){
        result = true;
      }
    }
    else if(flag == "approveCancel"){
      if(dataRow.SCHDUL_ST == "4" && dataRow.CLOSE_YN != 'Y' && dataRow.AUTH_TP <= '2'){
        result = true;
      }
    }
    // 내부거래 전용
    else if(flag == "sendCancel"){
      if((dataRow.SCHDUL_ST == "3" || dataRow.SCHDUL_ST == "5") && dataRow.CLOSE_YN != 'Y' && dataRow.AUTH_TP <= '3' && !(authConfig == "N" && dataRow.AUTH_TP == '2')){
        result = true;
      }
    }
    else if(flag == "send"){
      if(dataRow.SCHDUL_ST == "3" && dataRow.CLOSE_YN != 'Y' && dataRow.AUTH_TP <= '3'){
        result = true;
      }
    }

    return result;
  }

  module.scheduleEventMsg = function(checkRow, authConfig, flag){
    var result = dews.localize.get('진행가능한 법인이 없습니다.', 'M0002622', dews.localize.language(), 'COPTBS00100');

    if(checkRow.length == 1){
      var data = checkRow[0];

      if(data.CLOSE_YN == 'Y'){
        result = dews.localize.get('마감일을 확인해주십시오.', 'M0010486', dews.localize.language(), 'COPTBS00100');
      }
      else {
        if(flag == "complete" || flag == "completeCancel"){
          if((flag == "complete" && (data.SCHDUL_ST == "1" || data.SCHDUL_ST == "2") && (data.AUTH_TP > '3' || (authConfig == "N" && data.AUTH_TP == '2')))
            || (flag == "completeCancel" && data.SCHDUL_ST == "3" && (data.AUTH_TP > '3' || (authConfig == "N" && data.AUTH_TP == '2')))){
            result = dews.localize.get('작성완료/취소권한이 없습니다.', 'M0003523', dews.localize.language(), 'COPTBS00100');
          }
        }
        else if(flag == "approve" || flag == "approveCancel"){
          if((flag == "approve" && data.SCHDUL_ST == "3" && data.AUTH_TP > '2')
            || (flag == "approveCancel" && data.SCHDUL_ST == "4" && data.AUTH_TP > '2')){
            result = dews.localize.get('승인권한이 없습니다.', 'M0003446', dews.localize.language(), 'COPTBS00100');
          }
        }
      }
    }

    return result;
  }

  //END: commonService  --------------------------------

  /**
   * 멀티파일 다운로드
   * @example gerp.CA.MULTIFILE.download(self, file_dc, zip_nm)
   * @param self 현재 페이지의 정보가 담긴 객체
   * @param file_dc 다운로드 받을 파일키
   * @param zip_nm 압축할 파일명
   */
  module.MULTIFILE = {
    download: function (self, file_dc, zip_nm) {
      // 기존의 iframe 태그 있을시 제거
      self.$content.find('> iframe').remove();
      // 다운받을 파일 목록과 인증 토큰값을 동시에 받아오는 로직
      $.when(
        dews.api.get(dews.url.getApiUrl('CA', 'CaCommonService', 'getDownloadFile'),{
          data: {
            FILE_DC: file_dc
          }
        }),
        dews.api.get('/auth/temporary/token')
      ).done(function (multifile, token) {
        // multifile 받아올 파일에 대한 ajax 통신에 대한 결과
        // token 받아올 토큰 값에 대한 ajax 통신에 대한 결과
        var data = multifile[0];
        var $iframe = $('<iframe style="display: none; width: 0; height: 0;"></iframe>');
        self.$content.append($iframe);
        // 파일을 받을 경로 설정
        var url = '/download/files?keys=';
        $.each(data, function (idx, file) {
            if (idx !== 0) {
              url += ',';
            }
            url += encodeURIComponent(file.NEW_FILE_DC)
        });
        url += '&zipname=' + zip_nm + '&token=' + encodeURIComponent(token[0]);
        // 완성된 url을 통해 파일 다운로드 실행
        $iframe.prop('src', url);
      }).fail(function () {
        console.log(arguments);
      });
    }
  };

  module.VERIFY = {
    validation: function(params){
      var result = {
        required: [],
        duplePK: [],
        dupleUnique: []
      };

      // 필수 컨트롤 변수
      var type = params.type;   // grid, card, tree 별로 검증 로직 수정
      var mstCtrl = params.mstCtrl; // type에 따라 컨드롤이 다름

      // dtl 사용 변수
      var dtlCtrl = params.dtlCtrl;
      var dtlUse = params.dtlUse;

      // 패널 변수
      var panelUse = params.panelUse;
      var penelCtrl = params.panelCtrl;
      var penelItems = [];

      // 트리 사용 필요 변수
      var $tree = params.$tree;
      var exceptLevel = params.exceptLevel;

      // pk, unique 배열
      var pkArr = params.pkArr;
      var uniqueArr = params.uniqueArr;
      var dtlPkArr = params.dtlPkArr;
      var dtlUniqueArr = params.dtlUniqueArr;

      // 메시지 사용여부
      var msgUse = params.msgUse;

      var pkPipe = "|";
      var uqPipe = "|";
      var dtlPkPipe = "|";
      var dtlUqPipe = "|";

      if(dtlUse){
        result["dtlRequired"] = [];
        result["dtlDuplePK"] = [];
        result["dtlDupleUnique"] = [];
      }

      // control 필수항목 가져오기
      if(panelUse && penelCtrl != null){
        $.each(penelCtrl.items, function(idx, ctrl){
          var reqInfo = {};
          var $ctrl = $(ctrl.container);

          if($ctrl != null && $ctrl.find(".required").length > 0){

            reqInfo.CONTROL = $ctrl.find(".required")[0];
            reqInfo.LABEL_TXT = ctrl.label.textContent;

            if($ctrl.find('[data-dews-bind-column]').length > 0){
              reqInfo.BIND_COL = $ctrl.find('[data-dews-bind-column]')[0].dataset.dewsBindColumn;
            }
            else if($ctrl.find('[data-dews-bind-value]').length > 0){
              reqInfo.BIND_COL = $ctrl.find('[data-dews-bind-value]')[0].dataset.dewsBindValue;
            }
            else if($ctrl.find('[data-dews-bind-code]').length > 0){
              reqInfo.BIND_COL = $ctrl.find('[data-dews-bind-code]')[0].dataset.dewsBindCode;
            }

            penelItems.push(reqInfo);
          }
        });
      }

      // 필수, 중복, 유니크 항목 체크
      if(type != "tree"){
        $.each(mstCtrl.dataItems(), function(rowIdx, row){

          if(!panelUse && type == "grid"){
            // 그리드 컬럼 필수 검증
            $.each(mstCtrl.getColumns(), function(colIdx, col){
              if(col.attributes && col.attributes.class == "required" && (row[col.field] == null || row[col.field] == '')){
                result.required.push({ rowIdx: rowIdx, colField: col.field, colName: col.title, ctrlId: null, node: null });
              }
            });
          }
          else if(panelUse){
            $.each(penelItems, function(idx, ctrl){
              if(row[ctrl.BIND_COL] == null || row[ctrl.BIND_COL] == ''){
                result.required.push({ rowIdx: rowIdx, colField: ctrl.BIND_COL, colName: ctrl.LABEL_TXT, ctrl: ctrl.CONTROL, node: null });
              }
            });
          }

          var pkChk = true;
          var pkStr = "";
          var dupleRow = { rowIdx: rowIdx };
          if(pkArr && pkArr.length > 0){
            $.each(pkArr, function(i, key){
              if(row[key] == null || row[key] == ""){
                pkChk = false;
                return false;
              }
              else{
                if(i < key.length){
                  pkStr += row[key] + "^";
                }
                else{
                  pkStr += row[key];
                }

                dupleRow[key] = row[key];
              }
            });

            if(pkChk){
              if(pkPipe.indexOf("|" + pkStr + "|") == -1){
                pkPipe += pkStr + "|";
              }
              else{
                result.duplePK.push(dupleRow);
              }
            }
          }

          var uniqueStr = "";
          var uniqueRow = { rowIdx: rowIdx };
          if(uniqueArr && uniqueArr.length > 0){
            $.each(uniqueArr, function(i, key){
              if(row[key] != null && row[key] != ""){
                if(i < key.length){
                  uniqueStr += ((row[key] == null || row[key] == "") ? " " : row[key]) + "^";
                }
                else{
                  uniqueStr += row[key];
                }

                uniqueRow[key] = row[key];
              }
            });

            if(uniqueStr != ""){
              if(uqPipe.indexOf("|" + uniqueStr + "|") == -1){
                uqPipe += uniqueStr + "|";
              }
              else{
                result.dupleUnique.push(uniqueRow);
              }
            }
          }

          if(type == "grid" && dtlUse){
            var dtlItems

            if(mstCtrl.dataSource.options.detailDataSource.options.lineDataSources[row._uid]){
              dtlItems = mstCtrl.dataSource.options.detailDataSource.options.lineDataSources[row._uid].data()
            }

            $.each(dtlItems, function(dtlIdx, dtlRow){

              $.each(dtlCtrl.getColumns(), function(colIdx, col){
                if(col.attributes && col.attributes.class == "required" && (dtlRow[col.field] == null || dtlRow[col.field] == '')){
                  result.dtlRequired.push({ rowIdx: dtlIdx, mstIdx: rowIdx, colField: col.field, colName: col.title, ctrlId: null, node: null });
                }
              });

              var dtlPkChk = true;
              var dtlPkStr = "";
              var dtlDupleRow = { rowIdx: dtlIdx, mstIdx: rowIdx };
              if(dtlPkArr && dtlPkArr.length > 0){
                $.each(dtlPkArr, function(i, key){
                  if(dtlRow[key] == null || dtlRow[key] == ""){
                    dtlPkChk = false;
                    return false;
                  }
                  else{
                    if(i < key.length){
                      dtlPkStr += dtlRow[key] + "^";
                    }
                    else{
                      dtlPkStr += dtlRow[key];
                    }

                    dtlDupleRow[key] = dtlRow[key];
                  }
                });

                if(dtlPkChk){
                  if(dtlPkPipe.indexOf("|" + dtlPkStr + "|") == -1){
                    dtlPkPipe += dtlPkStr + "|";
                  }
                  else{
                    result.dtlDuplePK.push(dtlDupleRow);
                  }
                }
              }

              var dtlUniqueStr = "";
              var dtlUniqueRow = { rowIdx: dtlIdx, mstIdx: rowIdx };
              if(dtlUniqueArr && dtlUniqueArr.length > 0){
                $.each(dtlUniqueArr, function(i, key){
                  if(dtlRow[key] != null && dtlRow[key] != ""){
                    if(i < key.length){
                      dtlUniqueStr += ((dtlRow[key] == null || dtlRow[key] == "") ? " " : dtlRow[key]) + "^";
                    }
                    else{
                      dtlUniqueStr += dtlRow[key];
                    }

                    dtlUniqueRow[key] = dtlRow[key];
                  }
                });

                if(dtlUniqueStr != ""){
                  if(dtlUqPipe.indexOf("|" + dtlUniqueStr + "|") == -1){
                    dtlUqPipe += dtlUniqueStr + "|";
                  }
                  else{
                    result.dtlDupleUnique.push(dtlUniqueRow);
                  }
                }
              }

            });
          }
        });
      }
      else {
        // 트리 검증
        if(panelUse){
          $.each($tree.find('.k-item'), function(idx, node){
            var nodeItem = mstCtrl.dataItem(node);

            if(nodeItem != null && nodeItem.level() + 1 <= exceptLevel){
              return true;
            }

            $.each(penelItems, function(idx, ctrl){
              if(nodeItem[ctrl.BIND_COL] == null || nodeItem[ctrl.BIND_COL] == ''){
                result.required.push({ rowIdx: null, colField: ctrl.BIND_COL, colName: ctrl.LABEL_TXT, ctrl: ctrl.CONTROL, node: node });
              }
            });

            var pkChk = true;
            var pkStr = "";
            var dupleRow = { rowIdx: null, node: node };
            if(pkArr && pkArr.length > 0){
              $.each(pkArr, function(i, key){
                if(nodeItem[key] == null || nodeItem[key] == ""){
                  pkChk = false;
                }
                else{
                  if(i < key.length){
                    pkStr += nodeItem[key] + "^";
                  }
                  else{
                    pkStr += nodeItem[key];
                  }

                  dupleRow[key] = nodeItem[key];
                }
              });

              if(pkChk){
                if(pkPipe.indexOf("|" + pkStr + "|") == -1){
                  pkPipe += pkStr + "|";
                }
                else{
                  result.duplePK.push(dupleRow);
                }
              }
            }

            var uniqueStr = "";
            var uniqueRow = { index: null, node: node };
            if(uniqueArr && uniqueArr.length > 0){
              $.each(uniqueArr, function(i, key){
                if(nodeItem[key] != null && nodeItem[key] != ""){
                  if(i < key.length){
                    uniqueStr += ((nodeItem[key] == null || nodeItem[key] == "") ? " " : nodeItem[key]) + "^";
                  }
                  else{
                    uniqueStr += nodeItem[key];
                  }

                  uniqueRow[key] = nodeItem[key];
                }
              });

              if(uniqueStr != ""){
                if(uqPipe.indexOf("|" + uniqueStr + "|") == -1){
                  uqPipe += uniqueStr + "|";
                }
                else{
                  result.dupleUnique.push(uniqueRow);
                }
              }
            }
          });
        }
      }

      if(msgUse){
        var chk = false;
        var errType = "";
        var dtlFlag = false;
        var rowIndex = 0;
        var dtlIndex = 0;
        var column = "";
        var showMessage = "";
        var ctrl;
        var node;

        if(result.required.length > 0){
          chk = true;
          errType = "required";
          rowIndex = result.required[0].rowIdx;
          column = result.required[0].colField;
          ctrl = result.required[0].ctrl;
          node = result.required[0].node;
          showMessage = result.required[0].colName + " " + gerp.MA.MSG.SAVE_VALID_GRID_ALERT;
        }
        else if(result.duplePK.length > 0){
          chk = true;
          errType = "pk";
          rowIndex = result.duplePK[0].rowIdx;
          ctrl = result.duplePK[0].ctrl;
          node = result.duplePK[0].node;
          showMessage = dews.localize.get("중복된 데이터가 존재합니다.", 'M0000744');
        }
        else if(result.dupleUnique.length > 0){
          chk = true;
          errType = "unique";
          rowIndex = result.dupleUnique[0].rowIdx;
          ctrl = result.dupleUnique[0].ctrl;
          node = result.dupleUnique[0].node;
          showMessage = dews.localize.get("중복된 데이터가 존재합니다.", 'M0000744');
        }
        else if(dtlUse && result.dtlRequired != null && result.dtlRequired.length > 0){
          chk = true;
          dtlFlag = true;
          errType = "required";
          rowIndex = result.dtlRequired[0].mstIdx;
          dtlIndex = result.dtlRequired[0].rowIdx;
          column = result.dtlRequired[0].colField;
          showMessage = result.dtlRequired[0].colName + " " + gerp.MA.MSG.SAVE_VALID_GRID_ALERT;
        }
        else if(dtlUse && result.dtlDuplePK != null && result.dtlDuplePK.length > 0){
          chk = true;
          dtlFlag = true;
          errType = "pk";
          rowIndex = result.dtlDuplePK[0].mstIdx;
          dtlIndex = result.dtlDuplePK[0].rowIdx;
          showMessage = dews.localize.get("중복된 데이터가 존재합니다.", 'M0000744');
        }
        else if(dtlUse && result.dtlDupleUnique != null && result.dtlDupleUnique.length > 0){
          chk = true;
          dtlFlag = true;
          errType = "unique";
          rowIndex = result.dtlDupleUnique[0].mstIdx;
          dtlIndex = result.dtlDupleUnique[0].rowIdx;
          showMessage = dews.localize.get("중복된 데이터가 존재합니다.", 'M0000744');
        }

        if(chk){
          if(panelUse){
            if(!dtlFlag){
              if(type == "tree"){
                mstCtrl.select(node);
              }
              else {
                mstCtrl.setFocus();
                mstCtrl.select(rowIndex);
              }

              if(errType == "required"){
                penelCtrl.validate({ tooltip: true, message: gerp.MA.MSG.SAVE_VALID_ALERT });
              }
              else{
                dews.alert(showMessage, "warning");
              }

              $(ctrl).focus();
            }
          }
          else{
            if(type == "grid"){

              if(!dtlFlag){
                mstCtrl.setFocus();
                mstCtrl.select(rowIndex, column);
              }
              else {
                mstCtrl.select(rowIndex);
                dtlCtrl.setFocus();
                dtlCtrl.select(dtlIndex, column);
              }

              dews.alert(showMessage, "warning");
            }
          }
        }
      }

      return result;
    },
    afterSave: function(params){

      // 필수 컨트롤 변수
      var type = params.type;
      var mstCtrl = params.mstCtrl;

      // dtl 사용 여부
      var dtlUse = params.dtlUse;
      var dtlCtrl = params.dtlCtrl;

      var pkArr = params.pkArr;

      if(dtlUse){
        pkArr = params.dtlPkArr;
      }

      // 패널 변수
      var panelUse = params.panelUse;
      var penelCtrl = params.panelCtrl;
      var penelItems = [];

      var error = params.error;

      var infoColumns = [];

      if(dtlUse){
        if(type == "grid"){
          infoColumns = dtlCtrl.getColumns()
        }
      }
      else if(panelUse && penelCtrl != null){
        $.each(penelCtrl.items, function(idx, ctrl){
          var colInfo = {};
          var $ctrl = $(ctrl.container);

          colInfo.title = ctrl.label.textContent;

          if($ctrl.find('[data-dews-bind-column]').length > 0){
            colInfo.field = $ctrl.find('[data-dews-bind-column]')[0].dataset.dewsBindColumn;
          }
          else if($ctrl.find('[data-dews-bind-value]').length > 0){
            colInfo.field = $ctrl.find('[data-dews-bind-value]')[0].dataset.dewsBindValue;
          }
          else if($ctrl.find('[data-dews-bind-code]').length > 0){
            colInfo.field = $ctrl.find('[data-dews-bind-code]')[0].dataset.dewsBindCode;
          }

          penelItems.push(colInfo);
        });

        infoColumns = penelItems;
      }
      else{
        if(type == "grid"){
          infoColumns = mstCtrl.getColumns()
        }
      }

      if(error.length > 0){
        var initData = {
          pkColumns: pkArr,
          infoColumns: infoColumns,
          errorItems: error,
          dtlUse: dtlUse
        };

        var dialog = dews.ui.dialog("H_CA_VERIFY_POP", {
          url: "~/codehelp/CA/H_CA_VERIFY_POP",
          title: dews.localize.get("중복 데이터", 'D0088618'),
          helpCustom: 'true',
          width: 300 + (pkArr.length * 77),
          height: 480,
          buttons: 'close',
          ok: function (data) {

          }
        });

        dialog.setInitData(initData);
        dialog.open();
      }
    }
  };

  module.WS = {
    getProcLastState: function(menu_cd){
      var result = "";

      dews.api.get(dews.url.getApiUrl("CA", "CaWebSocketService", "getProcessLastState"), {
        async: false,
        data: {
          menu_cd: menu_cd
        }
      })
      .done(function(data){
        result = data;
      })
      .fail(function (xhr, satus, error) {
        dews.error(error);
      });

      return result;
    },
    getProcState: function(menu_cd, guid_no){
      var result = "";

      dews.api.get(dews.url.getApiUrl("CA", "CaWebSocketService", "getProcessState"), {
        async: false,
        data: {
          menu_cd: menu_cd,
          guid_no: guid_no
        }
      })
      .done(function(data){
        result = data;
      })
      .fail(function (xhr, satus, error) {
        dews.error(error);
      });

      return result;
    },
    getProcList: function(menu_cd, start_ym, end_ym, st_cd){
      var result;

      dews.api.get(dews.url.getApiUrl("CA", "CaWebSocketService", "getProcessList"), {
        async: false,
        data: {
          menu_cd: menu_cd,
          start_dt: start_ym,
          end_dt: end_ym,
          st_cd: st_cd
        }
      })
      .done(function(data){
        result = data;
      })
      .fail(function (xhr, satus, error) {
        dews.error(error);
      });

      return result;
    },
    openProcDialog: function(menu_cd){
      var initData = {
        MENU_CD: menu_cd,
      };

      var dialog = dews.ui.dialog("H_CA_WSWRK_INFO", {
        url: "~/codehelp/CA/H_CA_WSWRK_INFO",
        title: dews.localize.get("작업관리", "D0102864", dews.localize.language(), "COPTBS00100"),  //CS:)
        helpCustom: 'true',
        width: 1050,
        height: 445,
        ok: function (data) {

        }
      });

      dialog.setInitData(initData);
      dialog.open();
    },
    insertProcess: function(menu_cd, fg_cd, insertDatas){
      var guid;

      dews.api.post(dews.url.getApiUrl("CA", "CaWebSocketService", "insertProcess"), {
        async: false,
        data: {
          menu_cd: menu_cd,
          fg_cd: fg_cd,
          insertDatas: JSON.stringify(insertDatas)
        }
      })
      .done(function(data){
        guid = data;
      })
      .fail(function (xhr, satus, error) {
        dews.error(error);
      });

      return guid;
    },
    updateProcess: function(menu_cd, guid_no_pipe, st_cd, flag_cd, updateDatas){
      dews.api.post(dews.url.getApiUrl("CA", "CaWebSocketService", "updateProcess"), {
        async: false,
        data: {
          menu_cd: menu_cd,
          guid_no_pipe: guid_no_pipe,
          st_cd: st_cd,
          flag_cd: flag_cd,
          updateDatas: JSON.stringify(updateDatas)
        }
      })
      .done(function(data){

      })
      .fail(function (xhr, satus, error) {
        dews.error(error);
      });
    },
    procCheck: function(menu_cd){
      var result = true;
      var procState = module.WS.getProcLastState(menu_cd);

      if(procState === "1"){
        dews.alert("진행 중인 프로세스가 존재합니다.", "warning")
        .done(function(e){
          module.WS.openProcDialog(menu_cd);
        });
        return false;
      }

      return result;
    }
  };

  module.FILE = {
    initialFile: function(dewself, menuCode, dataCode, callback) {

      var $conditionPanel = $(".dews-ui-condition-panel", dewself.$content);
      var $acpe = $("input.required.ca-acpe", dewself.$content);
      var $corp = ($("input.required.ca-corp", dewself.$content).length) ? $("input.required.ca-corp", dewself.$content) : $("select.required.ca-corp", dewself.$content);
      var $btnFile =  $("button.ca-btn-file", dewself.$content);

      if($btnFile.length > 0){
        var dewsConPanel = ($conditionPanel.length) ? dewself[$conditionPanel[0].id] : '';
        var dewsAcpe = ($acpe.length) ? dewself[$acpe[0].id] : '';
        var dewsCorp = ($corp.length) ? dewself[$corp[0].id] : '';
        // var dewsTcorp = ($corp.length > 1 && dataCode == "23") ? dewself[$corp[1].id] : '';

      if(dewsAcpe != "" && dewsCorp != ""){

          $btnFile.text(dews.localize.get("첨부파일", "D0007015"));
          $btnFile.off("click").on("click", function(e){
            var acpcCode = dewsAcpe.code();
            var corpCode = $corp.hasClass("dews-ui-codepicker") ? dewsCorp.code() : dewsCorp.codes();
            // var tcorpCode = dewsTcorp ? dewsTcorp.codes() : "";

            // if(!acpcCode || !corpCode || corpCode.length <= 0 || (dataCode == "23" && (!tcorpCode || tcorpCode.length <= 0))){
            if(!acpcCode || !corpCode || corpCode.length <= 0){
              dewsConPanel.validate({ tooltip: true, message: gerp.MA.MSG.SAVE_VALID_ALERT });
            }
            else {
              var dialogType = $corp.hasClass("dews-ui-codepicker") ? "single" : "multi";
              var menuInfo = {
                MENU_CD: menuCode,
                DATA_CD: dataCode,
                SETTL_YM: dewsAcpe.code(),
                CORP_CD: ($corp.hasClass("dews-ui-codepicker") ? dewsCorp.code() : ""),
                CORP_CD_PIPE: ($corp.hasClass("dews-ui-codepicker") ? dewsCorp.code() + "|" : dewsCorp.codes().join("|")),
                FGRP_SQ: null
              }

              module.FILE.openDialog(dialogType, menuInfo, callback);
            }
          });
        }
      }
    },
    openDialog: function(type, menuInfo, callback){
      var dialogID = "";
      var dialogWidth = 0;
      var dialogHeight = 0;
      var dialogTitle = dews.localize.get("첨부파일 등록", 'D0014033');

      if(type == "single"){
        dialogID = "H_CA_FILE_UPLOAD";
        dialogWidth = 800;
        dialogHeight = 315;

        var schedule = module.FILE.searchFileScheduleData(menuInfo);
        menuInfo.STATUS = {
          AUTH_TP: schedule.length > 0 ? schedule[0].AUTH_TP : 9,
          SCHDUL_ST: schedule.length > 0 ? schedule[0].SCHDUL_ST : 9,
          CLOSE_DT: new Date(schedule[0].CLOSE_DT.substring(0, 4), parseInt(schedule[0].CLOSE_DT.substring(4, 6)) - 1, schedule[0].CLOSE_DT.substring(6))
        };
      }
      else if(type == "multi"){
        dialogID = "H_CA_FILE_MULTICORP";
        dialogWidth = 800;
        dialogHeight = 500;
      }
      else if(type == "download"){
        dialogID = "H_CA_FILE_DOWNLOAD";
        dialogWidth = 800;
        dialogHeight = 450;
        dialogTitle = dews.localize.get("첨부파일 다운로드", "D0078368");
      }

      var initData = { INFO: menuInfo };

      var dialog = dews.ui.dialog(dialogID, {
        url: "~/codehelp/CA/" + dialogID,
        title: dialogTitle,
        helpCustom: 'true',
        width: dialogWidth,
        height: dialogHeight,
        ok: function (data) {
          if(typeof(callback) === "function"){
            callback(true);
          }
        }
      });

      dialog.setInitData(initData);
      dialog.open();
    },
    searchFileData: function(menuInfo, callback) {
      dews.api.post(dews.url.getApiUrl("CA", "CaCommonService", "getFileData"), {
        async: false,
        data: {
          menuInfo: JSON.stringify(menuInfo)
        }
      })
      .done(function(data){
        if(typeof(callback) === "function"){
          callback(data);
        }
      })
      .fail(function (xhr, status, error, e) {
        dews.error(error);
      });
    },
    searchFileScheduleData: function(menuInfo, callback) {
      var result = [];

      dews.api.get(dews.url.getApiUrl("CA", "CaCommonService", "getFileSchedule"), {
        async: false,
        data: {
          settl_ym: menuInfo.SETTL_YM,
          data_cd: menuInfo.DATA_CD,
          corp_cd_pipe: menuInfo.CORP_CD_PIPE
        }
      })
      .done(function(data){
        result = data;
      })
      .fail(function (xhr, status, error, e) {
        dews.error(error);
      });

      return result;
    },
    fileBind: function(ctrl, data) {
      var filelist = dews.ui.dataSource("filelist", { data: data });
      ctrl.setDataSource(filelist);
      filelist.read();
    },
    saveFileData: function(menuInfo, insertFileList, deleteFileList, callback){

      var ret = module.FILE.beforeSave(menuInfo.STATUS);

      if(!ret){
        dews.api.post(dews.url.getApiUrl("CA", "CaCommonService", "saveFileInfo"), {
          async: false,
          data: {
            menuInfo: JSON.stringify(menuInfo),
            insertFileList: JSON.stringify(insertFileList),
            deleteFileList: JSON.stringify(deleteFileList)
          }
        })
        .done(function(data){
          dews.alert(gerp.MA.MSG.SAVE_DONE_ALERT).done(function(){
            if(typeof(callback) === "function"){
              callback();
            }
          });
        })
        .fail(function (xhr, status, error, e) {
          dews.error(error);
        });
      }
      else {
        dews.alert(ret, "warning");
      }
    },
    beforeSave: function(data) {
      var result = "";
      var nowDate = new Date();
      nowDate.setHours(0, 0, 0, 0);

      if(data.AUTH_TP > "3"){
        result = dews.localize.get("권한이 없습니다.", "M0005289", dews.localize.language(), "COPTBS00100");
      }
      else if(data.SCHDUL_ST > "4"){
        result = dews.localize.get("작성상태를 확인해 주십시오.", "M0002614", dews.localize.language(), "COPTBS00100");
      }
      else if(data.CLOSE_DT.getTime() < nowDate.getTime()){
        result = dews.localize.get("마감일을 확인해주십시오.", "M0010486", dews.localize.language(), "COPTBS00100");
      }

      return result;
    },
    fileDowload: function(dewself, fileName, fileKeys){
      var keys = "";
      var url = "/download/files";
      var token = getToken();
      var $iframe = $('<iframe style="display: none; width: 0; height: 0;"></iframe>');

      keys = fileKeys;

      url += "?keys=" + encodeURIComponent(keys) + "&zipname=" + encodeURIComponent(fileName) + "&token=" + encodeURIComponent(token);
      dewself.$content.append($iframe);
      $iframe.prop("src", url);
      // dewself.$content.find('> iframe').remove();

      function getToken() {
        var result = "";

        dews.api.get('/auth/temporary/token', { async: false }).done(function(data){
          result = data;
        });

        return result;
      }
    },
    getFileKey: function(items){
      var result = "";

      var sliceLength = parseInt(items.length / 500) + 1;
      var sliceRemainder = items.length % 500;

      var startIdx = 0;

      for(var i = 0; i < sliceLength; i++){
        var sliceItems = [];

        if(i != sliceLength - 1){
          sliceItems = items.slice(startIdx, (startIdx + 500));
        }
        else {
          sliceItems = items.slice(startIdx, (startIdx + sliceRemainder));
        }

        startIdx += 500;

        dews.api.post(dews.url.getApiUrl("CA", "CaCommonService", "getFileKeys"), {
          async: false,
          data: {
            items: JSON.stringify(sliceItems)
          }
        })
        .done(function(data){
          result += data;
        })
        .fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
      }

      return result;
    }
  }

  dews.localize.load(dews.localize.language(), 'COPTBS00100')

  console.log('## CA Module Script Loaded!!! ## 2022.12.28');

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
