/*
 * IA 모듈 공통 함수
 * /view/js/ia.cm.js
 */
(function (dews, gerp, $) {
  var module = {};

  //---------Setting
  var moduleCode = "IA"; //모듈 코드

  //---------Start
  //공통함수
  module.COMMON = {
    /**
     * 환경설정 데이터 가져오기 (CI)
     * @example var ret = COMMON.getCiCtrlConfig("IA", "P00540");
     * @param {*} module_cd : 모듈
     * @param {*} ctrl_cd : 구분
     * @return {*} 년월
     */
    getCiCtrlConfig: function (module_cd, ctrl_cd) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "CM",
            "CommonCtrlConfigService",
            "common_ci_ctrlconfig_string"
          ),
          {
            async: false,
            data: {
              module_cd: module_cd,
              ctrl_cd: ctrl_cd,
              use_yn: "Y",
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 환경설정 데이터 가져오기 (MA)
     * @example var ret = COMMON.getMaCtrlConfig("IA", "P00540");
     * @param {*} module_cd : 모듈
     * @param {*} ctrl_cd : 구분
     * @return {*} 년월
     */
    getMaCtrlConfig: function (module_cd, ctrl_cd) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "CM",
            "CommonCtrlConfigService",
            "common_ma_ctrlconfig_string"
          ),
          {
            async: false,
            data: {
              module_cd: module_cd,
              ctrl_cd: ctrl_cd,
              use_yn: "Y",
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * null Check
     * @returns
     */
    //null 체크  2022.03.25 CS:)
    isEmpty: function (data) {
      if (
        data === "" ||
        data === undefined ||
        data === null ||
        data.length === 0
      ) {
        return true;
      } else {
        return false;
      }
    },    

    /**
     * 로그인사용자의 권한 가져오기 2022.03.25 CS:)
     * @param {*}
     * @param {*} object
     * @param {*} mvot_fg
     * @param {*} eval_prid_sq
     * @returns
     */
    getLoginAuth: function () {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_get_authority"
          ),
          {
            async: false,
            data: {},
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      if (ret !== null && ret !== undefined && ret.DATA2 == "1") {
        return true;
      } else {
        return false;
      }
    },
    /**
     * 로그인사용사 권한있는 회사 목록 가져오기 2022.01.14 CS:)
     * @example var ret = COMMON.getAuthCompanyInfo("USER_ID", "LOGIN_GROUP", "LANG_CD");
     * @param {*} user_id : 로그인계정 ID
     * @param {*} login_group : 로그인계정 그룹 ID
     * @param {*} lang_cd : 선택 언어
     * @returns 로그인사용자의 권한회사 리스트 리턴
     */
    getAuthCompanyInfo: function (loginUser, loginGroup, langCd) {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "common_ia_companyinfo"),
          {
            async: false,
            data: {
              loginUser: loginUser,
              loginGroup: loginGroup,
              langCd: langCd,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * WIDGET에서 회사변경시 IA_EXCELUPLD7_INFO테이블에 저장된 변경된 회사코드 불러오기 2022.01.19 CS:)
     * @example var ret = COMMON.getCompanyCode("USER_ID")
     * @param {*} loginUser : 로그인계정 ID
     * @return WIDGET 회사 드롭다운에 변경된 회사코드 리턴
     */
    getCompanyCode(loginUser) {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "common_ia_company_select"
          ),
          {
            async: false,
            data: {
              loginUser: loginUser,
            },
          }
        )
        .done(function (data) {
          if (data && data.length > 0) {
            ret = data[0].companyCode;
          } else {
            ret = null;
          }
        });

        return ret;
    },

    /**
     * 로그인사용자의 사용권한 회사WIDGET에서 회사변경시 IA_EXCELUPLD7_INFO테이블에 변경된 회사코드 저장 2022.01.19 CS:)
     * @example IA_EXCELUPLD7_INFO테이블에 MENU_ID : 'DASHBOARD', DATA98_TXT(로그인계정ID), DATA99_TXT(변경한회사코드)로 저장
     * @param {*} loginUser : 로그인계정 ID
     * @param {*} company_cd : 회사변경 WIDGET 드롭다운에서 변경한 회사코드
     */
    setCompanyCode(loginUser, company_cd) {
      var ret = null;
      dews.api.get(
        dews.url.getApiUrl("IA", "IACommonService", "common_ia_companysave"),
        {
          async: false,
          data: {
            loginUser: loginUser,
            companyCode: company_cd,
          },
        }
      );
    },

    /**
     * 통제정보버전 디폴트값으로 가져오기
     * @example var ret = COMMON.getEvalPlanDefault("20170101", "20181128");
     * @return {*} 통제정보버전 중 제일 순번이 높은 것 리턴
     */
    getVersionDefault: function () {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_version_list"),
          {
            async: false,
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 연결평가주기 디폴트값으로 가져오기
     * @example var ret = COMMON.getConcorpPlanDefault("20170101", "20181128");
     * @param {*} evalType : 작업 타입 (자가진단:1, 설계평가:2, 운영평가: 3, 전체: "")
     * @return {*} 평가주기중 제일 순번이 높은 것 리턴
     */
    getConCorpPlanDefault: function (evalType) {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_con_corpplan_list"
          ),
          {
            async: false,
            data: {
              evalType: evalType || "",
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 평가주기 디폴트값으로 가져오기
     * @example var ret = COMMON.getEvalPlanDefault("20170101", "20181128");
     * @param {*} evalType : 작업 타입 (자가진단:1, 설계평가:2, 운영평가: 3, 전체: "")
     * @return {*} 평가주기중 제일 순번이 높은 것 리턴
     */
    getEvalPlanDefault: function (evalType) {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evalplan_list"
          ),
          {
            async: false,
            data: {
              evalType: evalType || "",
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 법인별 평가주기 디폴트값으로 가져오기
     * @example var ret = COMMON.getEvalPlanDefault("20170101", "20181128");
     * @param {*} company_cd : 회사 코드
     * @param {*} evalType : 작업 타입 (자가진단:1, 설계평가:2, 운영평가: 3, 전체: "")
     * @return {*} 평가주기중 제일 순번이 높은 것 리턴
     */
    getComEvalPlanDefault: function (company_cd, evalType) {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evalplan_list"
          ),
          {
            async: false,
            data: {
              company_cd: company_cd,
              evalType: evalType || "",
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 평가보고서 디폴트값으로 가져오기
     * @example var ret = COMMON.getEvrptDefault();
     * @return {*} 평가보고서 중 순번이 높은걸 리턴, DoubleObject (DATA1, DATA2)
     */
    getEvrptDefault: function () {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_evrpt_list"),
          {
            async: false,
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 감사평가보고서 디폴트값으로 가져오기
     * @example var ret = COMMON.getAuEvrptDefault();
     * @return {*} 평가보고서 중 순번이 높은걸 리턴, DoubleObject (DATA1, DATA2)
     */
    getAuEvrptDefault: function () {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_auevrpt_list"),
          {
            async: false,
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 법인별 평가보고서 디폴트값으로 가져오기
     * @example var ret = COMMON.getEvrptDefault();
     * @return {*} 평가보고서 중 순번이 높은걸 리턴, DoubleObject (DATA1, DATA2)
     */
    getComEvrptDefault: function (company_cd) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_evrpt_list"),
          {
            async: false,
            data: {
              company_cd: company_cd,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 평가계획 설계, 운영, 자가진단 상태 값 가져오기
     * @example var ret = COMMON.getEvalPlanState(evalPlan);
     * @param {*} evalPlan : 평가주기순번
     * @return {*} 받아온 평가주기순번의 설계평가, 운영평가, 자가진단의 전사수준과 업무수준 체크 값을 가져 옴
     */
    getEvalPlanState: function (evalPlan) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evalplan_state_list"
          ),
          {
            async: false,
            data: {
              evalPlan: evalPlan,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 법인별 평가계획 설계, 운영, 자가진단 상태 값 가져오기
     * @example var ret = COMMON.getEvalPlanState(evalPlan);
     * @param {*} evalPlan : 평가주기순번
     * @return {*} 받아온 평가주기순번의 설계평가, 운영평가, 자가진단의 전사수준과 업무수준 체크 값을 가져 옴
     */
    getComEvalPlanState: function (company_cd, evalPlan) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evalplan_state_list"
          ),
          {
            async: false,
            data: {
              company_cd: company_cd,
              evalPlan: evalPlan,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 평가주기별 자가진단/평가 진행관리 -> 진행상태 리턴
     * @example var ret = COMMON.getPridClose(1, '5');
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} prgr_mng_fg : 진행관리구분
     * @return {*} 년월
     */
    getPridClose: function (eval_prid_sq, prgr_mng_fg) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_prid_close_list"
          ),
          {
            async: false,
            data: {
              eval_prid_sq: eval_prid_sq,
              prgr_mng_fg: prgr_mng_fg,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 법인별 평가주기별 자가진단/평가 진행관리 -> 진행상태 리턴
     * @example var ret = COMMON.getPridClose(1, '5');
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} prgr_mng_fg : 진행관리구분
     * @return {*} 년월
     */
    getComPridClose: function (company_cd, eval_prid_sq, prgr_mng_fg) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_prid_close_list"
          ),
          {
            async: false,
            data: {
              company_cd: company_cd,
              eval_prid_sq: eval_prid_sq,
              prgr_mng_fg: prgr_mng_fg,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 스코핑평가주기별 자가진단/평가 진행관리 -> 진행상태 리턴
     * @example var ret = COMMON.getPridClose(1, '1'); //1.작성, 2.승인
     * @param {*} scop_prid_sq : 스코핑평가주기
     * @param {*} prgr_mng_fg : 진행관리구분
     * @return {*} 년월
     */
    getScPridClose: function (scop_prid_sq, prgr_mng_fg) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_scprid_close_list"
          ),
          {
            async: false,
            data: {
              scop_prid_sq: scop_prid_sq,
              prgr_mng_fg: prgr_mng_fg,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 연결 스코핑평가주기별 자가진단/평가 진행관리 -> 진행상태 리턴
     * @example var ret = COMMON.getIcScPridClose(1, '1'); //1.작성, 2.승인
     * @param {*} scop_prid_sq : 연결스코핑평가주기
     * @param {*} prgr_mng_fg : 진행관리구분
     * @return {*} 년월
     */
    getIcScPridClose: function (scop_prid_sq, prgr_mng_fg) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_icscprid_close_list"
          ),
          {
            async: false,
            data: {
              scop_prid_sq: scop_prid_sq,
              prgr_mng_fg: prgr_mng_fg,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 법인별 스코핑평가주기별 자가진단/평가 진행관리 -> 진행상태 리턴
     * @example var ret = COMMON.getPridClose(1, '1'); //1.작성, 2.승인
     * @param {*} scop_prid_sq : 스코핑평가주기
     * @param {*} prgr_mng_fg : 진행관리구분
     * @return {*} 년월
     */
    getComScPridClose: function (company_cd, scop_prid_sq, prgr_mng_fg) {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_scprid_close_list"
          ),
          {
            async: false,
            data: {
              company_cd: company_cd,
              scop_prid_sq: scop_prid_sq,
              prgr_mng_fg: prgr_mng_fg,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 평가주기별 사원의 직책명 가져오기
     * @example var ret = COMMON.ia_common_pstn(eval_prid_sq, mvot_fg, emp_no);
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} emp_no : 사원번호
     * @return {*} Scoping중 순번이 제일 높은 것 리턴, 설계자 요구에 따라 날짜는 제거, DoubleObject (DATA1, DATA2)
     *             -> 변경 스코핑 테이블 스키마대로 데이터 리턴 (data1, data2는 우선 살려둠)
     */
    getPstn: function (eval_prid_sq, emp_no) {
      var ret = null;
      dews.api
        .get(dews.url.getApiUrl("IA", "IACommonService", "ia_common_pstn"), {
          async: false,
          data: {
            eval_prid_sq: eval_prid_sq || "",
            emp_no: emp_no || "",
          },
        })
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 평가주기별 사원의 직책명 가져오기
     * @example var ret = COMMON.ia_common_pstn(eval_prid_sq, mvot_fg, emp_no);
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} emp_no : 사원번호
     * @return {*} Scoping중 순번이 제일 높은 것 리턴, 설계자 요구에 따라 날짜는 제거, DoubleObject (DATA1, DATA2)
     *             -> 변경 스코핑 테이블 스키마대로 데이터 리턴 (data1, data2는 우선 살려둠)
     */
    getComPstn: function (company_cd, eval_prid_sq, emp_no) {
      var ret = null;
      dews.api
        .get(dews.url.getApiUrl("IA", "IACommonService", "ia_common_pstn"), {
          async: false,
          data: {
            company_cd: company_cd,
            eval_prid_sq: eval_prid_sq || "",
            emp_no: emp_no || "",
          },
        })
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * Scoping 디폴트값으로 가져오기
     * @example var ret = COMMON.getScopingDefault();
     * @param {*} date_start : 시작년월일
     * @param {*} date_end : 종료년월일
     * @return {*} Scoping중 순번이 제일 높은 것 리턴, 설계자 요구에 따라 날짜는 제거, DoubleObject (DATA1, DATA2)
     *             -> 변경 스코핑 테이블 스키마대로 데이터 리턴 (data1, data2는 우선 살려둠)
     */
    getScopingDefault: function () {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_scoping_list"),
          {
            async: false,
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * Scoping 디폴트값으로 가져오기
     * @example var ret = COMMON.getScopingDefault();
     * @param {*} date_start : 시작년월일
     * @param {*} date_end : 종료년월일
     * @return {*} Scoping중 순번이 제일 높은 것 리턴, 설계자 요구에 따라 날짜는 제거, DoubleObject (DATA1, DATA2)
     *             -> 변경 스코핑 테이블 스키마대로 데이터 리턴 (data1, data2는 우선 살려둠)
     */
    getComScopingDefault: function (company_cd) {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_scoping_list"),
          {
            async: false,
            data: {
              company_cd: company_cd,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },


    /**
     * 연결Scoping 디폴트값으로 가져오기
     * @example var ret = COMMON.getScopingDefault();
     * @param {*} date_start : 시작년월일
     * @param {*} date_end : 종료년월일
     * @return {*} 연결Scoping중 순번이 제일 높은 것 리턴, 설계자 요구에 따라 날짜는 제거, DoubleObject (DATA1, DATA2)
     *             -> 변경 스코핑 테이블 스키마대로 데이터 리턴 (data1, data2는 우선 살려둠)
     */
    getComIcScopingDefault: function () {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_ic_common_scoping_list"),
          {
            async: false,
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 연결Scoping 디폴트값으로 가져오기
     * @example var ret = COMMON.getIcScopingDefault();
     * @param {*} date_start : 시작년월일
     * @param {*} date_end : 종료년월일
     * @return {*} 연결Scoping중 순번이 제일 높은 것 리턴, 설계자 요구에 따라 날짜는 제거, DoubleObject (DATA1, DATA2)
     *             -> 변경 스코핑 테이블 스키마대로 데이터 리턴 (data1, data2는 우선 살려둠)
     */
    getComIcScopingDefault: function (company_cd) {
      var ret = null;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_ic_common_scoping_list"),
          {
            async: false,
            data: {
              company_cd: company_cd,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },


    /**
     * 현재 로그인 아이디에 맞는 내부회계 사용자의 부서 디폴트값으로 가져오기
     * @example var ret = COMMON.getDeptDefault();
     * @return {*} 로그인 사용자에 맞는 내부회계 사용자 정보
     */
    getDeptDefault: function () {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_dept_list"),
          {
            async: false,
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 현재 로그인 아이디에 맞는 내부회계 사용자 디폴트값으로 가져오기
     * @example var ret = COMMON.getUserDefault();
     * @return {*} 로그인 사용자에 맞는 내부회계 사용자 정보
     */
    getUserDefault: function () {
      var ret = null;

      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_user_list"),
          {
            async: false,
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });

      return ret;
    },

    /**
     * 현재 로그인 아이디에 맞는 평가주기별 내부회계 사용자 디폴트값으로 가져오기
     * @example var ret = COMMON.getPrUserDefault(1, '1');
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} mvot_fg : 이관구분 (1.평가주기별기초데이터 이관, 2.스코핑주기별 기초데이터 이관)
     * @return {*} 평가주기중 젤 순번이 높은걸 리턴, 설계자 요구에 따라 날짜는 제거, DoubleObject (DATA1, DATA2)
     */
    getPrUserDefault: function (eval_prid_sq, mvot_fg) {
      var ret;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_pruser_list"),
          {
            async: false,
            data: {
              eval_prid_sq: eval_prid_sq || "",
              mvot_fg: mvot_fg || "",
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      return ret;
    },
    /**
     * 현재 로그인 아이디에 맞는 평가주기별 내부회계 사용자 부서 가져오기
     * @example var ret = COMMON.getPrDeptDefault(1, '1',user_id);
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} mvot_fg : 이관구분 (1.평가주기별기초데이터 이관, 2.스코핑주기별 기초데이터 이관)
     * @param {*} user_id : User EMP_NO
     * @return {*} String (DATA1)
     */
    getPrDept: function (eval_prid_sq, mvot_fg, user_id) {
      var ret;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_prdept"),
          {
            async: false,
            data: {
              eval_prid_sq: eval_prid_sq || "",
              mvot_fg: mvot_fg || "",
              user_id: user_id
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      return ret;
    },

    /**
     * 현재 로그인 아이디에 맞는 평가보고서별 내부회계 사용자 디폴트값으로 가져오기
     * @example var ret = COMMON.getPrUserDefault(1, '1');
     * @param {*} evrpt_sq : 평가보고서순번
     * @param {*} mvot_fg : 이관구분 (1.평가주기별기초데이터 이관, 2.스코핑주기별 기초데이터 이관)
     * @return {*} 평가주기중 젤 순번이 높은걸 리턴, 설계자 요구에 따라 날짜는 제거, DoubleObject (DATA1, DATA2)
     */
    getErUserDefault: function (evrpt_sq, mvot_fg) {
      var ret;
      dews.api
        .get(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_evuser_list"),
          {
            async: false,
            data: {
              evrpt_sq: evrpt_sq || "",
              mvot_fg: mvot_fg || "",
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      return ret;
    },

    /**
     * 권한 적용
     * @example IA.COMMON.setAuthority(self.$content.find("#btnInit"));
     * @argument {String} object : 대상 객체(조회조건인 경우 None or Disabled, 버튼인경우 Show or Hide
     * @return {Object} 사용자의 권한정보(DATA1: 사원코드, DATA2: 권한 값, DATA3: 사원명)
     */
    setAuthority: function (object, mvot_fg, eval_prid_sq) {
      var rt = null;
      var node = object[0];
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_get_authority"
          ),
          {
            async: false,
            data: {},
          }
        )
        .done(function (data) {
          if ($(node).hasClass("dews-ui-codepicker")) {
            var dewsControl = $(node).data("dews-control");
            if (data) {
              if (data.DATA2 == "1") {
                rt = data;
                dewsControl.readonly(false);
              } else {
                dewsControl.readonly(true);
              }
              dewsControl.setData({ EMP_NO: data.DATA1, EMP_NM: data.DATA3 });
            } else {
              dewsControl.readonly(true);
              dews.alert(dews.localize.get('사용자를 내부회계 사원 테이블에 추가해야 합니다.', 'M0011018', dews.localize.language(), "ITAOTS00100"));
            }
          } else if ($(node).hasClass("dews-ui-button")) {
            if (data && data.DATA2 == "1") {
              rt = data;
              $(node).css("display", "");
            } else {
              $(node).css("display", "none");
            }
          } else if ($(node).hasClass("dews-button-group")) {
            if (data && data.DATA2 == "1") {
              rt = data;
              $(node).css("display", "");
            } else {
              $(node).css("display", "none");
            }
          }
        });

      return rt;
    },
  };

  /***
   * ERROR LOG 조회
   * gubn : 1.CO LOG, 2.CM LOG
   */
  module.viewErrorList = function(menu_cd, menu_nm) {
    var inputData = {
      MENU_CD: menu_cd,
      MENU_NM: menu_nm
    }
  
    var dlgError;
  
    dlgError = dews.ui.dialog("ITAOTS00100_ERR", {
      url: "/view/IA/ITAOTS00100_ERR",
      title: "에러로그조회",
      width: 1100,
      height: 732,
      initData: inputData
    });
  
    dlgError.open();
  }

  $(document).unbind('keydown.co');

  $(document).bind('keydown.co', function (e) {
    if (e.altKey && e.shiftKey && e.ctrlKey && event.keyCode == 79) {
      if (dews.ui.page.menu.module == "IA") {
        module.viewErrorList(dews.ui.page.menu.id, dews.ui.page.menu.name);
      }
    }
  });

  module.BINDING = {
    /**
     * JQeryObject에 항목들에 데이터 바인딩합니다.
     * @example BINDING.bindingControls($('#content_ITAOTS00200 #tabJyunS'), dataRow);
     * @param {*} object : jqueryObject
     * @param {*} dataRow : 데이터소스 행
     * @return {*} boolean : true (성공), false (실패)
     */
    bindingControls: function (self, object, dataRow) {
      var ret = true;

      //td관련
      var tdList = object.find("td");
      $.each(tdList, function (i, target) {
        if (target.id != undefined && target.id != "") {
          if ($(target).attr("type") == "date") {
            var data = dataRow[target.id];
            if (!data) {
              target.innerHTML = "";
            } else {
              if (data.length == 6) {
                target.innerHTML = dews.string.format(
                  "{0}-{1}",
                  data.substring(0, 4),
                  data.substring(4, 6)
                );
              } else if (data.length == 8) {
                target.innerHTML = dews.string.format(
                  "{0}-{1}-{2}",
                  data.substring(0, 4),
                  data.substring(4, 6),
                  data.substring(6, 8)
                );
              } else {
                target.innerHTML = "";
              }
            }
          } else if ($(target).attr("type") == "period") {
            var startdata = dataRow[$(target).attr("date-start-colname")];
            var enddata = dataRow[$(target).attr("date-end-colname")];
            var start = "",
              end = "";
            if (startdata) {
              if (startdata.length == 6) {
                start = dews.string.format(
                  "{0}-{1}",
                  startdata.substring(0, 4),
                  startdata.substring(4, 6)
                );
              } else if (startdata.length == 8) {
                start = dews.string.format(
                  "{0}-{1}-{2}",
                  startdata.substring(0, 4),
                  startdata.substring(4, 6),
                  startdata.substring(6, 8)
                );
              }
            }
            if (enddata) {
              if (enddata.length == 6) {
                end = dews.string.format(
                  "{0}-{1}",
                  enddata.substring(0, 4),
                  enddata.substring(4, 6)
                );
              } else if (startdata.length == 8) {
                end = dews.string.format(
                  "{0}-{1}-{2}",
                  enddata.substring(0, 4),
                  enddata.substring(4, 6),
                  enddata.substring(6, 8)
                );
              }
            }

            if (start != "" || end != "") {
              target.innerHTML = start + " ~ " + end;
            } else {
              target.innerHTML = "";
            }
          } else if ($(target).attr("type") == "numeric") {
            var data = dataRow[target.id];
            if (!data) {
              target.innerHTML = "";
            } else {
              target.innerHTML = data
                .toString()
                .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
          } else {
            // target.innerHTML = dataRow[target.id] ? dataRow[target.id] : "";
            target.innerHTML = dataRow[target.id]
              ? dataRow[target.id].replace(/\n/gi, "<br>")
              : "";
          }
        }
      });

      //textBox관련
      var txtList = object.find(".dews-ui-textbox"),
        _txt;
      $.each(txtList, function (i, txt) {
        var targetid = txt.id;
        var target = self[txt.id];
        var bindid = $(txt).attr("data-binding-colname");
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          _txt =
            typeof dataRow[targetid] === "undefined"
              ? ""
              : dataRow[targetid] || "";
          target.text(_txt);
        }
      });

      //dropDownList관련
      var dropList = object.find(".dews-ui-dropdownlist");
      $.each(dropList, function (i, drop) {
        var target = self[drop.id];
        if (target != undefined) {
          if (typeof dataRow[drop.id] == "undefined") {
            target.text("");
          } else {
            target.value(dataRow[drop.id]);
          }
        }
      });

      //datePicker관련
      var dateList = object.find(".dews-ui-datepicker");
      $.each(dateList, function (i, date) {
        var target = self[date.id];
        if (target != undefined) {
          target.value(
            typeof dataRow[date.id] === "undefined" ? "" : dataRow[date.id]
          );
        }
      });

      //codePicker관련
      var codepickerList = object.find(".dews-ui-codepicker");
      $.each(codepickerList, function (i, codepicker) {
        var target = self[codepicker.id];
        if (target != undefined) {
          var col = $(codepicker).attr("data-dews-code-field");
          var colname = $(codepicker).attr("data-dews-text-field");
          var code = dataRow[$(codepicker).attr("data-dews-bind-code")];
          var name = dataRow[$(codepicker).attr("data-dews-bind-text")];
          var objData = {};
          objData[col] = typeof code === "undefined" ? "" : code;
          objData[colname] = typeof name === "undefined" ? "" : name;
          target.setData(objData, false);
        }
      });

      //numeric관련
      var numericList = object.find(".dews-ui-numerictextbox");
      $.each(numericList, function (i, numeric) {
        var target = self[numeric.id];
        if (target != undefined) {
          target.value(
            typeof dataRow[numeric.id] === "undefined" ? 0 : dataRow[numeric.id]
          );
        }
      });

      return ret;
    },

    /**
     * JQeryObject에 항목들에 데이터를 리셋합니다.
     * @example BINDING.bindingResetControls($('#content_ITAOTS00200 #tabJyunS'));
     * @param {*} object : jqueryObject
     * @param {*} dataRow : 데이터소스 행
     * @return {*} boolean : true (성공), false (실패)
     */
    bindingResetControls: function (object) {
      var ret = true;

      //td관련
      var tdList = object.find("td");
      $.each(tdList, function (i, target) {
        if (target.id != undefined && target.id != "") {
          target.innerHTML = "";
        }
      });

      //textBox관련
      var txtList = object.find(".dews-ui-textbox"),
        _txt;
      $.each(txtList, function (i, txt) {
        var target = self[txt.id];
        if (target != undefined) {
          target.text("");
        }
      });

      //dropDownList관련
      var dropList = object.find(".dews-ui-dropdownlist");
      $.each(dropList, function (i, drop) {
        var target = self[drop.id];
        if (target != undefined) {
          target.text("");
        }
      });

      //datePicker관련
      var dateList = object.find(".dews-ui-datepicker");
      $.each(dateList, function (i, date) {
        var target = self[date.id];
        if (target != undefined) {
          target.value("");
        }
      });

      //codePicker관련
      var codepickerList = object.find(".dews-ui-codepicker");
      $.each(codepickerList, function (i, codepicker) {
        var target = self[codepicker.id];
        if (target != undefined) {
          var col = $(codepicker).attr("data-dews-code-field");
          var colname = $(codepicker).attr("data-dews-text-field");
          var objData = {};
          objData[col] = "";
          objData[colname] = "";
          target.setData(objData, false);
        }
      });

      //numeric관련
      var numericList = object.find(".dews-ui-numerictextbox");
      $.each(numericList, function (i, numeric) {
        var target = self[numeric.id];
        if (target != undefined) {
          target.value(0);
        }
      });

      return ret;
    },

    /**
     * 평가보고서 수행 상태값을 바인딩 해줍니다.
     * @example BINDING.bindingEvrptState(evprt, $('#content_ITAOTS00200 #tabJyunS'));
     * @param {*} evrpt : 평가보고서 순번
     * @param {*} object : jqueryObject
     * @return {*} object : 상태코드, 명 (성공), false (실패)
     */
    bindingEvrptExec: function (evrpt, object) {
      var ret = true;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evrptexec_list"
          ),
          {
            async: false,
            data: {
              evrpt: evrpt,
            },
          }
        )
        .done(function (data) {
          if (!data) {
            if (object != undefined) {
              object.text(dews.localize.get("미작성", 'D0094676', dews.localize.language(), "ITAOTS00100"));
            }
            ret = false;
          } else {
            if (object != undefined) {
              object.text(data.DATA2 || dews.localize.get("미작성", 'D0094676', dews.localize.language(), "ITAOTS00100"));
            }
            ret = data;
          }
        });
      return ret;
    },

    /**
     * 평가보고서 수행 상태값을 바인딩 해줍니다.
     * @example BINDING.bindingEvrptState(evprt, $('#content_ITAOTS00200 #tabJyunS'));
     * @param {*} evrpt : 평가보고서 순번
     * @param {*} object : jqueryObject
     * @return {*} object : 상태코드, 명 (성공), false (실패)
     */
    bindingComEvrptExec: function (company_cd, evrpt, object) {
      var ret = true;

      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evrptexec_list"
          ),
          {
            async: false,
            data: {
              company_cd: company_cd,
              evrpt: evrpt,
            },
          }
        )
        .done(function (data) {
          if (!data) {
            if (object != undefined) {
              object.text(dews.localize.get("미작성", 'D0094676', dews.localize.language(), "ITAOTS00100"));
            }
            ret = false;
          } else {
            if (object != undefined) {
              object.text(data.DATA2 || dews.localize.get("미작성", 'D0094676', dews.localize.language(), "ITAOTS00100"));
            }
            ret = data;
          }
        });
      return ret;
    },

    /**
     * 평가보고서 수행 상태값을 가져옵니다.
     * @example BINDING.getEvrptExec(evprt);
     * @param {*} evrpt : 평가보고서 순번
     * @param {*} object : jqueryObject
     * @return {*} object : 상태코드, 명 (성공), false (실패)
     */
    getEvrptExec: function (evrpt) {
      var ret = false;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evrptexec_list"
          ),
          {
            async: false,
            data: {
              evrpt: evrpt,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      return ret;
    },

    /**
     * 평가보고서 수행 상태값을 가져옵니다.
     * @example BINDING.getEvrptExec(evprt);
     * @param {*} evrpt : 평가보고서 순번
     * @param {*} object : jqueryObject
     * @return {*} object : 상태코드, 명 (성공), false (실패)
     */
    getComEvrptExec: function (company_cd, evrpt) {
      var ret = false;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evrptexec_list"
          ),
          {
            async: false,
            data: {
              company_cd: company_cd,
              evrpt: evrpt,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      return ret;
    },

    /**
     * 평가보고서 진행관리 값을 가져옵니다.
     * @example BINDING.getEvrptPrgrMng(evprt, prgr_step_fg);
     * @param {*} evrpt : 평가보고서 순번
     * @param {*} prgr_step_fg : 평가보고서 진행단계 구분
     * @return {*} object : 상태코드, 명 (성공), false (실패)
     */
    getEvrptPrgrMng: function (evrpt, prgr_step_fg) {
      var ret = false;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evrptprgr_mng"
          ),
          {
            async: false,
            data: {
              evrpt: evrpt,
              prgr_step_fg: prgr_step_fg,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      return ret;
    },

    /**
     * 평가보고서 진행관리 값을 가져옵니다.
     * @example BINDING.getEvrptPrgrMng(evprt, prgr_step_fg);
     * @param {*} evrpt : 평가보고서 순번
     * @param {*} prgr_step_fg : 평가보고서 진행단계 구분
     * @return {*} object : 상태코드, 명 (성공), false (실패)
     */
    getComEvrptPrgrMng: function (company_cd, evrpt, prgr_step_fg) {
      var ret = false;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_evrptprgr_mng"
          ),
          {
            async: false,
            data: {
              company_cd: company_cd,
              evrpt: evrpt,
              prgr_step_fg: prgr_step_fg,
            },
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      return ret;
    },

    /**
     * JQeryObject에 항목들에 데이터 바인딩합니다.
     * @example BINDING.getState($('#content_ITAOTS00200 #state'), dataRow);
     * @param {*} object : jqueryObject
     * @param {*} stateValue : 상태값
     * @return {*} boolean : true (성공), false (실패)
     */
    getState: function (object, stateValue) {
      var ret = true;
      //td관련
      var tdList = object.find("td");
      if (tdList.length > 0) {
        var target = tdList[0];

        //모든 클래스 삭제
        target.removeAttribute("class");
        //스타일 클래스 추가
        $(target).addClass("bt-state");

        //상태클래스 추가
        if (stateValue == "110") {
          //state-pending : orange -> 미평가
          $(target).addClass("state-pending");
        } else if (stateValue == "140") {
          //state-issue : orange -> 이슈 (icon)
          $(target).addClass("state-issue");
        } else if (
          stateValue == "120" ||
          stateValue == "150" ||
          stateValue == "170" ||
          stateValue == "210" ||
          stateValue == "141" ||
          stateValue == "151"
        ) {
          //state-inprogress : blue -> ~중
          $(target).addClass("state-inprogress");
        } else if (
          stateValue == "220" ||
          stateValue == "320" ||
          stateValue == "340" ||
          stateValue == "360" ||
          stateValue == "380" ||
          stateValue == "400" ||
          stateValue == "420" ||
          stateValue == "440" ||
          stateValue == "460" ||
          stateValue == "480" ||
          stateValue == "820" ||
          stateValue == "840" ||
          stateValue == "860"
        ) {
          //state-reject : red -> 반려
          $(target).addClass("state-reject");
        } else if (
          stateValue == "130" ||
          stateValue == "160" ||
          stateValue == "310" ||
          stateValue == "330" ||
          stateValue == "350" ||
          stateValue == "370" ||
          stateValue == "390" ||
          stateValue == "410" ||
          stateValue == "430" ||
          stateValue == "450" ||
          stateValue == "470" ||
          stateValue == "710" ||
          stateValue == "810" ||
          stateValue == "830" ||
          stateValue == "850" ||
          stateValue == "161"
        ) {
          //state-confirm : green -> 완료
          $(target).addClass("state-confirm");
        }
      }

      return ret;
    },
  };

  //첨부파일
  module.FILE = {
    /**
     * 멀티파일 데이터 가져오기
     * @example var ret = FILE.bind(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} fgrp_sq : 파일그룹순번
     * @return {*} boolean
     */
    bind: function (ctrl, fgrp_sq) {
      var ret = false;

      if (!fgrp_sq) {
        if (ctrl.options.dataSource._data) {
          for (var i = ctrl.options.dataSource._data.length; i > 0; i--) {
            ctrl.deleteMultiFile(i - 1);
          }
        }
      } else {
        dews.api
          .get(
            dews.url.getApiUrl("IA", "IACommonService", "ia_common_file_list"),
            {
              async: false,
              data: {
                fgrp_sq: fgrp_sq,
              },
            }
          )
          .done(function (data) {
            if (data) {
              ret = true;

              var filelist = dews.ui.dataSource("filelist", { data: data });
              ctrl.setDataSource(filelist);
              filelist.read();
            }
          });
      }
      return ret;
    },

    /**
     * 생성일 : 2020.07.01 생성자 : 전상만
     * 멀티파일 데이터 가져오기
     * @example var ret = FILE.bind_multi(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} fgrp_sq_pipe : 파일그룹순번리스트(파이프)
     * @return {*} boolean
     */
    bind_multi: function (ctrl, fgrp_sq_pipe) {
      var ret = false;

      if (!fgrp_sq_pipe) {
        if (ctrl.options.dataSource._data) {
          for (var i = ctrl.options.dataSource._data.length; i > 0; i--) {
            ctrl.deleteMultiFile(i - 1);
          }
        }
      } else {
        dews.api
          .get(
            dews.url.getApiUrl(
              "IA",
              "IACommonService",
              "ia_common_file_multi_list"
            ),
            {
              async: false,
              data: {
                fgrp_sq_pipe: fgrp_sq_pipe,
              },
            }
          )
          .done(function (data) {
            if (data) {
              ret = true;

              var filelist = dews.ui.dataSource("filelist", { data: data });
              ctrl.setDataSource(filelist);
              filelist.read();
            }
          });
      }
      return ret;
    },

    /**
	   * 생성일 : 2022.05.06 생성자 : 서천석
     * 회사구분 멀티파일 데이터 가져오기
     * @example var ret = FILE.bind_multi_company(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} fgrp_sq_pipe : 파일그룹순번리스트(파이프)
     * @return {*} boolean
     */
     bind_multi_company: function(ctrl, fgrp_sq_pipe, company_cd) {
      var ret = false;

      if (!fgrp_sq_pipe) {
        if (ctrl.options.dataSource._data) {
          for (var i = ctrl.options.dataSource._data.length; i > 0; i--) {
            ctrl.deleteMultiFile(i - 1);
          }
        }
      }
      else {
        dews.api.get(dews.url.getApiUrl("IA", "IACommonService", "ia_common_file_multi_list_company"), {
          async: false,
          data: {
            fgrp_sq_pipe: fgrp_sq_pipe,
            company_cd: company_cd
          }
        }).done(function (data) {
          if (data) {
            ret = true;
            var filelist = dews.ui.dataSource('filelist', { data: data });
            ctrl.setDataSource(filelist);
            filelist.read();
          }
        });
      }
      return ret;
    },
    /**
     * 멀티파일 데이터 저장하기
     * @example var ret = FILE.upload(1, fileInfo);
     * @param {*} fgrp_sq : 파일그룹순번
     * @param {*} fileInfo : 파일정보
     * @return {*} boolean
     */
    upload: function (fgrp_sq, fileInfo) {
      var ret = null;

      if (!fgrp_sq) {
        fgrp_sq = "";
      }
      dews.api
        .post(
          dews.url.getApiUrl("IA", "IACommonService", "ia_common_file_upload"),
          {
            async: false,
            data: {
              fgrp_sq: fgrp_sq,
              fileInfo: JSON.stringify(fileInfo),
            },
          }
        )
        .done(function (data) {
          ret = data;
        });

      return ret;
    },

    /**
     * 멀티파일 데이터 식제
     * @example var ret = FILE.delete(1, '1|2|');
     * @param {*} fgrp_sq : 파일그룹순번
     * @param {*} file_sq_pipe : 파일순번(파이프)
     * @return {*} boolean
     */
    delete: function (fgrp_sq, fileInfo) {
      var ret = false;

      if (fgrp_sq) {
        dews.api
          .post(
            dews.url.getApiUrl(
              "IA",
              "IACommonService",
              "ia_common_file_delete"
            ),
            {
              async: false,
              data: {
                fgrp_sq: fgrp_sq,
                fileInfo: JSON.stringify(fileInfo),
              },
            }
          )
          .done(function (data) {
            ret = true;
          });
      }

      return ret;
    },

    /**
     * Single파일 데이터 가져오기
     * @example var ret = FILE.get(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} fgrp_sq : 파일그룹순번
     * @return {*} boolean
     */
    bindSingle: function (ctrl, fgrp_sq) {
      var ret = false;

      if (!fgrp_sq) {
        ctrl.deleteFile(); //체인지 이벤 발생 안함
      } else {
        dews.api
          .get(
            dews.url.getApiUrl("IA", "IACommonService", "ia_common_file_list"),
            {
              async: false,
              data: {
                fgrp_sq: fgrp_sq,
              },
            }
          )
          .done(function (data) {
            if (data) {
              ret = true;

              // 파일 정보
              if (data.length > 0) {
                var fileInfo = {
                  fileKey: data[0]["NEW_FILE_DC"],
                  filename: data[0]["FILE_NM"],
                  extension: data[0]["ORGL_FEXTSN_DC"],
                  size: data[0]["FILE_VR"],
                };
                ctrl.setFile(fileInfo);
              } else {
                ctrl.deleteFile();
              }
            }
          });
      }
      return ret;
    },

    /**
     * 멀티파일 데이터 가져오기
     * @example var ret = FILE.bind(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} mvot_fg : 구분 (1.평가주기, 2.스코핑)
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} fgrp_sq : 파일그룹순번
     * @return {*} boolean
     */
    bind_pr: function (ctrl, mvot_fg, eval_prid_sq, fgrp_sq) {
      var ret = false;

      if (!fgrp_sq) {
        if (ctrl.options.dataSource._data) {
          for (var i = ctrl.options.dataSource._data.length; i > 0; i--) {
            ctrl.deleteMultiFile(i - 1);
          }
        }
      } else {
        dews.api
          .get(
            dews.url.getApiUrl(
              "IA",
              "IACommonService",
              "ia_common_file_list_pr"
            ),
            {
              async: false,
              data: {
                mvot_fg: mvot_fg,
                eval_prid_sq: eval_prid_sq,
                fgrp_sq: fgrp_sq,
              },
            }
          )
          .done(function (data) {
            if (data) {
              ret = true;

              var filelist = dews.ui.dataSource("filelist", { data: data });
              ctrl.setDataSource(filelist);
              filelist.read();
            }
          });
      }
      return ret;
    },

    /**
     * 멀티파일 데이터 가져오기
     * 생성일 : 2020.07.01 생성자 : 전상만
     * @example var ret = FILE.bind_pr_multi(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} mvot_fg : 구분 (1.평가주기, 2.스코핑)
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} fgrp_sq_pipe : 파일그룹순번리스트(파이프)
     * @return {*} boolean
     */
    bind_pr_multi: function (ctrl, mvot_fg, eval_prid_sq, fgrp_sq_pipe) {
      var ret = false;

      if (!fgrp_sq_pipe) {
        if (ctrl.options.dataSource._data) {
          for (var i = ctrl.options.dataSource._data.length; i > 0; i--) {
            ctrl.deleteMultiFile(i - 1);
          }
        }
      } else {
        dews.api
          .get(
            dews.url.getApiUrl(
              "IA",
              "IACommonService",
              "ia_common_file_list_multi_pr"
            ),
            {
              async: false,
              data: {
                mvot_fg: mvot_fg,
                eval_prid_sq: eval_prid_sq,
                fgrp_sq_pipe: fgrp_sq_pipe,
              },
            }
          )
          .done(function (data) {
            if (data) {
              ret = true;

              var filelist = dews.ui.dataSource("filelist", { data: data });
              ctrl.setDataSource(filelist);
              filelist.read();
            }
          });
      }
      return ret;
    },

    /**
     * 멀티파일 데이터 저장하기
     * @example var ret = FILE.upload(1, fileInfo);
     * @param {*} mvot_fg : 구분 (1.평가주기, 2.스코핑)
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} fgrp_sq : 파일그룹순번
     * @param {*} fileInfo : 파일정보
     * @return {*} boolean
     */
    upload_pr: function (mvot_fg, eval_prid_sq, fgrp_sq, fileInfo) {
      var ret = null;

      if (!fgrp_sq) {
        fgrp_sq = "";
      }
      dews.api
        .post(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_file_upload_pr"
          ),
          {
            async: false,
            data: {
              mvot_fg: mvot_fg,
              eval_prid_sq: eval_prid_sq,
              fgrp_sq: fgrp_sq,
              fileInfo: JSON.stringify(fileInfo),
            },
          }
        )
        .done(function (data) {
          ret = data;
        });

      return ret;
    },

    /**
     * 멀티파일 데이터 식제
     * @example var ret = FILE.delete(1, '1|2|');
     * @param {*} mvot_fg : 구분 (1.평가주기, 2.스코핑)
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} fgrp_sq : 파일그룹순번
     * @param {*} file_sq_pipe : 파일순번(파이프)
     * @return {*} boolean
     */
    delete_pr: function (mvot_fg, eval_prid_sq, fgrp_sq, fileInfo) {
      var ret = false;

      if (fgrp_sq) {
        dews.api
          .post(
            dews.url.getApiUrl(
              "IA",
              "IACommonService",
              "ia_common_file_delete_pr"
            ),
            {
              async: false,
              data: {
                mvot_fg: mvot_fg,
                eval_prid_sq: eval_prid_sq,
                fgrp_sq: fgrp_sq,
                fileInfo: JSON.stringify(fileInfo),
              },
            }
          )
          .done(function (data) {
            ret = true;
          });
      }

      return ret;
    },

    /**
     * Single파일 데이터 가져오기
     * @example var ret = FILE.get(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} mvot_fg : 구분 (1.평가주기, 2.스코핑)
     * @param {*} eval_prid_sq : 평가주기
     * @param {*} fgrp_sq : 파일그룹순번
     * @return {*} boolean
     */
    bindSingle_pr: function (ctrl, mvot_fg, eval_prid_sq, fgrp_sq) {
      var ret = false;

      if (!fgrp_sq) {
        ctrl.deleteFile(); //체인지 이벤 발생 안함
      } else {
        dews.api
          .get(
            dews.url.getApiUrl(
              "IA",
              "IACommonService",
              "ia_common_file_list_pr"
            ),
            {
              async: false,
              data: {
                mvot_fg: mvot_fg,
                eval_prid_sq: eval_prid_sq,
                fgrp_sq: fgrp_sq,
              },
            }
          )
          .done(function (data) {
            if (data) {
              ret = true;

              // 파일 정보
              if (data.length > 0) {
                var fileInfo = {
                  fileKey: data[0]["NEW_FILE_DC"],
                  filename: data[0]["FILE_NM"],
                  extension: data[0]["ORGL_FEXTSN_DC"],
                  size: data[0]["FILE_VR"],
                };
                ctrl.setFile(fileInfo);
              } else {
                ctrl.deleteFile();
              }
            }
          });
      }
      return ret;
    },

    /**
     * 회사의 미비점평가 템플릿을 가져옵니다
     * @example FILE.dfevTemplate();
     * @return {*} object : 상태코드, 명 (성공), false (실패)
     */
    dfevTemplate: function () {
      var ret = false;
      dews.api
        .get(
          dews.url.getApiUrl(
            "IA",
            "IACommonService",
            "ia_common_file_dfevtemplate"
          ),
          {
            async: false,
          }
        )
        .done(function (data) {
          if (data) {
            ret = data;
          }
        });
      return ret;
    },
  };
  //---------End

  // 메일
  module.Mail = {
    /**
     * 메일 보내기
     * @example var ret = Mail.send("MAIL0401", {evrpt_sq: self.evrpt_sq.code(), ....} );
     * @param {*} mailKey : 파일그룹순번
     * @param {*} param : 파라미터 객체
     * @return {*} boolean
     */
    send: function (mailKey, param) {
      var ret = false;
      dews.api
        .post(dews.url.getApiUrl("IA", "IAMailService", "ia_mail_send"), {
          async: true,
          data: {
            mailKey: mailKey,
            param: JSON.stringify(param),
          },
        })
        .done(function (data) {
          if (data) {
            ret = true;
          }
        });
      return ret;
    },
  };
  //---------End

  //첨부파일
  module.XLS = {
    XlsUtil: function () {
      return {
        self: {},
        verifyUrl: null,
        saveUrl: null,
        xlsParam: {},
        initData: function (self) {
          var pself = this;
          pself.self = self;

          var html = '<li class="ia_common_file_class" style="display: none;">';
          html +=
            '<span><input id="ia_common_file" type="file" class="dews-ui-file"></span>';
          html += "</li>";

          self.$content.append(html);
          setTimeout(function (e) {
            $(".ia_common_file_class", self.$content).trigger("inituicontrols");
            var $file = self.$content.find("#ia_common_file");
            self.ia_common_file = dews.ui.file($file);
          }, 100);

          $(document).unbind("keydown.ia_xls");

          $(document).bind("keydown.ia_xls", function (e) {
            if (e.altKey && e.shiftKey && e.ctrlKey && event.keyCode == 68) {
              if (dews.ui.page.menu.module == "IA") {
                //xlsErrorView(dews.ui.page.menu.id); //메뉴id 또는 메뉴id + 키구분값
                var inputData = {
                  title: dews.localize.get("오류 내역", 'D0085502', dews.localize.language(), "ITAOTS00100"),
                  menu_id: dews.ui.page.menu.id,
                };

                var dialog = dews.ui
                  .dialog("H_IA_MENUXLS_ERROR_V", {
                    url: "~/codehelp/IA/H_IA_MENUXLS_ERROR_V",
                    width: 1002,
                    height: 455,
                    initData: inputData,
                    ok: function (data) {
                      //skip
                    },
                  })
                  .open();
              }
            }
          });
        },
        initUpData: function (initData) {
          var pself = this;

          if (initData) {
            pself.verifyUrl = initData.verifyUrl;
            pself.saveUrl = initData.saveUrl;
            pself.xlsParam = initData.params;
            pself.verify = initData.verify;
            pself.msg = initData.msg;
          }
        },
        xlsuploadVerifyParam: {},
        xlsuploadSaveParam: {},
        initUpDataChange: function (uploadInfo) {
          var pself = this;

          if (uploadInfo) {
            pself.verifyUrl = uploadInfo.verifyUrl;
            pself.saveUrl = uploadInfo.saveUrl;
            pself.xlsParam = uploadInfo.params;
            pself.xlsuploadVerifyParam =
              uploadInfo.uploadVerifyParam == null
                ? {}
                : uploadInfo.uploadVerifyParam;
            pself.xlsuploadSaveParam =
              uploadInfo.uploadSaveParam == null
                ? {}
                : uploadInfo.uploadSaveParam;
          }
        },
        downloadUrl: null,
        xlsdownloadParam: {},
        xlsdownloadCols: {},
        xlsdownloadTitles: {},
        initDownData: function (downloadInfo) {
          var pself = this;

          if (downloadInfo) {
            pself.downloadUrl = downloadInfo.downloadUrl;
            pself.xlsdownloadParam =
              downloadInfo.downloadParam == null
                ? {}
                : downloadInfo.downloadParam;
            pself.xlsdownloadCols = downloadInfo.colList;
            pself.xlsdownloadTitles = downloadInfo.titleList;
          }
        },
        upload: function (title, is_exists_check) {
          //2022.01.20 is_exists_check와 관련 로직 추가
          //엑셀업로드

          var pself = this;
          var ret = false;

          var dialog_width;

          if(arguments.length == 1){ //is_exists_check 없음
            is_exists_check = false; //default: false(기존데이터 삭제 checkbox 표시X)
          }

          if(is_exists_check == true){
            dialog_width = 505;
          }else{
            dialog_width = 430;
            is_exists_check = false;
          }

          var inputData = {
            title: title,
            is_exists_check : is_exists_check,
            verify: pself.verify,
            msg: pself.msg
          };

          return new Promise(function (resolve, reject) {
            var dialog = dews.ui.dialog("H_IA_MENUXLS_LOAD_C", {
              url: "~/codehelp/IA/H_IA_MENUXLS_LOAD_C",
              width: dialog_width,
              height: 262,
              initData: inputData,
              ok: function (data) {
                //데이터 처리
                if (data) {
                  dews.ui.loading.show({
                    type: "tiny",
                    text: dews.localize.get("엑셀 데이터를 업로드 하고 있습니다.", 'M0019626', dews.localize.language(), "ITAOTS00100"),
                  });

                  setTimeout(function (e) {
                    var errList = pself.XlsUpload(data.FILEKEY);
                    if (errList) {
                      if (errList.length > 0) {
                        dews.ui.loading.hide();

                        //error 창 오픈
                        if (
                          errList[0]["COL_NO"] == "" &&
                          errList[0]["ROW_NO"] == ""
                        ) {
                          //에러메시지 오픈
                          dews.alert(errList[0]["ERROR_MESSAGE"], "error");
                        } else {
                          //오류를 팝업창으로 리턴
                          setTimeout(function (e) {
                            pself.viewErrorPop(errList);
                          }, 100);
                        }
                      } else {
                        //검증쿼리 실행후 판단
                        var verify_param = {};
                        if (!pself.xlsuploadVerifyParam.menu_id) {
                          verify_param = {
                            menu_id: pself.xlsParam.menu_id,
                            file_sq: pself.xlsParam.file_sq,
                          };
                        } else {
                          verify_param = pself.xlsuploadVerifyParam;
                        }

                        dews.api
                          .get(pself.verifyUrl, {
                            async: false,
                            data: verify_param,
                          })
                          .done(function (verifyData) {
                            //에러가 없으면 저장, 에러가 있으면 팝업창
                            if (verifyData.length > 0) {
                              dews.ui.loading.hide();

                              setTimeout(function (e) {
                                pself.viewErrorPop(verifyData);
                              }, 100);
                            } else {
                              if(is_exists_check){
                                if (pself.saveData_chk(data.IS_CHECKED)) {
                                  resolve(true);
                                }
                              }else{
                                if (pself.saveData()) {
                                  resolve(true);
                                }
                              }
                            }
                          })
                          .fail(function (xhr, status, error) {
                            //로직 및 쿼리 오류
                            dews.ui.loading.hide();
                            dews.alert(dews.localize.get("검증쿼리 오류입니다.", 'M0107849', dews.localize.language(), "ITAOTS00100"), "error");
                          });
                      }
                    } else {
                      dews.ui.loading.hide();
                      dews.alert(
                        dews.localize.get("Excel 파일로 저장 후 업로드 하시기 바랍니니다.", 'M0107850', dews.localize.language(), "ITAOTS00100"),
                        "error"
                      );
                    }
                  }, 100);
                }
              },
            });

            dialog.open();
          });
        },
        XlsUpload: function (fileKey) {
          var pself = this;
          var errList = null;

          var parameters = {
            fileKey: fileKey, //파일패스
            menu_id: pself.xlsParam.menu_id, //메뉴id
            file_sq: pself.xlsParam.file_sq, //파일순번
            col_cnt: pself.xlsParam.col_cnt, //양식컬럼수
            col_clob_no: pself.xlsParam.col_clob_no, //clob컬럼번호
            col_no: pself.xlsParam.col_no, //시작 col 번호
            row_no: pself.xlsParam.row_no, //시작 row 번호
          };

          dews.api
            .post(
              dews.url.getApiUrl(
                "IA",
                "IACommonService",
                "ia_common_xls_upload"
              ),
              {
                async: false,
                data: parameters,
              }
            )
            .done(function (data) {
              //성공 (엑셀업로드 성공, 엑셀업로드 오류)
              errList = data;
            })
            .fail(function (xhr, status, error) {
              //로직 및 쿼리 오류
            });

          return errList;
        },
        viewErrorPop: function (errList) {
          var inputData = {
            title: dews.localize.get("오류 리스트", 'D0110113', dews.localize.language(), "ITAOTS00100"),
            ERROR: errList,
          };

          var dialog = dews.ui
            .dialog("H_IA_MENUXLS_ERROR_C", {
              url: "~/codehelp/IA/H_IA_MENUXLS_ERROR_C",
              width: 800,
              height: 450,
              initData: inputData,
              ok: function (data) {
                //skip
              },
            })
            .open();
        },
        saveData: function () {
          //데이터 저장
          var pself = this;
          var ret = false;

          var save_param = {};
          if (!pself.xlsuploadSaveParam.menu_id) {
            save_param = {
              menu_id: pself.xlsParam.menu_id,
              file_sq: pself.xlsParam.file_sq,
            };
          } else {
            save_param = pself.xlsuploadSaveParam;
          }

          dews.api
            .post(pself.saveUrl, {
              async: false,
              data: save_param,
            })
            .done(function (data) {
              //재조회
              ret = true;

              dews.ui.loading.hide();
            })
            .fail(function (xhr, status, error) {
              //로직 및 쿼리 오류
              dews.ui.loading.hide();
              dews.alert(dews.localize.get("저장쿼리 오류입니다.", 'M0107851', dews.localize.language(), "ITAOTS00100"), "error");
            });

          return ret;
        },
        saveData_chk: function (is_checked) {
          //데이터 저장
          var pself = this;
          var ret = false;

          var save_param = {};
          if (!pself.xlsuploadSaveParam.menu_id) {
            save_param = {
              menu_id: pself.xlsParam.menu_id,
              file_sq: pself.xlsParam.file_sq,
            };
          } else {
            pself.xlsuploadSaveParam["is_checked"] = is_checked; //check 추가
            save_param = pself.xlsuploadSaveParam;
          }

          dews.api
            .post(pself.saveUrl, {
              async: false,
              data: save_param,
            })
            .done(function (data) {
              //재조회
              ret = true;

              dews.ui.loading.hide();
            })
            .fail(function (xhr, status, error) {
              //로직 및 쿼리 오류
              dews.ui.loading.hide();
              dews.alert(dews.localize.get("저장쿼리 오류입니다.", 'M0107851', dews.localize.language(), "ITAOTS00100"), "error");
            });

          return ret;
        },
        download: function (title, text, downloadInfo) {
          //엑셀다운로드
          var pself = this;
          var ret = false;

          var inputData = {
            title: title,
            text: text,
            downloadInfo: downloadInfo,
          };

          return new Promise(function (resolve, reject) {
            var dialog = dews.ui.dialog("H_IA_MENUXLS_DOWN_C", {
              url: "~/codehelp/IA/H_IA_MENUXLS_DOWN_C",
              width: 425,
              height: 220,
              initData: inputData,
              ok: function (data) {
                //데이터 처리
                if (data) {
                  dews.ui.loading.show({
                    type: "tiny",
                    text: dews.localize.get("데이터를 다운로드 하고 있습니다.", 'M0018722', dews.localize.language(), "ITAOTS00100"),
                  });

                  setTimeout(function (e) {
                    //다운로드 로직
                    if (
                      title == dews.localize.get("업무수준CM 다운로드", 'D0021590', dews.localize.language(), "ITAOTS00100") ||
                      title == dews.localize.get("전사수준CM 다운로드", 'D0021559', dews.localize.language(), "ITAOTS00100") ||
                      title == dews.localize.get("CM계정매핑 다운로드", 'D0021620', dews.localize.language(), "ITAOTS00100") ||
                      title == "Download CM at companywide level" ||
                      title == "Download job level CM" ||
                      title == "Download CM account mapping"
                    ) {
                      if (pself.XlsDownload_CM(data.FILENAME)) {
                        resolve(true);
                      }
                    } else if (
                      title == dews.localize.get("업무수준CM이력 다운로드", 'D0078281', dews.localize.language(), "ITAOTS00100") ||
                      title == "Job Level CM History Download" ||
                      title == dews.localize.get("전사수준이력CM 다운로드", 'D0110114', dews.localize.language(), "ITAOTS00100") ||
                      title === dews.localize.get("사원 다운로드", 'D0010045', dews.localize.language(), "ITAOTS00100") ||
                      title === "Download employee" ||  //khkim
                      title === dews.localize.get("중요한 계정과목 선정 / 경영자 주장 식별", 'D0010251', dews.localize.language(), "ITAOTS00100") ||
                      title === "Selection of significant COA / management assertion identification" ||
                      title === dews.localize.get("중요한 주석정보", 'D0010255', dews.localize.language(), "ITAOTS00100") ||
                      title === "Info on significant footnote"
                    ) {
                      if (pself.PRXlsDownload_CM(data.FILENAME, downloadInfo)) {
                        resolve(true);
                      }
                    } else {
                      if (pself.XlsDownload(data.FILENAME)) {
                        resolve(true);
                      }
                    }

                    dews.ui.loading.hide();
                  }, 100);
                }
              },
            });

            dialog.open();
          });

          return ret;
        },
        XlsDownload: function (fileName) {
          var pself = this;
          var ret = false;

          dews.api
            .get(pself.downloadUrl, {
              async: false,
              data: pself.xlsdownloadParam,
            })
            .done(function (data) {
              if (data) {
                dews.api
                  .post(
                    dews.url.getApiUrl(
                      "IA",
                      "IACommonService",
                      "ia_common_xls_download"
                    ),
                    {
                      async: false,
                      data: {
                        dataList: JSON.stringify(data),
                        colList: JSON.stringify(pself.xlsdownloadCols),
                        titleList: JSON.stringify(pself.xlsdownloadTitles),
                        fileName: fileName,
                      },
                    }
                  )
                  .done(function (data) {
                    //성공(엑셀 다운로드)

                    var fileInfo = {
                      fileKey: data.newFilename,
                      filename: data.originalFilename,
                      extension: data.originalExtension,
                      size: data.fileSize,
                      isNew: true,
                    };

                    pself.self["ia_common_file"].setFile(fileInfo);
                    pself.self.$content
                      .find(".ia_common_file_class #ia_common_file")
                      .closest(".dews-file-wrap")
                      .find(".dews-file-button.icon-download")
                      .click();

                    ret = true;
                  })
                  .fail(function (xhr, status, error) {
                    //로직 및 쿼리 오류
                    dews.alert(dews.localize.get("다운로드 오류입니다.", 'M0018723', dews.localize.language(), "ITAOTS00100"), "error");
                  });
              } else {
                dews.alert(dews.localize.get("다운로드 쿼리 오류입니다.", 'M0107852', dews.localize.language(), "ITAOTS00100"), "error");
              }
            })
            .fail(function (xhr, status, error) {
              dews.alert(dews.localize.get("다운로드 데이터 조회 오류입니다.", 'M0107853', dews.localize.language(), "ITAOTS00100"), "error");
            });

          return ret;
        },
        XlsDownload_CM: function (fileName) {
          var pself = this;
          var ret = false;

          var param = {
            use1_yn: pself.xlsdownloadParam.use1_yn,
            use4_yn: pself.xlsdownloadParam.use4_yn,
            colList: JSON.stringify(pself.xlsdownloadCols),
            titleList: JSON.stringify(pself.xlsdownloadTitles),
            fileName: fileName,
          };

          dews.api
            .post(pself.downloadUrl, {
              async: false,
              data: param,
            })
            .done(function (data) {
              if (data) {
                //성공(엑셀 다운로드)
                var fileInfo = {
                  fileKey: data.newFilename,
                  filename: data.originalFilename,
                  extension: data.originalExtension,
                  size: data.fileSize,
                  isNew: true,
                };

                pself.self["ia_common_file"].setFile(fileInfo);
                pself.self.$content
                  .find(".ia_common_file_class #ia_common_file")
                  .closest(".dews-file-wrap")
                  .find(".dews-file-button.icon-download")
                  .click();

                ret = true;
              } else {
                dews.alert(dews.localize.get("다운로드 오류입니다.", 'M0018723', dews.localize.language(), "ITAOTS00100"), "error");
              }
            })
            .fail(function (xhr, status, error) {
              dews.alert(dews.localize.get("다운로드 데이터 조회 오류입니다.", 'M0107853', dews.localize.language(), "ITAOTS00100"), "error");
            });

          return ret;
        },
        PRXlsDownload_CM: function (fileName, downloadInfo) {
          var pself = this;
          var ret = false;
          if (downloadInfo.downloadParam.company_cd != undefined) {
            var param = {
              use1_yn: pself.xlsdownloadParam.use1_yn,
              use4_yn: pself.xlsdownloadParam.use4_yn,
              colList: JSON.stringify(pself.xlsdownloadCols),
              titleList: JSON.stringify(pself.xlsdownloadTitles),
              fileName: fileName,
              eval_prid_sq: downloadInfo.downloadParam.eval_prid_sq,
              mvot_fg: downloadInfo.downloadParam.mvot_fg,
              company_cd : downloadInfo.downloadParam.company_cd
            };
          } else{
            var param = {
              use1_yn: pself.xlsdownloadParam.use1_yn,
              use4_yn: pself.xlsdownloadParam.use4_yn,
              colList: JSON.stringify(pself.xlsdownloadCols),
              titleList: JSON.stringify(pself.xlsdownloadTitles),
              fileName: fileName,
              eval_prid_sq: downloadInfo.downloadParam.eval_prid_sq,
              mvot_fg: downloadInfo.downloadParam.mvot_fg
            };
          }

          if (downloadInfo.downloadParam.scop_prid_sq != undefined) {
            param = {
              scop_prid_sq: downloadInfo.downloadParam.scop_prid_sq,
              scop_his_sq: downloadInfo.downloadParam.scop_his_sq,
            };
          }

          dews.api
            .post(pself.downloadUrl, {
              async: false,
              data: param,
            })
            .done(function (data) {
              if (data) {
                //성공(엑셀 다운로드)
                var fileInfo = {
                  fileKey: data.newFilename,
                  filename: data.originalFilename,
                  extension: data.originalExtension,
                  size: data.fileSize,
                  isNew: true,
                };

                pself.self["ia_common_file"].setFile(fileInfo);
                pself.self.$content
                  .find(".ia_common_file_class #ia_common_file")
                  .closest(".dews-file-wrap")
                  .find(".dews-file-button.icon-download")
                  .click();

                ret = true;
              } else {
                dews.alert(dews.localize.get("다운로드 오류입니다.", 'M0018723', dews.localize.language(), "ITAOTS00100"), "error");
              }
            })
            .fail(function (xhr, status, error) {
              dews.alert(dews.localize.get("다운로드 데이터 조회 오류입니다.", 'M0107853', dews.localize.language(), "ITAOTS00100"), "error");
            });

          return ret;
        },
      };
    },
  };

  module.PRINT = {
    /**
     * 인쇄 호출.
     * @argument {String} reportId         : RPRT_CD 값 (ex.  "R_MLEMIA00400_0")
     * @argument {List} parameters params  : RPRT_CD, OBJECT_CD, PARA_CD, PARA_TXT
     */
    invoke: function (self, reportId, params) {
      /* 파라미터 저장 요청 */
      dews.api
        .post(dews.url.getApiUrl("CM", "printService", "setPrintParam"), {
          async: false,
          data: {
            reportCode: reportId,
            items: JSON.stringify(params),
          },
        })
        .done(function (data) {
          /* 파라미터 키 리턴 */
          var parameterKey = data;

          if (parameterKey != "" && parameterKey != null) {
            /* 인증토큰 */
            var authToken = JSON.parse(self.token).access_token;

            /* 출력물 정보 */
            var reportInfoUrl =
              window.location.protocol +
              "//" +
              window.location.host +
              dews.url.getApiUrl("CM", "printService", "getPrintFormList");

            /* DERPViewer 호출 */
            location.href =
              'GERP://" "' +
              authToken +
              '" "' +
              reportId +
              '" "' +
              reportInfoUrl +
              '" "' +
              parameterKey +
              '" "' +
              (self.menu || {}).id;
          }
        });
    },
  };


  module.DRS = {
    get: function() {
      return dews.ui.page.mainEnv.drsCode;
    }
  };

  module.GW = {
    open: function (e) {
      var url = "";
      if (module.DRS.get() == "10097") {
        //대유에이텍
        //url = e.row.data.GW_READ_URL + e.row.data.GW_DOC_KEY_CD;
        //메뉴 곳곳에 백단 작업을 해놨음...아래내용처럼...다수정해야함.
        //아래는 임시방편
        url =
          e.row.data.GW_READ_URL.substring(
            0,
            e.row.data.GW_READ_URL.indexOf("legacyKey=") + 10
          ) + e.row.data.GW_DOC_KEY_CD;
      } else if (module.DRS.get() == "10062") {
          // } else if (module.DRS.get() == "x0001") {
        //한국가스기술공사
        return {
          self: {},
          gwdocu_fgrp_sq: "",
          // dept_cd: "",
          emp_cd: "",
          exclude_yn: "Y",
          count: 1,
          evt: null,
          czgb: null,
          mode: "U",
          bg_delete:
            "background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAOCAYAAAD0f5bSAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjlBNDU3QTQ4MUE5MDExRTg5MjRGRUQwNEZENjBGQzI3IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjlBNDU3QTQ5MUE5MDExRTg5MjRGRUQwNEZENjBGQzI3Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OUE0NTdBNDYxQTkwMTFFODkyNEZFRDA0RkQ2MEZDMjciIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OUE0NTdBNDcxQTkwMTFFODkyNEZFRDA0RkQ2MEZDMjciLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5Nf8oQAAAAQklEQVR42mJkwATFQKyGxL8OxBMYCICZBPgMjNgEiQUzSVHHRI4NTHhsnYnLFVSzaahrol88sUDp20TadgNEAAQYANXzCl0mUjPUAAAAAElFTkSuQmCC) no-repeat 50%;",
          bg_download:
            "background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozNzU4QTYyMjNBMjA2ODExODIyQUU2QzQ2QjIzOEVDRiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDowM0QwOUZEQUM4MUMxMUU3QTBCMkExRjhDMDk3NEY2NiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDowM0QwOUZEOUM4MUMxMUU3QTBCMkExRjhDMDk3NEY2NiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RkE0Rjc3NzM0QjIwNjgxMTgyMkFFNkM0NkIyMzhFQ0YiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Mzc1OEE2MjIzQTIwNjgxMTgyMkFFNkM0NkIyMzhFQ0YiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4h8CFRAAAAkUlEQVR42mLcuXPnfwbC4AMQu7q5uZ1Bl2AEGeDs7IxT5969exlkZGQYnjx58hHIdUE3hIkI2xmEhIRAhvADmXt27dplSrIBf//+ZeDn52eQlZUFGbIbWY6FCP3vr169iswXJMkAYPgIoocJyV7AB1Bc0HTpB06FdXochA3ApWjUBfgBxdFInXSAnrpIAQABBgB4xi4LZIQXqwAAAABJRU5ErkJggg==) no-repeat 50%;",
          init: function (self, ctrlclass, itemcount, mode) {
            var my = this;
            my.self = self;

            if (ctrlclass) {
              my.class = ctrlclass;
            }

            //init
            //<button type='button' class='dews-ui-button ico-search ico-search-au'></button> \
            var gwfiletag =
              " \
            <div class='dews-ui-gwfile' data-dews-width='100%' data-dews-height='100%' style='min-width: 200px;'> \
              <div class='dews-gwfile-head'> \
                <div class='dews-button-group'> \
                  <input type='checkbox' class='dews-ui-checkbox dews-ui-gwfile-check'> \
                  <label class='dews-ui-title dews-ui-gwfile-title'>{mode_title}</label> \
                  <button type='button' class='dews-ui-button ico-add' {mode}></button> \
                  <button type='button' class='dews-ui-button ico-delete' {mode}></button> \
                </div> \
              </div> \
              <div class='dews-gwfile-contents'>	\
                <ul> \
                </ul> \
              </div> \
            </div> \
        ";

            if (mode) {
              my.mode = mode;
            }

            gwfiletag = gwfiletag.replaceAll(
              "{mode}",
              my.mode == "D" ? "style='display:none;'" : ""
            );
            gwfiletag = gwfiletag.replaceAll(
              "{mode_title}",
              my.mode == "D" ? dews.localize.get("문서목록", 'D0110115', dews.localize.language(), "ITAOTS00100") : dews.localize.get("전체선택", 'D0004755', dews.localize.language(), "ITAOTS00100")
            );

            $(my.class, self.$content).html($(gwfiletag));
            $(my.class, self.$content).trigger("inituicontrols");

            if (my.mode == "D") {
              $(my.class + " .dews-checkbox-wrapper", self.$content).prop(
                "style",
                "display:none;"
              );
            }

            if (itemcount) {
              $(my.class + " .dews-gwfile-contents", my.self.$content).prop(
                "style",
                "overflow-y:auto;height:" + (27 * itemcount).toString() + "px"
              );
            } else {
              $(my.class + " .dews-gwfile-contents", my.self.$content).prop(
                "style",
                "overflow-y:auto;height:" +
                  ($(".gwfile-td", my.self.$content).height() - 28).toString() +
                  "px"
              );
            }

            my.setBindYn(false);
            my.setCheckEabledT(false);

            $(my.class + " .dews-ui-gwfile-check", my.self.$content).change(
              function () {
                my.setChecked();
              }
            );

            //추가
            $(my.class + " .dews-ui-gwfile .ico-add", my.self.$content).click(
              function () {
                my.viewLoadPop();
              }
            );

            //삭제
            $(
              my.class + " .dews-ui-gwfile .ico-delete",
              my.self.$content
            ).click(function () {
              var $this = $(
                my.class +
                  " .dews-ui-gwfile .dews-gwfile-contents ul li .dews-ui-gwfile-check-child",
                my.self.$content
              );
              var isDelete = false;
              for (var i = $this.length - 1; i >= 0; i--) {
                if ($($this[i]).prop("checked")) {
                  isDelete = true;
                  break;
                }
              }

              if (isDelete) {
                var confirm = dews
                  .confirm(dews.localize.get("선택된 문서를 삭제하시겠습니까?", 'M0107854', dews.localize.language(), "ITAOTS00100"), "ico2")
                  .yes(function () {
                    confirm.dialog.dialog.bind("deactivate", function () {
                      for (var i = $this.length - 1; i >= 0; i--) {
                        if ($($this[i]).prop("checked")) {
                          my.deleteRow(
                            $($this[i])
                              .parent()
                              .parent()
                              .find(".APRVL_ID")
                              .text()
                          );
                          $($this[i]).parent().parent().remove();
                        }
                      }
                      my.setCheckEabledH();
                      my.event("N");
                    });
                  })
                  .no(function () {});
              } else {
                dews.alert(dews.localize.get("선택된 문서가 없습니다.", 'M0107855', dews.localize.language(), "ITAOTS00100"), "warning");
              }
            });

            //조회
            // $(my.class + ' .dews-ui-gwfile .ico-search', my.self.$content).click(function() {
            //   my.bind(1);
            // });

            //customEvent
            my.evt = jQuery.Event("gwChange", {
              key: my.gwdocu_fgrp_sq,
              // dept_cd: my.dept_cd,
              emp_cd: my.emp_cd,
            });
          },
          setBindYn: function (value) {
            var my = this;
            if (!value) {
              $(my.class + " .dews-ui-gwfile .dews-gwfile-head .dews-ui-button", my.self.$content).addClass("k-state-disabled");
              $(my.class + " .dews-ui-gwfile .dews-gwfile-head .dews-ui-button", my.self.$content).prop("disabled", true);
            } else {
              $(my.class + " .dews-ui-gwfile .dews-gwfile-head .dews-ui-button", my.self.$content).removeClass("k-state-disabled");
              $(my.class + " .dews-ui-gwfile .dews-gwfile-head .dews-ui-button", my.self.$content).prop("disabled", false);
            }
          },
          bindKey: function (gwdocu_fgrp_sq) {
            var my = this;
            my.gwdocu_fgrp_sq = gwdocu_fgrp_sq;
          },
          bind: function (gwdocu_fgrp_sq, emp_cd) {
            var my = this;
            my.gwdocu_fgrp_sq = gwdocu_fgrp_sq;
            // my.dept_cd = dept_cd;
            my.emp_cd = emp_cd

            my.setBindYn(gwdocu_fgrp_sq !== undefined);

            if (gwdocu_fgrp_sq) {

              dews.api.get(dews.url.getApiUrl('AU', 'AuGWService', 'list_doc'), {
                async: false,
                data: {
                  gwdocu_fgrp_sq: my.gwdocu_fgrp_sq
                }
              }).done(function (data) {

                $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul', my.self.$content).html('');

                if (data) {
                  my.setListBind(data);
                }
              }).fail(function (xhr, status, error) {
                dews.alert(dews.localize.get("데이터 조회 오류입니다.", 'M0000921', dews.localize.language(), "ITAOTS00100"), "error");
              });
            }
            else {
              my.setListClear();
            }
          },
          viewLoadPop: function() {
            var my = this;

            var inputData = {
              gwdocu_fgrp_sq: my.gwdocu_fgrp_sq,
              exclude_yn: my.exclude_yn,
              menu_id: dews.ui.page.menu.id,
              // dept_cd: my.dept_cd,
              emp_cd: my.emp_cd,
            }

            return new Promise(function (resolve, reject) {
              var dialog = dews.ui.dialog("H_IA_GW_C", {
                url: "~/codehelp/IA/H_IA_GW_C",
                width: 1200,
                height: 535,
                title: dews.localize.get("그룹웨어문서 목록", 'D0110116', dews.localize.language(), "ITAOTS00100"),
                initData: inputData,
                ok: function (data) {

                  //데이터 처리
                  if (data) {

                    dews.ui.loading.show({
                      type: 'tiny',
                      target: my.class,
                      text: dews.localize.get('데이터를 불러오고 있습니다.', 'M0001570', dews.localize.language(), "ITAOTS00100")
                    });

                    setTimeout(function (e) {

                      if (data != null && data.length != 0) {
                        my.insertRows(data);
                        my.setListBind(data);
                        my.event('N');
                      }

                      dews.ui.loading.hide({
                        target: my.class
                      });

                    });
                  }
                }
              });

              dialog.open();
            });
          },
          athzInsertRow: function (data) {
            var my = this;

            dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'insert_doc_athz'), {
              async: false,
              data: {
                athz_rpts_cd: data,
                gwdocu_fgrp_sq: my.gwdocu_fgrp_sq
              }
            }).done(function (data) {

              if (my.gwdocu_fgrp_sq != "") {
                my.gwdocu_fgrp_sq = data;
              }

              //my.event('Y');
            }).fail(function (xhr, status, error) {
              dews.alert(dews.localize.get("데이터 추가 오류입니다.", 'M0107856', dews.localize.language(), "ITAOTS00100"), "error");
            });

            return my.gwdocu_fgrp_sq;
          },
          cleanGwDoc: function (data) {
            dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'clean_gwdoc'), {
              async: false,
              data: {
                menu_cd: data
              }
            }).done(function (data) {

            }).fail(function (xhr, status, error) {
            });
          },
          reGwDoc: function () {
            dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'reupdate_gwdoc'), {
              async: false
            }).done(function (data) {

            }).fail(function (xhr, status, error) {
            });
          },
          insertRows: function (data) {
            var my = this;

            dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'insert_doc'), {
              async: false,
              data: {
                items: JSON.stringify(data),
                gwdocu_fgrp_sq: my.gwdocu_fgrp_sq
              }
            }).done(function (data) {

              if (my.gwdocu_fgrp_sq != "") {
                my.gwdocu_fgrp_sq = data;
              }
            }).fail(function (xhr, status, error) {
              dews.alert(dews.localize.get("데이터 추가 오류입니다.", 'M0107856', dews.localize.language(), "ITAOTS00100"), "error");
            });
          },
          deleteRow: function (aprvl_id) {
            var my = this;

            dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'delete_doc'), {
              async: false,
              data: {
                gwdocu_fgrp_sq: my.gwdocu_fgrp_sq,
                aprvl_id: aprvl_id
              }
            }).done(function (data) {

            }).fail(function (xhr, status, error) {
              dews.alert(dews.localize.get("데이터 삭제 오류입니다.", 'M0107857', dews.localize.language(), "ITAOTS00100"), "error");
            });
          },
          link: function (aprvl_id, doc_no) {
            var my = this;
            if (module.DRS.get() == "10062") { //가스기술공사
              if (my.czgb == null) {
                dews.ajax.script('~/view/js/CZ/gb.common.js', {
                  once: true,
                  async: false
                }).done(function () {
                  my.czgb = gerp.CZ.GB;
                });
                if (!my.self.user) {
                  my.self.user = dews.ui.page.user;
                }
                my.czgb.initialize(my.self);
              }
              my.czgb.viewAthzDocumentByDocId(aprvl_id);
            }
            else {
              dews.alert(dews.string.format(dews.localize.get("결재번호", 'D0014432', dews.localize.language(), "ITAOTS00100")+ ": {0}, " + dews.localize.get("문서번호", 'D0012484', dews.localize.language(), "ITAOTS00100") + ": {1}", aprvl_id, doc_no));
            }
          },
          setListBind: function (data) {
            var my = this;

            $.each(data, function (i, row) {
              var addhtml = " \
                <li class style='width:100%'> \
                  <input type='checkbox' class='dews-ui-checkbox dews-ui-gwfile-check-child'> \
                  <span class='TITL_DC'>{TITL_DC}</span> \
                  <span class='DOC_NM'>[{DOC_NO}]</span> \
                  <span class='APRVL_ID' style='display:none;'>{APRVL_ID}</span> \
                  <span class='DOC_NO' style='display:none;'>{DOC_NO}</span> \
                  <span class='LINE_SQ' style='display:none;'>{LINE_SQ}</span> \
                  <button class='btn-icon download'></button> \
                  <button class='btn-icon delete'></button> \
                </li> \
              "
              addhtml = addhtml.replaceAll("{TITL_DC}", row.TITL_DC);
              addhtml = addhtml.replaceAll("{DOC_NO}", row.DOC_NO);
              addhtml = addhtml.replaceAll("{APRVL_ID}", row.APRVL_ID);
              addhtml = addhtml.replaceAll("{LINE_SQ}", row.LINE_SQ);

              $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul', my.self.$content).append($(addhtml));
              $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last', my.self.$content).trigger('inituicontrols');

              if(my.mode == "D") {
                $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .dews-checkbox-wrapper', self.$content).prop("style", "display:none;");
              }

              $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .download', my.self.$content).prop('style', my.bg_download);
              $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .delete', my.self.$content).prop('style', my.bg_delete);


              $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last span', my.self.$content).click(function(e) {
                var $this = $(this).parent().find(".dews-ui-gwfile-check-child");
                $this.prop("checked", !$this.prop("checked"));

                my.setCheckedH();
              });

              $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last span', my.self.$content).dblclick(function(e) {
                $(this).parent().find(".download").click();
              });

              $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .download', my.self.$content).click(function(e) {
                $this = $(this).parent();
                var aprvl_id = $this.find(".APRVL_ID").text();
                var doc_no = $this.find(".DOC_NO").text();
                my.link(aprvl_id, doc_no);
              });

              if (my.mode != "D") {
                $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .delete', my.self.$content).click(function(e) {
                  var $this = $(this).parent();
                  var confirm = dews.confirm(dews.localize.get("선택된 문서를 삭제하시겠습니까?", 'M0107854', dews.localize.language(), "ITAOTS00100"), "ico2").yes(function(){
                    confirm.dialog.dialog.bind('deactivate', function(){
                      my.deleteRow($this.find(".APRVL_ID").text());
                      $this.remove();
                      my.setCheckEabledH();
                      my.event('N');
                    })
                  }).no(function(){
                  });
                });
              }
              else {
                $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .delete', my.self.$content).prop("style", "display:none;")
                $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .delete', my.self.$content).removeClass('btn-icon');
              }
            });

            my.setCheckEabledH();
          },
          setListClear: function () {
            var my = this;
            $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul', my.self.$content).html('');
            my.setCheckEabledT(false);
          },
          setCheckEabledH() {
            var my = this;
            my.setCheckEabledT($(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li', my.self.$content).length != 0);
          },
          setCheckEabledT(value) { //상단 체크박스 활성화 여부
            var my = this;
            if (!value) {
              $(my.class + ' .dews-ui-gwfile-check', my.self.$content).prop("checked", "");
            }
            $(my.class + ' .dews-ui-gwfile-check', my.self.$content).prop("disabled", value ? "" : "disabled");
          },
          setCheckedH() {
            var my = this;

            var $this = $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li .dews-ui-gwfile-check-child', my.self.$content);
            var _check = 0;
            var _nocheck = 0;
            for (var i = $this.length - 1; i >= 0; i--) {
              if ($($this[i]).prop("checked")) {
                _check++;
              }
              else {
                _nocheck++;
              }
            }
            my.setCheckedT(_check != 0 && _nocheck == 0);
          },
          setCheckedT(isCheck) { //상단 체크
            var my = this;
            $(my.class + ' .dews-ui-gwfile-check', my.self.$content).prop("checked", isCheck ? "checked" : "");
          },
          setChecked() { //자식들 체크
            var my = this;
            var isCheck = $(my.class + ' .dews-ui-gwfile-check', my.self.$content).prop("checked");
            $(my.class + ' .dews-ui-gwfile-check-child', my.self.$content).prop("checked", isCheck ? "checked" : "");
          },
          event(data) {
            var my = this;
            my.count = $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li', my.self.$content).length;
            my.evt.key = my.gwdocu_fgrp_sq;
            my.evt.count = my.count;
            my.evt.athz = data;
            $(my.class, my.self.$content).trigger(my.evt);
          }
        };
      } else {
        url = e.row.data.GW_READ_URL + "?loginid=" + e.row.data.MSNGR_ID + "&appid=" + e.row.data.GW_DOC_KEY_CD;
      }

      window.open(url);
    }
  };

  //IA 멀티라인 다국어 처리
  //공통 다국어 처리
  module.LANGUAGE = {
    LanguageUtil : function() {
      return {
        self: {},
        popOpen: false,
        useCompany: true,
        col_Info_multi: [],
        col_Info: {},
        col_Param: {},
        col_Name: "",
        std_Lang: "",
        otherCOL: "",
        multiTitle: "",
        multiButton: "",
        isSession: false,
        isSeq: "",
        initPage: function (self, isSession) {
          var popself = this;
          popself.isSession = isSession;

          dews.localize
            .load(dews.localize.language(), "BASLAN00400")
            .then(function (data) {
              popself.multiTitle = dews.localize.get(
                "다국어 설정",
                "D0000898",
                dews.localize.language(),
                "BASLAN00400"
              );
            });

          popself.multiButton = "저장";
          dews.localize
            .load(dews.localize.language(), "CSBCIC00500")
            .then(function (data) {
              popself.multiButton = dews.localize.get(
                "저장",
                "D0000388",
                dews.localize.language(),
                "CSBCIC00500"
              );
            });

          if (popself.isSession) {
            std_Lang = self.user.language.toUpperCase();
          } else {
            dews.api
              .get(
                dews.url.getApiUrl(
                  "CM",
                  "MultiLanguageService",
                  "company_std_language"
                ),
                {
                  async: false,
                }
              )
              .done(function (data) {
                if (data && data.length > 0) {
                  std_Lang = data;
                }
              })
              .fail(function (xhr, status, error) {
                dews.ui.snackbar.error(error);
              });
          }

          dews.api
            .get(
              dews.url.getApiUrl("CM", "MultiLanguageService", "language_list"),
              {
                async: false,
              }
            )
            .done(function (data) {
              if (data) {
                var popupHtml = '<div class="dews-popup-panel cm-popup-multilanguage" id="popup" style="padding:0 !important">';
                popupHtml += '<div class="dews-button-group" style="background: #f1f6f9; margin-bottom:0;">';
                popupHtml += '<div style="float:left;height:calc(100% - 39px);">';
                popupHtml += '<h3 style="float: left; padding-left:15px; margin-top: 8px; text-align: left;" class="cm-title-multilanguage">' + popself.multiTitle + "</h3>";
                popupHtml += "</div>";
                popupHtml += '<button class="dews-ui-button cm-btn-multilanguage-save" style="float:right;">' + popself.multiButton + "</button>";
                popupHtml += "</div>";
                popupHtml += '<div class="dews-popup-item" style="height: 50px; padding-top:8px;">';
                popupHtml += '<div class="dews-popup-content"></div>';
                popupHtml += '<div class="cm-content-multilanguage" style="height:193px;overflow:auto;border-top:2px solid #666;">';
                var tableHtml = "";
                if (data.length > 0) {
                  tableHtml = '<table style="width: 100%;width: 100%;table-layout: fixed;border-collapse: collapse;border-spacing: 0;">';
                  tableHtml += "<colgroup>";
                  tableHtml += '<col width="20%">';
                  tableHtml += '<col width="30%">';
                  tableHtml += '<col width="20%">';
                  tableHtml += '<col width="30%">';
                  tableHtml += "</colgroup>";
                  tableHtml += "<tbody>";

                  $.each(data, function (i, it) {
                    if (i % 2 == 0) {
                      var concatHtml = '<tr style="height:40px;border-bottom: 1px solid #e1e1e1;">';
                      concatHtml += '<th style="padding: 6px 9px;color: #000; font-weight: normal; text-align: right; background-color: #f7f7f7;text-align: right !important;">{0}</th>';
                      concatHtml += '<td style="padding: 6px 9px;">';
                      concatHtml += '<textarea type="text" id="{1}" class="dews-ui-textbox k-textbox dews-control-activate dews-form-control" style="width:100%" maxlength="2000"></textarea>';
                      concatHtml += '<textarea type="text" id="old_{1}" class="cm-popup-multilanguagehidden" style="display:none"></textarea>';
                      concatHtml += "</td>";

                      tableHtml += dews.string.format(concatHtml, it.COL_NM + " (" + it.COL2_NM + ")", it.COL_CD);

                      if (data.length >= i + 2) {
                        concatHtml = '<th style="padding: 6px 9px;color: #000; font-weight: normal; text-align: right; background-color: #f7f7f7;text-align: right !important;">{0}</th>';
                        concatHtml += '<td style="padding: 6px 9px;">';
                        concatHtml += '<textarea type="text" id="{1}" class="dews-ui-textbox k-textbox dews-control-activate dews-form-control" style="width:100%" maxlength="2000"></textarea>';
                        concatHtml += '<textarea type="text" id="old_{1}" class="cm-popup-multilanguagehidden" style="display:none"></textarea>';
                        concatHtml += "</td>";
                        concatHtml += "</tr>";

                        tableHtml += dews.string.format(concatHtml, data[i + 1].COL_NM + " (" + data[i + 1].COL2_NM + ")", data[i + 1].COL_CD);
                      } else {
                        tableHtml += '<td colspan="2" style="border-left:0px;padding: 6px 9px;" />';
                        tableHtml += "</tr>";
                      }
                    }
                  });

                  tableHtml += "</tbody></table>";
                }

                popupHtml += tableHtml;
                popupHtml += "</div></div></div>";

                self.$content.append(popupHtml);

                var textbox_list = self.$content.find(".cm-popup-multilanguage .dews-ui-textbox");
                $.each(textbox_list, function (i, textbox) {
                  self[textbox.id] = dews.ui.textbox($(textbox));

                  //---현재사용중인 언어 readonly
                  if (textbox.id == std_Lang) {
                    self[textbox.id].readonly(true);
                  }
                });

                var textbox_list_old = self.$content.find(".cm-popup-multilanguagehidden");
                $.each(textbox_list_old, function (i, textbox) {
                  self[textbox.id] = textbox;

                  //---현재사용중인 언어 readonly
                  if (textbox.id == std_Lang) {
                    self[textbox.id].readonly(true);
                  }
                });

                var $btnSave = self.$content.find(".cm-btn-multilanguage-save");
                dews.ui.button($btnSave);

                var $btnCtrl = self.$content.find(".cm-btn-multilanguage");
                var $popupCtrl = self.$content.find(".cm-popup-multilanguage");
                var $popup = dews.ui.popuppanel($popupCtrl, {
                  height: 245, //다국어팝업 높이
                });

                //다국어 버튼 메인으로 변환 후 삭제
                $btnCtrl.on("click", function (e) {
                  if ($popupCtrl[0].style.display == "none") {
                    popself.popOpen = true;
                    if (popself.col_Param) {
                      popself.bindDataMulti(popself.col_Param, popself.col_Name, null);
                    }
                    $popup.show();
                  } else {
                    popself.popOpen = false;
                    $popup.hide();
                  }
                });

                dews.ui.mainbuttons.localize.on("click", function (e) {
                  if ($popupCtrl[0].style.display == "none") {
                    popself.popOpen = true;
                    if (popself.col_Param) {
                      popself.bindDataMulti(
                        popself.col_Param,
                        popself.col_Name,
                        null
                      );
                    }
                    $popup.show();
                  } else {
                    popself.popOpen = false;
                    $popup.hide();
                  }
                });

                $btnSave.on("click", function (e) {
                  //save
                  popself.saveData(true);
                });

                $(
                  ".cm-popup-multilanguage .dews-popup-close-button",
                  self.$content
                ).on("click", function (e) {
                  if ($popupCtrl[0].style.display != "none") {
                    popself.popOpen = false;
                  }
                });

                $(".cm-popup-multilanguage .dews-ui-textbox", self.$content).on(
                  "change",
                  function (e) {
                    popself.saveButtonEnable(true);
                  }
                );

                popself.saveButtonEnable(false);

                //popup 저장버튼 스타일이 생성시..right인데 안먹힘..어느순간부터
                $(
                  ".cm-popup-multilanguage .cm-btn-multilanguage-save",
                  self.$content
                ).attr("style", "float:right;");
                //-------------------------

                $(
                  ".cm-popup-multilanguage .dews-popup-arrow-button",
                  self.$content
                ).attr("style", "display:none;");
                $(
                  ".cm-popup-multilanguage .cm-btn-multilanguage-save",
                  self.$content
                ).attr("style", "margin-top: 4px;margin-right: 29px;");
              }
            });
        },

        changeTextBox: function (self, multiLine) {  //S : SingleText, M : MultiLineText
          var popself = this;
          popself.isSession = undefined;

          dews.localize.load(dews.localize.language(), 'BASLAN00400')
          .then(function (data) {
            popself.multiTitle = dews.localize.get('다국어 설정', 'D0000898', dews.localize.language(), 'BASLAN00400');
          });

          popself.multiButton = "저장";
          dews.localize.load(dews.localize.language(), 'CSBCIC00500')
          .then(function (data) {
            popself.multiButton = dews.localize.get('저장', 'D0000388', dews.localize.language(), 'CSBCIC00500');
          });

          if(popself.isSession){
            std_Lang = self.user.language.toUpperCase();
          }
          else{
            dews.api.get(dews.url.getApiUrl("CM", "MultiLanguageService", "company_std_language"), {
              async: false
            }).done(function (data) {
              if(data && data.length > 0){
                std_Lang = data;
              }
            }).fail(function (xhr, status, error) {
              dews.ui.snackbar.error(error);
            });
          }

          dews.api.get(dews.url.getApiUrl("CM", "MultiLanguageService", "language_list"), {
            async: false,
          }).done(function (data) {
              if (data) {
                //var popupHtml = '<div class="dews-popup-panel cm-popup-multilanguage" id="popup" style="padding:0 !important">';   //kihongKim
                var popupHtml ='<div class="dews-button-group" style="background: #f1f6f9; margin-bottom:0;">';

                // if(multiLine)
                //   popupHtml +='<div style="float:left;height:calc(100% - 36px);">';
                // else
                  popupHtml +='<div style="float:left;height:36px;">';

                popupHtml +='<h3 style="float: left; padding-left:15px; margin-top: 8px;" class="cm-title-multilanguage">' + popself.multiTitle + "</h3>";
                popupHtml += "</div>";
                popupHtml += '<button class="dews-ui-button cm-btn-multilanguage-save" style="float:right;">' + popself.multiButton + "</button>";
                popupHtml += "</div>";
                //popupHtml += '<div class="dews-popup-item" style="height: calc(100% - 39px); padding-top:8px;">';
                popupHtml += '<div class="dews-popup-item" style="height: 39px; padding-top:8px;">';
                popupHtml += '<div class="dews-popup-content"></div>';

                if(multiLine)
                 popupHtml += '<div class="cm-content-multilanguage" style="height:195px;overflow:auto;border-top:2px solid #666;">';
                else
                  popupHtml += '<div class="cm-content-multilanguage" style="height:123px;overflow:auto;border-top:2px solid #666;">';

                var tableHtml = "";
                if (data.length > 0) {
                  tableHtml = '<table style="width: 100%;width: 100%;table-layout: fixed;border-collapse: collapse;border-spacing: 0;">';
                  tableHtml += "<colgroup>";
                  tableHtml += '<col width="20%">';
                  tableHtml += '<col width="30%">';
                  tableHtml += '<col width="20%">';
                  tableHtml += '<col width="30%">';
                  tableHtml += "</colgroup>";
                  tableHtml += "<tbody>";

                  $.each(data, function (i, it) {
                    if (i % 2 == 0) {
                      var concatHtml = '<tr style="height:40px;border-bottom: 1px solid #e1e1e1;">';
                      concatHtml += '<th style="padding: 6px 9px;color: #000; font-weight: normal; text-align: right; background-color: #f7f7f7;text-align: right !important;">{0}</th>';
                      concatHtml += '<td style="padding: 6px 9px;">';
                      if(multiLine){
                        concatHtml += '<textarea type="text" id="{1}" class="dews-ui-textbox k-textbox dews-control-activate dews-form-control" style="width:100%" maxlength="2000"></textarea>';
                        concatHtml += '<textarea type="text" id="old_{1}" class="cm-popup-multilanguagehidden" style="display:none"></textarea>';
                      } else{
                        concatHtml += '<input type="text" id="{1}" class="dews-ui-textbox k-textbox dews-control-activate dews-form-control" style="width:100%" maxlength="200"></input>';
                        concatHtml += '<input type="text" id="old_{1}" class="cm-popup-multilanguagehidden" style="display:none"></input>';
                      }
                      concatHtml += "</td>";

                      tableHtml += dews.string.format(
                        concatHtml,
                        it.COL_NM + " (" + it.COL2_NM + ")",
                        it.COL_CD
                      );

                      if (data.length >= i + 2) {
                        concatHtml = '<th style="padding: 6px 9px;color: #000; font-weight: normal; text-align: right; background-color: #f7f7f7;text-align: right !important;">{0}</th>';
                        concatHtml += '<td style="padding: 6px 9px;">';
                        if(multiLine){
                          concatHtml += '<textarea type="text" id="{1}" class="dews-ui-textbox k-textbox dews-control-activate dews-form-control" style="width:100%" maxlength="2000"></textarea>';
                          concatHtml += '<textarea type="text" id="old_{1}" class="cm-popup-multilanguagehidden" style="display:none"></textarea>';
                        } else{
                          concatHtml += '<input type="text" id="{1}" class="dews-ui-textbox k-textbox dews-control-activate dews-form-control" style="width:100%" maxlength="200"></input>';
                          concatHtml += '<input type="text" id="old_{1}" class="cm-popup-multilanguagehidden" style="display:none"></input>';
                        }
                        concatHtml += '</td>';
                        concatHtml += '</tr>';

                        tableHtml += dews.string.format(concatHtml, data[i + 1].COL_NM + " (" + data[i + 1].COL2_NM + ")", data[i + 1].COL_CD);
                      } else {
                        tableHtml += '<td colspan="2" style="border-left:0px;padding: 6px 9px;" />';
                        tableHtml += '</tr>';
                      }
                    }
                  });

                  tableHtml += '</tbody></table>';
                }

                popupHtml += tableHtml;
                popupHtml += '</div></div>';
                //kihongKim Start
                self.$content[0].lastChild.replaceChildren();
                self.$content[0].lastChild.innerHTML = popupHtml;
                //kihongKim End
                var textbox_list = self.$content.find(".cm-popup-multilanguage .dews-ui-textbox");
                $.each(textbox_list, function (i, textbox) {
                  var context = self[textbox.id].text();
                  self[textbox.id] = dews.ui.textbox($(textbox));

                  //---현재사용중인 언어 readonly
                  if (textbox.id == std_Lang) {
                    self[textbox.id].readonly(true);
                  }
                  self[textbox.id].text(context);
                });


                var textbox_list_old = self.$content.find(".cm-popup-multilanguagehidden");
                $.each(textbox_list_old, function (i, textbox) {
                  var context_old = self[textbox.id].textContent;
                  self[textbox.id] = textbox;

                  //---현재사용중인 언어 readonly
                  if (textbox.id == std_Lang) {
                    self[textbox.id].readonly(true);
                  }
                  self[textbox.id].textContent = context_old;
                });

                var $btnSave = self.$content.find(".cm-btn-multilanguage-save");
                dews.ui.button($btnSave);

                var $btnCtrl = self.$content.find(".cm-btn-multilanguage");
                var $popupCtrl = self.$content.find(".cm-popup-multilanguage");
                var $popup = dews.ui.popuppanel($popupCtrl, {
                  height: 245
                });

                //SingleLine, MultiLine 사이즈 변경
                self.$content.find(".cm-popup-multilanguage")[0].style.height = multiLine ? '245px' : '180px';

                // 다국어 버튼 메인으로 변환 후 삭제
                $btnCtrl.on("click", function (e) {
                  if ($popupCtrl[0].style.display == "none") {
                    popself.popOpen = true;
                    if (popself.col_Param) {
                      popself.bindDataMulti(
                        popself.col_Param,
                        popself.col_Name,
                        null
                      );
                    }
                    $popup.show();
                  } else {
                    popself.popOpen = false;
                    $popup.hide();
                  }
                });

                dews.ui.mainbuttons.localize.on("click", function (e) {
                  if ($popupCtrl[0].style.display == "none") {
                    popself.popOpen = true;
                    if (popself.col_Param) {
                      popself.bindDataMulti(popself.col_Param, popself.col_Name, null);
                    }
                    $popup.show();
                  } else {
                    popself.popOpen = false;
                    $popup.hide();
                  }
                });

                $btnSave.on("click", function (e) {
                  //save
                  popself.saveData(true);
                });

                $(
                  ".cm-popup-multilanguage .dews-popup-close-button",
                  self.$content
                ).on("click", function (e) {
                  if ($popupCtrl[0].style.display != "none") {
                    popself.popOpen = false;
                  }
                });

                $(".cm-popup-multilanguage .dews-ui-textbox", self.$content).on(
                  "change",
                  function (e) {
                    popself.saveButtonEnable(true);
                  }
                );

                popself.saveButtonEnable(false);

                //popup 저장버튼 스타일이 생성시..right인데 안먹힘..어느순간부터
                $(
                  ".cm-popup-multilanguage .cm-btn-multilanguage-save",
                  self.$content
                ).attr("style", "float:right;");
                //-------------------------

                $(
                  ".cm-popup-multilanguage .dews-popup-arrow-button",
                  self.$content
                ).attr("style", "display:none;");
                $(
                  ".cm-popup-multilanguage .cm-btn-multilanguage-save",
                  self.$content
                ).attr("style", "margin-top: 4px;margin-right: 29px;");
              }
            });
        },
        initInfo: function (self, info) {
          //다국어 변경컬럼이 단일일때
          var popself = this;
          popself.self = self;
          popself.col_Info = info;
        },
        initInfoMulti: function (self, infos) {
          //다국어 변경 테이블이 여러개 일때
          var popself = this;
          popself.self = self;
          popself.col_Info_multi = infos;
          popself.setInitInfo(0);
        },
        initInfoMultiSeq: function (self, infos, isSeq) {
          //다국어 변경 테이블이 여러개이고 PK컬럼이 SQ컬럼이며 표시되는 순서가 정렬순서와 일치할때
          var popself = this;
          popself.self = self;
          popself.col_Info_multi = infos;
          popself.isSeq = isSeq;
          popself.setInitInfo(0);
        },
        setInitInfo: function (idx) {
          var popself = this;
          if (idx != null) {
            popself.col_Info = popself.col_Info_multi[idx];
          }
        },
        setUseCompany: function (isUse) {
          var popself = this;
          popself.useCompany = isUse;
        },
        setAllCompany: function (table_id, col_cd, mTable_id) {
          //CI 기준 정보 입력시 MA아래의 모든 회사의 값 동기화
          var popself = this;
          popself.downTable = table_id;
          popself.downCol = col_cd;
          popself.mTable = mTable_id;
        },
        saveButtonEnable: function (isModify) {
          var popself = this;
          if (!isModify) {
            $(".cm-btn-multilanguage-save", popself.self.$content).prop(
              "disabled",
              true
            );
            $(".cm-btn-multilanguage-save", popself.self.$content).addClass(
              "k-state-disabled"
            );
          } else {
            $(".cm-btn-multilanguage-save", popself.self.$content).prop(
              "disabled",
              false
            );
            $(".cm-btn-multilanguage-save", popself.self.$content).removeClass(
              "k-state-disabled"
            );
          }
        },
        clearData: function () {
          var popself = this;
          popself.saveButtonEnable(false);
          var textbox_list = $(
            ".cm-popup-multilanguage .dews-ui-textbox",
            popself.self.$content
          );
          $.each(textbox_list, function (i, textbox) {
            popself.self[textbox.id].text("");
            popself.self["old_" + textbox.id].textContent = "";
          });
        },
        bindData: function (params, name) {
          var popself = this;
          popself.bindDataMulti(params, name, null);
        },
        bindDataParamMulti: function (params, name, COL) {
          //변경된 컬럼이 여러개일 경우 현재와 이전을 구분하기 위해 생성
          var popself = this;
          popself.beforeCol = popself.col_Info.COL;
          popself.col_Info.COL = COL;
          popself.bindDataMulti(params, name, null);
        },
        bindDataMulti: function (params, name, idx) {
          var popself = this;
          var textbox_list = $(
            ".cm-popup-multilanguage .dews-ui-textbox",
            popself.self.$content
          );
          var checkData = false;

          $.each(textbox_list, function (i, textbox) {
            //IE에서는 popself.self["old_"+textbox.id].textContent 값이 "undefined"로 나옴
            //kihongKim
            var newText = popself.self[textbox.id].text().replaceAll('\n','');
            var oldText = popself.self["old_" + textbox.id].textContent.replaceAll('\n','');
            if (
              newText !=
              (popself.self["old_" + textbox.id].textContent == "undefined"
                ? ""
                : oldText)
            ) {
              checkData = true;
            }
          });

          if (checkData) {
            dews
              .confirm(
                "다국어설정 데이터가 저장되지 않았습니다." +
                  "\n" +
                  "저장하시겠습니까?",
                "question"
              )
              .yes(function () {
                popself.saveData();
                popself.setInitInfo(idx);
                popself.bindDataSearch(params, name);
              })
              .no(function () {
                popself.setInitInfo(idx);
                popself.bindDataSearch(params, name);
              });
          } else {
            popself.setInitInfo(idx);
            popself.bindDataSearch(params, name);
          }
        },
        bindDataTableAndParamMulti: function (params, name, COL, idx) {
          //다국어 저장하는 테이블과 대상 컬럼이 여러개일 경우
          var popself = this;
          popself.beforeCol = popself.col_Info.COL;
          popself.col_Info.COL = COL;
          popself.otherCOL = COL;
          popself.bindDataMulti(params, name, idx);
        },

        bindDataTableAndParamMultiLine: function (params, name, COL, idx, self, multiLine){
          //다국어 저장하는 테이블과 대상 컬럼이 여러개일 경우
          var popself = this;
          //싱글라인, 멀티라인 텍스트박스 변경
          popself.changeTextBox(self, multiLine);
          popself.beforeCol = popself.col_Info.COL;
          popself.col_Info.COL = COL;
          popself.otherCOL = COL;
          popself.bindDataMulti(params, name, idx);
        },
        bindDataSearch: function (params, name) {
          var popself = this;
          popself.clearData();
          popself.col_Param = params;
          popself.col_Name = name;

          if (popself.otherCOL) {
            if (popself.otherCOL != popself.col_Info.COL) {
              popself.col_Info.COL = popself.otherCOL;
            }
          }

          //title
          if (name != null && name.indexOf('\n')==-1) {     //kihongKim
            var title = name + " " + popself.multiTitle;
          } else {
            var title = popself.multiTitle;
          }

          $(".cm-title-multilanguage", popself.self.$content).text(title);
          $(".cm-btn-multilanguage-save", popself.self.$content).text(
            popself.multiButton
          );

          if (popself.isSeq == "") {
            if (
              $(".cm-popup-multilanguage", popself.self.$content)[0].style
                .display != "none" ||
              popself.popOpen
            ) {
              var plist = popself.col_Info.PCOL.split("|");
              var keys = "";

              if (popself.useCompany) {
                $.each(plist, function (i, p) {
                  if (p != "COMPANY_CD" && p != "") {
                    keys += params[p] + "|";
                  }
                });
              } else {
                $.each(plist, function (i, p) {
                  if (p != "") {
                    if (p.indexOf("_SQ") == -1) {
                      keys += params[p] + "|";
                    } else {
                      keys += i + "|";
                    }
                  }
                });
              }

              var param = {
                table: popself.col_Info.TABLE,
                pcols: popself.col_Info.PCOL,
                col: popself.col_Info.COL,
                keys: keys,
                usecompany: popself.useCompany ? "1" : "2",
                isSession: popself.isSession ? "1" : "2",
              };

              dews.api
                .get(
                  dews.url.getApiUrl(
                    "CM",
                    "MultiLanguageService",
                    "language_list_bind"
                  ),
                  {
                    async: false,
                    data: param,
                  }
                )
                .done(function (data) {
                  if (data) {
                    $.each(data, function (i, it) {
                      if (popself.self[it.LANG_CD]) {
                        popself.self[it.LANG_CD].text(it.DATA);
                        popself.self["old_" + it.LANG_CD].textContent = it.DATA;
                      }
                    });
                  }
                });
            }
          } else {
            var names = name.split(this.isSeq);
            var lang = {};
            for (var seq = 1; seq <= names.length; seq++) {
              if (
                $(".cm-popup-multilanguage", popself.self.$content)[0].style
                  .display != "none" ||
                popself.popOpen
              ) {
                var plist = popself.col_Info.PCOL.split("|");
                var keys = "";

                if (popself.useCompany) {
                  $.each(plist, function (i, p) {
                    if (p != "COMPANY_CD" && p != "") {
                      keys += params[p] + "|";
                    }
                  });
                } else {
                  $.each(plist, function (i, p) {
                    if (p != "") {
                      if (p.indexOf("_SQ") == -1) {
                        keys += params[p] + "|";
                      } else {
                        keys += seq + "|";
                      }
                    }
                  });
                }

                var param = {
                  table: popself.col_Info.TABLE,
                  pcols: popself.col_Info.PCOL,
                  col: popself.col_Info.COL,
                  keys: keys,
                  usecompany: popself.useCompany ? "1" : "2",
                  isSession: popself.isSession ? "1" : "2",
                };

                dews.api
                  .get(
                    dews.url.getApiUrl(
                      "CM",
                      "MultiLanguageService",
                      "language_list_bind"
                    ),
                    {
                      async: false,
                      data: param,
                    }
                  )
                  .done(function (data) {
                    if (data) {
                      $.each(data, function (i, it) {
                        if (popself.self[it.LANG_CD]) {
                          if (
                            lang[it.LANG_CD] == undefined ||
                            lang[it.LANG_CD] == " "
                          ) {
                            lang[it.LANG_CD] = "";
                            lang[it.LANG_CD] += it.DATA;
                          } else if (it.DATA != " ") {
                            lang[it.LANG_CD] += "," + it.DATA;
                          }
                        }
                      });
                    }
                  });
              }
            }
            var langCd = Object.keys(lang);
            for (var i = 0; i < langCd.length; i++) {
              popself.self[langCd[i]].text(lang[langCd[i]]);
              popself.self["old_" + langCd[i]].textContent = lang[langCd[i]];
            }
          }
          if (popself.self[std_Lang]) {
            if (popself.self[std_Lang].text() == "") {
              popself.self[std_Lang].text(name);
              popself.self["old_" + std_Lang].textContent = name;
            }
          }
          return true;
        },
        saveDataPop: function () {
          //저장시 태우는 로직
          var popself = this;
          if (
            !$(".cm-btn-multilanguage-save", popself.self.$content).hasClass(
              "k-state-disabled"
            )
          ) {
            popself.saveData();
          }
        },
        saveData: function (flag) {
          //저장로직
          var popself = this;
          var textbox_list = $(
            ".cm-popup-multilanguage .dews-ui-textbox",
            popself.self.$content
          );
          var dataList = [];
          var plist = popself.col_Info.PCOL.split("|");
          var params = popself.col_Param;
          var keys = "";

          if (popself.isSeq == "") {
            //현재 사용중인 언어는 저장하지 않는다. (우선 저장)
            $.each(textbox_list, function (i, textbox) {
              if (
                popself.self[textbox.id].text() !=
                popself.self["old_" + textbox.id].textContent
              ) {
                dataList.push({
                  LANG_CD: textbox.id,
                  DATA: popself.self[textbox.id].text(),
                });
              }
            });

            if (popself.useCompany) {
              $.each(plist, function (i, p) {
                if (p != "COMPANY_CD" && p != "") {
                  keys += params[p] + "|";
                }
              });
            } else {
              $.each(plist, function (i, p) {
                if (p != "") {
                  keys += params[p] + "|";
                }
              });
            }

            var iscompany = popself.useCompany ? "1" : "2";
            var param = {
              table: popself.col_Info.TABLE,
              pcols: popself.col_Info.PCOL,
              //저장버튼을 눌렀을경우 현재의 컬럼
              //그 이외의 이벤트로 저장이 발생할경우 이전의 컬럼으로 저장
              col: flag
                ? popself.col_Info.COL
                : popself.beforeCol
                ? popself.beforeCol
                : popself.col_Info.COL,
              keys: keys,
              datalist: JSON.stringify(dataList),
              usecompany: iscompany,
            };

            dews.ajax
              .post(
                dews.url.getApiUrl(
                  "CM",
                  "MultiLanguageService",
                  "language_save"
                ),
                {
                  async: false,
                  dataType: "json",
                  data: param,
                }
              )
              .done(function (data) {
                if (popself.downTable) {
                  var dParam = {
                    //CI 다국어테이블과 그아래 다국어테이블의 명칭 컬럼명이 같다는 전제하에 진행(1:1)
                    uTable: popself.col_Info.TABLE,
                    dTable: popself.downTable,
                    mTable: popself.mTable,
                    pcols: popself.col_Info.PCOL,
                    dCol: popself.downCol,
                    keys: keys,
                  };
                  dews.ajax
                    .post(
                      dews.url.getApiUrl(
                        "CM",
                        "MultiLanguageService",
                        "language_save_down"
                      ),
                      {
                        async: false,
                        dataType: "json",
                        data: dParam,
                      }
                    )
                    .done(function (data) {
                      popself.saveButtonEnable(false);
                      dews.ui.snackbar.ok(
                        dews.localize.get("저장이 완료되었습니다.", "M0000021")
                      );
                      popself.bindDataSearch(
                        popself.col_Param,
                        popself.col_Name
                      );
                    });
                } else {
                  popself.saveButtonEnable(false);
                  dews.ui.snackbar.ok(
                    dews.localize.get("저장이 완료되었습니다.", "M0000021")
                  );
                  popself.bindDataSearch(popself.col_Param, popself.col_Name);
                }
              });
          } else {
            var names = popself.self[dews.ui.page.user.stdrLangCd.toUpperCase()]
              .text()
              .split(this.isSeq);
            var datas = "";
            var cnt = 1;
            var exit = false;
            var forOneDataL;
            var forOneDataD;

            for (var seq = 1; seq <= names.length; seq++) {
              $.each(textbox_list, function (i, textbox) {
                if (
                  popself.self[textbox.id].text() !=
                  popself.self["old_" + textbox.id].textContent
                ) {
                  let text = popself.self[textbox.id].text();
                  if (text.indexOf(popself.isSeq) != -1) {
                    datas = text.split(popself.isSeq);
                    if (
                      datas[seq - 1] !== "" &&
                      datas[seq - 1] !== null &&
                      datas[seq - 1] !== undefined
                    ) {
                      dataList.push({
                        LANG_CD: textbox.id,
                        DATA: datas[seq - 1],
                      });
                    } else {
                      dataList.push({ LANG_CD: textbox.id, DATA: " " });
                    }
                  } else if (text.indexOf(popself.isSeq) == -1 && text == "") {
                    dataList.push({ LANG_CD: textbox.id, DATA: " " });
                  } else if (text.indexOf(popself.isSeq) == -1) {
                    if (forOneDataL != textbox.id && forOneDataD != text) {
                      dataList.push({ LANG_CD: textbox.id, DATA: text });
                      forOneDataL = textbox.id;
                      forOneDataD = text;
                    } else {
                      dataList.push({ LANG_CD: textbox.id, DATA: " " });
                    }
                  }
                }
              });

              if (exit) {
                return false;
              }

              if (popself.useCompany) {
                $.each(plist, function (i, p) {
                  if (p != "COMPANY_CD" && p != "") {
                    keys += params[p] + "|";
                  }
                });
              } else {
                $.each(plist, function (i, p) {
                  if (p != "") {
                    if (p.indexOf("_SQ") == -1) {
                      keys += params[p] + "|";
                    } else {
                      keys += seq + "|";
                    }
                  }
                });
              }

              var iscompany = popself.useCompany ? "1" : "2";
              var param = {
                table: popself.col_Info.TABLE,
                pcols: popself.col_Info.PCOL,
                //저장버튼을 눌렀을경우 현재의 컬럼
                //그 이외의 이벤트로 저장이 발생할경우 이전의 컬럼으로 저장
                col: flag
                  ? popself.col_Info.COL
                  : popself.beforeCol
                  ? popself.beforeCol
                  : popself.col_Info.COL,
                keys: keys,
                datalist: JSON.stringify(dataList),
                usecompany: iscompany,
              };

              dews.ajax
                .post(
                  dews.url.getApiUrl(
                    "CM",
                    "MultiLanguageService",
                    "language_save"
                  ),
                  {
                    async: false,
                    dataType: "json",
                    data: param,
                  }
                )
                .done(function (data) {
                  popself.saveButtonEnable(false);
                  if (names.length == cnt) {
                    dews.ui.snackbar.ok(
                      dews.localize.get("저장이 완료되었습니다.", "M0000021")
                    );
                    popself.bindDataSearch(popself.col_Param, popself.col_Name);
                  } else {
                    cnt++;
                    dataList = [];
                  }
                  keys = "";
                });
            }
          }
        },
        statePop: function (isAdd) {
          var popself = this;
          var textbox_list = $(
            ".cm-popup-multilanguage .dews-ui-textbox",
            popself.self.$content
          );

          $.each(textbox_list, function (i, textbox) {
            if (isAdd) {
              popself.self[textbox.id].readonly(true);
            } else {
              //---현재사용중인 언어 readonly 제외
              if (textbox.id != std_Lang) {
                popself.self[textbox.id].readonly(false);
              }
            }
          });
        },
        addPop: function () {
          var popself = this;
          var $popup = $(".cm-popup-multilanguage", popself.self.$content);
          if ($popup[0].style.display != "none") {
            popself.popOpen = false;
            $popup.hide();
          }
        },
      };
    }
  };

  //---------End
  dews.localize.load(dews.localize.language(), 'ITAOTS00100');

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=ia.cm.js
