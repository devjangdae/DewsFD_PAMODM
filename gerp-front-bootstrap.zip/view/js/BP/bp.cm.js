/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
/*
 * BP 모듈 공통 함수
 * /view/js/bp.cm.js
 */
(function (dews, gerp, $) {
  var module = {};

  //---------Setting
  var moduleCode = 'BP';  //모듈 코드
  var ynClose = 'N';      //Y.마감, N.미마감
  var tpClose;

  //---------Start

  //Date공통함수
  module.DATE = {
    GetDiffMonth : function (startDate, endDate) {

      var nStartMon, nEndMon;
      nStartMon = parseInt(startDate.substr(0,4), 10)*12 + parseInt(startDate.substr(4,2), 10);
      nEndMon = parseInt(endDate.substr(0,4), 10)*12 + parseInt(endDate.substr(4,2), 10);

      return (nEndMon - nStartMon + 1);
    },
    /**
     * 공통코드 CO/P00170 의 연월 기준값에 따른 값 리턴
     * @example DATE.getDateP00170("11");
     * @param {*} type : 11.현재월, 12.다음월, 13.현재 연도 1월, 14.현재 연도 12월, 15: 다음 연도 1월, 16: 다음 연도 12월
     * @return {*} 해당 연월
     */
    getDateP00170 : function (type) {
      var yyMM = "";
      var now = new Date();
      if(type == "11") { // 현재월
        yyMM = new Date(now.getFullYear(), now.getMonth());
      }
      else if(type == "12") { // 다음월
        yyMM = new Date(now.getFullYear(), now.getMonth()+1);
      }
      else if(type == "13") { // 현재 연도 1월
        yyMM = new Date(now.getFullYear(), now.getMonth());
      }
      else if(type == "14") { // 현재 연도 12월
        yyMM = new Date(now.getFullYear(), 11);
      }
      else if(type == "15") { // 다음 연도 1월
        yyMM = new Date(now.getFullYear()+1, 0);
      }
      else if(type == "16") { // 다음 연도 12월
        yyMM = new Date(now.getFullYear()+1, 11);
      }
      return yyMM;
    }
  };

  module.SEARCH = {
    /**
     * 사업계획 버젼 조회
     * @example SEARCH.getBpVer('0');
     * @param {*} confrim : 0.전체, 1.확정된것만, 2.미확정된것만
     * @return {*} CODE, NAME, YM_FROM, YM_TO
     */
    getBpVer: function (confrim) {
      var dtVer = null;

      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getBpVer'), {
        async: false,
        data: {
          confirm: confrim
        }
      }).done(function (data) {
          if (data.length > 0) {
            dtVer = data;
          }
      });

      return dtVer;
    },
    /**
     * 사업시나리오 버젼 조회
     * @example SEARCH.getBpScen('001', '0');
     * @param {*} bpVer : 버젼
     * @param {*} confrim : 0.전체, 1.확정된것만, 2.미확정된것만
     * @return {*} CODE, NAME
     */
    getBpScen: function (bpVer, confrim) {
      var dtScen = null;

      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getBpScen'), {
        async: false,
        data: {
          ver_cd: bpVer,
          confirm: confrim
        }
      }).done(function (data) {
        if (data.length > 0) {
          dtScen = data;
        }
      });

      return dtScen;
    },
    /**
     * 템플릿계획 버젼 조회
     * @example SEARCH.getTmplVer('0');
     * @param {*} confrim : 0.전체, 1.확정된것만, 2.미확정된것만
     * @return {*} CODE, NAME, START_DT_TP, END_DT_TP
     */
    getTmplVer: function (confrim) {
      var dtVer = null;

      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getTmplVer'), {
        async: false,
        data: {
          confirm: confrim
        }
      }).done(function (data) {
          if (data.length > 0) {
            dtVer = data;
          }
      });

      return dtVer;
    },
    /**
     * 템플릿 시나리오 조회
     * @example SEARCH.getTmplScen('001', '0');
     * @param {*} bpVer : 버젼
     * @param {*} confrim : 0.전체, 1.확정된것만, 2.미확정된것만
     * @return {*} CODE, NAME
     */
    getTmplScen: function (bpVer, confrim) {
      var dtScen = null;

      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getTmplScen'), {
        async: false,
        data: {
          ver_cd: bpVer,
          confirm: confrim
        }
      }).done(function (data) {
        if (data.length > 0) {
          dtScen = data;
        }
      });

      return dtScen;
    },
    /**
     * 현재회사 통화
     * @example SEARCH.getExch();
     * @return {*} String
     */
    getExch: function () {
      var exch = null;

      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getExch'), {
        async: false
      }).done(function (data) {
        exch = data;
      });

      return exch;
    },
    /**
     * 현재회사 공장리스트
     * @example SEARCH.getPlant();
     * @return {*} CD_PLANT, NM_PLANT
     */
    getPlant: function () {
      var plant = null;

      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getPlant'), {
        async: false
      }).done(function (data) {
        plant = data;
      });

      return plant;
    },
    /**
     * 현재회사 무역관리, 비용구분 ('IE', 'P00100')
     * @example SEARCH.getChargeGubn();
     */
    getChargeGubn: function () {
      var charge = null;

      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getChargeGubn'), {
        async: false
      }).done(function (data) {
        charge = data;
      });

      return charge;
    },
    /**
     * 현재회사 인사관리, 사회보험코드 ('HR', 'P01160')
     * @example SEARCH.getSiGubn();
     */
    getSiGubn: function () {
      var si = null;

      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getSiGubn'), {
        async: false
      }).done(function (data) {
        si = data;
      });

      return si;
    },
    /* 사업계획 메뉴별로 사용여부, 필수여부, 중복체크 여부를 확인하기 위한 api
     * @example SEARCH.getMenuColumn();
     * @param {*} bpVer : 버젼
     * @param {*} menuId : 메뉴ID
     * @param {*} onlyUse : 사용여부가 Y인 컬럼만 가져오는 지 여부
     * @return {*} CD_BPVER, CD_MENU, CD_COLUMN, ID_TABLE, YN_USE, YN_MANDATORY, YN_DUPCHK, YN_SYSTEM
     */
    getMenuColumn: function(bpVer, menuId, onlyUse) {
      var ret = [];
      dews.api.get(dews.url.getApiUrl('BP', 'BpCommonService', 'getMenuColumn'), {
        async: false,
        data: {
          ver_cd: bpVer,
          menuId: menuId,
          onlyUse: onlyUse || ""
        }
      }).done(function (data) {
        ret = data;
      });

      return ret;
    }

  };

  //BP, 마감 관련
  module.CLOSE = {

    /**
     * value 가 null 이거나 undefined 가 아니라면 false 를 리턴
     * @param {*} value 체크객체
     * @returns {boolean} Null 인지 여부
     */
    isNull: function (value) {
      if (value != null && value != undefined) {
        return false;
      }

      return true;
    },

    /**
     * @param {*} value 모듈코드(마감코드)
     */
    setCloseCode: function(value) {
      tpClose = value;
    },

    /**
    * @example var magam = Close.regetClose('201801');
    * @param {*} yyyyMM 결산년
    * @param {*} tpClose 관리회계 마감 구분 (코드관리)
    * @return {*} 마감여부 Y.마감, N.미마감
    */
    regetClose: function(yyyyMM) {

      if (!this.isNull(yyyyMM) && !this.isNull(tpClose)) {
/*
        dews.api.get(dews.url.getApiUrl("CO", "CostCenterAccountingCAPService", "ccacap00300_select_close"), {
          async: false,
          data: {
            cd_module: "CO",
            ym_close: yyyyMM,
            cd_tpclose: tpClose
          }
        }).done(function (data) {
          if (data.length > 0) {
            ynClose = data[0]["YN_CLOSE"];
          }
          else {
            ynClose = 'N';
          }
        });
*/
      }

      return ynClose;
    },

    /**
     * @return {*} 마감여부 Y.마감, N.미마감
     */
    getClose: function() {
      return ynClose;
    },

    /**
     * 스낵바를 띄우고 마감여부리터
     * @return {*} 마감여부 Y.마감, N.미마감
     */
    getCloseMsg: function() {
      if (ynClose == "Y") {
        dews.ui.snackbar.warning("마감된 기간입니다.");
      }

      return ynClose;
    }
  };

  //---------End

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=bp.cm.js
