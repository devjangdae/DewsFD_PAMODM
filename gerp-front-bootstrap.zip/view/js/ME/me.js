/*
 * @desc    ME 모듈 공통 함수
 * @author
 * @date    2020.01.14
 * @path    /view/js/me.js
 */
(function (dews, gerp, $) {
    var module = {};
    var moduleCode = 'ME';  //모듈 코드

    //------------------------------------------Start------------------------------------------
    //

    //API
    module.api = {

        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           guid
         *  @ex
         *  @memo           uid 생성
         *  @return         string
         * ------------------------------------------------------------------------------------------*/
        guid : function () {
            return 'xxxxxxxx-xxxx-4xxx-9xxx-xxxxxxxxxxxx'.replace(/[xy]/g,
            function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        },

        /* --------------------------------------------------------------------------------------------
        *  @no
        *  @desc           공통코드조회
        *  @ex
        *  @memo
        * --------------------------------------------------------------------------------------------
        *  @module_cd      모듈코드
        *  @field_cd_pipe  코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
        *  @syscode_yn     시스템코드 유무(Y,N)
        *  @base_yn        디폴트 코드구분(Y,N)
        *  @foreign_yn     외국언어적용 유무(Y,N)- Y : NM_SYSDEF2, N : NM_SYSDEF
        *  @end_dt         종료일-종료일이 있는 경우 종료일 이전 데이터 제외
        *  @keyword        검색할 코드 또는 명
        * --------------------------------------------------------------------------------------------
        *  @return         검색된 code에 대한 data set
        * ------------------------------------------------------------------------------------------*/
        getCodeData : function (objCodeDtl, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
            if (!objCodeDtl.hasOwnProperty(module_cd)) {
                objCodeDtl[module_cd] = {};
            }
            $.each(field_cd_pipe.split("|"), function (i, v) {
                if (v != null && v != "") {
                    objCodeDtl[module_cd][v] = [];
                }
            });
            dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
            async: false,
            data: {
                module_cd     : module_cd,
                field_cd_pipe : field_cd_pipe,
                syscode_yn    : syscode_yn,
                base_yn       : base_yn,
                foreign_yn    : foreign_yn,
                end_dt        : end_dt,
                keyword       : keyword
            }
            }).done(function (data) {
                if (data.length > 0) {
                    $.each(data, function (i, obj) {
                        objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
                        tmpCdField = obj.FIELD_CD;
                    });
                }
            }).fail(function (xhr, status, error) {
                dews.error(error);
            });
            return objCodeDtl;
        },

        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           null,undefined,"" 체크
         *  @ex             dataNullCheck(value)
         *  @memo
         *  @return         true, false
         * ------------------------------------------------------------------------------------------*/
        dataNullCheck : function(value) {
            if(!value || value == undefined || value == "") {
                return false;
            }
            return true;
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc          NaN,null,undefined,Infinity 체크
         *  @ex             numberNullCheck(value)
         *  @memo
         *  @return        true, false
         * ------------------------------------------------------------------------------------------*/
        numberNullCheck : function(value) {
          if(isNaN(value)) return 0;
          if(value == -Infinity) return 0;
          return value == ( null || undefined || Infinity ) ? 0 : value;
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           0붙이기
         *  @ex             leadingZeros("1", 2)
         *  @memo           첫번째 파라미터에 두번째 파라미터 수만큼 0을 붙인다
         *  @return         string
         * ------------------------------------------------------------------------------------------*/
        leadingZeros : function(n, digits) {
            var zero = '';
            n = n.toString();

            if (n.length < digits) {
              for (var i = 0; i < digits - n.length; i++)
                zero += '0';
            }
            return zero + n;
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           오늘
         *  @ex             currentDate()
         *  @memo           오늘년월일을 문자로 리턴
         *  @return         string
         * ------------------------------------------------------------------------------------------*/
        currentDate : function() {
          var d = new Date();
          return d.getFullYear().toString() + leadingZeros((d.getMonth() + 1).toString(), 2) + leadingZeros(d.getDate().toString(), 2);
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           현재시간
         *  @ex             currentTime()
         *  @memo           현재시간을 문자로 리턴
         *  @return         string
         * ------------------------------------------------------------------------------------------*/
        currentTime : function() {
          var d = new Date();
          return leadingZeros(d.getHours(), 2) + leadingZeros(d.getMinutes(), 2) + leadingZeros(d.getSeconds(), 2);
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           날짜 문자 변환
         *  @ex             dateToString(date)
         *  @memo           날짜형식을 문자형식으로 리턴
         *  @return         string
         * ------------------------------------------------------------------------------------------*/
        dateToString : function(date) {
          var y = date.getFullYear(),
              m = date.getMonth() + 1,
              d = date.getDate();

          return y + leadingZeros(m, 2) + leadingZeros(d, 2);
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           grid paging merge 처리
         *  @ex             mergeData(data)
         *  @memo           row 시작 번호부터 페이징 사이즈만큼 재조회
         *  @return
         * ------------------------------------------------------------------------------------------*/
        mergeData : function(data) {
          var grid = dews.ui.page.grid == undefined ? dews.ui.dialogPage[dews.ui.dialogPage.$content.find('.dews-ui-grid').attr('id')] : dews.ui.page.grid;
          var serviceUrl = grid.dataSource.options.transport.read.url.split('/'); // 0: "", 1: "api", 2: module, 3: service name, 4: url

          dews.api.get(dews.url.getApiUrl(serviceUrl[2], serviceUrl[3], serviceUrl[4]), {
            async: false,
            data: data
          }).done(function (data) {
            var rawData  = Array.from(grid.dataItems());
            var readData = Array.from(data);

            grid.dataSource.data($.merge(rawData, readData));
          }).fail(function (xhr, satus, error) {
            dews.error(error);
          }).always(function(){
            dews.ui.loading.hide();
          });
        }
    }

    function leadingZeros(n, digits) {
        var zero = '';
        n = n.toString();

        if (n.length < digits) {
            for (var i = 0; i < digits - n.length; i++)
            zero += '0';
        }
        return zero + n;
    }

    //-------------------------------------------End-------------------------------------------

    var newModule = {};
    newModule[moduleCode] = module;
    window.gerp = $.extend(true, gerp, newModule);
  })(window.dews, window.gerp || {}, jQuery);

  //# sourceURL=me.js
