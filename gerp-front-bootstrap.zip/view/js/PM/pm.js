/*
 * @desc    PM 모듈 공통 함수
 * @author
 * @date    2019.05.13
 * @path    /view/js/pm.js
 */
(function (dews, gerp, $) {
    var module = {};
    var moduleCode = 'PM';  //모듈 코드

    //------------------------------------------Start------------------------------------------
    //

    //API
    module.api = {

        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           guid
         *  @ex
         *  @memo           uid 생성
         *  @return         string
         * ------------------------------------------------------------------------------------------*/
        guid : function () {
            return 'xxxxxxxx-xxxx-4xxx-9xxx-xxxxxxxxxxxx'.replace(/[xy]/g,
            function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        },

        /* --------------------------------------------------------------------------------------------
        *  @no
        *  @desc           공통코드조회
        *  @ex
        *  @memo
        * --------------------------------------------------------------------------------------------
        *  @module_cd      모듈코드
        *  @field_cd_pipe  코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
        *  @syscode_yn     시스템코드 유무(Y,N)
        *  @base_yn        디폴트 코드구분(Y,N)
        *  @foreign_yn     외국언어적용 유무(Y,N)- Y : NM_SYSDEF2, N : NM_SYSDEF
        *  @end_dt         종료일-종료일이 있는 경우 종료일 이전 데이터 제외
        *  @keyword        검색할 코드 또는 명
        * --------------------------------------------------------------------------------------------
        *  @return         검색된 code에 대한 data set
        * ------------------------------------------------------------------------------------------*/
        getCodeData : function (objCodeDtl, module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
            if (!objCodeDtl.hasOwnProperty(module_cd)) {
                objCodeDtl[module_cd] = {};
            }
            $.each(field_cd_pipe.split("|"), function (i, v) {
                if (v != null && v != "") {
                    objCodeDtl[module_cd][v] = [];
                }
            });
            dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
            async: false,
            data: {
                module_cd     : module_cd,
                field_cd_pipe : field_cd_pipe,
                syscode_yn    : syscode_yn,
                base_yn       : base_yn,
                foreign_yn    : foreign_yn,
                end_dt        : end_dt,
                keyword       : keyword
            }
            }).done(function (data) {
                if (data.length > 0) {
                    $.each(data, function (i, obj) {
                        objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
                        tmpCdField = obj.FIELD_CD;
                    });
                }
            }).fail(function (xhr, status, error) {
                dews.error(error);
            });
            return objCodeDtl;
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           오늘날짜
         *  @ex             currentDate()
         *  @memo
         *  @return         오늘날짜
         * ------------------------------------------------------------------------------------------*/
        currentDate : function() {
          var d = new Date();
          return d.getFullYear().toString() + leadingZeros((d.getMonth() + 1).toString(), 2) + leadingZeros(d.getDate().toString(), 2);
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           날짜더하기
         *  @ex             addDate(날짜,더하고 싶은 일수)
         *  @memo
         *  @return         날짜string
         * ------------------------------------------------------------------------------------------*/
        addDate : function(date, i) {
          var targetDay = new Date(date.valueOf()+(24*60*60*1000)*i);
          ty = targetDay.getFullYear();
          tm = targetDay.getMonth() + 1;
          td = targetDay.getDate();
          return String(ty) + leadingZeros(String(tm), 2) + leadingZeros(String(td), 2);
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           null,undefined,"" 체크
         *  @ex             dataNullCheck(value)
         *  @memo
         *  @return         true, false
         * ------------------------------------------------------------------------------------------*/
        dataNullCheck : function(value) {
            if(!value || value == undefined || value == "") {
                return false;
            }
            return true;
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           0붙이기
         *  @ex             leadingZeros("1", 2)
         *  @memo           첫번째 파라미터에 두번째 파라미터 수만큼 0을 붙인다
         *  @return         string
         * ------------------------------------------------------------------------------------------*/
        leadingZeros : function(n, digits) {
            var zero = '';
            n = n.toString();

            if (n.length < digits) {
              for (var i = 0; i < digits - n.length; i++)
                zero += '0';
            }
            return zero + n;
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           grid paging merge 처리
         *  @ex             mergeData()
         *  @memo           row 시작 번호부터 페이징 사이즈만큼 재조회
         *  @return
         * ------------------------------------------------------------------------------------------*/
        mergeData : function(data) {
          var grid = dews.ui.page.grid;
          var serviceUrl = grid.dataSource.options.transport.read.url.split('/'); // 0: "", 1: "api", 2: module, 3: service name, 4: url

          dews.api.get(dews.url.getApiUrl(serviceUrl[2], serviceUrl[3], serviceUrl[4]), {
            async: false,
            data: data
          }).done(function (data) {
            var rawData  = Array.from(grid.dataItems());
            var readData = Array.from(data);

            grid.dataSource.data($.merge(rawData, readData));
          }).fail(function (xhr, satus, error) {
            dews.error(error);
          }).always(function(){
            dews.ui.loading.hide();
          });
        },
        /* --------------------------------------------------------------------------------------------
         *  @no
         *  @desc           설비관리 단위 조회
         *  @ex             getPmUnit()
         *  @memo           설비관리 단위메뉴에 등록된 단위 조회
         *  @return
         * ------------------------------------------------------------------------------------------*/
        getPmUnit : function(module_cd,field_cd,sysdef_cd) {
          var unitList = [];
          dews.api.get(dews.url.getApiUrl("PM", "PmCommonService", dews.string.format("UNIT_CD_list")), {
            async: false,
            data: {
                module_cd     : module_cd,
                field_cd      : field_cd,
                sysdef_cd     : sysdef_cd,
            }
            }).done(function (data) {
                if (data.length > 0) {
                    unitList = data;
                }
            }).fail(function (xhr, status, error) {
                dews.error(error);
            });
            return unitList;
        }
    }

    function leadingZeros(n, digits) {
      var zero = '';
      n = n.toString();

      if (n.length < digits) {
          for (var i = 0; i < digits - n.length; i++)
          zero += '0';
      }
      return zero + n;
    }

    //-------------------------------------------End-------------------------------------------

    var newModule = {};
    newModule[moduleCode] = module;
    window.gerp = $.extend(true, gerp, newModule);
  })(window.dews, window.gerp || {}, jQuery);

  //# sourceURL=pm.js
