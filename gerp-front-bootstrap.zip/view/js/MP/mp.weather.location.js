/*
 * MP 모듈 공통 함수
 * /view/js/mp.weather.location.js
 */
(function (dews, gerp, $) {
    var module = {};
    var moduleCode = 'MP'; //모듈 코드

    module.Weather = {
        WeatherUtil: function () {
            return {
                getWeatherLocation: function () {
                    return weatherLocation;
                },
            };
        }
    };

    var newModule = {};
    newModule[moduleCode] = module;
    window.gerp = $.extend(true, gerp, newModule);

})(window.dews, window.gerp || {}, jQuery);

const weatherLocation = [
    {
        "CODE": "69,133",
        "CODE_NM": "가평군"
    },
    {
        "CODE": "92,131",
        "CODE_NM": "강릉시"
    },
    {
        "CODE": "57,63",
        "CODE_NM": "강진군"
    },
    {
        "CODE": "51,130",
        "CODE_NM": "강화군"
    },
    {
        "CODE": "90,69",
        "CODE_NM": "거제시"
    },
    {
        "CODE": "91,90",
        "CODE_NM": "경산시"
    },
    {
        "CODE": "100,91",
        "CODE_NM": "경주시"
    },
    {
        "CODE": "65,99",
        "CODE_NM": "계룡시"
    },
    {
        "CODE": "83,87",
        "CODE_NM": "고령군"
    },
    {
        "CODE": "85,145",
        "CODE_NM": "고성군(강원)"
    },
    {
        "CODE": "85,71",
        "CODE_NM": "고성군(경남)"
    },
    {
        "CODE": "57,128",
        "CODE_NM": "고양시"
    },
    {
        "CODE": "56,80",
        "CODE_NM": "고창군"
    },
    {
        "CODE": "66,62",
        "CODE_NM": "고흥군"
    },
    {
        "CODE": "66,77",
        "CODE_NM": "곡성군"
    },
    {
        "CODE": "63,102",
        "CODE_NM": "공주시"
    },
    {
        "CODE": "60,124",
        "CODE_NM": "과천시"
    },
    {
        "CODE": "58,125",
        "CODE_NM": "광명시"
    },
    {
        "CODE": "58,74",
        "CODE_NM": "광주광역시"
    },
    {
        "CODE": "65,123",
        "CODE_NM": "광주시"
    },
    {
        "CODE": "74,111",
        "CODE_NM": "괴산군"
    },
    {
        "CODE": "62,127",
        "CODE_NM": "구리시"
    },
    {
        "CODE": "84,96",
        "CODE_NM": "구미시"
    },
    {
        "CODE": "56,92",
        "CODE_NM": "군산시"
    },
    {
        "CODE": "88,99",
        "CODE_NM": "군위군"
    },
    {
        "CODE": "59,122",
        "CODE_NM": "군포시"
    },
    {
        "CODE": "69,95",
        "CODE_NM": "금산군"
    },
    {
        "CODE": "100,77",
        "CODE_NM": "기장군"
    },
    {
        "CODE": "59,88",
        "CODE_NM": "김제시"
    },
    {
        "CODE": "80,96",
        "CODE_NM": "김천시"
    },
    {
        "CODE": "55,128",
        "CODE_NM": "김포시"
    },
    {
        "CODE": "95,77",
        "CODE_NM": "김해시"
    },
    {
        "CODE": "56,71",
        "CODE_NM": "나주시"
    },
    {
        "CODE": "64,128",
        "CODE_NM": "남양주시"
    },
    {
        "CODE": "77,68",
        "CODE_NM": "남해군"
    },
    {
        "CODE": "62,97",
        "CODE_NM": "논산시"
    },
    {
        "CODE": "84,115",
        "CODE_NM": "단양군"
    },
    {
        "CODE": "61,78",
        "CODE_NM": "담양군"
    },
    {
        "CODE": "54,112",
        "CODE_NM": "당진시"
    },
    {
        "CODE": "89,90",
        "CODE_NM": "대구광역시"
    },
    {
        "CODE": "67,100",
        "CODE_NM": "대전광역시"
    },
    {
        "CODE": "61,134",
        "CODE_NM": "동두천시"
    },
    {
        "CODE": "97,127",
        "CODE_NM": "동해시"
    },
    {
        "CODE": "50,67",
        "CODE_NM": "목포시"
    },
    {
        "CODE": "52,71",
        "CODE_NM": "무안군"
    },
    {
        "CODE": "92,83",
        "CODE_NM": "밀양시"
    },
    {
        "CODE": "62,66",
        "CODE_NM": "보성군"
    },
    {
        "CODE": "73,103",
        "CODE_NM": "보은군"
    },
    {
        "CODE": "90,113",
        "CODE_NM": "봉화군"
    },
    {
        "CODE": "98,76",
        "CODE_NM": "부산광역시"
    },
    {
        "CODE": "56,87",
        "CODE_NM": "부안군"
    },
    {
        "CODE": "59,99",
        "CODE_NM": "부여군"
    },
    {
        "CODE": "56,125",
        "CODE_NM": "부천시"
    },
    {
        "CODE": "80,71",
        "CODE_NM": "사천시"
    },
    {
        "CODE": "76,80",
        "CODE_NM": "산청군"
    },
    {
        "CODE": "98,125",
        "CODE_NM": "삼척시"
    },
    {
        "CODE": "81,102",
        "CODE_NM": "상주시"
    },
    {
        "CODE": "52,33",
        "CODE_NM": "서귀포시"
    },
    {
        "CODE": "51,110",
        "CODE_NM": "서산시"
    },
    {
        "CODE": "60,127",
        "CODE_NM": "서울특별시"
    },
    {
        "CODE": "55,76",
        "CODE_NM": "서천군"
    },
    {
        "CODE": "63,124",
        "CODE_NM": "성남시"
    },
    {
        "CODE": "83,91",
        "CODE_NM": "성주군"
    },
    {
        "CODE": "87,141",
        "CODE_NM": "속초시"
    },
    {
        "CODE": "60,121",
        "CODE_NM": "수원시"
    },
    {
        "CODE": "63,79",
        "CODE_NM": "순창군"
    },
    {
        "CODE": "70,70",
        "CODE_NM": "순천시"
    },
    {
        "CODE": "57,123",
        "CODE_NM": "시흥시"
    },
    {
        "CODE": "50,66",
        "CODE_NM": "신안군"
    },
    {
        "CODE": "60,110",
        "CODE_NM": "아산시"
    },
    {
        "CODE": "91,106",
        "CODE_NM": "안동시"
    },
    {
        "CODE": "58,121",
        "CODE_NM": "안산시"
    },
    {
        "CODE": "65,115",
        "CODE_NM": "안성시"
    },
    {
        "CODE": "59,123",
        "CODE_NM": "안양시"
    },
    {
        "CODE": "97,79",
        "CODE_NM": "양산시"
    },
    {
        "CODE": "88,138",
        "CODE_NM": "양양군"
    },
    {
        "CODE": "61,131",
        "CODE_NM": "양주시"
    },
    {
        "CODE": "73,66",
        "CODE_NM": "여수시"
    },
    {
        "CODE": "72,121",
        "CODE_NM": "여주군"
    },
    {
        "CODE": "61,138",
        "CODE_NM": "연천군"
    },
    {
        "CODE": "74,97",
        "CODE_NM": "영동군"
    },
    {
        "CODE": "86,119",
        "CODE_NM": "영월군"
    },
    {
        "CODE": "58,107",
        "CODE_NM": "예산군"
    },
    {
        "CODE": "86,107",
        "CODE_NM": "예천군"
    },
    {
        "CODE": "62,118",
        "CODE_NM": "오산시"
    },
    {
        "CODE": "71,99",
        "CODE_NM": "옥천군"
    },
    {
        "CODE": "54,124",
        "CODE_NM": "옹진군"
    },
    {
        "CODE": "57,56",
        "CODE_NM": "완도군"
    },
    {
        "CODE": "62,91",
        "CODE_NM": "완주군"
    },
    {
        "CODE": "64,119",
        "CODE_NM": "용인시"
    },
    {
        "CODE": "102,84",
        "CODE_NM": "울산광역시"
    },
    {
        "CODE": "102,115",
        "CODE_NM": "울진군"
    },
    {
        "CODE": "76,122",
        "CODE_NM": "원주시"
    },
    {
        "CODE": "72,113",
        "CODE_NM": "음성군"
    },
    {
        "CODE": "83,78",
        "CODE_NM": "의령군"
    },
    {
        "CODE": "90,101",
        "CODE_NM": "의성군"
    },
    {
        "CODE": "60,122",
        "CODE_NM": "의왕시"
    },
    {
        "CODE": "61,130",
        "CODE_NM": "의정부시"
    },
    {
        "CODE": "68,121",
        "CODE_NM": "이천시"
    },
    {
        "CODE": "60,91",
        "CODE_NM": "익산시"
    },
    {
        "CODE": "80,138",
        "CODE_NM": "인제군"
    },
    {
        "CODE": "55,124",
        "CODE_NM": "인천광역시"
    },
    {
        "CODE": "66,84",
        "CODE_NM": "임실군"
    },
    {
        "CODE": "57,77",
        "CODE_NM": "장성군"
    },
    {
        "CODE": "63,89",
        "CODE_NM": "전주시"
    },
    {
        "CODE": "89,123",
        "CODE_NM": "정선군"
    },
    {
        "CODE": "58,83",
        "CODE_NM": "정읍시"
    },
    {
        "CODE": "53,38",
        "CODE_NM": "제주시"
    },
    {
        "CODE": "81,118",
        "CODE_NM": "제천시"
    },
    {
        "CODE": "71,110",
        "CODE_NM": "증평군"
    },
    {
        "CODE": "81,75",
        "CODE_NM": "진주시"
    },
    {
        "CODE": "68,111",
        "CODE_NM": "진천군"
    },
    {
        "CODE": "87,83",
        "CODE_NM": "창녕군"
    },
    {
        "CODE": "90,77",
        "CODE_NM": "창원시"
    },
    {
        "CODE": "63,110",
        "CODE_NM": "천안시"
    },
    {
        "CODE": "65,139",
        "CODE_NM": "철원군"
    },
    {
        "CODE": "91,86",
        "CODE_NM": "청도군"
    },
    {
        "CODE": "69,106",
        "CODE_NM": "청주시"
    },
    {
        "CODE": "73,134",
        "CODE_NM": "춘천시"
    },
    {
        "CODE": "76,114",
        "CODE_NM": "충주시"
    },
    {
        "CODE": "85,93",
        "CODE_NM": "칠곡군"
    },
    {
        "CODE": "95,119",
        "CODE_NM": "태백시"
    },
    {
        "CODE": "48,109",
        "CODE_NM": "태안군"
    },
    {
        "CODE": "87,68",
        "CODE_NM": "통영시"
    },
    {
        "CODE": "56,131",
        "CODE_NM": "파주시"
    },
    {
        "CODE": "84,123",
        "CODE_NM": "평창군"
    },
    {
        "CODE": "62,114",
        "CODE_NM": "평택시"
    },
    {
        "CODE": "64,134",
        "CODE_NM": "포천시"
    },
    {
        "CODE": "102,94",
        "CODE_NM": "포항시"
    },
    {
        "CODE": "64,126",
        "CODE_NM": "하남시"
    },
    {
        "CODE": "74,73",
        "CODE_NM": "하동군"
    },
    {
        "CODE": "86,77",
        "CODE_NM": "함안군"
    },
    {
        "CODE": "54,61",
        "CODE_NM": "해남군"
    },
    {
        "CODE": "55,106",
        "CODE_NM": "홍성군"
    },
    {
        "CODE": "75,130",
        "CODE_NM": "홍천군"
    },
    {
        "CODE": "57,119",
        "CODE_NM": "화성시"
    },
    {
        "CODE": "61,72",
        "CODE_NM": "화순군"
    },
    {
        "CODE": "72,139",
        "CODE_NM": "화천군"
    },
    {
        "CODE": "77,125",
        "CODE_NM": "횡성군"
    },
    {
        "CODE": "66,103",
        "CODE_NM": "세종특별자치시"
    }
]

//# sourceURL=mp.weather.location.js