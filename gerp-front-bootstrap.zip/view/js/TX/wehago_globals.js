/**
 * Wehago Object
 */
 var url = new URL(window.document.location.href);
 var drs_cd = url.searchParams.get('drs_cd');

 var service_code = "derp";
 if(drs_cd == "10072"){
  service_code = "hanwhalife";
} else if(drs_cd == "10029"){
  service_code = "byucksan";
} else if(drs_cd == "10091"){
  service_code = "smlab";
} else if(drs_cd == "10098"){
  service_code = "gyceramics";
} else if(drs_cd == "10096"){
  service_code = "incar";
} else if(drs_cd == "10080"){
  service_code = "dermafirm";
} else if(drs_cd == "10081"){
  service_code = "wowventures";
} else if(drs_cd == "10093"){   
  service_code = "cartini";
} else if(drs_cd == "10067"){   
  service_code = "idispowertel";
} else if(drs_cd == "10088"){     //아이에이치큐
  service_code = "ihq";
} else if(drs_cd == "10143"){     //한국성장금융투자운용
  service_code = "kgrowth";
} else if(drs_cd == "10132"){     //하이라이트브랜즈
  service_code = "hilightbrands";
} else if(drs_cd == "10114"){     //에스케이핀크스(주)
  service_code = "thepinx";
} else if(drs_cd == "10095"){     //(주)에이치이엠파마 광교지점
  service_code = "hem";
} else if(drs_cd == "10075"){
  service_code = "donga";
}
 ;var wehago_globals = {
     service_code: service_code,   // 발급받은 코드
    mode : "live",   // dev-개발, live-운영
};
