/*********************************************
 * TX 모듈 세무 공통 유틸 함수
 *
 * 		-	2020-02-19 wrote by ironman
 * 		-	메뉴내 반복적인 js 공통함수들 정의
 *********************************************/
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'TX';

  if (!Array.prototype.find) {
    Array.prototype.find = function (predicate) {
      'use strict';
      if (this == null) {
        throw new TypeError('Array.prototype.find called on null or undefined');
      }
      if (typeof predicate !== 'function') {
        throw new TypeError('predicate must be a function');
      }
      var list = Object(this);
      var length = list.length >>> 0;
      var thisArg = arguments[1];
      var value;

      for (var i = 0; i < length; i++) {
        value = list[i];
        if (predicate.call(thisArg, value, i, list)) {
          return value;
        }
      }
      return undefined;
    };
  }

  if (!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
      value: function (predicate) {
        'use strict';
        if (this == null) {
          throw new TypeError('Array.prototype.findIndex called on null or undefined');
        }
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }
        var list = Object(this);
        var length = list.length >>> 0;
        var thisArg = arguments[1];
        var value;

        for (var i = 0; i < length; i++) {
          value = list[i];
          if (predicate.call(thisArg, value, i, list)) {
            return i;
          }
        }
        return -1;
      },
      enumerable: false,
      configurable: false,
      writable: false
    });
  }

  module.COMMON = (function () {
    return {

      globalVariables : {},
      wInvoiceInstance : {},
      initializeWehagoApi : function() {
    	  var txComm = this;

    	  var promise = function(){
    	        return new Promise(function(resolve){
    	          var targetJsCount = 5;
    	          var loadJsCount = 0;

    	          dews.ajax.script('https://static.wehago.com/support/jquery/jquery.cookie.js', { once: true, async: false }).done(function () {
    	        	  loadJsCount++;
    	        	  if(loadJsCount == targetJsCount) {
    	        		  resolve();
    	        	  }
    	        	  console.log('jquery.cookie.js loaded.');
    	          });
    	          dews.ajax.script('https://static.wehago.com/support/wehago.0.1.2.js', { once: true, async: false }).done(function () {
    	        	  loadJsCount++;
    	        	  if(loadJsCount == targetJsCount) {
    	        		  resolve();
    	        	  }
    	        	  console.log('wehago.0.1.2.js loaded.');
    	          });
    	          dews.ajax.script('https://static.wehago.com/support/wehagoLogin-1.0.5.min.js', { once: true, async: false }).done(function () {
    	        	  loadJsCount++;
    	        	  if(loadJsCount == targetJsCount) {
    	        		  resolve();
    	        	  }
    	        	  console.log('wehagoLogin-1.0.5.min.js loaded.');
    	          });
    	          dews.ajax.script('https://static.wehago.com/support/service/common/wehagoCommon-0.1.9.min.js', { once: true, async: false }).done(function(){
    	        	  loadJsCount++;
    	        	  if(loadJsCount == targetJsCount) {
    	        		  resolve();
    	        	  }
    	        	  console.log('wehagoCommon-0.1.9.min.js loaded.');
    	          });
    	          dews.ajax.script('https://static.wehago.com/support/service/invoice/wehagoInvoice-0.0.4.min.js', { once: true, async: false }).done(function (){
    	        	  loadJsCount++;
    	        	  if(loadJsCount == targetJsCount) {
    	        		  resolve();
    	        	  }
    	        	  console.log('wehagoInvoice-0.0.4.min.js loaded.');
    	          });
    	        })
    	    };

    	    promise().then(function(){
    	    	txComm.createWehagoInvoice();
    	    });
      },
      createWehagoInvoice : function(){
    	  var txComm = this;
    	  var app_key = "3d2f118b2fdf4a77b5264800bde130eb";
        var service_code = "derp";
        if(dews.app.drsCode == "10072"){
          app_key = "4718496BACFB4E0E877898B441437731";
          service_code = "hanwhalife";
        } else if(dews.app.drsCode == "10029"){
          app_key = "0da924f354064a11bae048e64ec7d583";
          service_code = "byucksan";
        } else if(dews.app.drsCode == "10091"){
          app_key = "e126a4c2e8774f229da589e4a7202e9b";
          service_code = "smlab";
        } else if(dews.app.drsCode == "10098"){
          app_key = "92efaa13a1ae49b68ef623552d5057b7";
          service_code = "gyceramics";
        } else if(dews.app.drsCode == "10096"){
          app_key = "6f2f9e73048a401eb0548535c44b15e9";
          service_code = "incar";
        } else if(dews.app.drsCode == "10080"){     //더마펌
          app_key = "f200007015344970ba24beb716604981";
          service_code = "dermafirm";
        } else if(dews.app.drsCode == "10081"){     //와우벤처스
          app_key = "218dea8374ca46e1a9d74c9bbb7ed76b";
          service_code = "wowventures";
        } else if(dews.app.drsCode == "10093"){     //카티니
          app_key = "04a090f64c004d9f9444fbcae6deebd2";
          service_code = "cartini";
        } else if(dews.app.drsCode == "10067"){     //아이디스파워텔
          app_key = "7947470d8f654865a5a955cb6edb3414";
          service_code = "idispowertel";
        } else if(dews.app.drsCode == "10088"){     //아이에이치큐
          app_key = "b3b343c4db8945898be3a321b750c50c";
          service_code = "ihq";
        } else if(dews.app.drsCode == "10143"){     //한국성장금융투자운용
          app_key = "13979568cad141f5aad4fec9445532ba";
          service_code = "kgrowth";
        } else if(dews.app.drsCode == "10132"){     //하이라이트브랜즈
          app_key = "ffb87ac66a22400fa666d89fe382bc3c";
          service_code = "hilightbrands";
        } else if(dews.app.drsCode == "10114"){     //에스케이핀크스(주)
          app_key = "6190e879539746899bb16f60c62e8640";
          service_code = "thepinx";
        } else if(dews.app.drsCode == "10114"){     //(주)에이치이엠파마 광교지점
          app_key = "54f541525f7a4ebd82907130d1dfd23d";
          service_code = "hem";
        } else if(dews.app.drsCode == "10075"){
          app_key = "4f02201b5050401ab91e93fce752def7";
          service_code = "donga";
        }


    	  if(txComm.isValidateIntelockingStatusByWehago() == true) {
    		  txComm.wInvoiceInstance = new wehago_invoice({
    			  app_key: app_key,
    			  service_code: service_code,
    			  redirect_uri: "http://" + txComm.getDomain() + "/view/TX/WEHAGO_LOGIN?drs_cd="+dews.app.drsCode,
    			  mode: "live",
    			  access_token : $.cookie(service_code+"_access_token")
    		  });
    	  }
      },
      isValidateIntelockingStatusByWehago : function(){
    	  var txComm = this;
        var service_code = "derp";
        if(dews.app.drsCode == "10072"){
          service_code = "hanwhalife";
        } else if(dews.app.drsCode == "10029"){
          service_code = "byucksan";
        } else if(dews.app.drsCode == "10091"){
          service_code = "smlab";
        } else if(dews.app.drsCode == "10098"){
          service_code = "gyceramics";
        } else if(dews.app.drsCode == "10096"){
          service_code = "incar";
        } else if(dews.app.drsCode == "10080"){
          service_code = "dermafirm";
        } else if(dews.app.drsCode == "10081"){
          service_code = "wowventures";
        } else if(dews.app.drsCode == "10093"){     //카티니
          service_code = "cartini";
        } else if(dews.app.drsCode == "10067"){     //아이디스파워텔
          service_code = "idispowertel";
        } else if(dews.app.drsCode == "10088"){     //아이에이치큐
          service_code = "ihq";
        } else if(dews.app.drsCode == "10143"){     //한국성장금융투자운용
          service_code = "kgrowth";
        } else if(dews.app.drsCode == "10132"){     //하이라이트브랜즈
          service_code = "hilightbrands";
        } else if(dews.app.drsCode == "10114"){     //에스케이핀크스(주)
          service_code = "thepinx";
        } else if(dews.app.drsCode == "10095"){     //(주)에이치이엠파마 광교지점
          service_code = "hem";
        } else if(dews.app.drsCode == "10075"){
          service_code = "donga";
        }
    	  if(txComm.isSafeValue($.cookie(service_code+'_token')) && txComm.isSafeValue($.cookie(service_code+'_selected_company_no')) &&
			  txComm.isSafeValue($.cookie(service_code+'_access_token'))) {
		  return true;
		}
		else {
		  return false;
		}
      },
      /**********************
       * 대량의 데이터를 작업 단위를 나누는 프로세스
       * 100개 이하 - 10건씩
       * 500개 이하 - 20건씩
       **********************/
      getWorkSliceCount : function(totalCount) {
    	  var slice = totalCount / 100;

    	  if(slice >= 50) slice = 49; // 50으로 딱떨어지면 1자리 숫자에 변함이 없는 프로그레스가 만들어

          if(slice < 1) {
            if(totalCount > 2)
              slice = 2;
            else
              slice = 1;
          }

          console.log('tx.common.js →  getWorkSliceCount('+ totalCount.toLocaleString() +') → return ' + slice.toLocaleString());
          return slice;
      },
      /**********************
       * 안전한 값인지 검사
       **********************/
      isSafeValue: function (value) {
		var txComm = this;
		if(value == undefined)
		    return false;
		if(value == null)
			return false;
		if(value == "null")
			return false;
		if(value.length == 0)
			return false;
		if(txComm.replaceAll(value,' ','').length == 0)
			return false;
		return true;
      },
      /**********************
       * 문자열에서 전체 값 변경
       **********************/
      replaceAll : function(str, searchStr, replaceStr) {
    	  return str.split(searchStr).join(replaceStr);
      },
      /**********************
       * 도메인 가져오기
       **********************/
      getDomain : function() {
    	  var url = window.location.hostname;
    	  if(location.port != null && location.port != '' && location.port != '80' && location.port != '443'){
    		  url +=":" + location.port;
    	  }
    	  return url;
      },
      /**********************
       * 전화번호를 3개의 배열로 반환
       **********************/
      getTelPhoneSpliter : function(noStr) {
    	  var txComm = this;
    	  var output = ['','',''];
          //유효성 검사
          if (!txComm.isSafeValue(noStr) || noStr.length < 9)
              return output;

          //첫번째 자리
          if (noStr.startsWith("02")) {
              output[0] = noStr.substring(0, 2);
              noStr = noStr.substring(2, noStr.length);
          }
          else {
              output[0] = noStr.substring(0, 3);
              noStr = noStr.substring(3, noStr.length);
          }

          if (noStr.length == 8) {
              output[1] = noStr.substring(0, 4);
              noStr = noStr.substring(4, noStr.length);
          }
          else {
              output[1] = noStr.substring(0, 3);
              noStr = noStr.substring(3, noStr.length);
          }

          //마지막 자리
          output[2] = noStr.substring(0,noStr.length);
          return output;
      },
      /**********************
       * 전달된 날짜를 포맷으로 반환
       **********************/
      isValidityDate : function(yyyymmdd) {
    	  var currVal = yyyymmdd;

    	  if (currVal == '')
    		  return false;

    	  var rxDatePattern = /^(\d{4})(\d{1,2})(\d{1,2})$/;
    	  var dtArray = currVal.match(rxDatePattern);

    	  if (dtArray == null)
    		  return false;

    	  dtYear = dtArray[1];
    	  dtMonth = dtArray[2];
    	  dtDay = dtArray[3];

    	  if (dtMonth < 1 || dtMonth > 12)
    		  return false;
    	  else if (dtDay < 1 || dtDay > 31)
    		  return false;
    	  else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31)
    		  return false;
    	  else if (dtMonth == 2) {
    		  var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
    		  if (dtDay > 29 || (dtDay == 29 && !isleap))
    			  return false;
    	  }
    	  return true;
      },
      getYyyymmdd : function(date) {
    	  var yyyy = date.getFullYear().toString();
    	  var mm = (date.getMonth() + 1).toString();
    	  var dd = date.getDate().toString();
    	  return yyyy + (mm[1] ? mm : '0'+mm[0]) + (dd[1] ? dd : '0'+dd[0]);
      },
      getMmdd : function(date) {
    	  var mm = (date.getMonth() + 1).toString();
    	  var dd = date.getDate().toString();
    	  return (mm[1] ? mm : '0'+mm[0]) + (dd[1] ? dd : '0'+dd[0]);
      },
      getTelPhoneDashStyle : function(noStr) {
    	  var txComm = this;
    	  if(!txComm.isSafeValue(noStr)){
    		  return '';
    	  }
    	  var formatNum = '';
    	  var type = '1'; // '0' 이면 가운데자리를 별표시함.
    	  noStr = txComm.replaceAll(noStr,'-','');

    	  if(noStr.length==11){
    		  	if(type==0){
    		  		formatNum = noStr.replace(/(\d{3})(\d{4})(\d{4})/, '$1-****-$3');
    		  	}
    		  	else{
    		  		formatNum = noStr.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
    		  	}
    	  }
    	  else if(noStr.length==8){
    		  formatNum = noStr.replace(/(\d{4})(\d{4})/, '$1-$2');
    	  }
    	  else{
    		  if(noStr.indexOf('02')==0){
    			  if(type==0){
    				  formatNum = noStr.replace(/(\d{2})(\d{4})(\d{4})/, '$1-****-$3');
    			  }
    			  else{
    				  formatNum = noStr.replace(/(\d{2})(\d{4})(\d{4})/, '$1-$2-$3');
    			  }
    		  }
    		  else{
    			  if(type==0){
    				  formatNum = noStr.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3');
    			  }
    			  else{
    				  formatNum = noStr.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
    			  }
    		  }
    	  }
    	  return formatNum;
      },
      /**********************
       *
       **********************/
      test : function(e){

      },
      getDRS_CODE: function() {
        return dews.app.drsCode;
      },
      isNull: function(value) {
        //	undefined || null  = null
      if (value == undefined || value == null) return true;

      //	문자열 빈값 = null
      if (typeof value == "string" && value == "") return true;

      //	Object type( Array,Object)
      if (typeof value == "object") {
        if (value.constructor == Object)	// 변수 = 객체인경우 요소 여부만 체크
        {
          var keys = Object.keys(value);

          if (keys.length == 0) return true;
        }
        else if (value.constructor == Array)	// 변수 = 배열인경우 배열 갯수 체크
        {
          if (value.length == 0) return true;
        }
      }

      return false;
      }
    };
})();

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=tx.common.js
