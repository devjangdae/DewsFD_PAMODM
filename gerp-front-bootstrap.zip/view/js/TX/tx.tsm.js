/*
 * TX 모듈 세무 원천세 공통 함수
 */
(function (dews, gerp, $) {
  var module = {};

  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'TX'; // 모듈 코드를 입력 해주세요.

  //////// Polyfill
  if (!Array.prototype.find) {
    Array.prototype.find = function (predicate) {
      'use strict';
      if (this == null) {
        throw new TypeError('Array.prototype.find called on null or undefined');
      }
      if (typeof predicate !== 'function') {
        throw new TypeError('predicate must be a function');
      }
      var list = Object(this);
      var length = list.length >>> 0;
      var thisArg = arguments[1];
      var value;

      for (var i = 0; i < length; i++) {
        value = list[i];
        if (predicate.call(thisArg, value, i, list)) {
          return value;
        }
      }
      return undefined;
    };
  }

  if (!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
      value: function (predicate) {
        'use strict';
        if (this == null) {
          throw new TypeError('Array.prototype.findIndex called on null or undefined');
        }
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }
        var list = Object(this);
        var length = list.length >>> 0;
        var thisArg = arguments[1];
        var value;

        for (var i = 0; i < length; i++) {
          value = list[i];
          if (predicate.call(thisArg, value, i, list)) {
            return i;
          }
        }
        return -1;
      },
      enumerable: false,
      configurable: false,
      writable: false
    });
  }

  // 공통 함수 정의
  module.TSM = (function () {
    var CLOSE = '9';
    var closedMenu;

    return {
      ////////////////////////////////// 속성 영역
      /**
       * 공용 메시지
       */
      messages: {
        search: {
          not_saved: '저장하지 않은 데이터가 있습니다.' + '\n' + '조회를 계속하시겠습니까?',
          // cancel: '취소되었습니다.'
        },
        edit: {
          closed: '마감 되었습니다.',
          notRecent: '다음 차수가 존재합니다.'
        },
        delete: {
          no_rows: {
            grid: '삭제할 항목을 체크해 주십시오.',
            cardlist: '삭제할 항목을 선택해 주십시오.'
          },
          ask: '삭제 하시겠습니까?' + '\n' + '(반드시 저장을 하셔야 반영이 됩니다.)'
        },
        save: {
          ask: '저장하시겠습니까?',
          no_dirty: '저장할 데이터가 없습니다.',
          done: '저장이 완료되었습니다.',
          error: '자료를 저장하는 중 오류가 발생되었습니다.',
          cancel: '취소하였습니다.',
          verify: '필수항목을 입력하지 않았습니다.',
          saving: '저장하는 중입니다.'
        },
        closing: {
          not_saved: '저장하지 않은 데이터가 있습니다.' + '\n' + '닫기를 계속하시겠습니까?'
        },
        btn_load: {
          no_options: '불러오기 할 수 있는 항목이 없습니다.',
          done: '불러오기가 완료되었습니다.'
        },
        btn_removeAll: {
          ask: '<p align="left">' +
            '신고방식 : {0}\n' +
            '사 업 장 : {1}\n' +
            '과세기간 : {2}~{3}\n' +
            '신고구분 : {4}\n' +
            '입력된 데이터를 모두 삭제합니다.\n' +
            '삭제하시겠습니까?</p>',
          done: '일괄삭제가 완료되었습니다.'
        },
        btn_subBizArea: {
          no_code: '사업장 코드를 입력하십시오.'
        },
        btn_openDocu: {
          not_available: '전표이동 할 항목을 선택해 주십시오.',
          not_docuData: '전표에서 불러오기 한 항목이 아닙니다.'
        }
      },
      /**
       * 공용 타이틀 혹은 텍스트
       */
      titles: {
        bizarea_cd: '사업장',
        dept_cd: '부서',
        pjt_cd: '프로젝트',
        incmper_no: '소득자',
        btn_printDate: '출력일',
        btn_build_media: '파일작성',
        btn_taxAgency: '세무대리인',
        btn_openDocu: '전표이동',
        yy_impute: '귀속연도',
        tp_adjust: '정산구분',
        emp_no: '사원번호',
        pay_dt: '지급일자',
        data_cd: '소득구분'
      },
      /**
       * 데이터 셋
       */
      dataSet: {},
      /**
       * 공용 컴포넌트 ID 목록
       */
      componentId: {
        bizarea_cd: 'oCD_BIZAREA',
        bizarea_cd2: 'oBIZAREA_CD2',
        common_bizarea_cd: 'oBIZAREA_CD', // 공통사업장
        common_bizarea_cd2: 'oBIZAREA_CD3', // 공통사업장
        common_bizarea_cd3: 'oBIZAREA_CD4', // 공통사업장 (원천세신고지설정 tab 추가로 컴포넌트 추가)
        common_bizarea_cd4: 'oBIZAREA_CD5', // 공통사업장 (원천세신고지설정 tab 추가로 컴포넌트 추가)
        dept_cd: 'oCD_DEPT',
        pjt_cd: 'oCD_PJT',
        incmper_no: 'oNO_PER',
        btn_printDate: 'btn_printDate', // 출력일
        btn_build_media: 'btn_build_media', // 파일작성
        btn_taxAgency: 'btn_taxAgency', // 세무대리인
        btn_openDocu: 'btn_openDocu', // 전표이동
        yy_impute: 'oYY_IMPUTE', // 귀속연도
        tp_adjust: 'oTP_ADJUST', // 정산구분
        emp_no: 'oNO_EMP', // 사원번호
        pay_dt: 'oDT_PAY', // 지급일자
        ym_income: 'oYM_INCOME', // 귀속년월
        data_cd: 'oCD_DATA' // 소득구분
      },
      /**
       * 그리드 컴포넌트 종류 ( grid, cardlist... )
       */
      gridTypes: {
        grid: 'grid',
        cardlist: 'cardlist'
      },

      globalVariables: {},

      ////////////////////////////////// 메서드 영역
      /**
       * dews ui component 에서 dom 상의 element 를 추출
       * @example var element = VC.getElement(dewself.tp_bizarea);
       * @param {DEWS Component} component DEWS ui 컴포넌트
       * @returns {DOM element} element
       */
      getElement: function (component) {
        if (component.hasOwnProperty('_element')) return component._element;
        if (component.hasOwnProperty('element')) {
          if (component.element.hasOwnProperty('context')) return component.element.context;
          return component.element;
        }
        return null;
      },

      normalizeParameter: function (value, defaultValue) {
        if (typeof value === 'function') {
          value = value();
        }
        if (this.isNotNull(value) == false && this.isNotNull(defaultValue)) {
          value = defaultValue;
        }

        return value;
      },
      jsonToXml: function (json) {
        var self = this;
        var isObject = function (val) {
          return val !== null && ((typeof val === 'function') || (typeof val === 'object'));
        }

        function _getNode(json, node, doc) {
          for (var key in json) {
            if (json.hasOwnProperty(key)) {
              var val = self.normalizeParameter(json[key]);
              var el = doc.createElement(key);
              var _isObject = isObject(val);
              if (_isObject === false) {
                $(el).text(val);
              }
              node.appendChild(el);
              if (_isObject === true) {
                _getNode(val, el, doc);
              }
            }
          }
        }
        var doc = $.parseXML('<xml/>');
        var xml = doc.getElementsByTagName('xml')[0];
        _getNode(json, xml, doc);
        var htmlString = xml.outerHTML;
        if (typeof htmlString === 'undefined' && XMLSerializer) {
          htmlString = new XMLSerializer().serializeToString(xml);
        }
        return htmlString;
      },
      xmlToJson: function (xmlString) {
        var _toJson = function ($xml) {
          var value = null;
          if ($xml.children().length > 0) {
            value = {};
            $xml.children().each(function (idx, child) {
              var $child = $(child);
              var childName = $child[0].tagName;
              var jsonChild = _toJson($child);
              if (value.hasOwnProperty(childName)) {
                if (Array.isArray(value[childName]) == false) {
                  value[childName] = [value[childName]];
                }
                value[childName].push(jsonChild[childName]);
              } else value[childName] = jsonChild[childName];
            });
          } else {
            value = $xml.text();
          }

          var json = {};
          json[$xml[0].tagName] = value;
          return json;
        };

        var xml = $.parseXML(xmlString);
        var $root = $(xml).children().first();
        var json = _toJson($root);
        return json[$root[0].tagName];
      },
      insertDocu: function (options) {
        var grid = options.grid,
          rows = options.rows,
          verifier = options.verifier,
          preworkPromise = options.preworkPromise,
          previewApi = options.previewApi,
          insertApi = options.insertApi,
          menuId = options.menuId,
          ok = options.ok;

        if (typeof grid === 'undefined' || grid == null ||
          typeof rows === 'undefined' || rows == null ||
          typeof previewApi === 'undefined' || previewApi == null ||
          typeof insertApi === 'undefined' || insertApi == null) {
          throw 'arguments are not filled';
        }

        if (rows && rows.length > 0) {
          (new Promise(function (resolve, reject) {
            var notAllowedRows = verifier && typeof verifier == 'function' ? rows.filter(function (data) {
              return verifier.call(grid, data) == false;
            }) : [];

            if (notAllowedRows && notAllowedRows.length > 0) {
              dews.confirm('전표처리가 불가능한 항목이 있습니다.' + '\n' + '가능한 항목만 선택하시겠습니까?', 'question')
                .yes(function () {
                  var notAllowedIndex = grid.getCheckedIndex().filter(function (idx) {
                    return verifier.call(grid, grid.dataItem(idx)) == false;
                  });
                  if (notAllowedIndex) {
                    grid.setCheck(notAllowedIndex, false);
                  };
                  rows = grid.getCheckedRows();
                  if (!(rows && rows.length > 0)) {
                    setTimeout(function () {
                      dews.alert('전표처리 할 항목을 체크해 주십시오.')
                        .done(function () {
                          grid.setFocus();
                        });
                    }, 300);
                    reject();
                  } else {
                    resolve();
                  }
                })
                .no(reject);
            } else resolve();
          })).then(function () {
              return preworkPromise && preworkPromise != null ? preworkPromise() : new Promise(function (resolve, reject) {
                resolve();
              });
            })
            .then(function () {
              setTimeout(function () {
                dews.ui.loading.show({
                  text: '전표처리 항목을 구성중입니다.'
                });
              }, 0);

              dews.api.post(previewApi.url, {
                data: previewApi.data(rows)
              }).done(function (previewData) {
                setTimeout(function () {
                  dews.ui.loading.hide();
                }, 0);
                if (previewData.length > 0) {
                  var previewData = JSON.parse(previewData);
                  previewData = previewData[Object.keys(previewData)[0]];

                  let isOccurError = false;
                  $.each(previewData, function(idx, item){
                    if(item.DOCU_CD == undefined) {
                    } else if(item.DOCU_CD == '' || item.DOCU_CD == null){
                    isOccurError = true;
                    dews.ui.loading.hide();
                    let curMessage = '전표유형은 필수입력입니다.';
                    if(item.MENU_CD && item.MENU_CD == 'TSMDOC00400'){
                      curMessage = '대체전표 데이터의 [유형] 필수값이 누락되었습니다.';
                    }
                    console.error(curMessage);
                    setTimeout(function () {
                      dews.alert(curMessage, { align: 'center', icon: 'error' });
                    }, 0);
                    return false;
                  }
                });

                if(!isOccurError)
                {

               
                dews.ui.dialog("GLDDOC00500_PREVIEW", {
                    url: "/view/FI/GLDDOC00500_PREVIEW",
                    title: dews.localize.get("전표처리정보", 'D0004061'),
                    width: 720,
                    height: 586,
                    initData: {
                      menuId: menuId,
                      //docuData: JSON.stringify(previewData),
                      docuData: JSON.stringify(previewData),
                      strDocuments: JSON.stringify(previewData),
                      mainTitle: dews.localize.get("원천세 전표처리", 'D0004348')
                    },
                    ok: function (insertData) {
                      if (insertData && insertData.length > 0) {

                    	  setTimeout(function () {
                    		dews.ui.loading.show({
                    			text: '전표처리를 진행하고 있습니다.'
                    		 });
                    	}, 0);

                        dews.api.post(insertApi.url, {
                          data: insertApi.data(rows, insertData)
                        }).done(function () {
                          setTimeout(function () {
                        	dews.ui.loading.hide();
                            dews.ui.snackbar.ok(dews.localize.get('전표처리가 완료되었습니다.', 'M0001635'));
                            if (typeof ok === 'function') ok(rows, insertData);
                          }, 0);
                        }).fail(function (xhr, status, error) {
                          dews.ui.loading.hide();
                          console.error(error);
                          setTimeout(function () {
                            dews.alert(error, { align: 'left', icon: 'error' });
                          }, 0);
                        });


                      }
                    }
                  }).open();
                }
              }
              }).fail(function (xhr, status, error) {
                console.error(error);
                setTimeout(function () {
                  dews.ui.loading.hide();
                  setTimeout(function () {
                    dews.alert(error, 'error');
                  }, 300);
                }, 0);
              })
            })
            .catch(function () {

            });
        } else {
          dews.alert('전표처리 할 항목을 체크해 주십시오.')
            .done(function () {
              grid.setFocus();
            });
        }
      },
      insertAbDocu: function (options) {
		  var grid = options.grid,
		    rows = options.rows,
		    verifier = options.verifier,
		    preworkPromise = options.preworkPromise,
		    insertApi = options.insertApi,
		    menuId = options.menuId,
		    ok = options.ok;

		  if (typeof grid === 'undefined' || grid == null ||
		    typeof rows === 'undefined' || rows == null ||
		    typeof insertApi === 'undefined' || insertApi == null) {
		    throw 'arguments are not filled';
		  }

		  if (rows && rows.length > 0) {
		    (new Promise(function (resolve, reject) {
		      var notAllowedRows = verifier && typeof verifier == 'function' ? rows.filter(function (data) {
		        return verifier.call(grid, data) == false;
		      }) : [];

		      if (notAllowedRows && notAllowedRows.length > 0) {
		        dews.confirm('결의서처리가 불가능한 항목이 있습니다.' + '\n' + '가능한 항목만 선택하시겠습니까?', 'question')
		          .yes(function () {
		            var notAllowedIndex = grid.getCheckedIndex().filter(function (idx) {
		              return verifier.call(grid, grid.dataItem(idx)) == false;
		            });
		            if (notAllowedIndex) {
		              grid.setCheck(notAllowedIndex, false);
		            };
		            rows = grid.getCheckedRows();
		            if (!(rows && rows.length > 0)) {
		              setTimeout(function () {
		                dews.alert('결의서처리 할 항목을 체크해 주십시오.')
		                  .done(function () {
		                    grid.setFocus();
		                  });
		              }, 300);
		              reject();
		            } else {
		              resolve();
		            }
		          })
		          .no(reject);
		      } else resolve();
		    })).then(function () {
		        return preworkPromise && preworkPromise != null ? preworkPromise() : new Promise(function (resolve, reject) {
		          resolve();
		        });
		      })
		      .then(function () {
		        setTimeout(function () {
		          dews.ui.loading.show({
		            text: '결의서처리를 진행하고 있습니다.'
		           });
		        }, 0);

		        dews.api.post(insertApi.url, {
		          data: insertApi.data(rows)
		        }).done(function () {
		          setTimeout(function () {
			          dews.ui.loading.hide();
			            dews.ui.snackbar.ok(dews.localize.get('결의서처리가 완료되었습니다.', 'M0001635'));
			            if (typeof ok === 'function')
			            	ok(rows);
		          }, 0);
		        }).fail(function (xhr, status, error) {
		          dews.ui.loading.hide();
		          console.error(error);
		          setTimeout(function () {
		            dews.alert(error, { align: 'left', icon: 'error' });
		          }, 0);
		        });

		      })
		      .catch(function () {

		      });
		  } else {
		    dews.alert('결의서처리 할 항목을 체크해 주십시오.')
		      .done(function () {
		        grid.setFocus();
		      });
		  }
		},
      deleteDocu: function (options) {
        var grid = options.grid,
          rows = options.rows,
          verifier = options.verifier,
          deleteApi = options.deleteApi,
          ok = options.ok,
          waitTimeout = 0;

        if (rows && rows.length > 0) {
          (new Promise(function (resolve, reject) {
            var notAllowedRows = verifier && typeof verifier == 'function' ? rows.filter(function (data) {
              return verifier.call(grid, data) == false;
            }) : [];

            if (notAllowedRows && notAllowedRows.length > 0) {
              setTimeout(function () {
                waitTimeout = 300;
                dews.confirm('전표취소가 불가능한 항목이 있습니다.' + '\n' + '가능한 항목만 선택하시겠습니까?', 'question')
                  .yes(function () {
                    var notAllowedIndex = grid.getCheckedIndex().filter(function (idx) {
                      return verifier.call(grid, grid.dataItem(idx)) == false;
                    });
                    if (notAllowedIndex) {
                      grid.setCheck(notAllowedIndex, false);
                    };
                    rows = grid.getCheckedRows();

                    if (!(rows && rows.length > 0)) {
                      setTimeout(function () {
                        dews.alert('전표취소 할 항목을 체크해 주십시오.')
                          .done(function () {
                            grid.setFocus();
                          });
                      }, 300);
                      reject();
                    } else {
                      resolve();
                    }
                  })
                  .no(reject);
              }, 0);
            } else resolve();
          })).then(function () {
              return new Promise(function (resolve, reject) {
                setTimeout(function () {
                  dews.confirm(dews.string.format('선택한 {0}개 항목을 전표취소 하시겠습니까?', rows.length) + '\n' +
                      '※ 승인된 항목은 취소되지 않습니다.', {
                        align: 'left',
                        icon: 'question'
                      })
                    .yes(function () {
                      resolve();
                    })
                    .no(function () {
                      reject();
                    });
                }, waitTimeout);
              });
            })
            .catch(function () {
              throw null;
            })
            .then(function () {
              setTimeout(function () {
                dews.ui.loading.show({
                  text: '전표처리 항목을 구성중입니다.'
                });
              }, 0);

              dews.api.post(deleteApi.url, {
                data: deleteApi.data(rows)
              }).done(function () {
                dews.ui.loading.hide();
                setTimeout(function () {
                  if (typeof ok === 'function') ok(rows);
                  dews.ui.snackbar.info('전표취소가 완료되었습니다.');
                }, 0);
              }).fail(function (xhr, status, error) {
                setTimeout(function () {
                  dews.ui.loading.hide();
                  dews.alert(error, 'error');
                }, 0);
                console.log(error);
              })
            })
            .catch(function () {});
        } else {
          dews.alert('전표취소 할 항목을 체크해 주십시오.')
            .done(function () {
              grid.setFocus();
            });
        }
      },
      deleteAbDocu: function (options) {
          var grid = options.grid,
            rows = options.rows,
            verifier = options.verifier,
            deleteApi = options.deleteApi,
            ok = options.ok,
            waitTimeout = 0;

          if (rows && rows.length > 0) {
            (new Promise(function (resolve, reject) {
              var notAllowedRows = verifier && typeof verifier == 'function' ? rows.filter(function (data) {
                return verifier.call(grid, data) == false;
              }) : [];

              if (notAllowedRows && notAllowedRows.length > 0) {
                setTimeout(function () {
                  waitTimeout = 300;
                  dews.confirm('결의서취소가 불가능한 항목이 있습니다.' + '\n' + '가능한 항목만 선택하시겠습니까?', 'question')
                    .yes(function () {
                      var notAllowedIndex = grid.getCheckedIndex().filter(function (idx) {
                        return verifier.call(grid, grid.dataItem(idx)) == false;
                      });
                      if (notAllowedIndex) {
                        grid.setCheck(notAllowedIndex, false);
                      };
                      rows = grid.getCheckedRows();

                      if (!(rows && rows.length > 0)) {
                        setTimeout(function () {
                          dews.alert('결의서취소 할 항목을 체크해 주십시오.')
                            .done(function () {
                              grid.setFocus();
                            });
                        }, 300);
                        reject();
                      } else {
                        resolve();
                      }
                    })
                    .no(reject);
                }, 0);
              } else resolve();
            })).then(function () {
                return new Promise(function (resolve, reject) {
                  setTimeout(function () {
                    dews.confirm(dews.string.format('선택한 {0}개 항목을 결의서취소 하시겠습니까?', rows.length) + '\n' +
                        '※ 승인된 항목은 취소되지 않습니다.', {
                          align: 'left',
                          icon: 'question'
                        })
                      .yes(function () {
                        resolve();
                      })
                      .no(function () {
                        reject();
                      });
                  }, waitTimeout);
                });
              })
              .catch(function () {
                throw null;
              })
              .then(function () {
                setTimeout(function () {
                  dews.ui.loading.show({
                    text: '결의서처리 항목을 구성중입니다.'
                  });
                }, 0);

                dews.api.post(deleteApi.url, {
                  data: deleteApi.data(rows)
                }).done(function () {
                  dews.ui.loading.hide();
                  setTimeout(function () {
                    if (typeof ok === 'function') ok(rows);
                    dews.ui.snackbar.info('결의서취소가 완료되었습니다.');
                  }, 0);
                }).fail(function (xhr, status, error) {
                  setTimeout(function () {
                    dews.ui.loading.hide();
                    dews.alert(error, 'error');
                  }, 0);
                  console.log(error);
                })
              })
              .catch(function () {});
          } else {
            dews.alert('결의서취소 할 항목을 체크해 주십시오.')
              .done(function () {
                grid.setFocus();
              });
          }
        },
      sendOrOpenGroupwareDocument: function (options) {
        var self = this;
        var menuCode = (options || {}).menuCode || this.globalVariables.menu.id;
        var menuParams = JSON.stringify((options || {}).menuParams || {});
        var formId = (options || {}).formId || '';
        var mode = (options || {}).mode || '';
        var callback = (options || {}).callback;

        if (menuCode.length <= 0 || formId.length <= 0) {
          console.error('sendOrOpenGroupwareDocument : parameter not filled', menuCode, menuParams, formId);
          dews.alert('전자결재 상신/조회 중 오류가 발생했습니다.', 'error');
        }

        dews.api.post(dews.url.getApiUrl('TX', 'TxCommonServices', 'groupware_request_get'), {
          data: {
            menuCode: menuCode || '',
            menuParams: menuParams || '',
            formId: formId || '',
            mode: mode || '',
          }
        }).done(function (data) {
          if (data) {
            dews.ajax.script('~/view/js/hdg.cm.util.js', {
                once: true
              })
              .done(function () {
                var api = gerp.CM.EltrAthzUtil;
                api.createEltrAthz(data.serverUrl, data, true);
              });
            if (typeof callback == 'function') {
              callback({
                docNo: data.approKey,
                menuCode: menuCode,
                menuParams: menuParams,
                formId: formId
              });
            }
          } else {
            console.error('sendOrOpenGroupwareDocument : no senddata retrieved.');
            dews.alert('전자결재 상신/조회 중 오류가 발생했습니다.', 'error');
          }
        }).fail(function (xhr, status, error) {
          console.error(error);
          dews.alert(error, 'error');
        });
      },
      /**
       * 로그인한 사원코드
       * @example VC.getEmpCode();
       * @returns {String} 사원코드
       */
      getEmpCode: function () {
        return this.nvl(dews.ui.page.user, '') == '' ? null : dews.ui.page.user.empCode ? dews.ui.page.user.empCode : dews.ui.page
          .user.gEmpCode;
      },
      /**
       * value 가 null 이거나 undefined 가 아니라면 true 를 리턴
       * @param {*} value 체크객체
       * @returns {boolean} Not Null 인지 여부
       */
      isNotNull: function (value) {
        if (value != null && value != undefined && value != '') return true;
        return false;
      },
      jsVersion: function () {
        // .net tx-interface 버전과 비교하기 위하여 사용합니다.
        // getTXInterFaceVersion()
        return '2021082702'.toString();
      },
      isNull: function (value) {
          if (value == null)
        	  return true;

          if (value == undefined)
        	  return true;

          if (value == '')
        	  return true;
          return false;
        },
      /**
       * Oracle NVL 유사함수.
       * value 가 null 혹은 undefined 라면 nullValue 를 리턴한다.
       * @example showMessage = VC.nvl(showMessage, true);
       * @param {*} value 체크 값
       * @param {*} nullValue null/undefined 기본값
       * @returns {*} value 혹은 nullValue
       */
      nvl: function (value, nullValue) {
        if (this.isNotNull(value) == false) return nullValue;
        return value;
      },
      number: function (value) {
        if ($.isNumeric(value)) return Number(value);
        return 0;
      },
      /**
       * 현재일자의 yyyyMMdd 형식 문자열
       * @example var today = VC.todayString();
       * @returns yyyyMMdd 형식 날짜
       */
      todayString: function () {
        return dews.date.format(new Date(), 'yyyyMMdd');
      },
      commitCells: function (dewself) {
        try {
          if (!dewself) {
            dewself = dews.ui.page;
          }
          if (dewself && dewself.$content) {
            dewself.$content.find('.dews-ui-grid').each(function (idx, el) {
              var grid = $(el).data('dews-control');
              if (grid) {
                grid.commitCell();
              }
            });
          }
        } catch (error) {
          console.error(error);
        }
      },
      getDeclYear: function (yyyyMMdd) {
    	  var declDate = new Date(yyyyMMdd.substring(0, 4), yyyyMMdd.substring(4, 6), 1);
          return dews.date.format(declDate, 'yyyy');
        },
        getCookie : function (name) {
      	  var cName = name + "=";
            var x = 0;
            while ( x <= document.cookie.length ){
              var y = (x+cName.length);
              if ( document.cookie.substring( x, y ) == cName ){
                if ( (endOfCookie=document.cookie.indexOf( ";", y )) == -1 )
                  endOfCookie = document.cookie.length;
                return unescape( document.cookie.substring( y, endOfCookie ) );
              }
              x = document.cookie.indexOf( " ", x ) + 1;
              if ( x == 0 )
                break;
            }
            return "";
        },
        setCookie : function (name, value, expiredays) {
      	  var today = new Date();
            today.setDate(today.getDate() + expiredays);
            document.cookie = name + '=' + escape(value) + '; path=/; expires=' + today.toGMTString() + ';'
        },
      /**
       * yyyyMMdd → date 변환
       * @author 이호현 선임연구원
       * @since  2018-03-30 최초개발
       * @example var year = VC.convertToDate('yyyyMMdd');
       * @param {*} value yyyyMMdd 형태의 날짜
       * @returns date
       */
      convertToDate: function (value) {
        if (this.isNotNull(value) && value.length == 8) {
          var year = value.substring(0, 4);
          var month = value.substring(4, 6);
          var day = value.substring(6, 8);
          return new Date(this.number(year), this.number(month) - 1, this.number(day));
        }
      },
      /**
       * 날짜 비교 함수
       * @author 이호현 선임연구원
       * @since  2018-04-02 최초개발
       * @example var bool = VC.dateCompare( 입력날짜, 비교날짜 )
       * @param {*} value yyyyMMdd 형태의 입력날짜
       * @param {*} compareDate yyyyMMdd 형태의 비교날짜
       * @returns true/false
       */
      dateCompare: function (value, compareDate) {
        if (this.convertToDate(value).getTime() > this.convertToDate(compareDate).getTime()) {
          return false;
        } else {
          return true;
        }
      },
      /**
       * 현재 연월의 yyyy 형식 문자열
       * @author 이호현 선임연구원
       * @since  2018-03-30 최초개발
       * @example var year = VC.dateYear();
       * @returns yyyy 형식 날짜
       */
      dateYear: function () {
        return new Date().getFullYear().toString();
      },
      /**
       * 현재 연월의 yyyyMM 형식 문자열
       * @author 이호현 선임연구원
       * @since  2018-03-30 최초개발
       * @example var yearMonth = VC.dateYearMonth();
       * @returns yyyy 형식 날짜
       */
      dateYearMonth: function () {
        return dews.date.format(new Date(), 'yyyyMM');
      },
      /**
       * 이번달의 시작일을 구하는 함수
       * @author 이호현 선임연구원
       * @since  2018-04-20 최초개발
       * @example var dateStart = VC.dateStart();
       * @returns yyyyMMdd 형식 날짜
       */
      dateStart: function () {
        var date = new Date();
        return new Date(date.getFullYear(), date.getMonth(), 1);
      },
      /**
       * 이번달의 마지막일을 구하는 함수
       * @author 이호현 선임연구원
       * @since  2018-04-20 최초개발
       * @example var dateStart = VC.dateStart();
       * @returns yyyyMMdd 형식 날짜
       */
      dateLast: function () {
        var date = new Date();
        return new Date(date.getFullYear(), date.getMonth() + 1, 0);
      },
      dateMonth: function () {
        return dews.date.format(new Date(), 'MM');
      },
      dateDay: function () {
        return dews.date.format(new Date(), 'dd');
      },
      /**
       * DIV 내부의 모든 하위 컨트롤을 Disabled 시킨다.
       * @author 이호현 선임연구원
       * @since  2018-03-30 최초개발
       * @example VC.disableElements(dewself.$oBasicSubPage.children(), false);
       * @param {*} element 엘리먼트
       * @param {*} disabled true/false
       */
      disableElements: function (element, disabled) {
        for (var i = 0; i < element.length; i++) {
          element[i].disabled = disabled;

          this.disableElements(element[i].children, disabled);
        }
      },
      /**
       * 문자열에 데이터가 존재하는지 아닌지 체크하는 함수.
       * @author 이호현 선임연구원
       * @since  2018-03-30 최초개발
       * @example var bool = VC.isIn( 입력값, 비교값 )
       * @param {*} value 입력값
       * @param {*} values 비교값
       * @returns true/false
       */
      isIn: function (value, values) {
        if (this.isNotNull(values.match(new RegExp(value)))) {
          return true;
        }
        return false;
      },
      /**
       * 입력된 데이터가 from, to 구간에 해당하는지 확인하는 함수.
       * @author 이호현 선임연구원
       * @since  2018-03-30 최초개발
       * @example var bool = VC.isBetween( 입력값, 시작값, 종료값 )
       * @param {*} value 입력값
       * @param {*} from  시작값
       * @param {*} to    종료값
       * @returns true/false
       */
      isBetween: function (value, from, to) {
        if (value >= from && value <= to) {
          return true;
        } else {
          return false;
        }
      },
      /**
       * 남녀 성별 구분
       * @author 이호현 선임연구원
       * @since  2018-03-30 최초개발
       * @example var gender = VC.isGender(value);
       * @param {*} value 주민등록번호
       * @returns 0.주민등록번호 오류 1.남자 2.여자
       */
      isGender: function (value) {
        if (value.length == 13) {
          if (this.isIn(value.substr(6, 1), '0|1|3|5|7|')) {
            return 1;
          } else {
            return 2;
          }
        }
        return 0;
      },
      /**
       * 나이 계산
       * @author 이호현 선임연구원
       * @since  2018-04-02 최초개발
       * @example var age = VC.getAge(value);
       * @param {*} value 주민등록번호
       * @returns 나이
       */
      getAge: function (rvers_yy,value) {
        if (this.isNotNull(value) == false || isNaN(value) || value.length < 7) {
          return null;
        }

        var birth_yy;
        var century = value.substring(6,7);

        if (century == '9' || century == '0') {
			birth_yy = '18' + value.substring(0,2);
		} else if (century == '1' || century == '2' || century == '5' || century == '6') {
			birth_yy = '19' + value.substring(0,2);
		} else if (century == '3' || century == '4' || century == '7' || century == '8') {
			birth_yy = '20' + value.substring(0,2);
		}

        var age = rvers_yy - birth_yy;

        return age;
      },
      /**
       * 이메일 유효성 검사
       * @author 이호현 선임연구원
       * @since  2018-04-24 최초개발
       * @example var boolean = VC.validateEmail(value)
       * @param {*} value 이메일
       * @returns true/false
       */
      validateEmail: function (value) {
        try {
          var regExp = /[0-9a-zA-Z][_0-9a-zA-Z-]*@[_0-9a-zA-Z-]+(\.[_0-9a-zA-Z-]+){1,2}$/;
          if (this.isNotNull(value)) {
            if (this.nvl(value.match(regExp), '') == '') {
              dews.ui.snackbar.warning('이메일이 잘못되었습니다.', 'warning');
              return false;
            } else return true;
          } else return true;
        } catch (error) {
          console.log(error);
        }
      },
      /**
       * 주민등록번호 유효성 검사
       * @author 이호현 선임연구원
       * @since  2018-04-24 최초개발
       * @example var boolean = VC.validateResidentNumber(value)
       * @param {*} value 주민등록번호
       * @returns true/false
       */
      validateResidentNumber: function (value) {
        try {
          var format = /^\d{6}[1234]\d{6}$/;
          if (false == format.test(value)) {
            return false;
          }

          var birthYear = (value.charAt(6) <= "2") ? "19" : "20";
          birthYear += value.substr(0, 2);
          var birthMonth = value.substr(2, 2) - 1;
          var birthDay = value.substr(4, 2);
          var birthDate = new Date(birthYear, birthMonth, birthDay);

          if (birthDate.getFullYear() % 100 != value.substr(0, 2) ||
            birthDate.getMonth() != birthMonth ||
            birthDate.getDate() != birthDay) {
            return false;
          }

          if('3478'.indexOf(value.charAt(6)) > -1 &&  // (주민등록번호 7번째자릿수로 판단) 2000년대
              (value.substr(0, 2) == '20' && birthMonth >= '10') || value.substr(0, 2) > '20') {
              // 2020년 10월이후부터 검증하지않음 (-> 20년 10월이후이거나 20년이후)
          } else {
            var array = new Array(13);
            for (var i = 0; i < 13; i++) {
              array[i] = parseInt(value.charAt(i));
            }

            multipliers = [2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5];
            for (var sum = 0, i = 0; i < 12; i++) {
              sum += (array[i] *= multipliers[i]);
            }

            if ((11 - (sum % 11)) % 10 != array[12]) {
              return false;
            }
          }

          return true;

        } catch (error) {
          console.log(error);
        }
      },
      /**
       * 사업자등록번호 유효성 검사
       * @author 이호현 선임연구원
       * @since  2018-04-24 최초개발
       * @example var boolean = VC.validateBusinessNumber(value)
       * @param {*} value 사업자등록번호
       * @returns true/false
       */
      validateBusinessNumber: function (value) {
        try {
          if (value.length != 10) {
            return false;
          }

          var patern = new Array(1, 3, 7, 1, 3, 7, 1, 3, 5, 1);
          var temp, i, sum = 0,
            calc, remander;

          for (i = 0; i <= 7; i++) {
            sum += patern[i] * value.charAt(i);
          }
          calc = '0' + (patern[8] * value.charAt(8));
          calc = calc.substring(calc.length - 2, calc.length);
          sum += Math.floor(calc.charAt(0)) + Math.floor(calc.charAt(1));
          remander = (10 - (sum % 10)) % 10;

          if (Math.floor(value.charAt(9)) == remander) {
            return true;
          } else {
            return false;
          }

          return true;

        } catch (error) {
          console.log(error);
        }
      },
      /**
       * 포맷 및 개인정보암호화 세팅
       * 주민등록번호, 사업자등록번호 포맷 지원
       * [개인정보마스킹기준설정], [개인정보마스킹설정] 메뉴에 설정된 데이터 기준
       * @author 이호현 선임연구원
       * @since  2019-06-12 최초개발
       * @example VC.getMaskingFormats(formatCode, masking, formatCharactor);
       */
      getMaskingFormat: function (formatCode, masking, formatCharactor) {
        try {
          formatCode = formatCode.toUpperCase();
          var mask = '';
          masking = typeof masking === 'undefined' ? true : masking;
          if (!dews.ui.page || !dews.ui.page.env || !dews.ui.page.env.mask) {
            masking = false;
          }
          switch (formatCode) {
            case 'RES_NO':
              mask = '000000-0000000';
              if (masking) {
                mask = dews.string.secureMask(mask, 'RES_NO', true);
              }
              mask = mask.length >= 13 ? mask.substring(0, 6) + '-' + mask.substring(mask.length - 7) : mask;
              break;

              /* 2021-03-05 사업자등록번호 포맷제거 */
            case 'BIZR_NO':
               mask = 'AAAAAAAAAAAAAAAAAAAA';
              break;

          }
          if (formatCharactor && formatCharactor.length > 0) {
            mask = mask.replace(/0/g, formatCharactor);
          }
          return mask;
        } catch (error) {
          console.error(error);
          return '';
        }
      },
      /**
       * 포맷 및 개인정보암호화 세팅
       * @author 이호현 선임연구원
       * @since  2019-06-12 최초개발
       * @example VC.getMaskingFormats(formatCode, formatCharactor);
       */
      getMaskingFormats: function (formatCode, formatCharactor) {
        try {
          var VC = this;
          return {
            type: 'function',
            format: function (value, e) {
              if (value && value.length > 0) {
                if (e.row.data.DECRYPT_FG == '1') {
                  return dews.string.mask(value, VC.getMaskingFormat('RES_NO', e.row.index != e.grid.select()), formatCharactor);
                } else if (e.row.data.DECRYPT_FG == '2' || formatCode == 'FRNR_INSERT_NO') {
                  return dews.string.secureMask(value, 'FRNR_INSERT_NO', true);
                } else if (e.row.data.DECRYPT_FG == '3' || e.row.data.CORP_PSN_CD == "1" ) {//법인개인구분: 법인
                  return dews.string.mask(value, VC.getMaskingFormat('BIZR_NO', e.row.index != e.grid.select()), formatCharactor);
                } else if (e.row.data.FRGNR_CD == '1') {
                  return dews.string.mask(value, VC.getMaskingFormat('RES_NO', e.row.index != e.grid.select()), formatCharactor);
                } else if (e.row.data.FRGNR_CD == '9') {
                  return dews.string.secureMask(value, 'FRNR_INSERT_NO', true);
                } else {
                  return dews.string.mask(value, VC.getMaskingFormat(formatCode, e.row.index != e.grid.select(),
                    formatCharactor));
                }
              }
            }
          }
        } catch (error) {
          console.error(error);
          return {};
        }
      },
      /**
       * 개인정보로그 저장
       * @author 이호현 선임연구원
       * @since  2019-06-12 최초개발
       * @example VC.setPersonalLog();
       * @Params tableName 개인정보를 소유한 테이블명
       *         personalInfoFieldName : 개인정보 필드명 ( ex) RES_NO )
       *         keyFieldNamesPipe : 테이블 Primary Key 의 PipeString ( ex) COMPANY_CD|BIZAREA_CD )
       *         keyData : KEY 데이터 ex) e.row.data
       *         crudType : 개인정보 열람타입 ※ 생략시 read ( create, read, update, delete )
       */
      setPersonalLog: function (tableName, personalInfoFieldNames, keyFieldNamesPipe, keyData, crudType) {
        try {
          dews.api.post(dews.url.getApiUrl('TX', 'TxCommonServices', 'personal_log_insert'), {
            data: {
              data: JSON.stringify($.extend(false, {}, keyData, {
                crudType: crudType || '',
                menuCode: dews.ui.page.menu.id || '',
                tableName: tableName || '',
                personalInfoFieldNames: personalInfoFieldNames || '',
                keyFieldNamesPipe: keyFieldNamesPipe || '',
              }))
            }
          }).fail(function (xhr, status, error) {
            // log no exception
            //dews.error(error);
            console.error(error);
          });
        } catch (error) {
          console.error(error);
        }
      },

      /**
       * 사업/기타/이자배당 데이터소스
       * @author 이호현 선임연구원
       * @since  2018-04-02 최초개발
       * @example VC.getFlagIncomeDataSource();
       * @returns dataSource
       */
      getFlagIncomeDataSource: function () {
        var dataSource = dews.ui.dataSource('dataSource', {
          data: [{
              SYSDEF_CD: "F",
              SYSDEF_NM: "거주자사업소득"
            },
            {
              SYSDEF_CD: "G",
              SYSDEF_NM: "거주자기타소득"
            },
            {
              SYSDEF_CD: "BI",
              SYSDEF_NM: "비거주자사업소득"
            },
            {
              SYSDEF_CD: "B",
              SYSDEF_NM: "이자배당소득"
            },
          ]
        });
        return dataSource;
      },
      /**
       * vatvtm00100_common_info_get 서비스 호출
       * 내부적으로 쓰임
       * @example var commonInfo = VC.getCommonInfo(dewself);
       * @param {*} dewself dewself
       * @param {json} componentId VC.componentId 참조
       * @param {json} cache 캐시 객체
       * @returns {json} vatvtm00100_common_info_get 호출값
       */
      getCommonInfo: function (dewself, componentId, cache) {
        cache = $.extend(false, {}, cache);
        var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself,
          componentId);
        var commonInfo = null;

        dews.api.get(dews.url.getApiUrl('TX', 'TsmCommonServices', 'TsmCommon_hr_config_mst_list'), {
            async: false,
            data: {
              config_cd: 'TAX001' || '',
              emp_no: this.getEmpCode() || '',
            }
          })
          .done(function (data) {
            commonInfo = data;
          })
          .fail(function (xhr, status, error) {
            console.error(error);
          });

        return commonInfo;
      },
      /**
       * 내부적으로 쓰임
       * @example var commonInfo = VC.getCommonInfo(dewself);
       * @param {*} dewself dewself
       * @param {json} componentId VC.componentId 참조
       * @param {json} cache 캐시 객체
       * @returns {json} vatvtm00100_common_info_get 호출값
       */
          getCommonInfoByConfigCd: function (dewself, componentId, configCd, cache) {
            cache = $.extend(false, {}, cache);
            var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself,
              componentId);
            var commonInfo = null;

            dews.api.get(dews.url.getApiUrl('TX', 'TsmCommonServices', 'TsmCommon_hr_config_mst_list'), {
                async: false,
                data: {
                  config_cd: configCd  || '',
                  emp_no: this.getEmpCode()  || '',
                }
              })
              .done(function (data) {
                commonInfo = data;
              })
              .fail(function (xhr, status, error) {
                console.error(error);
              });

            return commonInfo;
          },


      /**
       * 공용 컴포넌트의 각종 정보를 리턴한다.
       * @param {object} dewself dewself
       * @param {json} componentId 공용 컴포넌트 목록 ( VC.componentId 확인 )
       * @returns {json} 공용 컴포넌트 정보
       */
      getCommonComponentInfo: function (dewself, componentId) {
        var VC = this;

        function _getId(componentType) {
          return componentId.hasOwnProperty(componentType) ? componentId[componentType] : null;
        }

        function _getComponent(componentType) {
          return componentId.hasOwnProperty(componentType) ? dewself[componentId[componentType]] : null;
        }

        function _getJQuery(componentType) {
          return componentId.hasOwnProperty(componentType) ? dewself['$' + componentId[componentType]] : null;
        }

        function _getComponentInfo(componentType, valueFunc) {
          var component = _getComponent(componentType);
          return {
            valid: (component != null),
            id: _getId(componentType),
            component: VC.isNotNull(component) ? component : null,
            '$': _getJQuery(componentType),
            value: VC.isNotNull(component) ? valueFunc(component) : null
          };
        }

        function _getButtonInfo(buttonType) {
          var component = _getComponent(buttonType);
          var jquery = _getJQuery(buttonType);
          return {
            valid: component != null,
            id: _getId(buttonType),
            component: component,
            '$': jquery,
            enabled: function (enabled) {
              if (VC.isNotNull(enabled)) {
                if (!enabled) {
                  jquery.attr('disabled', 'disabled');
                  jquery.addClass('k-state-disabled');
                } else {
                  jquery.removeAttr('disabled');
                  jquery.removeClass('k-state-disabled');
                }
              }
              return (jquery.attr('disabled') === 'disabled') == false;
            }
          };
        }

        var sq_modify = _getComponent('sq_modify');
        var col_form_cd = componentId.hasOwnProperty('col_form_cd') && componentId.col_form_cd != null ? componentId.col_form_cd :
          null;

        if (col_form_cd == null && sq_modify != null) {
          var sq_modify_options = sq_modify.getOptions();
          if (sq_modify_options.helpParams != null && sq_modify_options.helpParams.hasOwnProperty('col_form_cd')) {
            col_form_cd = sq_modify_options.helpParams.col_form_cd;
          }
        }

        return {
          bizarea_cd: _getComponentInfo('bizarea_cd', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = value.code;
                data[option.textField] = value.text;
                if (component.codes) {
                  component.setData([data]);
                } else {
                  component.setData(data);
                }
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          bizarea_cd2: _getComponentInfo('bizarea_cd2', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = value.code;
                data[option.textField] = value.text;
                if (component.codes) {
                  component.setData([data]);
                } else {
                  component.setData(data);
                }
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          common_bizarea_cd: _getComponentInfo('common_bizarea_cd', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = value.code;
                data[option.textField] = value.text;
                if (component.codes) {
                  component.setData([data]);
                } else {
                  component.setData(data);
                }
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          common_bizarea_cd2: _getComponentInfo('common_bizarea_cd2', function (component) {
              return function (value) {
                if (value != undefined) {
                  var option = component.getOptions();
                  var data = {};
                  data[option.codeField] = value.code;
                  data[option.textField] = value.text;
                  if (component.codes) {
                    component.setData([data]);
                  } else {
                    component.setData(data);
                  }
                }
                return {
                  code: component.code(),
                  text: component.text()
                };
              };
            }),
          common_bizarea_cd3: _getComponentInfo('common_bizarea_cd3', function (component) {
              return function (value) {
                if (value != undefined) {
                  var option = component.getOptions();
                  var data = {};
                  data[option.codeField] = value.code;
                  data[option.textField] = value.text;
                  if (component.codes) {
                    component.setData([data]);
                  } else {
                    component.setData(data);
                  }
                }
                return {
                  code: component.code(),
                  text: component.text()
                };
              };
            }),
          common_bizarea_cd4: _getComponentInfo('common_bizarea_cd4', function (component) {
              return function (value) {
                if (value != undefined) {
                  var option = component.getOptions();
                  var data = {};
                  data[option.codeField] = value.code;
                  data[option.textField] = value.text;
                  if (component.codes) {
                    component.setData([data]);
                  } else {
                    component.setData(data);
                  }
                }
                return {
                  code: component.code(),
                  text: component.text()
                };
              };
            }),
          dept_cd: _getComponentInfo('dept_cd', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = value.code;
                data[option.textField] = value.text;
                if (component.codes) {
                  component.setData([data]);
                } else {
                  component.setData(data);
                }
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          pjt_cd: _getComponentInfo('pjt_cd', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = value.code;
                data[option.textField] = value.text;
                if (component.codes) {
                  component.setData([data]);
                } else {
                  component.setData(data);
                }
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          incmper_no: _getComponentInfo('incmper_no', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = value.code;
                data[option.textField] = value.text;
                if (component.codes) {
                  component.setData([data]);
                } else {
                  component.setData(data);
                }
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          btn_printDate: _getButtonInfo('btn_printDate'),
          btn_build_media: _getButtonInfo('btn_build_media'),
          btn_taxAgency: _getButtonInfo('btn_taxAgency'),
          btn_openDocu: _getButtonInfo('btn_openDocu'),
          btn_viewDocu: _getButtonInfo('btn_viewDocu'),
          yy_impute: _getComponentInfo('yy_impute', function (component) {
            return function (value) {
              if (value != undefined) {
                component.value(value);
              }
              return component.value();
            };
          }),
          tp_adjust: _getComponentInfo('tp_adjust', function (component) {
            return function (value) {
              if (value != undefined) {
                component.value(value);
              }
              return component.value();
            };
          }),
          emp_no: _getComponentInfo('emp_no', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = value.code;
                data[option.textField] = value.text;
                if (component.codes) {
                  component.setData([data]);
                } else {
                  component.setData(data);
                }
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          pay_dt: _getComponentInfo('pay_dt', function (component) {
            return function (value) {
              if (value != undefined) {
                component.setPeriod(value.from, value.to);
              }
              return {
                from: component.getStartDate(),
                to: component.getEndDate()
              };
            };
          }),
          ym_income: _getComponentInfo('ym_income', function (component) {
            return function (value) {
              if (value != undefined) {
                component.value(value);
              }
              return component.value();
            };
          }),
          data_cd: _getComponentInfo('data_cd', function (component) {
            return function (value) {
              if (value != undefined) {
                component.value(value);
              }
              return component.value();
            };
          }),
        };
      },

      /**
       * CommonCodeDtlService 서비스 사용.
       * @example var dataSource = page.getFlagDataSource('MA', 'P00350');
       * @param {string} cd_module 모듈코드
       * @param {string} cd_field_pipe 코드디테일 코드(PIPE 사용)
       * @param {string} yn_sycode 시스템코드 유무(Y,N)
       * @param {string} yn_default 디폴트 코드구분(Y,N)
       * @param {string} yn_foreign 외국언어적용 유무(Y,N)
       * @param {string} dt_end 종료일
       * @param {string} nm_keyword 검색할 코드 또는 명
       * @returns {Array<JSON>} 조회된 dataSource [ { CD_SYSDEF, NM_SYSDEF } ]
       */
      getFlagDataSource: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword) {
        var self = this;
        yn_sycode = self.nvl(yn_sycode, '');
        base_yn = self.nvl(base_yn, '');
        yn_foreign = self.nvl(yn_foreign, '');
        end_dt = self.nvl(end_dt, '');
        nm_keyword = self.nvl(nm_keyword, '');

        var result = [];
        if (module_cd == undefined || module_cd.length <= 0 ||
          cd_field_pipe == undefined || cd_field_pipe.length <= 0) {
          return;
        }
        if (cd_field_pipe.endsWith('|') == false) cd_field_pipe += '|';

        dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", "common_codeDtl_list"), {
          async: false,
          data: {
            module_cd: module_cd || '', // 모듈
            field_cd_pipe: cd_field_pipe || '', // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
            syscode_yn: yn_sycode || '', // 시스템코드 유무(Y,N)
            base_yn: base_yn || '', // 디폴트 코드구분(Y,N)
            foreign_yn: yn_foreign || '', // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
            end_dt: end_dt || '', // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
            keyword: nm_keyword || '', // 검색할 코드 또는 명
          }
        }).done(function (data) {
          if (data.length > 0) {
            result = data;
          } else {
            console.error('getFlagDataSource(' + module_cd + ', ' + cd_field_pipe + ', ' + yn_sycode + ', ' + base_yn +
              ', ' + yn_foreign + ', ' + end_dt + ', ' + nm_keyword + ') Error : no data retrieved.');
          }
        }).fail(function (xhr, status, error) {
          console.error('getFlagDataSource(' + module_cd + ', ' + cd_field_pipe + ', ' + yn_sycode + ', ' + base_yn +
            ', ' + yn_foreign + ', ' + end_dt + ', ' + nm_keyword + ') Error : ' + error);
        });
        return result;
      },
      /**
       * 캐시 리턴.
       * initializeComponents, initializeButton, isEditable 등의 cache 파라메터에 쓰임.
       * @param {*} dewself dewself
       * @param {json} componentId VC.componentId 참조
       * @returns {json} 캐시 객체
       */
      getCache: function (dewself, componentId) {
        var componentInfo = this.getCommonComponentInfo(dewself, componentId);
        var commonInfo = this.getCommonInfo(dewself, componentId, {
          componentInfo: componentInfo
        });
        return {
          componentInfo: componentInfo,
          initializeInfo: componentInfo,
          referenceInfo: componentInfo,
          commonInfo: commonInfo
        };
      },

      /**
       * 부가세 관련 컴포넌트를 초기화합니다.
       * 1. fg_decl    - 신고방식 : 신고방식 내부데이터 채움. 신고방식 변경시 사업장, 신고구분 컴포넌트 초기화
       * 2. cd_bizarea - 사업장 : 신고방식에 따라 코드도움 설정 ( 사업장 / 주사업장 ), 기본값 지정. 변경시 신고구분 컴포넌트 초기화
       * 3. ym_vat     - 과세기간 : 기간에 따라 과세기간 지정. 변경시 신고구분 컴포넌트 초기화
       * 4. sq_modify  - 신고구분 : 신고구분 코드도움 설정. 신고방식, 사업장, 과세기간에 따른 신고구분 자동설정. helpParams 으로 cd_form 필요. (혹은 componentId 에 부여)
       * @example VC.initializeComponents(dewself, initializeId, referenceId);
       * @param {*} dewself dewself
       * @param {json} initializeId 초기화 대상 컴포넌트. VC.componentId 참조
       * @param {json} referenceId 참조 대상 컴포넌트. VC.componentId 참조
       * @param {json} cache VC.getCache 확인
       * @param {function} extraEventCallback 내부 change 이벤트에 추가적으로 호출될 이벤트 콜백
       * @param {boolean} allocateEvents 초기화시 이벤트 연결여부.
       */
      initializeComponents: function (dewself, initializeId, referenceId, cache, extraEventCallback, allocateEvents) {
        var VC = this;
        cache = $.extend(false, {
          initializeInfo: null,
          referenceInfo: null,
          commonInfo: null
        }, cache);
        allocateEvents = this.nvl(allocateEvents, true);

        var initializeInfo = this.isNotNull(cache.initializeInfo) ? cache.initializeInfo : this.getCommonComponentInfo(dewself,
          initializeId);
        var referenceInfo = this.isNotNull(cache.referenceInfo) ? cache.referenceInfo : this.getCommonComponentInfo(dewself,
          referenceId);
        var commonInfo = this.isNotNull(cache.commonInfo) ? cache.commonInfo : this.getCommonInfo(dewself, referenceId);
        var eventCache = $.extend(false, {}, cache);
        eventCache.commonInfo = null;

        function getInitialValue(propName, defaultValue) {
          var result = defaultValue;

          if (dewself.initialData) {
            if (VC.nvl(dewself.initialData[propName], '').length > 0) {
              result = dewself.initialData[propName];
            }
          }

          return result;
        }

        // 사업장
        if (initializeId.hasOwnProperty('bizarea_cd') && initializeInfo.bizarea_cd.valid) {
          var char_cd_val_dc = '1';
          var bizarea_cd = initializeInfo.bizarea_cd;
          bizarea_cd.component.clearData();

          if ((commonInfo[0].CHAR_CD_VAL_DC || '').length > 0) {
            char_cd_val_dc = commonInfo[0].CHAR_CD_VAL_DC;
          }

          switch (char_cd_val_dc) {
            case '1': // 사업장별

            // 갑근세사업장 HELP
            if(['TSMIND00200', 'TSMREA00100', 'TSMREA00300', 'TSMREW00200', 'TSMREW00100', 'TSMWTD00200'].indexOf(dewself.menu.id) > -1) {
              bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                helpCode: 'H_TX_TSM_HR_TAXBIZAREA_S',
                codeField: 'BIZAREA_CD',
                textField: 'BIZAREA_NM'
              }));

              bizarea_cd.component.setHelpParams({});

              if ((commonInfo[0].BIZAREA_CD || '').length > 0) {
                bizarea_cd.value({
                  code: getInitialValue('bizarea_cd', commonInfo[0].BIZAREA_CD),
                  text: getInitialValue('bizarea_nm', commonInfo[0].BIZAREA_NM)
                });
              }
            } else {
              bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                helpCode: 'H_MA_BIZAREA_MST_S',
                codeField: 'BIZAREA_CD',
                textField: 'BIZAREA_NM'
              }));
              bizarea_cd.component.setHelpParams({});

              if ((dews.ui.page.user.bizAreaCode || '').length > 0) {
                bizarea_cd.value({
                  code: getInitialValue('bizarea_cd', dews.ui.page.user.bizAreaCode),
                  text: getInitialValue('bizarea_nm', dews.ui.page.user.bizAreaName)
                });
              }

              try {
                gerp.MA.setControlByAuth.apply(dewself);
              } catch (error) {}
            }
              break;
            case '2': // 본점일괄
              bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                helpCode: 'H_TX_TSM_HR_HEADBIZAREA_S',
                codeField: 'BIZAREA_CD',
                textField: 'BIZAREA_NM'
              }));

              bizarea_cd.component.setHelpParams({});

              if ((commonInfo[0].BIZAREA_CD || '').length > 0) {
                bizarea_cd.value({
                  code: getInitialValue('bizarea_cd', commonInfo[0].BIZAREA_CD),
                  text: getInitialValue('bizarea_nm', commonInfo[0].BIZAREA_NM)
                });
              }

              break;
            case '3': // 사업자단위과세
              bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                helpCode: 'H_MA_MAINBIZAREA_MST_S',
                codeField: 'MNBSN_CD',
                textField: 'NM_MAINBIZAREA'
              }));

              bizarea_cd.component.setHelpParams({
                module_cd: 'HR'
              });

              if ((commonInfo[0].BIZAREA_CD || '').length > 0) {
                bizarea_cd.value({
                  code: getInitialValue('bizarea_cd', commonInfo[0].BIZAREA_CD),
                  text: getInitialValue('bizarea_nm', commonInfo[0].BIZAREA_NM)
                });
              }

              if (dewself.authority && dewself.authority.grant && $.inArray(dewself.authority.grant, ['S', 'C']) < 0) {
                bizarea_cd.component.enable(false);
              }
              break;
          }
        }

        // 사업장
        if ((initializeId.hasOwnProperty('bizarea_cd2') && initializeInfo.bizarea_cd2.valid)) {
          var char_cd_val_dc = '1';
          var bizarea_cd = initializeInfo.bizarea_cd2;
          bizarea_cd.component.clearData();

          if ((commonInfo[0].CHAR_CD_VAL_DC || '').length > 0) {
            char_cd_val_dc = commonInfo[0].CHAR_CD_VAL_DC;
          }

          switch (char_cd_val_dc) {
            case '1': // 사업장별
              bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                helpCode: 'H_MA_BIZAREA_MST_S',
                codeField: 'BIZAREA_CD',
                textField: 'BIZAREA_NM'
              }));
              bizarea_cd.component.setHelpParams({});

              if ((dews.ui.page.user.bizAreaCode || '').length > 0) {
                bizarea_cd.value({
                  code: getInitialValue('bizarea_cd', dews.ui.page.user.bizAreaCode),
                  text: getInitialValue('bizarea_nm', dews.ui.page.user.bizAreaName)
                });
              }

              try {
                gerp.MA.setControlByAuth.apply(dewself);
              } catch (error) {}
              break;
            case '2': // 본점일괄
              bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                helpCode: 'H_TX_TSM_HR_HEADBIZAREA_S',
                codeField: 'BIZAREA_CD',
                textField: 'BIZAREA_NM'
              }));

              bizarea_cd.component.setHelpParams({});

              if ((commonInfo[0].BIZAREA_CD || '').length > 0) {
                bizarea_cd.value({
                  code: getInitialValue('bizarea_cd', commonInfo[0].BIZAREA_CD),
                  text: getInitialValue('bizarea_nm', commonInfo[0].BIZAREA_NM)
                });
              }

              break;
            case '3': // 사업자단위과세
              bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                helpCode: 'H_MA_MAINBIZAREA_MST_S',
                codeField: 'MNBSN_CD',
                textField: 'NM_MAINBIZAREA'
              }));

              bizarea_cd.component.setHelpParams({
                module_cd: 'HR'
              });

              if ((commonInfo[0].BIZAREA_CD || '').length > 0) {
                bizarea_cd.value({
                  code: getInitialValue('bizarea_cd', commonInfo[0].BIZAREA_CD),
                  text: getInitialValue('bizarea_nm', commonInfo[0].BIZAREA_NM)
                });
              }

              if (dewself.authority && dewself.authority.grant && $.inArray(dewself.authority.grant, ['S', 'C']) < 0) {
                bizarea_cd.component.enable(false);
              }
              break;
          }
        }

        // 공통 사업장
        if (initializeId.hasOwnProperty('common_bizarea_cd') && initializeInfo.common_bizarea_cd.valid) {
          var bizarea_cd = initializeInfo.common_bizarea_cd;

          bizarea_cd.component.clearData();

          bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
            helpCode: 'H_MA_BIZAREA_MST_S',
            codeField: 'BIZAREA_CD',
            textField: 'BIZAREA_NM'
          }));
          bizarea_cd.component.setHelpParams({});

          if ((dews.ui.page.user.bizAreaCode || '').length > 0) {
            bizarea_cd.value({
              code: getInitialValue('bizarea_cd', dews.ui.page.user.bizAreaCode),
              text: getInitialValue('bizarea_nm', dews.ui.page.user.bizAreaName)
            });
          }

          try {
            gerp.MA.setControlByAuth.apply(dewself);
          } catch (error) {}
        }

        // 공통 사업장
        if (initializeId.hasOwnProperty('common_bizarea_cd2') && initializeInfo.common_bizarea_cd2.valid) {
          var bizarea_cd = initializeInfo.common_bizarea_cd2;

          bizarea_cd.component.clearData();

          bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
            helpCode: 'H_MA_BIZAREA_MST_S',
            codeField: 'BIZAREA_CD',
            textField: 'BIZAREA_NM'
          }));
          bizarea_cd.component.setHelpParams({});

          if ((dews.ui.page.user.bizAreaCode || '').length > 0) {
            bizarea_cd.value({
              code: getInitialValue('bizarea_cd', dews.ui.page.user.bizAreaCode),
              text: getInitialValue('bizarea_nm', dews.ui.page.user.bizAreaName)
            });
          }

          try {
            gerp.MA.setControlByAuth.apply(dewself);
          } catch (error) {}
        }

        // 공통 사업장
        if (initializeId.hasOwnProperty('common_bizarea_cd3') && initializeInfo.common_bizarea_cd3.valid) {
          var bizarea_cd = initializeInfo.common_bizarea_cd3;

          bizarea_cd.component.clearData();

          bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
            helpCode: 'H_MA_BIZAREA_MST_S',
            codeField: 'BIZAREA_CD',
            textField: 'BIZAREA_NM'
          }));
          bizarea_cd.component.setHelpParams({});

          if ((dews.ui.page.user.bizAreaCode || '').length > 0) {
            bizarea_cd.value({
              code: getInitialValue('bizarea_cd', dews.ui.page.user.bizAreaCode),
              text: getInitialValue('bizarea_nm', dews.ui.page.user.bizAreaName)
            });
          }

          try {
            gerp.MA.setControlByAuth.apply(dewself);
          } catch (error) {}
        }

        // 공통 사업장
        if (initializeId.hasOwnProperty('common_bizarea_cd4') && initializeInfo.common_bizarea_cd4.valid) {
          var bizarea_cd = initializeInfo.common_bizarea_cd4;

          bizarea_cd.component.clearData();

          bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
            helpCode: 'H_MA_BIZAREA_MST_S',
            codeField: 'BIZAREA_CD',
            textField: 'BIZAREA_NM'
          }));
          bizarea_cd.component.setHelpParams({});

          if ((dews.ui.page.user.bizAreaCode || '').length > 0) {
            bizarea_cd.value({
              code: getInitialValue('bizarea_cd', dews.ui.page.user.bizAreaCode),
              text: getInitialValue('bizarea_nm', dews.ui.page.user.bizAreaName)
            });
          }

          try {
            gerp.MA.setControlByAuth.apply(dewself);
          } catch (error) {}
        }

        // 부서
        if (initializeId.hasOwnProperty('dept_cd') && initializeInfo.dept_cd.valid) {
          var dept_cd = initializeInfo.dept_cd;
          dept_cd.component.clearData();
          dept_cd.component.setOptions($.extend({}, dept_cd.component.getOptions(), {
            helpCode: 'H_MA_DEPT_MST_S',
            helpSize: 'big',
            codeField: 'DEPT_CD',
            textField: 'DEPT_NM'
          }));
          dept_cd.component.setHelpParams({});

          try {
            gerp.MA.setControlByAuth.apply(dewself);
          } catch (error) {}
        }

        // 프로젝트
        if (initializeId.hasOwnProperty('pjt_cd') && initializeInfo.pjt_cd.valid) {
          var pjt_cd = initializeInfo.pjt_cd;
          pjt_cd.component.clearData();
          pjt_cd.component.setOptions($.extend({}, pjt_cd.component.getOptions(), {
            helpCode: 'H_PS_WBS_MST_S',
            helpSize: 'largebig',
            codeField: 'WBS_NO',
            textField: 'WBS_NM'
          }));
          pjt_cd.component.setHelpParams({});
        }
        // 소득자
        if (initializeId.hasOwnProperty('incmper_no') && initializeInfo.incmper_no.valid) {

          var incmper_no = initializeInfo.incmper_no;
          var data_cd;
          if (this.isIn(dewself.menu.id, 'TSMINB00100|TSMINB00200')) {
            data_cd = 'F'
          } else if (this.isIn(dewself.menu.id, 'TSMING00100|TSMING00200')) {
            data_cd = 'G'
          } else if (this.isIn(dewself.menu.id, 'TSMINO00100|TSMINO00200')) {
            data_cd = 'BI'
          } else if (this.isIn(dewself.menu.id, 'TSMINT00100|TSMINT00200')) {
            data_cd = 'B'
          }

          incmper_no.component.clearData();
          incmper_no.component.setOptions($.extend({}, incmper_no.component.getOptions(), {
            helpCode: 'H_TX_TSM_HR_EARNER_MST_S',
            helpSize: 'big',
            codeField: 'INCMPER_NO',
            textField: 'INCMPER_NM'
          }));
          incmper_no.component.setHelpParams({
            data_cd: data_cd
          });
        }

        // 귀속연도
        if (initializeId.hasOwnProperty('yy_impute') && initializeInfo.yy_impute.valid) {
          if (dews.date.format(new Date(), 'MMdd') <= '0310') {
            var now = new Date();
            var date = String(now.getFullYear() - 1) + String(now.getMonth()) + String(now.getDate());
            initializeInfo.yy_impute.value(date);
          } else {
            initializeInfo.yy_impute.value(this.dateYear());
          }
        }

        // 정산구분
        if (initializeId.hasOwnProperty('tp_adjust') && initializeInfo.tp_adjust.valid) {
          //initializeInfo.yy_impute.value(this.dateYear());
          // 임시 주석.
          var tp_adjust = initializeInfo.tp_adjust;
          tp_adjust.component.setDataSource(this.getFlagDataSource('HR', 'P00560'));
          tp_adjust.value(getInitialValue('tp_adjust', '0'));

          tp_adjust.component.on('change', function (e) {
            if (tp_adjust.component.selectedIndex == 0) {
              if (dews.date.format(new Date(), 'MMdd') <= '0310') {
                var now = new Date();
                var date = String(now.getFullYear() - 1) + String(now.getMonth()) + String(now.getDate());
                initializeInfo.yy_impute.value(date);
              } else {
                initializeInfo.yy_impute.value(new Date().getFullYear().toString());
              }
            } else {
              initializeInfo.yy_impute.value(new Date().getFullYear().toString());
            }
          });
        }

        // 사원
        if (initializeId.hasOwnProperty('emp_no') && initializeInfo.emp_no.valid) {
          var emp_no = initializeInfo.emp_no;
          if (referenceInfo.yy_impute.valid) {
            emp_no.component.clearData();
            emp_no.component.setHelpParams({});

            emp_no.value({
              code: dewself.user.empCode,
              text: dewself.user.username
            });
          }
        }

        // 지급일자
        if (initializeId.hasOwnProperty('pay_dt') && initializeInfo.pay_dt.valid) {
          var pay_dt = initializeInfo.pay_dt;
          pay_dt.component.setStartDate(this.dateStart());
          pay_dt.component.setEndDate(this.dateLast());
        }

        // 귀속연월
        if (initializeId.hasOwnProperty('ym_income') && initializeInfo.ym_income.valid) {
          initializeInfo.ym_income.value(this.dateYearMonth());
        }

        // 소득구분
        if (initializeId.hasOwnProperty('data_cd') && initializeInfo.data_cd.valid) {
          var data_cd = initializeInfo.data_cd;
          data_cd.component.setDataSource(this.getFlagIncomeDataSource());
          data_cd.value(getInitialValue('data_cd', 'F'));
        }
      },

      /**
       * 불러오기, 일괄삭제, 출력일, 종사업장 버튼 초기화
       * 리턴된 객체는 다음과 같은 함수를 가지고 있습니다.
       * init(initFunction) : 버튼 클릭시 호출되며, 해당 함수에서 false 를 리턴하면 실행하지 않습니다.
       * setInitData(initJson) : 대화상자 내부로 주입될 데이터
       * setTitle(title) : 대화상자 명
       * yes(yesFunction) : 대화상자에서 yes 버튼을 클릭했을 경우 호출되며 대화상자에서 데이터가 처음 파라메터로 넘어옵니다.
       * done() : 설정을 모두 종료하고 초기화를 실행합니다.
       * @example VC.initializeButton(dewself, 'btn_load', componentId);
       * @param {*} dewself dewself
       * @param {String} componentType 초기화 대상 버튼 VC.componentId 참조
       * @param {json} componentId VC.componentId 참조
       * @param {json} cache VC.getCache 확인
       */
      initializeButton: function (dewself, componentType, componentId, cache) {
        var VC = this;
        cache = $.extend(false, {
          componentInfo: null
        }, cache);

        var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself,
          componentId, true);
        if (componentInfo.hasOwnProperty(componentType) == false) return;
        var component = componentInfo[componentType];

        return {
          _componentType: componentType,
          _component: component,
          _initializeData: {},
          _title: null,
          _initialize: null,
          _yesFunction: null,
          init: function (initialize) {
            this._initialize = initialize;
            return this;
          },
          setInitData: function (initializeData) {
            this._initializeData = initializeData;
            return this;
          },
          setTitle: function (title) {
            this._title = title;
            return this;
          },
          yes: function (yesFunction) {
            this._yesFunction = yesFunction;
            return this;
          },
          done: function () {
            var self = this;
            this._component.$.off('click').on('click', function (e) {
              if (self._component.enabled() == false) return;
              if (VC.isNotNull(self._initialize))
                if (self._initialize() == false) return;

              var initData = VC.isNotNull(self._initializeData) ? (typeof self._initializeData === 'function' ? self
                ._initializeData() : self._initializeData) : null;
              initData = $.extend(true, {}, initData);
              var dialogTitle = VC.isNotNull(self._title) ? self._title : null;
              var yesFunction = VC.nvl(self._yesFunction, function () {
                return false;
              });

              switch (self._componentType) {
                case 'btn_printDate':
                  dews.ui.dialog('tsmCommon_printDateDialog', {
                    url: '/view/TX/TSMREW00000_COMMON_PRINTDATE_POP',
                    title: (dialogTitle == null ? VC.titles.btn_printDate : dialogTitle),
                    width: 390,
                    height: 135,
                    initData: initData,
                    ok: function (data) {
                      yesFunction(data);
                    }
                  }).open();
                  break;
              }
            });
          }
        };
      },

      /**
       * 추가/수정/삭제 여부를 리턴합니다.
       * 1. 최근 문서 여부 : sq_modify ( 0. 정기, 1 ~ 수정 ) 가 최종적으로 작성된 것이 아닌경우 불가
       * 2. 서식 마감 여부 : 부가세 신고서상에서 해당 서식이 마감처리된 경우 불가 ( cd_form 참조 )
       * @param {*} dewself dewself
       * @param {boolean} showMessage 수정불가일때 메시지 발생여부
       * @param {json} componentId VC.componentId 확인
       * @param {*} cache VC.getCache 확인
       * @returns {boolean} 수정 가능 여부 true : 수정가능 / false : 수정불가
       */
      isEditable: function (dewself, showMessage, componentId, cache) {
        function _getComponent(componentType) {
          return componentId.hasOwnProperty(componentType) ? dewself[componentId[componentType]] : null;
        }
        showMessage = this.nvl(showMessage, true);
        cache = $.extend(false, {
          componentInfo: null,
          commonInfo: null
        }, cache);

        var commonInfo = this.isNotNull(cache.commonInfo) ? cache.commonInfo : this.getCommonInfo(dewself, componentId);
        var editable = true;
        cache.commonInfo = commonInfo

        return editable;
      },

      /**
       * 신고방식에 따른 사업장 목록을 리턴합니다.
       * 1. 신고방식 - 사업장별 : 사업장 코드 리턴 ( ex) 1000 )
       * 2. 신고방식 - 사업자단위과세 : 주사업장 코드의 종사업장 목록을 리턴 ( ex) 1000|2000 )
       * @param {*} dewself dewself
       * @param {json} componentId VC.componentId 참조
       * @param {json} cache VC.getCache 확인
       * @param {string} 사업장코드
       */
      cd_subBizArea: function (dewself, componentId, cache) {
        var initializeInfo = this.isNotNull(cache.initializeInfo) ? cache.initializeInfo : this.getCommonComponentInfo(dewself,
          componentId);
        var commonInfo = this.isNotNull(cache.commonInfo) ? cache.commonInfo : this.getCommonInfo(dewself, componentId);
        //var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself, componentId, true);
        var fg_decl = commonInfo[0].CHAR_CD_VAL_DC;
        //var decl_fg = componentInfo.decl_fg.value();
        //var bizarea_cd = componentInfo.bizarea_cd.value().code;
        var bizarea_cd = initializeInfo.bizarea_cd;
        var cd_subBizArea = bizarea_cd;
        if (fg_decl == '3') {
          dews.api.get(dews.url.getApiUrl('TX', 'ValueAddedTaxManagementVTMService', 'vatvtm00100_common_subbizarea_list'), {
              async: false,
              data: {
                'mnbsn_cd': bizarea_cd  || '',
              }
            })
            .done(function (data) {
              cd_subBizArea = data.map(function (d) {
                return d.BIZAREA_CD;
              }).join('|');
            })
            .fail(function (xhr, status, error) {
              console.error(error);
            });
        }
        return cd_subBizArea;
      },

      /**
       * GUID 문자열을 리턴합니다. (우리가 익히 아는 GUID 는 아니고 그에 준하는 랜덤문자.)
       */
      guid: function () {
        return 'xxxxxxxx-xxxx-4xxx-9xxx-xxxxxxxxxxxx'.replace(/[xy]/g,
          function (c) {
            var r = Math.random() * 16 | 0,
              v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
          });
      },
      getValue: function (value, defaultValue) {
        if (typeof value === 'function') {
          value = value();
        }
        if (this.isNotNull(value) == false && this.isNotNull(defaultValue)) {
          value = defaultValue;
        }

        return value;
      },
      openDocu: function (pc_cd, docu_no, taxbil_no) {
        var package_fg = this.globalVariables.package_fg || '1';
        if (package_fg == '2') {
          var user = this.globalVariables.user || {};
          dews.api.get(dews.url.getApiUrl('TX', 'TxCommonServices', 'docu_info_get'), {
            data: {
              pc_cd: pc_cd || '',
              docu_no: docu_no || '',
              taxbil_no: taxbil_no || ''
            }
          }).done(function (data) {
            if (data) {
              var docuParams = {
                COMPANY_CD: user.companyCode,
                PC_CD: data.PC_CD || '',
                DOCU_NO: data.DOCU_NO || '',
                WRT_DEPT_CD: data.WRT_DEPT_CD || '',
                WRT_EMP_NO: data.WRT_EMP_NO || ''
              };
              dews.ui.openMenu('FI', 'GLDDOC00500', docuParams);
            }
          }).fail(function (xhr, status, error) {
            console.error(error);
            dews.alert(error, 'error');
          });
        } else {
          if (docu_no.toLowerCase() == 'copy') {
            var docuParams = {
              taxbil_no: taxbil_no,
            };
            dews.ui.openMenu('TX', 'VATTIM00300', docuParams);
          } else {
            var docuParams = {
              pc_cd: pc_cd, //회계단위코드
              docu_no: docu_no, //전표번호
            };
            dews.ui.openMenu('FI', 'GLDDOC00700', docuParams);
          }
        }
      },
      openAbDocu: function (pc_cd, docu_no, taxbil_no) {
    	  var docuParams = {
              pc_cd: pc_cd, //회계단위코드
              abdocu_no :  docu_no, //전표번호
            };
            dews.ui.openMenu('FI', 'GLDDOC01400', docuParams);
      },
      connectInterface: function (subProtocol) {
        var Version_JS = this.jsVersion();
        return new Promise(function (resolve, reject) {
          subProtocol = subProtocol || 'Service';
          var support = "MozWebSocket" in window ? 'MozWebSocket' : ("WebSocket" in window ? 'WebSocket' : null);
          if (support == null) {
            reject(ws, '현재 브라우저가 D-ERP Client Interface 를 지원하지 않습니다.');
          }
          else {
	    	  try {
	              ws = new window[support]('wss://localhost:53159/', subProtocol);
	            }
	            catch(e) {
	              reject('현재 브라우저는 구버전으로 파일제작이 불가능 합니다.\n\n마이크로소프트 엣지 및 구글 크롬 브라우저를 이용하시기 바랍니다.');
	            }
            ws.onopen = function (e) {
              // Handshake 메시지를 기다린다.
              ws.onmessage = function (e) {
                var result = JSON.parse(e.data);
                if (result.Result == 'Success' && result.Message == 'Welcome'){
                  let isNeedUpdate = false;
                  let isNeedUpdateMode = "";
                  if(result.Version_InterFace && result.Version_TXInterFace)
                  {
                    if(Number(result.Version_TXInterFace) < Number(Version_JS)){
                      // TX닷넷설치안됨, 메뉴배포됨
                      isNeedUpdate = true;
                      isNeedUpdateMode = "dot";
                    } else if(Number(result.Version_TXInterFace) > Number(Version_JS)){
                      // TX닷넷설치됨, 메뉴배포안됨
                      isNeedUpdate = true;
                      isNeedUpdateMode = "menu";
                    }
                  } else {  //버전관리 이전버전
                    isNeedUpdate = true;
                    isNeedUpdateMode = "none";
                  }
                  if(!isNeedUpdate)
                  {
                    resolve({ws: ws});
                  } else {
                    // 업데이트 로직
                    setTimeout(function () {
                      console.log("======= consoleInfoInterVersion =======");
                      console.log("jsVer : " + Version_JS);
                      console.log("interfaceVer : " + (result.Version_InterFace || ""));
                      console.log("txInterfaceVer : " + (result.Version_TXInterFace || ""));
                      console.log("======= ======================= =======");

                      if(isNeedUpdateMode == "dot" || isNeedUpdateMode == "none")
                      {
                        dews.ui.dialog('errorDialog', {
                          title: '전자신고 프로그램 설치',
                          content: '<div class="dews-ui-referbox" style="height: 190px;">' +
                            '  <ul>'+
                            '<li>전자신고 파일 작성 및 홈택스 연동서비스를 사용하기 위해서 </li>' +
                            '<li>업데이트 프로그램을 재설치하셔야 합니다.</li>' +
                            '<br>' +
                            '<span class="dews-text-care">파일 다운로드가 안되실 경우 : </span>' +
                            '<li>인터넷 주소창에 아래 URL을 직접 입력하여 수동 설치해주시기 바랍니다.</li>' +
                            '<li><span class="dews-text-warning">asp.duzonerp.co.kr/link/act_message/HDUPDATE/autohometax.zip </span></li>' +
                            '<br>' +
                            '<span class="dews-text-care">설치가 안될경우 :</span>' +
                            '<li>제어판>프로그램추가/제거>D-ERP Client Interface 검색하여</li>' +
                            '<li>제거 후 재설치 하시기 바랍니다.</li>' +
                            '</ul>' +
                            '</div>' +
                            '<div class="dews-button-group">' +
                            '  <button class="dews-ui-button" onclick="window.open(&quot;http://asp.duzonerp.co.kr/link/act_message/HDUPDATE/autohometax.zip&quot;)">' +
                            '파일 다운로드' + '</button>' +
                            '</div>',
                          buttons: 'close',
                          width: 520,
                          height: 320
                        }).open();
                      } else if(isNeedUpdateMode == "menu"){
                        dews.ui.dialog('errorDialog', {
                          title: 'ERP10 메뉴 업데이트 요청',
                          content: '<div class="dews-ui-referbox" style="height: 40px;">' +
                            '<ul>' +
                            '<li>메뉴 업데이트가 필요합니다.</li>' +
                            '<li>관리자에게 문의해주세요. </li>' +
                            '</ul>' +
                            '</div>' ,
                          buttons: 'close',
                          width: 360,
                          height: 140
                        }).open();
                      }

                    }, 0);
                    ws.close();
                    reject();
                  }
                } else {
                  ws.onclose = function (e) {};
                  ws.close();
                  reject('D-ERP Client Interface 를 시작중 오류가 발생했습니다. ' + result.Message);
                }
              }
            };
            ws.onclose = function (e) {
              switch (e.code) {
                case 1006:
                  // 설치 페이지 오픈
                  setTimeout(function () {
                    // dews.ui.dialog('errorDialog', {
                    //   title: '전자신고 프로그램 설치',
                    //   content: '<div class="dews-ui-referbox" style="height: 40px;">' +
                    //     '  <ul><li>전자신고 파일 작성 및 홈택스 연동서비스를 사용하기 위해서 아래 프로그램을 설치하셔야 합니다.</li>' + '</ul>' +
                    //     '</div>' +
                    //     '<div class="dews-button-group">' +
                    //     '  <button class="dews-ui-button" onclick="window.open(&quot;http://asp.duzonerp.co.kr/link/act_message/HDUPDATE/autohometax.zip&quot;)">' +
                    //     '파일 다운로드' + '</button>' +
                    //     '</div>',
                    //   buttons: 'close',
                    //   width: 360,
                    //   height: 200
                    // }).open();
                    dews.ui.dialog('errorDialog', {
                      title: '전자신고 프로그램 설치',
                      content: '<div class="dews-ui-referbox" style="height: 190px;">' +
                        '  <ul>'+
                        '<li>전자신고 파일 작성 및 홈택스 연동서비스를 사용하기 위해서 </li>' +
                        '<li>업데이트 프로그램을 재설치하셔야 합니다.</li>' +
                        '<br>' +
                        '<span class="dews-text-care">파일 다운로드가 안되실 경우 : </span>' +
                        '<li>인터넷 주소창에 아래 URL을 직접 입력하여 수동 설치해주시기 바랍니다.</li>' +
                        '<li><span class="dews-text-warning">asp.duzonerp.co.kr/link/act_message/HDUPDATE/autohometax.zip </span></li>' +
                        '<br>' +
                        '<span class="dews-text-care">설치가 안될경우 :</span>' +
                        '<li>제어판>프로그램추가/제거>D-ERP Client Interface 검색하여</li>' +
                        '<li>제거 후 재설치 하시기 바랍니다.</li>' +
                        '</ul>' +
                        '</div>' +
                        '<div class="dews-button-group">' +
                        '  <button class="dews-ui-button" onclick="window.open(&quot;http://asp.duzonerp.co.kr/link/act_message/HDUPDATE/autohometax.zip&quot;)">' +
                        '파일 다운로드' + '</button>' +
                        '</div>',
                      buttons: 'close',
                      width: 520,
                      height: 320
                    }).open();                    
                  }, 0);
                  //reject('D-ERP Client Interface 가 설치되지 않았습니다.');
                  reject();
                  break;
                default:
                  reject(e.reason);
                  break;
              }
            }
          }
        });
      },
      sendInterface: function (ws, serviceName, data) {

        // var jsonData = this.xmlToJson(data);
        // jsonData.jsVersion = this.jsVersion();
        // data = this.jsonToXml(jsonData);

        return new Promise(function (resolve, reject) {
          ws = ws && ws.hasOwnProperty('ws') ? ws.ws : ws;
          if (!ws || ws == null) {
            reject(ws, 'PROGMA ERROR : connectInterface first.');
            return;
          }
          ws.onmessage = function (e) {
            var result = JSON.parse(e.data);
            if (result.Result == 'Success') {
              resolve({
                ws: ws,
                data: result
              });
            } else {
              reject({
                ws: ws,
                reason: result
              });
            }
          };
          ws.onclose = function (e) {
            // reject({
            //   ws: ws,
            //   reason: e.reason
            // });
          }
          ws.send(JSON.stringify({
            ServiceName: serviceName,
            Data: data
          }));
        });
      },
      closeInterface: function (ws) {
        ws = ws && ws.hasOwnProperty('ws') ? ws.ws : ws;
        return new Promise(function (resolve, reject) {
          if (!ws || ws == null) {
            reject(ws, 'PROGMA ERROR : connectInterface first.');
            return;
          }
          ws.onerror = function (e) {
            reject(ws, e);
          };
          ws.onclose = function (e) {
            resolve(ws, e.CloseEvent);
          };
          ws.close();
        });
      },
      execInterface: function (method, data, onOpen) {
        var VC = this;
        var jsonToXml = function (json) {
          var isObject = function (val) {
            return val !== null && ((typeof val === 'function') || (typeof val === 'object'));
          }

          function _getNode(json, node, doc) {
            for (var key in json) {
              if (json.hasOwnProperty(key)) {
                var val = VC.getValue(json[key]);
                var el = doc.createElement(key);
                var _isObject = isObject(val);
                if (_isObject === false) {
                  $(el).text(val);
                }
                node.appendChild(el);
                if (_isObject === true) {
                  _getNode(val, el, doc);
                }
              }
            }
          }

          var doc = $.parseXML('<xml/>');
          var xml = doc.getElementsByTagName('xml')[0];
          _getNode(json, xml, doc);

          return xml.outerHTML;
        };

        location.replace('derp-client-interface://');
        var cancelToken = setInterval(function () {
          try {
            $.ajax({
                type: 'POST',
                url: 'http://localhost/derp-client-interface',
                data: jsonToXml({
                  method: 'echo',
                  token: VC.guid(),
                  data: {}
                }),
                timeout: 100
              })
              .done(function () {
                if (onOpen && typeof onOpen === 'function') onOpen();
                clearInterval(cancelToken);
                $.ajax({
                    type: 'POST',
                    url: 'http://localhost/derp-client-interface',
                    data: jsonToXml({
                      method: VC.getValue(method),
                      token: VC.guid(),
                      data: data
                    })
                  })
                  .done(function (responseData) {
                    var result = JSON.parse(responseData);
                    $.post('http://localhost/derp-client-interface', jsonToXml({
                      method: 'stop'
                    }));
                  })
                  .fail(function (xhr) {
                    if (xhr.status != 0) {
                      $.post('http://localhost/derp-client-interface', jsonToXml({
                        method: 'stop'
                      }));
                    }
                  });
              });
          } catch (e) {

          }
        }, 200);
        return cancelToken;
      },
      /**
       * 그리드 지원 클래스
       * @param {string} id 아이디
       * @param {string} type 그리드 타입 ( VC.gridTypes.grid / VC.gridTypes.cardlist )
       */
      GridComponent: function (id, type) {
        var VC = this;
        return {
          ////////////////////////////////// 속성 영역
          /**
           * 대표 ID = Grid.id 부여
           */
          id: id,
          /**
           * Grid 타입 : VC.gridtype 참조
           */
          type: type,
          /**
           * Grid 객체
           */
          grid: null,
          /**
           * DataSource 객체
           */
          dataSource: null,
          /**
           * CommonFunction 에서 수행되는 기능 제어. false 를 주면 해당 버튼에 참여안함.
           */
          allowFunctions: {
            add: true,
            delete: true,
            save: true,
            customValidation: false
          },
          /**
           * Read 서비스.
           */
          service: {
            read: {
              url: null,
              data: null
            }
          },
          /**
           * 그리드 저장시 Verifier 처리할 함수
           * function (data, showMessage, index, datas, gridComponent)
           */
          verifier: null,

          ////////////////////////////////// 메서드 영역
          /**
           * 데이터소스가 변경되었는지 (getDirtyDataCount) 여부를 리턴한다.
           * @returns {boolean} 데이터소스 변경여부
           */
          isDirty: function () {
            if (VC.isNotNull(this.dataSource))
              return this.dataSource.getDirtyDataCount() > 0;
            return false;
          },
          /**
           * 유효성 체크 함수를 사용해서 데이터 소스에서 유효성 실패한 RowIndex Array 를 리턴한다.
           * @param {boolean} showMessage 메시지를 발생여부. 주어진 유효성 체크 함수로 전달된다.
           * @param {boolean} stopIfNotVerified 유효성 실패 이후, 계속 유효성 체크를 할건지 여부.
           * @param {function} verifier 유효성 체크 함수. 기본적으로 GridComponent.verifier 사용. function (data, showMessage, index, datas, gridComponent)
           * @returns {Array<number>} 유효성 검사에 실패한 Row Index Array
           */
          verify: function (showMessage, stopIfNotVerified, verifier) {
            showMessage = VC.nvl(showMessage, true);
            stopIfNotVerified = VC.nvl(stopIfNotVerified, true);
            verifier = VC.nvl(verifier, this.verifier);
            var notVerifiedRows = [];
            var continueVerify = true;

            if (VC.isNotNull(verifier)) {
              var dirtyDataSet = this.dataSource.getDirtyData();
              for (var prop in dirtyDataSet) {
                if (prop === 'Deleted') continue;
                var datas = dirtyDataSet[prop];
                for (var index = 0; index < datas.length && continueVerify; index++) {
                  if (verifier(datas[index], showMessage, index, datas, this) == false) {
                    notVerifiedRows.push(index);
                    if (stopIfNotVerified) continueVerify = false;
                  }
                }
                if (continueVerify == false) break;
              }
            }
            return notVerifiedRows;
          },
          /**
           * 그리드와 데이터 소스의 값을 초기화 합니다.
           */
          clear: function () {
            if (VC.isNotNull(this.grid) && VC.isNotNull(this.dataSource)) {
              this.dataSource.data([]);
              if (this.dataSource.options.detail == true) {
                this.dataSource.options.lineDataSources = {};
                this.grid.setDataSource(this.dataSource);
              }
              if (this.grid.refresh) this.grid.refresh();
            }
          }
        };
      },

      /**
       * 페이지 클래스
       * 페이지 내에 데이터를 보유한 상태로 제공되는 다양한 기능을 제공한다.
       * @example
       * var page = VC.Page();
       */
      Page: function () {
        var VC = this;
        return {
          version: {
            FEVERSION: null,
            SERVICENAME: null,
            PACKAGE: null,
            SERVICE: null,
            VERSION: null,
            DRSCODE: null,
            VERSION_TX_COM: null,
            VERSION_TX_TSMCOM: null,
            VERSION_TSM_JS: null,
          },          
          // 각종 dataSet
          dataSet: {
            dewself: null,
            componentId: null,
            flag: {},
            cache: {},
            printDate: null,
            primaryKey: {},
            extraPrimaryKey: {},
            format_vr: {
              exrt_rt: '#,###.##',
              fmny_amt: '#,###.##'
            },
            package_fg: '1',
            package_yn: 'Y',
            background_color: '#1c90fb',
            sub_color: '#e6f3ff'
          },
          // 페이지내 그리드 지원
          grids: [],
          service: {
            save: {
              url: null
            }
          },
          dirty: false,
          ignoreDirty: false,
          /**
           * CommonCodeDtlService 서비스 사용.
           * @example
           * var dataSource = page.getFlagDataSource('MA', 'P00350');
           * @param {string} cd_module 모듈코드
           * @param {string} cd_field_pipe 코드디테일 코드(PIPE 사용)
           * @param {string} yn_sycode 시스템코드 유무(Y,N)
           * @param {string} yn_default 디폴트 코드구분(Y,N)
           * @param {string} yn_foreign 외국언어적용 유무(Y,N)
           * @param {string} dt_end 종료일
           * @param {string} nm_keyword 검색할 코드 또는 명
           * @param {boolean} reload 캐싱사용여부
           * @returns {*} 조회된 dataSource
           */
          getFlagDataSource: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword, reload) {
            if (module_cd == undefined || module_cd.length <= 0 ||
              cd_field_pipe == undefined || cd_field_pipe.length <= 0) {
              return;
            }
            var storedName = cd_field_pipe.endsWith('|') ? cd_field_pipe.substring(0, cd_field_pipe.length - 1) : cd_field_pipe;
            if (this.dataSet.flag.hasOwnProperty(module_cd) == false) this.dataSet.flag[module_cd] = {};
            if (this.dataSet.flag[module_cd].hasOwnProperty(storedName) == false || reload == true) this.dataSet.flag[module_cd][
              storedName
            ] = [];

            if (this.dataSet.flag[module_cd][storedName].length > 0)
              return this.dataSet.flag[module_cd][storedName];
            else {
              this.dataSet.flag[module_cd][storedName] = VC.getFlagDataSource(module_cd, cd_field_pipe, yn_sycode, base_yn,
                yn_foreign, end_dt, nm_keyword);
              // 캐싱을 위해 분해
              if (cd_field_pipe.indexOf('|')) {
                var cd_fields = cd_field_pipe.split('|');
                var self = this;
                cd_fields.forEach(function (field_cd) {
                  if (field_cd.length > 0)
                    self.dataSet.flag[module_cd][field_cd] = self.dataSet.flag[module_cd][storedName].filter(function (data) {
                      return data.FIELD_CD == field_cd;
                    });
                });
              }
            }
            return this.dataSet.flag[module_cd][storedName];
          },
          /**
           *
           */
          getFlagDefaultDataSource: function () {
            var dataSource = dews.ui.dataSource('dataSource', {
              data: [{
                  value: "Y",
                  text: "Yes"
                },
                {
                  value: "N",
                  text: "No"
                }
              ]
            });
            return dataSource;
          },
          getDropDownDataSource: function (module_cd, field_cd) {
            return dews.ui.dataSource('flagSource_' + module_cd + '_' + field_cd, {
              data: this.getFlagDataSource(module_cd, field_cd)
            });
          },
          /**
           * CommonCodeDtlService 서비스를 사용해서 DropDownList 의 값을 채워줌
           * 이를 사용하기 위해 html 상에서 element 에 다음 항목이 지정되어 있어야 한다.
           * ※ dews 공용속성이 아님.
           * 필수
           * data-dews-cd-module: 모듈 코드, CI_CODEDTL.CD_MODULE
           * data-dews-cd-field: 코드디테일 코드(PIPE 사용), CI_CODEDTL.CD_FIELD
           *
           * 옵션
           * data-dews-yn-sycode: 시스템코드 유무(Y,N)
           * data-dews-yn-default: 디폴트 코드구분(Y,N)
           * data-dews-yn-foreign: 외국언어적용 유무(Y,N)
           * data-dews-dt-end: 종료일
           * data-dews-nm-keyword: 검색할 코드 또는 명
           * @example
           * # html
           * <select id="tp_bizarea" class="dews-ui-dropdownlist"
           *  data-dews-cd-module="MA"
           *  data-dews-cd-field="P00350"
           *  data-dews-value-field="CD_SYSDEF"
           *  data-dews-text-field="NM_SYSDEF" />
           * # script
           * page.setDropdownlistDataSource(dewself.tp_bizarea, '1');
           * @param {*} component DEWS ui 컴포넌트
           * @param {boolean} reload 캐싱사용여부
           * @returns {*} 조회된 dataSource
           */
          setDropdownlistDataSource: function (component, defaultSelectionValue, reload) {
            reload = VC.nvl(reload, false);

            if (component == null) {
              console.error('setFlag() Error : component is null.');
              return;
            }
            var element = VC.getElement(component);
            if (element == null) {
              console.error('setFlag(' + component.id + ') Error : element context is null.');
              return;
            }

            var module_cd = element.dataset.hasOwnProperty('dewsCdModule') ? element.dataset.dewsCdModule : '';
            var field_cd = element.dataset.hasOwnProperty('dewsCdField') ? element.dataset.dewsCdField : '';
            if (module_cd == null || module_cd.length < 0 ||
              field_cd == null || field_cd < 0) {
              console.error('setFlag(' + id + ') Error : no attribute. data-dews-cd-module, data-dews-cd-field');
              return;
            }
            var yn_sycode = element.dataset.hasOwnProperty('dewsYnSycode') ? element.dataset.dewsYnSycode : '';
            var base_yn = element.dataset.hasOwnProperty('dewsYnDefault') ? element.dataset.dewsYnDefault : '';
            var yn_foreign = element.dataset.hasOwnProperty('dewsYnForeign') ? element.dataset.dewsYnForeign : '';
            var end_dt = element.dataset.hasOwnProperty('dewsDtEnd') ? element.dataset.dewsDtEnd : '';
            var nm_keyword = element.dataset.hasOwnProperty('dewsNmKeyword') ? elementContext.dataset.dewsNmKeyword : '';
            var dataSource = this.getFlagDataSource(module_cd, field_cd + '|', yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword,
              reload);

            component.setDataSource(dataSource);
            if (defaultSelectionValue != undefined && defaultSelectionValue != null && defaultSelectionValue.length > 0) {
              component.select(function (item) {
                return item.SYSDEF_CD == defaultSelectionValue;
              });
            }

            return dataSource;
          },
          /**
           * 초기화를 시작합니다.
           * 이후 반드시 endInitialize() 를 호출해야 합니다.
           * @param {*} dewself dewself
           * @param {json} componentId VC.componentId 참조
           */
          beginInitialize: function (dewself, componentId) {
            this.dataSet.dewself = dewself;
            this.dataSet.componentId = this.getComponentId(VC.nvl(componentId, {}));
            this.dataSet.cache = VC.getCache(dewself, this.dataSet.componentId);
            var commonInfo = VC.isNotNull(this.dataSet.cache.commonInfo) ? this.dataSet.cache.commonInfo : VC.getCommonInfo(
              dewself, this.dataSet.componentId);
            if ((commonInfo || []).length > 0) {
              this.dataSet.package_fg = ((commonInfo[0] || {}).PACKAGE_FG) || '1';
              this.dataSet.package_yn = ((commonInfo[0] || {}).PACKAGE_YN) || '1';
              this.dataSet.docu_proc_ty = ((commonInfo[0] || {}).DOCU_PROC_TY) || '1';
              this.dataSet.use_bg_fg = ((commonInfo[0] || {}).USE_BG_FG) || '1';
              this.dataSet.use_bizplan_yn = ((commonInfo[0] || {}).USE_BIZPLAN_YN) || 'N';
              this.dataSet.rdocu_ty = ((commonInfo[0] || {}).RDOCU_TY) || '11';

              VC.globalVariables.package_fg = this.dataSet.package_fg;
              VC.globalVariables.docu_proc_ty = this.dataSet.docu_proc_ty;
              VC.globalVariables.use_bg_fg = this.dataSet.use_bg_fg;
              VC.globalVariables.use_bizplan_yn = this.dataSet.use_bizplan_yn;
              VC.globalVariables.rdocu_ty = this.dataSet.rdocu_ty;

              VC.globalVariables.user = dewself.user;
              //this.dataSet.background_color = ((commonInfo[0] || {}).CLR_NM) || '#1c90fb';
              // if ((commonInfo[0] || {}).CLR_NM) == 'blue') {

              // }
              // 현대백화점일경우 공통 제어를 받지 않음.
              if (this.dataSet.package_fg == '2') {
                this.dataSet.background_color = '#3ababc';
                this.dataSet.sub_color = '#E0F8EC';
              } else {
                // html타이틀 색상을 dews메인 테마 색상으로 변경
                // 관련메뉴: 연말정산자료입력( 관리자, 사용자 ), 사업소득연말정산입력( 관리자, 사용자 )
                if ((commonInfo[0] || {}).CLR_NM == 'cyan') {
                  this.dataSet.background_color = '#2ba6ad';
                  this.dataSet.sub_color = '#E0F8EC';
                } else if ((commonInfo[0] || {}).CLR_NM == 'green') {
                  this.dataSet.background_color = '#51b44f';
                  this.dataSet.sub_color = '#E0F8EC';
                } else if ((commonInfo[0] || {}).CLR_NM == 'indigo') {
                  this.dataSet.background_color = '#3c61c2';
                  this.dataSet.sub_color = '#e6f3ff';
                } else if ((commonInfo[0] || {}).CLR_NM == 'orange') {
                  this.dataSet.background_color = '#f87e2d';
                  this.dataSet.sub_color = '#F8E6E0';
                } else if ((commonInfo[0] || {}).CLR_NM == 'purple') {
                  this.dataSet.background_color = '#7469cc';
                  this.dataSet.sub_color = '#F2E0F7';
                } else if ((commonInfo[0] || {}).CLR_NM == 'red') {
                  this.dataSet.background_color = '#d94c35';
                  this.dataSet.sub_color = '#F8E6E0';
                }
              }
            }
            this.initializeCodePicker();
            if ((VC.globalVariables.package_fg || '') == '2') {
              dews.ui.page.mainButtons.delete.useDefaultConfirm = false;
            }
          },
          /**
           * 초기화 작업을 종료합니다.
           */
          endInitialize: function () {
            this.dataSet.cache = {};
          },
          /**
           * 기본 componentId 를 바탕으로 컴포넌트 id 목록을 리턴합니다.
           * @param {json} componentId 컴포넌트 id 목록 null 가능
           * @returns {json} 컴포넌트 목록
           */
          getComponentId: function (componentId) {
            return $.extend(true, VC.componentId, componentId);
          },
          /**
           * 부가세 관련 컴포넌트를 초기화합니다.
           * VC.initializeComponents 참고
           * @example page.initializeComponents(dewself);
           * @param {*} dewself dewself
           * @param {json} componentId VATCommonClass.componentId 확인
           */
          initializeComponents: function () {
            var self = this;
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            VC.initializeComponents(dewself, componentId, componentId, this.dataSet.cache, function (componentType) {
              if (componentType == 'sq_modify') {
                self.dataSet.printDate = null;
              }
            });
          },
          /**
           * 부가세 관련 버튼을 초기화합니다.
           * VC.initializeButton 참고
           * @param {string} componentType 버튼 타입 ( btn_load / btn_removeAll / btn_printDate / btn_subBizArea / btn_vacct )
           * @param {function} yesFunction 불러오기 버튼에서 항목 체크후 '예' 를 클릭했을 때 호출되는 콜백함수
           * @param {Array<string>} options 불러오기 버튼일때 허용가능한 옵션 목록
           * @param {Array<json>} helpMessages 불러오기 버튼일때 표기되는 옵션별 메시지
           */
          initializeButton: function (componentType, yesFunction, options, helpMessages) {
            var self = this;
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            var componentInfo = VC.isNotNull(this.dataSet.cache.componentInfo) ? this.dataSet.cache.componentInfo : VC
              .getCommonComponentInfo(dewself, componentId);

            switch (componentType) {
              case 'btn_printDate':
                VC.initializeButton(dewself, componentType, componentId, this.dataSet.cache)
                  .setInitData(function () {
                    return {
                      printDate: self.printDate()
                    };
                  })
                  .yes(function (data) {
                    self.printDate(data.printDate);
                    if (VC.isNotNull(yesFunction))
                      yesFunction(data.printDate);
                  })
                  .done();
                break;
              case 'btn_openDocu':
                // 이건 page.focusedGrid 를 써야 해서 VC.initializeButton 를 못쓴다.
                componentInfo[componentType].$.off('click').on('click', function (e) {
                  try {
                    options = options || {};
                    var focusedGridComponent = self.getTargetGridComponent(options);
                    if (focusedGridComponent && focusedGridComponent != null) {
                      var focusedGrid = focusedGridComponent.grid;
                      if (focusedGrid && focusedGrid != null) {
                        if (focusedGrid.select() >= 0 && focusedGrid.dataItems().length > 0) {
                          var dataItem = focusedGrid.dataItem(focusedGrid.select());
                          var col_CD_PC = VC.nvl(options.pc_cd, 'PC_CD');
                          var col_NO_DOCU = VC.nvl(options.docu_no, 'DOCU_NO');
                          if (dataItem.hasOwnProperty(col_CD_PC) &&
                            dataItem.hasOwnProperty(col_NO_DOCU)) {
                            if (VC.isNotNull(dataItem[col_CD_PC]) && dataItem[col_CD_PC].length > 0 &&
                              VC.isNotNull(dataItem[col_NO_DOCU]) && dataItem[col_NO_DOCU].length > 0) {

                              if(VC.globalVariables.docu_proc_ty == '1')
                            	  VC.openDocu(dataItem[col_CD_PC], dataItem[col_NO_DOCU]);
                              else
                            	  VC.openAbDocu(dataItem[col_CD_PC], dataItem[col_NO_DOCU]);
                              return;
                            } else {
                              dews.ui.snackbar.info(VC.messages.btn_openDocu.not_docuData);
                              return;
                            }
                          }
                        }
                      }
                    }
                    dews.ui.snackbar.info(VC.messages.btn_openDocu.not_available);
                  } catch (e) {
                    dews.alert(e);
                  } finally {
                    $(e.target).blur();
                  }
                });
                break;
              case 'btn_viewDocu':
                // 이건 page.focusedGrid 를 써야 해서 VC.initializeButton 를 못쓴다.
                componentInfo[componentType].$.off('click').on('click', function (e) {
                  var viewSuccess = false;
                  try {
                    options = options || {};
                    var focusedGridComponent = self.getTargetGridComponent(options);
                    if (focusedGridComponent && focusedGridComponent != null) {
                      var focusedGrid = focusedGridComponent.grid;
                      if (focusedGrid && focusedGrid != null) {
                        if (focusedGrid.select() >= 0 && focusedGrid.dataItems().length > 0) {
                          var dataItem = focusedGrid.dataItem(focusedGrid.select());
                          var data = null;
                          if (typeof options.getData === 'function') {
                            data = options.getData({
                              field: {
                                name: focusedGrid.getCurrentColumn()
                              },
                              row: {
                                index: focusedGrid.select(),
                                data: dataItem
                              },
                              grid: focusedGrid,
                              id: focusedGridComponent.id
                            });
                          }

                          if (VC.isNotNull(data)) {
                            viewSuccess = true;
                            dews.ui.dialog('vatCommon_loadDialog', {
                              url: '/view/TX/VATVTM00100_COMMON_VIEWDOCU_POP',
                              title: VC.titles.btn_viewDocu + (VC.nvl(data.title, '').length > 0 ? '(' + data.title +
                                ')' :
                                ''),
                              width: 900,
                              height: 440,
                              initData: {
                                service: {
                                  url: data.url || options.url,
                                  data: data.data
                                },
                                visiableColumns: data.visiableColumns || []
                              },
                              ok: function (docuInfo) {
                                VC.openDocu(docuInfo.pc_cd, docuInfo.docu_no, docuInfo.taxbil_no);
                              }
                            }).open();
                          }
                        }
                      }
                    }
                    if (viewSuccess == false) {
                      dews.ui.snackbar.info(VC.messages.btn_viewDocu.not_available);
                    }
                  } catch (e) {
                    dews.alert(e);
                  } finally {
                    $(e.target).blur();
                  }
                });
                break;
            }
          },
          /**
           * 추가/수정/삭제 여부를 리턴합니다.
           * 1. 최근 문서 여부 : sq_modify ( 0. 정기, 1 ~ 수정 ) 가 최종적으로 작성된 것이 아닌경우 불가
           * 2. 서식 마감 여부 : 부가세 신고서상에서 해당 서식이 마감처리된 경우 불가 ( cd_form 참조 )
           * ※ 캐싱기능
           *  - 페이지의 공용 컴포넌트 값을 저장하여 재조회시 이 데이터가 달라졌다면 폐기 후 확인.
           * @param {boolean} reload 캐싱된 추가/수정/삭제 여부를 재조회 여부
           * @param {boolean} showMessage 수정불가일때 메시지 발생여부
           * @returns {boolean} 수정 가능 여부 true : 수정가능 / false : 수정불가
           */
          isEditable: function (reload, showMessage) {
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            if (VC.nvl(reload, false) || this.dataSet.cache.hasOwnProperty('commonInfo') == false) {
              this.dataSet.cache = VC.getCache(dewself, componentId);
            }
            var editable = VC.isEditable(dewself, showMessage, componentId, this.dataSet.cache);
            var showEditable = '';
            // if (this.dataSet.cache.commonInfo) {
            //   var commonInfo = this.dataSet.cache.commonInfo;
            //   if (editable == false) {
            //     if (commonInfo.CLOSE_YN == 'Y') {
            //       showEditable = 'closed';
            //     } else if (commonInfo.YN_RECENT == 'N') {
            //       showEditable = 'recent';
            //     }
            //     if (dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').hasClass(showEditable) == false) {
            //       dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').remove();
            //       var html = '<span id="tx_vat_editableLabel" class="@class" style="display: inline-block; background: @bgColor; color: white; text-align: center; line-height: 27px; height: 27px; width: @widthpx;">@text</span>';
            //       dewself.$content.find('.dews-button-group').prepend(
            //         $(html.replace('@class', showEditable)
            //           .replace('@bgColor', showEditable == 'closed' ? '#F44336' : '#FF9800')
            //           .replace('@width', showEditable == 'closed' ? '50' : '100')
            //           .replace('@text', showEditable == 'closed' ? '마감' : '다음차수존재'))
            //       );
            //     }
            //   } else {
            //     dewself.$content.find(".dews-button-group").children('#tx_vat_editableLabel').remove();
            //   }
            // }
            return editable;
          },
          /**
           * 마감여부에 따른 스타일 변경 및 그리드 입력 제어
           * @author 이호현 선임연구원
           * @since  2018-04-18
           * @param {string} editable Y.마감 N.취소
           * @example page.isClosed(editable)
           */
          onClosed: function (editable) {
            var dewself = this.dataSet.dewself;
            var showEditable = editable == 'Y' ? 'closed' : '';
            var gridComponents = this.grids;

            if (showEditable == 'closed') {
              if (dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').hasClass(showEditable) == false) {
                dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').remove();
                var html =
                  '<span id="tx_vat_editableLabel" class="@class" style="display: inline-block; background: @bgColor; color: white; text-align: center; line-height: 27px; height: 27px; width: @widthpx;">@text</span>';
                dewself.$content.find('.dews-button-group').prepend(
                  $(html.replace('@class', showEditable)
                    .replace('@bgColor', '#F44336')
                    .replace('@width', '50')
                    .replace('@text', '마감'))
                );
              }
            } else {
              dewself.$content.find(".dews-button-group").children('#tx_vat_editableLabel').remove();
            }
          },
          /**
           * 마감여부에 따른 입력 제어 및 메시지 호출( 문서번호 )
           * @author 이호현 선임연구원
           * @since  2019-02-11
           * @example page.closed()
           */
          closed: function (message) {
            var dewself = this.dataSet.dewself;
            var success = false;

            if (VC.isNotNull(this.CLOSE)) {
              if (VC.isIn(this.CLOSE, '1|9|')) {
                success = true;
              } else {
                if (message) {
                  if (VC.isIn(dewself.menu.id, 'TSMINC00200|TSMINC00300|TSMINC00400|TSMINC00500|')) {
                    if (this.closedMenu == 'TSMINM00300') {
                      dews.ui.snackbar.error('소득자별원천징수영수증이 마감되어 있습니다.');
                    } else {
                      dews.ui.snackbar.error('원천징수이행상황신고서가 마감되어 있습니다.');
                    }

                  } else if (VC.isIn(dewself.menu.id, 'TSMINM00300|TSMREW00200|TSMREL00100|TSMIND00200|') && VC.isIn(this.CLOSE,
                      '8|')) {
                    dews.ui.snackbar.error('신고용 파일이 전자결재 중입니다.');
                  }
                }
              }
            }

            return success;
          },
          /**
           * 마감여부에 따른 스타일 변경( 문서번호 )
           * @author 이호현 선임연구원
           * @since  2019-02-11
           * @param  data 문서번호 데이터
           * @example page.onDocuClosed(data)
           */
          onDisplayClosed: function (bizarea_cd, rvers_ym, paystd_ym) {
            try {
              var dewself = this.dataSet.dewself;
              var close_yn = '9',
                closed_menu;
              var text = '대기';

              function setClosed(data) {
                try {
                  var array = data.filter(function (d) {
                    return d.DECL_FG == '2'
                  })
                  var docu_no = [];

                  if (array.length > 0) {
                    $.each(array, function (index, value) {
                      docu_no.push(value.DOC_NO);
                    });
                    docu_no = docu_no.reduce(function (previous, current) {
                      return previous > current ? previous : current;
                    });
                    array = array.filter(function (d) {
                      return d.DOC_NO == docu_no;
                    })
                  } else {
                    array = data.filter(function (d) {
                      return d.CLOSE_YN != '9'
                    })
                    if (array.length > 0) {
                      $.each(array, function (index, value) {
                        docu_no.push(value.CLOSE_YN);
                      });
                      docu_no = docu_no.reduce(function (previous, current) {
                        return previous > current ? previous : current;
                      });
                      array = array.filter(function (d) {
                        return d.CLOSE_YN == docu_no;
                      })
                    } else {
                      return;
                    }
                  }

                  // console.log(docu_no);

                  close_yn = array[0].CLOSE_YN;
                  text = array[0].CLOSE_NM;
                  closed_menu = array[0].MENU_CD;
                } catch (error) {
                  console.log(error);
                }
              }

              // 소득입력 메뉴들은 소득자별원천징수영수증 마감을 우선으로 확인한다.
              if (VC.isIn(dewself.menu.id, 'TSMINC00200|TSMINC00300|TSMINC00400|TSMINC00500|')) {
                var impr_fg = dewself.menu.id == 'TSMINC00200' ? 'F' :
                  dewself.menu.id == 'TSMINC00300' ? 'G' :
                  dewself.menu.id == 'TSMINC00400' ? 'BI' :
                  dewself.menu.id == 'TSMINC00500' ? 'B' : null;
                dews.api.get(dews.url.getApiUrl('TX', 'TaxServiceManagementINCService', 'Tsminc00200_docu_list'), {
                    async: false,
                    data: {
                      'menu_cd': 'TSMINM00300',
                      'impr_fg': impr_fg || '',
                      'bizarea_cd': bizarea_cd || '',
                      'rvers_ym': rvers_ym || '',
                      'paystd_ym': paystd_ym || '',
                    }
                  })
                  .done(function (data) {
                    if (data.length > 0) {
                      setClosed(data);
                    }
                  })
                  .fail(function (xhr, status, error) {
                    console.error(error);
                  });
              }

              if (VC.isIn(close_yn, '1|9|')) {
                dews.api.get(dews.url.getApiUrl('TX', 'TaxServiceManagementINCService', 'Tsminc00200_docu_list'), {
                    async: false,
                    data: {
                      'menu_cd': 'TSMREW00200',
                      'impr_fg': 'W',
                      'bizarea_cd': bizarea_cd || '',
                      'rvers_ym': rvers_ym || '',
                      'paystd_ym': paystd_ym || '',
                    }
                  })
                  .done(function (data) {
                    if (data.length > 0) {
                      setClosed(data);
                    }
                  })
                  .fail(function (xhr, status, error) {
                    console.error(error);
                  });
              }

              this.CLOSE = close_yn;
              this.closedMenu = closed_menu;

              dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').remove();
              if (VC.isIn(close_yn, '1|')) {
                bgColor = '#ae6204';
              } else if (VC.isIn(close_yn, '2|3|')) {
                bgColor = '#1c90fb';
              } else if (VC.isIn(close_yn, '4|6|8|')) {
                bgColor = '#318164';
              } else if (VC.isIn(close_yn, '5|7|')) {
                bgColor = '#e85e30';
              } else {
                return;
              }

              // 2019-11-11 wrote by maestrox
              //  - 소득입력 메뉴들은 마감표시 되지 않도록 처리
              if (VC.isIn(dewself.menu.id, 'TSMINC00200|TSMINC00300|TSMINC00400|TSMINC00500|')) {
                return;
              }

              var html =
                '<span id="tx_vat_editableLabel" class="@class" style="display: inline-block; background: @bgColor; color: white; text-align: center; line-height: 27px; height: 27px; width: @widthpx;">@text</span>';
              dewself.$content.find('.dews-button-group').prepend(
                $(html.replace('@class', 'closed')
                  .replace('@bgColor', bgColor)
                  .replace('@width', '70')
                  .replace('@text', text))
              );

            } catch (error) {
              console.log(error);
            }
            return this.CLOSE;
          },
          /**
           * 마감여부에 따른 스타일 변경( 문서번호 )
           * @author 이호현 선임연구원
           * @since  2019-02-11
           * @param  data 문서번호 데이터
           * @example page.onDocuClosed(data)
           */
          onDisplayClosed2: function (data) {
            try {
              var dewself = this.dataSet.dewself;
              var bgColor = '#faa733';
              var text = '대기';
              var close_yn = '9';

              dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').remove();

              if (data.length > 0) {
                close_yn = data[0].CLOSE_YN;
                text = data[0].CLOSE_NM;

                if (VC.isIn(close_yn, '1|')) {
                  bgColor = '#ae6204';
                } else if (VC.isIn(close_yn, '2|3|')) {
                  bgColor = '#1c90fb';
                } else if (VC.isIn(close_yn, '4|6|8|')) {
                  bgColor = '#318164';
                } else if (VC.isIn(close_yn, '5|7|')) {
                  bgColor = '#e85e30';
                } else {
                  return;
                }

                var html =
                  '<span id="tx_vat_editableLabel" class="@class" style="display: inline-block; background: @bgColor; color: white; text-align: center; line-height: 27px; height: 27px; width: @widthpx;">@text</span>';
                dewself.$content.find('.dews-button-group').prepend(
                  $(html.replace('@class', 'closed')
                    .replace('@bgColor', bgColor)
                    .replace('@width', '70')
                    .replace('@text', text))
                );
              }
              this.CLOSE = close_yn;
            } catch (error) {
              console.log(error);
            }
          },
          /**
           * 마감여부에 따른 스타일 변경( 연말정산전용 )
           * @author 이호현 선임연구원
           * @since  2018-09-19
           * @param {string} close_yn 0.작업중 1.사용자마감 2.관리자마감 3.취소요청 4.마감취소
           * @example page.isClosed2(close_yn)
           */
          onClosed2: function (close_yn,cal_rst_fg, yrend_close_yn) {
            try {
              var dewself = this.dataSet.dewself;
              var bgColor; // = '#1c90fb';
              var width; // = '50';
              var text; // = '작업중';

              if (close_yn == '0') {
                bgColor = '#1c90fb';
                width = '70';
                text = '작업중'
              } else if (close_yn == '1') {
                bgColor = '#00CC66';

                if(cal_rst_fg != null) {
                	text = '사용자마감 ' + (cal_rst_fg == '1' ? '(일반)' : '(표준)');
                	width = '110';
                }
                else {
                	text = '사용자마감';
                	width = '90';
                }
              } else if (close_yn == '2') {
                bgColor = '#F44336';

                if(cal_rst_fg != null) {
                	text = '관리자마감 ' + (cal_rst_fg == '1' ? '(일반)' : '(표준)');
                	width = '110';
                }
                else {
                	text = '관리자마감';
                	width = '90';
                }
              } else if (close_yn == '3') {
                bgColor = '#febc2c';
                width = '70';
                text = '취소요청'
              } else if (close_yn == '4') {
                bgColor = '#9a83ff';
                width = '70';
                text = '마감취소'
              }
              if(yrend_close_yn =='Y')
              {
                text = '마감처리불가';
              }
              dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').remove();
              var html =
                '<span id="tx_vat_editableLabel" class="@class" style="display: inline-block; background: @bgColor; color: white; text-align: center; line-height: 27px; height: 27px; width: @widthpx;">@text</span>';
              dewself.$content.find('.dews-button-group').prepend(
                $(html.replace('@class', 'closed')
                  .replace('@bgColor', bgColor)
                  .replace('@width', width)
                  .replace('@text', text))
              );
            } catch (error) {
              console.log(error);
            }
          },
          /**
           * Page 내에 주어진 GridComponent 아이디가 유효한지 여부
           * @param {string} id 아이디
           * @returns {boolean} 유효여부
           */
          isValidId: function (id) {
            var gridComponent = this.grids.find(function (element) {
              return element.id == id;
            });
            if (gridComponent == undefined || gridComponent == null) return false;
            return true;
          },
          /**
           * 그리드 컴포넌트를 지정하거나 객체를 얻는다.
           * @example
           * function initializeGrid01() {
           *   var gridComponent = page.gridComponent('grid01', VC.gridTypes.grid);
           *   gridComponent.services.read = {
           *     url: dews.url.getApiUrl('MODULE', 'MIDDLE MODULE', 'SERVICE NAME'),
           *     data: function () { return {}; }
           *   };
           *   gridComponent.dataSource = dews.ui.dataSource(gridComponent.id, { ... });
           *   gridComponent.grid = dews.ui.grid('#' + gridComponent.id, {
           *     dataSource: gridComponent.dataSource,
           *     ...
           *   });
           * };
           * @param {string} id 그리드 id
           * @param {string} type 그리드 타입 ( VC.gridTypes.grid / VC.gridTypes.cardlist )
           * @returns {GridComponent} 그리드 컴포넌트 객체
           */
          gridComponent: function (id, type) {
            if (this.isValidId(id) == false) {
              this.grids.push(VC.GridComponent(id, type));
            }
            return this.grids.find(function (element) {
              return element.id == id;
            });
          },
          /**
           * Page 에 등록된 그리드 객체를 얻는다.
           * @param {string} id 그리드 id
           * @returns {dews.ui.grid} 그리드 객체
           */
          grid: function (id) {
            if (this.isValidId(id)) return this.gridComponent(id).grid;
            return undefined;
          },
          /**
           * Page 에 등록된 데이터 소스 객체를 얻는다.
           * @param {string} id 그리드 id
           * @returns {dews.ui.dataSource} 데이터 소스 객체
           */
          dataSource: function (id) {
            if (this.isValidId(id)) return this.gridComponent(id).dataSource;
            return undefined;
          },
          /**
           * 현재 포커스가 주어진 그리드 컴포넌트 객체를 얻는다.
           * @returns {GridComponent} 그리드 컴포넌트 객체
           */
          getFocusedGridComponent: function () {
            return this.grids.find(function (gridComponent) {
              return (VC.isNotNull(gridComponent.grid) &&
                gridComponent.grid.focused);
            });
          },
          /**
           * 현재 포커스가 주어진 그리드 객체를 얻는다.
           * @returns {dews.ui.grid} 그리드 객체
           */
          getFocusedGrid: function () {
            var gridComponent = this.getFocusedGridComponent();
            if (gridComponent != null && gridComponent != undefined) return gridComponent.grid;
            return null;
          },
          getTargetGridComponent: function (options) {
            options = $.extend(false, {
              fixed: undefined,
              target: undefined
            }, options);
            var fixed = VC.nvl(options.fixed, '');
            var target = VC.nvl(options.target, '');
            var gridComponent = null;
            if (fixed != '') {
              gridComponent = this.gridComponent(fixed);

              if (target != '' && gridComponent.allowFunctions.hasOwnProperty(target) && gridComponent.allowFunctions[target] ===
                false) {
                gridComponent = null;
              }
            } else {
              var targetGrids = target != '' ?
                this.grids.filter(function (gridComponent) {
                  return !(gridComponent.allowFunctions.hasOwnProperty(target) && gridComponent.allowFunctions[target] ===
                    false);
                }) : this.grids;

              if (targetGrids.length == 1)
                gridComponent = targetGrids[0];
              else gridComponent = targetGrids.find(function (gridComponent) {
                return (VC.isNotNull(gridComponent.grid) && gridComponent.grid.focused);
              });
            }

            return gridComponent;
          },
          /**
           * 페이지 내 DataSource 중 변경된 것이 있는지 리턴한다.
           * @returns {boolean} DataSource 변경여부
           */
          isDirty: function (options) {
            if (this.ignoreDirty) return false;
            if (this.dirty === true) return true;
            var dirtyGridComponents = this.getDirtyGridComponent(options);
            if (VC.isNotNull(dirtyGridComponents) && dirtyGridComponents.length > 0) return true;
            return false;
          },
          /**
           * 페이지 내 DataSource 변경이 발생한 GridComponent 를 리턴한다.
           * @returns {Array<GridComponent>} 변경된 GridComponent Array
           */
          getDirtyGridComponent: function (options) {
            if (this.ignoreDirty) return [];
            options = $.extend(false, {
              fixed: undefined
            }, options);
            var fixed = VC.nvl(options.fixed, '');
            var containsNoDirty = VC.nvl(options.containsNoDirty, false);
            var grids =
              fixed != '' ? [this.gridComponent(fixed)] :
              this.grids.filter(function (gridComponent) {
                return !(gridComponent.allowFunctions.hasOwnProperty('save') && gridComponent.allowFunctions.save === false);
              });

            return containsNoDirty === true ? grids :
              grids
              .filter(function (gridComponent, index, grids) {
                return gridComponent.isDirty();
              });
          },
          /**
           * 페이지 내 DataSource 중 변경된 DataSource Array 를 리턴한다.
           * @returns {Array<dews.ui.datasource>} 변경된 DataSource Array
           */
          getDirtyDataSource: function (options) {
            return this.getDirtyGridComponent(options)
              .map(function (gridComponent, index, grids) {
                return gridComponent.dataSource;
              });
          },
          /**
           * 페이지 내 모든 GridComponent 에 대해 유효성 체크를 실행한다.
           * @param {boolean} showMessage 메시지를 발생여부. 주어진 유효성 체크 함수로 전달된다.
           * @param {boolean} stopIfNotVerified 유효성 실패 이후, 계속 유효성 체크를 할건지 여부.
           * @param {function} verifier 유효성 체크 함수. function (data, showMessage, index, datas, gridComponent)
           * @returns {Array<?>} 유효성 검사 실패한 목록 { {GridComponent} gridComponent, {Array<int>} rows } Array
           */
          verify: function (options) {
            var showMessage = VC.nvl(options.showMessage, true);
            var stopIfNotVerified = VC.nvl(options.stopIfNotVerified, true);
            var verifier = options.stopIfNotVerified;
            var verified = [];
            var gridComponents = this.getDirtyGridComponent(options);

            for (var index = 0; index < gridComponents.length; index++) {
              var gridComponent = gridComponents[index];
              var notVerifiedRows = gridComponent.verify(showMessage, stopIfNotVerified, verifier);
              if (notVerifiedRows.length > 0) {
                verified.push({
                  gridComponent: gridComponent,
                  rows: notVerifiedRows
                });
              }
              if (stopIfNotVerified == true && notVerifiedRows.length > 0) break;
            }
            return verified;
          },
          /**
           * 페이지내 수정된 데이터 소스를 저장한다.
           * GridComponent.service.save.url 이 반드시 지정되어 있어야 동작한다.
           * @param {boolean} showMessage 성공/실패시 메시지 발생 여부
           * @returns {boolean} 저장 성공 여부
           */
          save: function (options) {
            if (VC.nvl(this.service.save.url, '') == '') return false;
            options = $.extend(false, {
              showMessage: true
            }, options);
            var showMessage = VC.nvl(options.showMessage, true);
            var models = VC.nvl(options.models, []);
            var result = true;
            var apiData = {};
            var saveGrids = this.grids.filter(function (gridComponent) {
              return !(gridComponent.allowFunctions.hasOwnProperty('save') && gridComponent.allowFunctions.save === false);
            });
            if (saveGrids.length > 0) {
              var rows = null;
              options = $.extend(true, options, {
                containsNoDirty: true
              });
              this.getDirtyDataSource(options).map(function (dataSource) {
                var result = {};
                result[dataSource.id] = $.extend(true, {
                  'Added': [],
                  'Updated': [],
                  'Deleted': []
                }, dataSource.getDirtyData());
                return result;
              }).forEach(function (data) {
                rows = $.extend(false, {}, rows, data);
              });
              apiData = $.extend(true, apiData, {
                rows: JSON.stringify(rows)
              });
            }
            if (models.length > 0) {
              var extraData = null;
              models.map(function (model, index) {
                var result = {};
                var name = 'data' + dews.number.format(index + 1, '00');
                result[name] = JSON.stringify(typeof model === 'function' ? model() : model);
                return result;
              }).forEach(function (data) {
                extraData = $.extend(false, {}, extraData, data);
              });
              apiData = $.extend(true, apiData, extraData);
            }
            dews.api.post(this.service.save.url, {
                async: false,
                data: apiData
              })
              .done(function () {
                if (showMessage) dews.ui.snackbar.ok(VC.messages.save.done);
              })
              .fail(function (xhr, status, error) {
                if ((VC.globalVariables.package_fg || '') == '2') {
                  dews.error(error);
                } else {
                  dews.error(VC.messages.save.error + '\n' + error);
                }
                result = false;
              });
            return result;
          },

          clear: function () {
            for (var idx = 0; idx < this.grids.length; idx++) {
              this.grids[idx].clear();
            }
            this.dirty = false;
          },
          /**
           * 범용적으로 로직이 구성된 기능버튼 함수 모음
           * onClosing : 페이지를 닫을 경우 그리드에 저장되지 않은 항목이 있을 경우 메시지 처리.
           * @example dewself.closing.on(page.commonFunctions(dewself).onClosing);
           * add: '추가' 버튼 클릭시 현재 포커스가 지정된 그리드에 Row 추가.
           * @example dews.ui.mainbuttons.add.on('click', page.commonFunctions(dewself).add);
           * delete: '삭제' 버튼 클릭시 현재 포커스가 지정된 그리드에서 삭제를 수행한다. (grid: 체크된 항목 삭제, cardlist: 선택된 항목 삭제)
           * @example dews.ui.mainbuttons.delete.on('click', page.commonFunctions(dewself).delete);
           * search: '조회' 버튼 클릭시 그리드에 저장되지 않은 항목이 있을 경우 메시지 처리.
           * @example dews.ui.mainbuttons.search.on('click', page.commonFunctions(dewself).search(onSearchData));
           * save: '저장' 버튼 클릭시 저장기능 수행
           * @example dews.ui.mainbuttons.save.on('click', page.commonFunctions(dewself).save);
           */
          commonFunctions: function (fixedGridId) {
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            var page = this;
            var package_fg = VC.globalVariables.package_fg || '';
            var commitCells = function () {
              try {
                dews.ui.page.find('.dews-ui-grid').each(function (idx, el) {
                  var grid = $(el).data('dews-control');
                  if (grid) {
                    grid.commitCell();
                  }
                });
              } catch (error) {
                console.error(error);
              }
            };
            return {
              onClosing: function (before, after) {
                return function (e) {
                  commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'onClosing'
                  };
                  if (typeof before === 'function' && before(e) == false) return;
                  if (page.isDirty(options)) {
                    return dews.confirm(VC.messages.closing.not_saved, 'ico2')
                      .yes(function () {
                        if (typeof after === 'function') after(e);
                      })
                      .no(function () {
                        e.preventDefault();
                      }).promise();
                  }
                };
              },
              add: function (before, after) {
                return function (e) {
                  commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'add'
                  };
                  e.preventDefault();
                  var gridComponent = page.getTargetGridComponent(options);
                  if (gridComponent != null && VC.isNotNull(gridComponent.grid)) {
                    var grid = gridComponent.grid;
                    var editable = page.isEditable(false, false);
                    var gridEditable = gridComponent.type == VC.gridTypes.grid ? (typeof grid.options.editable ==
                      'undefined' ?
                      true : grid.options.editable) : true;
                    if (page.isEditable() && gridEditable) {
                      if (typeof before === 'function' && before(gridComponent.id, editable, gridComponent) == false)
                        return;
                      grid.addRow();
                      grid.setFocus();
                      if (typeof after === 'function') after(gridComponent.id, editable, gridComponent);
                    }
                  }
                };
              },
              delete: function (before, after) {
                return function (e) {
                  commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'delete'
                  };
                  e.preventDefault();
                  var gridComponent = page.getTargetGridComponent(options);
                  if (gridComponent != null && VC.isNotNull(gridComponent.grid)) {
                    var grid = gridComponent.grid;
                    var checkedIndexes = [];
                    var gridEditable = gridComponent.type == VC.gridTypes.grid ? (typeof grid.options.editable ==
                      'undefined' ?
                      true : grid.options.editable) : true;
                    // switch (gridComponent.type) {
                    //   case VC.gridTypes.cardlist:
                    //     checkedIndexes.push(grid.select());
                    //     break;
                    //   case VC.gridTypes.grid:
                    //     if (grid.options.checkable == false) {
                    //       if (grid.dataItems().length > 0)
                    //         checkedIndexes.push(grid.select());
                    //     } else checkedIndexes = grid.getCheckedIndex();
                    //     break;
                    // }

                    if (grid.options.checkable == false) {
                      if (grid.dataItems().length > 0)
                        checkedIndexes.push(grid.select());
                    } else {
                      checkedIndexes = grid.getCheckedIndex();
                    }

                    if (checkedIndexes.length > 0) {
                      var editable = page.isEditable(false, false);
                      if (page.isEditable() && gridEditable) {
                        if (typeof before === 'function' && before(checkedIndexes, gridComponent.id, editable,
                            gridComponent) ==
                          false) return;
                        for (var i = checkedIndexes.length - 1; i >= 0; i--) {
                          grid.removeRow(checkedIndexes[i]);
                        }
                        grid.setFocus();
                        if (typeof after === 'function') after(checkedIndexes, gridComponent.id, editable, gridComponent);
                      }else{
                        //수정 불가상태에서 삭제시 메세지 처리 하기 위해서 argments에 "N" 추가
                        if (typeof before === 'function' && before(checkedIndexes, gridComponent.id, editable, gridComponent , "N") == false) return;
                      }
                    } else {
                      dews.ui.snackbar.info(gridComponent.type == VC.gridTypes.grid ? VC.messages.delete.no_rows.grid :
                        VC.messages
                        .delete.no_rows.cardlist);
                    }
                  }
                };
              },
              search: function (searchData) {
                return function (e) {
                  commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'search'
                  };
                  e.preventDefault();
                  if (typeof searchData !== 'function') {
                    console.error('searchData must be a function.');
                  } else {
                    var wrapperSearch = function () {
                      if (package_fg == '2') {
                        page.grids.forEach(function (grid) {
                          if (grid.dataSource && !grid.dataSource.options.error) {
                            grid.dataSource.options.error = function (e) {
                              if (e) {
                                dews.error(e);
                                dews.ui.loading.hide();
                              }
                            }
                          }
                        });
                      }
                      var result = searchData();
                      if (result !== false) {
                        page.storePrimaryKey();
                        page.dirty = false;
                      }
                    };
                    if (page.isDirty(options)) {
                      var confirm = dews.confirm(VC.messages.search.not_saved, 'ico2')
                        .yes(function () {
                          wrapperSearch();
                        });
                    } else wrapperSearch();
                  }
                };
              },
              save: function (before, after, models) {
                return function (e) {
                  commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'save',
                    models: models
                  };
                  e.preventDefault();
                  if (page.isDirty(options)) {
                    if (package_fg == '2') {
                      var gridComponents = page.getDirtyGridComponent(options);
                      for (var index = 0; index < gridComponents.length; index++) {
                        var gridComponent = gridComponents[index];
                        if (gridComponent.allowFunctions.customValidation == true) continue;
                        if (gridComponent.type == 'grid' && gridComponent.grid && (gridComponent.grid.validate(true) || {})
                          .result == false) {
                          dews.alert(VC.messages.save.verify, 'warning');
                          gridComponent.grid.setFocus();
                          return;
                        }
                      }
                    }
                    var verifyResult = page.verify(options);
                    if (verifyResult.length > 0) {
                      //verifyResult[0].gridComponent.grid.select(verifyResult[0].rows[0]);
                      verifyResult[0].gridComponent.grid.setFocus();
                    } else {
                      var editable = page.isEditable(true, false);
                      if (typeof before === 'function' && before(page.getDirtyDataSource(options), editable) == false)
                        return;
                      if (page.isEditable()) {
                        new Promise(function (resolve) {
                          if (package_fg == '2') {
                            var confirm = dews.confirm(VC.messages.save.ask, 'ico2')
                              .yes(function () {
                                setTimeout(function () {
                                  resolve();
                                }, 0);
                              })
                              .no(function () {
                                confirm.dialog.dialog.bind('deactivate', function () {
                                  dews.alert(VC.messages.save.cancel);
                                });
                              });
                          } else {
                            resolve();
                          }
                        }).then(function () {
                          return new Promise(function (resolve) {
                            dews.ui.loading.show({
                              text: VC.messages.save.saving
                            });
                            setTimeout(function () {
                              resolve();
                            }, 0);
                          });
                        }).then(function () {
                          return new Promise(function (resolve) {
                            if (package_fg == '2') {
                              options.showMessage = false;
                            }
                            resolve(page.save(options));
                          });
                        }).then(function (success) {
                          dews.ui.loading.hide();
                          if (success) {
                            page.ignoreDirty = true;
                            try {
                              dews.ui.mainbuttons.search.click();
                              if (package_fg == '2') {
                                setTimeout(function () {
                                  dews.alert(VC.messages.save.done);
                                }, 0);
                              }
                            } catch (ex) {
                              throw ex;
                            } finally {
                              page.ignoreDirty = false;
                            }
                          }
                          if (success && typeof after === 'function') after();
                        });
                      }
                    }
                  } else {
                    if (package_fg == '2') {
                      dews.alert(VC.messages.save.no_dirty);
                    } else {
                      dews.ui.snackbar.info(VC.messages.save.no_dirty);
                    }
                  }
                };
              },
              print: function (before, reportSet, rprt_cd, personalInfoFieldNames, customParam) {
                return function (e) {
                  VC.commitCells();
                  e.preventDefault();
                  if (typeof before === 'function' && before(reportSet, rprt_cd) == false) return;
                  page.invokePrint(reportSet, rprt_cd, personalInfoFieldNames, customParam);
                };
              }
            };
          },
          /**
           * 출력일을 설정하거나, 얻습니다.
           */
          printDate: function (printDate) {
            if (printDate != undefined) {
              this.dataSet.printDate = printDate;
            }
            var result = this.dataSet.printDate;
            if (result == null) {
              var dewself = this.dataSet.dewself;
              var componentId = this.dataSet.componentId;
              var componentInfo = VC.isNotNull(this.dataSet.cache.componentInfo) ? this.dataSet.cache.componentInfo : VC
                .getCommonComponentInfo(dewself, componentId);
              result = VC.todayString();
            }
            return result;
          },
          /**
           * fg_declterm 을 얻습니다.
           */
          // fg_declterm: function () {
          //   var dewself = this.dataSet.dewself;
          //   var componentId = this.dataSet.componentId;
          //   return VC.fg_declterm(dewself, componentId, this.dataSet.cache);
          // },
          /**
           * VC.cd_subBizArea() 참고
           */
          cd_subBizArea: function () {
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            return VC.cd_subBizArea(dewself, componentId, this.dataSet.cache);
          },
          /**
           * 현 검색조건의 PrimaryKey 를 저장합니다.
           * extranPrimaryKey 를 지정하면 해당 항목도 추가적으로 저장됩니다.
           * @param {json} extraPrimaryKey 추가 저장 목록
           */
          storePrimaryKey: function (extraPrimaryKey) {
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            var componentInfo = VC.isNotNull(this.dataSet.cache.componentInfo) ? this.dataSet.cache.componentInfo : VC
              .getCommonComponentInfo(dewself, componentId);

            this.dataSet.primaryKey = $.extend(true, {}, this.dataSet.primaryKey, {});
            if (VC.isNotNull(extraPrimaryKey)) {
              var loweredSet = {};
              for (var prop in extraPrimaryKey) {
                loweredSet[prop.toLowerCase()] = extraPrimaryKey[prop];
              }
              this.dataSet.extraPrimaryKey = $.extend(false, this.dataSet.extraPrimaryKey || {}, loweredSet);
            }
          },
          /**
           * Primary Key 를 얻습니다.
           */
          getPrimaryKey: function (primaryKeyName) {
            var dewself = this.dataSet.dewself;
            primaryKeyName = VC.isNotNull(primaryKeyName) ? primaryKeyName.toLowerCase() : primaryKeyName;

            if (VC.isNotNull(primaryKeyName) && primaryKeyName.length > 0) {
              if (this.dataSet.extraPrimaryKey != null && this.dataSet.extraPrimaryKey.hasOwnProperty(primaryKeyName))
                return this.dataSet.extraPrimaryKey[primaryKeyName];
              if (this.dataSet.primaryKey.hasOwnProperty(primaryKeyName))
                return this.dataSet.primaryKey[primaryKeyName];
              return '';
            } else {
              return $.extend(true, {}, this.dataSet.primaryKey, this.dataSet.extraPrimaryKey);
            }
          },
          /**
           * 그리드 rowAdd 이벤트 호출시 기본값을 지정합니다.
           */
          setPrimaryKeys: function (gridComponent, e) {
            if (e.hasOwnProperty('row') && e.row.hasOwnProperty('index') && e.row.hasOwnProperty('data')) {
              var primaryKeys = $.extend(false, {
                data_fg: '1',
              }, this.dataSet.primaryKey, this.dataSet.extraPrimaryKey);
              for (var primaryKey in primaryKeys) {
                if (e.row.data.hasOwnProperty(primaryKey.toUpperCase())) {
                  gridComponent.grid.setCellValue(e.row.index, primaryKey.toUpperCase(), primaryKeys[primaryKey]);
                }
              }
            }
          },
          /**
           * 인쇄 호출.
           * @argument {String} reportId
           * @argument {String} objectId
           * @argument {Json} parameters
           */
          invokePrint: function (reportSet, rprt_cd, personalInfoFieldNames, customParam) {
            var dewself = this.dataSet.dewself;
            var page = this;
            rprt_cd = VC.normalizeParameter(rprt_cd);
            if (VC.nvl(rprt_cd, '') == '') rprt_cd = 'R_' + (dewself.menu || {}).id + '_0';
            reportSet = VC.normalizeParameter(reportSet);
            if (typeof reportSet === 'undefined' || reportSet == null) {
              reportSet = {};
              reportSet['R_' + (dewself.menu || {}).id + '_01'] = {};
            }
            customParam = VC.normalizeParameter(customParam);
            new Promise(function (resolve) {
              if ((personalInfoFieldNames || []).length > 0) {
                var dialog = dews.ui.dialog('printPersonalConfigDialog', {
                  title: '인쇄',
                  content: '<div style="width: 100%; height: 50px; display: flex; flex-direction: row; align-items: center; justify-content: center;">' +
                    '<input type="checkbox" id="no_masking_yn" class="dews-ui-checkbox">' +
                    '<label for="no_masking_yn" style="text-align: left !important; margin-left: 5px">신고용(개인정보표시)</label>' +
                    '</div>' +
                    '<div class="dews-ui-referbox" style="height: 40px;">' +
                    '  <ul><li>개인정보마스킹 설정이 되어 있지 않다면, 보관용으로 인쇄하더라도 개인정보가 표시됩니다.</li></ul>' +
                    '</div>',
                  buttons: 'applyAndClose',
                  width: 400,
                  height: 210
                });
                dialog.buttons.ok.on('click', function () {
                  dialog.close();
                  resolve(dialog.$content.find('#no_masking_yn').prop('checked') ? 'Y' : 'N');
                });
                dialog.open();
              } else {
                resolve('N');
              }
            }).then(function (no_masking_yn) {
              var items = [];
              for (var object_cd in reportSet) {
                var parameters = $.extend(true, page.getPrimaryKey(), {
                    printdate: page.printDate(),
                    no_masking_yn: no_masking_yn
                  },
                  VC.normalizeParameter(reportSet[object_cd]));
                if ((personalInfoFieldNames || []).length > 0) {
                  personalInfoFieldNames.forEach(function (personalInfoFieldName) {
                    parameters['m_' + personalInfoFieldName] = dews.getSecureMaskFormat(personalInfoFieldName) ||
                      '';
                  });
                }
                for (var para_cd in parameters) {
                  items.push({
                    RPRT_CD: rprt_cd,
                    OBJECT_CD: object_cd,
                    PARA_CD: para_cd,
                    PARA_TXT: parameters[para_cd]
                  });
                }
              }
              dews.api.post(dews.url.getApiUrl('CM', 'printService', 'setPrintParam'), {
                data: {
                  reportCode: rprt_cd || '',
                  items: JSON.stringify(items)
                }
              }).done(function (parameterKey) {
            	  /* 파라미터 키 리턴 */
            	  if (VC.nvl(parameterKey, '').length > 0) {

            	  /* 2020-04-23 wrote by maestrox

            	  [시나리오 설명]

            	  1. A 라는 인쇄물이 A-1 로 개정이 되었다. 조회기간이 2019년에 A 인쇄물이 표시되어야 하고, 그 이후엔 A-1 인쇄물이 표시되어야 한다면 ?
            	  2. 인쇄 공통 [douzone-comet-service-common] 수정하는 방안이 있으나..
            	  3. 현백의 경우 공통 모듈 배포가 현실적으로 불가능 (업데이트 사용하지 않음)
            	  4. 결국 A-1 를 MA_REPORT_DTL 에 별개로 등록하고 조건에 따라 USE_YN 을 변경하는 것으로 처리

            	  */

            	    if(dewself.menu.id == 'TSMREW00200') {
            	      /*
            	      1) 메뉴가 '원천징수이행상황신고서'
            	      2) 지급년월이 202004 미만 인경우
            	      - [R_TSMREW00200_0][R_TSMREW00200_01][사용여부:Y]
            	      - [R_TSMREW00200_0][R_TSMREW00200_01_202004][사용여부:N]
            	      3) 지급년월이 202004 이상 인경우
            	      - [R_TSMREW00200_0][R_TSMREW00200_01][사용여부:N]
            	      - [R_TSMREW00200_0][R_TSMREW00200_01_202004][사용여부:Y]

            	      ※ 2020-05-22 wrote by maestrox
            	      - 이 부분 로직을 프론트단에서 제어할 수 있도록 유영준 연구가 처리한 건이 있는데, 향후 그 로직을 사용하는 것이
            	      - 바람직할 것으로 보임 (퇴직소득원천징수영수증 프론트 참고)
            	      */
            	      var printSettings = [];
            	      if(dewself.oYM_PAY.getStartDate() * 1 < 202004){
            	        printSettings.push({RPRT_CD: rprt_cd, OBJECT_CD: 'R_TSMREW00200_01', USE_YN : 'Y'});
            	        printSettings.push({RPRT_CD: rprt_cd, OBJECT_CD: 'R_TSMREW00200_01_202004', USE_YN : 'N'});
            	      }
            	      else {
            	        printSettings.push({RPRT_CD: rprt_cd, OBJECT_CD: 'R_TSMREW00200_01', USE_YN : 'N'});
            	        printSettings.push({RPRT_CD: rprt_cd, OBJECT_CD: 'R_TSMREW00200_01_202004', USE_YN : 'Y'});
            	      }
            	      dews.api.post(dews.url.getApiUrl('TX', 'TsmCommonServices', 'setPrintOption'), {async : false,data: {printSettings: JSON.stringify(printSettings)}});
            	    }
            	    // 2020-08-31 wrote by ironman
            	    // - 인쇄 방식 변경에 따른 작업
            	    if(page.dataSet.package_fg == '1'){
                    var options = {}
                    if(dewself.menu.id == "TSMREA00100"){ // 간이지급명세서

                      /* 귀속년도가 2021 이전 || 귀속년도 == 2021 && 상반기 인 경우, "1" 202107이후 데이터는 "2" */
                      // var _value = customParam.PAY_YM < 2021 ? "0" :(customParam.PAY_YM == 2021 && customParam.PAY_QT == "1" ? "0" : "1");

                      /* 파라미터 저장 요청
                        21.12.07. 출력옵션 로직 추가.
                      */
                      // var json = {printservice_filter:{colname:"GroupOfPrint",value:_value}};
                      // var json_encoded  = btoa(JSON.stringify(json)); //base64

                      options = {
                        reportId : rprt_cd,
                        parameterKey : parameterKey,
                        menuId : (dewself.menu || {}).id,
                        // customParams : json_encoded // 옵션을 가지고 분기처리 하려 하였으나 배포 문제로 보류 21.12.16
                      };
                    } else if(dewself.menu.id == "TSMYET01100") { // 근로소득원천징수영수증
                      /* 정산연도 2021하반기 이후부터는 1인 출력물만 */
                      // var _value = customParam.RVERS_YY < 2021 ? 0 : 1;

                      /* 파라미터 저장 요청
                        21.12.14. 출력옵션 로직 추가.
                      */
                      // var json = {printservice_filter:{colname:"GroupOfPrint",value:_value}};
                      // var json_encoded  = btoa(JSON.stringify(json)); //base64

                      options = {
                        reportId : rprt_cd,
                        parameterKey : parameterKey,
                        menuId : (dewself.menu || {}).id,
                        // customParams : json_encoded
                      };
                  }else {
                      options = {
                        reportId : rprt_cd,
                        parameterKey : parameterKey,
                        menuId : (dewself.menu || {}).id
                      };
                    }
            	      dews.app.print(options);
            	    }
            	    else if(page.dataSet.package_fg == '2'){
            	      /* 인증토큰 */
            	      var authToken = JSON.parse(dewself.token).access_token;
            	      /* 출력물 정보 */
            	      var reportInfoUrl = window.location.protocol + "//" + window.location.host + dews.url.getApiUrl('CM','printService', 'getPrintFormList');
            	      /* DRWebViewer 호출 */
            	      location.href = 'GERP://" "' + authToken + '" "' + rprt_cd + '" "' + reportInfoUrl + '" "' + parameterKey + '" "' + (dewself.menu || {}).id;
            	    }
            	  }
              });
            })
          },
          openMenu: function (moduleId, menuId, data) {
            dews.ui.openMenu(moduleId, menuId, $.extend(true, this.getPrimaryKey(), data));
          },
          getCodePickerID: function (id) {
            if ((this.dataSet.package_fg || '1') == '2') {
              switch (id) {
                case 'H_MA_PARTNER_MST_S':
                  id = 'H_MA_PARTNER_MST_S_HDG';
                  break;
                case 'H_PS_WBS_MST_S':
                  id = 'H_MA_PROJECT_MST_S';
                  break;
              }
            }
            return id;
          },
          getCodePickerOptions: function (options, source) {
            var page = this;
            if ((this.dataSet.package_fg || '1') == '2') {
              var id = (options || {}).helpCode || '';
              switch (id) {
                case 'H_MA_PARTNER_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_PARTNER_MST_S_HDG',
                    helpCustom: false,
                    helpParams: (function (helpParams) {
                      return function () {
                        var userHelpParams = {};
                        if (helpParams && typeof helpParams === 'function')
                          userHelpParams = helpParams(arguments);
                        else userHelpParams = helpParams || {};
                        var pc_cd_pipe = page.dataSet.dewself.user.profitCenterCode + '|';
                        var bizarea_cd_pipe = '';
                        switch ((source || '')) {
                          case 'component':
                            bizarea_cd_pipe = page.cd_subBizArea();
                            break;
                          case 'grid':
                            bizarea_cd_pipe = page.getPrimaryKey('subbizarea_cd');
                            break;
                        }
                        if (bizarea_cd_pipe && bizarea_cd_pipe.length > 0) {
                          dews.api.post(dews.url.getApiUrl('TX', 'TxCommonServices', 'pc_cd_list'), {
                            async: false,
                            data: {
                              bizarea_cd_pipe: bizarea_cd_pipe || '',
                            }
                          }).done(function (datas) {
                            if (datas && datas.length > 0) {
                              pc_cd_pipe = datas.map(function (data) {
                                return data.PC_CD;
                              }).join('|');
                            }
                          }).fail(function (xhr, status, error) {
                            console.error(error);
                            dews.alert(error, 'error');
                          });
                        }
                        return $.extend(true, {
                          'pc_cd': pc_cd_pipe || ''
                        }, userHelpParams);
                      };
                    })(options.helpParams)
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      if ((pickerData.PARTNER_FG_CD || '') == '7') {
                        pickerData.RES_NO = pickerData.PARTNER_MNG_NO;
                      }
                      callback(rowData, pickerData, rowIndex);
                    };
                  }
                  break;
                case 'H_PS_WBS_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_PROJECT_MST_S',
                    helpCustom: false,
                    codeField: 'PJT_NO',
                    textField: 'PJT_NM',
                    helpSize: 'big'
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      callback(rowData, $.extend(true, {}, pickerData, {
                        WBS_NO: pickerData.PJT_NO,
                        WBS_NM: pickerData.PJT_NM
                      }), rowIndex);
                    };
                  }
                  break;
                case 'H_FI_ASSET_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'AMGASC00200_IMPORT',
                    helpCustom: true,
                    codeField: 'ASSET_CD',
                    textField: 'ASSET_NM',
                    helpSize: 'medium',
                    helpViewUrl: '/view/FA/AMGASC00200_IMPORT',
                    helpTitle: '고정자산도움창'
                  });
                  break;
                case 'H_MA_COA_MST_S':
                case 'H_MA_COA_MST_S02':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_COA_MST_C',
                    helpCustom: true,
                    textField: 'FULL_ACCT_NM',
                    helpWidth: 700,
                    helpHeight: 600,
                    helpViewUrl: '~/codehelp/CM/H_MA_COA_MST_C',
                    helpApiUrl: '/api/CM/CMCustomCodeHelpService/H_MA_COA_MST_C_list_auto_comp',
                    helpParams: (function (helpParams) {
                      return function () {
                        var userHelpParams = {};
                        if (helpParams && typeof helpParams === 'function')
                          userHelpParams = helpParams(arguments);
                        else userHelpParams = helpParams || {};
                        userHelpParams = $.extend(false, {
                          gaap_cd: '',
                          end_dt: '',
                          drcrfg_cd: '',
                          acctattr_cd: '',
                          fsform_cd: 'D0012',
                          fill_yn: '',
                          keyword: '',
                          dept_cd: '',
                          grp_fg_cd: '',
                          relation_cd: '',
                          partner_mndr_fg_cd: '',
                          acct_cd: '',
                          acctlv_cd: '',
                          up_acct_cd: '',
                          input_fg: 'N',
                          pc_cd: dews.ui.page.user.profitCenterCode || '',
                          end_acct_fg: 'N'
                        }, userHelpParams);
                        if (id == 'H_MA_COA_MST_S02') {
                          userHelpParams = $.extend(false, { fill_yn: 'Y' }, userHelpParams);
                        }
                        return userHelpParams;
                      };
                    })(options.helpParams)
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      callback(rowData, $.extend(true, {}, pickerData, {
                        ACCT_NM: pickerData.FULL_ACCT_NM
                      }), rowIndex);
                    };
                  }
                  break;
                case 'H_MA_DEPT_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_DEPT_MST_C',
                    helpCustom: true,
                    textField: source == 'component' ? 'DEPT_NM' : 'FULL_DEPT_NM',
                    helpWidth: 700,
                    helpHeight: 600,
                    helpViewUrl: '~/codehelp/CM/H_MA_DEPT_MST_C',
                    helpApiUrl: '/api/CM/CMCustomCodeHelpService/H_MA_DEPT_MST_C_list_auto_comp',
                    helpParams: (function (helpParams) {
                      return function () {
                        var userHelpParams = {};
                        if (helpParams && typeof helpParams === 'function')
                          userHelpParams = helpParams(arguments);
                        else userHelpParams = helpParams || {};
                        userHelpParams = $.extend(false, {
                          company_cd: '',
                          bizarea_cd: helpParams.bizarea_cd,
                          pc_cd: '',
                          dept_cd: '',
                          dept_lv: '',
                          end_dt: '',
                          fill_yn: '',
                          keyword: '',
                          user_id: '',
                          eltr_athz_mngt_dept_yn: '',
                          input_fg: 'N',
                          end_dept_fg: 'N',
                          unauth_fg: 'N'
                        }, userHelpParams);
                        return userHelpParams;
                      };
                    })(options.helpParams)
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      callback(rowData, $.extend(true, {}, pickerData, {
                        DEPT_NM: pickerData[source == 'component' ? 'DEPT_NM' : 'FULL_DEPT_NM']
                      }), rowIndex);
                    };
                  }
                  break;
                case 'H_HR_EMP_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_HR_EMP_MST_S_HDG',
                  });
                  break;
              }
            }
            return options;
          },
          /**
           * 부가세 관련 현대백화점용 코드피커를 초기화합니다.
           * VC.initializeComponents 참고
           * @example page.initializeComponents();
           */
          initializeCodePicker: function (parentSelector) {
            var self = this;
            if ((self.dataSet.package_fg || '1') == '2') {
              var setCodePicker = function (idx, el) {
                var $el = $(el).data('dews-control');
                var options = ($el.getOptions() || {});
                var newOptions = self.getCodePickerOptions(options, 'component');
                if (newOptions != options) {
                  $el.setOptions(newOptions);
                }
              }
              if (VC.isNotNull(this.dataSet.dewself.menu)) {
                parentSelector = parentSelector || '#content_' + this.dataSet.dewself.menu.id;
                $(parentSelector + ' .dews-ui-codepicker').each(setCodePicker);
                $(parentSelector + ' .dews-ui-multicodepicker').each(setCodePicker);
              }

            }
          },
          getCodePickerEditor: function (options) {
            if ((options || {}).type == 'codepicker') {
              return this.getCodePickerOptions(options, 'grid');
            }
            return options;
          },
          // 현대백화점 전용
          addEvidenceDocumentPromise: function (evidenceTypeOrMenuCode, sourceKey) {
            var self = this;
            return new Promise(function (resolve, reject) {
              var evidenceKey = null;
              var companyCode = dews.ui.page.user.companyCode;
              var userCode = dews.ui.page.user.userid;
              if (self.dataSet.package_fg == '2') {
                switch (evidenceTypeOrMenuCode) {
                  case 'cash':
                  case 'VATHTX00400':
                    evidenceKey = sourceKey;
                    break;
                  case 'nts':
                  case 'VATETI00300':
                  case 'VATETI00900':
                    evidenceKey = sourceKey;
                    break;
                  default:
                    dews.api.post(dews.url.getApiUrl('TX', 'TxCommonServices', 'new_document_number_get'), {
                      async: false,
                      data: {}
                    }).done(function (data) {
                      if (data && data.HWRT_EVDN_CONN_KEY_VAL) {
                        evidenceKey = data.HWRT_EVDN_CONN_KEY_VAL;
                      }
                    }).fail(function (xhr, status, error) {
                      console.error(error);
                      dews.alert(error, 'error');
                      reject(error);
                    });
                    break;
                }
                if ((evidenceKey || '') != '') {
                  dews.ajax.script('~/view/js/fi.slip.js', {
                      once: true
                    })
                    .done(function () {
                      if ($.OfficeSLIP) {
                        $.OfficeSLIP.SLIP_Load(companyCode, userCode, evidenceKey, 'EDIT', 'FI', function () {
                          resolve(evidenceKey);
                        });
                      } else {
                        reject('slip script load error.');
                      }
                    })
                    .fail(function (xhr, status, error) {
                      console.error(error);
                      dews.alert(error, 'error');
                      reject(error);
                    });
                } else {
                  reject('evidenceKey is not valid.');
                }
              } else {
                reject('not suppored.');
              }
            });
          },
          viewEvidenceDocumentPromise: function (evidenceTypeOrMenuCode, evidenceKey) {
            var self = this;
            return new Promise(function (resolve, reject) {
              if (self.dataSet.package_fg == '2') {
                var companyCode = dews.ui.page.user.companyCode;
                var userCode = dews.ui.page.user.userid;
                if ((evidenceKey || '') != '') {
                  dews.ajax.script('~/view/js/fi.slip.js', {
                      once: true
                    })
                    .done(function () {
                      if ($.OfficeSLIP) {
                        $.OfficeSLIP.SLIP_Load(companyCode, userCode, evidenceKey, 'VIEW', 'FI', function () {});
                        resolve(evidenceKey);
                      } else {
                        reject('slip script load error.');
                      }
                    })
                    .fail(function (xhr, status, error) {
                      console.error(error);
                      dews.alert(error, 'error');
                      reject(error);
                    });
                } else {
                  reject('evidenceKey is not valid.');
                }
              } else {
                reject('not suppored.');
              }
            })
          },
          addOrViewEvidenceDocumentPromise: function (evidenceTypeOrMenuCode, evidenceKey, sourceKey) {
            if ((evidenceKey || '') == '') {
              return this.addEvidenceDocumentPromise(evidenceTypeOrMenuCode, sourceKey);
            } else {
              return this.viewEvidenceDocumentPromise(evidenceTypeOrMenuCode, evidenceKey);
            }
          },
          /**
           * 소득입력메뉴들 (TSMINC00200|TSMINC00300|TSMINC00400|TSMINC00500)
           * 예산컬럼 옵션처리
           * 1. TAX051 값에 따라서
           *      1 (미사용)  -> 컬럼 hide
           *      2 (필수)    -> 컬럼 show / required
           *      3 (선택)    -> 컬럼 show
           *
           * @author 주희정 연구원
           * @since  2021-05-21 최초개발
           * @example VC.settingBg(grid);
           */
           settingBg: function (grid) {
            try {
              var dewself = this.dataSet.dewself;
              var targetColumns = new Array('BG_NM', 'BGACCT_NM', 'BIZPLAN_NM');

              // 소득입력메뉴들
              if(VC.isIn(dewself.menu.id, 'TSMINC00200|TSMINC00300|TSMINC00400|TSMINC00500|')) {
                dews.api.get(dews.url.getApiUrl('TX', 'TaxServiceManagementREWService', 'Tsmrew00000_hr_config_mst_list'), {
                  async: false,
                  data: {
                    config_cd: 'TAX051',
                    emp_no: null || '',
                  }
                }).done(function (data) {
                  if (data.length > 0) {
                    var tax051 = data[0].CHAR_CD_VAL_DC;
                    var bizplan_yn = VC.globalVariables.use_bg_fg == '2' ? false : (VC.globalVariables.use_bg_fg == '1' && VC.globalVariables.use_bizplan_yn == 'Y');

                    $.each(targetColumns, function(idx, targetColumn){
                      var options = $.extend({}, grid.columns[targetColumn], {
                        attributes: {
                            class: tax051 == '2' ? targetColumn != 'BIZPLAN_NM' || (targetColumn == 'BIZPLAN_NM' && bizplan_yn) ? 'required' : 'none' : 'none'
                        },
                        visible: tax051 == '1' ? false : targetColumn == 'BIZPLAN_NM' ? bizplan_yn : true
                      });
                      grid.setColumn(targetColumn, options);
                    });
                  }
                })
                .fail(function (xhr, status, error) {
                  console.error(error);
                });
              }
            } catch (error) {
              console.error(error);
            }
          },

          /**
           * HR_INCOME_CLOSE_LIST 마감여부 조회 서비스 호출
           * @example var incomeCloseInfo = VC.getHrIncomeCloseList(bizarea_cd, impr_fg, rvers_ym, pay_ym);
         * bizarea_cd, impr_fg, rvers_ym, pay_ym
           * @returns {json} HR_INCOME_CLOSE_LIST 마감여부 조회 서비스 호출
           */
          getHrIncomeCloseList: function (bizarea_cd, impr_fg, rvers_ym, pay_ym) {
            dews.api.get(dews.url.getApiUrl('TX', 'TaxServiceManagementINCService', 'Tsminc_income_close_list'), {
                async: false,
                data: {
                  bizarea_cd: bizarea_cd || '',
                  impr_fg: impr_fg || '',
                  rvers_ym: rvers_ym || '',
                  pay_ym: pay_ym || ''
                }
              })
              .done(function (data) {
                incomeCloseInfo = data;
              })
              .fail(function (xhr, status, error) {
                console.error(error);
              });
            return incomeCloseInfo;
          },
          /**
           * 마감여부에 따른 스타일 변경( 그밖의소득입력 )
           * @author 이호현 선임연구원
           * @since  2018-09-19
           * @param {string} close_yn 1.마감 그외 작업중
           * @example page.isClosed2(close_yn)
           */
           onHrIncomeClosed: function (close_yn) {
            try {
              var dewself = this.dataSet.dewself;
              var bgColor;
              var width;
              var text;

              if (close_yn == '1') {
                // bgColor = '#00CC66'; // 사용자마감 색상
                bgColor = '#F44336';	// 관리자마감 색상
                text = '마감';
                width = '70';
              }
              dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').remove();
              if (close_yn == '1') {
                var html =
                  '<span id="tx_vat_editableLabel" class="@class" style="display: inline-block; background: @bgColor; color: white; text-align: center; line-height: 27px; height: 27px; width: @widthpx;">@text</span>';
                dewself.$content.find('.dews-button-group').prepend(
                  $(html.replace('@class', 'closed')
                    .replace('@bgColor', bgColor)
                    .replace('@width', width)
                    .replace('@text', text))
                );
              }
            } catch (error) {
              console.log(error);
            }
          }
        };
      },
      getTsmVersion: function (page) {
        try {
          // const extend = function (parent, child) {
          //   child = child || {};
          //   for (let prop in parent) {
          //     child[prop] = parent[prop];
          //   }
          //   return child;
          // };
          let jsVersion = this.getStickVersion();
          console.info("======= consoleInfoStickVersion ===================================================================================");
          console.info(" >> Front-end 버전 정보 :VERSION : " + page.version.FEVERSION);
          dews.api.get(dews.url.getApiUrl("TX", page.version.SERVICENAME, "getMapStickVersion"), {
          }).done(function (data) {
            if (data != null && data.length == 1) {
              // page.version = extend(data[0], page.version);
              $.extend( true, page.version, data[0] );
              page.version.VERSION_TSM_JS = jsVersion;
              // console.log(data[0], page.version);
              // return;
              console.info(" >> Back-end 버전 정보 : PACKAGE : " + page.version.PACKAGE);
              console.info(" >> Back-end 버전 정보 : SERVICE : " + page.version.SERVICE);
              console.info(" >> Back-end 버전 정보 : VERSION : " + page.version.VERSION);
              console.info(" >> Back-end 버전 정보 : DRSCODE : " + page.version.DRSCODE);
              console.info(" >> Back-end 버전 정보 : VERSION_TX_COM : " + page.version.VERSION_TX_COM);
              console.info(" >> Back-end 버전 정보 : VERSION_TX_TSMCOM : " + page.version.VERSION_TX_TSMCOM);
              console.info(" >> Front-end 버전 정보 : TSM_JS : " + page.version.VERSION_TSM_JS);
            }
            console.info("==================================================================================================================");
            if(page.dataSet.package_fg != '2' && page.version){
              // this.getTsmVersionDialog(page.version);
              // this.getStickVersion2();
              data = page.version;

        dews.ui.dialog('informationDialog', {
          title: 'ERP10 세무메뉴 정보',
          content:
            `<div id="informationDialog" class="dews-ui-dialog medium k-window-content k-content" data-role="window" style="" tabindex="0" role="dialog" aria-labelledby="informationDialog_wnd_title">` +
            `<div class="dews-dialog-contents" style="height: calc(100% - 60px);"><div class="menu-information-contents-area">` +
            `  <h4 class="dews-ui-title" id="basic-info">기본 정보</h4>` +
            `  <table>` +
            `    <colgroup>` +
            `      <col style="width:33.333%" span="3">` +
            `    </colgroup>` +
            `    <thead>` +
            `      <tr>` +
            `        <th id="menu-id">메뉴 ID</th>` +
            `        <th id="menu-name">메뉴</th>` +
            `        <th id="module">모듈</th>` +
            `      </tr>` +
            `    </thead>` +
            `    <tbody>` +
            `      <tr id="menu-info">        <td>`+ dews.ui.page.menu.id +`</td>` +
            `        <td>`+ dews.ui.page.menu.name +`</td>` +
            `        <td>`+ dews.ui.page.menu.module + (dews.ui.page.menu.module=="TX"?"(세무관리)" : '') +`</td></tr>` +
            `    </tbody>` +
            `  </table>` +
            `  <h4 class="dews-ui-title" id="version-title">Front/Back-end 정보</h4>` +
            `  <table>` +
            `    <colgroup>` +
            `      <col style="width:50%" span="2">` +
            `    </colgroup>` +
            `    <thead>` +
            `    <tr>` +
            `      <th>Front-end</th>` +
            `      <th>Back-end</th>` +
            `    </tr>` +
            `    </thead>` +
            `    <tbody>` +
            `    <tr>` +
            `      <td class="algL">` +
              `        <ul id="frontend-version"><li><strong>파일명&nbsp:&nbsp</strong>` + dews.ui.page.menu.id + `.html</li>` +
            `<li><strong>버전정보&nbsp:&nbsp</strong>` + data.FEVERSION + ` </li>` +
            `</ul>` +
            `      </td>` +
            `      <td class="algL">` +
              `        <ul id="backend-version"><li><strong>서비스명&nbsp:&nbsp</strong>` + data.SERVICE + `</li>` +
            `<li><strong>버전정보&nbsp:&nbsp</strong>` + data.VERSION + ` </li>` +
            `</ul>` +
            `      </td>` +
            `    </tr>` +
            `    </tbody>` +
            `  </table>` +

            `  <h4 class="dews-ui-title" id="version-title2">Front/Back-end common 정보</h4>` +
            `  <table>` +
            `    <colgroup>` +
            `      <col style="width:50%" span="2">` +
            `    </colgroup>` +
            `    <thead>` +
            `    <tr>` +
            `      <th>Front-end</th>` +
            `      <th>Back-end</th>` +
            `    </tr>` +
            `    </thead>` +
            `    <tbody>` +
            `    <tr>` +
            `      <td class="algL">` +
              `        <ul id="frontend-version2">` +
            `<li><strong>파일명&nbsp:&nbsp</strong>tx.tsm.js</li>` +
            `<li><strong>버전정보&nbsp:&nbsp</strong>` + data.VERSION_TSM_JS + ` </li>` +
            `</ul>` +
            `      </td>` +
            `      <td class="algL">` +
              `        <ul id="backend-version2"><li><strong>서비스&nbsp:&nbsp</strong>` +   `douzone-comet-service-tx-common` + `</li>` +
            `<li><strong>버전정보&nbsp:&nbsp</strong>` + data.VERSION_TX_COM + ` </li>` +
            `<li><strong>서비스&nbsp:&nbsp</strong>` + `douzone-comet-service-tx-tsmcommon` + `</li>` +
            `<li><strong>버전정보&nbsp:&nbsp</strong>` + data.VERSION_TX_TSMCOM + ` </li>` +
            `</ul>` +
            `      </td>` +
            `    </tr>` +
            `    </tbody>` +
            `  </table>` +
            `</div>` +
            ` </div> </div>` ,
          buttons: 'close',
          width: 800,
          height: 580
          }).open();

            }
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.warning(error);
          });
        } catch (error) {
          console.log(error);
        }
      },
      getStickVersion: function () {
        return "1.0.23021606";
      },
    };
  })();

  //////// 작성 영역 - 끝 ////////
  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=tx.tsm.js
