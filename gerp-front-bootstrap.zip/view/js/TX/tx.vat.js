/* 소스변환 : 김철희(netfuny) 변환시간 : 2018-08-28 08:39:06  */
// /view/js/tx.vat.js
/*
 * TX 모듈 부가세관리 공통 함수
 */
(function (dews, gerp, $) {
  var module = {};
  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'TX'; // 모듈 코드를 입력 해주세요.
  //////// Polyfill
  if (!Array.prototype.find) {
    Array.prototype.find = function (predicate) {
      'use strict';
      if (this == null) {
        throw new TypeError('Array.prototype.find called on null or undefined');
      }
      if (typeof predicate !== 'function') {
        throw new TypeError('predicate must be a function');
      }
      var list = Object(this);
      var length = list.length >>> 0;
      var thisArg = arguments[1];
      var value;
      for (var i = 0; i < length; i++) {
        value = list[i];
        if (predicate.call(thisArg, value, i, list)) {
          return value;
        }
      }
      return undefined;
    };
  }
  if (!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
      value: function (predicate) {
        'use strict';
        if (this == null) {
          throw new TypeError('Array.prototype.findIndex called on null or undefined');
        }
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }
        var list = Object(this);
        var length = list.length >>> 0;
        var thisArg = arguments[1];
        var value;
        for (var i = 0; i < length; i++) {
          value = list[i];
          if (predicate.call(thisArg, value, i, list)) {
            return i;
          }
        }
        return -1;
      },
      enumerable: false,
      configurable: false,
      writable: false
    });
  }
  if (!Array.from) {
    Array.from = (function () {
      var toStr = Object.prototype.toString;
      var isCallable = function (fn) {
        return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
      };
      var toInteger = function (value) {
        var number = Number(value);
        if (isNaN(number)) { return 0; }
        if (number === 0 || !isFinite(number)) { return number; }
        return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
      };
      var maxSafeInteger = Math.pow(2, 53) - 1;
      var toLength = function (value) {
        var len = toInteger(value);
        return Math.min(Math.max(len, 0), maxSafeInteger);
      };
      // The length property of the from method is 1.
      return function from(arrayLike /*, mapFn, thisArg */ ) {
        // 1. Let C be the this value.
        var C = this;
        // 2. Let items be ToObject(arrayLike).
        var items = Object(arrayLike);
        // 3. ReturnIfAbrupt(items).
        if (arrayLike == null) {
          throw new TypeError('Array.from requires an array-like object - not null or undefined');
        }
        // 4. If mapfn is undefined, then let mapping be false.
        var mapFn = arguments.length > 1 ? arguments[1] : void undefined;
        var T;
        if (typeof mapFn !== 'undefined') {
          // 5. else
          // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
          if (!isCallable(mapFn)) {
            throw new TypeError('Array.from: when provided, the second argument must be a function');
          }
          // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
          if (arguments.length > 2) {
            T = arguments[2];
          }
        }
        // 10. Let lenValue be Get(items, "length").
        // 11. Let len be ToLength(lenValue).
        var len = toLength(items.length);
        // 13. If IsConstructor(C) is true, then
        // 13. a. Let A be the result of calling the [[Construct]] internal method
        // of C with an argument list containing the single item len.
        // 14. a. Else, Let A be ArrayCreate(len).
        var A = isCallable(C) ? Object(new C(len)) : new Array(len);
        // 16. Let k be 0.
        var k = 0;
        // 17. Repeat, while k < len… (also steps a - h)
        var kValue;
        while (k < len) {
          kValue = items[k];
          if (mapFn) {
            A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
          } else {
            A[k] = kValue;
          }
          k += 1;
        }
        // 18. Let putStatus be Put(A, "length", len, true).
        A.length = len;
        // 20. Return A.
        return A;
      };
    }());
  }
  // 세무통합 공통
  module.VAT = (function () {
    return {
      ////////////////////////////////// 속성 영역
      /**
       * 공용 메시지
       */
      messages: {
        search: {
          not_saved: '저장하지 않은 데이터가 있습니다.' + '\n' + '조회를 계속하시겠습니까?'
        },
        edit: {
          closed: '마감 되었습니다.',
          notRecent: '다음 차수가 존재합니다.'
        },
        delete: {
          no_rows: {
            grid: '삭제할 항목을 체크해 주십시오.',
            cardlist: '삭제할 항목을 선택해 주십시오.'
          },
          ask: '삭제 하시겠습니까?' + '\n' + '(반드시 저장을 하셔야 반영이 됩니다.)'
        },
        save: {
          ask: '저장하시겠습니까?',
          no_dirty: '저장할 데이터가 없습니다.',
          done: '저장이 완료되었습니다.',
          error: '자료를 저장하는 중 오류가 발생되었습니다.',
          verify: '필수항목을 입력하지 않았습니다.',
          saving: '저장하는 중입니다.'
        },
        closing: {
          not_saved: '저장하지 않은 데이터가 있습니다.' + '\n' + '닫기를 계속하시겠습니까?'
        },
        btn_load: {
          no_options: '불러오기 할 수 있는 항목이 없습니다.',
          done: '불러오기가 완료되었습니다.'
        },
        btn_removeAll: {
          ask: '<p align="left">' +
            '신고방식 : {0}' + '\n' +
            '사 업 장 : {1}' + '\n' +
            '과세기간 : {2}~{3}' + '\n' +
            '신고구분 : {4}' + '\n' +
            '입력된 데이터를 모두 삭제합니다.' + '\n' +
            '삭제하시겠습니까?' + '</p>',
          done: '일괄삭제가 완료되었습니다.'
        },
        btn_subBizArea: {
          no_code: '사업장 코드를 입력하십시오.'
        },
        btn_openDocu: {
          not_available: '전표이동 할 항목을 선택해 주십시오.',
          not_docuData: '전표에서 불러오기 한 항목이 아닙니다.'
        },
        btn_viewDocu: {
          not_available: '전표조회 할 항목을 선택해 주십시오.'
        },
      },
      /**
       * 공용 타이틀 혹은 텍스트
       */
      titles: {
        decl_fg: '신고방식',
        bizarea_cd: '사업장',
        vat_ym: '과세기간',
        from_ym: '과세기간 시작일',
        to_ym: '과세기간 종료일',
        mrtf_sq: '신고구분',
        btn_load: '불러오기',
        btn_printDate: '출력일',
        btn_subBizArea: '종사업장',
        btn_vacct: '계정등록',
        btn_openDocu: '전표이동',
        btn_viewDocu: '전표조회',
        btn_closeBizArea : '휴폐업조회'
      },
      /**
       * 데이터 셋
       */
      dataSet: {
        flag: {},
      },
      /**
       * 공용 컴포넌트 ID 목록
       */
      componentId: {
        // 검색조건
        decl_fg: 'oFG_DECL', // 신고방식
        bizarea_cd: 'oCD_BIZAREA', // 사업장
        vat_ym: 'oYM_VAT', // 과세기간
        mrtf_sq: 'oSQ_MODIFY', // 신고구분
        form_cd: null, // 전자신고첨부서식코드 ( ※ 컴포넌트 아님, sq_modify 에 HelpParams 으로 제공 )
        // 버튼
        btn_load: 'btn_load', // 불러오기
        btn_removeAll: 'btn_removeAll', // 일괄삭제
        btn_printDate: 'btn_printDate', // 출력일
        btn_subBizArea: 'btn_subBizArea', // 종사업장
        btn_vacct: 'btn_vacct', // 계정등록
        btn_openDocu: 'btn_openDocu', // 전표이동
        btn_viewDocu: 'btn_viewDocu', // 전표조회
        btn_closeBizArea : 'btn_closeBizArea',
      },
      /**
       * 그리드 컴포넌트 종류 ( grid, cardlist... )
       */
      gridTypes: {
        grid: 'grid',
        cardlist: 'cardlist'
      },
      globalVariables: {},
      ymVat: {},
      ////////////////////////////////// 메서드 영역
      /**
       * value 가 null 이거나 undefined 가 아니라면 true 를 리턴
       * @param {*} value 체크객체
       * @returns {boolean} Not Null 인지 여부
       */
      isNotNull: function (value) {
        return (value != null && value != undefined && value != "");
      },
      /**
       * Oracle NVL 유사함수.
       * value 가 null 혹은 undefined 라면 nullValue 를 리턴한다.
       * @example showMessage = VC.nvl(showMessage, true);
       * @param {*} value 체크 값
       * @param {*} nullValue null/undefined 기본값
       * @returns {*} value 혹은 nullValue
       */
      nvl: function (value, nullValue) {
        return this.isNotNull(value) == false ? nullValue : value;
      },
      number: function (value) {
        return $.isNumeric(value) ? Number(value) : 0;
      },
      /**
       * 현재일자의 yyyyMMdd 형식 문자열
       * @example var today = VC.todayString();
       * @returns yyyyMMdd 형식 날짜
       */
      todayString: function () {
        return dews.date.format(new Date(), 'yyyyMMdd');
      },
      commitCells: function (dewself) {
        try {
          if (!dewself) {
            dewself = dews.ui.page;
          }
          if (dewself && dewself.$content) {
            dewself.$content.find('.dews-ui-grid').each(function (idx, el) {
              var grid = $(el).data('dews-control');
              if (grid) {
                grid.commitCell();
              }
            });
          }
        } catch (error) {
          console.error(error);
        }
      },
      /**
       * vatvtm00100_common_info_get 서비스 호출
       * 내부적으로 쓰임
       * @example var commonInfo = VC.getCommonInfo(dewself);
       * @param {*} dewself dewself
       * @param {json} componentId VC.componentId 참조
       * @param {json} cache 캐시 객체
       * @returns {json} vatvtm00100_common_info_get 호출값
       */
      getCommonInfo: function (dewself, componentId, cache) {
        var VC = this;
        cache = $.extend(false, {}, cache);
        var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself,
          componentId);
        var commonInfo = null;
        var from_ym = componentInfo.vat_ym.valid == true ? this.nvl(componentInfo.vat_ym.value().from, '') : '';
        var to_ym = componentInfo.vat_ym.valid == true ? this.nvl(componentInfo.vat_ym.value().to, '') : '';
        if (from_ym.length <= 0 && componentInfo.vat_ym.valid == true)
          from_ym = VC.getDefaultValue(dewself, componentId, cache, 'from_ym');
        if (to_ym.length <= 0 && componentInfo.vat_ym.valid == true)
          to_ym = VC.getDefaultValue(dewself, componentId, cache, 'to_ym');
        dews.api.get(dews.url.getApiUrl('TX', 'ValueAddedTaxManagementVTMService', 'vatvtm00100_common_info_get'), {
            async: false,
            data: {
              decl_fg: componentInfo.decl_fg.valid ? this.nvl(componentInfo.decl_fg.value(), '') : '',
              bizarea_cd: componentInfo.bizarea_cd.valid ? this.nvl(componentInfo.bizarea_cd.value().code, '') : '',
              from_ym: from_ym,
              to_ym: to_ym,
              mrtf_sq: componentInfo.mrtf_sq.valid ? this.nvl(componentInfo.mrtf_sq.value().code, '') : '',
              form_cd: componentInfo.form_cd ? this.nvl(componentInfo.form_cd.value, '') : '',
              cd_bizarea_user: dews.ui.page.user.bizAreaCode || ''
            }
          })
          .done(function (data) {
            commonInfo = data;
          })
          .fail(function (xhr, status, error) {
            console.error(error);
          });
        return commonInfo;
      },
      /**
       * 공용 컴포넌트의 각종 정보를 리턴한다.
       * @param {object} dewself dewself
       * @param {json} componentId 공용 컴포넌트 목록 ( VC.componentId 확인 )
       * @returns {json} 공용 컴포넌트 정보
       */
      getCommonComponentInfo: function (dewself, componentId) {
        var VC = this;
        function _getId(componentType) {
          return componentId.hasOwnProperty(componentType) ? componentId[componentType] : null;
        }
        function _getComponent(componentType) {
          return componentId.hasOwnProperty(componentType) ? dewself[componentId[componentType]] : null;
        }
        function _getJQuery(componentType) {
          return componentId.hasOwnProperty(componentType) ? dewself['$' + componentId[componentType]] : null;
        }
        function _getComponentInfo(componentType, valueFunc) {
          var component = _getComponent(componentType);
          return {
            valid: (component != null),
            id: _getId(componentType),
            component: component,
            '$': _getJQuery(componentType),
            value: valueFunc(component)
          };
        }
        function _getButtonInfo(buttonType) {
          var component = _getComponent(buttonType);
          var jquery = _getJQuery(buttonType);
          return {
            valid: component != null,
            id: _getId(buttonType),
            component: component,
            '$': jquery,
            enabled: function (enabled) {
              if (VC.isNotNull(enabled)) {
                if (!enabled) {
                  jquery.attr('disabled', 'disabled');
                  jquery.addClass('k-state-disabled');
                } else {
                  jquery.removeAttr('disabled');
                  jquery.removeClass('k-state-disabled');
                }
              }
              return (jquery.attr('disabled') === 'disabled') == false;
            }
          };
        }
        var mrtf_sq = _getComponent('mrtf_sq');
        var form_cd = componentId.hasOwnProperty('form_cd') && componentId.form_cd != null ? componentId.form_cd : null;
        if (form_cd == null && mrtf_sq != null) {
          var sq_modify_options = mrtf_sq.getOptions();
          if (sq_modify_options.helpParams != null && sq_modify_options.helpParams.hasOwnProperty('form_cd')) {
            form_cd = sq_modify_options.helpParams.form_cd;
          }
        }
        return {
          decl_fg: _getComponentInfo('decl_fg', function (component) {
            return function (value) {
              if (value != undefined) {
                component.value(value);
              }
              return component.value();
            };
          }),
          bizarea_cd: _getComponentInfo('bizarea_cd', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = String(value.code);
                data[option.textField] = String(value.text);
                component.setData(data);
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          vat_ym: _getComponentInfo('vat_ym', function (component) {
            return function (value) {
              if (value != undefined) {
                component.setPeriod(value.from, value.to);
              }
              return {
                from: component.getStartDate(),
                to: component.getEndDate()
              };
            };
          }),
          mrtf_sq: _getComponentInfo('mrtf_sq', function (component) {
            return function (value) {
              if (value != undefined) {
                var option = component.getOptions();
                var data = {};
                data[option.codeField] = String(value.code);
                data[option.textField] = String(value.text);
                component.setData(data);
              }
              return {
                code: component.code(),
                text: component.text()
              };
            };
          }),
          form_cd: {
            valid: (form_cd != null),
            value: form_cd
          },
          btn_load: _getButtonInfo('btn_load'),
          btn_removeAll: _getButtonInfo('btn_removeAll'),
          btn_printDate: _getButtonInfo('btn_printDate'),
          btn_subBizArea: _getButtonInfo('btn_subBizArea'),
          btn_vacct: _getButtonInfo('btn_vacct'),
          btn_openDocu: _getButtonInfo('btn_openDocu'),
          btn_viewDocu: _getButtonInfo('btn_viewDocu'),
          btn_closeBizArea : _getButtonInfo('btn_closeBizArea'),
        };
      },
      /**
       * CommonCodeDtlService 서비스 사용.
       * @example var dataSource = page.getFlagDataSource('MA', 'P00350');
       * @param {string} cd_module 모듈코드
       * @param {string} cd_field_pipe 코드디테일 코드(PIPE 사용)
       * @param {string} yn_sycode 시스템코드 유무(Y,N)
       * @param {string} yn_default 디폴트 코드구분(Y,N)
       * @param {string} yn_foreign 외국언어적용 유무(Y,N)
       * @param {string} dt_end 종료일
       * @param {string} nm_keyword 검색할 코드 또는 명
       * @returns {Array<JSON>} 조회된 dataSource [ { CD_SYSDEF, NM_SYSDEF } ]
       */
      getFlagDataSource: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword, reload) {
        var self = this;
        yn_sycode = self.nvl(yn_sycode, '');
        base_yn = self.nvl(base_yn, '');
        yn_foreign = self.nvl(yn_foreign, '');
        end_dt = self.nvl(end_dt, self.todayString());
        nm_keyword = self.nvl(nm_keyword, '');
        reload = self.nvl(reload, false);
        if (module_cd == undefined || module_cd.length <= 0 ||
          cd_field_pipe == undefined || cd_field_pipe.length <= 0) {
          return;
        }
        if (self.dataSet.flag.hasOwnProperty(module_cd) == false) self.dataSet.flag[module_cd] = {};
        var cd_fields = cd_field_pipe.split('|').filter(function (field_cd) {
          return self.isNotNull(field_cd) && field_cd.length > 0;
        });
        var uncachedFields = cd_fields.filter(function (field_cd) {
          return reload || self.dataSet.flag[module_cd].hasOwnProperty(field_cd) == false;
        });
        if (uncachedFields && uncachedFields != null && uncachedFields.length > 0) {
          dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", "common_codeDtl_list"), {
            async: false,
            data: {
              module_cd: module_cd, // 모듈
              field_cd_pipe: uncachedFields.join('|') + '|', // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
              syscode_yn: yn_sycode, // 시스템코드 유무(Y,N)
              base_yn: base_yn, // 디폴트 코드구분(Y,N)
              foreign_yn: yn_foreign, // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
              end_dt: end_dt, // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
              keyword: nm_keyword, // 검색할 코드 또는 명
            }
          }).done(function (data) {
            if (data.length > 0) {
              uncachedFields.forEach(function (field_cd) {
                self.dataSet.flag[module_cd][field_cd] = data.filter(function (data) {
                  return data.FIELD_CD == field_cd;
                });
              });
            } else {
              console.error('getFlagDataSource(' + 'module_cd' + ', ' + 'cd_field_pipe' + ', ' + 'yn_sycode' + ', ' +
                'base_yn' + ', ' + 'yn_foreign' + ', ' + 'end_dt' + ', ' + 'nm_keyword' + ') Error : no data retrieved.');
            }
          }).fail(function (xhr, status, error) {
            console.error('getFlagDataSource(' + 'module_cd' + ', ' + 'cd_field_pipe' + ', ' + 'yn_sycode' + ', ' + 'base_yn' +
              ', ' + 'yn_foreign' + ', ' + 'end_dt' + ', ' + 'nm_keyword' + ') Error : ' + error);
          });
        }
        if (cd_fields.length == 1) return self.dataSet.flag[module_cd][cd_fields[0]];
        else {
          var result = [];
          cd_fields.forEach(function (field_cd) {
            result = result.concat(self.dataSet.flag[module_cd][field_cd]);
          });
          return result;
        }
      },
      /**
       * 캐시 리턴.
       * initializeComponents, initializeButton, isEditable 등의 cache 파라메터에 쓰임.
       * @param {*} dewself dewself
       * @param {json} componentId VC.componentId 참조
       * @returns {json} 캐시 객체
       */
      getCache: function (dewself, componentId) {
        var componentInfo = this.getCommonComponentInfo(dewself, componentId);
        var commonInfo = this.getCommonInfo(dewself, componentId, {
          componentInfo: componentInfo
        });
        return {
          componentInfo: componentInfo,
          initializeInfo: componentInfo,
          referenceInfo: componentInfo,
          commonInfo: commonInfo
        };
      },
      getDefaultValue: function (dewself, componentId, cache, defaultId) {
        var VC = this;
        var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself,
          componentId);
        if (defaultId == 'from_ym' || defaultId == 'to_ym') {
          var vat_ym = componentInfo.vat_ym;
          var format = vat_ym.$.hasClass('dews-ui-periodpicker') ? 'yyyyMMdd' : 'yyyyMM';
          var today = new Date();
          var month = today.getMonth() + 1;
          var date = today.getDate();
          var from_ym = null;
          var to_ym = null;
          var day = 25;

          if (VC.nvl(from_ym, '').length <= 0) {
              if ((month >= 2 && month <= 3) || ( month == 1 && date > day) || (month == 4 && date <= day)) {
                from_ym = dews.date.format(new Date(today.getFullYear(), 0, 1), format);
              } else if ((month >= 5 && month <= 6) || (month == 4 && date > day) || (month == 7 && date <= day)) {
                from_ym = dews.date.format(new Date(today.getFullYear(), 3, 1), format);
              } else if ((month >= 8 && month <= 9) || (month == 7 && date > day) || (month == 10 && date <= day)) {
                from_ym = dews.date.format(new Date(today.getFullYear(), 6, 1), format);
              } else if ((month >= 11 || month <= 12) || (month == 10 && date > day) || (month == 1 && date <= day)) {
                from_ym = dews.date.format(new Date(today.getFullYear() - (month <= 1 ? 1 : 0), 9, 1), format);
              }
            }
            if (VC.nvl(to_ym, '').length <= 0) {
  			to_ym = dews.date.parse(from_ym,format);
  			to_ym.setMonth(to_ym.getMonth() + 3);
  			to_ym = dews.date.format(new Date(to_ym.getFullYear(), to_ym.getMonth(),0), format);
              //if (month == 1) {
              //  to_ym = dews.date.format(new Date(today.getFullYear() - 1, 12, 0), format);
              //} else {
              //  to_ym = dews.date.format(new Date(today.getFullYear(), today.getMonth()+1, 0), format);
              //}
            }
          return defaultId == 'from_ym' ? from_ym : to_ym;
        }
        return null;
      },
      /**
       * 부가세 관련 컴포넌트를 초기화합니다.
       * 1. fg_decl    - 신고방식 : 신고방식 내부데이터 채움. 신고방식 변경시 사업장, 신고구분 컴포넌트 초기화
       * 2. cd_bizarea - 사업장 : 신고방식에 따라 코드도움 설정 ( 사업장 / 주사업장 ), 기본값 지정. 변경시 신고구분 컴포넌트 초기화
       * 3. ym_vat     - 과세기간 : 기간에 따라 과세기간 지정. 변경시 신고구분 컴포넌트 초기화
       * 4. sq_modify  - 신고구분 : 신고구분 코드도움 설정. 신고방식, 사업장, 과세기간에 따른 신고구분 자동설정. helpParams 으로 cd_form 필요. (혹은 componentId 에 부여)
       * @example VC.initializeComponents(dewself, initializeId, referenceId);
       * @param {*} dewself dewself
       * @param {json} initializeId 초기화 대상 컴포넌트. VC.componentId 참조
       * @param {json} referenceId 참조 대상 컴포넌트. VC.componentId 참조
       * @param {json} cache VC.getCache 확인
       * @param {function} extraEventCallback 내부 change 이벤트에 추가적으로 호출될 이벤트 콜백
       * @param {boolean} allocateEvents 초기화시 이벤트 연결여부.
       */
      initializeComponents: function (dewself, initializeId, referenceId, cache, extraEventCallback, allocateEvents) {
        var VC = this;
        cache = $.extend(false, {
          initializeInfo: null,
          referenceInfo: null,
          commonInfo: null
        }, cache);
        allocateEvents = this.nvl(allocateEvents, true);
        var initializeInfo = this.isNotNull(cache.initializeInfo) ? cache.initializeInfo : this.getCommonComponentInfo(dewself,
          initializeId);
        var referenceInfo = this.isNotNull(cache.referenceInfo) ? cache.referenceInfo : this.getCommonComponentInfo(dewself,
          referenceId);
        var commonInfo = this.isNotNull(cache.commonInfo) ? cache.commonInfo : this.getCommonInfo(dewself, referenceId);
        var eventCache = $.extend(false, {}, cache);
        eventCache.commonInfo = null;
        function getInitialValue(propName, defaultValue) {
          var result = defaultValue;
          if (dewself.initialData) {
            if (VC.nvl(dewself.initialData[propName], '').length > 0) {
              result = dewself.initialData[propName];
              dewself.initialData[propName] = null;
            }
          }
          return result;
        }
        // 신고방식
        if (initializeId.hasOwnProperty('decl_fg') && initializeInfo.decl_fg.valid && VC.isNotNull(commonInfo)) {
          var decl_fg = initializeInfo.decl_fg;
          decl_fg.component.setDataSource(this.getFlagDataSource('FI', 'S40300'));
          decl_fg.value(getInitialValue('decl_fg', commonInfo.DECL_FG));
          if (allocateEvents)
            decl_fg.component.on('change', function (e) {
              VC.initializeComponents(dewself, {
                bizarea_cd: referenceInfo.bizarea_cd.id,
                mrtf_sq: referenceInfo.mrtf_sq.id
              }, referenceId, eventCache, null, false);
              if (typeof extraEventCallback === 'function') extraEventCallback('decl_fg');
            });
        }
        // 기간
        if (initializeId.hasOwnProperty('vat_ym') && initializeInfo.vat_ym.valid) {
          var vat_ym = initializeInfo.vat_ym;
          var from_ym = getInitialValue('from_ym', VC.getDefaultValue(dewself, initializeId, cache, 'from_ym'));
          var to_ym = getInitialValue('to_ym', VC.getDefaultValue(dewself, initializeId, cache, 'to_ym'));
          vat_ym.component.setStartDate(from_ym);
          vat_ym.component.setEndDate(to_ym);
          if (allocateEvents)
            vat_ym.component.on('change', function (e) {
              VC.initializeComponents(dewself, {
                mrtf_sq: referenceInfo.mrtf_sq.id
              }, referenceId, eventCache, null, false);
              if (typeof extraEventCallback === 'function') extraEventCallback('vat_ym');
            });
        }
        // 사업장
        if (initializeId.hasOwnProperty('bizarea_cd') && initializeInfo.bizarea_cd.valid) {
          var bizarea_cd = initializeInfo.bizarea_cd;
          if (referenceInfo.decl_fg.valid) {
            bizarea_cd.component.clearData();
            // I104500 인 경우 무조건 주사업장 도움창 사용
            var fg_decl_value = referenceInfo.decl_fg.component.value();
            if (referenceInfo.form_cd.value && referenceInfo.form_cd.value == 'I104500')
              fg_decl_value = '2';
            bizarea_cd.component.enable(true);
            switch (fg_decl_value) {
              case '1': // 사업장별
                bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                  helpCode: 'H_MA_BIZAREA_MST_S',
                  codeField: 'BIZAREA_CD',
                  textField: 'BIZAREA_NM'
                }));
                bizarea_cd.component.setHelpParams({});
                if ((dews.ui.page.user.bizAreaCode || '').length > 0) {
                  bizarea_cd.value({
                    code: getInitialValue('bizarea_cd', dews.ui.page.user.bizAreaCode),
                    text: getInitialValue('bizarea_nm', dews.ui.page.user.bizAreaName)
                  });
                }
                if (referenceInfo.btn_subBizArea.valid)
                  referenceInfo.btn_subBizArea.enabled(false);
                try {
                  gerp.MA.setControlByAuth.apply(dewself);
                } catch (error) {}
                break;
              case '2': // 사업자단위과세
                bizarea_cd.component.setOptions($.extend({}, bizarea_cd.component.getOptions(), {
                  helpCode: 'H_MA_MAINBIZAREA_MST_S',
                  codeField: 'MNBSN_CD',
                  textField: 'NM_MAINBIZAREA'
                }));
                bizarea_cd.component.setHelpParams({
                  module_cd: 'FI'
                });
                if ((commonInfo.MNBSN_CD || '').length > 0) {
                  bizarea_cd.value({
                    code: getInitialValue('bizarea_cd', commonInfo.MNBSN_CD),
                    text: getInitialValue('bizarea_nm', commonInfo.NM_MAINBIZAREA)
                  });
                }
                if (referenceInfo.btn_subBizArea.valid)
                  referenceInfo.btn_subBizArea.enabled(true);
                if (dewself.authority && dewself.authority.grant && $.inArray(dewself.authority.grant, ['S', 'C']) < 0) {
                  bizarea_cd.component.enable(false);
                }
                break;
            }
            if (allocateEvents)
              bizarea_cd.component.on('change', function (e) {
                VC.initializeComponents(dewself, {
                  mrtf_sq: referenceInfo.mrtf_sq.id
                }, referenceId, eventCache, null, false);
                if (typeof extraEventCallback === 'function') extraEventCallback('bizarea_cd');
              });
          }
        }
        // 신고구분
        if (initializeId.hasOwnProperty('mrtf_sq') && initializeInfo.mrtf_sq.valid) {
          var mrtf_sq = initializeInfo.mrtf_sq;
          var form_cd = initializeInfo.form_cd.value;
          if (form_cd == null) {
            console.error('component [' + mrtf_sq.id + '] error : data-dews-help-params=\"form_cd=\" 을 반드시 설정하십시오.');
          }
          // 코드 Help 세팅
          var options = $.extend(true, {}, mrtf_sq.component.getOptions());
          if (VC.nvl(options.helpCode, '') == '') options.helpCode = 'H_FI_VAT_EREPORT_MST_S';
          if (VC.nvl(options.helpCustom, false) == false) options.helpCustom = true;
          if (VC.nvl(options.helpViewUrl, '') == '') options.helpViewUrl = '~/codehelp/TX/H_FI_VAT_EREPORT_MST_C';
          if (VC.nvl(options.codeField, '') != 'MRTF_SQ') options.codeField = 'MRTF_SQ';
          if (VC.nvl(options.textField, '') != 'NM_SQ_MODIFY') options.textField = 'NM_SQ_MODIFY';
          if (VC.nvl(options.helpSize, '') != 'big') options.helpSize = 'big';
          mrtf_sq.component.setOptions(options);
          // HELP PARAM 세팅
          mrtf_sq.component.setHelpParams({
            form_cd: form_cd,
            decl_fg: referenceInfo.decl_fg.component.value(),
            bizarea_cd: referenceInfo.bizarea_cd.component.code(),
            from_ym: referenceInfo.vat_ym.component.getStartDate().substring(0, 6),
            to_ym: referenceInfo.vat_ym.component.getEndDate().substring(0, 6),
            /*yn_next_seq: VC.nvl(options.helpCode, '') == 'H_FI_VAT_EREPORT_MST_S01' ? true : false*/
            useNextSeq: VC.nvl(options.helpCode, '') == 'H_FI_VAT_EREPORT_MST_S01' ? true : false
          });
          // DB 에서 기초 차수를 읽어옴
          // commonInfo 재구성
          // cache.commonInfo = commonInfo = this.getCommonInfo(dewself, referenceId);
          mrtf_sq.value({
            code: getInitialValue('mrtf_sq', commonInfo.MRTF_SQ),
            text: getInitialValue('nm_sq_modify', commonInfo.NM_SQ_MODIFY)
          });
          if (allocateEvents && typeof extraEventCallback === 'function')
            mrtf_sq.component.on('change', function (e) {
              extraEventCallback('bizarea_cd');
            });
        }
      },
      /**
       * 불러오기, 일괄삭제, 출력일, 종사업장 버튼 초기화
       * 리턴된 객체는 다음과 같은 함수를 가지고 있습니다.
       * init(initFunction) : 버튼 클릭시 호출되며, 해당 함수에서 false 를 리턴하면 실행하지 않습니다.
       * setInitData(initJson) : 대화상자 내부로 주입될 데이터
       * setTitle(title) : 대화상자 명
       * yes(yesFunction) : 대화상자에서 yes 버튼을 클릭했을 경우 호출되며 대화상자에서 데이터가 처음 파라메터로 넘어옵니다.
       * done() : 설정을 모두 종료하고 초기화를 실행합니다.
       * @example VC.initializeButton(dewself, 'btn_load', componentId);
       * @param {*} dewself dewself
       * @param {String} componentType 초기화 대상 버튼 VC.componentId 참조
       * @param {json} componentId VC.componentId 참조
       * @param {json} cache VC.getCache 확인
       */
      initializeButton: function (dewself, componentType, componentId, cache) {
        var VC = this;
        cache = $.extend(false, {
          componentInfo: null
        }, cache);
        var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself,
          componentId, true);
        if (componentInfo.hasOwnProperty(componentType) == false) return;
        var component = componentInfo[componentType];
        return {
          _componentType: componentType,
          _component: component,
          _initializeData: {},
          _title: null,
          _initialize: null,
          _yesFunction: null,
          init: function (initialize) {
            this._initialize = initialize;
            return this;
          },
          setInitData: function (initializeData) {
            this._initializeData = initializeData;
            return this;
          },
          setTitle: function (title) {
            this._title = title;
            return this;
          },
          yes: function (yesFunction) {
            this._yesFunction = yesFunction;
            return this;
          },
          done: function () {
            var self = this;
            this._component.$.off('click').on('click', function (e) {
              VC.commitCells();
              if (self._component.enabled() == false) return;
              // init
              if (VC.isNotNull(self._initialize))
                if (self._initialize() == false) return;
              var initData = VC.isNotNull(self._initializeData) ? (typeof self._initializeData === 'function' ? self
                ._initializeData() :
                self._initializeData) : null;
              initData = $.extend(true, {}, initData);

              if(initData.form_cd =='I103200' && initData.from_ym.length == 6) {
            	  var to = dews.date.parse(initData.to_ym,'yyyyMM');
            	  initData.from_ym = initData.from_ym + '01';
            	  initData.to_ym = dews.date.format(new Date(to.getFullYear(), to.getMonth()+1, 0), 'yyyyMMdd');
              }

              var dialogTitle = VC.isNotNull(self._title) ? self._title : null;
              var yesFunction = VC.nvl(self._yesFunction, function () {
                return false;
              });
              switch (self._componentType) {
                case 'btn_load':
                	if(VC.ymVat[0]){
	                    var ymStart = VC.ymVat[0], ymEnd = VC.ymVat[1];
	                    var stMonth = ymStart.substr(4,6), endMonth = ymEnd.substr(4,6);
	                    if (!(ymStart == ymEnd || (ymStart.substr(0,4) == ymEnd.substr(0,4) && (stMonth == '01' && endMonth == '03' ||
	                                                                                            stMonth == '04' && endMonth == '06' ||
	                                                                                            stMonth == '07' && endMonth == '09' ||
	                                                                                            stMonth == '10' && endMonth == '12')))){
	                      dews.alert('월별 혹은 분기별 기간을 입력하십시오.');
	                      return;
	                    }
                  }
                  dews.ui.dialog('vatCommon_loadDialog', {
                    url: '/view/TX/VATVTM00100_COMMON_LOAD_POP',
                    title: (dialogTitle == null ? VC.titles.btn_load : dialogTitle),
                    width: '800',
                    height: dews.ui.page.menu.id == "VATVTM00800" ? '630' : '600',
                    initData: initData,
                    ok: function (data) {
                      if (yesFunction(data) != false) {
                        dews.ui.snackbar.info(VC.messages.btn_load.done);
                      }
                    }
                  }).open();
                  break;
                case 'btn_removeAll':
                  var length = componentInfo.vat_ym.value().from.length;
                  var format = length == 8 ? 'yyyy-MM-dd' : 'yyyy-MM';
                  var from = length == 8 ? componentInfo.vat_ym.value().from : componentInfo.vat_ym.value().from + '01';
                  var to = length == 8 ? componentInfo.vat_ym.value().to : componentInfo.vat_ym.value().to + '01';
                  dews.confirm(dews.string.format(VC.messages.btn_removeAll.ask,
                      componentInfo.decl_fg.component.text(),
                      componentInfo.bizarea_cd.value().text,
                      dews.date.format(dews.date.parse(from), format),
                      dews.date.format(dews.date.parse(to), format),
                      componentInfo.mrtf_sq.value().text), 'question')
                    .yes(function () {
                      new Promise(function (resolve) {
                        dews.ui.loading.show({
                          text: '일괄삭제중입니다.'
                        });
                        setTimeout(function () {
                          resolve();
                        }, 0);
                      }).then(function () {
                        var result = yesFunction({
                          decl_fg: componentInfo.decl_fg.value(),
                          bizarea_cd: componentInfo.bizarea_cd.value().code,
                          from_ym: componentInfo.vat_ym.value().from,
                          to_ym: componentInfo.vat_ym.value().to,
                          mrtf_sq: componentInfo.mrtf_sq.value().code
                        });
                        dews.ui.loading.hide();
                        if (result != false) {
                          dews.ui.snackbar.info(VC.messages.btn_removeAll.done);
                        }
                      });
                    });
                  break;
                case 'btn_printDate':
                  dews.ui.dialog('vatCommon_printDateDialog', {
                    url: '/view/TX/VATVTM00100_COMMON_PRINTDATE_POP',
                    title: (dialogTitle == null ? VC.titles.btn_printDate : dialogTitle),
                    width: 390,
                    height: 127,
                    initData: initData,
                    ok: function (data) {
                      yesFunction(data);
                    }
                  }).open();
                  break;
                case 'btn_subBizArea':
                  dews.ui.dialog('vatCommon_subBizAreaDialog', {
                    url: '/view/TX/VATVTM00100_COMMON_SUBBIZAREA_POP',
                    title: (dialogTitle == null ? VC.titles.btn_subBizArea : dialogTitle),
                    width: 560,
                    height: 474,
                    initData: initData,
                    ok: function (data) {
                      yesFunction(data);
                    }
                  }).open();
                  break;
                case 'btn_vacct':
                  dews.ui.dialog('vatCommon_vacctDialog', {
                    url: '/view/TX/VATVTM00100_COMMON_VACCT_POP',
                    title: (dialogTitle == null ? VC.titles.btn_vacct : dialogTitle),
                    size: 'medium',
                    initData: initData,
                    ok: function (data) {
                      yesFunction(data);
                    }
                  }).open();
                  break;
                  case 'btn_closeBizArea':
                    dews.ui.dialog('vatCommon_closeBizAreaDialog',{
                    url: '/view/TX/VATVTM00100_COMMON_CLOSEBIZAREA_POP',
                    title: (dialogTitle == null ? VC.titles.btn_closeBizArea : dialogTitle),
                    width : 830,
                    height : 550,
                    initData: initData
                  }).open();
                  break;
              }
            });
          }
        };
      },
      /**
       * 추가/수정/삭제 여부를 리턴합니다.
       * 1. 최근 문서 여부 : sq_modify ( 0. 정기, 1 ~ 수정 ) 가 최종적으로 작성된 것이 아닌경우 불가
       * 2. 서식 마감 여부 : 부가세 신고서상에서 해당 서식이 마감처리된 경우 불가 ( cd_form 참조 )
       * @param {*} dewself dewself
       * @param {boolean} showMessage 수정불가일때 메시지 발생여부
       * @param {json} componentId VC.componentId 확인
       * @param {*} cache VC.getCache 확인
       * @returns {boolean} 수정 가능 여부 true : 수정가능 / false : 수정불가
       */
      isEditable: function (dewself, showMessage, componentId, cache) {
        if(dews.ui.page.menu.id != "VATVTC00800" && dews.ui.page.menu.id != "VATVTS00800") {
          var VC = this;
          function _getComponent(componentType) {
            return componentId.hasOwnProperty(componentType) ? dewself[componentId[componentType]] : null;
          }
          showMessage = this.nvl(showMessage, true);
          cache = $.extend(false, {
            componentInfo: null,
            commonInfo: null
          }, cache);
          var commonInfo = this.isNotNull(cache.commonInfo) ? cache.commonInfo : this.getCommonInfo(dewself, componentId);
          var editable = true;
          if (VC.isNotNull(commonInfo)) {
            if (commonInfo.MAIN_CLOSE_YN == 'Y') {
              if (showMessage){
                if(commonInfo.MAIN_CLOSE_YN == 'Y' && commonInfo.CLOSE_YN == 'N'){
                  dews.alert('부가세 신고서가[마감]되어있습니다.\n마감 해제 후 입력, 수정, 삭제가 가능합니다.');
                }else if(commonInfo.MAIN_CLOSE_YN == 'Y' && commonInfo.CLOSE_YN == 'Y'){
                  dews.ui.snackbar.error(this.messages.edit.closed, 'warning');
                }
              }
              editable = false;
            } else if (commonInfo.RECENT_YN == 'N') {
              if (showMessage)
                dews.ui.snackbar.error(this.messages.edit.notRecent, 'warning');
              editable = false;
            }
            cache.commonInfo = commonInfo;
          }
          return editable;
        } else {
          return true;
        }
      },
      /**
       * fg_declterm - 신고기간구분 값을 리턴합니다.
       * 1. 1 ~ 3 월 : 년도 + '11'
       * 2. 4 ~ 6 월 : 년도 + '12'
       * 3. 7 ~ 9 월 : 년도 + '21'
       * 4. 10 ~ 12 월 : 년도 + '22'
       * @param {*} dewself dewself
       * @param {json} componentId VC.componentId 참조
       * @param {json} cache VC.getCache 확인
       * @returns {string} fg_declterm
       */
      declterm_fg: function (dewself, componentId, cache) {
        var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself,
          componentId, true);
        var to_ym = componentInfo.vat_ym.value().to;
        var end_dt = dews.date.parse(to_ym.substring(0, 6) + '01', 'yyyyMMdd');
        var month = end_dt.getMonth() + 1;
        if (month >= 1 && month <= 3) return end_dt.getFullYear() + '11';
        else if (month >= 4 && month <= 6) return end_dt.getFullYear() + '12';
        else if (month >= 7 && month <= 9) return end_dt.getFullYear() + '21';
        else if (month >= 10 && month <= 12) return end_dt.getFullYear() + '22';
        return '';
      },
      /**
       * 신고방식에 따른 사업장 목록을 리턴합니다.
       * 1. 신고방식 - 사업장별 : 사업장 코드 리턴 ( ex) 1000 )
       * 2. 신고방식 - 사업자단위과세 : 주사업장 코드의 종사업장 목록을 리턴 ( ex) 1000|2000 )
       * @param {*} dewself dewself
       * @param {json} componentId VC.componentId 참조
       * @param {json} cache VC.getCache 확인
       * @param {string} 사업장코드
       */
      subo_cd: function (dewself, componentId, cache, bizarea_cd) {
        var componentInfo = this.isNotNull(cache.componentInfo) ? cache.componentInfo : this.getCommonComponentInfo(dewself,
          componentId, true);
        var decl_fg = componentInfo.decl_fg.value();
        bizarea_cd = bizarea_cd || componentInfo.bizarea_cd.value().code;
        var subo_cd = bizarea_cd;
        if (decl_fg == '2') {

        	// 2020-07-22 wrote by ironman
        	// - 사업장단위 과세인 경우 조회조건에 사업장이 없음으로 bizarea_cd 가 undefined 상태임
        	// - 내부사용자라면 dewself.user.bizAreaCode 으로 대체 가능 하나 외부사용자는 이것 마저 undefined 일 것임
        	// - 외부사용자의 경우 임의의 종사업장번호 하나를 얻어 API 호출 시 오류 발생되지 않도록 처리
        	if(bizarea_cd == undefined && dewself.user.bizAreaCode != undefined) {
        		bizarea_cd = dewself.user.bizAreaCode;
        	}
        	else if(bizarea_cd == undefined && dewself.user.bizAreaCode == undefined) {
        		dews.api.get(dews.url.getApiUrl('TX', 'ValueAddedTaxManagementVTMService', 'vatvtm00100_common_temp_bizarea'), {
    				async: false,
    				data: {
    					'company_cd' : dewself.user.companyCode
    				}
    			}).done(function (data) {
    				if(data != null) {
    					bizarea_cd = data[0];
    				}
    			}).fail(function (xhr, status, error) {
    				console.error(error);
    			});
        	}
          dews.api.get(dews.url.getApiUrl('TX', 'ValueAddedTaxManagementVTMService', 'vatvtm00100_common_subbizarea_list'), {
              async: false,
              data: {
                'mnbsn_cd' : bizarea_cd
              }
            })
            .done(function (data) {
              subo_cd = data.map(function (d) {
                return d.BIZAREA_CD;
              }).join('|');
            })
            .fail(function (xhr, status, error) {
              console.error(error);
            });
        }
        return subo_cd;
      },
      cd_subBizArea: function (dewself, componentId, cache, bizarea_cd) {
        return this.subo_cd(dewself, componentId, cache, bizarea_cd);
      },
      /**
       * GUID 문자열을 리턴합니다. (우리가 익히 아는 GUID 는 아니고 그에 준하는 랜덤문자.)
       */
      guid: function () {
        return 'xxxxxxxx-xxxx-4xxx-9xxx-xxxxxxxxxxxx'.replace(/[xy]/g,
          function (c) {
            var r = Math.random() * 16 | 0,
              v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
          });
      },
      normalizeParameter: function (value, defaultValue) {
        if (typeof value === 'function') {
          value = value();
        }
        if (this.isNotNull(value) == false && this.isNotNull(defaultValue)) {
          value = defaultValue;
        }
        return value;
      },
      openDocu: function (pc_cd, docu_no, taxbil_no, doline_sq) {
        var package_fg = this.globalVariables.package_fg || '1';
        if (package_fg == '2') {
          dews.api.get(dews.url.getApiUrl('TX', 'TxCommonServices', 'docu_info_get'), {
            data: {
              pc_cd: pc_cd || '',
              docu_no: docu_no || '',
              taxbil_no: taxbil_no || ''
            }
          }).done(function (data) {
            if (data) {
              var docuParams = {
                COMPANY_CD: dews.ui.page.user.companyCode,
                PC_CD: data.PC_CD || '',
                DOCU_NO: data.DOCU_NO || '',
                WRT_DEPT_CD: data.WRT_DEPT_CD || '',
                WRT_EMP_NO: data.WRT_EMP_NO || ''
              };
              dews.ui.openMenu('FI', 'GLDDOC00500', docuParams);
            }
          }).fail(function (xhr, status, error) {
            console.error(error);
            dews.alert(error, 'error');
          });
        } else {
          if (docu_no.toLowerCase() == 'copy') {
            var docuParams = {
              taxbil_no: taxbil_no,
            };
            dews.ui.openMenu('TX', 'VATTIM00300', docuParams);
          } else {
            var docuParams = {
              pc_cd: pc_cd, //회계단위코드
              docu_no: docu_no, //전표번호
              doline_sq: doline_sq,
            };
            dews.ui.openMenu('FI', 'GLDDOC00700', docuParams);
          }
        }
      },
      connectInterface: function (subProtocol) {
        return new Promise(function (resolve, reject) {
          subProtocol = subProtocol || 'Service';
          var support = "MozWebSocket" in window ? 'MozWebSocket' : ("WebSocket" in window ? 'WebSocket' : null);
          if (support == null) {
            reject(ws, '현재 브라우저가 D-ERP Client Interface 를 지원하지 않습니다.');
          } else {
            var ws = new window[support]('wss://localhost:53159/', subProtocol);
            ws.onopen = function (e) {
              // Handshake 메시지를 기다린다.
              ws.onmessage = function (e) {
                var result = JSON.parse(e.data);
                if (result.Result == 'Success' && result.Message == 'Welcome')
                  resolve({
                    ws: ws
                  });
                else {
                  ws.onclose = function (e) {};
                  ws.close();
                  reject('D-ERP Client Interface 를 시작중 오류가 발생했습니다. ' + result.Message);
                }
              }
            };
            ws.onclose = function (e) {
              switch (e.code) {
                case 1006:
                  // 설치 페이지 오픈
                  setTimeout(function () {
                    dews.ui.dialog('errorDialog', {
                      title: '전자신고 프로그램 설치',
                      content:
                        '<div class="dews-ui-referbox" style="height: 45px; margin-top: 6px;">' +
                        '  <ul><li>전자신고 파일 작성 및 홈택스 연동서비스를 사용하기 위해서 전자신고 프로그램을 설치하셔야 합니다.<br>다운로드센터로 이동 하시겠습니까?</li>' + '</ul>' +
                        '</div>',
                        // '<div class="dews-dialog-button-group">' +
                        // '  <button class="dews-ui-button" onclick="window.open(&quot;http://asp.duzonerp.co.kr/link/act_message/HDUPDATE/autohometax.zip&quot;)">' +
                        // '파일 다운로드' + '</button>' +
                        // '</div>',
                      buttons: 'applyAndClose',
                      ok:function(data){
                        dews.app.openDownloadCenter()
                      },
                      width: 360,
                      height: 150
                    }).open();
                    var dialogText = setInterval(function () {
                      if(""!=$($("#errorDialog .dews-button-group .dews-ui-button")[0]).text()){
                        $($("#errorDialog .dews-button-group .dews-ui-button")[0]).text("이동")
                        $($("#errorDialog .dews-button-group .dews-ui-button")[0]).on('click',function(e){
                          dews.ui.dialog('errorDialog').ok();
                        })
                        clearInterval(dialogText)
                      }
                    }, 100);
                  }, 0);
                  //reject('D-ERP Client Interface 가 설치되지 않았습니다.');
                  reject();
                  break;
                default:
                  reject(e.reason);
                  break;
              }
            }
          }
        });
      },
      sendInterface: function (ws, serviceName, data) {
        return new Promise(function (resolve, reject) {
          ws = ws && ws.hasOwnProperty('ws') ? ws.ws : ws;
          if (!ws || ws == null) {
            reject(ws, 'PROGMA ERROR : connectInterface first.');
            return;
          }
          ws.onmessage = function (e) {
            var result = JSON.parse(e.data);
            if (result.Result == 'Success') {
              resolve({
                ws: ws,
                data: result
              });
            } else {
              reject({
                ws: ws,
                reason: result
              });
            }
          };
          ws.onclose = function (e) {
            // reject({
            //   ws: ws,
            //   reason: e.reason
            // });
          }
          ws.send(JSON.stringify({
            ServiceName: serviceName,
            Data: data
          }));
        });
      },
      closeInterface: function (ws) {
        ws = ws && ws.hasOwnProperty('ws') ? ws.ws : ws;
        return new Promise(function (resolve, reject) {
          if (!ws || ws == null) {
            reject(ws, 'PROGMA ERROR : connectInterface first.');
            return;
          }
          ws.onerror = function (e) {
            reject(ws, e);
          };
          ws.onclose = function (e) {
            resolve(ws, e.CloseEvent);
          };
          ws.close();
        });
      },
      jsonToXml: function (json) {
        var self = this;
        var isObject = function (val) {
          return val !== null && ((typeof val === 'function') || (typeof val === 'object'));
        }
        function _getNode(json, node, doc) {
          for (var key in json) {
            if (json.hasOwnProperty(key)) {
              var val = self.normalizeParameter(json[key]);
              var el = doc.createElement(key);
              var _isObject = isObject(val);
              if (_isObject === false) {
                $(el).text(val);
              }
              node.appendChild(el);
              if (_isObject === true) {
                _getNode(val, el, doc);
              }
            }
          }
        }
        var doc = $.parseXML('<xml/>');
        var xml = doc.getElementsByTagName('xml')[0];
        _getNode(json, xml, doc);
        var htmlString = xml.outerHTML;
        if (typeof htmlString === 'undefined' && XMLSerializer) {
          htmlString = new XMLSerializer().serializeToString(xml);
        }
        return htmlString;
      },
      xmlToJson: function (xmlString) {
        var _toJson = function ($xml) {
          var value = null;
          if ($xml.children().length > 0) {
            value = {};
            $xml.children().each(function (idx, child) {
              var $child = $(child);
              var childName = $child[0].tagName;
              var jsonChild = _toJson($child);
              if (value.hasOwnProperty(childName)) {
                if (Array.isArray(value[childName]) == false) {
                  value[childName] = [value[childName]];
                }
                value[childName].push(jsonChild[childName]);
              } else value[childName] = jsonChild[childName];
            });
          } else {
            value = $xml.text();
          }
          var json = {};
          json[$xml[0].tagName] = value;
          return json;
        };
        var xml = $.parseXML(xmlString);
        var $root = $(xml).children().first();
        var json = _toJson($root);
        return json[$root[0].tagName];
      },
      insertDocu: function (options) {
        var grid = options.grid,
          rows = options.rows,
          verifier = options.verifier,
          preworkPromise = options.preworkPromise,
          previewApi = options.previewApi,
          insertApi = options.insertApi,
          menuId = options.menuId,
          ok = options.ok,
          package_fg = this.globalVariables.package_fg || '1';
        if (typeof grid === 'undefined' || grid == null ||
          typeof rows === 'undefined' || rows == null ||
          typeof previewApi === 'undefined' || previewApi == null ||
          typeof insertApi === 'undefined' || insertApi == null) {
          throw 'arguments are not filled';
        }
        if (rows && rows.length > 0) {
          (new Promise(function (resolve, reject) {
            var notAllowedRows = verifier && typeof verifier == 'function' ? rows.filter(function (data) {
              return verifier.call(grid, data) == false;
            }) : [];
            if (notAllowedRows && notAllowedRows.length > 0) {
              dews.confirm('전표처리가 불가능한 항목이 있습니다.' + '\n' + '가능한 항목만 선택하시겠습니까?', 'question')
                .yes(function () {
                  var notAllowedIndex = grid.getCheckedIndex().filter(function (idx) {
                    return verifier.call(grid, grid.dataItem(idx)) == false;
                  });
                  if (notAllowedIndex) {
                    grid.setCheck(notAllowedIndex, false);
                  };
                  rows = grid.getCheckedRows();
                  if (!(rows && rows.length > 0)) {
                    setTimeout(function () {
                      dews.alert('전표처리 할 항목을 체크해 주십시오.')
                        .done(function () {
                          grid.setFocus();
                        });
                    }, 300);
                    reject();
                  } else {
                    resolve();
                  }
                })
                .no(reject);
            } else resolve();
          })).then(function () {
              return preworkPromise && preworkPromise != null ? preworkPromise() : new Promise(function (resolve, reject) {
                resolve();
              });
            })
            .then(function () {
              setTimeout(function () {
                dews.ui.loading.show({
                  text: '전표처리 항목을 구성중입니다.'
                });
              }, 0);
              dews.api.post(previewApi.url, {
                data: previewApi.data(rows)
              }).done(function (previewData) {
                setTimeout(function () {
                  dews.ui.loading.hide();
                }, 0);
                if (previewData.length > 0) {
                  var previewData = JSON.parse(previewData);
                  previewData = previewData[Object.keys(previewData)[0]];
                  dews.ui.dialog("GLDDOC00500_PREVIEW", {
                    url: "/view/FI/GLDDOC00500_PREVIEW",
                    title: dews.localize.get("전표처리정보", 'D0004061'),
                    width: 720,
                    height: 586,
                    initData: {
                      menuId: menuId,
                      docuData: JSON.stringify(previewData),
                      strDocuments: JSON.stringify(previewData),
                      mainTitle: dews.localize.get("부가세 전표처리", 'D0004348')
                    },
                    ok: function (insertData) {
                      if (insertData && insertData.length > 0) {
                        (new Promise(function (resolve, reject) {
                          setTimeout(function () {
                            dews.ui.loading.show({
                              text: '전표처리를 진행하고 있습니다.'
                            });
                            setTimeout(function () {
                              resolve();
                            }, 100); // 간혹 로딩표시가 표시 안되는 게 있어서 100ms 이후 resolve 처리
                          }, 200); // 대화상자 오픈시 200ms 이후에 로딩표시 하도록
                        })).then(function () {
                          dews.api.post(insertApi.url, {
                              data: insertApi.data(rows, insertData)
                            })
                            .done(function () {
                              dews.ui.loading.hide();
                              setTimeout(function () {
                                if (package_fg == '2') {
                                  dews.alert('전표처리가 완료되었습니다.', 'info');
                                } else {
                                  dews.ui.snackbar.ok('전표처리가 완료되었습니다.');
                                }
                                if (typeof ok === 'function') ok(rows, insertData);
                              }, 0);
                            })
                            .fail(function (xhr, status, error) {
                              dews.ui.loading.hide();
                              console.error(error);
                              setTimeout(function () {
                                dews.alert(error, { align: 'left', icon: 'error' });
                                //dews.ui.snackbar.error(dews.localize.get("전표처리가 실패했습니다.", 'M0001641'));
                              }, 0);
                            });
                        });
                      }
                    }
                  }).open();
                }
              }).fail(function (xhr, status, error) {
                console.error(error);
                setTimeout(function () {
                  dews.ui.loading.hide();
                  setTimeout(function () {
                    dews.alert(error, { align: 'left', icon: 'error' });
                  }, 300);
                }, 0);
              })
            })
            .catch(function () {
            });
        } else {
          dews.alert('전표처리 할 항목을 체크해 주십시오.')
            .done(function () {
              grid.setFocus();
            });
        }
      },
      insertWebSocketDocu: function (options) {
        var grid = options.grid,
          rows = options.rows,
          verifier = options.verifier,
          preworkPromise = options.preworkPromise,
          previewApi = options.previewApi,
          insertApi = options.insertApi,
          menuId = options.menuId,
          ok = options.ok,
          package_fg = this.globalVariables.package_fg || '1';
        if (typeof grid === 'undefined' || grid == null ||
          typeof rows === 'undefined' || rows == null ||
          typeof previewApi === 'undefined' || previewApi == null ||
          typeof insertApi === 'undefined' || insertApi == null) {
          throw 'arguments are not filled';
        }
        if (rows && rows.length > 0) {
          (new Promise(function (resolve, reject) {
            var notAllowedRows = verifier && typeof verifier == 'function' ? rows.filter(function (data) {
              return verifier.call(grid, data) == false;
            }) : [];
            if (notAllowedRows && notAllowedRows.length > 0) {
              dews.confirm('전표처리가 불가능한 항목이 있습니다.' + '\n' + '가능한 항목만 선택하시겠습니까?', 'question')
                .yes(function () {
                  var notAllowedIndex = grid.getCheckedIndex().filter(function (idx) {
                    return verifier.call(grid, grid.dataItem(idx)) == false;
                  });
                  if (notAllowedIndex) {
                    grid.setCheck(notAllowedIndex, false);
                  };
                  rows = grid.getCheckedRows();
                  if (!(rows && rows.length > 0)) {
                    setTimeout(function () {
                      dews.alert('전표처리 할 항목을 체크해 주십시오.')
                        .done(function () {
                          grid.setFocus();
                        });
                    }, 300);
                    reject();
                  } else {
                    resolve();
                  }
                })
                .no(reject);
            } else resolve();
          })).then(function () {
              return preworkPromise && preworkPromise != null ? preworkPromise() : new Promise(function (resolve, reject) {
                resolve();
              });
            })
            .then(function () {
              setTimeout(function () {
                dews.ui.loading.show({
                  type: 'tiny',
                  text: '전표처리 항목을 구성중입니다.'
                });
              }, 0);
              var previewXhr = new XMLHttpRequest();
              var previewBlob = new Blob([JSON.stringify(rows)], { type: "text/plain;charset=utf-8" });
              var previewFormData = new FormData();
              previewFormData.append('file', previewBlob);
              previewFormData.append('isText', 'false');
              previewFormData.append('token', JSON.parse(dews.ui.page.token).access_token);
              previewXhr.open('POST', "/upload/file", true);
              var previewComp = function (e) {
                setTimeout(function () {
                  dews.ui.loading.hide();
                }, 0);
                var previewProgress = dews.ui.progress("previewProgress" + previewApi.pageId, {
                  total: rows.length,
                  modal: true,
                  position: {
                    align: 'right|bottom',
                    margin: [0, 0, 0, 0]
                  },
                  titlebar: {
                      text: previewApi.title
                  },
                  textTemplate: '데이터를' + ' <strong>#=percent#</strong> ' + '처리 중 입니다.',
                  alterTextTemplate: '진행 상황: #=progress#'
                });
                var previewLtx = dews.ws.ltx(previewApi.url, {
                  data: previewApi.data(JSON.parse(e.target.response).data.newFilename),
                  done: function (e) {
                    previewProgress.setCurrent(rows.length);
                    var previewData = JSON.parse(e.resultData).docuData;
                    if (previewData.length > 0) {
                      dews.ui.dialog("GLDDOC00500_PREVIEW", {
                        url: "/view/FI/GLDDOC00500_PREVIEW",
                        title: dews.localize.get("전표처리정보", 'D0004061'),
                        width: 720,
                        height: 586,
                        initData: {
                          menuId: menuId,
                          docuData: JSON.stringify(previewData),
                          strDocuments: JSON.stringify(previewData),
                          mainTitle: dews.localize.get("부가세 전표처리", 'D0004348')
                        },
                        ok: function (insertData) {
                          if (insertData && insertData.length > 0) {
                            dews.ui.loading.show({
                              type: 'tiny',
                              text: '전표처리를 진행하고 있습니다.'
                            });
                            var insertXhr = new XMLHttpRequest();
                            var data = {
                              rows: rows,
                              insertData: JSON.parse(insertData)
                            }
                            var insertBlob = new Blob([JSON.stringify(data)], { type: "text/plain;charset=utf-8" });
                            var insertFormData = new FormData();
                            insertFormData.append('file', insertBlob);
                            insertFormData.append('isText', 'false');
                            insertFormData.append('token', JSON.parse(dews.ui.page.token).access_token);
                            insertXhr.open('POST', "/upload/file", true);
                            var insertComp = function (e) {
                              dews.ui.loading.hide();
                              var insertProgress = dews.ui.progress("insertProgress" + insertApi.pageId, {
                                total: rows.length,
                                modal: true,
                                position: {
                                  align: 'right|bottom',
                                  margin: [0, 0, 0, 0]
                                },
                                titlebar: {
                                    text: insertApi.title
                                },
                                textTemplate: '데이터를' + ' <strong>#=percent#</strong> ' + '처리 중 입니다.',
                                alterTextTemplate: '진행 상황: #=progress#'
                              });
                              var insertLtx = dews.ws.ltx(insertApi.url, {
                                data: insertApi.data(JSON.parse(e.target.response).data.newFilename),
                                done: function (e) {
                                  insertProgress.setCurrent(rows.length);
                                  dews.ui.loading.hide();
                                  setTimeout(function () {
                                    if (package_fg == '2') {
                                      dews.alert('전표처리가 완료되었습니다.', 'info');
                                    } else {
                                      dews.ui.snackbar.ok('전표처리가 완료되었습니다.');
                                    }
                                    if (typeof ok === 'function') ok(rows, insertData);
                                  }, 0);
                                },
                                error: function (e) {
                                  var data = JSON.parse(e.resultData);
                                  dews.ui.progress("insertProgress" + insertApi.pageId).close();
                                  dews.error(data.message);
                                },
                                progress: function (e) {
                                  var data = JSON.parse(e.resultData);
                                  insertProgress.setTextTemplate(data.message);
                                  insertProgress.setCurrent(data.progressCount);
                                }
                              });
                              insertLtx.on('disconnect', function () {
                                dews.ui.progress("insertProgress" + insertApi.pageId).close();
                              });
                              insertLtx.start();
                            };
                            insertXhr.addEventListener('load', insertComp);
                            insertXhr.send(insertFormData);
                          }
                        }
                      }).open();
                    }
                  },
                  error: function (e) {
                    var data = JSON.parse(e.resultData);
                    dews.ui.progress("previewProgress" + previewApi.pageId).close();
                    dews.error(data.message);
                  },
                  progress: function (e) {
                    var data = JSON.parse(e.resultData);
                    previewProgress.setTextTemplate(data.message);
                    previewProgress.setCurrent(data.progressCount);
                  }
                });
                previewLtx.on('disconnect', function () {
                  dews.ui.progress("previewProgress" + previewApi.pageId).close();
                });
                previewLtx.start();
              };
              previewXhr.addEventListener('load', previewComp);
              previewXhr.send(previewFormData);
            })
          .catch(function () {
          });
        } else {
          dews.alert('전표처리 할 항목을 체크해 주십시오.')
            .done(function () {
              grid.setFocus();
            });
        }
      },
      deleteDocu: function (options) {
        var VC = this;
        var grid = options.grid,
          rows = options.rows,
          verifier = options.verifier,
          deleteApi = options.deleteApi,
          ok = options.ok,
          waitTimeout = 0,
          askMessage = options.askMessage || '',
          package_fg = this.globalVariables.package_fg || '1';
        if (rows && rows.length > 0) {
          (new Promise(function (resolve, reject) {
            var notAllowedRows = verifier && typeof verifier == 'function' ? rows.filter(function (data) {
              return verifier.call(grid, data) == false;
            }) : [];
            if (notAllowedRows && notAllowedRows.length > 0) {
              setTimeout(function () {
                waitTimeout = 300;
                dews.confirm('전표취소가 불가능한 항목이 있습니다.' + '\n' + '가능한 항목만 선택하시겠습니까?', 'question')
                  .yes(function () {
                    var notAllowedIndex = grid.getCheckedIndex().filter(function (idx) {
                      return verifier.call(grid, grid.dataItem(idx)) == false;
                    });
                    if (notAllowedIndex) {
                      grid.setCheck(notAllowedIndex, false);
                    };
                    rows = grid.getCheckedRows();
                    if (!(rows && rows.length > 0)) {
                      setTimeout(function () {
                        dews.alert('전표취소 할 항목을 체크해 주십시오.')
                          .done(function () {
                            grid.setFocus();
                          });
                      }, 300);
                      reject();
                    } else {
                      resolve();
                    }
                  })
                  .no(reject);
              }, 0);
            } else resolve();
          })).then(function () {
              return new Promise(function (resolve, reject) {
                setTimeout(function () {
                  dews.confirm(
                      dews.string.format(askMessage && askMessage.length > 0 ? askMessage : ('선택한 {0}개 항목을 전표취소 하시겠습니까?' +
                        '\n' + '※ 전표가 승인된 항목은 취소되지 않습니다.'), rows.length), {
                        align: 'left',
                        icon: 'question'
                      })
                    .yes(function () {
                      resolve();
                    })
                    .no(function () {
                      reject();
                    });
                }, waitTimeout);
              });
            })
            .catch(function () {
              throw null;
            })
            .then(function () {
              setTimeout(function () {
                dews.ui.loading.show({
                  text: '전표처리 항목을 구성중입니다.'
                });
              }, 0);
              dews.api.post(deleteApi.url, {
                data: deleteApi.data(rows)
              }).done(function (result) {
                dews.ui.loading.hide();
                var message = '전표취소가 완료되었습니다.';
                if (result && (result.total || result.success)) {
                  message = dews.string.format('총 {0}건의 전표 중 {1}건 전표취소가 완료되었습니다.',
                    VC.number(result.total), VC.number(result.success));
                }
                setTimeout(function () {
                  if (typeof ok === 'function') ok(rows);
                  if (package_fg == '2') {
                    setTimeout(function () {
                      dews.alert(message, 'info');
                    }, 150);
                  } else {
                    dews.ui.snackbar.info(message);
                  }
                }, 0);
              }).fail(function (xhr, status, error) {
                setTimeout(function () {
                  dews.ui.loading.hide();
                  dews.alert(error, 'error');
                }, 0);
                console.log(error);
              })
            })
            .catch(function () {});
        } else {
          dews.alert('전표취소 할 항목을 체크해 주십시오.')
            .done(function () {
              grid.setFocus();
            });
        }
      },
      sendOrOpenGroupwareDocument: function (options) {
        var self = this;
        var menuCode = (options || {}).menuCode || dews.ui.page.menu.id;
        var menuParams = JSON.stringify((options || {}).menuParams || {});
        var formId = (options || {}).formId || '';
        var mode = (options || {}).mode || '';
        var callback = (options || {}).callback;
        if (menuCode.length <= 0 || formId.length <= 0) {
          console.error('sendOrOpenGroupwareDocument : parameter not filled', menuCode, menuParams, formId);
          dews.alert('전자결재 상신/조회 중 오류가 발생했습니다.', 'error');
        }
        dews.api.post(dews.url.getApiUrl('TX', 'TxCommonServices', 'groupware_request_get'), {
          data: {
            menuCode: menuCode,
            menuParams: menuParams,
            formId: formId,
            mode: mode
          }
        }).done(function (data) {
          if (data) {
            dews.ajax.script('~/view/js/hdg.cm.util.js', {
                once: true
              })
              .done(function () {
                var api = gerp.CM.EltrAthzUtil;
                api.createEltrAthz(data.serverUrl, data, true);
              });
            if (typeof callback == 'function') {
              callback({
                docNo: data.approKey,
                menuCode: menuCode,
                menuParams: menuParams,
                formId: formId
              });
            }
          } else {
            console.error('sendOrOpenGroupwareDocument : no senddata retrieved.');
            dews.alert('전자결재 상신/조회 중 오류가 발생했습니다.', 'error');
          }
        }).fail(function (xhr, status, error) {
          console.error(error);
          dews.alert(error, 'error');
        });
      },
      getInfo: function (info_cd, params) {
        var result = '';
        dews.api.get(dews.url.getApiUrl('TX', 'TxCommonServices', 'info_get'), {
          dataType: 'text',
          async: false,
          data: {
            info_cd: info_cd || '',
            param_json_string: JSON.stringify(params || {}) || ''
          }
        }).done(function (resultString) {
          result = resultString;
        }).fail(function (xhr, status, error) {
          console.error(error);
          dews.alert(error, 'error');
        });
        return result;
      },
      getMaskingFormat: function (formatCode, masking, formatCharactor) {
        try {
          formatCode = formatCode.toUpperCase();
          var mask = '';
          masking = typeof masking === 'undefined' ? true : masking;
          if (!dews.ui.page || !dews.ui.page.env || !dews.ui.page.env.mask) {
            masking = false;
          }
          switch (formatCode) {
            case 'RES_NO':
              mask = '000000-0000000';
              if (masking) {
                mask = dews.string.secureMask(mask, 'RES_NO', true);
              }
              mask = mask.length >= 13 ? mask.substring(0, 6) + '-' + mask.substring(mask.length - 7) : mask;
              break;
            case 'BIZR_NO':
              mask = '000-00-00000';
              break;
          }
          if (formatCharactor && formatCharactor.length > 0) {
            mask = mask.replace(/0/g, formatCharactor);
          }
          return mask;
        } catch (error) {
          console.error(error);
          return '';
        }
      },
      getMaskingFormats: function (formatCode, formatCharactor) {
        try {
          var VC = this;
          return {
            type: 'function',
            format: function (value, e) {
              if (value && value.length > 0) {
                return dews.string.mask(value, VC.getMaskingFormat(formatCode, e.row.index != e.grid.select(), formatCharactor));
              }
            }
          }
        } catch (error) {
          console.error(error);
          return {};
        }
      },
      setPersonalLog: function (tableName, personalInfoFieldNames, keyFieldNamesPipe, keyData, crudType) {
        try {
          dews.api.post(dews.url.getApiUrl('TX', 'TxCommonServices', 'personal_log_insert'), {
            data: {
              data: JSON.stringify($.extend(false, {}, keyData, {
                crudType: crudType,
                menuCode: dews.ui.page.menu.id,
                tableName: tableName,
                personalInfoFieldNames: personalInfoFieldNames,
                keyFieldNamesPipe: keyFieldNamesPipe
              }))
            }
          }).fail(function (xhr, status, error) {
            // log no exception
            //dews.error(error);
            console.error(error);
          });
        } catch (error) {
          console.error(error);
        }
      },
      /**
       * 그리드 지원 클래스
       * @param {string} id 아이디
       * @param {string} type 그리드 타입 ( VC.gridTypes.grid / VC.gridTypes.cardlist )
       */
      GridComponent: function (id, type) {
        var VC = this;
        return {
          ////////////////////////////////// 속성 영역
          /**
           * 대표 ID = Grid.id 부여
           */
          id: id,
          /**
           * Grid 타입 : VC.gridtype 참조
           */
          type: type,
          /**
           * Grid 객체
           */
          grid: null,
          /**
           * DataSource 객체
           */
          dataSource: null,
          /**
           * CommonFunction 에서 수행되는 기능 제어. false 를 주면 해당 버튼에 참여안함.
           */
          allowFunctions: {
            add: true,
            delete: true,
            save: true,
            customValidation: false
          },
          /**
           * Read 서비스.
           */
          service: {
            read: {
              url: null,
              data: null
            }
          },
          /**
           * 그리드 저장시 Verifier 처리할 함수
           * function (data, showMessage, index, datas, gridComponent)
           */
          verifier: null,
          ////////////////////////////////// 메서드 영역
          /**
           * 데이터소스가 변경되었는지 (getDirtyDataCount) 여부를 리턴한다.
           * @returns {boolean} 데이터소스 변경여부
           */
          isDirty: function () {
            if (VC.isNotNull(this.dataSource))
              return this.dataSource.getDirtyDataCount() > 0;
            return false;
          },
          /**
           * 유효성 체크 함수를 사용해서 데이터 소스에서 유효성 실패한 RowIndex Array 를 리턴한다.
           * @param {boolean} showMessage 메시지를 발생여부. 주어진 유효성 체크 함수로 전달된다.
           * @param {boolean} stopIfNotVerified 유효성 실패 이후, 계속 유효성 체크를 할건지 여부.
           * @param {function} verifier 유효성 체크 함수. 기본적으로 GridComponent.verifier 사용. function (data, showMessage, index, datas, gridComponent)
           * @returns {Array<number>} 유효성 검사에 실패한 Row Index Array
           */
          verify: function (showMessage, stopIfNotVerified, verifier) {
            showMessage = VC.nvl(showMessage, true);
            stopIfNotVerified = VC.nvl(stopIfNotVerified, true);
            verifier = VC.nvl(verifier, this.verifier);
            var notVerifiedRows = [];
            var continueVerify = true;
            if (VC.isNotNull(verifier)) {
              var dirtyDataSet = this.dataSource.getDirtyData();
              for (var prop in dirtyDataSet) {
                if (prop === 'Deleted') continue;
                var datas = dirtyDataSet[prop];
                for (var index = 0; index < datas.length && continueVerify; index++) {
                  if (verifier(datas[index], showMessage, index, datas, this) == false) {
                    notVerifiedRows.push(index);
                    if (stopIfNotVerified) continueVerify = false;
                  }
                }
                if (continueVerify == false) break;
              }
            }
            return notVerifiedRows;
          },
          /**
           * 그리드와 데이터 소스의 값을 초기화 합니다.
           */
          clear: function () {
            if (VC.isNotNull(this.grid) && VC.isNotNull(this.dataSource)) {
              this.dataSource.data([]);
              if (this.dataSource.options.detail == true) {
                this.dataSource.options.lineDataSources = {};
                this.grid.setDataSource(this.dataSource);
              }
              if (this.grid.refresh) this.grid.refresh();
            }
          }
        };
      },
      /**
       * 페이지 클래스
       * 페이지 내에 데이터를 보유한 상태로 제공되는 다양한 기능을 제공한다.
       * @example
       * var page = VC.Page();
       */
      Page: function () {
        var VC = this;
        return {
          // 각종 dataSet
          dataSet: {
            dewself: null,
            componentId: null,
            flag: {},
            cache: {},
            printDate: null,
            primaryKey: {
              decl_fg: '',
              bizarea_cd: '',
              bizarea_nm: '',
              from_ym: '',
              to_ym: '',
              mrtf_sq: 0,
              nm_sq_modify: ''
            },
            extraPrimaryKey: {},
            format_vr: {
              exrt_rt: '#,###.##',
              fmny_amt: '#,###.##'
            },
            package_fg: '1',
            package_yn: 'Y'
          },
          // 페이지내 그리드 지원
          grids: [],
          service: {
            save: {
              url: null
            }
          },
          dirty: false,
          ignoreDirty: false,
          /**
           * CommonCodeDtlService 서비스 사용.
           * @example
           * var dataSource = page.getFlagDataSource('MA', 'P00350');
           * @param {string} cd_module 모듈코드
           * @param {string} cd_field_pipe 코드디테일 코드(PIPE 사용)
           * @param {string} yn_sycode 시스템코드 유무(Y,N)
           * @param {string} yn_default 디폴트 코드구분(Y,N)
           * @param {string} yn_foreign 외국언어적용 유무(Y,N)
           * @param {string} dt_end 종료일
           * @param {string} nm_keyword 검색할 코드 또는 명
           * @param {boolean} reload 캐싱사용여부
           * @returns {*} 조회된 dataSource
           */
          getFlagDataSource: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword, reload) {
            return VC.getFlagDataSource.apply(VC, arguments);
          },
          /**
           * CommonCodeDtlService 서비스를 사용해서 DropDownList 의 값을 채워줌
           * 이를 사용하기 위해 html 상에서 element 에 다음 항목이 지정되어 있어야 한다.
           * ※ dews 공용속성이 아님.
           * 필수
           * data-dews-cd-module: 모듈 코드, CI_CODEDTL.CD_MODULE
           * data-dews-cd-field: 코드디테일 코드(PIPE 사용), CI_CODEDTL.CD_FIELD
           *
           * 옵션
           * data-dews-yn-sycode: 시스템코드 유무(Y,N)
           * data-dews-yn-default: 디폴트 코드구분(Y,N)
           * data-dews-yn-foreign: 외국언어적용 유무(Y,N)
           * data-dews-dt-end: 종료일
           * data-dews-nm-keyword: 검색할 코드 또는 명
           * @example
           * # html
           * <select id="tp_bizarea" class="dews-ui-dropdownlist"
           *  data-dews-cd-module="MA"
           *  data-dews-cd-field="P00350"
           *  data-dews-value-field="CD_SYSDEF"
           *  data-dews-text-field="NM_SYSDEF" />
           * # script
           * page.setDropdownlistDataSource(dewself.tp_bizarea, '1');
           * @param {*} component DEWS ui 컴포넌트
           * @param {boolean} reload 캐싱사용여부
           * @returns {*} 조회된 dataSource
           */
          setDropdownlistDataSource: function (component, defaultSelectionValue, reload) {
            reload = VC.nvl(reload, false);
            if (component == null) {
              console.error('setFlag() Error : component is null.');
              return;
            }
            var element = (function () {
              if (component.hasOwnProperty('$element')) return component.$element.get(0);
              if (component.hasOwnProperty('_element')) return component._element;
              if (component.hasOwnProperty('element')) {
                if (component.element.hasOwnProperty('context')) return component.element.context;
                return component.element;
              }
              return null;
            })();
            if (element == null) {
              console.error('setFlag(' + component.id + ') Error : element context is null.');
              return;
            }
            var module_cd = element.dataset.hasOwnProperty('dewsCdModule') ? element.dataset.dewsCdModule :
              element.dataset.hasOwnProperty('dewsModuleCd') ? element.dataset.dewsModuleCd : '';
            var field_cd = element.dataset.hasOwnProperty('dewsCdField') ? element.dataset.dewsCdField :
              element.dataset.hasOwnProperty('dewsFieldCd') ? element.dataset.dewsFieldCd : '';
            if (module_cd == null || module_cd.length < 0 ||
              field_cd == null || field_cd < 0) {
              console.error('setFlag(' + id + ') Error : no attribute. data-dews-module-cd, data-dews-field-cd');
              return;
            }
            var yn_sycode = element.dataset.hasOwnProperty('dewsYnSycode') ? element.dataset.dewsYnSycode : '';
            var base_yn = element.dataset.hasOwnProperty('dewsYnDefault') ? element.dataset.dewsYnDefault : '';
            var yn_foreign = element.dataset.hasOwnProperty('dewsYnForeign') ? element.dataset.dewsYnForeign : '';
            var end_dt = element.dataset.hasOwnProperty('dewsDtEnd') ? element.dataset.dewsDtEnd : '';
            var nm_keyword = element.dataset.hasOwnProperty('dewsNmKeyword') ? elementContext.dataset.dewsNmKeyword : '';
            var dataSource = this.getFlagDataSource(module_cd, field_cd + '|', yn_sycode, base_yn, yn_foreign, end_dt,
              nm_keyword, reload);
            component.setDataSource(dataSource);
            if (defaultSelectionValue != undefined && defaultSelectionValue != null && defaultSelectionValue.length > 0) {
              component.select(function (item) {
                return item.SYSDEF_CD == defaultSelectionValue;
              });
            }
            return dataSource;
          },
          /**
           * 초기화를 시작합니다.
           * 이후 반드시 endInitialize() 를 호출해야 합니다.
           * @param {*} dewself dewself
           * @param {json} componentId VC.componentId 참조
           */
          beginInitialize: function (dewself, componentId) {
            this.dataSet.dewself = dewself;
            this.dataSet.componentId = this.getComponentId(VC.nvl(componentId, {}));
            this.dataSet.cache = VC.getCache(dewself, this.dataSet.componentId);
            var commonInfo = VC.isNotNull(this.dataSet.cache.commonInfo) ? this.dataSet.cache.commonInfo : VC.getCommonInfo(
              dewself, this.dataSet.componentId);
            this.dataSet.format_vr.exrt_rt = (commonInfo || {}).VR_FORMAT_RT_EXCH;
            this.dataSet.format_vr.fmny_amt = (commonInfo || {}).VR_FORMAT_AM_EX;
            this.dataSet.package_fg = ((commonInfo || {}).PACKAGE_FG) || '1';
            this.dataSet.package_yn = ((commonInfo || {}).PACKAGE_YN) || 'Y';
            VC.globalVariables.package_fg = this.dataSet.package_fg;
            VC.globalVariables.user = dewself.user;
            VC.globalVariables.menu = dewself.menu;
            this.initializeCodePicker();
            if ((VC.globalVariables.package_fg || '') == '2') {
              dews.ui.page.mainButtons.delete.useDefaultConfirm = false;
            }
          },
          /**
           * 초기화 작업을 종료합니다.
           */
          endInitialize: function () {
            this.dataSet.cache = {};
          },
          /**
           * 기본 componentId 를 바탕으로 컴포넌트 id 목록을 리턴합니다.
           * @param {json} componentId 컴포넌트 id 목록 null 가능
           * @returns {json} 컴포넌트 목록
           */
          getComponentId: function (componentId) {
            return $.extend(true, {}, VC.componentId, componentId);
          },
          /**
           * 부가세 관련 컴포넌트를 초기화합니다.
           * VC.initializeComponents 참고
           * @example page.initializeComponents(dewself);
           * @param {*} dewself dewself
           * @param {json} componentId VATCommonClass.componentId 확인
           */
          initializeComponents: function () {
            var self = this;
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            // dewself, initializeId, referenceId, cache, allocateEvents, extraEventCallback
            VC.initializeComponents(dewself, componentId, componentId, this.dataSet.cache, function (componentType) {
              if (componentType == 'mrtf_sq') {
                self.dataSet.printDate = null;
              }
            });
          },
          /**
           * 부가세 관련 버튼을 초기화합니다.
           * VC.initializeButton 참고
           * @param {string} componentType 버튼 타입 ( btn_load / btn_removeAll / btn_printDate / btn_subBizArea / btn_vacct )
           * @param {function} yesFunction 불러오기 버튼에서 항목 체크후 '예' 를 클릭했을 때 호출되는 콜백함수
           * @param {Array<string>} options 불러오기 버튼일때 허용가능한 옵션 목록
           * @param {Array<json>} helpMessages 불러오기 버튼일때 표기되는 옵션별 메시지
           */
          initializeButton: function (componentType, yesFunction, options, helpMessages, extraOptions) {
            var self = this;
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            var componentInfo = VC.isNotNull(this.dataSet.cache.componentInfo) ? this.dataSet.cache.componentInfo :
              VC.getCommonComponentInfo(dewself, componentId);
            var initButton = null;
            switch (componentType) {
              case 'btn_load':
                var multi_yn = VC.getInfo('ctrlconfig', {
                  module_cd: 'TX',
                  ctrl_cd: 'TX01070'
                });
                if (multi_yn == 'Y' && (extraOptions || {}).multi_yn == 'Y') {
                  multi_yn = 'Y';
                } else {
                  multi_yn = 'N';
                }
                extraOptions = $.extend(true, {}, extraOptions, {
                  multi_yn: multi_yn
                });
                var getAvailableOptions = function () {
                  var info = VC.getCommonComponentInfo(dewself, componentId);
                  var editable = VC.isEditable(dewself, true, componentId);
                  var availableOptions = $.extend(true, [], VC.isNotNull(options) ? options : ['1', '2', '5']);
                  availableOptions = availableOptions.filter(function (option) {
                    switch (option) {
                      case '1':
                        if (extraOptions.multi_yn == 'Y') return true;
                        if (editable == false) return false;
                        break;
                      case '2':
                        // 신고구분이 정기인 경우 이전차수 불러오기 없음
                        if (editable == false) return false;
                        if (info.mrtf_sq.value().code == '0') return false;
                        break;
                      case '5':
                        // 신고방식이 사업장별인 경우 사업장별 데이터 불러오기 없음
                        if (editable == false) return false;
                        if (info.decl_fg.value() == '1') return false;
                      case '8':
                        // 현대백화점 허브인 경우, 현대백화점이 아니라면 불러오기 없음
                        if (editable == false) return false;
                        if (self.dataSet.package_fg != '2') return false;
                      default:
                        if (editable == false) return false;
                        break;
                    }
                    return true;
                  });
                  return availableOptions;
                };
                VC.initializeButton(dewself, componentType, componentId, this.dataSet.cache)
                  .init(function () {
                    var availableOptions = getAvailableOptions();
                    if (availableOptions.length <= 0) {
                      dews.alert(VC.messages.btn_load.no_options, 'info');
                      return false;
                    }
                    return true;
                  })
                  .setInitData(function () {
                    var info = VC.getCommonComponentInfo(dewself, componentId);
                    var availableOptions = getAvailableOptions();
                    return {
                      options: availableOptions,
                      helpMessages: VC.isNotNull(helpMessages) ? helpMessages : [],
                      decl_fg: info.decl_fg.value(),
                      bizarea_cd: info.bizarea_cd.value().code,
                      from_ym: info.vat_ym.value().from,
                      to_ym: info.vat_ym.value().to,
                      mrtf_sq: info.mrtf_sq.value().code,
                      form_cd: info.form_cd.value,
                      extraOptions: extraOptions
                    };
                  })
                  .yes((function () {
                    if (((extraOptions || {}).progress || true) == true) {
                      return function (data) {
                        new Promise(function (resolve) {
                          if (typeof (extraOptions || {}).preProgressPromise == 'function') {
                            extraOptions.preProgressPromise(data)
                              .then(function (preProgressData) {
                                resolve(preProgressData);
                              })
                          } else {
                            resolve({});
                          }
                        }).then(function (preProgressData) {
                          if (data.multi_yn == 'Y') {
                            var progress = dews.ui.progress('loadProgress', {
                              titlebar: {
                                text: '자료를 불러오고 있습니다.'
                              },
                              textTemplate: '',
                              alterTextTemplate: '진행 상황 : #=progress#',
                              total: data.checkedRows.length,
                              modal: true
                            });
                            setTimeout(function () {
                              data.checkedRows.reduce(function (p, checkedRow, i) {
                                return p.then(function () {
                                  return new Promise(function (resolve, reject) {
                                    progress.setCurrent(i);
                                    progress.setTextTemplate(dews.string.format('[{0}] {1}', checkedRow
                                      .BIZAREA_CD, checkedRow.BIZAREA_NM));
                                    progress.setAlterTextTemplate('진행 상황 : #=progress#');
                                    setTimeout(function () {
                                      var eachData = {
                                        option: data.option,
                                        multi_yn: data.multi_yn,
                                        checkedRows: [checkedRow],
                                        preProgressData: preProgressData || {},
                                        isLast: (i + 1 == data.checkedRows.length)
                                      };
                                      if (yesFunction) {
                                        var funcResult = yesFunction(eachData);
                                        (function () {
                                          if (typeof funcResult == 'object' && funcResult.then) {
                                            return funcResult;
                                          } else {
                                            return new Promise(function (resultResolve) {
                                              resultResolve(funcResult);
                                            });
                                          }
                                        })().then(function (result) {
                                          progress.setCurrent(i + 1);
                                          if (result != false) {
                                            if (i + 1 == data.checkedRows.length) {
                                              setTimeout(function () {
                                                progress.close();
                                                if (result != false) {
                                                  dews.ui.snackbar.info(VC.messages.btn_load
                                                    .done);
                                                }
                                              })
                                            }
                                            resolve();
                                          } else {
                                            reject();
                                          }
                                        })
                                      } else {
                                        progress.setCurrent(i + 1);
                                        resolve();
                                      }
                                    }, 0);
                                  });
                                });
                              }, Promise.resolve()).catch(function () {
                                progress.close();
                              });
                            }, 0);
                          } else {
                            (new Promise(function (resolve, reject) {
                              setTimeout(function () {
                                dews.ui.loading.show({
                                  text: '자료를 불러오고 있습니다.'
                                });
                                setTimeout(function () {
                                  resolve();
                                }, 100);
                              }, 200);
                            })).then(function () {
                              return new Promise(function (resolve, reject) {
                                if (yesFunction) {
                                  var funcResult = yesFunction($.extend(false, data, {
                                    multi_yn: 'N',
                                    isLast: true,
                                    preProgressData: preProgressData || {},
                                  }));
                                  (function () {
                                    if (typeof funcResult == 'object' && funcResult.then) {
                                      return funcResult;
                                    } else {
                                      return new Promise(function (resultResolve) {
                                        resultResolve(funcResult);
                                      });
                                    }
                                  })().then(function (result) {
                                    resolve(result);
                                  })
                                } else {
                                  resolve();
                                }
                              });
                            }).then(function (result) {
                              dews.ui.loading.hide();
                              if (result != false) {
                                dews.ui.snackbar.info(VC.messages.btn_load.done);
                              }
                            });
                          }
                        });
                        return false;
                      }
                    } else return yesFunction;
                  })())
                  .done();
                break;
              case 'btn_removeAll':
                VC.initializeButton(dewself, componentType, componentId, this.dataSet.cache)
                  .init(function () {
                    return VC.isEditable(dewself, true, componentId);
                  })
                  .yes(yesFunction)
                  .done();
                break;
              case 'btn_printDate':
                VC.initializeButton(dewself, componentType, componentId, this.dataSet.cache)
                  .setInitData(function () {
                    return {
                      printDate: self.printDate()
                    };
                  })
                  .yes(function (data) {
                    self.printDate(data.printDate);
                    if (VC.isNotNull(yesFunction))
                      yesFunction(data.printDate);
                  })
                  .done();
                break;
              case 'btn_subBizArea':
                var bizarea_cd = componentInfo.bizarea_cd;
                VC.initializeButton(dewself, componentType, componentId, this.dataSet.cache)
                  .init(function () {
                    if (bizarea_cd == null || VC.nvl(bizarea_cd.value().code, '') == '') {
                      dews.alert(VC.messages.btn_subBizArea.no_code, 'info');
                      if (bizarea_cd != null && bizarea_cd.valid) bizarea_cd.$.focus();
                      return false;
                    }
                    return true;
                  })
                  .setInitData(function () {
                    return {
                      mnbsn_cd: (bizarea_cd != null ? bizarea_cd.value().code : '')
                    };
                  })
                  .done();
                break;
              case 'btn_vacct':
                var menu_cd = VC.nvl($.extend(false, {}, options).menu_cd, (dewself.menu || {}).id);
                var acctattr_cd = (options || {}).acctattr_cd || '';
                var referText = (options || {}).referText || '';
                VC.initializeButton(dewself, componentType, componentId, this.dataSet.cache)
                  .init(function () {
                    return true;
                  })
                  .setInitData(function () {
                    return {
                      menu_cd: menu_cd,
                      page: self,
                      acctattr_cd: acctattr_cd,
                      referText: referText
                    };
                  })
                  .done();
                break;
              case 'btn_openDocu':
                // 이건 page.focusedGrid 를 써야 해서 VC.initializeButton 를 못쓴다.
                componentInfo[componentType].$.off('click').on('click', function (e) {
                  try {
                    options = options || {};
                    var focusedGridComponent = self.getTargetGridComponent(options);
                    if (focusedGridComponent && focusedGridComponent != null) {
                      var focusedGrid = focusedGridComponent.grid;
                      if (focusedGrid && focusedGrid != null) {
                        if (focusedGrid.select() >= 0 && focusedGrid.dataItems().length > 0) {
                          var dataItem = focusedGrid.dataItem(focusedGrid.select());
                          var col_CD_PC = VC.nvl(options.pc_cd, 'PC_CD');
                          var col_NO_DOCU = VC.nvl(options.docu_no, 'DOCU_NO');
                          var col_SQ_DOLINE = VC.nvl(options.doline_sq, 'DOLINE_SQ');
						  var col_TAXBIL_NO = VC.nvl(options.taxbil_no, 'TAXBIL_NO');
                          if (dataItem.hasOwnProperty(col_CD_PC) &&
                            dataItem.hasOwnProperty(col_NO_DOCU)) {
                            if (VC.isNotNull(dataItem[col_CD_PC]) && dataItem[col_CD_PC].length > 0 &&
                              VC.isNotNull(dataItem[col_NO_DOCU]) && dataItem[col_NO_DOCU].length > 0) {
                              VC.openDocu(dataItem[col_CD_PC], dataItem[col_NO_DOCU], dataItem[col_TAXBIL_NO],dataItem[col_SQ_DOLINE]);
                              return;
                            } else {
                              dews.ui.snackbar.info(VC.messages.btn_openDocu.not_docuData);
                              return;
                            }
                          }
                        }
                      }
                    }
                    dews.ui.snackbar.info(VC.messages.btn_openDocu.not_available);
                  } catch (e) {
                    dews.alert(e);
                  } finally {
                    $(e.target).blur();
                  }
                });
                break;
              case 'btn_viewDocu':
                // 이건 page.focusedGrid 를 써야 해서 VC.initializeButton 를 못쓴다.
                componentInfo[componentType].$.off('click').on('click', function (e) {
                  var viewSuccess = false;
                  try {
                    options = options || {};
                    var focusedGridComponent = self.getTargetGridComponent(options);
                    if (focusedGridComponent && focusedGridComponent != null) {
                      var focusedGrid = focusedGridComponent.grid;
                      if (focusedGrid && focusedGrid != null) {
                        if (focusedGrid.select() >= 0 && focusedGrid.dataItems().length > 0) {
                          var dataItem = focusedGrid.dataItem(focusedGrid.select());
                          var data = null;
                          if (typeof options.getData === 'function') {
                            data = options.getData({
                              field: {
                                name: focusedGrid.getCurrentColumn()
                              },
                              row: {
                                index: focusedGrid.select(),
                                data: dataItem
                              },
                              grid: focusedGrid,
                              id: focusedGridComponent.id
                            });
                          }
                          if (VC.isNotNull(data)) {
                            if (typeof yesFunction === 'function') {
                              if (yesFunction(data.data) == false) {
                                return;
                              }
                            }
                            viewSuccess = true;
                            dews.ui.dialog('vatCommon_loadDialog', {
                              url: '/view/TX/VATVTM00100_COMMON_VIEWDOCU_POP',
                              title: VC.titles.btn_viewDocu + (VC.nvl(data.title, '').length > 0 ? '(' + data.title +
                                ')' :
                                ''),
                              width: 1000,
                              height: 440,
                              initData: {
                                service: {
                                  url: data.url || options.url,
                                  data: data.data
                                },
                                visiableColumns: data.visiableColumns || []
                              },
                              ok: function (docuInfo) {
                                VC.openDocu(docuInfo.pc_cd, docuInfo.docu_no, docuInfo.taxbil_no,docuInfo.doline_sq);
                              }
                            }).open();
                          }
                        }
                      }
                    }
                    if (viewSuccess == false) {
                      dews.ui.snackbar.info(VC.messages.btn_viewDocu.not_available);
                    }
                  } catch (e) {
                    dews.alert(e);
                  } finally {
                    $(e.target).blur();
                  }
                });
                break;
                case 'btn_closeBizArea':
                  VC.initializeButton(dewself, componentType, componentId, this.dataSet.cache)
                  .setInitData(function () {
                    var info = VC.getCommonComponentInfo(dewself, componentId);
                    return {
                      decl_fg: info.decl_fg.value(),
                      bizarea_cd: info.bizarea_cd.value().code,
                      from_ym: info.vat_ym.value().from,
                      to_ym: info.vat_ym.value().to,
                      mrtf_sq: info.mrtf_sq.value().code,
                      form_cd: info.form_cd.value
                    };
                  })
                  // .yes(function (data) {
                  //   // self.printDate(data.printDate);
                  //   if (VC.isNotNull(yesFunction))
                  //     yesFunction(data.printDate);
                  // })
                  .done();
                break;
            }
          },
          /**
           * 추가/수정/삭제 여부를 리턴합니다.
           * 1. 최근 문서 여부 : sq_modify ( 0. 정기, 1 ~ 수정 ) 가 최종적으로 작성된 것이 아닌경우 불가
           * 2. 서식 마감 여부 : 부가세 신고서상에서 해당 서식이 마감처리된 경우 불가 ( cd_form 참조 )
           * ※ 캐싱기능
           *  - 페이지의 공용 컴포넌트 값을 저장하여 재조회시 이 데이터가 달라졌다면 폐기 후 확인.
           * @param {boolean} reload 캐싱된 추가/수정/삭제 여부를 재조회 여부
           * @param {boolean} showMessage 수정불가일때 메시지 발생여부
           * @returns {boolean} 수정 가능 여부 true : 수정가능 / false : 수정불가
           */
          isEditable: function (reload, showMessage) {
            if(dews.ui.page.menu.id != "VATVTC00800" && dews.ui.page.menu.id != "VATVTS00800") {
              var dewself = this.dataSet.dewself;
              var componentId = this.dataSet.componentId;
              if (VC.nvl(reload, false) || this.dataSet.cache.hasOwnProperty('commonInfo') == false) {
                this.dataSet.cache = VC.getCache(dewself, componentId);
              }
              var editable = VC.isEditable(dewself, showMessage, componentId, this.dataSet.cache);
              var showEditable = '';
              if (this.dataSet.cache.commonInfo) {
                var commonInfo = this.dataSet.cache.commonInfo;
                if (editable == false) {
                  if (commonInfo.CLOSE_YN == 'Y') {
                    showEditable = 'closed';
                  } else if (commonInfo.RECENT_YN == 'N') {
                    showEditable = 'recent';
                  }
                  if(commonInfo.MAIN_CLOSE_YN == 'Y' && commonInfo.CLOSE_YN == 'Y'){

                    if (dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').hasClass(showEditable) ==
                    false) {
                      dewself.$content.find('.dews-button-group').children('#tx_vat_editableLabel').remove();
                      var html =
                      '<span id="tx_vat_editableLabel" class="@class" style="display: inline-block; background: @bgColor; color: white; text-align: center; line-height: 27px; height: 27px; width: @widthpx;">@text</span>';
                      dewself.$content.find('.dews-button-group').prepend(
                        $(html.replace('@class', showEditable)
                        .replace('@bgColor', showEditable == 'closed' ? '#F44336' : '#FF9800')
                        .replace('@width', showEditable == 'closed' ? '50' : '100')
                        .replace('@text', showEditable == 'closed' ? '마감' : '다음차수존재'))
                        );
                      }
                    } else {
                      dewself.$content.find(".dews-button-group").children('#tx_vat_editableLabel').remove();
                    }
                } else {
                  dewself.$content.find(".dews-button-group").children('#tx_vat_editableLabel').remove();
                }
              }
              return editable;
            } else {
              return true;
            }
          },
          /**
           * Page 내에 주어진 GridComponent 아이디가 유효한지 여부
           * @param {string} id 아이디
           * @returns {boolean} 유효여부
           */
          isValidId: function (id) {
            var gridComponent = this.grids.find(function (element) {
              return element.id == id;
            });
            if (gridComponent == undefined || gridComponent == null) return false;
            return true;
          },
          /**
           * 그리드 컴포넌트를 지정하거나 객체를 얻는다.
           * @example
           * function initializeGrid01() {
           *   var gridComponent = page.gridComponent('grid01', VC.gridTypes.grid);
           *   gridComponent.services.read = {
           *     url: dews.url.getApiUrl('MODULE', 'MIDDLE MODULE', 'SERVICE NAME'),
           *     data: function () { return {}; }
           *   };
           *   gridComponent.dataSource = dews.ui.dataSource(gridComponent.id, { ... });
           *   gridComponent.grid = dews.ui.grid('#' + gridComponent.id, {
           *     dataSource: gridComponent.dataSource,
           *     ...
           *   });
           * };
           * @param {string} id 그리드 id
           * @param {string} type 그리드 타입 ( VC.gridTypes.grid / VC.gridTypes.cardlist )
           * @returns {GridComponent} 그리드 컴포넌트 객체
           */
          gridComponent: function (id, type) {
            if (this.isValidId(id) == false) {
              this.grids.push(VC.GridComponent(id, type));
            }
            return this.grids.find(function (element) {
              return element.id == id;
            });
          },
          /**
           * Page 에 등록된 그리드 객체를 얻는다.
           * @param {string} id 그리드 id
           * @returns {dews.ui.grid} 그리드 객체
           */
          grid: function (id) {
            if (this.isValidId(id)) return this.gridComponent(id).grid;
            return undefined;
          },
          /**
           * Page 에 등록된 데이터 소스 객체를 얻는다.
           * @param {string} id 그리드 id
           * @returns {dews.ui.dataSource} 데이터 소스 객체
           */
          dataSource: function (id) {
            if (this.isValidId(id)) return this.gridComponent(id).dataSource;
            return undefined;
          },
          /**
           * 현재 포커스가 주어진 그리드 컴포넌트 객체를 얻는다.
           * @returns {GridComponent} 그리드 컴포넌트 객체
           */
          getFocusedGridComponent: function () {
            return this.grids.find(function (gridComponent) {
              return (VC.isNotNull(gridComponent.grid) &&
                gridComponent.grid.focused);
            });
          },
          /**
           * 현재 포커스가 주어진 그리드 객체를 얻는다.
           * @returns {dews.ui.grid} 그리드 객체
           */
          getFocusedGrid: function () {
            var gridComponent = this.getFocusedGridComponent();
            if (gridComponent != null && gridComponent != undefined) return gridComponent.grid;
            return null;
          },
          getTargetGridComponent: function (options) {
            options = $.extend(false, {
              fixed: undefined,
              target: undefined
            }, options);
            var fixed = VC.nvl(options.fixed, '');
            var target = VC.nvl(options.target, '');
            var gridComponent = null;
            if (fixed != '') {
              gridComponent = this.gridComponent(fixed);
              if (target != '' && gridComponent.allowFunctions.hasOwnProperty(target) && gridComponent.allowFunctions[target] ===
                false) {
                gridComponent = null;
              }
            } else {
              var targetGrids = target != '' ?
                this.grids.filter(function (gridComponent) {
                  return !(gridComponent.allowFunctions.hasOwnProperty(target) && gridComponent.allowFunctions[target] ===
                    false);
                }) : this.grids;
              if (targetGrids.length == 1)
                gridComponent = targetGrids[0];
              else gridComponent = targetGrids.find(function (gridComponent) {
                return (VC.isNotNull(gridComponent.grid) && gridComponent.grid.focused);
              });
            }
            return gridComponent;
          },
          /**
           * 페이지 내 DataSource 중 변경된 것이 있는지 리턴한다.
           * @returns {boolean} DataSource 변경여부
           */
          isDirty: function (options) {
            if (this.ignoreDirty) return false;
            if (this.dirty === true) return true;
            var dirtyGridComponents = this.getDirtyGridComponent(options);
            if (VC.isNotNull(dirtyGridComponents) && dirtyGridComponents.length > 0) return true;
            return false;
          },
          /**
           * 페이지 내 DataSource 변경이 발생한 GridComponent 를 리턴한다.
           * @returns {Array<GridComponent>} 변경된 GridComponent Array
           */
          getDirtyGridComponent: function (options) {
            if (this.ignoreDirty) return [];
            options = $.extend(false, {
              fixed: undefined
            }, options);
            var fixed = VC.nvl(options.fixed, '');
            var containsNoDirty = VC.nvl(options.containsNoDirty, false);
            var grids =
              fixed != '' ? [this.gridComponent(fixed)] :
              this.grids.filter(function (gridComponent) {
                return !(gridComponent.allowFunctions.hasOwnProperty('save') && gridComponent.allowFunctions.save === false);
              });
            return containsNoDirty === true ? grids :
              grids
              .filter(function (gridComponent, index, grids) {
                return gridComponent.isDirty();
              });
          },
          /**
           * 페이지 내 DataSource 중 변경된 DataSource Array 를 리턴한다.
           * @returns {Array<dews.ui.datasource>} 변경된 DataSource Array
           */
          getDirtyDataSource: function (options) {
            return this.getDirtyGridComponent(options)
              .map(function (gridComponent, index, grids) {
                return gridComponent.dataSource;
              });
          },
          /**
           * 페이지 내 모든 GridComponent 에 대해 유효성 체크를 실행한다.
           * @param {boolean} showMessage 메시지를 발생여부. 주어진 유효성 체크 함수로 전달된다.
           * @param {boolean} stopIfNotVerified 유효성 실패 이후, 계속 유효성 체크를 할건지 여부.
           * @param {function} verifier 유효성 체크 함수. function (data, showMessage, index, datas, gridComponent)
           * @returns {Array<?>} 유효성 검사 실패한 목록 { {GridComponent} gridComponent, {Array<int>} rows } Array
           */
          verify: function (options) {
            var showMessage = VC.nvl(options.showMessage, true);
            var stopIfNotVerified = VC.nvl(options.stopIfNotVerified, true);
            var verifier = options.stopIfNotVerified;
            var verified = [];
            var gridComponents = this.getDirtyGridComponent(options);
            for (var index = 0; index < gridComponents.length; index++) {
              var gridComponent = gridComponents[index];
              var notVerifiedRows = gridComponent.verify(showMessage, stopIfNotVerified, verifier);
              if (notVerifiedRows.length > 0) {
                verified.push({
                  gridComponent: gridComponent,
                  rows: notVerifiedRows
                });
              }
              if (stopIfNotVerified == true && notVerifiedRows.length > 0) break;
            }
            return verified;
          },
          /**
           * 페이지내 수정된 데이터 소스를 저장한다.
           * GridComponent.service.save.url 이 반드시 지정되어 있어야 동작한다.
           * @param {boolean} showMessage 성공/실패시 메시지 발생 여부
           * @returns {boolean} 저장 성공 여부
           */
          getSaveData: function (options) {
            if (VC.nvl(this.service.save.url, '') == '') return false;
            options = $.extend(false, {
              showMessage: true
            }, options);
            var models = VC.nvl(options.models, []);
            var apiData = {};
            var saveGrids = this.grids.filter(function (gridComponent) {
              return !(gridComponent.allowFunctions.hasOwnProperty('save') && gridComponent.allowFunctions.save === false);
            });
            if (saveGrids.length > 0) {
              var rows = null;
              options = $.extend(true, options, {
                containsNoDirty: true
              });
              this.getDirtyDataSource(options).map(function (dataSource) {
                var result = {};
                result[dataSource.id] = $.extend(true, {
                  'Added': [],
                  'Updated': [],
                  'Deleted': []
                }, dataSource.getDirtyData());
                return result;
              }).forEach(function (data) {
                rows = $.extend(false, {}, rows, data);
              });
              apiData = $.extend(true, apiData, {
                rows: JSON.stringify(rows)
              });
            }
            if (models.length > 0) {
              var extraData = null;
              models.map(function (model, index) {
                var result = {};
                var name = 'data' + dews.number.format(index + 1, '00');
                result[name] = JSON.stringify(typeof model === 'function' ? model() : model);
                return result;
              }).forEach(function (data) {
                extraData = $.extend(false, {}, extraData, data);
              });
              apiData = $.extend(true, apiData, extraData);
            }
            return apiData;
          },
          savePromise: function (options) {
            var self = this;
            options = $.extend(false, {
              showMessage: true
            }, options);
            var showMessage = VC.nvl(options.showMessage, true);
            var apiData = this.getSaveData(options);
            return new Promise(function (resolve) {
              dews.api.post(self.service.save.url, {
                  data: apiData
                })
                .done(function () {
                  if (showMessage) dews.ui.snackbar.ok(VC.messages.save.done);
                  resolve(true);
                })
                .fail(function (xhr, status, error) {
                  setTimeout(function () {
                    if ((VC.globalVariables.package_fg || '') == '2') {
                      dews.error(error);
                    } else {
                      dews.error(VC.messages.save.error + '\n' + error);
                    }
                  }, 150);
                  resolve(false);
                });
            });
          },
          save: function (options) {
            options = $.extend(false, {
              showMessage: true
            }, options);
            var result = true;
            var showMessage = VC.nvl(options.showMessage, true);
            var apiData = this.getSaveData(options);
            dews.api.post(this.service.save.url, {
                async: false,
                data: apiData
              })
              .done(function () {
                if (showMessage) dews.ui.snackbar.ok(VC.messages.save.done);
              })
              .fail(function (xhr, status, error) {
                setTimeout(function () {
                  if ((VC.globalVariables.package_fg || '') == '2') {
                    dews.error(error);
                  } else {
                    dews.error(VC.messages.save.error + '\n' + error);
                  }
                }, 0);
                result = false;
              });
            return result;
          },
          clear: function () {
            for (var idx = 0; idx < this.grids.length; idx++) {
              this.grids[idx].clear();
            }
            this.dirty = false;
          },
          /**
           * 범용적으로 로직이 구성된 기능버튼 함수 모음
           * onClosing : 페이지를 닫을 경우 그리드에 저장되지 않은 항목이 있을 경우 메시지 처리.
           * @example dewself.closing.on(page.commonFunctions(dewself).onClosing);
           * add: '추가' 버튼 클릭시 현재 포커스가 지정된 그리드에 Row 추가.
           * @example dews.ui.mainbuttons.add.on('click', page.commonFunctions(dewself).add);
           * delete: '삭제' 버튼 클릭시 현재 포커스가 지정된 그리드에서 삭제를 수행한다. (grid: 체크된 항목 삭제, cardlist: 선택된 항목 삭제)
           * @example dews.ui.mainbuttons.delete.on('click', page.commonFunctions(dewself).delete);
           * search: '조회' 버튼 클릭시 그리드에 저장되지 않은 항목이 있을 경우 메시지 처리.
           * @example dews.ui.mainbuttons.search.on('click', page.commonFunctions(dewself).search(onSearchData));
           * save: '저장' 버튼 클릭시 저장기능 수행
           * @example dews.ui.mainbuttons.save.on('click', page.commonFunctions(dewself).save);
           */
          commonFunctions: function (fixedGridId) {
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            var page = this;
            var package_fg = VC.globalVariables.package_fg || '';
            return {
              onClosing: function (before, after) {
                return function (e) {
                  VC.commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'onClosing'
                  };
                  if (typeof before === 'function' && before(e) == false) return;
                  if (page.isDirty(options)) {
                    return dews.confirm(VC.messages.closing.not_saved, 'ico2')
                      .yes(function () {
                        if (typeof after === 'function') after(e);
                      })
                      .no(function () {
                        e.preventDefault();
                      }).promise();
                  }
                };
              },
              add: function (before, after) {
                return function (e) {
                  VC.commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'add'
                  };
                  e.preventDefault();
                  var gridComponent = page.getTargetGridComponent(options);
                  if (gridComponent != null && VC.isNotNull(gridComponent.grid)) {
                    var grid = gridComponent.grid;
                    var editable = page.isEditable(false, false);
                    var gridEditable = gridComponent.type == VC.gridTypes.grid ? (typeof grid.options.editable ==
                      'undefined' ?
                      true : grid.options.editable) : true;
                    if (page.isEditable() && gridEditable) {
                      if (typeof before === 'function' && before(gridComponent.id, editable, gridComponent) == false)
                        return;
                      grid.addRow();
                      grid.setFocus();
                      if (typeof after === 'function') after(gridComponent.id, editable, gridComponent);
                    }
                  }
                };
              },
              delete: function (before, after) {
                return function (e) {
                  VC.commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'delete'
                  };
                  e.preventDefault();
                  var gridComponent = page.getTargetGridComponent(options);
                  if (gridComponent != null && VC.isNotNull(gridComponent.grid)) {
                    var grid = gridComponent.grid;
                    var checkedIndexes = [];
                    var gridEditable = gridComponent.type == VC.gridTypes.grid ? (typeof grid.options.editable ==
                      'undefined' ?
                      true : grid.options.editable) : true;
                    switch (gridComponent.type) {
                      case VC.gridTypes.cardlist:
                        checkedIndexes.push(grid.select());
                        break;
                      case VC.gridTypes.grid:
                        if (grid.options.checkable == false) {
                          if (grid.dataItems().length > 0)
                            checkedIndexes.push(grid.select());
                        } else checkedIndexes = grid.getCheckedIndex();
                        break;
                    }
                    if (checkedIndexes.length > 0) {
                      var editable = page.isEditable(false, false);
                      if (page.isEditable() && gridEditable) {
                        if (typeof before === 'function' && before(checkedIndexes, gridComponent.id, editable,
                            gridComponent) ==
                          false) return;
                        for (var i = checkedIndexes.length - 1; i >= 0; i--) {
                          grid.removeRow(checkedIndexes[i]);
                        }
                        grid.setFocus();
                        if (typeof after === 'function') after(checkedIndexes, gridComponent.id, editable, gridComponent);
                      }else{
                        //수정 불가상태에서 삭제시 메세지 처리 하기 위해서 argments에 "N" 추가
                        if (typeof before === 'function' && before(checkedIndexes, gridComponent.id, editable, gridComponent , "N") == false) return;
                      }
                    } else {
                      dews.ui.snackbar.info(gridComponent.type == VC.gridTypes.grid ? VC.messages.delete.no_rows.grid :
                        VC.messages
                        .delete.no_rows.cardlist);
                    }
                  }
                };
              },
              search: function (searchData) {
                return function (e) {
                  VC.commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'search'
                  };
                  e.preventDefault();
                  if (typeof searchData !== 'function') {
                    console.error('searchData must be a function.');
                  } else {
                    var wrapperSearch = function () {
                      page.grids.forEach(function (grid) {
                        if (grid.dataSource && !grid.dataSource.options.error) {
                          grid.dataSource.options.error = function (e) {
                            if (e) {
                              dews.error(e);
                              dews.ui.loading.hide();
                            }
                          }
                        }
                      });
                      var result = searchData();
                      if (result !== false) {
                        page.storePrimaryKey();
                        page.dirty = false;
                      }
                    };
                    if (page.isDirty(options)) {
                      var confirm = dews.confirm(VC.messages.search.not_saved, 'ico2')
                        .yes(function () {
                          wrapperSearch();
                        });
                    } else wrapperSearch();
                  }
                };
              },
              save: function (before, after, models) {
                return function (e) {
                  VC.commitCells();
                  var options = {
                    fixed: fixedGridId,
                    target: 'save',
                    models: models
                  };
                  e.preventDefault();
                  if (page.isDirty(options)) {
                    if (package_fg == '2') {
                      var gridComponents = page.getDirtyGridComponent(options);
                      for (var index = 0; index < gridComponents.length; index++) {
                        var gridComponent = gridComponents[index];
                        if (gridComponent.allowFunctions.customValidation == true) continue;
                        if (gridComponent.type == 'grid' && gridComponent.grid && (gridComponent.grid.validate(true) || {})
                          .result == false) {
                          dews.alert(VC.messages.save.verify, 'warning');
                          gridComponent.grid.setFocus();
                          return;
                        }
                      }
                    }
                    var verifyResult = page.verify(options);
                    if (verifyResult.length > 0) {
                      //verifyResult[0].gridComponent.grid.select(verifyResult[0].rows[0]);
                      verifyResult[0].gridComponent.grid.setFocus();
                    } else {
                      var editable = page.isEditable(true, false);
                      if (typeof before === 'function' && before(page.getDirtyDataSource(options), editable) == false)
                        return;
                      if (page.isEditable()) {
                        new Promise(function (resolve) {
                          if (package_fg == '2') {
                            var confirm = dews.confirm(VC.messages.save.ask, 'ico2')
                              .yes(function () {
                                setTimeout(function () {
                                  resolve();
                                }, 0);
                              });
                          } else {
                            resolve();
                          }
                        }).then(function () {
                          return new Promise(function (resolve) {
                            dews.ui.loading.show({
                              text: VC.messages.save.saving
                            });
                            setTimeout(function () {
                              resolve();
                            }, 0);
                          });
                        }).then(function () {
                          if (package_fg == '2') {
                            options.showMessage = false;
                          }
                          return page.savePromise(options);
                        }).then(function (success) {
                          dews.ui.loading.hide();
                          if (success) {
                            page.ignoreDirty = true;
                            try {
                              dews.ui.mainbuttons.search.click();
                              if (package_fg == '2') {
                                setTimeout(function () {
                                  dews.alert(VC.messages.save.done);
                                }, 150);
                              }
                            } catch (ex) {
                              throw ex;
                            } finally {
                              page.ignoreDirty = false;
                            }
                          }
                          if (success && typeof after === 'function') after();
                        });
                      }
                    }
                  } else {
                    if (package_fg == '2') {
                      dews.alert(VC.messages.save.no_dirty);
                    } else {
                      dews.ui.snackbar.info(VC.messages.save.no_dirty);
                    }
                  }
                };
              },
              print: function (before, reportSet, rprt_cd, personalInfoFieldNames) {
                return function (e) {
                  VC.commitCells();
                  e.preventDefault();
                  if (typeof before === 'function' && before(reportSet, rprt_cd) == false) return;
                  page.invokePrint(reportSet, rprt_cd, personalInfoFieldNames);
                };
              }
            };
          },
          /**
           * 출력일을 설정하거나, 얻습니다.
           */
          printDate: function (printDate) {
            if (printDate != undefined) {
              this.dataSet.printDate = printDate;
            }
            var result = this.dataSet.printDate;
            if (result == null) {
              result = VC.todayString();
              var dewself = this.dataSet.dewself;
              var componentId = this.dataSet.componentId;
              var componentInfo = VC.isNotNull(this.dataSet.cache.componentInfo) ? this.dataSet.cache.componentInfo : VC
                .getCommonComponentInfo(
                  dewself, componentId);
              if (componentInfo.mrtf_sq.valid && componentInfo.vat_ym.valid && componentInfo.mrtf_sq.value().code == '0') {
                var tempDate = dews.date.parse(componentInfo.vat_ym.value().to.substring(0, 6) + '25');
                tempDate.setMonth(tempDate.getMonth() + 1);
                result = dews.date.format(tempDate, 'yyyyMMdd');
              }
            }
            return result;
          },
          /**
           * fg_declterm 을 얻습니다.
           */
          declterm_fg: function () {
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            return VC.declterm_fg(dewself, componentId, this.dataSet.cache);
          },
          /**
           * VC.cd_subBizArea() 참고
           */
          subo_cd: function (bizarea_cd) {
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            return VC.subo_cd(dewself, componentId, this.dataSet.cache, bizarea_cd);
          },
          cd_subBizArea: function (bizarea_cd) {
            return this.subo_cd(bizarea_cd);
          },
          /**
           * 현 검색조건의 PrimaryKey 를 저장합니다.
           * extranPrimaryKey 를 지정하면 해당 항목도 추가적으로 저장됩니다.
           * @param {json} extraPrimaryKey 추가 저장 목록
           */
          storePrimaryKey: function (extraPrimaryKey) {
            var dewself = this.dataSet.dewself;
            var componentId = this.dataSet.componentId;
            var componentInfo = VC.isNotNull(this.dataSet.cache.componentInfo) ? this.dataSet.cache.componentInfo : VC
              .getCommonComponentInfo(
                dewself, componentId);
            var storeValues = {};
            if (componentInfo.decl_fg.valid) storeValues.decl_fg = componentInfo.decl_fg.value();
            if (componentInfo.bizarea_cd.valid) {
              storeValues.bizarea_cd = componentInfo.bizarea_cd.value().code;
              storeValues.bizarea_nm = componentInfo.bizarea_cd.value().text;
            }
            if (componentInfo.decl_fg.valid && componentInfo.bizarea_cd.valid) {
              storeValues.subbizarea_cd = this.cd_subBizArea();
            }
            if (componentInfo.vat_ym.valid) {
              storeValues.from_ym = componentInfo.vat_ym.value().from;
              storeValues.to_ym = componentInfo.vat_ym.value().to;
              storeValues.declterm_fg = this.declterm_fg();
            }
            if (componentInfo.mrtf_sq.valid) {
              storeValues.mrtf_sq = componentInfo.mrtf_sq.value().code;
              storeValues.nm_sq_modify = componentInfo.mrtf_sq.value().text;
            }
            this.dataSet.primaryKey = $.extend(true, {}, this.dataSet.primaryKey, storeValues);
            if (VC.isNotNull(extraPrimaryKey)) {
              var loweredSet = {};
              for (var prop in extraPrimaryKey) {
                loweredSet[prop.toLowerCase()] = extraPrimaryKey[prop];
              }
              this.dataSet.extraPrimaryKey = $.extend(false, this.dataSet.extraPrimaryKey || {}, loweredSet);
            }
          },
          /**
           * Primary Key 를 얻습니다.
           */
          getPrimaryKey: function (primaryKeyName) {
            var dewself = this.dataSet.dewself;
            primaryKeyName = VC.isNotNull(primaryKeyName) ? primaryKeyName.toLowerCase() : primaryKeyName;
            if (VC.isNotNull(primaryKeyName) && primaryKeyName.length > 0) {
              if (this.dataSet.extraPrimaryKey != null && this.dataSet.extraPrimaryKey.hasOwnProperty(primaryKeyName))
                return this.dataSet.extraPrimaryKey[primaryKeyName];
              if (this.dataSet.primaryKey.hasOwnProperty(primaryKeyName))
                return this.dataSet.primaryKey[primaryKeyName];
              return '';
            } else {
              return $.extend(true, {}, this.dataSet.primaryKey, this.dataSet.extraPrimaryKey);
            }
          },
          /**
           * 그리드 rowAdd 이벤트 호출시 기본값을 지정합니다.
           */
          setPrimaryKeys: function (gridComponent, e) {
            if (e.hasOwnProperty('row') && e.row.hasOwnProperty('index') && e.row.hasOwnProperty('data')) {
              var primaryKeys = $.extend(false, {
                data_fg: '1',
              }, this.dataSet.primaryKey, this.dataSet.extraPrimaryKey);
              for (var primaryKey in primaryKeys) {
                if (e.row.data.hasOwnProperty(primaryKey.toUpperCase())) {
                  gridComponent.grid.setCellValue(e.row.index, primaryKey.toUpperCase(), primaryKeys[primaryKey]);
                }
              }
            }
          },
          /**
           * 인쇄 호출.
           * @argument {String} reportId
           * @argument {String} objectId
           * @argument {Json} parameters
           */
          invokePrint: function (reportSet, rprt_cd, personalInfoFieldNames) {
            var dewself = this.dataSet.dewself;
            var page = this;
            rprt_cd = VC.normalizeParameter(rprt_cd);
            if (VC.nvl(rprt_cd, '') == '') rprt_cd = 'R_' + (dewself.menu || {}).id + '_0';
            reportSet = VC.normalizeParameter(reportSet);
            if (typeof reportSet === 'undefined' || reportSet == null) {
              reportSet = {};
              reportSet['R_' + (dewself.menu || {}).id + '_01'] = {};
            }
            new Promise(function (resolve) {
              if ((personalInfoFieldNames || []).length > 0) {
                var dialog = dews.ui.dialog('printPersonalConfigDialog', {
                  title: '인쇄',
                  content: '<div style="width: 100%; height: 50px; display: flex; flex-direction: row; align-items: center; justify-content: center;">' +
                    '<input type="checkbox" id="no_masking_yn" class="dews-ui-checkbox">' +
                    '<label for="no_masking_yn" style="text-align: left !important; margin-left: 5px">신고용(개인정보표시)</label>' +
                    '</div>' +
                    '<div class="dews-ui-referbox" style="height: 40px;">' +
                    '  <ul><li>개인정보마스킹 설정이 되어 있지 않다면, 보관용으로 인쇄하더라도 개인정보가 표시됩니다.</li></ul>' +
                    '</div>',
                  buttons: 'applyAndClose',
                  width: 400,
                  height: 210
                });
                dialog.buttons.ok.on('click', function () {
                  dialog.close();
                  resolve(dialog.$content.find('#no_masking_yn').prop('checked') ? 'Y' : 'N');
                });
                dialog.open();
              } else {
                resolve('N');
              }
            }).then(function (no_masking_yn) {
              var items = [];
              for (var object_cd in reportSet) {
                var parameters = $.extend(true, page.getPrimaryKey(), {
                    printdate: page.printDate(),
                    no_masking_yn: no_masking_yn
                  },
                  VC.normalizeParameter(reportSet[object_cd]));
                if ((personalInfoFieldNames || []).length > 0) {
                  personalInfoFieldNames.forEach(function (personalInfoFieldName) {
                    parameters['m_' + personalInfoFieldName] = dews.getSecureMaskFormat(personalInfoFieldName) ||
                      '';
                  });
                }
                for (var para_cd in parameters) {
                  items.push({
                    RPRT_CD: rprt_cd,
                    OBJECT_CD: object_cd,
                    PARA_CD: para_cd,
                    PARA_TXT: parameters[para_cd]
                  });
                }
              }
              dews.api.post(dews.url.getApiUrl('CM', 'printService', 'setPrintParam'), {
                data: {
                  reportCode: rprt_cd,
                  items: JSON.stringify(items)
                }
              }).done(function (parameterKey) {
            	  if (VC.nvl(parameterKey, '').length > 0) {
            		  if(page.dataSet.package_fg == '1'){
            			  var options = {
            					  reportId : rprt_cd,
            					  parameterKey : parameterKey,
            					  menuId : (dewself.menu || {}).id
            			  };
            			  dews.app.print(options);
            		  }
            		  else if(page.dataSet.package_fg == '2'){
            			  /* 인증토큰 */
            			  var authToken = JSON.parse(dewself.token).access_token;
            			  /* 출력물 정보 */
            			  var reportInfoUrl = window.location.protocol + "//" + window.location.host + dews.url.getApiUrl('CM','printService', 'getPrintFormList');
            			  /* DRWebViewer 호출 */
            			  location.href = 'GERP://" "' + authToken + '" "' + rprt_cd + '" "' + reportInfoUrl + '" "' + parameterKey + '" "' + (dewself.menu || {}).id;
            		  }
            	  }
              });
            })
          },
          openMenu: function (moduleId, menuId, data) {
            dews.ui.openMenu(moduleId, menuId, $.extend(true, this.getPrimaryKey(), data));
          },
          /**
           * 부가세 관련 현대백화점용 코드피커아이디를 알맞게 변경하여 반환합니다..
           * VC.initializeComponents 참고
           * @example page.initializeComponents();
           */
          getCodePickerID: function (id) {
            if ((this.dataSet.package_fg || '1') == '2') {
              switch (id) {
                case 'H_MA_PARTNER_MST_S':
                  id = 'H_MA_PARTNER_MST_S_HDG';
                  break;
                case 'H_PS_WBS_MST_S':
                  id = 'H_MA_PROJECT_MST_S';
                  break;
              }
            }
            return id;
          },
          getCodePickerOptions: function (options, source) {
            var page = this;
            if ((this.dataSet.package_fg || '1') == '2') {
              var id = (options || {}).helpCode || '';
              switch (id) {
                case 'H_MA_PARTNER_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_PARTNER_MST_S_HDG',
                    helpCustom: false,
                    helpParams: (function (helpParams) {
                      return function () {
                        var userHelpParams = {};
                        if (helpParams && typeof helpParams === 'function')
                          userHelpParams = helpParams(arguments);
                        else userHelpParams = helpParams || {};
                        var pc_cd_pipe = dews.ui.page.user.profitCenterCode + '|';
                        var bizarea_cd_pipe = '';
                        switch ((source || '')) {
                          case 'component':
                            bizarea_cd_pipe = page.cd_subBizArea();
                            break;
                          case 'grid':
                            bizarea_cd_pipe = page.getPrimaryKey('subbizarea_cd');
                            break;
                        }
                        if (bizarea_cd_pipe && bizarea_cd_pipe.length > 0) {
                          dews.api.post(dews.url.getApiUrl('TX', 'TxCommonServices', 'pc_cd_list'), {
                            async: false,
                            data: {
                              bizarea_cd_pipe: bizarea_cd_pipe
                            }
                          }).done(function (datas) {
                            if (datas && datas.length > 0) {
                              pc_cd_pipe = datas.map(function (data) {
                                return data.PC_CD;
                              }).join('|');
                            }
                          }).fail(function (xhr, status, error) {
                            console.error(error);
                            dews.alert(error, 'error');
                          });
                        }
                        return $.extend(true, {
                          'pc_cd': (pc_cd_pipe || dews.ui.page.user.profitCenterCode) || ''
                        }, userHelpParams);
                      };
                    })(options.helpParams)
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      if ((pickerData.PARTNER_FG_CD || '') == '7') {
                        pickerData.RES_NO = pickerData.PARTNER_MNG_NO;
                      }
                      callback(rowData, pickerData, rowIndex);
                    };
                  }
                  break;
                case 'H_PS_WBS_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_PROJECT_MST_S',
                    helpCustom: false,
                    codeField: 'PJT_NO',
                    textField: 'PJT_NM',
                    helpSize: 'big'
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      callback(rowData, $.extend(true, {}, pickerData, {
                        WBS_NO: pickerData.PJT_NO,
                        WBS_NM: pickerData.PJT_NM
                      }), rowIndex);
                    };
                  }
                  break;
                case 'H_FI_ASSET_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'AMGASC00200_IMPORT',
                    helpCustom: true,
                    codeField: 'ASSET_CD',
                    textField: 'ASSET_NM',
                    helpSize: 'medium',
                    helpViewUrl: '/view/FA/AMGASC00200_IMPORT',
                    helpTitle: '고정자산도움창'
                  });
                  break;
                case 'H_MA_COA_MST_S':
                case 'H_MA_COA_MST_S02':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_COA_MST_C',
                    helpCustom: true,
                    textField: 'FULL_ACCT_NM',
                    helpWidth: 700,
                    helpHeight: 600,
                    helpViewUrl: '~/codehelp/CM/H_MA_COA_MST_C',
                    helpApiUrl: '/api/CM/CMCustomCodeHelpService/H_MA_COA_MST_C_list_auto_comp',
                    helpParams: (function (helpParams) {
                      return function () {
                        var userHelpParams = {};
                        if (helpParams && typeof helpParams === 'function')
                          userHelpParams = helpParams(arguments);
                        else userHelpParams = helpParams || {};
                        userHelpParams = $.extend(false, {
                          gaap_cd: '',
                          end_dt: '',
                          drcrfg_cd: '',
                          acctattr_cd: '',
                          fsform_cd: 'D0012',
                          fill_yn: '',
                          keyword: '',
                          dept_cd: '',
                          grp_fg_cd: '',
                          relation_cd: '',
                          partner_mndr_fg_cd: '',
                          acct_cd: '',
                          acctlv_cd: '',
                          up_acct_cd: '',
                          input_fg: 'N',
                          pc_cd: dews.ui.page.user.profitCenterCode || '',
                          end_acct_fg: 'N'
                        }, userHelpParams);
                        if (id == 'H_MA_COA_MST_S02') {
                          userHelpParams = $.extend(false, { fill_yn: 'Y' }, userHelpParams);
                        }
                        return userHelpParams;
                      };
                    })(options.helpParams)
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      callback(rowData, $.extend(true, {}, pickerData, {
                        ACCT_NM: pickerData.FULL_ACCT_NM
                      }), rowIndex);
                    };
                  }
                  break;
                case 'H_MA_DEPT_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_DEPT_MST_C',
                    helpCustom: true,
                    textField: source == 'component' ? 'DEPT_NM' : 'FULL_DEPT_NM',
                    helpWidth: 700,
                    helpHeight: 600,
                    helpViewUrl: '~/codehelp/CM/H_MA_DEPT_MST_C',
                    helpApiUrl: '/api/CM/CMCustomCodeHelpService/H_MA_DEPT_MST_C_list_auto_comp',
                    helpParams: (function (helpParams) {
                      return function () {
                        var userHelpParams = {};
                        if (helpParams && typeof helpParams === 'function')
                          userHelpParams = helpParams(arguments);
                        else userHelpParams = helpParams || {};
                        userHelpParams = $.extend(false, {
                          company_cd: '',
                          bizarea_cd: '',
                          pc_cd: dews.ui.page.user.profitCenterCode || '',
                          dept_cd: '',
                          dept_lv: '',
                          end_dt: '',
                          fill_yn: '',
                          keyword: '',
                          user_id: '',
                          eltr_athz_mngt_dept_yn: '',
                          input_fg: 'N',
                          end_dept_fg: 'N',
                          unauth_fg: 'N'
                        }, userHelpParams);
                        return userHelpParams;
                      };
                    })(options.helpParams)
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      callback(rowData, $.extend(true, {}, pickerData, {
                        DEPT_NM: pickerData[source == 'component' ? 'DEPT_NM' : 'FULL_DEPT_NM']
                      }), rowIndex);
                    };
                  }
                  break;
                case 'H_HR_EMP_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_HR_EMP_MST_S_HDG',
                  });
                  break;
              }
            } else {
              var id = (options || {}).helpCode || '';
              switch (id) {
                case 'H_MA_PARTNER_MST_S':
                  options = $.extend(true, {}, options, {
                    helpCode: 'H_MA_PARTNER_MST_S',
                    helpCustom: true,
                    codeField: 'PARTNER_CD',
                    textField: 'PARTNER_NM',
                    helpSize: 'big',
                    helpViewUrl: '~/codehelp/MA/H_MA_PARTNER_MST_C',
                    helpApiUrl: dews.url.getApiUrl('MA', 'MACustomCodeHelpService', 'MA_PARTNERE_MST_C_list'),
                    helpParams: function () {
                      return {
                        company_cd: "",
                        partner_fg_cd: "",
                        partner_csf_cd: "",
                        keyword: "",
                        start: 0,
                        count: 500,
                        use_yn: "Y"
                      }
                    }
                  });
                  if (options.callback) {
                    var callback = options.callback;
                    options.callback = function (rowData, pickerData, rowIndex) {
                      if (pickerData && pickerData.RES_NO && pickerData.RES_NO.length > 0) {
                        dews.api.get(dews.url.getApiUrl('TX', 'TxCommonServices', 'personal_decrypt_get'), {
                          async: false,
                          data: {
                            cryptKey: pickerData.RES_NO || '',
                            encryptStyle: 'JUMIN'
                          }
                        }).done(function (decrypt) {
                          if (decrypt && String(decrypt).length > 0) {
                            pickerData.RES_NO = String(decrypt);
                          }
                        }).fail(function (xhr, status, error) {
                          console.error(error);
                          dews.alert(error, 'error');
                        });
                      }
                      callback(rowData, pickerData, rowIndex);
                    };
                  }
              }
            }
            return options;
          },
          /**
            * @method 엑셀다운
            * @description 웹소켓방식 엑셀다운로드
          */
          wsExcelDown : function(url, parameter) {
            var progressBar = dews.ui.progress("progressBar", {
              total: 100,
              modal: true,
              textTemplate: dews.localize.get('데이터를', 'D0090437') + ' <strong>#=percent#</strong> ' + dews.localize.get('처리 중 입니다.', 'M0016920'),
              alterTextTemplate: dews.localize.get('진행 상황: #=progress#', 'D0005460')
          });
            return dews.ws.ltx(url, {
              data: parameter,
              done: function (e) {
                progressBar.setCurrent(0);
                var resultList = JSON.parse(e.resultData)
                var token;
                $.each(resultList, function (index, resultData) {
                  dews.api.get("/auth/temporary/token", {
                    async: false
                  }).done(function(data) {
                    token = data;
                    var key = resultData.split('/')[0];
                    var filename = resultData.split('/')[1];
                    var url = dews.string.format("/download/tempfile?token={0}&key={1}&filename={2}", token, key, filename);

                    var xhr = new XMLHttpRequest();
                    xhr.open("GET", url, true);
                    xhr.responseType = "blob";
                    xhr.send();
                    xhr.onload = function (e) {
                      if(window.navigator && window.navigator.msSaveOrOpenBlob){
                        window.navigator.msSaveOrOpenBlob(xhr.response, filename);
                      } else {
                        var element = window.document.createElement("a");
                        element.href = window.URL.createObjectURL(xhr.response);
                        element.download = filename;
                        element.click();
                      }
                    };
                  });
                });

                setTimeout(function () {
                  if (progressBar.container.is(":visible")) {
                    progressBar.close();
                  }
                });
              },
              error: function (e) {
                progressBar.close();
                setTimeout(function () { dews.error(e.resultData) });
              },
              progress: function (e) {
                progressBar.setCurrent(e.resultData);
              }
            });
          },
          /**
           * 부가세 관련 현대백화점용 코드피커를 초기화합니다.
           * VC.initializeComponents 참고
           * @example page.initializeComponents();
           */
          initializeCodePicker: function (parentSelector) {
            var self = this;
            if ((self.dataSet.package_fg || '1') == '2') {
              var setCodePicker = function (idx, el) {
                var $el = $(el).data('dews-control');
                var options = ($el.getOptions() || {});
                var newOptions = self.getCodePickerOptions(options, 'component');
                if (newOptions != options) {
                  $el.setOptions(newOptions);
                }
              }
              parentSelector = parentSelector || '#content_' + dews.ui.page.menu.id;
              $(parentSelector + ' .dews-ui-codepicker').each(setCodePicker);
              $(parentSelector + ' .dews-ui-multicodepicker').each(setCodePicker);
            }
            else {
              // getCodePickerOptions내부에서 분기처리 되어있긴 한데 혹시 몰라서 그냥 별도 else문으로 처리
	          var setCodePicker = function (idx, el) {
	            var $el = $(el).data('dews-control');
	            var options = ($el.getOptions() || {});
	            var id = (options || {}).helpCode || '';
	            if(id == "H_MA_PARTNER_MST_S") {
	              var newOptions = self.getCodePickerOptions(options, 'component');
	              if (newOptions != options) {
	                $el.setOptions(newOptions);
	              }
	            }
	          }
	          parentSelector = parentSelector || '#content_' + dews.ui.page.menu.id;
	          $(parentSelector + ' .dews-ui-codepicker').each(setCodePicker);
	          $(parentSelector + ' .dews-ui-multicodepicker').each(setCodePicker);
	        }
          },
          getCodePickerEditor: function (options) {
            if ((options || {}).type == 'codepicker') {
              return this.getCodePickerOptions(options, 'grid');
            }
            return options;
          },
          isValidDate: function (e) {
            var self = this;
            var invalidField = [].slice.call(arguments)
              .find(function (field) {
                if (e.cell.field == field) {
                  var to_ym = VC.number(self.getPrimaryKey('to_ym'));
                  var value = e.row.data[field] && e.row.data[field] instanceof Date ? dews.date.format(e.row.data[field],
                    'yyyyMMdd') : e.row.data[field];
                  if (value && value.length > 0 && $.isNumeric(value)) {
                    if (Number(to_ym) < Number(value.substring(0, 6))) {
                      dews.alert(dews.string.format('{0}은(는) 과세기간 종료일 보다 클 수 없습니다.', e.grid.columns[field.toUpperCase()]
                        .title));
                      e.grid.cancelCell();
                      return true;
                    }
                  }
                }
                return false;
              });
            return invalidField && invalidField.length > 0 ? false : true;
          },
          validateResidentNumber: function (value) {
            try {
              var format = /^\d{6}[1234]\d{6}$/;
              if (false == format.test(value)) {
                return false;
              }
              var birthYear = (value.charAt(6) <= "2") ? "19" : "20";
              birthYear += value.substr(0, 2);
              var birthMonth = value.substr(2, 2) - 1;
              var birthDay = value.substr(4, 2);
              var birthDate = new Date(birthYear, birthMonth, birthDay);
              if (birthDate.getFullYear() % 100 != value.substr(0, 2) ||
                birthDate.getMonth() != birthMonth ||
                birthDate.getDate() != birthDay) {
                return false;
              }
              var array = new Array(13);
              for (var i = 0; i < 13; i++) {
                array[i] = parseInt(value.charAt(i));
              }
              multipliers = [2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5];
              for (var sum = 0, i = 0; i < 12; i++) {
                sum += (array[i] *= multipliers[i]);
              }
              if ((11 - (sum % 11)) % 10 != array[12]) {
                return false;
              }
              return true;
            } catch (error) {
              console.log(error);
            }
          },
          getResidentNumberStyle: function (fieldName) {
            var self = this;
            return function (e) {
              return self.validateResidentNumber(e.row.data[fieldName]) == false ? {
                color: '#ff0000'
              } : {};
            }
          },
          // 현대백화점 전용
          addEvidenceDocumentPromise: function (evidenceTypeOrMenuCode, sourceKey) {
            var self = this;
            return new Promise(function (resolve, reject) {
              var evidenceKey = null;
              var companyCode = dews.ui.page.user.companyCode;
              var userCode = dews.ui.page.user.userid;
              if (self.dataSet.package_fg == '2') {
                switch (evidenceTypeOrMenuCode) {
                  case 'cash':
                  case 'VATHTX00400':
                    evidenceKey = sourceKey;
                    break;
                  case 'nts':
                  case 'VATETI00300':
                  case 'VATETI00900':
                    evidenceKey = sourceKey;
                    break;
                  default:
                    dews.api.post(dews.url.getApiUrl('TX', 'TxCommonServices', 'new_document_number_get'), {
                      async: false,
                      data: {}
                    }).done(function (data) {
                      if (data && data.HWRT_EVDN_CONN_KEY_VAL) {
                        evidenceKey = data.HWRT_EVDN_CONN_KEY_VAL;
                      }
                    }).fail(function (xhr, status, error) {
                      console.error(error);
                      dews.alert(error, 'error');
                      reject(error);
                    });
                    break;
                }
                if ((evidenceKey || '') != '') {
                  dews.ajax.script('~/view/js/fi.slip.js', {
                      once: true
                    })
                    .done(function () {
                      if ($.OfficeSLIP) {
                        $.OfficeSLIP.SLIP_Load(companyCode, userCode, evidenceKey, 'EDIT', 'FI', function (hwrtResult) {
                          var result = hwrtResult.split("/");
                          if(result[1]=="0" && result[2]=="0") {
                            resolve("");
                          } else{
                            resolve(evidenceKey);
                          }
                        });
                      } else {
                        reject('slip script load error.');
                      }
                    })
                    .fail(function (xhr, status, error) {
                      console.error(error);
                      dews.alert(error, 'error');
                      reject(error);
                    });
                } else {
                  reject('evidenceKey is not valid.');
                }
              } else {
                reject('not suppored.');
              }
            });
          },
          viewEvidenceDocumentPromise: function (evidenceTypeOrMenuCode, evidenceKey) {
            var self = this;
            return new Promise(function (resolve, reject) {
              if (self.dataSet.package_fg == '2') {
                var companyCode = dews.ui.page.user.companyCode;
                var userCode = dews.ui.page.user.userid;
                if ((evidenceKey || '') != '') {
                  dews.ajax.script('~/view/js/fi.slip.js', {
                      once: true
                    })
                    .done(function () {
                      if ($.OfficeSLIP) {
                        $.OfficeSLIP.SLIP_Load(companyCode, userCode, evidenceKey, 'VIEW', 'FI', function () {});
                        resolve(evidenceKey);
                      } else {
                        reject('slip script load error.');
                      }
                    })
                    .fail(function (xhr, status, error) {
                      console.error(error);
                      dews.alert(error, 'error');
                      reject(error);
                    });
                } else {
                  reject('evidenceKey is not valid.');
                }
              } else {
                reject('not suppored.');
              }
            })
          },
          addOrViewEvidenceDocumentPromise: function (evidenceTypeOrMenuCode, evidenceKey, sourceKey) {
            if ((evidenceKey || '') == '') {
              return this.addEvidenceDocumentPromise(evidenceTypeOrMenuCode, sourceKey);
            } else {
              return this.viewEvidenceDocumentPromise(evidenceTypeOrMenuCode, evidenceKey);
            }
          }
        };
      },
    };
  })();
  //////// 작성 영역 - 끝 ////////
  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=tx.vat.js
