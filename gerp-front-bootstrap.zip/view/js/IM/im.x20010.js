// 모듈 공통 함수
(function (dews, gerp, $) {
	var module = {};
	var moduleCode = 'IM_X20010';
	// ds_id : ds_ + 용어표준
	var codeDsMapArr = [
		// CO
		{ module_cd: 'CO', field_cd: 'P00390'		, field_nm: '손익센터구분코드'	, ds_id: 'ds_pca_fg_cd' },
		
		// MA
		{ module_cd: 'MA', field_cd: 'P00040'		, field_nm: '비용센터분류코드'	, ds_id: 'ds_cc_csf_cd' },
		{ module_cd: 'MA', field_cd: 'P00730'		, field_nm: '차대구분코드'		, ds_id: 'ds_drcrfg_cd' },
		{ module_cd: 'MA', field_cd: 'P00880'		, field_nm: '결재상태코드'		, ds_id: 'ds_athz_st_cd' },
		
		// FI
		{ module_cd: 'FI', field_cd: 'S30030'		, field_nm: '수지구분코드'		, ds_id: 'ds_balc_fg_cd' },
		
		// TR
		{ module_cd: 'TR', field_cd: 'Z01_10144', field_nm: '자금(계획)그룹코드'  , ds_id: 'ds_fundgrp_cd' }
	];
	var linkMenuMapArr = [
    // TR
    
    // FI
    { module_cd: 'FI', menu_id: 'GLDDOC00700'         , menu_nm: '전표조회'},
    { module_cd: 'FI', menu_id: 'GLD00000100_X10005'  , menu_nm: '임시전표리스트'},
    { module_cd: 'FI', menu_id: 'GLD00000200_X10005'  , menu_nm: '확정전표리스트'}
  ];
	
	// msg
	var message = { 
		action: {
			inquiry : '조회하시겠습니까?',
			save	: '저장하시겠습니까?',
			del 	: '삭제하시겠습니까?',
			aply  : '적용하시겠습니까?',
			confirm	: '확정처리 하시겠습니까?',
			print	: '출력하시겠습니까?',
			close	: '변경된 자료는 무시됩니다. \n진행하시겠습니까?',
			keep	: '저장하지 않은 데이터가 있습니다.\n계속하시겠습니까?',
			confirmKeep : '계속하시겠습니까?',
			load	: '조회 중 ...',
			send    : '전송 처리 하시겠습니까?',
			canceled : '취소되었습니다.',
			inquiryCompleted  : '정상적으로 조회되었습니다.',
			saveCompleted     : '정상적으로 저장되었습니다.',
			deleteCompleted   : '정상적으로 삭제되었습니다.',
			requestCompleted  : '정상적으로 처리되었습니다.',
			confirmCompleted  : '확정처리되었습니다.',
			sendCompleted     : '정상적으로 전송되었습니다.',
			filesave          : '파일을 저장하시겠습니까?',
			filesaveCompleted : '파일을 저장하였습니다.',
			isWant  : '{1}을(를) 하시겠습니까?',
			process : '{1}을(를) 처리하였습니다.'
		},
		fail: {
		  work : '작업이 실패하였습니다.',
		},	
		validate: {
		  processAddRow : '행추가 후 진행하시기 바랍니다.',
		  noSelectedRow : '선택된 행이 없습니다.',
		  noDataChanged : '변경된 데이터가 없습니다.',
		  dupData       : '중복된 데이터가 있습니다.',
		  notEqualKey   : 'id와 key 입력 항목의 수가 일치해야 합니다.',
		  notEqualDataKey : 'id와 serviceDataKey 입력 항목의 수가 일치해야 합니다.',
		  noArray   	: '매개변수가 배열이 아닙니다.',
			required 	: '필수입력 항목을 입력하세요.',
			requiredDtl : '{1}은(는) 필수입력입니다.',
			nodefined   : '정의되지 않은 항목이 있습니다.',
			nodefinedDtl: '{1}은(는) 정의되지 않았습니다',
			integer		: '유효한 정수를 입력하세요.',
			date		: '유효한 일자를 입력하세요.',
			wrongDate	: '은 유효한 일자가 아닙니다.',
			time		: '유효한 시간을 입력하세요.',
			wrongTime	: '유효한 시간이 아닙니다.',
			number		: '유효한 숫자를 입력하세요.',
			wrongNumber	: '은 유효한 숫자가 아닙니다.',
			selectRow  : '행을 선택바랍니다.',
			noRecord    : '검색된 데이터가 없습니다.',
			maxValue    : '입력된 값이 최대값보다 큽니다.',
			minValue    : '입력된 값이 최소값보다 작습니다.',
			dateRange   : '일자범위 검증 오류입니다.',
			numberRange : '숫자범위 검증 오류입니다.  ',
			valueRange  : '값 범위 검증 오류입니다.'
		},
		id: {
			noId   	: '매개변수가 필요합니다.',
			tail  : ''
		},
		config: {
		  dispMsg   : '메시지 출력 설정 오류',
		  noServiceReq  : '서비스 요청정보가 없습니다.'
    }
	};
	
	// fucntion
	function fc_isNull(obj) {
		if ( typeof obj === 'string' ) {
			return ( obj === null || obj === 'null' || obj === '' ) ? true : false;
		} else {
			return ( typeof obj === 'undefined' || obj === null ) ? true : false;
		}
	};
	
	function fc_getIdArr(ids) {
		return fc_getSplitArr(ids, "|");
	};
	
	function fc_getItemArr(ids) {
		return fc_getSplitArr(ids, ",");
	};
	
	function fc_getSplitArr(ids, spt) {
		var rsIdArr;
		if ( typeof ids === 'string' ) {
			rsIdArr = ids.split(spt);
		}else{
			rsIdArr = fc_isNull(ids) ? [] : ids;
		}
		return rsIdArr;
	};
	
	// keys : ','조합문자열, string[]
	function fc_getKeyJoinArr(data, keys) {
		var keyArr = fc_getItemArr(keys);
		
		if(typeof obj === 'object' && data.length === 'undefined'){
			data = [data];
		}
		
		var keyJoinArr = data.map(function (item) {
			return keyArr.map(function (keyEle) {
				return item[keyEle];
			}).join('|');
		});
		return keyJoinArr;
	};
	
	function fc_isFunction(obj) {
		return ( obj && typeof (obj) == 'function' ) ? true : false;
	};
	
	function fc_nvl(obj, defObj) {
		return fc_isNull(obj) ? defObj : obj;
	}
	
	function fc_getEventData(e) {
		if( !fc_isNull(e.cell) ){
			return e.cell.data;
		}
		/*
     * switch (dispMsgTp) { case 'alert': dews.alert(dispMsg); break; case
     * 'error': dews.error(dispMsg); break; };
     */
		
		return null;
	}
	
	function fc_getMenu(menuId) {
	  return linkMenuMapArr.filter(function(item) {
      return item.menu_id == menuId;
    })[0];
	}
	
	function fc_link(menuId, linkParams) {
	  var mi = fc_getMenu(menuId);
	  if( !fc_isNull(mi) ){
	    dews.ui.openMenu(mi.module_cd, mi.menu_id, linkParams);
	  }
	}
	
	function fc_getLinkFiDocuMenuId(opt) {
	  var rsMenuId = 'GLDDOC00700';
	  var drsCode = opt.drsCode;
	  var pcCd = fc_nvl(opt.pc_cd, self.user.profitCenterCode);
    var docuNo = opt.docu_no;
    
	  if( drsCode == '10005' ){
	    //동서발전
	    var docuMst = module.api.getDocuMst(pc_cd, docu_no);
	    if( !fc_isNull(docuMst) ){
	      if(docuMst.DOCU_ST_CD == '1'){
	        //확정전표리스트/GLD00000200_X10005
	        rsMenuId = 'GLD00000200_X10005'; 
	      }else if(docuMst.DOCU_ST_CD == '2'){
	        //임시전표리스트/GLD00000100_X10005
	        rsMenuId = 'GLD00000100_X10005';
	      }
	    }
    }else if( drsCode == '10144' ){
      //은하수산
    }else if( drsCode == '20010' ){
      //에이직랜드
    }else{
      
    }
    return rsMenuId;
	}
	
	function fc_setLinkFiDocuMenuId(opt) {
	  opt.menu_id = fc_getLinkFiDocuMenuId(opt);
	  fc_linkFiDocuNo(opt);
	}
	
	function fc_linkFiDocuNo(opt) {
		var self = fc_getPage();
		var e = opt.event;
		var pcCd = opt.pc_cd;
		var docuNo = opt.docu_no;
		var fiMenuId = 'GLDDOC00700'; //전표조회승인
		
		var docuParams = {
			pc_cd: fc_nvl(pcCd, self.user.profitCenterCode),
			docu_no: fc_nvl(docuNo, fc_getEventData(e))
		};
		
		if( !fc_isNull(opt.menu_id) ){
		  fiMenuId = opt.menu_id;
		}
		dews.ui.openMenu('FI', fiMenuId, docuParams);
	};
	
	function fc_log(logTit, obj) {
		console.log(logTit, "(1):", obj, ", type(2):", typeof obj);
	}
	
	function fc_logObj(logTit, obj){
		fc_log(logTit, obj);
		try{
			if(typeof obj == 'object'){
				fc_log('obj.options', obj.options);
			}
		} catch (error) {
			console.log("fc_logObj.error:", error);
		}
	}
	
	function fc_getObjTp(obj) {
		var objTp = "";
		
		fc_logObj("fc_getObjTp", obj);
		
		if( obj._grid ){
			objTp = "GRID";
		}else if( obj._card ){
			objTp = "CARD";	
		}
		
		return objTp;
	};
	
	function fc_getObjDsId(obj) {
		return obj.options.dataSource.id;
	}
	function fc_getObjDs(obj) {
		//console.log("fc_getObjDs.", obj);
		if( obj._grid ){
			// console.log("obj.dataSource:", obj.dataSource);
			// console.log("obj._grid.dataSource:", obj._grid.dataSource);
			
			return obj.dataSource;
		}else if( obj._card ){
			// console.log("obj.dataSource:", obj.dataSource);
			// console.log("obj._card.dataSource:", obj._card.dataSource);
			
			return obj._card.dataSource;	
		}else {
		  if( obj.dataSource ){
        return obj.dataSource;
      }else{
        return obj.options.dataSource;
      }
		}
	}
	
	function fc_getPage() {
		return dews.ui.dialogPage ? dews.ui.dialogPage : dews.ui.page;
	}
	
	function fc_getDtlTitle(tit) {
		return fc_isNull(tit) ? "": " [" + tit + "]";
	}
	
	// api fail시 setTimeout적용해야만 메시지가 출력됨(버그?)
	function fc_failError(msg) {
		setTimeout(function () {
            dews.error(msg);
        }, 200);
	}
	
	function fc_confirmNo() {
	  dews.ui.snackbar.warning(message.action.canceled);
	}
	
	function fc_dispMsg(sgOpt, defOpt) {
	  var isDispMsg = (sgOpt.isDispMsg == false) ? sgOpt.isDispMsg : true;
	  var dispMsgTp = sgOpt.dispMsgTp;
	  
	  var dispMsgFg = sgOpt.dispMsgFg || (defOpt ? fc_nvl(defOpt.dispMsgFg, 'msgbox') : 'msgbox');
	  var dispMsg = sgOpt.dispMsg || (defOpt ? fc_nvl(defOpt.dispMsg, null) : null);
	  
	  if(dispMsgTp == 'error'){
		  isDispMsg = true;
	  }
	  
	  if( isDispMsg && dispMsgTp && dispMsg ){
		  if( dispMsgFg == "msgbox" ){
			  switch (dispMsgTp) {
  	      case 'alert':
  	    	  dews.alert(dispMsg);
  	    	  break;
  	      case 'error':
  	    	  dews.error(dispMsg);
  	    	  break;
  	      default:
  	    	  dews.alert(message.config.dispMsg);
  	    	  break;
			  };
			  
		  }else if( dispMsgFg == "snackbar" ){
			  switch (dispMsgTp) {
  	      case 'ok':
  	    	  dews.ui.snackbar.ok(dispMsg);
  	    	  break;
  	      case 'warning':
  	    	  dews.ui.snackbar.warning(dispMsg);
  	    	  break;
  	      case 'error':
  	    	  dews.ui.snackbar.error(dispMsg);
  	    	  break;
  	      default:
  	    	  dews.alert(message.config.dispMsg);
  	    	  break;
			  };
		  }
	  }
	}
	
	function fc_isGrid(obj) {
		return ( fc_getObjTp(obj) == 'GRID' ) ? true : false;
	}
	function fc_isCard(obj) {
		return ( fc_getObjTp(obj) == 'CARD' ) ? true : false;
	}
	
	function fc_clearRows(obj) {
		obj.dataItems([]);
	}
	
	function fc_clearDs(obj) {
    obj.data([]);
  }
	
	function fc_setBtnEnable(btnIds, flag, btnAuths) {
	  var self = fc_getPage();
	  var btnIdArr = fc_getIdArr(btnIds);
	  var btnAuthArr = fc_getIdArr(btnAuths);
	  var authority = '2';
	  //2: 사용, 1: 미사용, 0: 숨김
	  
	  btnIdArr.forEach(function(element, index){
	    authority = btnAuthArr.length > 0 ? btnAuthArr[index] : '2';
	    if(authority == '2' && fc_isFunction(self[element].enable)){
	      self[element].enable(flag);
	    }
    });
  }
	
	function fc_isParentSelected(parObj, msg) {
		msg = msg || message.validate.processAddRow;
		var parRow = parObj.select();

    if (typeof parRow == 'undefined' || parRow == -1) {
      dews.alert(msg);
      return false;
    }
		return true;
	}
	
	// keys : ','조합문자열, string[]
	function fc_isLstDupKey(chkObj, keys, bindKeyData) { 
		
		if(fc_isNull(chkObj) || fc_isNull(keys)){
			return false;
		}
		
		var keyArr = fc_getItemArr(keys);
    
    var chkDatas = chkObj.dataItems();
    
    var dupChkArr = fc_getKeyJoinArr(chkDatas, keys);
	
		if( bindKeyData ){
			var rowIndex = chkObj.select();
			var rowState = chkObj.getRowState(rowIndex);
			var excldIndex = rowIndex;
			var bindKeyJoinArr = fc_getKeyJoinArr(bindKeyData, keys);
			
			// slice
			dupChkArr.splice(excldIndex, 1);
			
			// push
			dupChkArr.push(...bindKeyJoinArr);
			// dupChkArr.concat(bindKeyJoinArr);
		}else{
			
		}
		
		// dupChk
		var isDup = dupChkArr.some(function(element){
			return dupChkArr.indexOf(element) != dupChkArr.lastIndexOf(element);
		});
		
		return isDup;
	}
	
	function fc_isParentDefined(parObj, dtlObj, keys) {
		var keyArr = fc_getIdArr(keys);
		var parRow = parObj.select();

    if (typeof parRow == 'undefined' || parRow == -1) {
      return false;
    }
    
    var parDataArr = dtlObj.getParentData();
		
		var parData = parDataArr[parRow];
		
		if(fc_isNull(parData)){
			return true;
		}
		
		// check parentData
		return keyArr.some(function (keyEle) {
			return fc_isNull(parData[keyEle]) == true;
		});
	}
	
	function fc_setGridParKey(parObj, dtlObj, keys) {
		var keyArr = fc_getIdArr(keys);
		var parRow = parObj.select();
	    if (typeof parRow == 'undefined' || parRow == -1) {
	      return false;
	    }
	    var parDataArr = dtlObj.getParentData();
		var parData = parDataArr[parRow];
		
		dtlObj.dataItems().forEach(function(elementObj, rowIndex){
			// console.log("elementObj.", rowIndex, "=>", elementObj);
			keyArr.forEach(function(keyEle, keyIndex){
				// console.log("keyEle=>", keyEle);
				// console.log("parData[keyEle]=>", parData[keyEle]);
				
				dtlObj.setCellValue(rowIndex, keyEle, parData[keyEle]);
			});
		});		
		
	}
	
	function fc_getMessage( msg, addMsg ) {
		var message = msg;
		
		for ( var loop = 1; loop < arguments.length; loop++ ) {
			var regExp1 = new RegExp( '\\{([' + loop + '])\\}', 'g' );
			message = message.replace( regExp1, arguments[ loop ] );
		};
		
		return message;
	};
	
	
	// end
	
	module.msg = message,
	
	module.util = {
		fc_getCodeDsMaps: function(fieldCds) {
			var fieldCdArr = fc_getIdArr(fieldCds);			
			
			var rsCodeDsMaps = [];
			fieldCdArr.forEach(function(element, index){
				codeDsMapArr.filter(function(item) {
					return item.field_cd == element;
				}).forEach(function(ele, idx){
					// console.log("ele:", ele);
					rsCodeDsMaps.push(ele);
				});
				
			});
			
			return rsCodeDsMaps;
		},
		fc_setCtrlReadonly: function(ctrlIds, flag) {
		  var self = fc_getPage();
		  var ctrlIdArr = fc_getIdArr(ctrlIds);		  
		  
		  ctrlIdArr.forEach(function(element, index){			
			self[element].readonly(flag);
		  });
		},
		fc_selectCheckedIndex: function(fcGrid) {
		  if ( !fc_isGrid(fcGrid) || fcGrid.options.checkBar.visible == false){
		  	return [];
		  }
			
		  var selIndex = fcGrid.select();
		  var checkArray = fcGrid.getCheckedIndex();
		  
		  // 체크건이 없어도 선택행이 있으면 선택행 체크적용
		  if (checkArray.length == 0 && selIndex != -1) {
			  fcGrid.setCheck(selIndex, true, false);
			  checkArray = fcGrid.getCheckedIndex();
		  }
		  
		  return checkArray;
		},
		
		fc_getMessage: fc_getMessage,
		fc_clearRows: fc_clearRows,
		fc_clearDs: fc_clearDs,
		fc_isParentSelected: fc_isParentSelected,
		fc_setGridParKey: fc_setGridParKey,
		fc_isParentDefined: fc_isParentDefined,
		fc_dispMsg: fc_dispMsg,
		fc_confirmNo: fc_confirmNo,
		fc_isLstDupKey: fc_isLstDupKey,
		fc_setBtnEnable: fc_setBtnEnable,
		
		fc_nvl: fc_nvl,
		fc_linkFiDocuNo: fc_linkFiDocuNo,
		fc_setLinkFiDocuMenuId: fc_setLinkFiDocuMenuId,
		fc_link: fc_link,
		fc_getIdArr: fc_getIdArr,
		fc_getItemArr: fc_getItemArr,
		fc_isNull: fc_isNull
	},
	
	module.api = {
		/***************************************************************************
     * @desc 공통코드(MA_CODEDTL)를 가져옵니다.
     * @param {String}
     *          module_cd - [필수]모듈코드
     * @param {String}
     *          field_cd_pipe - [필수]필드코드(multi)
     * @return {Array} 해당 모듈/필드의 데이터를 배열(파라미터 부족등의 오류시 빈 배열)
     * @ex var objCodeDtl_SD = scmJS.api.getCodeData('SD', 'C00010|C00020');
     *     ------------------------------------------------------------------------------------------
     */
		getCodeData: function(module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
		  var objCodeDtl = {};
		  syscode_yn = (syscode_yn != undefined ? syscode_yn : null);
		  base_yn    = (base_yn    != undefined ? base_yn    : null);
		  foreign_yn = (foreign_yn != undefined ? foreign_yn : null);
		  end_dt     = (end_dt     != undefined ? end_dt     : null);
		  keyword    = (keyword    != undefined ? keyword    : null);
		  if(!module_cd){
  			console.error("scmJS - getCodeData 함수의 'module_cd' 파라미터가 부족합니다.");
  			return [];
		  } else if(!field_cd_pipe){
  			console.error("scmJS - getCodeData 함수의 'field_cd_pipe' 파라미터가 부족합니다.");
  			return [];
		  } else{
  			$.each(field_cd_pipe.split("|"), function (i, v) {
  			  if (v != null && v != "") {
  			    objCodeDtl[v] = [];
  			  }
  			});
  			dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", dews.string.format("common_codeDtl_list")), {
  			  async: false,
  			  data: {
  				module_cd: module_cd, // 모듈
  				field_cd_pipe: field_cd_pipe,   // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
  				syscode_yn: syscode_yn,   // 시스템코드 유무(Y,N)
  				base_yn: base_yn,   // 디폴트 코드구분(Y,N)
  				foreign_yn: foreign_yn,   // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
  				end_dt: end_dt,   // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
  				keyword: keyword    // 검색할 코드 또는 명
  			  }
  			}).done(function (data) {
  			  if (data.length > 0) {
    				$.each(data, function (i, obj) {
    				  objCodeDtl[obj.FIELD_CD].push(obj);
    				  tmpCdField = obj.FIELD_CD;
    				});
  			  } else {
  			  }
  			}).fail(function (xhr, status, error) {
  			  dews.error(error + '\n' + message.fail.work);
  			});
  			return objCodeDtl;
		  }
		},
		getDocuMst: function(pc_cd, docu_no) {
		  var docuInfo = null;
      if(docu_no != null) {
        dews.api.get(dews.url.getApiUrl("FI","Glddoc00700Service","get_docuMst"),{
          async : false,
          data : {
            pc_cd : pc_cd,
            docu_no : docu_no
          }
        }).done(function(data) {
          if(data.length > 0) {
            docuInfo = data[0];
          }
        }).fail(function(xhr,status,error){
          dews.ui.snackbar.error(error);
        });
      }
      return docuInfo;
		},
		
		fc_getCodeData: function(dsMapArr, codeApi) {
		  var codeDataInfo = {};
		  if(fc_isNull(dsMapArr) || dsMapArr.length == 0){
		    return codeDataInfo;
		  }
		  
		  var modules = dsMapArr.map(function (item) {
			return item.module_cd;
		  });
		  modules = Array.from(new Set(modules));
		  
		  modules.forEach(function(element, index){
			  var fields = dsMapArr.filter(function (item) {
			  	return item.module_cd == element;
			  }).map(function (item) {
				return item.field_cd;
			  });
		
			  //codeDataInfo[element] = codeApi.getCodeData(element, fields.join('|'));
			  codeDataInfo[element] = module.api.getCodeData(element, fields.join('|'));
		  });

		  return codeDataInfo;
		},
		
		fc_createCodeDs: function(codeDsMapArr, codeData) {
		  codeDsMapArr.forEach(function (element, index) {
		    module.api.fc_createDs(element.ds_id, codeData[element.module_cd][element.field_cd]);
		  });
		},
		
		fc_createDsUseYn: function(dsId) {
		  var self = fc_getPage();
		  var createDsId = dsId || 'ds_use_yn';
		  var dsData = {
			  schema: {
			        model: {
			          fields: [
			            { field: 'SYSDEF_CD', type: 'string' }, 
			            { field: 'SYSDEF_NM', type: 'string' }, 
			            { field: 'SYSDEF_CN', type: 'string' },
			            { field: 'SYSDEF_NM2', type: 'string' }, 
			            { field: 'SYSDEF_CN2', type: 'string' }
			          ]
			        }
			      },
		      data: [
		      {
		        "SYSDEF_CD": "Y",
		        "SYSDEF_NM": "사용",
		        "SYSDEF_CN": "Y:사용",
		        "SYSDEF_NM2": "예",
		        "SYSDEF_CN2": "Y:예"
		      },
		      {
		        "SYSDEF_CD": "N",
		        "SYSDEF_NM": "미사용",
		        "SYSDEF_CN": "N:미사용",
		        "SYSDEF_NM2": "아니오",
		        "SYSDEF_CN2": "N:아니오"
		      }
		    ]
		  };		 
		  self[createDsId] = dews.ui.dataSource(createDsId, { data: dsData.data });
		},		
		
		fc_createDs: function(dsId, dsData) {
		  var self = fc_getPage();
		  self[dsId] = dews.ui.dataSource(dsId, { data: dsData });
		},
		
		fc_setCtrlDs: function(ctrlId, dsId, insTopItem) {
		  var self = fc_getPage();
		  if( insTopItem ){
  			self[dsId].insert(0, insTopItem);			
		  }
		  
		  self[ctrlId].setDataSource(self[dsId]);
		},
		
		fc_confirm: function(sgOpt, validOpt) {
      var self = fc_getPage();
      
      var confirmYn = sgOpt.confirmYn || 'Y';
      var confirmMsg = sgOpt.confirmMsg || message.action.confirmKeep;
      
      try {
        // valid
        if( !validOpt ){
          validOpt = {};
        }
        var validYn = validOpt.validYn || 'Y';
        var validPanelId = validOpt.id || 'condition_mst';
        var validTooltip = true;
        
        if( typeof validOpt.tooltip != 'undefined'){
          validTooltip = validOpt.tooltip;
        }
        var validMessage = validOpt.message || message.validate.required;
        
        if( validYn == 'Y' && self[validPanelId] && self[validPanelId].validate ){
          var validRs = self[validPanelId].validate({tooltip: validTooltip, message: validMessage});            
          if( !validRs ){
            return false; 
          }
        }
        
        if (confirmYn == 'Y') {
          dews.confirm(confirmMsg, 'question').yes(function () {
            if (fc_isFunction(sgOpt.yes)) {
              sgOpt.yes();
            }
          }).no(function () {
            if (fc_isFunction(sgOpt.no)) {
              sgOpt.no();
            } else {
              //dews.ui.snackbar.warning(message.action.canceled);
              fc_confirmNo();
              return false;
            }
          });
        } else {
          if (fc_isFunction(sgOpt.yes)) {
            sgOpt.yes();
          }
        }

      } catch (error) {
        console.log("fc_confirm.error:" + error);
        dews.error(error);
      }
    },
		
		fc_getData: function(sgOpt) {
		  var fc_moduleCd = sgOpt.moduleCd;
		  var fc_serviceName = sgOpt.serviceName;
		  var fc_servicePath = sgOpt.servicePath;
		  var fc_serviceData = sgOpt.serviceData;
		  
		  if (!fc_moduleCd || !fc_serviceName || !fc_servicePath) {
		    dews.alert(message.config.noServiceReq);
		    return false;
		  }
		  var f_callbackOk = sgOpt.callbackOk;
		  var f_callbackFail = sgOpt.callbackFail;
		  // console.log("f_callbackOk----->", f_callbackOk);
		  // console.log("f_callbackFail----->", f_callbackFail);
		  
		  try {
			  dews.api.get(dews.url.getApiUrl(fc_moduleCd, fc_serviceName, fc_servicePath), {
			    async: false,
			    data: fc_serviceData
			  }).done(function (data) {
			    console.log("done.data----->", data);
			    
			    sgOpt.dispMsgTp = "ok";
			    fc_dispMsg(sgOpt, {dispMsgFg: 'snackbar', dispMsg: message.action.inquiryCompleted});
			    
			    if (fc_isFunction(f_callbackOk)) {
  				  // console.log("call f_callbackOk!!!");
  				  f_callbackOk(data);
  				}
			  }).fail(function (xhr, status, error) {
			    fc_failError(error);
			    
			    if (fc_isFunction(f_callbackFail)) {
  				  // console.log("call f_callbackFail!!!");
  				  f_callbackFail(xhr, status, error);
  				}
			  }).always(function () {
				  
			  });

		  } catch (error) {
			console.log("fc_getData.error:", error);
			dews.error(error);
		  }
		},
		fc_postData: function(sgOpt) {
		  module.api.fc_saveReqData(sgOpt);
		},
		fc_deleteData: function(sgOpt) {
		  sgOpt.httpMethod = 'DELETE';
		  module.api.fc_saveReqData(sgOpt);
    },
    fc_putData: function(sgOpt) {
      sgOpt.httpMethod = 'PUT';
      module.api.fc_saveReqData(sgOpt);
    },
    fc_saveReqData: function(sgOpt) {
		  var fc_moduleCd = sgOpt.moduleCd;
		  var fc_serviceName = sgOpt.serviceName;
		  var fc_servicePath = sgOpt.servicePath;
		  var fc_serviceData = sgOpt.serviceData;
		  
		  if (!fc_moduleCd || !fc_serviceName || !fc_servicePath) {
  			dews.alert(message.config.noServiceReq);
  			return false;
		  }
		  var f_callbackOk = sgOpt.callbackOk;
		  var f_callbackFail = sgOpt.callbackFail;
		  // console.log("f_callbackOk----->", f_callbackOk);
		  // console.log("f_callbackFail----->", f_callbackFail);
		  
		  var reqApi = dews.api.post;
		  if( !fc_isNull(sgOpt.httpMethod)){
		    if(sgOpt.httpMethod == 'DELETE'){
		      reqApi = dews.api.delete;
		    }else if(sgOpt.httpMethod == 'PUT'){
		      reqApi = dews.api.put;
		    }
		  }		  
		  
		  try {
		    reqApi(dews.url.getApiUrl(fc_moduleCd, fc_serviceName, fc_servicePath), {
			    async: false,
			    data: fc_serviceData
			  }).done(function (data) {
			    console.log("done.data----->", data);
			    
			    sgOpt.dispMsgTp = "ok";
			    fc_dispMsg(sgOpt, {dispMsgFg: 'snackbar', dispMsg: message.action.requestCompleted});
			    
			    if (fc_isFunction(f_callbackOk)) {
  				  // console.log("call f_callbackOk!!!");
  				  f_callbackOk(data);
  				}			    
			  }).fail(function (xhr, status, error) {
  				console.log("fail", status, error);
  				  
  		    // sgOpt.dispMsgTp = "error";
  		    // sgOpt.dispMsg = error;
  		    // fc_dispMsg(sgOpt);
  				fc_failError(error);
			    
			    if (fc_isFunction(f_callbackFail)) {
  				  // console.log("call f_callbackFail!!!");
  				  f_callbackFail(xhr, status, error);
  				}
			  }).always(function () {
				  
			  });

		  } catch (error) {
  			console.log("fc_getData.error:", error);
  			dews.error(error);
		  }
		},
		
		fc_search: function(sgOpt, validOpt) {
		  var self = fc_getPage();
		  
		  var confirmYn = sgOpt.confirmYn || 'N';
		  var confirmMsg = sgOpt.confirmMsg || message.action.keep;
		  
		  try {
  			// valid
  			if( !validOpt ){
  				validOpt = {};
  			}
  			var validYn = validOpt.validYn || 'Y';
  			var validPanelId = validOpt.id || 'condition_mst';
  			var validTooltip = true;
  			
  			if( typeof validOpt.tooltip != 'undefined'){
  				validTooltip = validOpt.tooltip;
  			}
  			var validMessage = validOpt.message || message.validate.required;
  			
  			if( validYn == 'Y' && self[validPanelId] && self[validPanelId].validate ){
  				var validRs = self[validPanelId].validate({tooltip: validTooltip, message: validMessage});						
  				if( !validRs ){
  					return false;	
  				}
  			}
  			
  			if (confirmYn == 'Y') {
  			  dews.confirm(confirmMsg, 'question').yes(function () {
    				if (fc_isFunction(sgOpt.yes)) {
    				  sgOpt.yes();
    				} else {
    					module.api.fc_getData(sgOpt);
    				}
  			  }).no(function () {
    				if (fc_isFunction(sgOpt.no)) {
    				  sgOpt.no();
    				} else {
    				  //dews.ui.snackbar.warning(message.action.canceled);
    				  fc_confirmNo();
    				  return false;
    				}
  			  });
  			} else {
  			  if (fc_isFunction(sgOpt.yes)) {
  			    sgOpt.yes();
  			  } else {
  				  module.api.fc_getData(sgOpt);
  			  }
  			}
  			// dews.ui.loading.hide();

		  } catch (error) {
  			console.log("fc_searchGrid.error:" + error);
  			// dews.ui.loading.hide();
  			dews.error(error);
		  }
		},

		fc_save: function(sgOpt, validOpt) {
		  var self = fc_getPage();
		  
		  // var confirmYn = sgOpt.confirmYn || 'Y';
		  var confirmMsg = sgOpt.confirmMsg || message.action.save;

		  fc_logObj("fc_saveGrid.sgOpt", sgOpt);
		  try {
  			// valid
  			if( !validOpt ){
  				validOpt = {};
  			}
  			var validYn = validOpt.validYn || 'Y';
  			var validPanelId = validOpt.id;
  			var validTooltip = true;
  			
  			if( typeof validOpt.tooltip != 'undefined'){
  				validTooltip = validOpt.tooltip;
  			}
  			var validMessage = validOpt.message || message.validate.required; 
  			
  			if( validYn == 'Y' && self[validPanelId] && self[validPanelId].validate ){
  				var validRs = self[validPanelId].validate({tooltip: validTooltip, message: validMessage});						
  				if( !validRs ){
  					return false;	
  				}
  			}
  			
  			dews.confirm(confirmMsg, 'question').yes(function () {
  			  module.api.fc_postData(sgOpt);
  			}).no(function () {
  			  if (fc_isFunction(sgOpt.no)) {
  			    sgOpt.no();
  			  } else {
    				//dews.ui.snackbar.warning(message.action.canceled);
  			    fc_confirmNo();
    				return false;
  			  }
  			});

		  } catch (error) {
		    dews.error(error);
		  }
		},
    fc_delete: function(sgOpt, validOpt) {
      var self = fc_getPage();
      
      // var confirmYn = sgOpt.confirmYn || 'Y';
      var confirmMsg = sgOpt.confirmMsg || message.action.save;

      fc_logObj("fc_delete.sgOpt", sgOpt);
      try {
        // valid
        if( !validOpt ){
          validOpt = {};
        }
        var validYn = validOpt.validYn || 'Y';
        var validPanelId = validOpt.id;
        var validTooltip = true;
        
        if( typeof validOpt.tooltip != 'undefined'){
          validTooltip = validOpt.tooltip;
        }
        var validMessage = validOpt.message || message.validate.required; 
        
        if( validYn == 'Y' && self[validPanelId] && self[validPanelId].validate ){
          var validRs = self[validPanelId].validate({tooltip: validTooltip, message: validMessage});            
          if( !validRs ){
            return false; 
          }
        }
        
        dews.confirm(confirmMsg, 'question').yes(function () {
          module.api.fc_deleteData(sgOpt);
        }).no(function () {
          if (fc_isFunction(sgOpt.no)) {
            sgOpt.no();
          } else {
            //dews.ui.snackbar.warning(message.action.canceled);
            fc_confirmNo();
            return false;
          }
        });

      } catch (error) {
        dews.error(error);
      }
    },		
		
		fc_searchGrid: function(sgOpt, validOpt) {
		  var self = fc_getPage();
		  var gridId = sgOpt.id || 'grid_mst';
		  var fcGrid = self[gridId];
		  
		  var searchDs = fc_getObjDs(fcGrid);
		  
		  var confirmYn = sgOpt.confirmYn || 'N';
		  var confirmMsg = sgOpt.confirmMsg || message.action.keep;
		  
		  var f_callbackOk = sgOpt.callbackOk;
		  var f_callbackFail = sgOpt.callbackFail;
		  // console.log("f_callbackOk----->", f_callbackOk);
		  // console.log("f_callbackFail----->", f_callbackFail);
		  
		  fc_logObj("fc_searchGrid.fcGrid:", fcGrid);
		  fc_logObj("fc_searchGrid.sgOpt:", sgOpt);

		  try {
  			// valid
  			if( !validOpt ){
  				validOpt = {};
  			}
  			var validYn = validOpt.validYn || 'Y';
  			var validPanelId = validOpt.id || 'condition_mst';
  			var validTooltip = true;
  			
  			if( typeof validOpt.tooltip != 'undefined'){
  				validTooltip = validOpt.tooltip;
  			}
  			var validMessage = validOpt.message || message.validate.required;
  			
  			if( validYn == 'Y' && self[validPanelId] && self[validPanelId].validate ){
  				var validRs = self[validPanelId].validate({tooltip: validTooltip, message: validMessage});						
  				if( !validRs ){
  					return false;	
  				}
  			}
  			
  			if (confirmYn == 'Y') {
  			  dews.confirm(confirmMsg, 'question').yes(function () {
    				if (fc_isFunction(sgOpt.yes)) {
    				  sgOpt.yes();
    				} else {
    				  // dews.ui.loading.show({ type: 'tiny', text: '조회중입니다.' });
    				  searchDs.read().done(function() {
    				    sgOpt.dispMsgTp = "ok";
    				    fc_dispMsg(sgOpt, {dispMsgFg: 'snackbar', dispMsg: message.action.inquiryCompleted});
    				    
    				    if (fc_isFunction(f_callbackOk)) {
    				    	console.log("ds read....done f_callbackOk.data", searchDs.data());
    				    	f_callbackOk(searchDs.data());
    				    }
    				  }).fail(function() {
    				    console.log("ds read....fail....");
    				  }).always(function() {
    				  });
    				}
  			  }).no(function () {
    				if (fc_isFunction(sgOpt.no)) {
    				  sgOpt.no();
    				} else {
    				  //dews.ui.snackbar.warning(message.action.canceled);
    				  fc_confirmNo();
    				  return false;
    				}
  			  });
  			} else {
  			  if (fc_isFunction(sgOpt.yes)) {
  			    sgOpt.yes();
  			  } else {
  			    // dews.ui.loading.show({ type: 'tiny', text: '조회중입니다.' });
  			    searchDs.read().done(function() {
  				  
    				  sgOpt.dispMsgTp = "ok";
    				  fc_dispMsg(sgOpt, {dispMsgFg: 'snackbar', dispMsg: message.action.inquiryCompleted});
  				  
    				  if (fc_isFunction(f_callbackOk)) {
    				    console.log("ds read....done f_callbackOk.data", searchDs.data());
    					  f_callbackOk(searchDs.data());
    				  }
  			    }).fail(function() {
  			      console.log("ds read....fail....");
  			    }).always(function() {
  			    });				
  			  }
  			}
  			// dews.ui.loading.hide();

		  } catch (error) {
		    console.log("fc_searchGrid.error:" + error);
  			// dews.ui.loading.hide();
  			dews.error(error);
		  }
		},

		fc_removeRows: function(sgOpt) {
		  var self = fc_getPage();
		  var gridId = sgOpt.id || 'grid_mst';
		  var selectRowYn, checkedIndexYn;
		  
		  var fcGrid = self[gridId];
		  fc_logObj("fc_removeRows.fcGrid.options", fcGrid.options);
		  
		  if ( fc_isGrid(fcGrid) ){
			  if(fcGrid.options.checkBar.visible == true){
				  selectRowYn = 'N';
				  checkedIndexYn = sgOpt.checkedIndexYn || 'Y';
			  }else{
				  selectRowYn = sgOpt.selectRowYn || 'Y';
				  checkedIndexYn = 'N';
			  }
		  }else{
			  // card
			  selectRowYn = sgOpt.selectRowYn || 'Y';
			  checkedIndexYn = 'N';
		  }
		  
		  // checkRows/checkedIndex
		  var selIndex = fcGrid.select();
		  
		  if (selectRowYn == 'Y') {
  			if( selIndex != -1 && typeof selIndex != 'undefined'){
  				//grid, treegrid 구분처리
  				if (fc_isFunction(fcGrid.removeRow)) {
  				  fcGrid.removeRow(selIndex);
          }else if (fc_isFunction(fcGrid.remove)) {
            fcGrid.remove(selIndex);
          }
  				
  			}else{
  				dews.ui.snackbar.warning(message.validate.noSelectedRow, "warning");
  				return false;
  			}
			
		  }else if (checkedIndexYn == 'Y') {
    		// var checkArray = fcGrid.getCheckedRows();
    		var checkArray = fcGrid.getCheckedIndex();
    		
    		// 체크건이 없어도 선택행이 있으면 선택행 체크적용
    		if (checkArray.length == 0 && selIndex != -1) {
    			fcGrid.setCheck(selIndex, true, false);
    			checkArray = fcGrid.getCheckedIndex();
    		}
    		
    		if (checkArray.length == 0) {
    		  dews.ui.snackbar.warning(message.validate.noSelectedRow, "warning");
    		  return false;
    		} else {
    		  for (var idx = checkArray.length - 1; idx >= 0; idx--) {
    			  //grid, treegrid 구분처리
    			  if (fc_isFunction(fcGrid.removeRow)) {
              fcGrid.removeRow(checkArray[idx]);
            }else if (fc_isFunction(fcGrid.remove)) {
              fcGrid.remove(checkArray[idx]);
            }
    			  
    		  }
    		}
		  }
		  
		},

		// confirm chk & fc_removeRows
		fc_deleteRows: function(sgOpt) {
		  var confirmYn = sgOpt.confirmYn || 'Y';
		  var confirmMsg = sgOpt.confirmMsg || message.action.del;
		  var selectRowYn, checkedIndexYn;

		  if (confirmYn == 'Y') {
			  dews.confirm(confirmMsg, 'question').yes(function () {
  				if (fc_isFunction(sgOpt.yes)) {
  				  sgOpt.yes();
  				} else {
  				  module.api.fc_removeRows(sgOpt);
  				}
			  }).no(function () {
  				if (fc_isFunction(sgOpt.no)) {
  				  sgOpt.no();
  				} else {
  				  //dews.ui.snackbar.warning(message.action.canceled);
  				  fc_confirmNo();
  				  return false;
  				}
			  });
		  } else {
			  if (fc_isFunction(sgOpt.yes)) {
			    sgOpt.yes();
			  } else {
			    module.api.fc_removeRows(sgOpt);
			  }
		  }
		},

		fc_saveGrid: function(sgOpt) {
		  var self = fc_getPage();
		  var gridId = sgOpt.id || 'grid_mst';
		  var gridIdArr = fc_getIdArr(gridId);
		  var serviceDataKey = sgOpt.serviceDataKey;
		  
		  fc_logObj("fc_saveGrid.sgOpt", sgOpt);
		  fc_log("gridId----->", gridId);
		  fc_log("gridIdArr----->", gridIdArr);
		  
		  var fc_moduleCd = sgOpt.moduleCd;
		  var fc_serviceName = sgOpt.serviceName;
		  var fc_servicePath = sgOpt.servicePath;
		  var fc_serviceData = sgOpt.serviceData;
		  
		  if (!fc_moduleCd || !fc_serviceName || !fc_servicePath) {
  			dews.alert(message.config.noServiceReq);
  			return false;
		  }
		  
		  var validCheckYn = sgOpt.validCheckYn || 'Y';
		  var dirtyCheckYn = sgOpt.dirtyCheckYn || 'Y';
		  var confirmMsg = sgOpt.confirmMsg || message.action.save;

		  var f_callbackOk = sgOpt.callbackOk;
		  var f_callbackFail = sgOpt.callbackFail;
		  
		  // console.log("f_callbackOk----->" + f_callbackOk);
		  // console.log("f_callbackFail----->" + f_callbackFail);

		  try {
  			// validation
  			if (validCheckYn == 'Y') {
  			  var isNotValid = gridIdArr.some(function (element) {
  				  return fc_isFunction(self[element].validate) && self[element].validate().result == false;
  			  });
  			  // console.log("isNotValid----->" + isNotValid);
  			  if (isNotValid) {
  				  dews.alert(message.validate.required);
  				  return false;
  			  }
  				  
  			} else {
  				  //
  			}
  			  
  			// dirtyCheck
  			if (dirtyCheckYn == 'Y') {
  			  var isDirty = gridIdArr.some(function (element) {
  				  
  			    return fc_getObjDs(self[element]).getDirtyDataCount() != 0;
  			  });
  			  // console.log("isDirty----->" + isDirty);
  			  
  			  if (!isDirty) {
    				dews.alert(message.validate.noDataChanged);
    				return false;
  			  }
  			  /*
           * if (fc_getObjDs(self[gridId]).getDirtyDataCount() == 0) {
           * dews.alert(message.validate.noDataChanged); return false; }
           */
  			} else {
  			  //
  			}
  			
  			// dupCheck
  			var dupKeys = sgOpt.key;
  			if( dupKeys ){
  				console.log("dupCheck.dupKeys----->", dupKeys);
  				var dupKeyArr = fc_getIdArr(dupKeys);
  				if (gridIdArr.length != dupKeyArr.length) {
  				  dews.alert(message.validate.notEqualKey);
  				  return false;
  				}
  				
  				var dupTit = '';
  				var isDup = gridIdArr.some(function (element, eleIndex) {
  					dupTit = $("#"+element).data("title");
  					console.log("dupCheck.dupTit----->", dupTit);
  			    return fc_isLstDupKey(self[element], dupKeyArr[eleIndex]);
  				});
  				
  				if (isDup) {
  					dews.alert(message.validate.dupData + fc_getDtlTitle(dupTit));
  					return false;
  				}
  			}
  			
  			// serviceData
  			// serviceDataKey가 있는 경우 serviceDataKey기준으로 serviceData 생성
  			  if( serviceDataKey ){
  				  var serviceDataKeyArr = fc_getIdArr(serviceDataKey);
  				  var sData = {};
  				  
  				  if (gridIdArr.length != serviceDataKeyArr.length) {
  					  dews.alert(message.validate.notEqualDataKey);
  					  return false;
  				  }
  				  
  				  serviceDataKeyArr.forEach(function(element, keyIndex){
  					  
  					  var dsObj = fc_getObjDs(self[gridIdArr[keyIndex]]);
  					  
  					  sData[element] = JSON.stringify(dsObj.getDirtyData());
  				  });
  				  fc_serviceData = sData;
  				  
  			  }else{
  				  if( !fc_serviceData ){
  					  // console.log("set default fc_serviceData-----!!!");
  					  if( gridIdArr.length == 1 ){
  						  fc_serviceData = { gm_mst: JSON.stringify(fc_getObjDs(self[gridId]).getDirtyData()) };
  					  }
  				  }  
  			  }
  
  			dews.confirm(confirmMsg, 'question').yes(function () {
  			  dews.api.post(dews.url.getApiUrl(fc_moduleCd, fc_serviceName, fc_servicePath), {
    				async: false,
    				data: fc_serviceData,
  			  }).done(function (data) {
  				
  				sgOpt.dispMsgTp = "ok";
  			    fc_dispMsg(sgOpt, {dispMsgFg: 'snackbar', dispMsg: message.action.saveCompleted});
  
  				if (fc_isFunction(f_callbackOk)) {
  				  // console.log("call f_callbackOk!!!");
  				  f_callbackOk(data);
  				}
  
  			  }).fail(function (xhr, status, error) {
  				console.log("----->save.fail----->", xhr);
  				
  				fc_failError(error);
  
  				if (fc_isFunction(f_callbackFail)) {
  				  f_callbackFail(xhr, status, error);
  				}
  				
  			  }).always(function () {
  			  });
  			  
  			}).no(function () {
  			  if (fc_isFunction(sgOpt.no)) {
  			    sgOpt.no();
  			  } else {
  			    //dews.ui.snackbar.warning(message.action.canceled);
  			    fc_confirmNo();
  			    return false;
  			  }
  			});

		  } catch (error) {
  			console.log("fc_saveGrid.error----->", error);  
  			dews.error(error);
		  }
		},
		
		fc_dialogClose: function(sgOpt) {
		  var self = fc_getPage();
		  	
		  var confirmYn = sgOpt.confirmYn || 'Y';
		  var confirmMsg = sgOpt.confirmMsg || message.action.keep;
		  
		  var dsId = sgOpt.dsId;
		  
		  try {
  			if (confirmYn == 'Y') {
  			  if(!fc_isNull(dsId)){
  			    
  			    if (self[dsId].getDirtyDataCount() == 0) {
  			      if (fc_isFunction(sgOpt.yes)) {
                sgOpt.yes();
              }
  			    } else {
  			      dews.confirm(confirmMsg, 'question').yes(function () {
  			        if (fc_isFunction(sgOpt.yes)) {
  			          sgOpt.yes();
  			        } else {
  			        }
  			      }).no(function () {
  			        if (fc_isFunction(sgOpt.no)) {
  			          sgOpt.no();
  			        } else {
  			          //dews.ui.snackbar.warning(message.action.canceled);
  			          fc_confirmNo();
  			          return false;
  			        }
  			      });
  			    }
          }  			  
  			  
  			} else {
  			  if (fc_isFunction(sgOpt.yes)) {
  			    sgOpt.yes();
  			  }
  			}

		  } catch (error) {
  			console.log("fc_dialogClose.error:" + error);  			
  			dews.error(error);
		  }
		}
		
		// end
	}
	
	var newModule = {};
	newModule[moduleCode] = module;
	window.gerp = $.extend(true, gerp, newModule);
	// window.dews = $.extend(true, dews, module.api);
  
})(window.dews, window.gerp || {}, jQuery);
// # sourceURL=/js/PX/px.common.js