/*
 * @desc    IM 모듈 공통 함수
 * @path    /view/js/im.js
 */
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = "IM"; //모듈 코드

  class ImCodeValidationInfo {
    #PLANT_CD = {};
    #ITEM_CD = {};
    #SL_CD = {};
    #SECTION_CD = {};
    #BIN_CD = {};
    #UNIT_CD = {};
    #CC_CD = {};
    #INV_REASON_CD = {};
    #PARTNER_CD = {};

    setCodeInfo(code, codeKey, codeInfo){
      switch(code){
        case "PLANT_CD":
          if(this.#PLANT_CD[codeKey] == null)
            this.#PLANT_CD[codeKey] = codeInfo;
          break;
        case "PARTNER_CD":
          if(this.#PARTNER_CD[codeKey] == null)
            this.#PARTNER_CD[codeKey] = codeInfo;
          break;
        case "ITEM_CD":
          if(this.#ITEM_CD[codeKey] == null)
            this.#ITEM_CD[codeKey] = codeInfo;
          break;
        case "SL_CD":
          if(this.#SL_CD[codeKey] == null)
            this.#SL_CD[codeKey] = codeInfo;
          break;
        case "SECTION_CD":
          if(this.#SECTION_CD[codeKey] == null)
            this.#SECTION_CD[codeKey] = codeInfo;
          break;
        case "BIN_CD":
          if(this.#BIN_CD[codeKey] == null)
            this.#BIN_CD[codeKey] = codeInfo;
          break;
        case "UNIT_CD":
          if(this.#UNIT_CD[codeKey] == null)
            this.#UNIT_CD[codeKey] = codeInfo;
          break;
        case "CC_CD":
          if(this.#CC_CD[codeKey] == null)
            this.#CC_CD[codeKey] = codeInfo;
          break;
        case "INV_REASON_CD":
          if(this.#INV_REASON_CD[codeKey] == null)
            this.#INV_REASON_CD[codeKey] = codeInfo;
          break;
      }
    }

    getCodeInfo(code, codeKey){
      switch(code){
        case "PLANT_CD":
          return this.#PLANT_CD[codeKey];
          break;
        case "PARTNER_CD":
          return this.#PARTNER_CD[codeKey];
          break;
        case "ITEM_CD":
          return this.#ITEM_CD[codeKey];
          break;
        case "SL_CD":
          return this.#SL_CD[codeKey];
          break;
        case "SECTION_CD":
          return this.#SECTION_CD[codeKey];
          break;
        case "BIN_CD":
          return this.#BIN_CD[codeKey];
          break;
        case "UNIT_CD":
          return this.#UNIT_CD[codeKey];
          break;
        case "CC_CD":
          return this.#CC_CD[codeKey];
          break;
        case "INV_REASON_CD":
          return this.#INV_REASON_CD[codeKey];
          break;
      }
    }

  };

  module.codeValidationInfo = new ImCodeValidationInfo();

  module.enum = {
    // 입출고유형: MA-P01210
    inOutType : {
      IN : "1",
      OUT : "2",
      BOTH : "3"
    },
    // 마스터-재고실사상태: IM-P00060
    masterLineStatus : {
      PENDING: "1", //등록
      CONFIRM: "2", //확정
      RELEASE: "3", //발행
      INPUT: "4", //입력
      COMPLETE: "5", //완료
      CANCEL: "9" //취소
    },
    // 디테일-재고실사상태: IM-P00070
    detailLineStatus : {
      PENDING: "1", //등록
      CONFIRM: "2", //확정
      RELEASE: "3", //발행
      INPUT: "4", //입력
      COMPLETE: "5", //완료
      POSTING: "6", //전기
      RECYCLE: "7", //재실사
      CANCEL: "9" //취소
    },
  };

  //! 일반 공통 메소드
  module.com = {
    /*********************************************************************************************
     *  @desc  그리드 코드피커 옵션 세팅
     *  @param {object}  grid          그리드 컴포넌트
     *  @param {string}  field         세팅을 원하는 필드명
     *  @param {object}  reqOptions    세팅을 원하는 도움창 옵션 값
     *  @ex    imJs.com.setGridCodePickerEditor(grid, "BATCH_NO", gridOption);
     * ------------------------------------------------------------------------------------------*/
    setGridCodePickerEditor: function (grid, field, reqOptions) {
      if (!grid || !field) {
        throw "imJs - setGridCodePickerEditor 함수 인자가 부족합니다.";
      }

      var columnsIndex = -1;
      grid.options.columns.some(function(item, idx) {
        if(item.field === field) {
          columnsIndex = idx;
          return true;
        }
      });

      if (columnsIndex === -1) {
        throw "imJs - setGridCodePickerEditor 필드가 설정되지 않았습니다.";
      }

      var originCodeOptions = grid.options.columns[columnsIndex].codeOption;
      var newCodeOptions = $.extend({}, originCodeOptions, reqOptions);

      grid.options.columns[columnsIndex].codeOption = newCodeOptions;
    },

    getInvInstCdOption: function (inv_inst_tp_cd) {
      var pickerOptions = {
        custom: false,
        helpCustom: false,
        size: "largebig",
        helpSize: "largebig",
      };

      switch (inv_inst_tp_cd) {
        case "1":
          pickerOptions.codeField = "PARTNER_CD";
          pickerOptions.textField = "PARTNER_NM";
          pickerOptions.title = "구매 거래처 도움창";
          pickerOptions.helpTitle = "구매 거래처 도움창";
          pickerOptions.height = "550";
          pickerOptions.helpHeight = "550";
          pickerOptions.code = "H_PU_MA_PARTNERPU_INFO_S";
          pickerOptions.helpCode = "H_PU_MA_PARTNERPU_INFO_S";
          pickerOptions.apiUrl = "~/api/MA/MACustomCodeHelpService/H_PU_MA_PARTNERPU_INFO_S"
          break;
        case "2":
          pickerOptions.codeField = "SODOC_NO";
          pickerOptions.textField = "SODOC_NO";
          pickerOptions.title = "수주 조회 도움창";
          pickerOptions.helpTitle = "수주 조회 도움창";
          pickerOptions.width = "900";
          pickerOptions.helpWidth = "900";
          pickerOptions.height = "700";
          pickerOptions.helpHeight = "700";
          pickerOptions.code = "H_SD_SO_INFO_C";
          pickerOptions.helpCode = "H_SD_SO_INFO_C";
          pickerOptions.custom = true;
          pickerOptions.helpCustom = true;
          pickerOptions.viewUrl = "~/codehelp/SD/H_SD_SO_INFO_C";
          pickerOptions.helpViewUrl = "~/codehelp/SD/H_SD_SO_INFO_C";
          pickerOptions.helpParams = { flag: 2 };
          pickerOptions.apiUrl = "~/api/SD/SDCustomCodeHelpService/H_SD_SO_INFO_C_list_dtl"
          break;
        case "3":
          pickerOptions.codeField = "WBS_NO";
          pickerOptions.textField = "WBS_NM";
          pickerOptions.title = "WBS 도움창";
          pickerOptions.helpTitle = "WBS 도움창";
          pickerOptions.code = "H_PS_WBS_MST_C";
          pickerOptions.helpCode = "H_PS_WBS_MST_C";
          pickerOptions.custom = true;
          pickerOptions.helpCustom = true;
          pickerOptions.viewUrl = "~/codehelp/PS/H_PS_WBS_MST_C";
          pickerOptions.helpViewUrl = "~/codehelp/PS/H_PS_WBS_MST_C";
          pickerOptions.apiUrl = "~/api/PS/PSCustomCodeHelpService/H_PS_WBS_MST_C_search_list"
          break;
        case "4":
          pickerOptions.codeField = "PARTNER_CD";
          pickerOptions.textField = "PARTNER_NM";
          pickerOptions.title = "영업 거래처 도움창";
          pickerOptions.helpTitle = "영업 거래처 도움창";
          pickerOptions.height = "550";
          pickerOptions.helpHeight = "550";
          pickerOptions.code = "H_SD_MA_PARTNER_MST_S";
          pickerOptions.helpCode = "H_SD_MA_PARTNER_MST_S";
          pickerOptions.apiUrl = "~/api/MA/MACustomCodeHelpService/H_SD_MA_PARTNER_MST_S"
          break;
        default:
        // throw "잘못된 inv_inst_cd 입니다.";
      }
      return pickerOptions;
    },

    /*********************************************************************************************
     *  @desc  배치 시리얼 도움창 세팅 메소드
     *  @param {object}  io_tp          입출고 여부 (Obejct) -> "1": 입고, "2": 출고
     *  @param {string}  batch_use_yn   배치 사용 여부 (String) -> "Y": 사용, "N": 미사용
     *  @param {object}  ser_use_yn     시리얼 사용 여부 (String) -> "Y": 사용, "N": 미사용
     *  @ex    imJs.com.getBatchSerialOption(item.IO_TP, item.BATCH_USE_YN, item.SER_USE_YN)
     * ------------------------------------------------------------------------------------------*/
    getBatchSerialOption: function (io_tp, batch_use_yn, ser_use_yn) {
      let title, helpCode;
      let helpApiUrl = null;

      title = io_tp === "1" ? "입고" : "출고";
      title +=
        batch_use_yn === "Y"
          ? "배치정보"
          : ser_use_yn === "Y"
          ? "시리얼정보"
          : "";
      helpCode =
        batch_use_yn === "Y"
          ? "H_IM_BATCH"
          : ser_use_yn === "Y"
          ? "H_IM_SERIAL"
          : "";
      helpCode += io_tp === "1" ? "_RCPT_C" : "_ISS_C";

      switch(helpCode){
        case "H_IM_BATCH_RCPT_C" :
          helpApiUrl = dews.url.getApiUrl('IM', 'IMCustomCodeHelpService', helpCode);
        break;
      }

      let pickerOptions = {
        title: title,
        custom: true,
        size: "extra",
        code: helpCode,
        viewUrl: "/codehelp/IM/" + helpCode,
        apiUrl: helpApiUrl
      };

      if(helpApiUrl == null){
        delete pickerOptions.apiUrl;
      }

      return pickerOptions;
    },

    /*********************************************************************************************
     *  @desc  재고지시유형컨트롤과 재고지정컨트롤 이벤트 및 코드피커 동적세팅
     *  @param {object}  s_inv_inst_tp_cd     inv_inst_cd(재고지시유형) 컨트롤 객체
     *  @param {object}  s_inv_dsnt_cd        inv_dsnt_cd(재고지정) 컨트롤 객체
     *  @param {object}  s_inv_dsnt_sq        inv_inst_sq(재고지정순번) 컨트롤 객체
     *  @ex    imJs.com.setInvInstPickerEvent(self.s_inv_inst_tp_cd, self.s_inv_dsnt_cd, self.s_inv_dsnt_sq);
     * ------------------------------------------------------------------------------------------*/
    setInvInstPickerEvent: function (
      s_inv_inst_tp_cd,
      s_inv_dsnt_cd,
      s_inv_dsnt_sq
    ) {
      var that = this;

      if (!(s_inv_inst_tp_cd && s_inv_dsnt_cd)) {
        throw "setInvInstDialogEvent - 재고지정 Dialog 설정을 위해서는 s_inv_inst_tp_cd, s_inv_dsnt_cd 필요합니다.";
      }

      s_inv_inst_tp_cd.on("change", function () {
        var pickerOptions = that.getInvInstCdOption(s_inv_inst_tp_cd.value());
        s_inv_dsnt_cd.setOptions(pickerOptions);

        s_inv_dsnt_cd.readonly(!s_inv_inst_tp_cd.value());
        s_inv_dsnt_cd.clearData();
        if (s_inv_dsnt_sq) s_inv_dsnt_sq.reset();
      });

      s_inv_dsnt_cd.on("codedialog", function (e) {
        if (!s_inv_inst_tp_cd.value()) {
          dews.ui.tooltip.show(s_inv_inst_tp_cd, {
            type: "required",
          });
          e.preventDefault();
        }
      });

      s_inv_dsnt_cd.on("setData", function (e, data) {
        var helpCode = s_inv_dsnt_cd.options.helpCode;

        switch (helpCode) {
          case "H_SD_SO_INFO_C":
            if(s_inv_dsnt_sq) s_inv_dsnt_sq.text(data.SODOC_SQ);
            break;
          default:
            if(s_inv_dsnt_sq) s_inv_dsnt_sq.reset();
            break;
        }
      });
    },

    /*********************************************************************************************
     *  @desc  null 참조오류 우회처리
     *  @param {object}  func             null참조 발생여부 있는 값을 return하는 함수
     *  @param {object}  defaultValue     null참조 발생시 return시킬 값
     *  @ex    imJS.com.getSafe(function () { return e.row.isChange }, false);
     * ------------------------------------------------------------------------------------------*/
    getSafe: function (func, defaultValue) {
      try {
        return func();
      } catch (e) {
        return defaultValue;
      }
    },

    /*********************************************************************************************
     *  @desc  grid 내 모든 Row 제거 (setDetail로 묶인 child 포함)
     *  @param {object}  grid     모든 Row를 제거할 grid 객체
     *  @ex    imJS.com.clearGrid(self.dtlGrid);
     *  @check 연관관계 depth 1까지만 lineDataSource 포함하여 삭제됨.
     * ------------------------------------------------------------------------------------------*/
    clearGrid: function (grid) {
      if (!grid) {
        throw "imJs - clearGrid 함수 인자가 부족합니다.";
      }

      //! 해당 방식도 DirtyData가 남는 방식이라 read를 처리해야하는데 호환성 보고 처리할것.
      grid.dataSource.data([]);
      // grid.dataSource.read();

      //! 하단 방식은 DirtyData가 남는 방식이라 상단 방식으로 변경(일단 백업)
      // var gridRowIndexs = Array.apply(null, Array(grid.dataItems().length)).map(
      //   function (_, i) {
      //     return i;
      //   }
      // );

      // grid.removeRow(gridRowIndexs);
    },

    /*********************************************************************************************
     *  @desc  수불처리시 에러리스트 팝업 호출
     *  @param {list}  errorList     백단에서 응답받은 errorList
     *  @ex    imJs.com.openTransErrorDialog(xhr.responseJSON.error);
     * ------------------------------------------------------------------------------------------*/
    openTransErrorDialog: function (errorList) {
      if (!Array.isArray(errorList)) {
        throw "imJs - openTransErrorDialog 리스트 타입의 인자가 아닙니다.";
      }

      var dialog = dews.ui.dialog("H_IM_INVTRX_ERROR_C", {
        url: "/codehelp/IM/H_IM_INVTRX_ERROR_C",
        title: "수불처리 오류내역",
        buttons: "close",
        width: "1000",
        height: "600",
      });

      dialog.setInitData(errorList);
      dialog.open();
    },

    /*********************************************************************************************
     *  @desc  그리드 내 해당위치에 tooltip 띄워주는 기능
     *  @param {object}  targetGrid     툴팁을 띄울 그리드 객체
     *  @param {string}  columnName     툴팁을 띄울 컬럼명
     *  @param {number}  index          툴팁을 띄울 컬럼의 인덱스
     *  @param {string}  message        (option)툴팁에 띄울 메시지
     *  @ex    imJs.com.popGridTooltip(self.mstGrid, "BATCH_NO", 0);
     *         imJs.com.popGridTooltip(self.mstGrid, "BATCH_NO", 0, "입력해주세요.");
     *  @check 메시지 입력하지 않을경우 '필수값입니다' 메시지로 팝업.
     * ------------------------------------------------------------------------------------------*/
    popGridTooltip: function(targetGrid, columnName, index, message) {
      if (!targetGrid || !columnName || !index) {
        throw "imJs - popGridTooltip 함수 필수 인자가 부족합니다.";
      }

      targetGrid.showTooltip(index, columnName, {
        type: "normal",
        text: message || "필수값입니다.",
        position: "top",
        durationTime: 500,
        fadeOutTime: 2000
      });
    },

    /*********************************************************************************************
     *  @desc  grid 내 특정 컬럼의 중복 여부 판단
     *  @param {object}  grid             중복을 판단할 그리드 객체
     *  @param {string}  reqColumnName    중복여부를 판단할 컬럼명
     *  @param {string}  reqColumnValue   (option)중복 여부를 판단할 값(해당 컬럼에서 해당 값이 중복인지만 찾아옴)
     *  @ex    imJs.com.isDuplicate(self.dtlGrid, "PLANT_CD");
     *         imJs.com.isDuplicate(self.dtlGrid, "PLANT_CD", "1000");
     *  @check 현재 화면에 보이는 그리드의 데이터로만 중복 조회함(dirtyData나 mst-dtl구조 현재는 미지원)
     * ------------------------------------------------------------------------------------------*/
    isDuplicate: function (grid, reqColumnName, reqColumnValue) {
      if (!grid || !reqColumnName) {
        throw "imJs - isDuplicate 함수 필수 인자가 부족합니다.";
      }

      var columnValues = grid.dataItems()
        .map(function (row, index) {
          return grid.getCellValue(index, reqColumnName);
        });

      if(reqColumnValue == null) {
        return columnValues.some(function (columnValue) {
          return columnValues.indexOf(columnValue) !== columnValues.lastIndexOf(columnValue);
        });
      } else {
        return columnValues.some(function (columnValue) {
          return reqColumnValue === columnValue
          ? columnValues.indexOf(columnValue) !== columnValues.lastIndexOf(columnValue)
          : false;
        });
      }

    },
    /*********************************************************************************************
     *  @desc  Y/N 사용여부 데이터소스 return
     *  @param {boolean} blankFlag    공백 포함 여부
     * ------------------------------------------------------------------------------------------*/
    getYnDataSource: function(blankFlag){
      let data = [
        {SYSDEF_CD: "Y", SYSDEF_NM: "Yes"},
        {SYSDEF_CD: "N", SYSDEF_NM: "No"}
      ];
      if(blankFlag){
        data.unshift({SYSDEF_CD: "", SYSDEF_NM: ""});
      }
      let ynDataSource = dews.ui.dataSource("ynDataSource", { data: data });
      return ynDataSource;
    }
  };

  //! 서버사용 공통 메소드
  module.api = {
    /* --------------------------------------------------------------------------------------------
    *  @desc                 공통 세팅데이터 조회
    *  @author               김준일 (kji6649)
    *  @ex                   imApi.getXmlData({P_XML_ID: "get_MA_PARTNERPU_INFO", P_PURORG_CD: "1000", P_PARTNER_CD: "2000001001"})
    * --------------------------------------------------------------------------------------------
    *  params                파라미터 오브젝트
        P_XML_ID             P_XML_ID (필수)
    * --------------------------------------------------------------------------------------------
    *  @return               List<Map<String, Object>>, Exception
    *  @수정
    * ------------------------------------------------------------------------------------------*/
    getXmlData: function (obj) {
      var returnVr = null;
      if (obj && obj.P_XML_ID) {
        dews.api
          .post(dews.url.getApiUrl("IM", "ImCommonService", "getXmlData"), {
            async: false,
            data: {
              params: JSON.stringify(obj),
            },
          })
          .done(function (data) {
            returnVr = data;
          })
          .fail(function (xhr, status, error) {
            dews.error(error);
          });
      }
      return returnVr;
    },

    /**
     * ma.scm.js - getStdUnitQt 사용 권장, 더 이상 호출하지 말 것
     */
    getChangeUnitQt: function (item_cd, ord_rsv_qt, ord_unit_cd, std_unit_cd) {
      let convertedQt = null;
      if(item_cd && ord_rsv_qt && ord_unit_cd && std_unit_cd){
        dews.api.get(dews.url.getApiUrl("IM", "ImCommonService", "getChanged_Unit_Qt"), {
          async: false,
          data: {
            item_cd: item_cd,
            qt_source: ord_rsv_qt,
            cd_unit_source: ord_unit_cd,
            cd_unit_target: std_unit_cd,
          },
        }).done(function (resConvertedQt) {
          convertedQt = resConvertedQt;
        }).fail(function (xhr, status, error) {
          dews.error(error);
        });
      }

      return convertedQt;
    },

    /* --------------------------------------------------------------------------------------------
     *  @desc                 공장별, 품목별, 저장위치별 기본 섹션, 빈 데이터 조회
     *  @author               하지연 (ha930118)
     *  @ex                   imJs.api.getDefaultSectionBinData(plant_cd, item_cd, sl_cd)
     *  @return               List<ImCommon_SECTIONBIN>
     *  @수정
     * ------------------------------------------------------------------------------------------*/
    getDefaultSectionBinData: function (plant_cd, item_cd, sl_cd) {
      var defaultSectionBinData = {};

      dews.api
        .get(dews.url.getApiUrl("IM", "ImCommonService", "getDefaultSectionBinData"), {
          async: false,
          data: {
            plant_cd: plant_cd,
            item_cd: item_cd,
            sl_cd: sl_cd,
          },
        })
        .done(function (resDefaultSectionBinData) {
          defaultSectionBinData = resDefaultSectionBinData;
        })
        .fail(function (xhr, status, error) {
          dews.error(error);
        });

      return defaultSectionBinData;
    },
    /* --------------------------------------------------------------------------------------------
 *  @desc                 회사별 특정 수불유형에 해당하는 수불유형코드, 수불구분, 입출고유형, 주포스팅 코드, 재고증감여부 등
                          수불유형, 입고수불유형, 취소수불유형 관련 데이터 조회
 *  @author               하지연 (ha930118)
 *  @ex                   imJs.api.getTransactionType(invtrx_tp_cd)
 *  @return               <ImCommon_TransactionType>
 *  @수정
 * ------------------------------------------------------------------------------------------*/
    getTransactionType: function (invtrx_tp_cd) {
      var transactionTypeData;

      dews.api.get(dews.url.getApiUrl("IM", "ImCommonService", "transactiontype"), {
          async: false,
          data: {
            invtrx_tp_cd: invtrx_tp_cd
          },
        })
        .done(function (resTransactionTypeData) {
          transactionTypeData = resTransactionTypeData;
        })
        .fail(function (xhr, status, error) {
          dews.error(error);
        });

      return transactionTypeData || {};
    },

    /* --------------------------------------------------------------------------------------------
    *  @desc                 회사별 특정 수불유형에 해당하는 재고지시유형 리스트 조회
    *  @author               이민현 (devmin)
    *  @ex                   imJs.api.getInvInstCodes(invtrx_tp_cd, hasEmpty)
    *  @params               invtrx_tp_cd(options) - 값이 없을 경우 모든 데이터 조회
    *                        hasEmpty(options)     -  true: 빈값 포함하여 리스트 반환
    *  @return               List<ImCommon_CodeDetail>
    * ------------------------------------------------------------------------------------------*/
    getInvInstCodes: function (hasEmpty, invtrx_tp_cd) {
      var invInstCds;

      dews.api.get(dews.url.getApiUrl("IM", "ImCommonCodeListService", "inv_inst_cds"), {
          async: false,
          data: {
            invtrx_tp_cd: invtrx_tp_cd,
            hasEmpty : hasEmpty,
          },
        })
        .done(function (resInvInstCds) {
          invInstCds = resInvInstCds;
        })
        .fail(function (xhr, status, error) {
          dews.error(error);
        });

      return invInstCds;
    },
    /* --------------------------------------------------------------------------------------------
    *  @desc                 회사별 특정 수불유형에 해당하는 재고사유 리스트 조회
    *  @author               이민현 (devmin)
    *  @ex                   imJs.api.getInvRsnInstCodes(invtrx_tp_cd)
    *  @params               invtrx_tp_cd(options) - 값이 없을 경우 모든 데이터 조회
    *                        hasEmpty(options)     - true: 빈값 포함하여 리스트 반환
    *  @return               List<ImCommon_CodeDetail>
    * ------------------------------------------------------------------------------------------*/
    getInvRsnInstCodes: function(hasEmpty, invtrx_tp_cd) {
      var invRsnInstCds;

      dews.api.get(dews.url.getApiUrl("IM", "ImCommonCodeListService", "invrsn_inst_cds"), {
          async: false,
          data: {
            invtrx_tp_cd: invtrx_tp_cd,
            hasEmpty : hasEmpty,
          },
        })
        .done(function (resInvRsnInstCds) {
          invRsnInstCds = resInvRsnInstCds;
        })
        .fail(function (xhr, status, error) {
          dews.error(error);
        });

      return invRsnInstCds;
    },
    /*********************************************************************************************
    *  @desc  예산 다이얼로그를 오픈한다
    *  @param {Object} data    예산 데이터 오픈시 필요한 정보
    *  @ex    puJS.openBudgetMsgDialog(data);
    *         data = {company_cd : 'test',
                      bmData     : resultBmApiData }
              resultBmApiData -> 예산 결과 데이터
    *********************************************************************************************/
   openBudgetMsgDialog : function (data){
    dialog = dews.ui.dialog("H_PU_BUDGET_C",
      {
        url: "/codehelp/PU/H_PU_BUDGET_C",
        title: "예산 오류",
      });
      dialog.setInitData(data);
      dialog.open();
    },
    /*********************************************************************************************
     *  @desc   재고공통예산체크 (pu.js 기반으로 동일)
     *  @param  {Array} chkList 예산체크 대상 List [{BGACCT_CD, BUDGET_CD, BIZPLAN_CD, BUDGET_DT, BOOK_AMT}]
     *  @return bool
     *  @ex     module.api.bmProfitCheck([{BGACCT_CD, BUDGET_CD, BIZPLAN_CD, BUDGET_DT, BOOK_AMT}, .....]]);
    *********************************************************************************************/
    bmProfitCheck : function(chkList){
      var bRtn = true;
      var IM00003 = module.api.getMaCtrlConfig("IM","IM00003");
      if(IM00003 == "Y"){
        if(!chkList || chkList.length < 1){
          bRtn = false;
          dews.ui.snackbar.warning("예산체크 대상이 존재하지 않습니다.");
        }else{
          dews.api.post(dews.url.getApiUrl('PU', 'PuCommonService', 'PuCommonBmProfitCheck'), {
            async: false,
            data : {
              chkList: JSON.stringify(chkList)
            }
          }).done(function(data) {
            if(data.length > 0) {
              bRtn = false;
              dews.ui.loading.hide();
              if(data[0].RESULT == "exception"){
                dews.alert("예산체크중 시스템 오류가 발생했습니다.", {icon: "error"});
              }else{
                module.api.openBudgetMsgDialog({bmData : data});
              }
            }
          }).fail(function(xhr,status, error) {
            dews.ui.loading.hide();
            dews.error(error);
            bRtn = false;
          });
        }
      }
      return bRtn;
    },
    /*********************************************************************************************
     *  @desc   재고공통예산체크 (pu.js 기반으로 동일)
     *  @param  {Array} chkList 예산체크 대상 List [{BGACCT_CD, BUDGET_CD, BIZPLAN_CD, BUDGET_DT, BOOK_AMT}]
     *  @return bool
     *  @ex     module.api.bmProfitCheck([{BGACCT_CD, BUDGET_CD, BIZPLAN_CD, BUDGET_DT, BOOK_AMT}, .....]]);
    *********************************************************************************************/
     getPlant_Pc_Cd : function(plant_cd){
      let pc_cd = "";
      dews.api.get(dews.url.getApiUrl('IM', 'ImCommonService', 'getPlant_Pc_Cd'), {
        async: false,
        data : {
          plant_cd: plant_cd
        }
      }).done(function(data) {
        pc_cd = data;
      }).fail(function(xhr,status, error) {
        dews.error(error);
      });
      return pc_cd;
    },
    /*********************************************************************************************
     *  @desc   uid 생성
     *  @param
     *  @return string
     *  @ex     module.api.guid()
    *********************************************************************************************/
    guid : function () {
      return 'xxxxxxxx-xxxx-4xxx-9xxx-xxxxxxxxxxxx'.replace(/[xy]/g,
      function (c) {
          var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
      });
    },

    getCodeValidationInfo : function(targetCode, validateCode, rowData, std_dt) {
      let resultData = {};
      let plant_cd = rowData?.PLANT_CD;
      std_dt = std_dt==null?dews.date.format(new Date(), "yyyyMMdd"):std_dt;
      let apiUrl = null, apiParameter = {}, codeKey = "";

      if(!targetCode || !validateCode){
        return resultData;
      }

      switch(targetCode){
        case "PLANT_CD":
          codeKey = targetCode;
          apiUrl = dews.url.getApiUrl("CM", "codehelp/CodeHelpDataService", "H_MA_PLANT_MST_S");
          apiParameter = {};
          break;
        case "PARTNER_CD":
          codeKey = targetCode;
          apiParameter = {
            use_yn: "Y"
          };
          apiUrl = dews.url.getApiUrl("CM", "codehelp/CodeHelpDataService", "H_MA_PARTNER_MST_S");
          break;
        case "ITEM_CD":
          codeKey = targetCode+"|"+plant_cd;
          apiParameter = {
            plant_cd: plant_cd,
            invtrx_yn: "Y",
            use_yn: "Y",
            pagingStart: 0,
            pagingCount: 999999
          };
          if(plant_cd != null){
            apiUrl = dews.url.getApiUrl("MA", "MACustomCodeHelpService", "MA_PITEM_MST_C_list");
          }
          break;
        case "BATCH_NO":
          codeKey = targetCode+"|"+rowData.ITEM_CD+"|"+rowData.BATCH_STD_CD;
          apiParameter = {
            item_cd: rowData.ITEM_CD,
            batch_std_cd: rowData.BATCH_STD_CD,
            class_def_cd: "",
            class_tp: "",
            batch_no: validateCode,
            gubun: "MST"
          };
          if(rowData.ITEM_CD!=null && rowData.BATCH_STD_CD!=null){
            apiUrl = dews.url.getApiUrl("IM", "IMCustomCodeHelpService", "H_IM_BATCH_INFO_C");
          }
          break;
        case "SL_CD":
          codeKey = targetCode+"|"+plant_cd;
          apiParameter = {
            plant_cd: plant_cd,
            use_yn: "Y"
          };
          if(plant_cd!=null){
            apiUrl = dews.url.getApiUrl("CM", "codehelp/CodeHelpDataService", "H_MA_SL_INFO_S");
          }
          break;
        case "SECTION_CD":
          codeKey = targetCode+"|"+plant_cd+"|"+rowData.STRGTP_CD;
          apiParameter = {
            plant_cd: plant_cd,
            strgtp_cd: rowData.STRGTP_CD,
            section_cd: "",
            standard_dt: std_dt,
            gubun_cd: "MST"
          };
          if(plant_cd!=null && rowData.STRGTP_CD!=null){
            apiUrl = dews.url.getApiUrl("IM", "IMCustomCodeHelpService", "H_IM_SECTIONBIN_C_list");
          }
          break;
        case "BIN_CD":
          codeKey = targetCode+"|"+plant_cd+"|"+rowData.STRGTP_CD+"|"+rowData.SECTION_CD;
          apiParameter = {
            plant_cd: plant_cd,
            strgtp_cd: rowData.STRGTP_CD,
            section_cd: rowData.SECTION_CD,
            standard_dt: std_dt,
            gubun_cd: "DTL"
          };
          if(plant_cd!=null && rowData.STRGTP_CD!=null && rowData.SECTION_CD!=null){
            apiUrl = dews.url.getApiUrl("IM", "IMCustomCodeHelpService", "H_IM_SECTIONBIN_C_list");
          }
          break;
        case "UNIT_CD" :
          codeKey = targetCode+"|"+rowData.ITEM_CD;
          apiParameter = {
            item_cd: rowData.ITEM_CD
          };
          if(rowData.ITEM_CD!=null){
            apiUrl = dews.url.getApiUrl("CM", "codehelp/CodeHelpDataService", "H_MA_ITEMCNV_INFO_S");
          }
          break;
        case "CC_CD":
          codeKey = targetCode+"|"+plant_cd;
          apiParameter = {
            plant_cd: plant_cd
          };
          if(plant_cd!=null){
            apiUrl = dews.url.getApiUrl("CM", "codehelp/CodeHelpDataService", "H_MA_CC_MST_S");
          }
          break;
      }

      if(apiUrl != null && module.codeValidationInfo.getCodeInfo(targetCode, codeKey) == null){
        dews.api.get(apiUrl, {
          async: false, data: apiParameter
        }).done(function (data) {
          if (data) {
            module.codeValidationInfo.setCodeInfo(targetCode, codeKey, data);
          }
        }).fail(function (xhr, status, error) {
          dews.error(error);
        });
      }

      resultData = module.codeValidationInfo.getCodeInfo(targetCode, codeKey)?.find(function(item) { return item[targetCode] == validateCode}) || {};
      return resultData;
    }
  };

  module.set = {};

  module.polyFill = (function () {
    // https://tc39.github.io/ecma262/#sec-array.prototype.includes
    if (!Array.prototype.includes) {
      Object.defineProperty(Array.prototype, "includes", {
        value: function (searchElement, fromIndex) {
          if (this == null) {
            throw new TypeError('"this" is null or not defined');
          }

          // 1. Let O be ? ToObject(this value).
          var o = Object(this);

          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;

          // 3. If len is 0, return false.
          if (len === 0) {
            return false;
          }

          // 4. Let n be ? ToInteger(fromIndex).
          //    (If fromIndex is undefined, this step produces the value 0.)
          var n = fromIndex | 0;

          // 5. If n ≥ 0, then
          //  a. Let k be n.
          // 6. Else n < 0,
          //  a. Let k be len + n.
          //  b. If k < 0, let k be 0.
          var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

          function sameValueZero(x, y) {
            return (
              x === y ||
              (typeof x === "number" &&
                typeof y === "number" &&
                isNaN(x) &&
                isNaN(y))
            );
          }

          // 7. Repeat, while k < len
          while (k < len) {
            // a. Let elementK be the result of ? Get(O, ! ToString(k)).
            // b. If SameValueZero(searchElement, elementK) is true, return true.
            if (sameValueZero(o[k], searchElement)) {
              return true;
            }
            // c. Increase k by 1.
            k++;
          }

          // 8. Return false
          return false;
        },
      });
    }
  })();

  /*********************************************************************************************
   *  @desc  js파일 상속
   *  @param {Object} targetJS [필수] js 객체 변수
   *  @ex
   * ------------------------------------------------------------------------------------------*/
  module.extendJS = function (targetJS) {
    $.each(Object.keys(targetJS), function (idx, key) {
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
       겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function (idx, kName) {
        if (keyArr.indexOf(kName) >= 0) {
          console.error(
            "js 상속중 동일한 메소드 명이 존재합니다 - ",
            key + "." + kName
          );
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  };
  console.log("*** IM Module Script Loaded ***");

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  dews.ajax
    .script("~/view/js/MA/ma.scm.js", {
      once: true,
      async: false,
    })
    .done(function () {
      module.extendJS(gerp.MA);
    });


  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=/js/IM/im.js
