/*
 * @desc    IM 모듈 GroupWare 공통
 * @date    2021.10.21
 * @path    /view/js/im.gw.common.js
 */

(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'IM_GW';

  dews.ajax.script('~/view/js/HR/hr.gw.util.js', {
    once: true,
    async: false
  });

  let ma_cm_js;
  dews.ajax.script('~/view/js/MA/ma.cm.js', {
    once: true,
    async: false
  }).done(function () {
    ma_cm_js = gerp.MA;
  });

  module.gw = {
    GroupWareStore : function (dewself) {
      var store = new Map();
      var gw_properties = {};
      // 그룹웨어 설정여부
      let gwConfigSettings = {
        MA00037 : ma_cm_js.CODE.getMaCtrlConfig("MA", "MA00037"),
        PU00007 : ma_cm_js.CODE.getMaCtrlConfig("PU", "PU00007"),
        PU00011 : ma_cm_js.CODE.getMaCtrlConfig("PU", "PU00011"),
        IM00001 : ma_cm_js.CODE.getMaCtrlConfig("IM", "IM00001"),
        IM00005 : ma_cm_js.CODE.getMaCtrlConfig("IM", "IM00005"),
        SD00021 : ma_cm_js.CODE.getMaCtrlConfig("SD", "SD00021")
      };

      // 재고요청처리 수불유형 별 설정 가져오기
      let rsvAhtzConfig = {};
      dews.api.get(dews.url.getApiUrl("IM", "ImCommonGwService", "getListRsvAthzInfo"), {
        async: false,
        data: {
          returnType:"map"
        }
      }).done(function (data){
        if(data.length > 0){
          rsvAhtzConfig = data[0];
        }
      });

      // GroupWare Properties 가져오기
      dews.ajax.script('~/view/js/IM/im.gw.properties.js', {
        once: true,
        async: false
      }).done(function () {
        if(gerp.IM_GW_PROPERTIES){
          gw_properties = gerp.IM_GW_PROPERTIES.gw;
          formId_properties = gerp.IM_GW_PROPERTIES.formId;
        }
      });

      var api = {
        private : {
          setup : function(formInfo){
            var property = gw_properties[dewself.mainEnv.drsCode] || gw_properties["package"];

            /* GW구분
             * 0:사용안함  1:bizbox  2:기타  3:전자결재
            */
            if(gwConfigSettings["MA00037"] == "1") {
              // formInfo : FORM_ID, GW_FORM_ID, GW_PROC_CD
              property = $.extend({}, property, formInfo);
            }

            /* formId별 설정 */
            if(formId_properties[property.FORM_ID]){
              var formId_property = formId_properties[property.FORM_ID][dewself.mainEnv.drsCode] || formId_properties[property.FORM_ID].package;
              if(formId_property){
                property = $.extend({}, property, formId_property);
                if(!property.gwServerUrl){
                  property.gwServerUrl =  gerp.CM.EltrAthzUtil.getApprovalUrl(property.url_type);
                }
                store.set(formInfo.FORM_ID, this.extendsAttr(property));
              }
            }
          },
          extendsAttr : function(property) {
            return {
              getProperty : function(){
                return property;
              },
              getHtmlContents : function(paramData){
                var htmlContents = null;

                dews.api.post(property.contents_url, {
                  async: false,
                  data: {
                    paramData : JSON.stringify(paramData)
                  }
                }).done(function (data) {
                  if(data != null)
                    htmlContents = data;
                });

                return htmlContents;
              },
              /**
               * 전자결재 신청
               * @param {object} paramData 전자결재 신청을 위한 파라미터, 아래 sample 참고
               * paramData = {
               *   table_key_value : targetTable의 key값 배열  ex) ["1st_key_value", "2nd_key_value", "3rd_key_value"] (company_cd는 생략) : 필수
               *   mstGridData : self.mstGrid.dataItem(i) // 그리드 데이터, htmlContents 생성 시 사용, key는 임의대로 명명 가능
               *   dtlGridData : self.dtlGrid.dataItems()
               * }
               */
              approval : function(paramData) {
                var that = this;
                dews.ui.loading.show({
                  text : dews.localize.get("결재신청 진행중입니다.", "M0011658", "")
                });

                // GW_FORM_ID 체크
                if(!property.GW_FORM_ID){
                  dews.ui.loading.hide();
                  dews.ui.snackbar.error(dews.localize.get("전자결재양식등록에 등록되지 않은 서식 ID입니다.", '', '', ''));
                  return false;
                }

                // htmlContents 조회 및 체크
                var htmlContents = that.getHtmlContents(paramData);
                if(!htmlContents){
                  dews.ui.loading.hide();
                  dews.ui.snackbar.error(dews.localize.get("서식이 등록되어있지 않습니다.", '', '', ''));
                  return false;
                }

                dews.api.post(dews.url.getApiUrl("IM", "ImCommonGwService", "approval"), {
                  async: false,
                  data: {
                    menu_id         : dewself.menu.id,
                    table_nm        : property.athz_rpts_table_nm,
                    gw_form_id      : property.GW_FORM_ID,
                    table_key_value : JSON.stringify(paramData.table_key_value),
                    htmlContents    : htmlContents,
                    postProcess_url : property.postProcess_url,
                    module_cd       : property.module_cd,
                    title           : JSON.stringify(property.title)
                  }
                }).done(function(res){
                  if(res && res.error_type == null) {
                    that.openView({
                      mode : "W",
                      athz_rpts_cd : res.data[0].ATHZ_RPTS_CD,
                      loginId : res.aes_key,
                      title: res.title
                    });
                    dews.ui.snackbar.ok(dews.localize.get("결재신청 되었습니다.", '', '', ''));
                  }else{
                    dews.ui.snackbar.error(error);
                  }
                }).fail(function (xhr, status, error) {
                  dews.ui.snackbar.error(error);
                }).always(function(){
                  dews.ui.loading.hide();
                });

              },
              /**
               * 전자결재 openView
               * @param {object} data 전자결재 window Open을 위한 파라미터, 아래 sample 참고
               * data = {
               *  athz_rpts_cd  : 전자결재코드
               *  mode          : V(view모드) or W(상신모드-approval에서 사용) : 생략 시 V모드
               * }
               */
              openView : function(data){
                if(!data.loginId){
                  data.loginId = gerp.CM.EltrAthzUtil.getBizBoxLoginId();
                }
                if(!data.mode){
                  data.mode = "V";
                }

                gerp.CM.EltrAthzUtil.createEltrAthz(property.gwServerUrl, {
                  params : {
                    compSeq : dewself.user.companyCode
                    ,approKey : data.athz_rpts_cd
                    ,outProcessCode : property.GW_PROC_CD
                    ,formId : property.GW_FORM_ID
                    ,mod : data.mode
                    ,contentsType : "inner"
                    ,contentsStr: ""
                    ,loginId : data.loginId
                    ,widthYn : true
                    ,title : data.title
                    ,contentsEnc : "U"
                    ,contentsType:"outer"
                  },
                  close : function() {
                    property.gwWindow_close_event();
                  }
                });

              }
            };
          }
        },
        public : {
          get : function(menuid) {
            return store.get(menuid);
          },
          /**
           * 전자결재 설정여부 체크
           * @param {string} ctrl_cd 회사환경설정등록의 통제코드
           * @param {object} param 회사환경설정등록 외 추가적인 설정확인이 필요할 때 사용할 추가파라미터
           * @returns {bool} 전자결재 사용설정 여부 return
           */
          isScmApprovalSetting : function(ctrl_cd, param){
            let result = false;
            if(gwConfigSettings["MA00037"] != "0" && gwConfigSettings[ctrl_cd] == "Y"){
              result = true;
            }

            // 재고요청처리일 경우 재고요청별G/W상신여부설정의 수불유형 설정 체크
            if(result && ctrl_cd=="IM00001"){
              if(param == null){
                return false;
              }else if(rsvAhtzConfig[param.invtrx_tp_cd] == "Y"){
                return true;
              }else{
                return false;
              }
            }
            return result;
          }
        }
      }

      // 전자결재양식등록에 있는 해당 메뉴 서식ID 리스트
      var formInfoList = null;
      dews.api.get(dews.url.getApiUrl("IM", "ImCommonGwService", "getListFormId"), {
        async: false,
        data: {
          menuId : dewself.menu.id
        }
      }).done(function (data){
        formInfoList = data;
      });

      // 전자결재 설정 setup
      if(formInfoList != null){
        $.each(formInfoList, function(idx, item){
          api.private.setup(item);
        });
      }

      return api.public;
    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/IM/im.gw.common.js
