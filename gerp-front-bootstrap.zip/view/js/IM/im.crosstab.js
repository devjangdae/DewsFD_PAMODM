(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'IM';  //모듈 코드

  module.param = {
    HEADERFIELD_CD : null,
    HEADERFIELD_NM : null,
    REPEATFIELD_CD : null
  },

  module.userfunction = {
    makeHeader: function(count, header_fields, dynamic_fields)
    {

      for( var c = header_fields.length - 1 ; c = 0 ; c--)
      {
        $.each(dynamic_fields, function(i, dynamic_field) {

          var fields = dynamic_field.field.split('&&');
          var titles = dynamic_field.title.split('&&');

          if ( c == 0){
            set_default_col.push(
              {
                field : fields[c],
                title : titles[c],
                //align : 'right',
                width : 120,
                visible : false,
                //formats : format_field
              }
            );
          }
          else if ( c + 1 == header_fields.length ){
            set_default_col.push(
              {
                field : dynamic_field.field,
                title : dynamic_field.field,
                align : 'right',
                width : 120,
                visible : true,
                formats : format_field
              }
            );
          }
          else{
            set_default_col.push(
              {
                field : fields[c],
                title : titles[c],
                align : 'right',
                width : 120,
                visible : true,
                formats : format_field
              }
            );
          }

          if( count + 1 == dynamic_fields.length)
            set_default_fields.push({field : HEADERFIELD_CD});

          this.makeHeader(cross_files);

        });
      }
    }

  },

  //------------------------------------------Start------------------------------------------
  //
  //API
  module.api = {

      /* --------------------------------------------------------------------------------------------
      *  @no
      *  @desc                 크로스탭 공통함수
      *  @ex                   makeCrosstab: function ( grid, gridDataSource, data, change_fields, default_columns, repeat_fields)
      *  @memo
      * --------------------------------------------------------------------------------------------
      *  grid                  화면 그리드
      *  gridDataSource        화면 데이터 소스
      *  data                  크로스탭 변환전 데이터
      *  change_fields         크로스탭 고정 컬럼들
      *  default_columns       크로스탭 변환되지 않는 컬럼들
      *  repeatColumns         크로스탭 변환할 값을 가진 컬럼들
      *  footerOptions         크로스탭 변환 컬럼의 footer 설정 - key : repeat_fields.type (QT ..)
      *                        ex) {QT:{type:"sum", predefined: true, format: 'MA00001'}}
      * --------------------------------------------------------------------------------------------
      *  @return
      *  @수정+++
      * ------------------------------------------------------------------------------------------*/
    makeCrosstab_Header_New : function ( gridDataSource, data, header_fields, default_columns, repeat_fields, footerOptions) {
      if(gridDataSource.data().length > 0)
        gridDataSource.data([]);

      var data_columns= [];
      var grid_columns = [];
      //var grid_columns = default_columns;

      var dynamic_fields = [];
      var format_field;
      let align = "left";
      var old_field = '';
      var new_field = '';
      var footer_option = null;

      // 두개 이상발생 했을 때 추가 개발할 예정. 확정성을 위해 오프젝트로 개발.

      switch(repeat_fields[0]['type'])
      {
        case 'QT':
          format_field = { type: 'number', predefined: true, format: 'MA00001', negativeColor:true };
          footer_option = footerOptions == null ? null : footerOptions["QT"];
          align = "right";
          break;
      }

      $.each(default_columns, function(i, default_column) {
        var copy = default_column.constructor();
        for( var column in default_column )
          copy[column] = default_column[column];
        grid_columns.push(copy);
      });

      makeDefaultField( default_columns);
      // dataset 컬럼 생성하기 위한 재귀함수
      function makeDefaultField (columns) {
        $.each(columns, function(i, column) {
          data_columns.push( {field :  column['field']} )
          if( column.columns != undefined)
            makeDefaultField( column.columns )
        });
      };


      if(data && data.length > 0){

      const map = new Map();
      // 헤더리스트 얻기
      for( var key in data[0])
      {
        if( key.split('##').length <= 1)
          continue;

        var headers = key.split('##');

        dynamic_fields.push({
          field: headers[0],
          title: headers[1]
        });
      }

      // 멀티헤더 컬럼 오름차순, 내리차순으로 순서 만들기.
      $.each(header_fields, function (h, header_field) {

        dynamic_fields.sort(function(a, b) { // 오름차순
          var compare_a = '';
          var compare_b = '';
          var new_a = '';
          var new_b = '';
          if ( h == 0 )
          {
            compare_a = a.field;
            compare_b = b.field;
          }
          else
          {
            var fields_a = a.field.split('&&');
            var fields_b = b.field.split('&&');

            for( var f = 0   ; f < header_fields.length - h  ; f++ )
            {
              new_a = new_a == '' ? fields_a[f] : new_a + '&&' + fields_a[f];
              new_b = new_b == '' ? fields_b[f] : new_b + '&&' + fields_b[f];
            }
            if(new_a == new_b )
            {
              compare_a = fields_a;
              compare_b = fields_b;
            }
            else
            {
              compare_a = '';
              compare_b = '';
            }
          }

          var result = 0;
          if (header_field.sort == 'DESC')
            result = compare_a < compare_b ? 1 : compare_a > compare_b ? -1 : 0;
          else
            result = compare_a < compare_b ? -1 : compare_a > compare_b ? 1 : 0;

          return result;
        });
      });

      var new_parent_field = '';
      var field = '';
      var default_col = {};
      var child_default_cols = {};

      old_field = '';
      new_field = '';
      for( var h = header_fields.length - 1  ; h >= 0 ; h-- )
      {
        default_col= {};
        old_field = '';
        new_parent = false;

        var cnt_obj = 0;
        //for( var d = 0 ; d < dynamic_fields.length ; d++ )
        $.each(dynamic_fields, function (d, dynamic_field) {
          new_parent_field = '';
          new_parent_title = '';
          new_field = '';

          var fields = dynamic_field.field.split('&&');
          var titles = dynamic_field.title.split('&&');
          // parent header 필드 정보 만들기
          for( var f = 0   ; f < h  ; f++ )
          {
            new_parent_field = new_parent_field == '' ? fields[f] : new_parent_field + '&&' + fields[f];
            new_parent_title = titles[header_fields.length - h - 1 ];
          }

          // this header 필드 정보 만들기(풀네임)
          var isUse = true;
          for( var f = 0 ; f < h + 1 ; f++ )
          {
            if ( fields[f] == null || fields[f] == '' || fields[f] == ' ' ){
              isUse = false;
            }

            new_field = new_field == '' ? fields[f] : new_field + '&&' + fields[f];
            new_title = titles[h];
          }
          if( isUse == false ){
            return true;
          }

          if( new_parent_field =='' )
          {
            new_parent_field = 'top';
            new_parent_title = 'top';
          }

          switch(new_title)
          {
            case '수량':
            case '단가':
            case '금액':
              format_field = { type: 'number', predefined: true, format: 'MA00001', negativeColor:true };
              align = "right";
              break;
          }

          if ( old_field != new_field )
          {
            if ( default_col[new_parent_field] == null )
              default_col[new_parent_field] = [];
            if ( h == header_fields.length - 1 )
            {
              // 가장 아래 헤더 컬럼 만들기
              default_col[new_parent_field].push(
                {
                  field : new_field,
                  title : new_title,
                  align : align,
                  width : 120,
                  //editor : format_field,
                  formats : format_field,
                  footer : footer_option
                });

                data_columns.push({field : new_field});
            }
            else
            {
              // 가장 아래 헤더 이외에 컬럼 만들기
              default_col[new_parent_field].push(
                {
                  //align : 'center',
                  background : '#656668',
                  width : 150,
                  //fieldName : undefined,
                  //fillHeight: 32,
                  //fixedHeight : 32,
                  //minHeight: 32,
                  //multicolumnHeight: {},
                  name: new_field,
                  title : new_title,
                  //editable : false,
                  //type : 'group',
                  columns : []
                });

            }
            if( h < header_fields.length - 1 )//&& d > 0 )
            {
              default_col[new_parent_field][cnt_obj].columns = child_default_cols[new_field];
              cnt_obj++;
            }
            old_field = new_field;
            old_parent_field = new_parent_field;
          }
        });
        child_default_cols = default_col;

      }

      $.each(child_default_cols, function (i, child) {
        for( var aa = 0 ; aa < child.length ; aa++ )
        {
          grid_columns.push(child[aa]);
        }
      });

      var result = [];
      result.push(data_columns, grid_columns);

      return result;
    }
    },

    makeCrosstab_Header : function ( grid, gridDataSource, data, header_fields, group_fields, default_columns, repeat_fields) {

      gridDataSource.data([]);

      var set_default_fields= [];
      var set_default_col = default_columns;
      var new_dataSource;
      var add_field, add_title;

      var dynamic_fields = [];
      var boolChanged = false;
      var format_field;

      // 두개 이상발생 했을 때 추가 개발할 예정. 확정성을 위해 오프젝트로 개발.
      var REPEATFIELD_CD = repeat_fields[0].repeatfield_cd;
      var REPEATFIELD_TP = repeat_fields[0].repeatfield_tp;
      var HEADERFIELD_CD = '';
      var HEADERFIELD_NM = '';

      switch(REPEATFIELD_TP)
      {
        case 'QT':
          format_field = { type: 'number', predefined: true, format: 'MA00001', negativeColor:true };
          break;
      }

      $.each(default_columns, function(i, default_column) {
        set_default_fields.push( {field :  default_column['field']} )
      });

      if(data && data.length > 0){

      const map = new Map();
      // 헤더리스트 얻기
      for( var key in data[0])
      {
        if( key.split('##').length <= 1)
          continue;

        var headers = key.split('##');

        dynamic_fields.push({
          field: headers[0],
          title: headers[1]
        });
      }
      dynamic_fields.sort(function(a, b) { // 오름차순
          return a.field < b.field ? -1 : a.field > b.field ? 1 : 0;
      });

      var new_parent_field = '';
      var field = '';
      var old_field = '';
      var new_field = '';
      var default_col = {};
      var child_default_cols = {};
      //for( var h = 0 ; h < header_fields.length ; h++ )
      for( var h = header_fields.length - 1  ; h >= 0 ; h-- )
      {
        default_col= {};
        old_field = '';
        new_parent = false;

        var cnt_obj = 0;
        for( var d = 0 ; d < dynamic_fields.length ; d++ )
        {
          new_parent_field = '';
          new_parent_title = '';

          var fields = dynamic_fields[d].field.split('&&');
          var titles = dynamic_fields[d].title.split('&&');
          // parent header 필드 정보 만들기
          for( var f = 0   ; f < h  ; f++ )
          {
            new_parent_field = new_parent_field == '' ? fields[f] : new_parent_field + '&&' + fields[f];
            new_parent_title = titles[header_fields.length - h - 1 ];
          }

          // this header 필드 정보 만들기(풀네임)
          for( var f = 0 ; f < h + 1 ; f++ )
          {
            new_field = new_field == '' ? fields[f] : new_field + '&&' + fields[f];
            new_title = titles[h];
          }
          if( new_parent_field =='' )
          {
            new_parent_field = 'top';
            new_parent_title = 'top';
          }

          if ( old_field != new_field )
          {
            if ( default_col[new_parent_field] == null )
              default_col[new_parent_field] = [];
            if ( h == header_fields.length - 1 )
            {
              default_col[new_parent_field].push(
                {
                  field : new_field,
                  title : new_title,
                  align : 'right',
                  width : 120,
                  //visible : true,
                  formats : format_field//,
                  //editable : true
                });

              set_default_fields.push({field : new_field});
            }
            else
            {
              default_col[new_parent_field].push(
                {
                  align : 'center',
                  background : '#656668',
                  fieldName : undefined,
                  fillHeight: 32,
                  fixedHeight : 32,
                  minHeight: 32,
                  multicolumnHeight: {},
                  name: new_field,
                  title : new_title ,
                  //width : 400,
                  editable : false,
                  type : 'group',
                  columns : []//child_default_cols == 'undefined' || child_default_cols[old_field] == 'undefined' ? [] : child_default_cols[old_field][0]
                });

            }
            if( h < header_fields.length - 1 )//&& d > 0 )
            {
              default_col[new_parent_field][cnt_obj].columns = child_default_cols[new_field];
              cnt_obj++;
            }
            old_field = new_field;
            old_parent_field = new_parent_field;
          }
          parent_field = '';
          new_field = '';
        }
        child_default_cols = default_col;

      }

      var master = [];
      $.each(child_default_cols, function (i, child) {
        for( var aa = 0 ; aa < child.length ; aa++ )
        {
          set_default_col.push(child[aa]);
        }
      });
      gridDataSource.setFields(set_default_fields);

      //return set_default_col;
      grid.setColumns(set_default_col);

      gridDataSource.data(data);
      grid.setDataSource(gridDataSource);
      grid.refresh();

      set_default_col = [];
    }
    },


    makeCrosstab_multi : function ( grid, gridDataSource, data, header_fields, group_fields, default_columns, repeat_fields, sum_fields) {

      gridDataSource.data([]);

      var set_default_fields= [];
      var set_default_col = [];//default_columns.constructor();
      var new_dataSource;
      var add_field, add_title;

      var dynamic_fields = [];
      var boolChanged = false;
      var format_field;

      //var HEADERFIELD_CD = gerp.IM.param.HEADERFIELD_CD;
      //var HEADERFIELD_NM = gerp.IM.param.HEADERFIELD_NM;
      // 두개 이상발생 했을 때 추가 개발할 예정. 확정성을 위해 오프젝트로 개발.
      var REPEATFIELD_CD = repeat_fields[0].repeatfield_cd;
      var REPEATFIELD_TP = repeat_fields[0].repeatfield_tp;
      var HEADERFIELD_CD = '';
      var HEADERFIELD_NM = '';

      var boolSum = false;
      if( sum_fields != undefined && sum_fields.length > 0)
        boolSum = true;

      var alignType = REPEATFIELD_TP ? 'right' : 'left';

      switch(REPEATFIELD_TP)
      {
        case 'QT':
          format_field = { type: 'number', predefined: true, format: 'MA00001', negativeColor:true };
          break;
      }

      $.each(default_columns, function(i, default_column) {
        set_default_fields.push( {field :  default_column['field']} )

        var copy = default_column.constructor();
        for( var column in default_column )
          copy[column] = default_column[column];
        set_default_col.push(copy);
      });

      if(data && data.length > 0){

      const map = new Map();
      // 헤더리스트 얻기
      $.each(data, function (idx, item) {
          for( var c = 0 ; c < header_fields.length ; c++ )
          {
            HEADERFIELD_CD = HEADERFIELD_CD == '' ? item[header_fields[c]['field']] : HEADERFIELD_CD + '&&' + item[header_fields[c]['field']];
            HEADERFIELD_NM = HEADERFIELD_NM == '' ? item[header_fields[c]['title']] : HEADERFIELD_NM + '&&' + item[header_fields[c]['title']];
          }
          if(!map.has(HEADERFIELD_CD)){
              map.set(HEADERFIELD_CD, true);    // set any value to Map
              dynamic_fields.push({
                field: HEADERFIELD_CD,
                title: HEADERFIELD_NM
              });
          }
          HEADERFIELD_CD = '';
          HEADERFIELD_NM = '';
        });

      var parent = [];
      var new_parent = false;
      var parent_default_col = [];
      var new_parent_field = '', new_parent_title = '';
      var old_parent_field = '', old_parent_title = '';
      var field = '', title = '';
      var old_field = '';
      var new_field = '';
      var default_col = {};
      var child_default_cols = {};
      var default_colsss = [];
      for( var h = 0 ; h < header_fields.length ; h++ )
      {
        default_col= {};
        old_field = '';
        new_parent = false;

        var cnt_obj = 0;
        for( var d = 0 ; d < dynamic_fields.length ; d++ )
        {
          new_parent_field = '';
          new_parent_title = '';

          var fields = dynamic_fields[d].field.split('&&');
          var titles = dynamic_fields[d].title.split('&&');
          // parent header 필드 정보 만들기
          for( var f = header_fields.length - 1  ; f > h    ; f-- )
          {
            new_parent_field = new_parent_field == '' ? fields[f] : new_parent_field + '&&' + fields[f];
            new_parent_title = titles[h];
          }

          // this header 필드 정보 만들기(풀네임)
          for( var f = h ; f < header_fields.length  ; f++ )
          {
            new_field = new_field == '' ? fields[f] : new_field + '&&' + fields[f];
            new_title = titles[h];
          }
          if( new_parent_field =='' )
          {
            new_parent_field = 'top';
            new_parent_title = 'top';
          }

          if ( old_field != new_field )
          {
            if ( default_col[new_parent_field] == null )
              default_col[new_parent_field] = [];
            if ( h == 0 )
            {
              default_col[new_parent_field].push(
                {
                  field : new_field,
                  title : new_title,
                  align : alignType,
                  width : 120,
                  visible : true,
                  formats : format_field//,
                  //editable : true
                });

              set_default_fields.push({field : new_field});
            }
            else
            {
              default_col[new_parent_field].push(
                {
                  align : 'center',
                  background : '#656668',
                  fieldName : undefined,
                  fillHeight: 32,
                  fixedHeight : 32,
                  minHeight: 32,
                  multicolumnHeight: {},
                  name: new_field,
                  title : new_title ,
                  //width : 400,
                  editable : false,
                  type : 'group',
                  columns : []//child_default_cols == 'undefined' || child_default_cols[old_field] == 'undefined' ? [] : child_default_cols[old_field][0]
                });

            }
            if( h > 0 )//&& d > 0 )
            {
              default_col[new_parent_field][cnt_obj].columns = child_default_cols[new_field];
              cnt_obj++;
            }
            old_field = new_field;
            old_parent_field = new_parent_field;
          }
          parent_field = '';
          new_field = '';
        }
        child_default_cols = default_col;

      }

      var master = [];
      $.each(child_default_cols, function (i, child) {
        for( var aa = 0 ; aa < child.length ; aa++ )
        {
          set_default_col.push(child[aa]);
        }
      });
      gridDataSource.setFields(set_default_fields);
      grid.setColumns(set_default_col);
      grid.refresh();

      set_default_col = [];



      //데이터셋변경 --start
      var grid_idx = 0;
      var tmp_value = JSON.parse(JSON.stringify(group_fields));
      var newItem = {};
      var sumValue = 0.0;
      add_field = '';

      for(var i=0; i<data.length; i++){

        add_field = '';
        for( var c = 0 ; c < header_fields.length ; c++ )
          add_field = add_field == '' ? data[i][header_fields[c].field] : add_field + '&&' + data[i][header_fields[c].field];
        for ( var cnt = 0 ; cnt < group_fields.length ; cnt++)
        {
          if (tmp_value[cnt].field == data[i][group_fields[cnt].field])
            boolChanged = false;
          else
          {
            boolChanged = true;
            break;
          }
        }

          if ( boolChanged )  {
            // dataSource에 row데이터 추가.
            if ( newItem != undefined && newItem[group_fields[0].field] != undefined )
            {
              if ( boolSum)
              {
                for( var c = 0 ; c < sum_fields[0].SUM_COLUMNS.length ; c++)
                  sumValue = sumValue + (newItem[sum_fields[0].SUM_COLUMNS[c].COLUMN] || 0);
                newItem[sum_fields[0].TARGET_COLUMN] = sumValue;
                sumValue = 0.0;
              }
              gridDataSource.add(newItem);
              newItem = {};
            }

            // default value 그리드에 넣기
            $.each(default_columns, function(idx, default_column) {
                if( default_column.hasOwnProperty('field') && default_column.field.indexOf('UID') < 0 )
                {
                  newItem[default_column.field] = data[i][default_column.field];
                }
            });

            // 키값 변경.
            for ( var cnt = 0 ; cnt < group_fields.length ; cnt++)
              tmp_value[cnt].field = data[i][group_fields[cnt].field];
          }
          // crosstab value 그리드에 넣기
          if (data[i][REPEATFIELD_CD] == 0 || data[i][REPEATFIELD_CD] == '0' || data[i][REPEATFIELD_CD] === 0 || data[i][REPEATFIELD_CD] ==='0') {
            newItem[add_field] = '';
          } else {
            newItem[add_field] = data[i][REPEATFIELD_CD];
          }
        }
        if ( boolSum)
        {
          for( var c = 0 ; c < sum_fields[0].SUM_COLUMNS.length ; c++)
            sumValue = sumValue + (newItem[sum_fields[0].SUM_COLUMNS[c].COLUMN] || 0);
          newItem[sum_fields[0].TARGET_COLUMN] = sumValue;
        }
        gridDataSource.add(newItem);
        grid.setDataSource(gridDataSource);
        dews.ui.loading.hide();
        //데이터그리드변경 --end

        if (grid.dataItems().length > 0) {
          var options = { fields: [group_fields[0].field], value: grid.dataItems(0)[group_fields[0].field], startIndex: 0 };
          grid.searchCell(options);
          grid.select(0);
        }
        else{
          dews.error(dews.localize.get("조회된 저장위치가 없습니다.",'M0001413'));
        }
      }
      dews.ui.loading.hide();
    }

/*
    makeCrosstab: function ( grid, gridDataSource, data, change_fields, default_columns, repeat_fields, sum_fields) {

      gridDataSource.data([]);

      var set_default_fields= [];
      var set_default_col = default_columns;
      var new_dataSource;
      var add_field, add_title;

      var cross_fields = [];
      var boolChanged = false;
      var format_field;

      var HEADERFIELD_CD = gerp.IM.param.HEADERFIELD_CD;
      var HEADERFIELD_NM = gerp.IM.param.HEADERFIELD_NM;
      // 두개 이상발생 했을 때 추가 개발할 예정. 확정성을 위해 오프젝트로 개발.
      var REPEATFIELD_CD = repeat_fields[0].REPEATFIELD_CD;
      var REPEATFIELD_TP = repeat_fields[0].REPEATFIELD_TP;

      var boolSum = false;
      if( sum_fields != undefined && sum_fields.length > 0)
        boolSum = true;

      switch(REPEATFIELD_TP)
      {
        case 'QT':
          format_field = { type: 'number', predefined: true, format: 'MA00001' };
          break;
      }

      $.each(default_columns, function(i, default_column) {
        set_default_fields.push( {field :  default_column['field']} )
      });

      if(data && data.length > 0){

      const map = new Map();
      $.each(data, function (idx, item) {
            if(!map.has(item[HEADERFIELD_CD])){
                map.set(item[HEADERFIELD_CD], true);    // set any value to Map
                cross_fields.push({
                  field: item[HEADERFIELD_CD],
                  title: item[HEADERFIELD_NM]
                });
            }
        });

      //데이터헤더변경 -- start
      for(var i =0; i<cross_fields.length; i++){
          add_field = cross_fields[i].field;
          add_title = cross_fields[i].title;

          set_default_col.push(
            {
              field : add_field,
              title : add_title,
              align : 'right',
              width : 120,
              visible : true,
              formats : format_field
            }
          );
          set_default_fields.push({field : add_field});
      }
      gridDataSource.setFields(set_default_fields);
      grid.setColumns(set_default_col);
      grid.refresh();
      //데이터헤더변경 -- end

      //데이터그리드변경 --start
      var grid_idx = 0;
      var tmp_value = JSON.parse(JSON.stringify(change_fields));
      var newItem = {};
      var sumValue = Number("0.0");

      for(var i=0; i<data.length; i++){
          add_field = data[i][HEADERFIELD_CD];

          for ( var cnt = 0 ; cnt < change_fields.length ; cnt++)
          {
            if (tmp_value[cnt].field == data[i][change_fields[cnt].field])
              boolChanged = false;
            else
            {
              boolChanged = true;
              break;
            }
          }

          if ( boolChanged )  {
            // dataSource에 row데이터 추가.
            if ( newItem != undefined && newItem[change_fields[0].field] != undefined )
            {
              if ( boolSum)
              {
                for( var c = 0 ; c < sum_fields[0].SUM_COLUMNS.length ; c++)
                  sumValue = sumValue + (Number(newItem[sum_fields[0].SUM_COLUMNS[c].COLUMN]) || 0);
                newItem[sum_fields[0].TARGET_COLUMN] = sumValue;
                sumValue = 0.0;
              }
              gridDataSource.add(newItem);
              newItem = {};
            }

            // default value 그리드에 넣기
            $.each(default_columns, function(idx, default_column) {
                if( default_column.field !='__UUID')
                {
                  newItem[default_column.field] = data[i][default_column.field];
                }
            });

            // 키값 변경.
            for ( var cnt = 0 ; cnt < change_fields.length ; cnt++)
              tmp_value[cnt].field = data[i][change_fields[cnt].field];
          }
          // crosstab value 그리드에 넣기
          if (data[i][REPEATFIELD_CD] == 0 || data[i][REPEATFIELD_CD] == '0' || data[i][REPEATFIELD_CD] === 0 || data[i][REPEATFIELD_CD] ==='0') {
            newItem[add_field] = '';
          } else {
            newItem[add_field] = data[i][REPEATFIELD_CD];
          }
        }
        if ( boolSum)
        {
          for( var c = 0 ; c < sum_fields[0].SUM_COLUMNS.length ; c++)
            sumValue = sumValue + (Number(newItem[sum_fields[0].SUM_COLUMNS[c].COLUMN]) || 0);
          newItem[sum_fields[0].TARGET_COLUMN] = sumValue;
        }
        gridDataSource.add(newItem);

        grid.setDataSource(gridDataSource);
        dews.ui.loading.hide();
        //데이터그리드변경 --end

        if (grid.dataItems().length > 0) {
          var options = { fields: [change_fields[0].field], value: grid.dataItems(0)[change_fields[0].field], startIndex: 0 };
          grid.searchCell(options);
          grid.select(0);
        }
        else{
          dews.error(dews.localize.get("조회된 저장위치가 없습니다.",'M0001413'));
        }
      }
      dews.ui.loading.hide();
    }*/
  }

  console.log("*** IM Module CrossTab Script Loaded ***");

  //-------------------------------------------End-------------------------------------------

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=/js/IM/im.crosstab.js
