/*
 * @desc    IM 모듈 전자결재 properties
 * @date    2021.10.13
 * @path    /view/js/im.gw.properties.js
 */

(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'IM_GW_PROPERTIES';

  dews.ajax.script('~/view/js/HR/hr.gw.util.js', {
    once: true,
    async: false
  });

  /*
  * ● 그룹웨어 공통 설정, WF별 세부설정은 module.formId 에서 설정
  * gwServerUrl  : 전자결재 서버 URL (설정이 없다면 config/gw.properties-gw.server.url 로 설정)
  * url_type     : url타입 : 그룹웨어 결재구분 구분자 : "common" or "x"+drsCode (config/gw.properties - gw.approval.[url_type]].url)
  */
  module.gw = {
    package : {
      desc : "Package",
      url_type : "common"
    },
    10072 : {
      desc : "DEV테스트",
      gwServerUrl : "https://gw.comet.duzon.net/gw/outProcessEncLogOn.do",
      url_type : "common"
    },
    10114 : {
    	desc : "SK핀크스",
    	gwServerUrl : "https://gw.skpinx.co.kr/gw/outProcessEncLogOn.do",
    	url_type : "common"
    },
    10029 : {
    	desc : "벽산",
    	gwServerUrl : "https://bsgw.bsco.co.kr/gw/outProcessEncLogOn.do",
    	url_type : "common"
    },
    20038 : {
    	desc : "데코뷰",
    	gwServerUrl : "http://gwa.decoview.co.kr/gw/outProcessEncLogOn.do",
    	url_type : "common"
    }
  };


  /*
  * ● 메뉴 WF 별 세부설정
  *
  * moudle_cd           : 전자결재문서번호 채번 모듈코드(default:"HR" / 채번방식:company_cd+"_"+module_cd+"_"+athz_rpts_cd (athz_rpts_cd:자동채번:HR/12 고정))
  * contents_url        : 전자결재 양식 url
  * athz_rpts_table_nm  : ATHZ_RPTS_CD UPDATE 할 테이블ID
  * postProcess_url     : 후처리 서비스 url
  * gwWindow_close_event: 전자결재 창 close 시 이벤트
  * title               : 전자결재 default제목 ex) {text:"{0}_전자결재_{1}" , value:INVTRX_RSV_NO|INVTRX_TP_NM} => IRQ2023072401_전자결재_기타출고
  */
  module.formId = {
    /***************** IM *****************/
    // 재고요청처리_WF01
    IMIIRM00200_WF01 : {
      package : {
        desc : "Package",
        module_cd : "IM",
        contents_url : "/api/IM/Imiirm00200_GwContents_Service/imiirm00200_GwContents_WF01",
        athz_rpts_table_nm : "IM_MTLRSV_MST",
        postProcess_url : "/api/IM/IMIIRM00200_SERVICE/imiirm00200_confirm",
        title : {text:"[{0} : {1}] {2}", value:"INVTRX_TP_NM|INVTRX_RSV_NO|MST_RMK_DC"},
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      10072 : {
        desc : "DEV테스트",
        module_cd : "IM",
        contents_url : "/api/IM/Imiirm00200_GwContents_Service/imiirm00200_GwContents_WF01_20099",
        athz_rpts_table_nm : "IM_MTLRSV_MST",
        postProcess_url : "/api/IM/IMIIRM00200_SERVICE/imiirm00200_confirm",
        title : {text:"[{0} : {1}] {2}", value:"INVTRX_TP_NM|INVTRX_RSV_NO|MST_RMK_DC"},
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      10080 : {
        desc : "더마펌",
        contents_url : "/api/IM/Imiirm00200_GwContents_Service/imiirm00200_GwContents_WF01_10080",
        athz_rpts_table_nm : "IM_MTLRSV_MST",
        postProcess_url : "/api/IM/IMIIRM00200_SERVICE/imiirm00200_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20099 : {
        desc : "휴마시스",
        module_cd : "IM",
        contents_url : "/api/IM/Imiirm00200_GwContents_Service/imiirm00200_GwContents_WF01_20099",
        athz_rpts_table_nm : "IM_MTLRSV_MST",
        postProcess_url : "/api/IM/IMIIRM00200_SERVICE/imiirm00200_confirm",
        title : {text:"[{0} : {1}] {2}", value:"INVTRX_TP_NM|INVTRX_RSV_NO|MST_RMK_DC"},
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    },

    IMIIRM00200_X10114_WF01 : {
        10072 : {
          desc : "DEV테스트",
          contents_url : "/api/IM/Imiirm00200_GwContents_x10114_Service/imiirm00200_GwContents_WF01_10114",
          athz_rpts_table_nm : "IM_MTLRSV_MST",
          postProcess_url : "/api/IM/Imiirm01200_x10114_Service/imiirm00200_x10114_GWconfirm",
          gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
        },
        10114 : {
          desc : "SK핀크스",
          contents_url : "/api/IM/Imiirm00200_GwContents_x10114_Service/imiirm00200_GwContents_WF01_10114",
          athz_rpts_table_nm : "IM_MTLRSV_MST",
          postProcess_url : "/api/IM/Imiirm01200_x10114_Service/imiirm00200_x10114_GWconfirm",
          gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
        }
    },

    IMIIRM00201_X10114_WF01 : {
    	10072 : {
    		desc : "DEV테스트",
    		contents_url : "/api/IM/Imiirm00200_GwContents_x10114_Service/imiirm00200_GwContents_WF01_10114",
    		athz_rpts_table_nm : "IM_MTLRSV_MST",
    		postProcess_url : "/api/IM/Imiirm01200_x10114_Service/imiirm00200_x10114_GWconfirm",
    		gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
    	},
    	10114 : {
    		desc : "SK핀크스",
    		contents_url : "/api/IM/Imiirm00200_GwContents_x10114_Service/imiirm00200_GwContents_WF01_10114",
    		athz_rpts_table_nm : "IM_MTLRSV_MST",
    		postProcess_url : "/api/IM/Imiirm01200_x10114_Service/imiirm00200_x10114_GWconfirm",
    		gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
    	}
    },

    // 재고실사결과입력
    IMPPHY00300_WF01 : {
      package : {
        desc : "Package",
        module_cd : "IM",
        contents_url : "/api/IM/Impphy00300_GwContents_Service/impphy00300_GwContents_WF01",
        athz_rpts_table_nm : "IM_PHYSICAL_MST",
        postProcess_url : "/api/IM/IMPPHY00300_SERVICE/impphy00300_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    },

    /***************** PU *****************/
    // 구매발주입력_WF01
    PUOORD00100_WF01 : {
      package : {
        desc : "Package",
        module_cd : "PU",
        contents_url : "/api/PU/Puoord00100_GwContents_Service/puoord00100_GwContents_WF01",
        athz_rpts_table_nm : "PU_PURORDER_MST",
        postProcess_url : "/api/PU/Puoord00100_GwContents_Service/puoord00100_Gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      10072 : {
        desc : "DEV테스트",
        module_cd : "PU",
        contents_url : "/api/PU/Puoord00100_GwContents_Service/puoord00100_GwContents_WF01",
        athz_rpts_table_nm : "PU_PURORDER_MST",
        postProcess_url : "/api/PU/Puoord00100_GwContents_Service/puoord00100_Gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    },
    // 구매발주처리_WF01
    PUOORD00200_WF01 : {
      20099 :{
        desc : "휴마시스",
        module_cd : "PU",
        contents_url : "/api/PU/Puoord00200_GwContents_Service/puoord00200_GwContents_WF01_20099",
        athz_rpts_table_nm : "PU_PURORDER_MST",
        postProcess_url : "/api/PU/Puoord00200_GwContents_Service/puoord00200_Gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    },
    // 구매요청처리_WF01
    PUOPRQ00200_WF01 : {
      package : {
        desc : "Package",
        module_cd : "PU",
        contents_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_GwContents_WF01",
        athz_rpts_table_nm : "PU_PURREQ_MST",
        postProcess_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_Gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      10072 : {
        desc : "DEV테스트",
        module_cd : "PU",
        contents_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_GwContents_WF01",
        athz_rpts_table_nm : "PU_PURREQ_MST",
        postProcess_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_Gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      10091 : {
        desc : "삼광의료재단",
        module_cd : "PU",
        contents_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_GwContents_WF01_10091",
        athz_rpts_table_nm : "PU_PURREQ_MST",
        postProcess_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_Gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20099 :{
        desc : "휴마시스",
        module_cd : "PU",
        contents_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_GwContents_WF01_20099",
        athz_rpts_table_nm : "PU_PURREQ_MST",
        postProcess_url : "/api/PU/Puoprq00200_GwContents_Service/puoprq00200_Gw_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    },
    // 구매송장처리_WF03
    PUVIVE01300_WF03 : {
      package : {
        desc : "Package",
        module_cd : "PU",
        contents_url : "/api/PU/Puvive01300_GwContents_Service/puvive01300_GwContents_WF03",
        athz_rpts_table_nm : "PU_INVOICE_MST",
        postProcess_url : "/api/PU/Puvive01300_GwContents_Service/puvive01300_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      10072 : {
        desc : "DEV테스트",
        contents_url : "/api/PU/Puvive01300_GwContents_Service/puvive01300_GwContents_WF03",
        athz_rpts_table_nm : "PU_INVOICE_MST",
        postProcess_url : "/api/PU/Puvive01300_GwContents_Service/puvive01300_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      10091 : {
        desc : "삼광의료재단",
        contents_url : "/api/PU/Puvive01300_GwContents_Service/puvive01300_GwContents_WF03",
        athz_rpts_table_nm : "PU_INVOICE_MST",
        postProcess_url : "/api/PU/Puvive01300_GwContents_Service/puvive01300_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20038 : {
        desc : "데코뷰",
        contents_url : "/api/PU/Puvive01300_X20038Service/puvive01300_x20038_contents",
        athz_rpts_table_nm : "PU_INVOICE_MST",
        postProcess_url : "/api/PU/Puvive01300_X20038Service/puvive01300_x20038_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    },

    // 생산출고조정
    SFCORF01900_X10029_WF01 : {
      10029 : {
        desc : "벽산",
        contents_url : "/api/PP/Sfcorf01900_X10029_GwContents_Service/sfcorf01900_GwContents_WF01_10029",
        athz_rpts_table_nm : "PP_MTLTRXTMP_DTL",
        postProcess_url : "/api/PP/Sfcorf01900_X10029_GwContents_Service/sfcorf01900_X10029_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    },

    /***************** IE *****************/
    // 수입비용처리
    IETSCG00200_WF01 : {
      package : {
        desc : "Package",
        contents_url : "/api/IE/IETSCG_GwContents_Service/ietscg00200_GwContents_WF01",
        athz_rpts_table_nm : "IE_ICHARGE_MST",
        postProcess_url : "/api/IE/IETSCG00200_Service/ietscg00200_confirm",
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    },

    /***************** SD *****************/
    // 수주
    SLSSOR00200_WF01 : {
      package : {
        desc : "Package",
        module_cd : "SD",
        contents_url : "/api/SD/SlsssorBizboxService/slssor00200_bizbox_content_x20099",
        athz_rpts_table_nm : "SD_SO_MST",
        postProcess_url : "/api/SD/SlsssorBizboxService/slssor00200_bizbox_confirm_x20099",
        title : {text:"[수주서: {0}] {1}", value:"SODOC_NO|PARTNER_NM"},
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      },
      20099 : {
        desc : "휴마시스",
        module_cd : "SD",
        contents_url : "/api/SD/SlsssorBizboxService/slssor00200_bizbox_content_x20099",
        athz_rpts_table_nm : "SD_SO_MST",
        postProcess_url : "/api/SD/SlsssorBizboxService/slssor00200_bizbox_confirm_x20099",
        title : {text:"[수주서: {0}] {1}", value:"SODOC_NO|PARTNER_NM"},
        gwWindow_close_event : function(){dews.ui.mainbuttons.search.click();}
      }
    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
