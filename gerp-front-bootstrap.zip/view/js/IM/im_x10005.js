/*
 * @desc    IM 모듈 공통 함수 (X10005-동서발전)
 * @author  김준일
 * @date    2020.08.26
 * @path    /view/js/im_x10005.js
 */
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = "IM"; //모듈 코드

  //! 일반 공통 메소드
  module.com = {};

  //! 서버사용 공통 메소드
  module.api = {};

  //! 폴리필
  module.polyFill = (function () {
    // https://tc39.github.io/ecma262/#sec-array.prototype.find
    if (!Array.prototype.find) {
      Object.defineProperty(Array.prototype, "find", {
        value: function (predicate) {
          // 1. Let O be ? ToObject(this value).
          if (this == null) {
            throw TypeError('"this" is null or not defined');
          }
          var o = Object(this);
          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;
          // 3. If IsCallable(predicate) is false, throw a TypeError exception.
          if (typeof predicate !== "function") {
            throw TypeError("predicate must be a function");
          }
          // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
          var thisArg = arguments[1];
          // 5. Let k be 0.
          var k = 0;
          // 6. Repeat, while k < len
          while (k < len) {
            // a. Let Pk be ! ToString(k).
            // b. Let kValue be ? Get(O, Pk).
            // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
            // d. If testResult is true, return kValue.
            var kValue = o[k];
            if (predicate.call(thisArg, kValue, k, o)) {
              return kValue;
            }
            // e. Increase k by 1.
            k++;
          }

          // 7. Return undefined.
          return undefined;
        },
        configurable: true,
        writable: true,
      });
    }
  })();

  /*********************************************************************************************
   *  @desc  js파일 상속
   *  @param {Object} targetJS [필수] js 객체 변수
   *  @ex
   * ------------------------------------------------------------------------------------------*/
  module.extendJS = function (targetJS) {
    $.each(Object.keys(targetJS), function (idx, key) {
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
       겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function (idx, kName) {
        if (keyArr.indexOf(kName) >= 0) {
          console.error(
            "js 상속중 동일한 메소드 명이 존재합니다 - ",
            key + "." + kName
          );
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  };

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // im.js 상속
  dews.ajax
    .script("~/view/js/IM/im.js", {
      once: true,
      async: false,
    })
    .done(function () {
      module.extendJS(gerp.IM);
      console.log("*** IM Module(X10005) Script Loaded ***");
    });

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=/js/IM/im_x10005.js
