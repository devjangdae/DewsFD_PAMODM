/* 신규생성 : 이동명 2023-06-05 */
/*
 * FR 모듈 공통 함수
 * /view/js/fr.cm.js
 */
(function (dews, gerp, $) {
  var module = {};

  //---------Setting
  var defaultObject = {};
  var moduleCode = 'FR'; //모듈 코드
  
  //---------Start

  
  //Form 공통함수
  module.FORM = {

    /**
     * 폼 판넬에 속해있는 컨트롤 clear(빈값) 처리.
     * @example clearFormPanel(self.fp1);
     * @param {*} fp1 폼 판넬명
     * @return {*} 년월
     */
    clearFormPanel : function (form_panel) {
      var form_panel_data = form_panel.serialize();
      Object.keys(form_panel_data).forEach(function (e) {
        form_panel_data[e] = '';
      });
      form_panel.bindData(form_panel_data);
    },
    
  };

  module.DATE = {

    /**
     * frontEnd 에서 Type을 date to String 으로 형변환처리.
     * @example getDateStr(dataM, ['CONT_EXPY_DT', 'RMND_DT'], true);
     * @example getDateStr(dataM, ['CONT_EXPY_DT', 'RMND_DT'], true, 'yyyyMM');
     * @param {*} dataM: dzModel, ['CONT_EXPY_DT', 'RMND_DT']: 배열형식의 Columns, isInDeleted: delete 형변환 포함유무, yyyyMM: format 형식(생략가능)
     * @return {*} 형변환 된 dzModel
     */
    getDateStr : function(dzModelJson, keyArr, isInDeleted, format) {

      // 포멧 지정안되어있으면 디폴트 'yyyyMMdd'
      if (format == undefined) {
          format = "yyyyMMdd";
      }
      
      // added, updated 는 필수
      let arr = [dzModelJson.Added, dzModelJson.Updated];
  
      // deleted 필요하면 처리
      if (isInDeleted) {
          arr.push(dzModelJson.Deleted);
      }
  
      for (let idx = 0; idx < arr.length; idx++)
          arr[idx].map(function (v, i) {
              for (let idx = 0; idx < keyArr.length; idx++) {
                  v[keyArr[idx]] = dews.ui.formatedDate(v[keyArr[idx]], format);
              }
              return v;
          });
    }
  };

  module.MSGBOX = {
    /**
     * 
    /*********************************************************************************************
     *  @desc    alert 창 다시 alert 띄울경우 사용.
     *  @example let confirm = dews.confirm('확정 하시겠습니까 ? ', 'question').yes(function () {
     *               if (runProcess) {  // 필요 프로세스 처리
     *                   frCm.MSGBOX.confirmDeactivate(confirm, function () { self.dsM.read(); }, true, "확정되었습니다.", "success");
     *               }
     *           })
     *  @param  {object}  confirm    dews.alert
     *  @param  {object}  func       이후 실행해야 할 로직
     *  @param  {boolean} isUseAlert alert 호출 유무
     *  @param  {string}  alertMsg   message
     *  @param  {string}  alertIcon  아이콘
     *  @return 
     * ------------------------------------------------------------------------------------------*/
    confirmDeactivate: function (confirm, func, isUseAlert, alertMsg, alertIcon) {
      if (isUseAlert === true) {
          confirm.dialog.dialog.bind('deactivate', function () {
            module.MSGBOX.alertWithClosed(func, alertMsg, alertIcon);
          });
      }
      else {
          confirm.dialog.dialog.bind('deactivate', func);
      }
    },
    alertWithClosed: function (func, alertMsg, alertIcon) {
        dews.alert(alertMsg, alertIcon).on("closed", func);
    }

};

module.CALCULATE = {
  calcQtOrExum: function (grid, index, col_qt, col_inv_qt, col_um, col_inv_um, col_vat_incl_um, col_amt, col_vat_amt, col_tot_amt, col_unit_qt, col_vat_incl_yn, col_nume_trte_vr, col_dnom_trte_vr, exrt_rt, format_qt, format_um, format_amt) {

      const ma_format_list = maScm.api.getCommonFormat(); //회사환경포맷목록설정
      
      // 단위환산값(수주단위수량)
      const unit_qt = module.VALIDATE.isNull(grid.getCellValue(index, col_unit_qt)) ? 1 : grid.getCellValue(index, col_unit_qt);
      //부가세포함여부 
      const vat_incl_yn = module.VALIDATE.isNull(grid.getCellValue(index, col_vat_incl_yn)) ? 'N' : grid.getCellValue(index, col_vat_incl_yn);
      // 부가세율 분자값     
      const nume_trte_vr = module.VALIDATE.isNull(grid.getCellValue(index, col_nume_trte_vr)) ? 0 : grid.getCellValue(index, col_nume_trte_vr);
      // 부가세율 분모값     
      const dnom_trte_vr = module.VALIDATE.isNull(grid.getCellValue(index, col_dnom_trte_vr)) ? 100 : grid.getCellValue(index, col_dnom_trte_vr);

      // 환율(shnnsy psh 주문에는환율(외화/환황 컬럼이 따로 있지않음))
      exrt_rt = module.VALIDATE.isNull(exrt_rt, true) ? 1 : exrt_rt;

      let qt = module.VALIDATE.isNull(grid.getCellValue(index, col_qt)) ? 0 : grid.getCellValue(index, col_qt);
      let inv_qt = module.VALIDATE.isNull(grid.getCellValue(index, col_inv_qt)) ? 0 : grid.getCellValue(index, col_inv_qt);
      let um = module.VALIDATE.isNull(grid.getCellValue(index, col_um)) ? 0 : grid.getCellValue(index, col_um) * exrt_rt;
      let inv_um = module.VALIDATE.isNull(grid.getCellValue(index, col_inv_um)) ? 0 : grid.getCellValue(index, col_inv_um) * exrt_rt;
      let vat_incl_um = module.VALIDATE.isNull(grid.getCellValue(index, col_vat_incl_um)) ? 0 : grid.getCellValue(index, col_vat_incl_um) * exrt_rt;
      let amt = module.VALIDATE.isNull(grid.getCellValue(index, col_amt)) ? 0 : grid.getCellValue(index, col_amt);
      let vat_amt = module.VALIDATE.isNull(grid.getCellValue(index, col_vat_amt)) ? 0 : grid.getCellValue(index, col_vat_amt);
      let tot_amt = module.VALIDATE.isNull(grid.getCellValue(index, col_tot_amt)) ? 0 : grid.getCellValue(index, col_tot_amt);

      //if (unit_qt == 0 || (vat_incl_yn == "N" && um == 0) || (vat_incl_yn == "Y" && vat_incl_um == 0))
      if (unit_qt == 0)
          return;

      if (qt != 0 && inv_qt == 0) //재고단위수량 입력            
          inv_qt = qt * unit_qt;
      else if (qt == 0 && inv_qt != 0) //주문수량 입력
          qt = inv_qt == 0 ? 0 : inv_qt / unit_qt;

      if (vat_incl_yn == "Y") //부가세포함
      {
          // 단가 = Math.Round(부가세포함단가 / (1 + (_부가세율 / 100)), 0);
          //um = maScm.com.getChangeNumber(ma_format_list, format_amt, vat_incl_um / (1 + (nume_trte_vr / dnom_trte_vr)), "");
          um = vat_incl_um / (1 + (nume_trte_vr / dnom_trte_vr))

          // _재고단위단가 = Math.Round(_단가 / _수주단위수량, 0);
          //inv_um = maScm.com.getChangeNumber(ma_format_list, format_um, um / unit_qt, "");
          inv_um = um / unit_qt

          //_총금액 = _단가 * _주문수량;
          tot_amt = (vat_incl_um * qt);

          // 공급가액 : 10000 / 1.1 
          // 부가세 : (10000 / 1.1) * 0.1
          // 공급가액을 먼저구하고 차이를 부가세로 설정
          //_공급가액 = Math.Round(_총금액 / (1 + (_부가세율 / 100)), 0);
          //amt = maScm.com.getChangeNumber(ma_format_list, format_amt, tot_amt / (1 + (nume_trte_vr / dnom_trte_vr)), "");
          amt = tot_amt / (1 + (nume_trte_vr / dnom_trte_vr))

          //부가세 = _총금액 - _공급가액
          vat_amt = tot_amt - amt;

          // // 부가세를 먼저구하고 차이를 공급가액으로 설정
          // //_부가세 = Math.Round(_총금액 / (1 + (_부가세율 / 100)), 0);
          // vat_amt = maScm.com.getChangeNumber(ma_format_list, format_amt, tot_amt / (1 + (nume_trte_vr / dnom_trte_vr)) * (nume_trte_vr / dnom_trte_vr), "");

          // //_공급가액 = _총금액 - _부가세
          // amt = tot_amt - vat_amt;

          grid.setCellValue(index, col_vat_incl_um, maScm.com.getChangeNumber(ma_format_list, format_um, vat_incl_um, ""), false);
      }
      else if (vat_incl_yn == "N") //부가세미포함
      {
          // _재고단위단가 = _수주단위수량 == 0 ? 0 : Math.Round(_단가 / _수주단위수량, 0);
          //inv_um = unit_qt == 0 ? 0 : maScm.com.getChangeNumber(ma_format_list, format_um, um / unit_qt, "");
          inv_um = unit_qt == 0 ? 0 : um / unit_qt;

          //_공급가액 = _단가 * _주문수량;
          amt = (um * qt);
          //_부가세 = Math.Round(_공급가액 * (_부가세율 / 100), 0);
          //vat_amt = maScm.com.getChangeNumber(ma_format_list, format_amt, amt * (nume_trte_vr / dnom_trte_vr), "");
          vat_amt = amt * (nume_trte_vr / dnom_trte_vr)
          //_총금액 = _공급가액 + _부가세;
          tot_amt = amt + vat_amt;
      }

      grid.setCellValue(index, col_qt, maScm.com.getChangeNumber(ma_format_list, format_qt, qt, ""), false);
      grid.setCellValue(index, col_inv_qt, maScm.com.getChangeNumber(ma_format_list, format_qt, inv_qt, ""), false);
      grid.setCellValue(index, col_um, maScm.com.getChangeNumber(ma_format_list, format_um, um, ""), false);
      grid.setCellValue(index, col_inv_um, maScm.com.getChangeNumber(ma_format_list, format_um, inv_um, ""), false);

      grid.setCellValue(index, col_amt, maScm.com.getChangeNumber(ma_format_list, format_amt, amt, ""), false);
      grid.setCellValue(index, col_vat_amt, maScm.com.getChangeNumber(ma_format_list, format_amt, vat_amt, ""), false);
      grid.setCellValue(index, col_tot_amt, maScm.com.getChangeNumber(ma_format_list, format_amt, tot_amt, ""), false);
  }
};

module.VALIDATE = {
  isNull: function (val, zero_bl) {
    zero_bl = zero_bl === undefined ? false : zero_bl;
    return val === undefined || val === null || val === "" || (zero_bl && val === 0);
  },

  /**
   * 
  /*********************************************************************************************
   *  @desc    PrimaryKey 체크시 사용
   *  @example  let datasource = [
                    { DEPT_CD: '100', EMP_CD: 'AA', QT: 10 },
                    { DEPT_CD: '100', EMP_CD: 'AA', QT: 20 },
                    { DEPT_CD: '300', EMP_CD: 'BB', QT: 30 },
                    { DEPT_CD: '300', EMP_CD: 'BB', QT: 40 }
                ];
                let keyArr = ['DEPT_CD', 'EMP_CD'];

                let validatedPrimarykey = chkPrimarykey(datasource, keyArr);
                let validatedPrimarykey2 = chkPrimarykey(datasource, keyArr, true);

                if(!validatedPrimarykey)
                {
                    dews.alert('중복 데이터가 존재합니다.', 'warning');
                    return false;    
                }
                if (!validatedPrimarykey2.valid) {
                    dews.alert('중복 데이터가 존재합니다.\n' + validatedPrimarykey2.duplicates, 'warning');
                    return false;
                }
   *  @param  {list}      datasource ex) self.grid.dataItems()
   *  @param  {string[]}  keyArr     key 컬럼
   *  @param  {boolean}   useMsg     중복데이터 return 유무
   *  @return 
   * ------------------------------------------------------------------------------------------*/
  chkPrimarykey: function (datasource, keyArr, useMsg) {
    // 중복된 Primary Key를 검사하기 위해 사용할 Set 생성
    const keySet = new Set();

    if (!useMsg) {
      // useMsg가 false인 경우, 중복 검사를 수행하여 결과 반환
      for (const data of datasource) {
          const key = keyArr.map(key => data[key]).join(':'); // Primary Key 생성

          if (keySet.has(key)) {
              return false; // 중복된 Primary Key가 존재하면 false 반환
          }

          keySet.add(key); // 중복되지 않은 Primary Key 추가
      }

      return true; // 중복된 Primary Key가 없으면 true 반환
    } else {
      // useMsg가 true인 경우, 중복된 Primary Key를 추적하고 결과 반환
      const duplicates = [];
      for (const data of datasource) {
          const key = keyArr.map(key => data[key]).join(':'); // Primary Key 생성

          if (keySet.has(key)) {
              duplicates.push(
                  keyArr.reduce((obj, key) => {
                      obj[key] = data[key]; // 중복된 데이터의 Primary Key 필드 추출
                      return obj;
                  }, {})
              );
          }

          keySet.add(key); // 중복되는 Primary Key 추가
      }

      if (duplicates.length > 0) {
          const duplicatesString = duplicates
              .map(duplicate => {
                  const properties = Object.entries(duplicate)
                      .map(([key, value]) => `${key}: ${JSON.stringify(value)}`) // 중복된 데이터를 문자열로 변환
                      .join(', ');
                  return `{ ${properties} }`;
              })
              .join('\n');

          return {
              valid: false,
              duplicates: duplicatesString
          };
      } else {
          return { valid: true };
      }
    }
  }
};

/**********************************************************************************************/

  /*********************************************************************************************
  *  @desc  js파일 상속
  *  @param {Object} targetJS [필수] js 객체 변수
  *  @ex
  * ------------------------------------------------------------------------------------------*/
  module.extendJS = function(targetJS){
    $.each(Object.keys(targetJS), function(idx, key){
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
         겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName){
        if(keyArr.indexOf(kName) >= 0){
          console.error("js 상속중 동일한 메소드 명이 존재합니다 - ", (key + '.' + kName));
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  }

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  var maScm;
  dews.ajax.script('~/view/js/MA/ma.scm.js', {
    once: true,
    async: false
  }).done(function() {
    maScm = gerp.MA;
  });
  module.extendJS(maScm);

  //---------End

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=fr.cm.js
