/*********************************************************************************************
  @desc   QM 모듈 공통 함수
  @author
  @date   2020.07.21
  @path   /view/js/sd.js
  @notice 상속할 js파일은 최하단에 기술 할 것
  var qmJS;
  dews.ajax.script('~/view/js/QM/qm.js', {
    once: true,
    async: false
  }).done(function() {
    qmJS = gerp.QM;
  });
**********************************************************************************************/
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'QM';  // 모듈코드

  // 공통
  module.com = {
    /*********************************************************************************************
     *  @desc  에러 발생시 에러 내용 띄워주는 팝업
     *  @param {Array}  errList  에러 리스트
     *  @param {String} title    에러 팝업창 타이틀
     *  @ex  qmJS.com.openErrPop(errList);
     * ------------------------------------------------------------------------------------------*/
    openErrPop: function(errList, title){
      var dialog = dews.ui.dialog("H_QM_ERROR_C2",{
        url: "/codehelp/QM/H_QM_ERROR_C2",
        title: title || '저장실패',
        width: "700",
        height: "300"
      });
      dialog.setInitData(errList);
      dialog.open();
    },
	/*********************************************************************************************
     *  @desc   문서-첨부파일창을 오픈합니다.
     *          실제 저장되는 FILE_DC: 회사코드_[module_cd]_[docu_no]
     *          실제 저장되는 FILE_ATCH_TXT(FILE_PATH.파일경로): /모듈/중메뉴코드/
     *  @param  {String}  module_cd - [필수] 모듈코드(self.menu.module)
     *  @param  {String}  menu_cd   - [필수] 메뉴코드(self.menu.id)
     *  @param  {String}  docu_no   - [필수] 문서번호
     *  @param  {Object}  options   - [옵션] 옵션값(title, download, upload, read)
     *  @return {Promise} 도움창에서 변경된 데이터 있을시 사용.
     *  @ex     sdJS.com.openDocuFilePop(self.menu.module, self.menu.id, self.mstGrid.dataItem(e.row.index).SODOC_NO)
                .then(function(data) {
                  console.log(data);
                });
     * ------------------------------------------------------------------------------------------*/
    openDocuFilePop: function(module_cd, menu_cd, docu_no, options){
      if(module.com.isNull(module_cd) || module.com.isNull(menu_cd) || module.com.isNull(docu_no)){
        console.error("qmJS - openDocuFilePop 함수의 파라미터가 부족합니다.");
      } else{
        // 파일내역(PK) 설정
        var file_dc = menu_cd.substr(0, 6) + '_' + docu_no;
        return module.com.openFilePop(module_cd, menu_cd, file_dc, options);
      }
    },
    /*********************************************************************************************
     *  @desc   첨부파일창을 오픈합니다. #고유문서번호가 있는 경우, openDocuFilePop메소드 사용
     *          실제 저장되는 FILE_ATCH_TXT(FILE_PATH.파일경로): /모듈/중메뉴코드/
     *  @param  {String}  module_cd - [필수] 모듈코드(self.menu.module)
     *  @param  {String}  menu_cd   - [필수] 메뉴코드(self.menu.id) - 파일경로 설정.
     *  @param  {String}  file_dc   - [필수] 파일내역(PK) - 회사코드 제외하고 넘길것(실제 저장되는 FILE_DC: 회사코드_모듈코드_[file_dc])
     *  @param  {Object}  options   - [옵션] 옵션값(title, download, upload, read)
     *  @return {Promise} 도움창에서 변경된 데이터 있을시 사용.
     *  @ex     sdJS.com.openFilePop(self.menu.module, self.menu.id, '')
                .then(function(data) {
                  console.log(data);
                });
     * ------------------------------------------------------------------------------------------*/
    openFilePop: function(module_cd, menu_cd, file_dc, options){
      return new Promise(function(resolve){
        if(module.com.isNull(module_cd) || module.com.isNull(file_dc) || module.com.isNull(menu_cd)){
          console.error("ieJS - openFilePop 함수의 파라미터가 부족합니다.");
          resolve(false);
        } else{
          // 옵션값 세팅
          options = options || {};
          options.upload   = options.hasOwnProperty('upload')   ? options.upload   : true; // upload, delete 버튼 true/false
          options.download = options.hasOwnProperty('download') ? options.download : true; // download 버튼 true/false
          options.read     = options.hasOwnProperty('read')     ? options.read     : true; // read 자동조회 true/false
          options.title    = options.hasOwnProperty('title')    ? options.title    : '첨부파일'; // 타이틀 변경

          // 다이얼로그 세팅
          var dialog = dews.ui.dialog("H_QM_FILE_C", {
            url : "/codehelp/QM/H_QM_FILE_C",
            width : 680,
            height : 260,
            buttons : "none",
            ok: function(data){
              resolve(data);
            }
          });
          dialog.setInitData({
            file_dc   : file_dc,
            file_path : '/' + module_cd + '/' + menu_cd.substr(0, 6),
            options   : options
          });
          dialog.open();
        }
      });
    }
  };

  //API
  module.api = {
    /* --------------------------------------------------------------------------------------------
      *  @desc           그리드용 중복체크 함수
      *  @param          - parameters : 테이블 및 컬럼 정보 객체(table_nm, column_cd, column_nm, pk_cd)
      *                    >> 리턴받올 column_nm의 값이 없다면 공백('')으로 넘길것
      *                  - grid       : grid 객체
      *                  - flag       : 1/2/3 - 1: front만 체크, 2: back만 체크, 3:front, back 모두 체크
      *  @return         중복되는 코드가 있을시 : 중복데이터 object(pk_cd, pk_nm)
      *                                 없을시 : null
      *
      *  @ex             var parameters = {               |              var parameters = {
      *                    table_nm: 'IE_ECI_MST',        |               table_nm: 'LE_ROUTE_MST',
      *                    column_cd: 'INVC_NO',          |               column_cd: 'TRNSPROUTE_CD',
      *                    column_nm: '',                 |               column_nm: 'TRNSPROUTE_NM',
      *                    pk_cd: 'INVC-20190709-01'      |                pk_cd: 'SP001'
      *                  };                               |             };
      *
      *                  var result = sdJS.api.dupleChk(parameters, mstGrid, 2);
      * ------------------------------------------------------------------------------------------*/
  };

  // 에러 다이얼로그(sdJS.com의 openErrorPopup 함수) 사용을 위한 에러 리스트
  // 임시로 sql, java라고 명명
  module.errorList = {
    sql: {
      'ORA-00001': "PK 컬럼이 중복 됩니다.",
      'ORA-00904': "존재하지 않는 컬럼 입니다. (부적합한 식별자)",
      'ORA-00911': "문자가 부적합 합니다(';', ',' 등)",
      'ORA-00917': "콤마(,)가 누락되었습니다.",
      'ORA-00923': "FROM 키워드가 필요한 위치에 없습니다",
      'ORA-00933': "SQL 명령어가 올바르게 종료되지 않았습니다",
      'ORA-00936': "누락된 표현식(기호, 괄호, 띄어쓰기 등)",
      'ORA-00942': "테이블 또는 뷰가 존재하지 않습니다.",
      'ORA-00947': "INSERT문의 인자가 충분하지 않습니다.",
      'ORA-01722': "NUMBER 타입에 문자가 삽입되었습니다.",
      'ORA-12899': "컬럼에 설정된 길이보다 긴 값 삽입되었습니다.",
      'ORA-01438': "컬럼에 설정된 길이보다 긴 값 삽입되었습니다.",
      'ORA-01400': "NOT NULL 컬럼에 NULL이 삽입되었습니다.",
      'ORA-01407': "NOT NULL 컬럼에 NULL이 삽입되었습니다.",
      'ORA-01861': "컬럼의 데이터 타입과 인자 타입이 일치하지 않습니다."
    },
    java: {
      'null': "NullPointerException 발생",
      '/ by zero': "0으로 나눌 수 없습니다.",
      'Mapped Statements collection does not contain': "쿼리를 찾을수 없습니다.", // 경우가 여러가지 - namespace 잘못, mybatis id 중복
      'Error converting' : "형변환을 할 수 없습니다."
    }
  };

  /*********************************************************************************************
  *  @desc  js파일 상속
  *  @param {Object} targetJS [필수] js 객체 변수
  *  @ex
  * ------------------------------------------------------------------------------------------*/
  module.extendJS = function(targetJS){
    $.each(Object.keys(targetJS), function(idx, key){
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
         겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName){
        if(keyArr.indexOf(kName) >= 0){
          console.error("js 상속중 동일한 메소드 명이 존재합니다 - ", (key + '.' + kName));
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  }

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  var scmJS;
  dews.ajax.script('~/view/js/MA/ma.scm.js', {
    once: true,
    async: false
  }).done(function() {
    scmJS = gerp.MA;
  });
  module.extendJS(scmJS);

  /**********************************************************************************************/

  //-------------------------------------------End-------------------------------------------
  var newModule = {};
  newModule[moduleCode] = module;
  module.formatList = module.api.getCommonFormat(); // 회사환경설정-포맷리스트 세팅(sdJS.formatList)
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/QM/qm.js
