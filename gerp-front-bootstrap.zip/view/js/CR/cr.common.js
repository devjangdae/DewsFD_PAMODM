// /view/js/CR/cr.lib_Common.js
//# sourceURL=view/js/CR/cr.lib_Common.js

/*
 * CR 모듈 공통 함수
 */
(function(dews, gerp, $) {
    var module = {};
  
    //////// 작성 영역 - 시작 ////////
    var moduleCode = 'CR'; // 모듈 코드를 입력 해주세요.
  
    //// 공통 함수 정의 (방법 1)
    // module.myModuleFunction = function(page) {
    //   var text = page.MENU_NM.text();
    //   console.log(`## Print text ## : ${text}`);
    //   console.log('## Executed My Module Function ##');
    // };

    //// 공통 함수 정의 (방법 2)
    // module.MyCommonFunction = {
    //     getTest01 : function() {
    //         return "test01"
    //     },
    //     getTest02 : function(text) {
    //         return text;
    //     }
    // };

    // *****************************************************************************************
    // 01. 기준정보 - 영업조직권한설정 - CRM관리자등록 메뉴에 '관리자'로 등록되어 있는지 확인하는 함수
    //
    //   param01 : companyCode (회사코드)
    //   param02 : empNo       (직원번호)
    //   param03 : menugrpCode (메뉴그룹코드)
    //
    //   return : Array (CRM 관리자 권한)    
    // *****************************************************************************************
    module.fn_checkAdmin = function(companyCode, empNo, menugrpCode) {

        var result = [];

        dews.api.get(dews.url.getApiUrl('CR', 'CustomerRelationshipManagementMSTADMService', 'mstadm00200_check_adm'), {
            async: false,
            data: {
                company_cd: companyCode,
                emp_no: empNo,
                menugrp_cd: menugrpCode
            }
        }).done(function (data) {            
            
            result = data;
            

        }).fail(function (xhr, state , message, result) {

            // 실패 시에 수행합니다. 통신 오류 외의 서버 응답의 state 값이 'error'일 경우에도 fail이 수행됩니다.
            console.log("state:" + state + ", result:" + result + ", message:" + message);

        }).always(function () {

            // 성공, 실패와 관계없이 항상 실행합니다.

        });

        return result;

    }
    // *****************************************************************************************
    // *****************************************************************************************

    
    // *****************************************************************************************
    // 02. 메뉴 사용 권한을 조회하는 함수
    //
    //   param01 : companyCode (회사코드)
    //   param02 : empNo       (직원번호)
    //   param03 : menugrpCode (메뉴그룹코드)
    //   param04 : menuCode    (메뉴코드)
    //
    //   return : Array (사용자의 메뉴 권한)
    // *****************************************************************************************
    module.fn_checkEmpMenu= function(companyCode, empNo, menugrpCode, menuCode) {

        var result = [];

        dews.api.get(dews.url.getApiUrl('CR', 'CustomerRelationshipManagementMSTADMService', 'mstadm00200_check_emp_menu'), {
            async: false,
            data: {
                company_cd: companyCode,
                emp_no: empNo,
                menugrp_cd: menugrpCode,
                menu_cd : menuCode
            }
        }).done(function (data) {            

            result = data;            

        }).fail(function (xhr, state , message, result) {

            // 실패 시에 수행합니다. 통신 오류 외의 서버 응답의 state 값이 'error'일 경우에도 fail이 수행됩니다.
            console.log("state:" + state + ", result:" + JSON.stringify(result) + ", message:" + message);

        }).always(function () {

            // 성공, 실패와 관계없이 항상 실행합니다.

        });

        return result;

    }
    // *****************************************************************************************
    // *****************************************************************************************


    // *****************************************************************************************
    // 03. CRM 메뉴별 부서 데이터 접근 권한을 조회하는 함수
    //
    //   param01 : companyCode (회사코드)
    //   param02 : empNo       (직원번호)
    //   param03 : menugrpCode (메뉴그룹코드)
    //   param04 : menuCode    (메뉴코드)
    //
    //   return : Array (사용자의 메뉴별 부서 데이터 접근 권한)
    // *****************************************************************************************
    module.fn_checkEmpMenuDept= function(companyCode, empNo, menugrpCode, menuCode) {

        var result = [];

        dews.api.get(dews.url.getApiUrl('CR', 'CustomerRelationshipManagementMSTADMService', 'mstadm00200_check_emp_deptList'), {
            async: false,
            data: {
                company_cd: companyCode,
                emp_no: empNo,
                menugrp_cd: menugrpCode,
                menu_cd : menuCode
            }
        }).done(function (data) {

            result = data;     

        }).fail(function (xhr, state , message, result) {

            // 실패 시에 수행합니다. 통신 오류 외의 서버 응답의 state 값이 'error'일 경우에도 fail이 수행됩니다.
            console.log("state:" + state + ", result:" + JSON.stringify(result) + ", message:" + message);

        }).always(function () {

            // 성공, 실패와 관계없이 항상 실행합니다.

        });

        return result;

    }
    // *****************************************************************************************
    // *****************************************************************************************
  
    // console.log('## Module Script Loaded!!! ##');
  
    //////// 작성 영역 - 끝 ////////
  
    var newModule = {};
    newModule[moduleCode] = module;
    window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);