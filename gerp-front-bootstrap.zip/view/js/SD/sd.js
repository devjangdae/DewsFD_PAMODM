/*********************************************************************************************
  @desc   SD 모듈 공통 함수
  @author landameizer
  @date   2019.07.09
  @path   /view/js/sd.js
  @notice 상속할 js파일은 최하단에 기술 할 것
  var sdJS;
  dews.ajax.script('~/view/js/SD/sd.js', {
    once: true,
    async: false
  }).done(function() {
    sdJS = gerp.SD;
  });
**********************************************************************************************/
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'SD';  // 모듈코드

  //공통
  module.com = {
    /*********************************************************************************************
     *  @desc  에러 상세내용 표기 (ver1. alert & console logging처리 / ver2. H_SD_ERROR_PAGE_C 팝업 호출)
     *  @param {Object} error [필수] 에러객체 - sd-common 프로젝트의 SdCommonUtilError 모델.
     *  @param {String} errorMsg [선택] error alert에 표기할 문구.
     *  @ex  sdJS.com.detailErrorShow(error);
     * ------------------------------------------------------------------------------------------*/
    detailErrorShow: function(error, errorMsg){
      if(module.com.isNull(error)){
        console.error("sdJS - detailErrorShow: 오류 파라미터가 없습니다.", error);
      } else if(!error.hasOwnProperty('errorMessage')){ // Back단(sd-common)의 SdCommonUtilError를 파라미터로 받을것.
        console.error("sdJS - detailErrorShow: 오류 파라미터가 SD-오류객체가 아닙니다.", error);
        dews.error(dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
      } else{
        /* ver1. alert & console logging처리 */
        dews.error(errorMsg || "서버에서 요청 처리중 에러가 발생했습니다.");
        console.log("## SD - " + error.errorLocationFlag + ": " , error);

        /* ver2. 팝업으로 표기시 주석해제 후 사용하면 됨. (에러 상세내용이 표기되므로 일단 주석처리함) */
        // var dialog = dews.ui.dialog("H_SD_ERROR_PAGE_C",{
        //   url: "~/codehelp/SD/H_SD_ERROR_PAGE_C",
        //   title: "오류",
        //   width: "700",
        //   height: "300"
        // });
        // dialog.setInitData({
        //   error: error
        // });
        // dialog.open();
      }
    },
    /*********************************************************************************************
     *  @desc  분기에 따라 해당메뉴로 이동하는 메소드
     *  @param {Object} orgMenu  데이터 보내는 메뉴명
     *  @param {string} doctp    문서 구분코드(분기)
     *  @param {string} docno    문서 번호
     *  @ex    sdJS.com.linkToSdMenu("SLSSOR00100", data[0].doctp, data[0].docno);
     * ------------------------------------------------------------------------------------------*/
    linkToSdMenu: function(orgMenu, doctp, docno, dt, otherParams){
      var date = dt || dews.date.format(new Date(), 'yyyyMMdd');
      var strMenuNm = ""; //catch문에서 사용될 메뉴명
      try{
        if(docno){
          switch(doctp){
            case "SO1":{ //수주
              strMenuNm = '수주현황';
              var param = { menuID: orgMenu, sodoc_no: docno, so_dt: dt};
              dews.ui.openMenu("SD", "SLSSTR00300", true, param);
              break;
            }
            case "PR1":  //구매요청
            case "PR2":{ //구매요청(직납)
              strMenuNm = '구매요청현황';
              var param = { menuID: orgMenu, purreq_no: docno };
              dews.ui.openMenu("PU", "PUOPRQ00300", true, param);
              break;
            }
            case "PU":{ //(가)입고현황
              strMenuNm = otherParams.gubun != null && otherParams.gubun == 'T' ? '구매입고현황' : '가입고현황';
              var param = {
                menuID: orgMenu,
                rcpt_no: docno,
                plant_cd: otherParams.plant_cd,
                plant_nm: otherParams.plant_nm,
                rcpt_proc_dt: date
              };
              dews.ui.openMenu("PU", otherParams.gubun != null && otherParams.gubun == 'T' ? "PUGGRR00400" : "PUQIQC00400", true, param);
              break;
            }
            case "DLV":{ //납품지시
              strMenuNm = '납품지시현황';
              var param = { menuID: orgMenu, dlvdoc_no: docno, do_dt: date };
              dews.ui.openMenu("SD", "SHPSDR00300", true, param);
              break;
            }
            case "DLV2":{ //반품지시
              strMenuNm = '반품지시현황';
              var param = { menuID: orgMenu, dlvdoc_no: docno, do_dt: date };
              dews.ui.openMenu("SD", "SHPSDR00800", true, param);
              break;
            }
            case "GI1":{ //출고
              strMenuNm = '출고현황';
              var param = { menuID: orgMenu, gidoc_no: docno, invtrx_dt: date };
              dews.ui.openMenu("SD", "SHPDLV00400", true, param);
              break;
            }
            case "GI2":{ //반품
              strMenuNm = '출고반품현황';
              var param = { menuID: orgMenu, gidoc_no: docno, invtrx_dt: date };
              dews.ui.openMenu("SD", "SHPDLV00500", true, param);
              break;
            }
            case "BIL":{ //매출
              strMenuNm = '매출현황';
              var param = { menuID: orgMenu, billdoc_no: docno };
              dews.ui.openMenu("SD", "BILBIV00300", true, param);
              break;
            }
            case "FI":{ //FI전표
              strMenuNm = '전표조회승인';
              var param = { menuID: orgMenu, docu_no: docno , pc_cd: otherParams.pc_cd};
              dews.ui.openMenu("FI", "GLDDOC00700", true, param);
              break;
            }
            case "CO":{ //CO전표
              strMenuNm = '수익성전표조회';
              var param = { menuID: orgMenu,
                            padoc_no: docno,
                            yyyyMMstart: otherParams.yyyyMMstart,
                            yyyyMMend:otherParams.yyyyMMend };
              dews.ui.openMenu("CO", "PANPIA00100", true, param);
              break;
            }
            case "CO2":{ //CO비용전표
              strMenuNm = '전표통합조회';
              var param = { menuID: orgMenu,
                            docu_no: docno,
                            docu_tp_cd: otherParams.docu_tp_cd,
                            actg_dt: dt };
              dews.ui.openMenu("CO", "CBCCIA00200", true, param);
              break;
            }
            case "TRX":{ //수불
              strMenuNm = '재고전기내역조회';
              var param = {
                trans_menu_id: orgMenu,
                trans_no_mtldoc: docno
              };
              dews.ui.openMenu("IM", "IMARTP00200", true, param);
              break;
            }
            case "MTR":{ //자재원장
              strMenuNm = '자재원장문서조회';
              var param = {
                menuID: orgMenu,
                yyyyMMstart: date,
                yyyyMMend: date,
                mldoc_no: docno,
                plant_cd : otherParams.plant_cd
              };
              dews.ui.openMenu("CO", "MLEMIA00100", true, param);
              break;
            }
            default : {
              dews.alert("분기에 없는 파라미터가 입력되었습니다.","warning");
            }
          }
        }
      }catch(e){
        dews.alert(strMenuNm+" 메뉴의 권한이 없습니다.","warning");
      }
    },
    /*********************************************************************************************
     *  @desc  에러 발생시 에러 내용 띄워주는 팝업
     *  @param {Array}  errList  에러 리스트
     *  @param {String} title    에러 팝업창 타이틀
     *  @ex  sdJS.com.openErrPop(errList);
     * ------------------------------------------------------------------------------------------*/
    openErrPop: function(errList, title){
      var dialog = dews.ui.dialog("H_SD_ERROR_C2",{
        url: "/codehelp/SD/H_SD_ERROR_C2",
        title: title || '저장실패',
        width: "700",
        height: "300"
      });
      dialog.setInitData(errList);
      dialog.open();
    },
    /*********************************************************************************************
     *  @desc  문자열의 byte를 체크하는 메소드
     *  @param {char} ch    byte를 체크할 문자열
     *  @ex    sdJS.com.charByteSize("A");
     * ------------------------------------------------------------------------------------------*/
    charByteSize: function (ch) {
      var charCode = ch.charCodeAt(0);
      if (ch == null || ch.length == 0) {
        return 0;
      }
      if (charCode <= 0x00007F) {
        return 1;
      } else if (charCode <= 0x0007FF) {
        return 2;
      } else if (charCode <= 0x00FFFF) {
        return 3;
      } else {
        return 4;
      }
    },
    /*********************************************************************************************
     *  @desc  그리드 데이터를 단순히 보여주기위한 도움창 오픈
     *  @param {Object} grid    [필수]그리드 객체
     *  @param {Array}  columns [필수]도움창에서 보여줄 그리드의 컬럼명 배열(String-Array)
     *  @param {Object} options 옵션객체 - rowNo, title, size, rowData, footer
     *  @ex    sdJS.com.openView(self.mstGrid, ['COMP_CD', 'COMP_NM', 'ITEM_QT'], {});
     * ------------------------------------------------------------------------------------------*/
    openView: function(grid, columns, options){
      var dialog = dews.ui.dialog("H_SD_VIEW_C", {
        helpCustom: true,
        url: "/codehelp/SD/H_SD_VIEW_C",
        title: "자세히",
        size: 'medium'
      });

      // 파라미터 세팅
      dialog.setInitData({
        grid: grid,
        columns: columns,
        options: options,
        flag: true
      });

      dialog.open(); // 도움창 오픈
    },
    /*********************************************************************************************
     *  @desc  그리드 데이터를 단순히 보여주기위한 도움창 오픈
     *  @param {String} code   [필수]js내 sdPreDefinedColumns변수에 미리 선언해둔 컬럼 정보 사용.
     *  @param {Array}  data   [필수]도움창에서 보여줄 그리드 데이터
     *  @param {Object} options 옵션객체 - rowNo, title, size
     *  @ex    sdJS.com.openView('SC', [{SCALE_SQ: 1, SCALE_QT: 5, UNIT_CD: 'EA', PRC_AMT: '5000'}], {});
     * ------------------------------------------------------------------------------------------*/
    openDefinedView: function(code, data, options){
      var codeBool = sdPreDefinedColumns.hasOwnProperty(code);
      var dataBool = data && Array.isArray(data);
      var bool = false;

      if(!codeBool){
        console.error("sdJS - openDefinedView: 선언된 코드값이 없습니다.", code);
      } else if(!dataBool){
        console.error("sdJS - openDefinedView: 표시할 데이터가 없습니다.", data);
      } else{
        var dialog = dews.ui.dialog("H_SD_VIEW_C", {
          helpCustom: true,
          url: "/codehelp/SD/H_SD_VIEW_C",
          title: "자세히",
          size: 'medium'
        });

        // 파라미터 세팅
        dialog.setInitData({
          preDefinedColumns: sdPreDefinedColumns[code],
          data: data,
          options: options,
          flag: false
        });

        dialog.open(); // 도움창 오픈
        bool = true;
      }
      return bool;
    },
    /*********************************************************************************************
     * @desc   날짜 계산(+, -) 함수
     * @param  {Date/String} date      [필수] 날짜
     * @param  {String}      format    [필수] 날짜포맷 - DT : 날짜&시간 (예: yyyyMMddHHmmss), D : 날짜 (예: yyyyMMdd), M : 월 (예: yyyyMM), Y : 년 (예: yyyy)
     *                                                  DT2 : 날짜&시간 (예: yyyy-MM-dd HH:mm:ss), D2 : 날짜 (예: yyyy-MM-dd), M2 : 월 (예: yyyy-MM)
     * @param  {object}      calculate [필수] 날짜 계산  -  [1, 0, -1] ] - 년도 +1, 월 +0, 일 -1
     * @return {String}      계산된 날짜 반환 ex] - "20200120"
     * @ex     sdJS.com.makeDate(new Date(), 'D');
     * ------------------------------------------------------------------------------------------*/
    makeDate: function(p_date, format, calculate){
      var dataFormat;
      var dataFormat2;
      var flag = true;
      var day2;
      calculate = (calculate == undefined ? [0,0,0] : calculate);
      if(!p_date || !calculate){
        console.error("sdJS - dateMake: 함수 인자가 잘못되었습니다 -");
        return '';
      } else{
        if(format == 'DT' || format == 'D' || format == 'M' || format == 'Y'){ // 날짜포맷 유효성 체크
          dataFormat = dews.getFormatFromAlias(format, flag);
        } else if(format == 'DT2' || format == 'D2' || format == 'M2'){
            if(format == 'DT2') format = 'DT'
            else if(format == 'D2') format = 'D'
            else if(format == 'M2') format = 'M'
            flag = false;
          dataFormat = dews.getFormatFromAlias(format, flag);
        } else {
          console.error("sdJS - dateCalculate: 함수 인자(format)가 잘못되었습니다.", format);
          return '';
        }

        if(typeof p_date === 'object' && p_date instanceof Date){ // date의 타입이 Date
          date = dews.date.format(p_date, dataFormat);
          if(!flag){
            dataFormat2 = dews.getFormatFromAlias(format, !flag);
            day2 = dews.date.format(p_date, dataFormat2);
          }
        } else{
          console.error("sdJS - dateCalculate: 함수 인자(p_date)가 잘못되었습니다.", p_date);
          return '';
        }

        var day;
        var dateChange = [];

        dateChange.push(dews.date.parse(p_date, dataFormat).getFullYear());
        dateChange.push(dews.date.parse(p_date, dataFormat).getMonth());
        dateChange.push(dews.date.parse(p_date, dataFormat).getDate());
        dateChange.push(dews.date.parse(p_date, dataFormat).getHours());
        dateChange.push(dews.date.parse(p_date, dataFormat).getMinutes());
        dateChange.push(dews.date.parse(p_date, dataFormat).getSeconds());

        if(calculate[0]) dateChange[0] += calculate[0]
        if(calculate[1]) dateChange[1] += calculate[1]
        if(calculate[2]) dateChange[2] += calculate[2]

        for(var i=0;i<dateChange.length;i++){
          if(i != 0){
            if(i == 1){
              if(dateChange[i] < 10) dateChange[i] = '0' + (dateChange[i] + 1).toString();
              else dateChange[i] = (dateChange[i] + 1).toString();

              if(flag) day += dateChange[i];

              if(format == 'M') {
                if(!flag) day += dateChange[i];
                break;
              }
              if(!flag) day += dateChange[i] + '-';
            } else {
              if(dateChange[i] < 10) dateChange[i] = '0' + dateChange[i].toString();
              else dateChange[i] = dateChange[i].toString();

              if(flag) day += dateChange[i];
              else {
                if(i <= 3) day += dateChange[i];
                else day += ':' + dateChange[i];
              }

              if(i == 2){
                if(format == 'D') break;
                if(!flag) day += ' '
              }
            }
          } else {
            day = dateChange[i];
            if(format == 'Y') break;
            if(!flag) day = dateChange[i] + '-';
          }
        }
      }
      return day.toString();
    },
    /*********************************************************************************************
     *  @desc  코드피커 master-detail setDetail 관계 정의
     *  @param {Object} master  마스터 코드피커
     *  @param {Object} detail  디테일 코드피커
     *  @ex    폼패널 내 [영업조직>유통경로>제품군] 마스터-디테일 관계가 필요함.
     *         sdJS.com.setDtlCodePicker(dewself.s_salesorgn_cd, dewself.s_disch_cd); //영업조직-유통경로
     *         sdJS.com.setDtlCodePicker(dewself.s_disch_cd, dewself.s_prductgrp_cd); //유통경로-제품군
     * ------------------------------------------------------------------------------------------*/
    setDtlCodePicker :function (master, detail) {
      var prevMaster = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? master.codes().join("|") : master.code();
      master.subDetail = detail;

      var prevObj = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? detail.options.helpParams : {};
      if (prevObj === null) {prevObj = {}}

      if (typeof (master.options.codeField)) {
          var prevAuth = 'auth_' + master.options.codeField.substring(0, master.options.codeField.length-3).toLowerCase();
          if (prevMaster != null && prevMaster != "") {
            prevObj[prevAuth] = prevMaster;
          }
        } else {
          return;
        }
      detail.setHelpParams(prevObj, true);

      /*********************************************************************************
       *  @desc  dews setHelpParams 재정의
       *  @param {Object} params   파라미터
       *  @param {String} flag     상위코드 삭제유무(false:상위코드 삭제되어 하위코드 파라미터 제거)
       * -------------------------------------------------------------------------------*/
      detail.setHelpParams = function (params, flag) {
        if (detail.options.helpParams != null && flag) {
          params = $.extend(params, detail.options.helpParams);
        }
        defineDetailHelpParam = params;
        var self = this;
        self.options.helpParams = params;
      };

      master.on("change", function (e) {
        var obj = detail.options.helpParams === null ? {} : detail.options.helpParams;
        var curMaster = master.wrapper != undefined && $(master.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? master.codes().join("|") : master.code();
        var curDetail = detail.wrapper != undefined && $(detail.wrapper.context).hasClass("dews-ui-multicodepicker") === true ? detail.codes().join("|") : detail.code();

        //master코드설정시, 사전에 설정해놓은 detail/subDetail 코드 있으면 삭제 선행
        clearDetail(detail, detail.subDetail);

        if (typeof param === "string") {
          obj[param] = curMaster
        } else {
          var auth = 'auth_' + master.options.codeField.substring(0, master.options.codeField.length-3).toLowerCase();
          var cd = master.options.codeField.toLowerCase();
          obj[auth] = curMaster;
          obj[cd] = curMaster;
          if(master.options.helpParams !=undefined){
            obj = $.extend(obj, master.options.helpParams); //상위코드의 helpParams도 dtl/subDtl의 파라미터로 선언.
          }
        }
        if (curMaster != prevMaster) {
          console.log(curMaster, prevMaster.length);
          if (curMaster.length <= prevMaster.length) {
            if (detail.target === undefined) {detail.clearData()} else {detail.clearData()};
            clearDetail(detail, detail.subDetail);
          }
        } if(curMaster.length==0){ //master 전체삭제시 detail/subDetail 코드 삭제
          clearDetail(detail, detail.subDetail);
        }
        detail.setHelpParams(obj, true);
        prevMaster = curMaster;
      });

      function clearDetail(detail, subdetail) {
        if (subdetail != undefined) {
          clearDetail(subdetail, subdetail.subDetail);
          if (subdetail.wrapper != undefined && $(subdetail.wrapper.context).hasClass("dews-ui-multicodepicker") === true) {
            detail.clearData(); detail.setHelpParams({}, false);
            subdetail.clearData(); subdetail.setHelpParams({},false);
          } else {
            detail.clearData(); detail.setHelpParams({}, false);
            subdetail.clearData(); subdetail.setHelpParams({},false);
          }
        }
        else {
          if (detail.wrapper != undefined && $(detail.wrapper.context).hasClass("dews-ui-multicodepicker") === true) {
            detail.clearData(); detail.setHelpParams({}, false);
          } else {
            detail.clearData(); detail.setHelpParams({},false);
          }
        }
        return;
      }
    },
  };

  //API
  module.api = {
    /* --------------------------------------------------------------------------------------------
      *  @desc           그리드용 중복체크 함수
      *  @param          - parameters : 테이블 및 컬럼 정보 객체(table_nm, column_cd, column_nm, pk_cd)
      *                    >> 리턴받올 column_nm의 값이 없다면 공백('')으로 넘길것
      *                  - grid       : grid 객체
      *                  - flag       : 1/2/3 - 1: front만 체크, 2: back만 체크, 3:front, back 모두 체크
      *  @return         중복되는 코드가 있을시 : 중복데이터 object(pk_cd, pk_nm)
      *                                 없을시 : null
      *
      *  @ex             var parameters = {               |              var parameters = {
      *                    table_nm: 'IE_ECI_MST',        |               table_nm: 'LE_ROUTE_MST',
      *                    column_cd: 'INVC_NO',          |               column_cd: 'TRNSPROUTE_CD',
      *                    column_nm: '',                 |               column_nm: 'TRNSPROUTE_NM',
      *                    pk_cd: 'INVC-20190709-01'      |                pk_cd: 'SP001'
      *                  };                               |             };
      *
      *                  var result = sdJS.api.dupleChk(parameters, mstGrid, 2);
      * ------------------------------------------------------------------------------------------*/
    dupleChk : function (parameters, grid, flag){
      {
        flag = (flag == undefined ? 3 : flag);
        var result = null; // return 값(null or 객체)
        var table_nm = parameters.table_nm.toUpperCase();
        var column_cd = parameters.column_cd.toUpperCase();
        var column_nm = parameters.column_nm.toUpperCase();
        var pk_cd = parameters.pk_cd;
        var deleted_list = grid.dataSource.getDirtyData().Deleted;
        var grid_list = grid.dataItems();
        var msg = "sdJS - dupleChk 함수의 중복체크를 위한 파라미터가 부족합니다.\n";
      }
      // parameter 누락 체크
      if(!parameters.hasOwnProperty('column_cd')){
        console.error(msg + "parameters.column_cd");
        return null;
      } else if(!parameters.hasOwnProperty('column_nm')){
        column_nm = '';
        // console.error(msg + "parameters.column_nm");
        // return null;
      } else if(!parameters.hasOwnProperty('pk_cd')){
        console.error(msg + "parameters.pk_cd");
        return null;
      } else if(!parameters.hasOwnProperty('table_nm') && (flag == 2 || flag == 3)){
        console.error(msg + "parameters.table_nm");
        return null;
      }
      // Front단 체크
      // - 프론트 그리드 내에서 데이터 중복 체크
      if(flag == 1 || flag == 3){
        if(grid_list.length > 0){
          $.each(grid_list, function(idx, item){
            if(grid.dataItem(grid.select()).__UUID != item.__UUID){ // 자기자신과 비교 X
              if(item[column_cd] == pk_cd){
                result = {
                  pk_cd: item[column_cd],
                  pk_nm: item[column_nm]
                };
                return false;
              }
            }
          });
          if(result){
            return result;
          }
        }
        // - 프론트에서 삭제된 행 중 동일한 코드 있다면 조기 리턴
        if(deleted_list.length > 0){
          $.each(deleted_list, function(idx, item){
            if(item[column_cd] == pk_cd){
              result = null;
              return false;
            }
          });
          if(!result){
            return null;
          }
        }
      }
      // Back단 체크
      if(flag == 2 || flag == 3){
        dews.api.get(dews.url.getApiUrl("SD", "SdCommonService", "SdCommon_DupleChk"), {
          async: false,
          data: {
            table_nm: table_nm,
            column_cd: column_cd,
            column_nm: column_nm == null ? null : column_nm,
            pk_cd: pk_cd
          }
        }).done(function (data) {
          if(data.length > 0){
            // 데이터가 한 개만 있다고 가정(PK)
            result = {
              pk_cd: data[0].PK_CD,
              pk_nm: data[0].PK_NM
            };
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
      }
      return (result ? result : null);
    },
    /* --------------------------------------------------------------------------------------------
      *  @desc           그리드용 중복체크 함수
      *  @param          - parameters : 테이블 및 컬럼 정보 객체(table_nm, column_cd, column_nm, pk_cd)
      *                    >> 리턴받올 column_nm의 값이 없다면 공백('')으로 넘길것
      *                  - grid       : grid 객체
      *                  - flag       : 1/2/3 - 1: front만 체크, 2: back만 체크, 3:front, back 모두 체크
      *  @return         없을시 : 0
      *                  front에서 중복되는 코드가 있을시 :  1
      *                  back에서 중복되는 코드가 있을시 : 2
      *
      *  @ ex  front     var parameters = {
      *                    menuID: 'CLMCMD00400',
      *                    pk_cd: {
      *                      CSF_CD: e.grid.getCellValue(e.grid.select(), 'CSF_CD'),
      *                      TRMT_MANUAL_CD: e.grid.getCellValue(e.grid.select(), 'TRMT_MANUAL_CD')
      *                    }
      *                  };
      *                  var result = sdJS.api.dupleCheck(parameters, self.dtlGrid);
      *
      *        back      => SdCommon_dupleCheck_Enum 클래스에서 [메뉴, 테이블, 칼럼, 칼럼명] 매핑시켜줘야 함
      * ------------------------------------------------------------------------------------------*/
     dupleCheck : function (parameters, grid, flag){
      {
        flag = (flag == undefined ? 3 : flag);
        var result = null;
        var menuID = parameters.menuID;
        var pk_cd = parameters.pk_cd;
        var deleted_list = grid.dataSource.getDirtyData().Deleted;
        var grid_list = grid.dataItems();
        var msg = "sdJS - dupleChk 함수의 중복체크를 위한 파라미터가 부족합니다.\n";
      }
      // parameter 누락 체크
      if(!parameters.hasOwnProperty('menuID') && (flag == 2 || flag == 3)){
        console.error(msg + "parameters.menuID");
        return null;
      }
      // Front단 체크
      // - 프론트 그리드 내에서 데이터 중복 체크
      if(flag == 1 || flag == 3){
        if(grid_list.length > 0){
          $.each(grid_list, function(idx, item){
            if(grid.dataItem(grid.select()).__UUID != item.__UUID){ // 자기자신과 비교 X
              var cnt=0;
              for(var key in pk_cd){
                if(item[key] == pk_cd[key]){
                  cnt++;
                  if(cnt == Object.keys(pk_cd).length){
                    result = 1;
                    return result;
                  }
                }
              }
            }
          });
          if(result){
            return result;
          }
        }
        // - 프론트에서 삭제된 행 중 동일한 코드 있다면 조기 리턴
        if(deleted_list.length > 0){
          $.each(deleted_list, function(idx, item){
            for(var key in pk_cd){
              if(item[key] == pk_cd[key]){
                cnt++;
                if(cnt == Object.keys(pk_cd).length){
                  result = 1;
                  return result;
                }
              }
            }
          });
          if(result){
            return result;
          }
        }
      }

      // Back단 체크
      if(flag == 2 || flag == 3){
        dews.api.post(dews.url.getApiUrl("SD", "SdCommonService", "SdCommon_dupleCheck"), {
          async: false,
          data: {
            menuID: menuID,
            pk_cd: JSON.stringify(pk_cd)
          }
        }).done(function (data) {
          if(data.tp == "F"){
            result = 2;
            var initData = data.errorList;
            dialog = dews.ui.dialog("H_SD_ERROR_C2", {
              url: "/codehelp/SD/H_SD_ERROR_C2",
              title: dews.localize.get("오류메세지", 'D0007709'),
              width: "700",
              height: "300",
              ok: function (d, e) {
              }
            });
            dialog.setInitData(initData);
            dialog.open();
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
      }
      return (result ? result : null);
    },
    /*********************************************************************************************
     *  @desc   데이터소스를 반환
     *  @param  {string}  flag      [필수]어떤 데이터소스를 가져올지 플래그 값
     *  @param  {Boolean} addNull   배열 맨 앞에 공백값 추가 여부
     *  @param  {Object}  params    API에 넘길 파라미터
     *  @param  {Object}  returnArr 단순 배열로 받을 것인지 여부
     *  @return {Object}            데이터소스 객체
     *  @ex     var clasCdDataSource = sdJS.api.getDataSource('DOC_NO', false);
                - 경우에 따라서 addNull, params, returnArr 파라미터는 없어도 됨
                - 해당 데이터에는 clasCdDataSource.options.data로 접근 가능(Array형태)

     ## api 추가시 - 필수 파라미터가 필요하며 누락된 경우, case문에서 apiCall 변수를 false로 줄 것 ##
     * ------------------------------------------------------------------------------------------*/
    getDataSource: function(flag, addNull, params, returnArr){
      var returnDataSource;  // 최종 리턴 데이터소스
      var apiCall = true;    // api호출/비호출 제어를 위한 변수
      var resultArray  = []; // 리턴될 배열
      var dataSourceName = ''; // 리턴될 데이터소스의 명칭
      returnArr = returnArr || false; // 단순 배열로 반환할 것인지 여부값

      // API 변수
      var module_cd = '';
      var serviceName = '';
      var url = '';

      // 넘어온 파라미터값 없으면 빈객체로 초기화
      if(params && !(typeof params == 'object')){
        apiCall = false;
        console.error("sdJS - getDataSource 함수의 파라미터[params]가 object형이 아닙니다.");
      }
      params = params || {};

      // 공백 객체 추가 여부 - 파라미터 없으면 false로 초기화
      addNull = addNull ? true : false;

      /*********************** api분기 *********************/

      switch(flag){
        case 'SO': // 수주유형 - BIZ_DOC_CTGRY_CD를 PARAM으로 받는 API로 수정?
        case 'SO_TP':{
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_SD_SODTYPE_MST_integration";
          dataSourceName = 'soTpCdDataSource';
          break;
        }
        case 'DLV': // 납품유형
        case 'DLV_TP':{
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SD_DLVTYPE_INFO_list';
          dataSourceName = 'dlvTpDataSource';
          break;
        }
        case 'GI': // 출고유형
        case 'GI_TP':{
          // params.gubun = (params.hasOwnProperty('gi_tp') ? params.gi_tp : '');
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SD_GITYPE_INFO_list';
          dataSourceName = 'giTpDataSource';
          break;
        }
        case 'BIL': // 매출유형
        case 'BIL_TP':{
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SD_BILTYPE_INFO_list';
          dataSourceName = 'billTpDataSource';
          break;
        }
        case 'CMNY_TP': // 수금유형 - 파라미터 없을시 전체 조회
        case 'CMNY_INFO':{
          params.gubun      = (params.hasOwnProperty('gubun')      ? params.gubun      : ''); // 메뉴ID[dewself.menu.id]
          params.cmny_tp_cd = (params.hasOwnProperty('cmny_tp_cd') ? params.cmny_tp_cd : ''); // 수금유형코드
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_SD_CMNYTYPE_MST';
          dataSourceName = 'cmnyTpDataSource';
          break;
        }
        case 'CMNY_INFO_new':{ // 수금유형 - 수금종류코드로 조회시 사용
          params.gubun      = (params.hasOwnProperty('gubun')      ? params.gubun      : ''); // 메뉴ID[dewself.menu.id]
          params.cmny_tp_cd = (params.hasOwnProperty('cmny_tp_cd') ? params.cmny_tp_cd : ''); // 수금유형코드
          params.cmny_knd_cd = (params.hasOwnProperty('cmny_knd_cd') ? params.cmny_knd_cd : ''); // 수금종류코드
          params.cmny_fg_cd = (params.hasOwnProperty('cmny_fg_cd') ? params.cmny_fg_cd : ''); // 수금구분코드
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_SD_CMNYTYPE_MST_new';
          dataSourceName = 'cmnyTpDataSource';
          break;
        }
        case 'EC': // EC유형
        case 'EC_TP':{
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_SD_ECTYPE_MST';
          dataSourceName = 'ecTpDataSource';
          break;
        }
        case 'DOC_NO':{ // 자동채번 - module_cd_multi를 파라미터로 받는 API(파라미터 없을시 전모듈 조회)
          params.module_cd_multi = (params.hasOwnProperty('module_cd_multi') ? params.module_cd_multi : '');
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'MA_DOCUCTRL_MST_list_by_params';
          dataSourceName = 'clasCdDataSource';
          break;
        }
        case 'DOC_NO2':{ // 자동채번 - 'SD' 모듈의 채번규칙만 가져옴
          params = {}; // 해당 API의 파라미터 고정
          module_cd   = 'SD';
          serviceName = 'SalesImplementationGuideORTService';
          url         = 'MA_DOCUCTRL_MST_list';
          dataSourceName = 'sdClasCdDataSource';
          break;
        }
        case 'MA_PC':{ // 회계단위
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_MA_PC_MST';
          dataSourceName = 'pcCdDataSource';
          break;
        }
        case 'PRTNRFN_INFO':{ // 영업거래처형태
          if(!params.partner_cd){ // 필수값
            apiCall = false;
            console.error("sdJS - getDataSource[PRTNRFN_INFO] 함수의 파라미터[partner_cd]가 부족합니다.");
            break;
          } else{
            params.partner_cd  = (params.hasOwnProperty('partner_cd')  ? params.partner_cd  : ''); // 거래처코드
            params.use_yn      = (params.hasOwnProperty('use_yn')      ? params.use_yn      : ''); // 사용여부
            params.prtnr_fn_cd = (params.hasOwnProperty('prtnr_fn_cd') ? params.prtnr_fn_cd : ''); // 거래처형태
          }
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_MA_PARTNERFN_INFO';
          dataSourceName = 'prtnrFnDataSource';
          break;
        }
        case 'SAORG_INFO':{ // 영업조직 리스트
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_MA_SAORG_MST";
          dataSourceName = 'saorgCdDataSource';
          break;
        }
        case 'SAOFF_INFO':{ // 사업부 리스트 - 영업영역에 속한 사업부
          params.salesorgn_cd = (params.salesorgn_cd ? params.salesorgn_cd : '');
          params.disch_cd     = (params.disch_cd     ? params.disch_cd     : '');
          params.prductgrp_cd = (params.prductgrp_cd ? params.prductgrp_cd : '');
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_MA_AREAOFF_MST";
          dataSourceName = 'saoffCdDataSource';
          break;
        }
        case 'SALEGRP_INFO':{ // 영업그룹 리스트 - 영업영역에 속한 영업그룹만
          params.salesorgn_cd = (params.salesorgn_cd ? params.salesorgn_cd : '');
          params.disch_cd     = (params.disch_cd     ? params.disch_cd     : '');
          params.prductgrp_cd = (params.prductgrp_cd ? params.prductgrp_cd : '');
          params.saoff_cd     = (params.saoff_cd     ? params.saoff_cd     : '');
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_MA_OFFSGRP_MST";
          dataSourceName = 'salegrpCdDataSource';
          break;
        }
        case 'PAY_INFO':{ // 결제조건마스터
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_MA_PAYMENT_MST";
          dataSourceName = 'terpayCdDataSource';
          break;
        }
        case 'COMM_INFO':{ // 회사환경설정 - 자리수통제 리스트
          module_cd   = 'IM';
          serviceName = 'SCMCommonService';
          url         = "SCMApiProvider_MA_COMMON_CODE_list";
          dataSourceName = 'commonCodeDataSource';
          break;
        }
        case 'IF_INFO':{ // 연동시스템 마스터 중, 해당 RELATION_CD를 갖고있는 데이터 조회(PIPE 다중선택('|'))
          params.relation_cd = module.com.replaceNull(params.relation_cd);
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = "SdCommon_CI_SYSTEMIF_MST";
          dataSourceName = 'intlSysCdDataSource';
          break;
        }
        case 'CTRL_CONFIG':{ // module_cd 파라미터 없을시, 'MA'로 가져옴
          params.module_cd = module.com.replaceNull(params.relation_cd, 'MA');
          params.ctrl_cd_pipe = module.com.replaceNull(params.ctrl_cd_pipe);
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_MA_CTRLCONFIG';
          dataSourceName = 'ctrlConfigDataSource';
          break;
        }
        case 'ACCGRP_INFO':{ // 계정처리유형-포스팅유형 리스트
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_getMA_ACCGRP_MST';
          dataSourceName = 'accgrpPostingTpCdDataSource';
          break;
        }
        case 'YN': { // YES/NO 데이터소스
          apiCall = false;
          dataSourceName = 'ynUseDataSource';
          resultArray = [
            { SYSDEF_CD: 'Y', SYSDEF_NM: 'Yes' },
            { SYSDEF_CD: 'N', SYSDEF_NM: 'No'  }
          ];
          break;
        }
        case 'CREDIT_GRP_CD': { // 여신그룹 리스트 (영업거래처등록 메뉴(MA)에서도 사용됨)
          module_cd   = 'SD';
          serviceName = 'SdCommonService';
          url         = 'SdCommon_SD_CREDITGRP_INFO';
          dataSourceName = 'creditGrpCdDataSource';
          break;
        }
        default :{
          apiCall = false;
          console.error("sdJS - getDataSource 함수 인자의 구분값이 잘못되었습니다. flag : ", flag);
          break;
        }
      }
      /*********************** api분기 끝 *********************/

      // ynDataSource가 아니고 api를 태울 필수값을 충족하지 않을시, 리턴할 데이터 세팅
      if(!flag == 'YN' && !apiCall){
        dataSourceName = 'null';
        resultArray = [];
      }

      // API호출 - flag값이 넘어왔으며 API를 호출해야할 경우에만
      if(flag && apiCall && (module_cd || serviceName || url)){
        dews.api.get(dews.url.getApiUrl(module_cd, serviceName, url), {
          async: false,
          data: params
        }).done(function (data) {
          resultArray = data;
        }).fail(function (xhr, status, error) {
          dews.error(error || "데이터소스 호출에 실패했습니다.");
        });
      } else if(flag && apiCall && (!module_cd || !serviceName || !url)){
        console.error("sdJS - getDataSource 함수의 api를 호출할 수 없습니다.");
        if(!module_cd){console.error("- module_cd 없음");}
        if(!serviceName){console.error("- serviceName 없음");}
        if(!url){console.error("- url 없음");}
      }

      // 공백객체 추가
      if(addNull && resultArray.length){module.com.addNullObject(resultArray);}

      // 데이터소스 생성
      if(!returnArr){
        returnDataSource = dews.ui.dataSource(dataSourceName, {
          data: ( resultArray && Array.isArray(resultArray) && resultArray.length > 0 ? resultArray : [] )
        });
      } else{ // 단순 배열로 리턴
        returnDataSource = resultArray;
      }

      return returnDataSource;
    },
    getCreditBalance: function(ctrl_time_cd, credit_no, saleprtn_cd, exch_cd){
      var returnData;
      if(ctrl_time_cd && credit_no){
        dews.api.get(dews.url.getApiUrl("SD", "SdCommonService", "SdCommon_getCreditBalanceInfo"), {
          async: false,
          data: {
            ctrl_time_cd: ctrl_time_cd,
            credit_no: credit_no,
            saleprtn_cd: saleprtn_cd,
            exch_cd: exch_cd
          }
        }).done(function (data) {
          returnData = data;
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get("여신잔액 조회중 에러가 발생하였습니다."));
          return [];
        });
      }else{
        if(!ctrl_time_cd){
          dews.ui.snackbar.warning("여신통제시점코드가 없습니다.");
          return [];
        }else if(!credit_no){
          dews.ui.snackbar.warning("여신관리번호가 없습니다.");
          return [];
        }
      }
      return returnData;
    },
    /*********************************************************************************************
     *  @desc   파라미터로 받은 날짜를 결제조건(MA_PAYMENT_MST)에 따라 계산하여 반환
     *  @param  {String} terpay_cd   [필수] 결제조건 코드
     *  @param  {String} std_dt      [필수] 계산될 날짜. String 또는 Date
     *  @param  {String} calendar_yn 카렌다 사용여부(없을시 기본값 'Y')
     *  @return {String} 계산된 날짜
     *  @ex     var dt = sdJS.api.getPaymentDate('C000', '20200101', 'N');
     * ------------------------------------------------------------------------------------------*/
    getPaymentDate: function(terpay_cd, std_dt, calendar_yn){
      var rtn_date = ""; // 리턴값.
      var param_date = (typeof std_dt === 'object' && std_dt instanceof Date) ? dews.date.format(std_dt, 'yyyyMMdd') : std_dt;
      calendar_yn = module.com.isNull(calendar_yn) ? 'Y' : calendar_yn; // 없을시 기본값 'Y'
      if(module.com.isNull(terpay_cd) || module.com.isNull(std_dt)){
        console.error("sdJS - getPaymentDate: 함수 인자가 부족합니다.");
      } else if(!(typeof param_date === 'string' && param_date.length === 8 && param_date !== "")){
        console.error("sdJS - getPaymentDate: 날짜 파라미터가 부적절합니다.", std_dt);
      } else{
        dews.api.get(dews.url.getApiUrl("SD", "SdCommonService", "SdCommon_getPaymentDate"), {
          async: false,
          data: {
            terpay_cd   : terpay_cd,
            std_dt      : param_date,
            calendar_yn : calendar_yn
          }
        }).done(function (data) {
          rtn_date = data;
        }).fail(function(xhr, status, error){
          rtn_date = "";
          console.error("sdJS - getPaymentDate: 일치하는 결제조건코드가 없습니다.", terpay_cd);
        });
        return rtn_date;
      }
    },
    /*********************************************************************************************
     *  @desc   사용자 부가정보를 가져와 sdJS.user에 세팅.
     * ------------------------------------------------------------------------------------------*/
    getUserInfo: function(){
      dews.api.get(dews.url.getApiUrl("SD", "SdCommonService", "SdCommon_UserInfo"), {
        async: false,
        data: {}
      }).done(function (data) {
        if(data && data.length === 1){
          module.user = data[0];
        }
      }).fail(function(xhr, status, error){
        console.error("sdJS - getUserInfo: 사용자 부가정보 조회에 실패했습니다.");
      });
    },
    /*********************************************************************************************
     *  @desc  임시테이블번호 채번
     *  @param {String}   gubun    구분값(ex. 납품- DLV, 출고 GI)
     *  @return {String} 임시번호
     *  @ex  sdJS.api.getTmpDocNo("GI");
     * ------------------------------------------------------------------------------------------*/
    getTmpDocNo: function (gubun) {
      var tmpDocNo = "";
      dews.api.get(dews.url.getApiUrl("SD", "SdCommonWebSocketService", "getTmpDocNo"), {
        async: false,
        data: {
          gubun: gubun,
        }
      }).fail(function (xhr, status, error) {
        dews.error(error || "채번을 생성할 수 없습니다.");
      }).done(function (data) {
        if (data) {
          tmpDocNo = data;
        }
      });
      return tmpDocNo;
    },
    /*********************************************************************************************
     *  @desc  임시테이블번호 삭제
     *  @param {String}   gubun    구분값(ex. 납품- DLV, 출고 GI)
     *  @return {String} 임시번호
     *  @ex  sdJS.api.deleteTmpDocNo("TGI01","GI");
     * ------------------------------------------------------------------------------------------*/
    deleteTmpDocNo: function (tmpDocNo, gubun) {
      dews.api.post(dews.url.getApiUrl("SD", "SdCommonWebSocketService", "tmpDocNo_delete"), {
        async: false,
        data: {
          tmpDocNo: tmpDocNo,
          gubun: gubun
        }
      }).done(function () {
      }).fail(function (xhr, status, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
      });
    }
  };

 //공통 - BAFSDC (여신관리)
 module.bafsdc = {
  /*********************************************************************************************
   *  @desc  (여신관리) 여신통제시점, 여신통제방법, 여신정보테이블 조회 ▶ 라벨 텍스트 셋팅 ▶ 여신정보테이블 코드피커 셋팅
   *  @param {String}  strCreditGrpCd  여신그룹코드
   *  @param {Object}  objSelf         호출되는 메뉴의 this
   *  @return none
   *  @ex  sdJS.bafsdc.getCreditGrpInfo(dewself.s_credit_grp_cd.value(), dewself);
   * ------------------------------------------------------------------------------------------*/
  getCreditGrpInfo: function(strCreditGrpCd, objSelf){
    try{
      if(strCreditGrpCd){
        dews.api.get(dews.url.getApiUrl("SD", "SdCommonService", "SdCommon_SD_CREDITGRP_INFO_ctrl"), {
          async: false,
          data: {
            credit_grp_cd : strCreditGrpCd
          }
        }).done(function (data) {
          if(data.length > 0){
            if(data[0].COND_TABLE_NO == null || data[0].COND_TABLE_NO == ""){
              dews.alert('여신정보테이블 데이터가 없습니다. \r\n여신그룹등록 메뉴에서 등록해주세요.', 'warning');
              return false;
            }
            dews.localize.load(dews.localize.language(), 'BAFSDC00100').always(function() { //타메뉴에서 다국어 변환하기 위함(ex : BAFSDC00200...)
              eval('lbl_time_'+objSelf.menu.id).innerText  = dews.localize.get('여신통제시점', 'D0006428','','BAFSDC00100')+ ': ' + data[0].CTRL_TIME_NM + " | ";
              eval('lbl_method_'+objSelf.menu.id).innerText  = dews.localize.get('여신통제방법', 'D0006429','','BAFSDC00100')+': ' + data[0].CTRL_MTHD_NM;

              objSelf.s_cond_table_no.setData({ COND_TABLE_NO: data[0].COND_TABLE_NO, PRC_TABLE_DC: data[0].PRC_TABLE_DC }); //여신정보테이블 셋팅
              module.slsspn.setCondition(module.bafsdc.getSearchElementInfo(data[0].COND_TABLE_NO)); //컨디션패널 셋팅

              dews.ui.mainbuttons.search.click(); //조회
            });
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get(dews.localize.get("작업이 실패하였습니다.", "M0000055")));
        });
      }
    }catch(e){
      dews.alert('여신부가정보 조회 도중 오류가 발생했습니다.','warning');
      return false;
    }
  },
  /*********************************************************************************************
   *  @desc   (여신관리) 조건테이블에 등록된 여신요소 조회
   *  @param  {String}  strCondTableNo     여신정보테이블 코드
   *  @return {Arrays}
   *  @ex  sdJS.bafsdc.getSearchElementInfo(dewself.s_cond_table_no.code())
   * ------------------------------------------------------------------------------------------*/
  getSearchElementInfo: function (strCondTableNo){
    try{
      var arrRtnColumns = []; //리턴용 배열
      if(strCondTableNo){
        dews.api.get(dews.url.getApiUrl("SD", "BasicFunctionsandMasterDataSDCService", "bafsdc_element_info_list"), {
          async: false,
          data: {
            cond_table_no: strCondTableNo
          }
        }).done(function (data) {
          if(data.length>0){
            arrRtnColumns = data;
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get(dews.localize.get("작업이 실패하였습니다.", "M0000055")));
        });
      }
      return arrRtnColumns;
    }catch(e){
      dews.alert('여신요소 조회 도중 오류가 발생했습니다.','warning');
      return false;
    }
  },
  /*********************************************************************************************
   *  @desc   (여신관리) 조건테이블에 등록된 여신요소 조회 ▶ 배열변수 생성 및 리턴 (grid 컬럼 동적으로 생성하기 위함)
   *  @param  {String}  strCondTableNo      여신정보테이블 코드
   *  @param  {Boolean} boolSetArea         optional-aera 셋팅 여부
   *  @param  {String}  strMenuId           메뉴ID
   *  @return {Arrays}
   *  @ex  sdJS.bafsdc.getElementInfo(dewself.s_cond_table_no.code(), true, dewself.menu.id)
   * ------------------------------------------------------------------------------------------*/
  getElementInfo: function (strCondTableNo, boolSetArea, strMenuId){
    try{
      var arrRtnColumns = []; //리턴용 배열
      if(strCondTableNo){
        var arrElementInfo = module.bafsdc.getSearchElementInfo(strCondTableNo);
        if(arrElementInfo){
          if(boolSetArea){ //case 1 : optional-aera셋팅함
            if(!strMenuId){
              dews.alert('그리드 컬럼셋팅을 위한 \r\n여신요소 조회에 실패하였습니다.','warning');
              return false;
            }
            $.each(arrElementInfo, function (index, item){
              arrRtnColumns.push({ field : item.ELEMENT_FIELD_CD_RE , title : item.ELEMENT_FIELD_NM, align: "left"});
            });
          }else{ //case 2 : optional-aera셋팅안함
            $.each(arrElementInfo, function (index, item){
              arrRtnColumns.push({ field : item.ELEMENT_FIELD_CD_RE , title : item.ELEMENT_FIELD_NM, align: "left", attributes: { class: "readonly" } });
            });
          }
        }
      }
      return arrRtnColumns;
    }catch(e){
      dews.alert('여신요소 생성중 오류가 발생했습니다.','warning');
      return false;
    }
  }
};

//공통 - BILCMM (수금관리)
module.bilcmm = {
  /*********************************************************************************************
   *  @desc  (수금관리) 수금관련 GRID 컬럼 리셋 공통함수 (colArr배열 startIdx 이후의 모든 컬럼 리셋처리)
   *  @param {Object}  objSelf            호출되는 메뉴의 this
  *   @param {String}  strStartFieldNm    기준이 되는 컬럼 이름
   *  @return none
   *  @ex  sdJS.bilcmm.setCellValueInit(self, e.cell.field);
   * ------------------------------------------------------------------------------------------*/
  setCellValueInit: function(objSelf, strStartFieldNm){
    try{
      var colArr = [  'STLM_MTHD_CD',    /*결제방법코드*/   'STLM_MTHD_NM',    /*결제방법명*/
                      'CMNY_ACCT_CD',    /*수금계정코드*/   'CMNY_ACCT_NM',    /*수금계정명*/
                      'CMNY_MNG_NO',     /*수금관리번호*/   'CMNY_MNG_NO_TXT', /*수금관리번호텍스트*/
                      'NATION_CD',       /*국가코드*/       'BANK_CD',         /*은행코드*/
                      'FNLT_NM',         /*금융기관명*/     'FINPRODUCT_FG',   /*금융상품구분*/
                      'FNCPARTNER_CD',   /*금융기관코드*/   'FNCPARTNER_NM',   /*금융기관명*/
                      'FINPRODUCT_NO',   /*금융계좌번호*/   'SELF_ISSUE_YN',   /*자수*/
                      'ISSUE_ISTN_CD',   /*발행기관코드*/   'ISSUE_ISTN_NM',   /*발행기관명*/
                      'PBLISR_NM',       /*발행인*/         'BIL_ST',          /*어음상태*/
                      'BIL_ISSUE_DT',    /*어음발행일*/     'EXPRTN_DT',       /*만기일*/
                      'EXPRTN_DY',       /*어음기간*/       'FNCPARTNER_NM_HELP' /*금융거래처코드피커*/
                    ];
      var startIdx = -1; //startIdx 이후의 모든 컬럼 리셋처리
      var gridDsFields = objSelf.mstGrid.dataSource.options.schema.model.fields;
      $.each(colArr, function (index, item){
        if(startIdx > -1){
          var gridColumn = gridDsFields.filter(function(e) {return e && e.field == item;});
          if ((gridColumn || '') != ''){
            objSelf.mstGrid.setCellValue(objSelf.mstGrid.select(), item, '', false);
          }
        }
        if(startIdx == -1 && item == strStartFieldNm){
          startIdx = index;
        }
      });
    }catch(e){
      dews.alert('그리드 컬럼 초기화 작업 도중 오류가 발생했습니다.','warning');
      console.log(e);
      return false;
    }
  },
  /*********************************************************************************************
   *  @desc  (수금관리) 어음기간 계산
   *  @param {Object}  objSelf         호출되는 메뉴의 this
  *   @param {String}  strFieldNm      기준이 되는 컬럼 이름
   *  @return none
   *  @ex  sdJS.bilcmm.setCellValueInit(self, e.cell.field);
   * ------------------------------------------------------------------------------------------*/
  calcExprtnDt: function(strCmnyDt, strExprtnDt){
    try{
      var fDate = dews.date.format( strCmnyDt,   'yyyy-MM-dd').split("-");
      var tDate = dews.date.format( strExprtnDt, 'yyyy-MM-dd').split("-");
      var dateObjFrom = new Date(fDate[0], Number(fDate[1])-1, fDate[2]);
      var dateObjTo = new Date(tDate[0], Number(tDate[1])-1, tDate[2]);
      var betweenDay = (dateObjTo.getTime() - dateObjFrom.getTime())/1000/60/60/24;

      return Math.round(betweenDay);
    }catch(e){
      dews.alert('어음기간 계산 도중 오류가 발생했습니다.','warning');
      console.log(e);
      return false;
    }
  },
  /*********************************************************************************************
   *  @desc  (수금관리) 그리드 유효검사 (1~7)
   *  @param {Object}   objSelf    호출되는 메뉴의 this
   *  @param {Object}   item       유효검사 대상이 되는 그리드 행의 객체
   *  @param {Number}   index      유효검사 대상이 되는 그리드 seq
   *  @return Boolean
   *  @ex  sdJS.bilcmm.validationGridBilcmm(item, 0, self);
   * ------------------------------------------------------------------------------------------*/
  validationGridBilcmm: function(item, index, objSelf){
    try{
      var rtnObj = {}; //리턴용 객체

      //1. 결제방법
      if(!item.STLM_MTHD_CD){
        dews.alert(index+1+" 번째 행의 결제방법은 필수값 입니다.","warning");
        objSelf.mstGrid.select(index, 'STLM_MTHD_NM');
        return false;
      }

      //2. 수금계정
      if(!item.CMNY_ACCT_CD){
        dews.alert(index+1+" 번째 행의 수금계정은 필수값 입니다.","warning");
        objSelf.mstGrid.select(index, 'CMNY_ACCT_NM');
        return false;
      }

      //3. 수금관리번호 (결제방법 in ('12'(예금(뱅킹)),'13'(예금(자동이체)),'15'(어음),'16'(전자어음))일때
      if((item.STLM_MTHD_CD == '12' || item.STLM_MTHD_CD == '13'|| item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && !item.CMNY_MNG_NO){
        dews.alert(index+1+" 번째 행의 수금관리번호는 필수값입니다.","warning");
        if(item.STLM_MTHD_CD == '12' || item.STLM_MTHD_CD == '13'){
          objSelf.mstGrid.select(index, 'CMNY_MNG_NO');
        }else{
          objSelf.mstGrid.select(index, 'CMNY_MNG_NO_TXT');
        }
        return false;
      }

      //4. 자수 (결제방법 in ('15'(어음),'16'(전자어음))일때
      if((item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && (!item.SELF_ISSUE_YN)){
        dews.alert(index+1+" 번째 행의 자수는 필수값입니다.","warning");
        objSelf.mstGrid.select(index, 'SELF_ISSUE_YN');
        return false;
      }

      //5. 발행기관 (결제방법 in ('15'(어음),'16'(전자어음))일때
      if((item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && (!item.ISSUE_ISTN_NM)){
        dews.alert(index+1+" 번째 행의 발행기관은 필수값입니다.","warning");
        objSelf.mstGrid.select(index, 'ISSUE_ISTN_NM');
        return false;
      }

      //6. 발행인 (결제방법 in ('15'(어음),'16'(전자어음))일때
      if((item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && (!item.PBLISR_NM)){
        dews.alert(index+1+" 번째 행의 발행인은 필수값입니다.","warning");
        objSelf.mstGrid.select(index, 'PBLISR_NM');
        return false;
      }

      //7. 만기일 (결제방법 in ('15'(어음),'16'(전자어음))일때
      if((item.STLM_MTHD_CD == '15' || item.STLM_MTHD_CD == '16') && (!item.EXPRTN_DT)){
        dews.alert(index+1+" 번째 행의 만기일은 필수값입니다.","warning");
        objSelf.mstGrid.select(index, 'EXPRTN_DT');
        return false;
      }

      return true;
    }catch(e){
      dews.alert('수금관리 그리드 유효검사 도중 오류가 발생했습니다.','warning');
      console.log(e);
      return false;
    }
  }
};

//공통 - SPSSPN (판매계획)
module.slsspn = {
  /*********************************************************************************************
   *  @desc  (판매계획) 계획조건등록에 등록된 필드를 기준으로 컨디션, 그리드 세팅
   *  @param
   *  @param
   *  @return none
   * ------------------------------------------------------------------------------------------*/
  getPlanElementInfo: function(value){
    var arrElement = [];

    // 계획조건등록 데이터 조회
    dews.api.get(dews.url.getApiUrl("SD", "SalesSPNService", "get_sd_planelemt_info_for_front_common"), {
      async: false,
      data: {
        cond_table_no: value
      }
    }).done(function (data) {
      arrElement = data;
    }).fail(function (xhr, status, error) {
      dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
    });
    return arrElement;
  },
  setPlanCondition: function(value, isRequired){
    var arrElement = this.getPlanElementInfo(value);

    if(arrElement.length == 0){
      return false;
    }
    this.setCondition(arrElement);

    var arrColumns = this.setGrid(arrElement, isRequired);

    return arrColumns;
  },
  setCondition: function(arr){
    var self = dews.ui.page;

    // optional-area랜더링을 위해 코딩된 부분 삭제.
    self.find('.dews-ui-condition-panel ul.optional-area').children().remove();

    $.each(arr, function(idx, data){
      var $li = $("<li></li>");
      var $label = $("<label>" + data.ELEMENT_FIELD_NM + "</label>");
      var html = '';
      var excute_func;

      // 커스텀관련
      var nameField = '';
      var apiUrl = '';
      var helpSize = '';
      var custom = false;

      switch (data.HWND_FG) {
        case '1':
          excute_func = dews.ui.dropdownlist;

          // 데이터소스 생성
          var codeData = scmJS.api.getCodeData(data.MODULE_CD, data.COMM_FIELD_CD);
          var codeDataSourceName = data.MODULE_CD + '_' + data.COMM_FIELD_CD + 'dataSource';
          scmJS.com.addNullObject(codeData[data.COMM_FIELD_CD]);
          var dropDownDataSource =  dews.ui.dataSource(codeDataSourceName, {
            data: codeData[data.COMM_FIELD_CD]
          });

          html += "<span>";
          html += "<select id=\'" + data.ELEMENT_FIELD_CD + "\'";
          html += "data-dews-value-field=\'SYSDEF_CD\' data-dews-text-field=\'SYSDEF_NM\'";
          html += "data-custom-dynamic-field=\'" + data.ELEMENT_FIELD_CD + "\'";
          html += "data-custom-bizdoc-ctgry-cd=\'" + '' + "\'";
          html += "data-custom-doctp-cd=\'" + '' + "\'";
          html += "data-dews-bind-value=\'" + data.ELEMENT_FIELD_CD + "\'/>";
          html += "</span>";

          break;
        case '2':
          excute_func = dews.ui.codepicker;

          custom = false;

          html += "<span>";
          html += "<input type=\'text\' id=\'" + data.ELEMENT_FIELD_CD + "\'";
          html += "data-dews-help-code=\'H_MA_CODEDTL_S\'";
          html += "data-dews-code-field=\'SYSDEF_CD\' data-dews-text-field=\'SYSDEF_NM\'";
          html += "data-dews-help-title=\'" + data.ELEMENT_FIELD_NM + "\'";
          html += "data-dews-help-params='module_cd=" + data.MODULE_CD + "&&field_cd=" + data.COMM_FIELD_CD + "\'";
          html += "data-dews-help-custom=\'" + custom +  "\'" ;
          html += "data-dews-help-size=\'medium\'";
          html += "data-custom-dynamic-field=\'" + data.COMM_FIELD_CD + "\'";
          //html += "data-custom-bizdoc-ctgry-cd=\'" +  + "\'";
          //html += "data-custom-doctp-cd=\'" +  + "\'";
          html += "data-dews-bind-code=\'" + data.ELEMENT_FIELD_CD + "\'";
          html += "data-dews-bind-text=\'" + data.ELEMENT_FIELD_NM + "\'";
          html += "data-dews-bind-value=\'" + data.ELEMENT_FIELD_CD + "\'/>";
          html += "</span>";
          $span = $(html);

          break;

        case '3':
          excute_func = dews.ui.codepicker;

          custom = true;

          switch (data.HWND_ID_CD) {
            case 'H_SD_MA_ITEM_C':
              nameField = 'ITEM_NM';
              apiUrl = '~/api/SD/SDCustomCodeHelpService/SD_ITEM_CD_list';
              helpSize = 'big';
              break;

            case 'H_SD_SALESORGN_CD_C':
              nameField = 'SALESORGN_NM';
              apiUrl = '';
              helpSize = 'big';
              break;

            case 'H_SD_MA_PARTNER_MST_S':
              nameField = 'PARTNER_NM';
              custom = false;
              apiUrl = '';
              helpSize = 'big';
              break;

            case 'H_HR_EMP_MST_S01':
              nameField = 'KOR_NM';
              custom = false;
              apiUrl = '';
              helpSize = 'big';
              break;

            case 'H_MA_BIZAREA_MST_S':
              nameField = 'BIZAREA_NM';
              custom = false;
              apiUrl = '';
              helpSize = 'big';
              break;
          }

          html += "<span>";
          html += "<input type=\'text\' id=\'" + data.ELEMENT_FIELD_CD + "\'";
          html += "data-dews-help-code=\'" + data.HWND_ID_CD + "\'";
          html += "data-dews-code-field=\'" + (data.HWND_ID_CD == "H_HR_EMP_MST_S01"? "EMP_NO" : data.ELEMENT_FIELD_CD) + "\' data-dews-text-field=\'" + nameField + "\'";
          html += "data-dews-help-title=\'" + data.ELEMENT_FIELD_NM + "\'";
          html += "data-dews-help-params=\'\'";
          html += "data-dews-help-view-url='~/codehelp/" + data.MODULE_CD + "/" + data.HWND_ID_CD + "'";
          html += "data-dews-help-api-url=\'" + apiUrl + "\'";
          html += "data-dews-help-custom=\'" + custom +  "\'" ;
          html += "data-dews-help-size=\'" + helpSize +  "\'" ;
          html += "data-custom-dynamic-field=\'" + data.COMM_FIELD_CD + "\'";
          html += "data-custom-bizdoc-ctgry-cd=\'\'";
          html += "data-custom-doctp-cd=\'\'";
          html += "data-dews-bind-code=\'" + data.ELEMENT_FIELD_CD + "\'";
          html += "data-dews-bind-text=\'" + data.ELEMENT_FIELD_CD + "_NM\'";
          html += "data-dews-bind-value=\'" + data.ELEMENT_FIELD_CD + "\'/>";
          html += "</span>";
          $span = $(html);
          break;
      }

      $li.append($label);
      $li.append('\n');
      $li.append(html);

      $(self[self.find('.dews-ui-condition-panel')[0].id]._element).find('ul.optional-area').append($li);
      self[data.ELEMENT_FIELD_CD] = excute_func(self.$content.find('#' + data.ELEMENT_FIELD_CD));

      // 드롭다운 데이터소스 설정
      if(data.HWND_FG == '1'){
        self[data.ELEMENT_FIELD_CD].setDataSource(dropDownDataSource);
      }
    });
  },
  setGrid: function(arr, isRequired, isEditable){
    var self = dews.ui.page;
    var grid = self[self.find('.dews-ui-grid')[0].id];
    var arrColumns = this.setGridColumns(grid, arr, isRequired, isEditable);

    return arrColumns;
  },
  setGridColumns: function(grid, arr, isRequired, isEditable){
    var menu_id = dews.ui.page.menu.id;
    var arrColumns = [];
    var gridDataSource = grid && grid.dataSource ? grid.dataSource : grid.dataSource.options._baseDataSource;
    var inputMaxLength = 2000; // 저장테이블 컬럼 LENGTH.
    var required = isRequired? 'required' : '';
    var isEditable = isEditable == undefined ? true : isEditable;

    // 그리드 초기화
    grid.setColumns([]);

    $.each(arr, function(idx, data){
      var field_id = data.ELEMENT_FIELD_CD;
      var field_id_nm = field_id + '_NM'; // 그리드-코드피커전용
      var field_title = data.ELEMENT_FIELD_NM;
      var dataSourceArr = [];

      // 컬럼속성 정의
      var align = 'left';
      var formats = {};
      var editor = {};
      var dropDownDataSource;

      switch (data.HWND_FG) {
        case '1': //공통코드 콤보
          dataSourceArr.push(
            {field : field_id, dataType: 'text'},
            {field : field_id_nm, dataType: 'text'}
          );
          align = 'left';

          // 드롭다운리스트 데이터소스
          var codeData = scmJS.api.getCodeData(data.MODULE_CD, data.COMM_FIELD_CD);
          var codeDataSourceName = data.MODULE_CD + '_' + data.COMM_FIELD_CD + 'dataSource';
          dropDownDataSource =  dews.ui.dataSource(codeDataSourceName, {
            data: codeData[data.COMM_FIELD_CD]
          });
          editor = {
            type: 'dropDown',
            dataSource: dropDownDataSource,
            dataValueField: 'SYSDEF_CD',
            dataTextField: 'SYSDEF_NM',
            editable: function (e) { return isEditable ? (grid.getRowState(e.row.index) == "added" ? true : false) : isEditable}
          };
          break;

        case '2': //공통코드 코드피커
          dataSourceArr.push(
            {field : field_id,    dataType: 'text'},
            {field : field_id_nm, dataType: 'text'}
          );
          align = 'left';

          editor = {
            type: 'codepicker',
            helpCode: 'H_MA_CODEDTL_S',
            helpParams: { module_cd: data.MODULE_CD, field_cd: data.COMM_FIELD_CD },
            helpTitle: field_title + " " + dews.localize.get("조회", 'D0000509', '', 'BAFSEL00100'),
            gridCodeField : field_id,
            gridTextField : field_id_nm,
            callback: function (rowData, pickerData) {
              var row = grid.select();
              grid.setCellValue(row, field_id,    pickerData.SYSDEF_CD);
              grid.setCellValue(row, field_id_nm, pickerData.SYSDEF_NM);
            },
            editable: function (e) { return isEditable ? (grid.getRowState(e.row.index) == "added" ? true : false) : isEditable}
          }
          break;

        case '3': //커스텀 도움창
          var nameField = '';
          var apiUrl = '';
          var helpSize = '';
          var custom = true;

          switch (data.HWND_ID_CD) {
            case 'H_SD_MA_ITEM_C':
              nameField = 'ITEM_NM';
              apiUrl = '~/api/SD/SDCustomCodeHelpService/SD_ITEM_CD_list';
              helpSize = 'big';

              break;
            case 'H_SD_SALESORGN_CD_C':
              nameField = 'SALESORGN_NM';
              apiUrl = '~/api/SD/SDCustomCodeHelpService/H_SD_SALESORGN_CD_C';
              helpSize = 'big';
              break;

            case 'H_SD_MA_PARTNER_MST_S':
              nameField = 'PARTNER_NM';
              custom = false;
              apiUrl = '';
              helpSize = 'big';
              break;

            case 'H_HR_EMP_MST_S01':
              nameField = 'KOR_NM';
              custom = false;
              apiUrl = '';
              helpSize = 'big';
              break;

            case 'H_MA_BIZAREA_MST_S':
              nameField = 'BIZAREA_NM';
              custom = false;
              apiUrl = '';
              helpSize = 'big';
              break;
          }
          dataSourceArr.push(
            {field : field_id,    dataType: 'text'},
            {field : field_id_nm, dataType: 'text'}
          );
          align = 'left';

          editor = {
            type: 'codepicker',
            helpCode: data.HWND_ID_CD,
            helpCustom : custom,
            helpViewUrl : "/codehelp/" + data.MODULE_CD + '/' + data.HWND_ID_CD,
            helpApiUrl : apiUrl,
            helpTitle: field_title + " " + dews.localize.get("조회", 'D0000509', '', 'BAFSEL00100'),
            helpSize : helpSize,
            gridCodeField : field_id,
            gridTextField : field_id_nm,
            callback: function (rowData, pickerData) {
              var row = grid.select();
              switch (data.HWND_ID_CD) {
                case 'H_SD_MA_ITEM_C':
                  grid.setCellValue(row, field_id,    pickerData.ITEM_CD);
                  grid.setCellValue(row, field_id_nm, pickerData.ITEM_NM);
                  grid.setCellValue(row, 'ITEM_SPEC_DC', pickerData.ITEM_SPEC_DC, false);
                  break;

                case 'H_SD_SALESORGN_CD_C':
                  grid.setCellValue(row, field_id,    pickerData.SALESORGN_CD);
                  grid.setCellValue(row, field_id_nm, pickerData.SALESORGN_NM);
                  break;

                case 'H_SD_MA_PARTNER_MST_S':
                  grid.setCellValue(row, field_id,    pickerData.PARTNER_CD);
                  grid.setCellValue(row, field_id_nm, pickerData.PARTNER_NM);
                  break;

                case 'H_HR_EMP_MST_S01':
                  grid.setCellValue(row, field_id,    pickerData.EMP_NO);
                  grid.setCellValue(row, field_id_nm, pickerData.KOR_NM);
                  break;

                  case 'H_MA_BIZAREA_MST_S':
                    grid.setCellValue(row, field_id,    pickerData.BIZAREA_CD);
                    grid.setCellValue(row, field_id_nm, pickerData.BIZAREA_NM);
                    break;
              }
            },
            editable: function (e) { return isEditable ? (grid.getRowState(e.row.index) == "added" ? true : false) : isEditable}
          }
          break;
      }

      $.merge(gridDataSource.options.schema.model.fields, dataSourceArr);
      gridDataSource.setFields(gridDataSource.options.schema.model.fields);
      editor.maxLength = inputMaxLength; // 컬럼 사이즈

      var item = {
        field: field_id,
        title: field_title,
        align: align,
        editor: data.HWND_FG === '1'? editor : (menu_id === 'SLSSPN00100' && field_id === 'ITEM_CD' ? editor : { type: "readonly" }),
        formats: formats,
        attributes : {class : required},
        visible: data.HWND_FG === '1'? true : false,
        renderer: { showTooltip: true }
      }
      // 리턴값
      arrColumns.push(item);

      // 그리드에 컬럼 추가
      grid.addColumn(item);

      if(data.HWND_FG != '1'){
        var item_nm = {
          field: field_id_nm,
          title: field_title,
          align:  'left',
          formats: formats,
          attributes : {class : required},
          editor : menu_id === 'SLSSPN00100' && field_id === 'ITEM_CD' ? { type: "readonly"} : editor,
          visible: true
        }
        arrColumns.push(item_nm);
        grid.addColumn(item_nm);
      }

      // 품목일 경우 품목명, 규격 추가
      if(data.HWND_ID_CD == 'H_SD_MA_ITEM_C'){
        $.each(arrColumns, function(idx2, data2){
          if(data2.field == 'ITEM_CD'){
            data2.align = 'left';
            data2.visible = true;
          }

          if(data2.field == 'ITEM_CD_NM'){
              data2.title = dews.localize.get("품목명", 'D0000034');
          }
        });

        var item_spec_dc = {
          field: 'ITEM_SPEC_DC',
          title: dews.localize.get("규격", "D0000035"),
          align:  'left',
          formats: formats,
          editor : { type: "readonly" },
          visible: true
        }
        arrColumns.push(item_spec_dc);
        grid.addColumn(item_spec_dc);
      }

      grid.setColumns();
    });

    return arrColumns;
  },
  serializeCondition : function(){
    var self = dews.ui.page;
    var condition = self.find('.dews-ui-condition-panel');
  }
};
  module.shpdlv = {
    /*
    - 대략적으로 JSON Object의 size 계산
    - 아래에서 참조하여 가져옴
      sizeof.js
      A function to calculate the approximate memory usage of objects
      Created by Kate Morley - http://code.iamkate.com/ - and released under the terms
      of the CC0 1.0 Universal legal code:
      http://creativecommons.org/publicdomain/zero/1.0/legalcode
    */
    memorySizeOf: function (object) {

      // initialise the list of objects and size
      var objects = [object];
      var size = 0;
      // loop over the objects
      for (var index = 0; index < objects.length; index++) {

        switch (typeof objects[index]) {
          case 'boolean': size += 4; break;
          case 'number': size += 8; break;
          case 'string': size += 2 * objects[index].length; break;
          case 'object':
            if (Object.prototype.toString.call(objects[index]) != '[object Array]') {
              for (var key in objects[index]) size += 2 * key.length;
            }

            for (var key in objects[index]) {
              var processed = false;
              for (var search = 0; search < objects.length; search++) {
                if (objects[search] === objects[index][key]) {
                  processed = true;
                  break;
                }
              }
              if (!processed) objects.push(objects[index][key]);
            }
        }
      }
      return size;
    },

    // 웹소켓 파라미터 계산 시, 8000bytes 초과 시에 잘라서 별도의 리스트 추가
    checkSizeObject: function (docList, tmpDocNo) {
      var checkListNew = new Array();//최종 반환 리스트
      var checkOkList = new Array();//사이즈 초과 전까지의 리스트
      var totalSizeOfObject = 0;
      var sizeOfObject = 0;
      var tmpDocNoSize = 0;
      var endLength = docList.length - 1;

      $.each(docList, function (idx, item) {
        sizeOfObject = module.shpdlv.memorySizeOf(item);//리스트 사이즈 체크
        tmpDocNoSize = module.shpdlv.memorySizeOf(tmpDocNo);//임시번호 사이즈 체크
        totalSizeOfObject += sizeOfObject;

        if (totalSizeOfObject > 8000 - tmpDocNoSize) {//8000 이상 시, 웹소켓 파라미터 보낼때 일부 커넥션 오류 발생하여 일단 해당 기준으로 설정
          checkListNew.push(checkOkList);
          checkOkList = new Array();//초기화
          totalSizeOfObject = 0;
        }
        checkOkList.push(item);

        if (endLength === idx) {//마지막 인덱스 값일 때, 리스트값 모두 넣어줌
          checkListNew.push(checkOkList);
        }

      });
      return checkListNew;
    }
  }

  // openDefinedView 메소드 등에서 사용하기 위한 컬럼 미리 선언.
  const sdPreDefinedColumns = {
    SC: { //Scale Info Defined(스케일정보)
      fields: [
        { field: "_uid" },
        { field: "SCALE_SQ" },
        { field: "SCALE_QT" },
        { field: "UNIT_CD" },
        { field: "PRC_AMT" }
      ],
      columns: [
        { field: "SCALE_SQ", title: "순번", width: 40, align: "center" },
        { field: "SCALE_QT", title: "수량", width: 60, align: "right", formats: { type: "number", predefined: true, format: "MA00001"}},
        { field: "UNIT_CD", title: "단위", width: 50, align: "left" },
        { field: "PRC_AMT", title: "가격", width: 120, align: "right" , formats: { type: "number", predefined: true, format: "MA00003"}}
      ]
    }
  };

  // 에러 다이얼로그(sdJS.com의 openErrorPopup 함수) 사용을 위한 에러 리스트
  // 임시로 sql, java라고 명명
  module.errorList = {
    sql: {
      'ORA-00001': "PK 컬럼이 중복 됩니다.",
      'ORA-00904': "존재하지 않는 컬럼 입니다. (부적합한 식별자)",
      'ORA-00911': "문자가 부적합 합니다(';', ',' 등)",
      'ORA-00917': "콤마(,)가 누락되었습니다.",
      'ORA-00923': "FROM 키워드가 필요한 위치에 없습니다",
      'ORA-00933': "SQL 명령어가 올바르게 종료되지 않았습니다",
      'ORA-00936': "누락된 표현식(기호, 괄호, 띄어쓰기 등)",
      'ORA-00942': "테이블 또는 뷰가 존재하지 않습니다.",
      'ORA-00947': "INSERT문의 인자가 충분하지 않습니다.",
      'ORA-01722': "NUMBER 타입에 문자가 삽입되었습니다.",
      'ORA-12899': "컬럼에 설정된 길이보다 긴 값 삽입되었습니다.",
      'ORA-01438': "컬럼에 설정된 길이보다 긴 값 삽입되었습니다.",
      'ORA-01400': "NOT NULL 컬럼에 NULL이 삽입되었습니다.",
      'ORA-01407': "NOT NULL 컬럼에 NULL이 삽입되었습니다.",
      'ORA-01861': "컬럼의 데이터 타입과 인자 타입이 일치하지 않습니다."
    },
    java: {
      'null': "NullPointerException 발생",
      '/ by zero': "0으로 나눌 수 없습니다.",
      'Mapped Statements collection does not contain': "쿼리를 찾을수 없습니다.", // 경우가 여러가지 - namespace 잘못, mybatis id 중복
      'Error converting' : "형변환을 할 수 없습니다."
    }
  };

  //공통 - Calculate (금액계산)
module.Calculate = {
  calcQtOrExum: function(grid, index, p_exrt_cd, p_exrt_rt, col_qt, col_exum, col_examt, col_exrtrt, col_bookum, col_taxamt, col_bookamt,
                col_taxbookum, col_taxbookamt, col_taxexum, col_taxexamt, col_nume_trte_vr, col_dnom_trte_vr, ma_format_list, format_um, format_amt){
    var qt = grid.getCellValue(index, col_qt);
    var ex_um = grid.getCellValue(index, col_exum);
    var exrt_rt = p_exrt_rt;
    if ( p_exrt_rt == 0 || p_exrt_rt == undefined ){
      exrt_rt = grid.getCellValue(index, col_exrtrt);
    }
    var ex_amt = new BigNumber(ex_um).multiply(qt).value();
    var book_amt = new BigNumber(ex_amt).multiply(exrt_rt).value();
    // 포맷적용된 금액으로 세액 계산되도록 수정 230512
    book_amt = scmJS.com.getChangeNumber(ma_format_list, "MA00003", book_amt, "");
    var book_um = new BigNumber(book_amt).divide(qt).value();
    var nume_trte_vr = grid.getCellValue(index, col_nume_trte_vr);
    var dnom_trte_vr = grid.getCellValue(index, col_dnom_trte_vr);
    var tax_amt = new BigNumber(book_amt).multiply(new BigNumber(nume_trte_vr).divide(dnom_trte_vr).value()).value();
    var tax_book_amt = new BigNumber(book_amt).add(tax_amt).value();
    var tax_book_um = new BigNumber(tax_book_amt).divide(qt).value();
    var tax_ex_amt = new BigNumber(tax_book_amt).divide(exrt_rt).value();
    var tax_ex_um = new BigNumber(tax_ex_amt).add(qt).value();

    grid.setCellValue(index, col_examt, scmJS.com.getChangeNumber(ma_format_list, format_amt, ex_amt, p_exrt_cd), false);
    grid.setCellValue(index, col_bookum, scmJS.com.getChangeNumber(ma_format_list, "MA00002", book_um, ""), false);
    grid.setCellValue(index, col_bookamt, book_amt, false);
    grid.setCellValue(index, col_taxamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_amt, ""), false);
    grid.setCellValue(index, col_taxbookamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_amt, ""), false);
    grid.setCellValue(index, col_taxexamt, scmJS.com.getChangeNumber(ma_format_list, format_amt, tax_ex_amt, ""), false);
    grid.setCellValue(index, col_taxexum, scmJS.com.getChangeNumber(ma_format_list, format_um, tax_ex_um, ""), false);
/*    var column = grid.getColumns().filter(function(item) {
      return (item.field == col_taxbookamt);
    });
    if (column != undefined && column.length > 0) {
      grid.setCellValue(index, col_taxbookum, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_um, ""), false);
    }*/
  },
  calcExAmt: function(grid, index, p_exrt_cd, p_exrt_rt, col_qt, col_exum, col_examt, col_exrtrt, col_bookum, col_taxamt, col_bookamt, col_taxbookum, col_taxbookamt,
                  col_taxexum, col_taxexamt, col_nume_trte_vr, col_dnom_trte_vr, ma_format_list, format_um, format_amt){
    var qt = grid.getCellValue(index, col_qt);
    var ex_amt = grid.getCellValue(index, col_examt);
    var exrt_rt = p_exrt_rt;
    if ( p_exrt_rt == 0 || p_exrt_rt == undefined ){
      exrt_rt = grid.getCellValue(index, col_exrtrt);
    }
    var ex_um = new BigNumber(ex_amt).divide(qt).value();
    var book_amt = new BigNumber(ex_amt).multiply(exrt_rt).value();
    var book_um = new BigNumber(book_amt).divide(qt).value();
    var nume_trte_vr = grid.getCellValue(index, col_nume_trte_vr);
    var dnom_trte_vr = grid.getCellValue(index, col_dnom_trte_vr);
    var tax_amt = new BigNumber(book_amt).multiply(new BigNumber(nume_trte_vr).divide(dnom_trte_vr).value()).value();
    var tax_book_amt = new BigNumber(book_amt).add(tax_amt).value();
    var tax_book_um = new BigNumber(tax_book_amt).divide(qt).value();
    var tax_ex_amt = new BigNumber(tax_book_amt).divide(exrt_rt).value();
    var tax_ex_um = new BigNumber(tax_ex_amt).add(qt).value();

    grid.setCellValue(index, col_exum, scmJS.com.getChangeNumber(ma_format_list, format_um, ex_um, p_exrt_cd), false);
    grid.setCellValue(index, col_bookum, scmJS.com.getChangeNumber(ma_format_list, "MA00002", book_um, ""), false);
    grid.setCellValue(index, col_bookamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", book_amt, ""), false);
    grid.setCellValue(index, col_taxamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_amt, ""), false);
    grid.setCellValue(index, col_taxbookamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_amt, ""), false);
    grid.setCellValue(index, col_taxexamt, scmJS.com.getChangeNumber(ma_format_list, format_amt, tax_ex_amt, ""), false);
    grid.setCellValue(index, col_taxexum, scmJS.com.getChangeNumber(ma_format_list, format_um, tax_ex_um, ""), false);
 /*      var column = grid.getColumns().filter(function(item) { return (item.field == col_taxbookamt); });
    if (column != undefined && column.length > 0) {
      grid.setCellValue(index, col_taxbookum, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_um, ""), false);
    }*/
  },
  calcTaxBookUm: function(grid, index, p_exrt_cd, p_exrt_rt, col_qt, col_exum, col_examt, col_exrtrt, col_bookum, col_taxamt, col_bookamt, col_taxbookum, col_taxbookamt, col_nume_trte_vr, col_dnom_trte_vr, ma_format_list, format_um, format_amt){
    var exrt_rt = p_exrt_rt;
    if ( p_exrt_rt == 0 || p_exrt_rt == undefined ){
      exrt_rt = grid.getCellValue(index, col_exrtrt);
    }
    var nume_trte_vr = grid.getCellValue(index, col_nume_trte_vr);
    var dnom_trte_vr = grid.getCellValue(index, col_dnom_trte_vr);

    var qt = grid.getCellValue(index, col_qt);
    var tax_book_um = grid.getCellValue(index, col_taxbookum);
    var tax_book_amt = new BigNumber(tax_book_um).multiply(qt).value();
    var book_amt = new BigNumber(new BigNumber(tax_book_amt).multiply(new BigNumber(dnom_trte_vr).divide(new BigNumber(nume_trte_vr).add(dnom_trte_vr).value()).value()).value()).value(); // 장부금액=판매금액*환율*(분모세율/(분자세율+분모세율))
    var book_um = new BigNumber(book_amt).divide(qt).value();
    var tax_amt = scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_amt, "")
                  - scmJS.com.getChangeNumber(ma_format_list, "MA00003", book_amt, "") ;
    //var ex_amt = new BigNumber(book_amt).divide(exrt_rt).value();
    //var ex_um = new BigNumber(ex_amt).divide(qt).value();;

 /*      var column = grid.getColumns().filter(function(item) { return (item.field == col_taxbookamt); });
    if (column != undefined && column.length > 0) {
      grid.setCellValue(index, col_taxbookum, scmJS.com.getChangeNumber(ma_format_list, format_amt, ex_amt, p_exrt_cd), false);
    }*/
    grid.setCellValue(index, col_exum, scmJS.com.getChangeNumber(ma_format_list, format_um, ex_um, p_exrt_cd), false);
    grid.setCellValue(index, col_bookum, scmJS.com.getChangeNumber(ma_format_list, "MA00002", book_um, ""), false);
    grid.setCellValue(index, col_bookamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", book_amt, ""), false);
    grid.setCellValue(index, col_taxamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_amt, ""), false);
    grid.setCellValue(index, col_taxbookamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_amt, ""), false);
    grid.setCellValue(index, col_taxbookum, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_um, ""), false);
  },
  calcQtOrTaxExUm: function(grid, index, p_exrt_cd, p_exrt_rt, col_qt, col_exum, col_examt, col_exrtrt, col_bookum, col_taxamt, col_bookamt, col_taxbookum, col_taxbookamt,
                      col_taxexum, col_taxexamt, col_nume_trte_vr, col_dnom_trte_vr, ma_format_list, format_um, format_amt){
    var exrt_rt = p_exrt_rt;
    if ( p_exrt_rt == 0 || p_exrt_rt == undefined ){
      exrt_rt = grid.getCellValue(index, col_exrtrt);
    }
    var nume_trte_vr = grid.getCellValue(index, col_nume_trte_vr);
    var dnom_trte_vr = grid.getCellValue(index, col_dnom_trte_vr);

    var qt = grid.getCellValue(index, col_qt);
    var tax_ex_um = grid.getCellValue(index, col_taxexum);
    var tax_ex_amt = new BigNumber(tax_ex_um).multiply(qt).value();
    var tax_book_amt = new BigNumber(tax_ex_amt).multiply(exrt_rt).value();
    var book_amt = new BigNumber(new BigNumber(tax_book_amt).multiply(new BigNumber(dnom_trte_vr).divide(new BigNumber(nume_trte_vr).add(dnom_trte_vr).value()).value()).value()).value(); // 장부금액=판매금액*환율*(분모세율/(분자세율+분모세율))
    var book_um = new BigNumber(book_amt).divide(qt).value();
    var tax_amt = scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_amt, "")
                  - scmJS.com.getChangeNumber(ma_format_list, "MA00003", book_amt, "") ;
    var ex_amt = new BigNumber(book_amt).divide(exrt_rt).value();
    var ex_um = new BigNumber(ex_amt).divide(qt).value();;

 /*      var column = grid.getColumns().filter(function(item) { return (item.field == col_taxbookamt); });
    if (column != undefined && column.length > 0) {
      grid.setCellValue(index, col_taxbookum, scmJS.com.getChangeNumber(ma_format_list, format_amt, ex_amt, p_exrt_cd), false);
    }*/
    grid.setCellValue(index, col_exum, scmJS.com.getChangeNumber(ma_format_list, format_um, ex_um, p_exrt_cd), false);
    grid.setCellValue(index, col_examt, scmJS.com.getChangeNumber(ma_format_list, format_amt, ex_amt, p_exrt_cd), false);
    grid.setCellValue(index, col_bookum, scmJS.com.getChangeNumber(ma_format_list, "MA00002", book_um, ""), false);
    grid.setCellValue(index, col_bookamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", book_amt, ""), false);
    grid.setCellValue(index, col_taxamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_amt, ""), false);
    grid.setCellValue(index, col_taxbookamt, scmJS.com.getChangeNumber(ma_format_list, "MA00003", tax_book_amt, ""), false);
    grid.setCellValue(index, col_taxexum, scmJS.com.getChangeNumber(ma_format_list, format_um, tax_ex_um, ""), false);
    grid.setCellValue(index, col_taxexamt, scmJS.com.getChangeNumber(ma_format_list, format_amt, tax_ex_amt, ""), false);
  }
};

  /*********************************************************************************************
  *  @desc  js파일 상속
  *  @param {Object} targetJS [필수] js 객체 변수
  *  @ex
  * ------------------------------------------------------------------------------------------*/
  module.extendJS = function(targetJS){
    $.each(Object.keys(targetJS), function(idx, key){
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
         겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName){
        if(keyArr.indexOf(kName) >= 0){
          console.error("js 상속중 동일한 메소드 명이 존재합니다 - ", (key + '.' + kName));
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  }

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  var scmJS;
  dews.ajax.script('~/view/js/MA/ma.scm.js', {
    once: true,
    async: false
  }).done(function() {
    scmJS = gerp.MA;
  });
  module.extendJS(scmJS);

  // ma.scm.msg.js 상속
  // dews.ajax.script('~/view/js/MA/ma.scm.msg.js', {
  //   once: true,
  //   async: false
  // }).done(function() {
  // });
  // module.extendJS(window.gerp.SCM);

  /**********************************************************************************************/

  //-------------------------------------------End-------------------------------------------
  var newModule = {};
  newModule[moduleCode] = module;
  module.formatList = module.api.getCommonFormat(); // 회사환경설정-포맷리스트 세팅(sdJS.formatList)
  module.api.getUserInfo(); // 사용자 부가정보 조회
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/SD/sd.js
