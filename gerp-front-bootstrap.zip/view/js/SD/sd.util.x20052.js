(function (dews, gerp, $) {
  var module = {};
  var moduleCode = "SD";
  var version = "1.0.230223.01";

  console.debug("sd.util.x20052.js", dews.string.format("[ LOAD START :: version={0} ]", version));

  // 공통 메시지 기본값
  module.MSG = {
    //닫기
    CLOSE_CONFIRM: "저장하지 않은 데이터가 있습니다." + "\n" + "닫기를 계속 하시겠습니까?",         // 종료 확인 메세지
    //조회
    SEARCH_AGAIN_CONFIRM: "저장하지 않은 데이터가 있습니다." + "\n" + "조회를 계속 하시겠습니까?",  // 재조회 확인 메세지
    //삭제
    DELETE_CONFIRM: "삭제 하시겠습니까?" + "\n" + "(반드시 저장을 하셔야 반영이 됩니다.)",          // 삭제 확인 메세지(화면상에서 삭제)
    DELETE_IMME_CONFIRM: "삭제 하시겠습니까?",                                                      // 삭제 확인 메세지(DB 삭제)
    DELETE_DONE_ALERT: "삭제 되었습니다.",                                                          // 삭제 완료 메세지
    //저장
    SAVE_NO_DATA_ALERT: "저장할 데이터가 없습니다.",                                                // 저장할 데이터 없는 메세지
    SAVE_VALID_ALERT: "필수항목을 입력하지 않았습니다.",                                            // 저장 필수값 메세지
    SAVE_VALID_GRID_ALERT: "입력은 필수입니다.",                                                   // 필수값 누락 (그리드)
    SAVE_CONFIRM: "저장 하시겠습니까?",                                                             // 저장 확인 메세지
    SAVE_DONE_ALERT: "저장이 완료되었습니다.",                                                      // 저장 완료 메세지
    //로딩
    SEARCH_LOADING: "조회하는 중입니다.",                                                           // 조회 로딩 메세지
    SAVE_LOADING: "저장하는 중입니다.",                                                             // 저장 로딩 메세지
    DELETE_LOADING: "삭제하는 중입니다.",                                                           // 삭제 로딩 메세지(DB 삭제)
    //예외처리
    PROCESS_FAIL_ALERT: "작업이 실패하였습니다.",
    //선택
    CHECK_NO_DATA_ALERT: "선택된 데이터가 없습니다.",                                              // 체크된 데이터 없음
  };

  var bsApi;
  dews.ajax.script("/view/js/CM/cm.bscm.js", {
    once: true,
    async: false
  }).done(function () {
    bsApi = gerp.CM;
    module.MSG = $.extend(true, module.MSG, bsApi.MSG); // 공통 메시지(CM.MSG)와 병합(상단에 SD모듈 전용 메시지 우선)
  }).fail(function (xhr, status, error) {
    console.error("cm.bscm.js", "Common API Service not found error");
  });

  if (!bsApi.MSG) {
    dews.ajax.script("/view/js/MA/ma.cm.msg.js", {
      once: true,
      async: false
    }).done(function () {
      module.MSG = $.extend(true, module.MSG, gerp.MA.MSG); // 공통 메시지(MA.MSG)와 병합(상단에 SD모듈 전용 메시지 우선)
    }).fail(function (xhr, status, error) {
      console.error("ma.cm.msg.js", "Common API Service not found error");
    });
  }

  /**
   * getUserSalesInfo => 로그인 사용자의 지점, 루트의 기본값을 가져온다.
   * @param {object} control_PLANT_CD : 공장 컨트롤(예제. self.s_plant_cd)
   * @param {boolean} isAsync : 비동기 실행여부(기본=false, 비동기 실행). 컨트롤을 넘길 경우, 비동기실행(true)을 추천, 자동조회가 있는 화면은 동기실행(false) 추천.
   */
  module.getDefaultPlantInfo = function (control_PLANT_CD, isAsync) {
    let plantInfo = { PLANT_CD: "99", PLANT_NM: "영업물류센터", PC_CD: "1000" }; // 기본값
    // 영업물류공장(동아오츠카 전용)
    if (isAsync == undefined) { isAsync = false; }
    dews.api.get(dews.url.getApiUrl("SD", "SdCommonService_X20052", "getSalesPlantInfo"), {
      async: isAsync,
      data: {
        // std_dt: dews.date.format(new Date(), "yyyyMMdd"),
        // company_cd: self.user.companyCode,
      }
    }).done(function (data) {
      if (data) {
        plantInfo = data;
      }
    }).fail(function (xhr, status, error) {
      dews.error(error);
    }).always(function (data) {
      if (control_PLANT_CD) {
        control_PLANT_CD.setData(plantInfo);
      }
    });
    return plantInfo;
  }
  

  /**
   * getUserSalesInfo => 로그인 사용자의 지점, 루트의 기본값을 가져온다.
   * @param {object} control_SALEGRP_CD : 지점 컨트롤(예제. self.s_salegrp_cd)
   * @param {object} control_SALESROOT_CD : 루트 컨트롤(예제. self.s_salesroot_cd)
   * @param {boolean} isAsync : 비동기 실행여부(기본=false, 비동기 실행). 컨트롤 2종을 넘길 경우, 비동기실행(true)을 추천, 자동조회가 있는 화면은 동기실행(false) 추천.
   */
  module.getUserSalesInfo = function (control_SALEGRP_CD, control_SALESROOT_CD, isAsync) {
    var result = {
      SALEGRP_CD: "",
      SALEGRP_NM: "",
      SALESROOT_CD: "",
    };
    // if (isAsync == undefined) { isAsync = false; }
    // dews.api.get(dews.url.getApiUrl("SD", "SdCommonService_X20052", "getUserSalesInfo"), {
    //   async: isAsync,
    // }).done(function (data) {
    //   console.debug("getUserSalesInfo.data=", data);
    //   if (data) {
    //     if (data.BIZBNR_CD) {
    //       result.SALEGRP_CD = data.BIZBNR_CD;
    //       result.SALEGRP_NM = data.BIZBNR_NM;
    //       if (control_SALEGRP_CD) {
    //         control_SALEGRP_CD.setData({ SALEGRP_CD: data.BIZBNR_CD, SALEGRP_NM: data.BIZBNR_NM, });
    //       }
    //     }
    //     if (data.SALESROOT_CD) {
    //       result.SALESROOT_CD = data.SALESROOT_CD;
    //       if (control_SALEGRP_CD) {
    //         control_SALESROOT_CD.setData({ SALESROOT_CD: data.SALESROOT_CD, SALESROOT_CD: data.SALESROOT_CD, });
    //       }
    //     }
    //   }
    // }).fail(function (xhr, status, error) {
    //   dews.error(error);
    // }).always(function (data) {
    //   console.debug("getUserSalesInfo.result=", result);
    // });
    return result;
  };

  module.CodePickerInitializer = {
    /**
      * 지점 & 루트 도움창 초기화
      *
      * @param {codepicker} control_SALESORGN 지점 컨트롤(코드피커)
      * @param {JSON} options_SALESORGN
      *     @param {string} helpCode 코드도움 데이터를 바인딩하는 경우 사용할 코드도움 코드를 지정합니다.
      *     @param {string} codeField  코드도움 코드의 code 필드값을 지정합니다.(※ 생략가능 / 기본값: "code")
      *     @param {string} textField 코드도움 코드의 text 필드값을 지정합니다.(※ 생략가능 / 기본값: "text")
      *     @param {string} helpTitle  도움창 다이얼로그 타이틀을 지정합니다.
      *     @param {function} helpParams 코드도움에 추가적으로 전달할 데이터를 설정합니다.(※ 생략가능, 여러 항목을 전달할 때는 URL 파라미터 형식을 따릅니다.(key1=value1 & key2=value2))
      *     @param {function} setData 도움창 다이얼로그 데이터 선택 시 이벤트를 지정합니다.
      * @param {codepicker} control_SALESROOT 루트 컨트롤(코드피커)
      * @param {JSON} options_SALESROOT
      *     @param {string} helpCode 코드도움 데이터를 바인딩하는 경우 사용할 코드도움 코드를 지정합니다.
      *     @param {string} codeField  코드도움 코드의 code 필드값을 지정합니다.(※ 생략가능 / 기본값: "code")
      *     @param {string} textField 코드도움 코드의 text 필드값을 지정합니다.(※ 생략가능 / 기본값: "text")
      *     @param {boolean} useButton 찾기 버튼의 사용 여부를 지정합니다.(※ 생략가능 / 기본값: true)
      *     @param {boolean} useAjax 도움창 오픈 전 AJAX 를 통해서 먼저 확인할 지 여부를 지정합니다.(※ 생략가능 / 기본값: true)
      *     @param {string} helpSize 도움창의 사이즈 포맷을 설정합니다.(※ 생략가능, 기본값: "medium" / 설정가능값(각 사이즈 별 도움창의 크기): "small"(360x397) | "medium"(560x537) | "big"(746x537) | "largebig"(818x630) )
      *     @param {number} helpWidth  도움창 다이얼로그 너비를 지정합니다(※ helpSize 와 함께 설정 시 helpWidth 속성이 우선 적용됩니다.)
      *     @param {number} helpHeight 도움창 다이얼로그 높이를 지정합니다(※ helpSize 와 함께 설정 시 helpHeight 속성이 우선적용됩니다.)
      *     @param {boolean} helpCustom 사용자 정의 도움창 사용 여부를 지정합니다.(※ 생략가능 / 기본값: false)
      *     @param {string} helpViewUrl 도움창 View URL 을 지정합니다. (※ 생략가능, 생략 시 도움창 View URL 을 자동으로 생성합니다.)
      *     @param {string} helpApiUrl  도움창 Data URL 을 지정합니다. (※ 생략가능, 생략 시 도움창 Data URL 을 자동으로 생성합니다.)
      *     @param {string} helpTitle  도움창 다이얼로그 타이틀을 지정합니다.
      *     @param {boolean} moveFocus  코드피커 값 설정 후 패널에서 포커스 넘어갈 것인지 여부를 지정합니다(※ 생략가능 / 기본값: true)
      *     @param {boolean} useKeyword  검색어 입력 활성화 여부를 지정합니다.(※ 생략가능 / 기본값: true)
      *     @param {boolean} autoComplete  자동완성 사용 여부를 지정합니다.(※ 생략가능 / 기본값: false, html 속성 data-dews-autocomplete와 같이 사용할 경우 data-dews-autocomplete로 설정된 값이 우선적용됩니다.)
      *     @param {function} helpParams 코드도움에 추가적으로 전달할 데이터를 설정합니다.(※ 생략가능, 여러 항목을 전달할 때는 URL 파라미터 형식을 따릅니다.(key1=value1 & key2=value2))
      *     @param {function} setData 도움창 다이얼로그 데이터 선택 시 이벤트를 지정합니다.
      */
    SalesOrgnRoot_Relation: function (control_SALESORGN, options_SALESORGN, control_SALESROOT, options_SALESROOT) {
      console.debug("CodePickerInitializer.SalesOrgnRoot_Relation.START", {
        control_SALESORGN: control_SALESORGN,
        options_SALESORGN: options_SALESORGN,
        control_SALESROOT: control_SALESROOT,
        options_SALESROOT: options_SALESROOT,
      });

      var self = bsApi.getPage();
      // 1. 코드피커 생성 - 지점
      var popId = "H_MA_CODEDTL_S";
      let defaultParams = {
        helpCode: popId,
        codeField: "SYSDEF_CD",
        textField: "SYSDEF_NM",
        helpTitle: "지점 도움창",
      };
      options_SALESORGN = $.extend(true, options_SALESORGN, defaultParams);

      // 지점 도움창 파라메터 기본값
      let defaultHelpParams = function (e) {
        return {
          company_cd: self.user.companyCode,
          module_cd: "MA",
          field_cd: "S00040",
          date: dews.date.format(new Date(), "yyyyMMdd"),
          menu_cd: self.menu.id
        };
      };
      if (!options_SALESORGN.helpParams || !$.isFunction(options_SALESORGN.helpParams)) {
        options_SALESORGN.helpParams = defaultHelpParams;
      }

      // 지점 도움창 값 선택 이벤트(기본값)
      let defaultSetData = function (e, pickerData) {
        console.debug(dews.string.format("H_MA_CODEDTL_S({0}/{1}).setData", "MA", "S00040"), {
          e: e,
          pickerData: pickerData,
        });
        // 루트 코드피커 초기화
        control_SALESROOT.clearData(false);
        control_SALESORGN.focus();
      };
      if (!options_SALESORGN.setData || !$.isFunction(options_SALESORGN.setData)) {
        options_SALESORGN.setData = defaultSetData;
      }
      control_SALESORGN = dews.ui.codepicker(control_SALESORGN, {
        url: options_SALESORGN.helpViewUrl, // "/codehelp/CX/" + popId,
        title: options_SALESORGN.helpTitle, // "지점 도움창"
      });
      if (options_SALESORGN.setData && $.isFunction(options_SALESORGN.setData)) {
        control_SALESORGN.on("setData", function (e, pickerData) {
          return options_SALESORGN.setData(e, pickerData);
        });
      }

      // 2. 코드피커 생성 - 루트
      var popId2 = "H_SD_SALESROOT_MST_C_X20052";
      let defaultParams2 = {
        helpCode: popId2,
        codeField: "SALESROOT_CD",
        textField: "SALESROOT_CD",
        useButton: true,
        useAjax: true,
        helpSize: "big",
        helpWidth: 746,
        helpHeight: 537,
        helpCustom: true,
        helpViewUrl: "~/codehelp/CX/" + popId2,
        helpApiUrl: "~/api/CX/SDCustomCodeHelp_X20052_SERVICE/" + popId2,
        helpTitle: "루트 도움창",
        moveFocus: true,
        useKeyword: true,
        autoComplete: false,
      };
      options_SALESROOT = $.extend(true, options_SALESROOT, defaultParams2);

      // 루트 도움창 파라메터 기본값
      let defaultHelpParams2 = function (e) {
        return {
          salegrp_cd: bsApi.getString(control_SALESORGN.code()),
          salegrp_nm: bsApi.getString(control_SALESORGN.text()),
          use_yn: "Y",
        };
      };
      if (!options_SALESROOT.helpParams) { // !$.isFunction(options_SALESROOT.helpParams)
        options_SALESROOT.helpParams = defaultHelpParams2;
      }

      // 루트 도움창 값 선택 이벤트(기본값)
      let defaultSetData2 = function (e, pickerData) {
        console.debug(dews.string.format("H_SD_SALESROOT_MST_C_X20052({0}/{1}).setData", e.code, e.text), {
          e: e,
          pickerData: pickerData,
        });
        // 지점 코드피커 설정 - 지점이 선택되지 않거나 변경된 경우 선택한 루트의 지점으로 설정.
        if (bsApi.isNotNull(e.code) && (!control_SALESORGN.code() || control_SALESORGN.code() != pickerData.SALEGRP_CD)) {
          control_SALESORGN.setData({
            SYSDEF_CD: bsApi.getString(pickerData.SALEGRP_CD),
            SYSDEF_NM: bsApi.getString(pickerData.SALEGRP_NM),
          }, false);
        }
      };
      if (!options_SALESROOT.setData || !$.isFunction(options_SALESROOT.setData)) {
        options_SALESROOT.setData = defaultSetData2;
      }
      control_SALESROOT = dews.ui.codepicker(control_SALESROOT, {
        url: options_SALESROOT.helpViewUrl, // "~/codehelp/CX/H_SD_SALESROOT_MST_C_X20052"
        title: options_SALESROOT.helpTitle, // "루트 도움창"
      });
      if (options_SALESROOT.setData && $.isFunction(options_SALESROOT.setData)) {
        control_SALESROOT.on("setData", function (e, pickerData) {
          return options_SALESROOT.setData(e, pickerData);
        });
      }

      console.debug("CodePickerInitializer.SalesOrgnRoot_Relation.END", {
        control_SALESORGN: control_SALESORGN,
        options_SALESORGN: options_SALESORGN,
        control_SALESROOT: control_SALESROOT,
        options_SALESROOT: options_SALESROOT,
      });
    },
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);

  console.debug("sd.util.x20052.js", dews.string.format("[ LOAD COMPLETE :: version={0} ]", version));

})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=sd.util.x20052.js