(function(dews, gerp, $) {
  var module = {};

  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'WF'; // 모듈 코드를 입력 해주세요.

  // 공통 함수 정의
  module.styles = {
    "comments":{
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASBAMAAACk4JNkAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAnUExURUdwTHt7e3p6ent7e4CAgHp6enp6ent7e3p6enh4eHp6ent7e3t7e0mmdb4AAAAMdFJOUwCk8DYQWsDQgyDgcFmL33cAAAB6SURBVAjXY2BAAsxSZxYagBnlkQxTyycAWUYbgAS3MgMDy1KwkigHBg4BBp0zhxgYNzCwG0C0FTDwMIDFGA4wMDmAxVgUGBgDwGKsAgzMCWAx9gAGBkEwSwyI3TKBxLQUEHePg2mbBljC3EOxFeIWsYUOUFcpGjCgAgBzChWMqRkUPQAAAABJRU5ErkJggg=="
      }
    },
    "circulation":{
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASBAMAAACk4JNkAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAbUExURUdwTHt7e3l5eXp6ent7e3p6enp6enx8fHt7e8v239AAAAAIdFJOUwDgULwWgC9AnXlzagAAAGdJREFUCNdjYECAwg4gaCwAssRAXDYBINEAlgGRDYxASQiLgFgjk0WzAYRnqJYkCmYxibAGOBaAWMwKrAFMBiAWhwNrAEsDhMUmBmExKzAkgmTbgDoYGEA6gK4yVHEShTiR3aK5gAEASV8awazz2gsAAAAASUVORK5CYII="
      }
    },
    "emergency":{
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAEqADAAQAAAABAAAAEgAAAAC5YZBvAAABN0lEQVQ4EdWTsUoDQRCGd3aTcJUKx2FpIbFKIfgUUUnSpBdsYudjpLS9xqRPleCrWBgNnK1yRLGIF7kdZ4uVcXfDNYJkYZmZf//9dpjjhNjKlXe7WVXj0jUse71jV6P6wNVcnwfSWl9QByPn4jOv805nbHxcC+ZkvHFftEajm3Nb2wg2cSP2+2q5Xg8Q8RwAEoovtO/iKEphMildfxCUt9s7WK/fC61TBFgIpeZKiCMCNrEsL4nSSmazDw7zQKaTvCiyGuL1l1IZN5s8Ilih9TBuNA55Z96wCXJF/jQEMaBPxEfQ+vZ1tRqY2i4PRC2e0SwW1hCKIOWTAjjlZzVemJxmkggp567O6xLggea1z7VQRyfcsCkn0C+fB9p0sUr/M9DP56ff4o1e3a16OXD+Hk+newH9n6Vv8zFqzBG+L9IAAAAASUVORK5CYII="
      }
    },
    "oper":{ //시행
      fontSize: "12",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASBAMAAACk4JNkAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAbUExURUdwTHt7e3l5eXp6ent7e3p6enp6enx8fHt7e8v239AAAAAIdFJOUwDgULwWgC9AnXlzagAAAGdJREFUCNdjYECAwg4gaCwAssRAXDYBINEAlgGRDYxASQiLgFgjk0WzAYRnqJYkCmYxibAGOBaAWMwKrAFMBiAWhwNrAEsDhMUmBmExKzAkgmTbgDoYGEA6gK4yVHEShTiR3aK5gAEASV8awazz2gsAAAAASUVORK5CYII="
      }
    },
    "s10":{ //저장
      fontSize: "12",
      color : "#3077e8",
      // icon:{
      //   position:"left",
      //   image: "data:image/png;base64,XXX)"
      // }
    },
    "s20":{ //상신
      fontSize: "12",
      color : "#f09618",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAA/UExURUdwTPCVF++XGPCWGPCWGO+VFfCVF++WF/CWF/CWGP////jLjPOkN/WyVf7w3fGcJvrWpPvet//58ffEffzlxq4ZoVUAAAAKdFJOUwCwIP/AMO/wcIAZEo7JAAAAf0lEQVQY02WP2xqEIAiEKVQENWu393/WHKztYv8bhsPwAdEgakgpaKSbzJOUZ77wj+Xt1+phzEQXzay5K5Ii9m3gHaWAUKw1K1CBBAtsZz4/HR4vHNBeZYHlni5WYVGoAnb7YmkUrps5R2dZ38Ofw/5PHzMyU8nPu+N9kaAr9AWyiQUvC6WlEQAAAABJRU5ErkJggg=="
      }
    },
    "s30":{ //진행
      fontSize: "12",
      color : "#3077e8",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAeUExURUdwTDB26DB36DB26DB26jB25zB26DB26TB36Mzd+rOBz/MAAAAIdFJOUwC78HAsgO9/a1g4pQAAAFVJREFUCNdjYGBwF0ssYQAC5o6OjjYDIEMCyOhohAgAgQGDB4SRwhABYbRClIAUaXTM7Jwxs6MNxmhCSMEVO8G0ww2EW8HArNHR0QSylMFVSDGEgQEAMrYx8U+zM3YAAAAASUVORK5CYII="
      }
    },
    "s90":{ //종결
      fontSize: "12",
      color : "#3fa684",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAzUExURUdwTD6nhT+mhIXHsT6mgz6lgz6lhD+mhECmhT2mhP////P6+GO2m7fe0Uuri9vu6KvYyT+ftpgAAAAKdFJOUwB////AgLDwLHCJS9FEAAAAa0lEQVQY02WPWxaAIAhEcXyAWtn+Vxs+MjvOlxcZYIhUYhyzM0JDEV0cOwdMhfW/SXtkZbCQn3DkE/DkPk4WcMT1fb0MboVcrsFaqJY7lcFqaUPPNFiHSvXA2rl2O2w/XXv4H07P9zW+b/Ef2KEDjKYgOKYAAAAASUVORK5CYII="
      }
    },
    "s100":{ //반려
      fontSize: "12",
      color : "#e85e30",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAABCUExURUdwTOhdMOdgMOhdMOddMOpaMOheMOheMOhdMOheMOheMOt3UP/6+fS2ovKmjO+Pb/fNv/vk3PCYe/bEtPnWyuloPSYijC4AAAAKdFJOUwCwIL/AMO/wcIBdGfuwAAAAh0lEQVQY00VPWRbEIAjDVosCLl3m/lcdEPuaDyGYsAAoUtmPYy8JFjI5juw8TNaFicL3P+T8aVBNcrnIYHMlKBquSk3aY5UCkYiHZk8n00RAona5rTb1WKF2L/RKhGZp9VPE2VTWpNk0qYdPXg9uvhjfIjf7Yu/qE2Edh04xv+emEhFj2Sz/A4V9CG9fCy3yAAAAAElFTkSuQmCC"
      }
    },
    "s110":{ //보류
      fontSize: "12",
      color : "#ae6204",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAeUExURUdwTK5iA65hA69gAK1iAq1iBK9iBK9gAv///65iBGzs8p8AAAAIdFJOUwDwuyxwgH9vWAXrJwAAAFZJREFUCNdjYGAwUxRKZgAClpkzZ04sADI0gYyZkyACQODAYAlhCDNEzpzROaNz5lSgEjBjEoMkhDERwYBLwRUbwrTDDYRbwcAiCbTUAWS9qaJQMAMDAC8XNYTGLpa/AAAAAElFTkSuQmCC"
      }
    },
    "s40":{ //발신종결
      fontSize: "12",
      color : "#3077e8",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAzUExURUdwTDB36DB45zB36DB26DB16jB26DB36DB26DB26P////P3/nqn8VeQ7K7K99jl+4uy8kUIEzoAAAAKdFJOUwCwIP9wMO/wgMBhuD2RAAAAa0lEQVQY02WPWxKFMAhD0ZRXvbe6/9VKK1ZnzBcHEgaIQmwu4saUKrgk5eIFU8t7PhQefjOEySb8twYY+cP1BzhprydDRmPbb4aOSKt7ckTG0laTYyn3DI5kXb+HfU8Pj6a/3O/G+6pua69PLdYELVUiykAAAAAASUVORK5CYII="
      }
    },
    "s50":{ //수신상신
      fontSize: "12",
      color : "#3077e8",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAA5UExURUdwTDB36DB45zB36DB26DB16jB26DB36DB26DB26DB36P///5i79EyJ7L3T+Geb7+Hr/D1/6fP3/r9S78MAAAAKdFJOUwCwIG9wMO/wgMCOcEutAAAAe0lEQVQY02WPRxLEMAgEsVcSScHy/x+7gBwO7gtDGAoAjExcClOGiySL8lv5Jg/b228tQjJ/iKE6wpWBPM7DiA4Be6g6hlZXDOgLtIv0c7onCqGjKuiWa7pqcwu5qoHXCTJKOzToU3B/D78P+55uM7hSTPe79j4i0+76D3LVCFgzoBnGAAAAAElFTkSuQmCC"
      }
    },
    "s60":{ //수신진행
      fontSize: "12",
      color : "#3077e8",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAeUExURUdwTDB26DB36DB26DB26jB25zB26DB26TB36Mzd+rOBz/MAAAAIdFJOUwC78HAsgO9/a1g4pQAAAFVJREFUCNdjYGBwF0ssYQAC5o6OjjYDIEMCyOhohAgAgQGDB4SRwhABYbRClIAUaXTM7Jwxs6MNxmhCSMEVO8G0ww2EW8HArNHR0QSylMFVSDGEgQEAMrYx8U+zM3YAAAAASUVORK5CYII="
      }
    },
    "s70":{ //수신반려
      fontSize: "12",
      color : "#3077e8",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAABCUExURUdwTDB36DB45zB36DB25zB16jB26DB36DB26DB26DB36Pn7/1OO7KLB9I218keG6nGh77/V99zo+4Ot8bTN9src+esxTrUAAAAKdFJOUwCwIL/AMO/wcIBdGfuwAAAAh0lEQVQY00VP2xaAIAjD0lDw2uX/fzUQO+1FhhsMAEFI+3HsKcBCJMMRjbvJOmci9/8PPps8ogkmZx5ZXQGSygtVvh7tJPBEbUj1dBpi8oBE9TJbqeLRRunWECehWmr5FX4O5bVpDg3iaacsyBoENwuWb+Y7W7Av+oRbx6FRjN+5IXlEnzatX5FwCIrIpbLsAAAAAElFTkSuQmCC"
      }
    },
    "s80":{ //수신확인
      fontSize: "12",
      color : "#3077e8",
      icon:{
        position:"left",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAzUExURUdwTDB36DB45zB36DB26DB16jB26DB36DB26DB26P////P3/nqn8VeQ7K7K99jl+4uy8kUIEzoAAAAKdFJOUwCwIP9wMO/wgMBhuD2RAAAAa0lEQVQY02WPWxKFMAhD0ZRXvbe6/9VKK1ZnzBcHEgaIQmwu4saUKrgk5eIFU8t7PhQefjOEySb8twYY+cP1BzhprydDRmPbb4aOSKt7ckTG0laTYyn3DI5kXb+HfU8Pj6a/3O/G+6pua69PLdYELVUiykAAAAAASUVORK5CYII="
      }
    },
  }

  console.log('## WF Module Script Loaded!!! ##');

  //////// 작성 영역 - 끝 ////////

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.js
