(function(dews, gerp, $) {
  var module = {};

  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'FI'; // 모듈 코드를 입력 해주세요.

  // 공통 함수 정의
  module.controlItemCodepickerOptions = {
    PREFIX_DTL_CC:{helpCode:"H_MA_CC_MST_S2", textField: "CC_CD", codeField: "CC_NM", helpSize:"largebig" }, //비용센터
    PREFIX_DTL_PJT:{helpCode:"H_PS_WBS_MST_C", textField: "WBS_NO", codeField: "WBS_NM", helpSize:"largebig" ,helpCustom:true, helpViewUrl: "~/codehelp/PS/H_PS_WBS_MST_C", helpApiUrl: "~/api/PS/PSCustomCodeHelpService/H_PS_WBS_MST_C_search_list", helpParams:{pjt_no:"" ,plan_element_yn:"", acct_altm_element_yn:"", bill_element_yn:"", use_yn:"Y"}}, //프로젝트 -PS_PROJ_MST
    PREFIX_DTL_PARTNER:{helpCode:"H_MA_PARTNER_MST_S", textField: "PARTNER_CD", codeField: "PARTNER_NM", helpSize:"big", helpCustom:true, helpViewUrl: "~/codehelp/MA/H_MA_PARTNER_MST_C", helpApiUrl: "~/api/MA/MACustomCodeHelpService/MA_PARTNERE_MST_C_list", helpParams:{company_cd:"",partner_fg_cd:"1", partner_csf_cd:"", keyword:"", start:0, count:500, use_yn:""}}, //거래처 -MA_PARTNER
    PREFIX_DTL_EVDN:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P40030"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //증빙
    PREFIX_DTL_BG:{helpCode:"H_FI_BG_MST_PROFIT", textField: "BG_CD", codeField: "BG_NM", helpSize:"medium" }, //예산단위
    PREFIX_DTL_BIZPLAN:{helpCode:"H_FI_BIZPLAN_MST_S01", textField: "BIZPLAN_CD", codeField: "BIZPLAN_NM", helpSize:"medium" }, //사업계획
    PREFIX_DTL_BGACCT:{helpCode:"H_FI_BGACCT_MST_S05", textField: "BGACCT_CD", codeField: "BGACCT_NM", helpSize:"largebig",helpCustom:true, helpViewUrl: "~/codehelp/FI/H_FI_BGACCT_MST_C", helpApiUrl: "~/api/CM/codehelp/CodeHelpDataService/H_FI_BGACCT_MST_S05"}, //예산계정

    //Type A
    A01:{helpCode:"H_MA_BIZAREA_MST_S", textField: "BIZAREA_CD", codeField: "BIZAREA_NM", helpSize:"medium" }, //귀속사업장
    A02:{helpCode:"H_MA_PCA_MST_S", textField: "PCA_CD", codeField: "PCA_NM", helpSize:"big" }, //손익센터
    A03:{helpCode:"H_MA_DEPT_MST_S", textField: "DEPT_CD", codeField: "DEPT_NM", helpSize:"medium" }, //부서
    A04:{helpCode:"H_HR_EMP_MST_C", textField: "EMP_NO", codeField: "KOR_NM", helpSize:"big", helpCustom:true, helpViewUrl:"~/codehelp/HR/H_HR_EMP_MST_C", helpApiUrl: "~/api/MA/MACustomCodeHelpService/HR_EMP_MST_C_list", helpParams:{company_cd:"", pc_cd_pipe:"", bizarea_cd_pipe:"", dept_cd_pipe:"", hlof_fg_cd:"", emp_cd:"", start:0, count:500, combo0 : "1"}}, //사원
    A07:{helpCode:"H_FI_FINPRODUCT_MST_S", textField: "FINPRODUCT_CD", codeField: "FINPRODUCT_NO", helpSize:"large", helpCustom:true, helpViewUrl: "~/codehelp/FI/H_FI_FINPRODUCT_MST_C", helpApiUrl: "~/api/CM/codehelp/CodeHelpDataService/H_FI_FINPRODUCT_MST_S"}, //예적금계좌 -FI_DEPOSIT
    A08:{helpCode:"H_FI_FINPRODUCT_MST_S01", textField: "FINPRODUCT_CD", codeField: "FINPRODUCT_NM", helpSize:"large", helpCustom:true, helpViewUrl: "~/codehelp/FI/H_FI_FINPRODUCT_MST_C", helpApiUrl: "~/api/CM/codehelp/CodeHelpDataService/H_FI_FINPRODUCT_MST_S01" }, //신용카드 -FI_CARD
    A09:{helpCode:"H_MA_PARTNER_MST_S01", textField: "PARTNER_CD", codeField: "PARTNER_NM", helpSize:"big", helpParams:{use_yn: "Y"}}, //금융기관 -MA_PARTNER
    A10:{helpCode:"H_MA_ITEM_S", textField: "ITEM_CD", codeField: "ITEM_NM", helpSize:"big" }, //품목 -MA_ITEM
    A11:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P00170"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //재무제표 비용계정 집계
    A12:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"CO",field_cd:"P00390"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //손익구분 도움창
    A13:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"CO",field_cd:"P00400"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //수익성구분코드

    A21:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"A21"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"}, //사용자정의1
    A22:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"A22"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"}, //사용자정의2
    A23:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"A23"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"}, //사용자정의3
    A24:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"A24"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"}, //사용자정의4
    A25:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"A25"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"}, //사용자정의5

    //Type B
    B01:{helpCode:"H_FI_ASSET_MST_C3", textField: "ASSET_CD", codeField: "ASSET_NM", helpSize:"largebig", helpCustom:true, helpViewUrl:"~/codehelp/FI/H_FI_ASSET_MST_C3", helpApiUrl: "~/api/FI/FICustomCodeHelpService/H_FI_ASSET_MST_C3" }, //사원}, //자산관리번호 -FI_ASSET (메뉴한정-작업예정)
    // B02:{helpCode:"H_FI_BILLREC_MST_S", textField: "BIL_NO", codeField: "BIL_NO", helpSize:"largebig" }, //받을어음연동창 코드와명이동일    
    B02:{helpCode:"H_FI_BILLREC_MST_C", textField: "BIL_NO", codeField: "BIL_NO", helpSize:"largebig", helpCustom:true, helpViewUrl:"~/codehelp/FI/H_FI_BILLREC_MST_C"}, //받을어음연동창 코드와명이동일
    B03:{helpCode:"H_FI_BILLDEBT_MST_S", textField: "BIL_NO", codeField: "BIL_NO", helpSize:"largebig" }, //지급어음연동창 코드와명이동일
    B04:{helpCode:"H_FI_FINPRODUCT_MST_S02", textField: "FINPRODUCT_CD", codeField: "FINPRODUCT_NM", helpSize:"medium" }, //차입금관리번호 -FI_LOAN
    B05:{helpCode:"H_FI_STOCK_MST_S", textField: "STOCK_CD", codeField: "OILPRC_BOND_NM", helpSize:"big" }, //유가증권관리번호 -FI_STOCK
    B06:{helpCode:"NOTYET", textField: "CD_XXXXXX", codeField: "NM_XXXXXX"}, //LC번호 -TR_LC_IMH (메뉴한정-작업예정)
    B07:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P00280"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //미착품구분 -P00280
    B08:{helpCode:"H_FI_FINPRODUCT_MST_S03", textField: "FINPRODUCT_CD", codeField: "FINPRODUCT_NM", helpSize:"medium" }, //대여금관리번호 -FI_LEAD
    B11:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P00550", limit_cd_sysdef:"11|12|14|21|22|23|24|25|26|27|31|71|81|"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //자산처리구분 -P00550
    B12:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P00420"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //받을어음정리구분 P00020
    B13:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P00420"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //지급어음정리구분 P00020
    B24:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P00840"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //MA_B000005 통화
    B27:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P00820"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //타계정대체구분 FI_J000005, TP_ETCACCT
    B28:{helpCode:"H_FI_VRACCT_MST_S", textField: "VIRT_NO", codeField: "VIRT_NO", helpSize:"largebig", helpCustom:true, helpViewUrl: "~/codehelp/FI/H_FI_VRACCT_MST_S", helpApiUrl: "~/api/FI/FICustomCodeHelpService/H_FI_VRACCT_MST_S_list"}, //가상계좌
    //B50:{helpCode:"NOTYET", textField: "CD_XXXXXX", codeField: "NM_XXXXXX"}, //전자어음연동창 (메뉴한정-작업예정)
    //B51:{helpCode:"H_MA_CODEDTL_S", helpParams:{cd_module:"MA",cd_field:"P00020"}, textField: "CD_SYSDEF", codeField: "NM_SYSDEF", helpSize:"medium" }, //전자어음정리구분
    B53:{helpCode:"NOTYET", textField: "CD_XXXXXX", codeField: "NM_XXXXXX"}, //분할배서어음번호연동창 (메뉴한정-작업예정)
    //B54:{helpCode:"H_FI_FUND_MST_S2", textField: "FUND_CD", codeField: "FUND_NM", helpSize:"medium" }, // 자금과목
    B54:{helpCode:"H_FI_FUND_MST_C02", textField: "FUND_CD", codeField: "FUND_NM", helpSize:"big", helpCustom:true, helpViewUrl:"~/codehelp/FI/H_FI_FUND_MST_C02", helpApiUrl: "~/api/FI/FICustomCodeHelpService/H_FI_FUND_MST_C02"/*, helpParams:{acct_cd:"", drcrfg_cd:"", use_yn:"", keyword:""*/}, // 자금과목    
    B55:{helpCode:"H_PU_PURORDER_DTL_S", textField: "PURDOC_NO_SQ", codeField: "PURDOC_NO", helpSize:"big"}, //구매문서번호
    B56:{helpCode:"H_FI_CAR_INFO_S", textField: "BIZ_CAR_CD", codeField: "CAR_NM", helpSize:"medium", helpParams:{combo0:"Y"}}, //업무용차량
    B57:{helpCode:"H_FI_ASSETPUR_MST_S", textField: "PASSET_CD", codeField: "PASSET_NM", helpSize:"medium", helpParams:{combo0:"N"} }, //건설중인자산
    B58:{helpCode:"H_PM_ORDER_MST_C", textField: "PM_ORD_NO", codeField: "PM_ORD_NM", helpSize:"big", helpCustom:true, helpViewUrl: "~/codehelp/PM/H_PM_ORDER_MST_C", helpApiUrl: "~/api/PM/PMCustomCodeHelpService/pmcpop02600_list"}, //설비오더
    B59:{helpCode:"H_FI_FINPRODUCT_MST_S07", textField: "FINPRODUCT_CD", codeField: "FINPRODUCT_NM", helpSize:"medium" }, //차입금관리번호 -FI_LOAN
    B60:{helpCode:"H_RE_LEASE_MST_C", textField: "LEASE_CONT_NO", codeField: "LEASE_CONT_NM", helpSize:"big", helpCustom:true, helpViewUrl: "~/codehelp/RE/H_RE_LEASE_MST_C", helpApiUrl: "~/api/RE/Fimlsm00300Service/fimlsm00300_master_list"}, //리스계약번호
    B61:{helpCode:"H_FI_TCOST_MST", textField: "PRPY_MNG_NO", codeField: "PRPY_MNG_NO", helpSize:"big", helpCustom:true, helpViewUrl: "~/codehelp/FI/H_FI_TCOST_MST", helpApiUrl: "~/api/FI/FICustomCodeHelpService/H_FI_TCOST_MST_list"}, //리스계약번호

    B64:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30090",flag_cd:"31"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //차입구분 FI P30090
    B65:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30090",flag_cd:"35"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //사채구분 FI P30090
    B66:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30090",flag_cd:"11|13|14|16|19"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //운용상품구분 FI P30090
    B67:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30090",flag_cd:"21"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //대여구분 FI P30090
    B68:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30110"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //주식구분 FI P30110

    B73:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30091",limit_cd_sysdef:"29|30"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //차입구분 FI P30091
    B74:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30091",limit_cd_sysdef:"29|30"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //사채구분 FI P30091

    B79:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30091",limit_cd_sysdef:"12|13|14|15|16|17|18|19|20|21|22|23|24|25|26"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //상품구분 FI P30091
    B80:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P30091",limit_cd_sysdef:"27|28"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //대여구분 FI P30091

    //Type C
    C01:{helpCode:"H_MA_PARTNER_MST_S", textField: "BIZR_NO", codeField: "BIZR_NO", helpSize:"big", helpCustom:true, helpViewUrl:"~/codehelp/MA/H_MA_PARTNER_MST_C"}, //사업자등록번호 (거래처도움창으로 대체)
    C03:{helpCode:"H_MA_COA_MST_S02", textField: "ACCT_CD", codeField: "ACCT_NM", helpWidth:"", helpHeight:"", helpSize:"big" }, //대체계정 -계정도움창
    C07:{helpCode:"H_MA_PARTNER_MST_S", textField: "PARTNER_CD", codeField: "PARTNER_NM", helpSize:"big", helpCustom:true, helpViewUrl: "~/codehelp/MA/H_MA_PARTNER_MST_C"}, //배서처에서 > 거래처 -MA_PARTNER
    C13:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P01080"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //자타수구분 FI_F000005
    C14:{helpCode:"H_MA_TAX_MST_S", textField: "TAXAFS_CD", codeField: "TAXAFS_CD_NM", helpSize:"largebig", helpParams : { auth_taxcat:"A|B|"}}, //세무구분 (메뉴한정-작업예정)
    C15:{helpCode:"H_MA_PARTNER_DEPOSIT_S", textField: "PARTNER_ACNT_SQ", codeField: "NAME", helpSize:"medium" }, //거래처계좌번호 MA_PARTNER_DEPOSIT.CD_DEPOSITNO (거래처도움창으로 대체)
    C18:{helpCode:"H_MA_TAX_MST_S01", textField: "REASON_CD", codeField: "REASON_CD_NM", helpSize:"largebig", helpParams : { taxcat_cd : "A", taxafs_cd: "24"}}, //불공제구분 FI_T000002 > 세무구분도움창에서 (메뉴한정-작업예정)
    C19:{helpCode:"H_HR_EARNER_MST_S1", textField: "INCMPER_NO", codeField: "INCMPER_NM", helpSize:"medium"}, //기타소득자 (메뉴한정-작업예정)
    C20:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P40060"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //증빙구분
    C22:{helpCode:"H_MA_PAYMENT_MST_S", textField: "TERPAY_CD", codeField: "TERPAY_NM", helpSize:"medium"}, //결재조건 SA_B000002
    C23:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P00920"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //지급구분 PU_C000044
    C28:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"MA",field_cd:"P00920"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //결재수단 MA P00920
    C30:{helpCode:"NOTYET", textField: "CD_XXXXXX", codeField: "NM_XXXXXX"}, //법인카드사용처(?몰라?) editalbe:false
    C31:{helpCode:"H_MA_ITEMGRP_INFO_S", textField: "ITEM_GRP_CD", codeField: "ITEM_GRP_NM", helpSize:"medium"}, //품목군
    C32:{helpCode:"NOTYET", textField: "CD_XXXXXX", codeField: "NM_XXXXXX"}, //피배서인(전자어음연동창) editalbe:false
    C36:{helpCode:"H_HR_EARNER_MST_S2", textField: "INCMPER_NO", codeField: "INCMPER_NM", helpSize:"medium"}, //사업소득자 (메뉴한정-작업예정)
    C37:{helpCode:"NO_HELP", textField: "CD", codeField: "NM"}, //세금계산서번호 (부가세연동창) editalbe:false
    //C38:{helpCode:"NO_HELP", textField: "CD", codeField: "NM"}, //전자세금계산서발행구분 (부가세연동창) editalbe:false
    //C39:{helpCode:"NO_HELP", textField: "CD", codeField: "NM"}, //국세청기한내전송여부 (부가세연동창) editalbe:false
    C38:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"S40170"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //전자세금계산서발행구분 (부가세연동창) S40170
    C39:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"P00190"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //국세청기한내전송여부 (부가세연동창) P00190
    C45:{helpCode:"H_MA_PARTNER_MST_S", textField: "PARTNER_CD", codeField: "PARTNER_NM", helpSize:"large", helpCustom:true, helpViewUrl: "~/codehelp/MA/H_MA_PARTNER_MST_C"}, //접대상대 (접대비연동창) editalbe:false
    C49:{helpCode:"H_MA_PLANT_MST_S", textField: "PLANT_CD", codeField: "PLANT_NM", helpSize:"big"}, //공장
    C52:{helpCode:"H_MA_TAX_MST_S01", textField: "REASON_CD", codeField: "REASON_CD_NM", helpSize:"largebig", helpParams : { taxcat_cd : "A", taxafs_cd: ""}}, //불공제구분 FI_T000002 > 세무구분도움창에서 (메뉴한정-작업예정)
    C57:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"FI",field_cd:"S41800"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, //자산거래유형 FI S41800

    C58:{helpCode:"H_MA_COA_MST_S02", textField: "ACCT_CD", codeField: "ACCT_NM", helpWidth:"", helpHeight:"", helpSize:"big"}, //(본지점용)계정코드
    C59:{helpCode:"H_MA_CC_MST_S2", textField: "CC_CD", codeField: "CC_NM", helpSize:"largebig"}, //(본지점용)비용센터

    C62:{helpCode:"H_LR_IMCONT_INFO_C02", textField: "ENTR_NO", codeField: "CTCR_NM", helpSize:"big", helpCustom:true, helpViewUrl: "~/codehelp/LR/H_LR_IMCONT_INFO_C02", helpApiUrl: "~/api/LR/LRCustomCodeHelpService/H_LR_IMCONT_INFO_C02"}, //임대계약번호
    C63:{helpCode:"H_LR_IMCHACONT_INFO_C", textField: "RENT_CONT_NO", codeField: "LS_CONT_NM", helpSize:"big", helpCustom:true, helpViewUrl: "~/codehelp/LR/H_LR_IMCHACONT_INFO_C", helpApiUrl: "~/api/LR/LRCustomCodeHelpService/H_LR_IMCHACONT_INFO_C"}, //임차계약번호

    C64:{helpCode:"H_MA_BIZAREA_MST_S", textField: "BIZAREA_CD", codeField: "BIZAREA_NM", helpSize:"medium" }, //이관지사
    C65:{helpCode:"H_MA_BIZAREA_MST_S", textField: "BIZAREA_CD", codeField: "BIZAREA_NM", helpSize:"medium" }, //받는지사
    C66:{helpCode:"H_HR_EMP_MST_C", textField: "EMP_NO", codeField: "KOR_NM", helpSize:"big", helpCustom:true, helpViewUrl:"~/codehelp/HR/H_HR_EMP_MST_C", helpApiUrl: "~/api/MA/MACustomCodeHelpService/HR_EMP_MST_C_list", helpParams:{company_cd:"", pc_cd_pipe:"", bizarea_cd_pipe:"", dept_cd_pipe:"", hlof_fg_cd:"", emp_cd:"", start:0, count:500, combo0 : "1"}}, //수신자명
    C67:{helpCode:"NO_HELP", textField: "CD", codeField: "NM"}, //현금승인번호 (부가세연동창) editalbe:false
    C69:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"HR",field_cd:"P03170"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM", helpSize:"medium" }, //원천세소득구분
    C70:{helpCode:"H_LR_BRANCH_MST_S", textField: "BRN_CD", codeField: "BRN_NM", helpSize:"medium" }, //사업지 도움창
    C71:{helpCode:"H_MA_PARTNER_CRNC_S", textField: "CRNC_PARTNER_ACNT_SQ", codeField: "CRNC_NAME", helpSize:"medium" }, //거래처계좌번호 MA_PARTNER_CRNC    
    C72:{helpCode:"H_LR_NOH_MST_C", textField: "HO_NO", codeField: "HO_NM", helpSize:"big", helpCustom:true, helpViewUrl: "~/codehelp/HM/H_LR_NOH_MST_C", helpApiUrl: "~/api/HM/HMCustomCodeHelpService/H_LR_NOH_MST_C01"}, // 사업지호실
    C73:{helpCode:"H_MA_CODEDTL_S", helpParams:{module_cd:"HM",field_cd:"HP0230"}, textField: "SYSDEF_CD", codeField: "SYSDEF_NM"}, // 분양별도품목관리
    
    //Type D
    D11:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D11", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D13:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D13", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D14:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D14", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D19:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D19", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D20:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D20", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D21:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D21", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D23:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D23", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D25:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D25", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D26:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D26", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D27:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D27", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D30:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D30", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D31:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D31", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
    D33:{helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:"D33", combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"},
  };

  dews.api.get(dews.url.getApiUrl('FI', 'GeneralLedgerDocumentDOCService', 'glddoc00500_list_ma_acctmng'), {
    async : false
  }).done(function(data) {
    $.each(data, function(idx, item){
      module.controlItemCodepickerOptions[item.MCLS_CD] = {helpCode:"H_MA_ACCTMNG_DTL_S", helpParams:{mcls_cd:item.MCLS_CD, combo0 : "Y"}, textField: "MNGD_CD", codeField: "MNGD_NM", helpSize:"big"};
    });
  }).fail(function (xhr, status, error){
    dews.error(error);
  });

  module.swipeCodePicker = function(){
    var cloneData = $.extend(true, {}, module.controlItemCodepickerOptions);
    $.map(cloneData, function(value, key){
      var tf = value.textField;
      var cf = value.codeField;
      value.textField = cf;
      value.codeField = tf;
    });
    return cloneData;
  }

  console.log('## FI Module Script Loaded!!! ##');

  //////// 작성 영역 - 끝 ////////

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.js
