(function(dews, gerp, $) {
  //버튼추가
  if(dews.ui.page.$content.find("#btnWoonam").length == 0){
    dews.ui.page.$content.find(".dews-button-group").eq(0).prepend(
      '<button id="btnWoonam" class="dews-ui-button">전자증빙첨부</button>'
    )
    //버튼 초기화
    dews.ui.page.btnWoonam = dews.ui.button(dews.ui.page.$content.find("#btnWoonam"));
    dews.ui.page.btnWoonam.on("click", function(){
      var gridIndex = dews.ui.page.grid.select();
      if(gridIndex >= 0){
        var hData = dews.ui.page.grid.dataItem(gridIndex);
        if(!hData.DOCU_NO){
          dews.ui.snackbar.warning("저장후 증빙을 첨부할 수 있습니다.");
          return;
        }
        else if(hData.DOCU_ST_CD == "1" && !hData.CONN_KEY_YN) {
          dews.ui.snackbar.warning("첨부증빙이 없습니다.");
          return;
        }

        var key = "";
        if(!hData.CONN_KEY_VR){
          dews.api.post(dews.url.getApiUrl('FI', 'GeneralLedgerDocumentDOCService', 'getConnKeyVr'), {
            async: false,
            data: {
              company_cd: hData.COMPANY_CD,
              pc_cd: hData.PC_CD,
              docu_no: hData.DOCU_NO
            },
          }).done(function (data) {
            key = data;
          }).fail(function (xhr, status, error) {
            dews.error(error);
          }).always(function () {
            // 성공, 실패와 관계없이 항상 실행합니다.
          });
          if(!key){
            return;
          }
        }
        else{
          key = hData.CONN_KEY_VR;
        }

        var viewMode = "VIEW";
        if(hData.DOCU_ST_CD == "2" && (hData.GWAPRVLST_CD == "1" || hData.GWAPRVLST_CD == "5" || hData.GWAPRVLST_CD == "6")){
          viewMode = "EDIT";
        }

        dews.api.get(dews.url.getApiUrl('FI', 'FiAttachX10067Service', 'getAttachUrl'), {
          async: false,
          data: {
            key: key,
            viewMode : viewMode
          },
          dataType: 'json'
        }).done(function (data) {
          if(data.RESULTCODE == '00'){ // 00: 에러, 01: 성공
            dews.error("Error : 증빙첨부 서버주소를 가져오는중 에러가 발생했습니다.");
            return false;
          }
          var fullUrl = data.RESULTDATA.fullUrl;
          var ret = window.open(fullUrl, "popAttach","width=1400,height=700");  // 우남 전자증빙 팝업화면 호출

        }).fail(function (xhr, status, error) {
          dews.error(error);
        }).always(function () {
          // 성공, 실패와 관계없이 항상 실행합니다.
        });

      }
      else{
        dews.ui.snackbar.warning("선택된 데이터가 없습니다.");
      }
    });
  }
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.x10067.js
