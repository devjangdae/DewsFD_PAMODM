(function(dews, extendModule, $) {
  dews.localize.load('', "FI_COMDIC");

  var module = {};
  
  var defaultCodeDetail = {
    MA: {
      P00880: { desc: dews.localize.get("결재상태구분", 'D0030578', '', 'FI_COMDIC') }
    }
  }
  var defaultControlConfig = {
    FI: {
      FI01060 : { desc: dews.localize.get("미결전표 반제 사용여부", 'D0090146', '', 'FI_COMDIC')},
      FI01330: {}
    },
    BM: {
      BM00010: { desc: dews.localize.get("사업계획 사용여부", 'D0030586', '', 'FI_COMDIC') }
    },
    MA: {
      MA00003: {},
      MA00005: {}
    }
  }

  dews.ajax.script('~/view/js/FI/fi.cm.js', {
    once: true,
    async: false
  }).fail(function (xhr, status, error) {
    dews.alert("fi.cm.js not found", "error");
  });
  
  module.util = {
    createUid: function () {
      var guid = (function () {
        return 'xxxxxxxx-xxxx-4xxx-9xxx-xxxxxxxxxxxx'.replace(/[xy]/g,
          function (c) {
            var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
          });
      })();
      return dews.createUUid(guid);
    },
    addReducer: function (prev, curr) {
      return prev + curr
    }
  }
  
   //반제 관련 생성자 정의 
  module.BanUtil = function(pageObj, options){
    var self = this;
    self.options = options;
    self.commonUtil = gerp.FI;
    self.pageObj = pageObj;
    self.repayList = [];
    self.isAutoRepay = false;
    
    self.pendingGrid = options.pendingGrid;
    self.repayGrid = options.repayGrid;
    self.companyInfo = gerp.FI.getCompanyInfo();

    self.codeDetail = $.extend(true, {}, defaultCodeDetail, options.extendCodeDetail);
    self.controlConfig = $.extend(true, {}, defaultControlConfig, options.extendsControlConfig);

  }
  module.BanUtil.prototype.repayGridValCheckEvent = function(e){
    var self = this;
    try {
      var pendingList = self.pendingGrid.getCheckedRows();
      var selectRow = e.grid.dataItems(e.row.index);

      if (e.cell.field == "DIFF_AMT" && e.cell.data) {
        var diff_amt = self.getDifferenceAmount();

        if (!selectRow.TARGET_DOCU_AMT) {
          throw dews.localize.get("환차손계산대상전표금액이 계산되지 않았습니다.", 'M0019461', '', 'FI_COMDIC');
        } else if (!selectRow.DIFF_ACCT_CD) {
          setTimeout(function () { e.grid.select(e.row.index, "DIFF_ACCT_NM") });
          throw dews.localize.get("차액계정이 입력되지 않았습니다.", 'M0019462', '', 'FI_COMDIC');
        } else if (e.cell.data < 0) {
          throw dews.localize.get("차액은 양수로만 입력 가능합니다.", 'M0019463', '', 'FI_COMDIC');
        } else if (e.cell.data > diff_amt) {
          throw dews.localize.get("차액 가능한 금액을 초과였습니다.", 'M0019464', '', 'FI_COMDIC');
        }
      } else if (e.cell.field == "CONFIRM_REPAY_AMT" && e.grid.dataItems(e.row.index).EXCH_CD != self.companyInfo.EXCH_CD) {
        if (self.isAutoRepay) {
          var prev_target_docu_amt = e.grid.dataItems(e.row.index).TARGET_DOCU_AMT;
          var prev_target_docu_amt2 = e.grid.dataItems(e.row.index).TARGET_DOCU_AMT2;
          var prev_confirm_repay_amt = e.grid.dataItems(e.row.index).CONFIRM_REPAY_AMT;
          var prev_confirm_repay_amt2 = e.grid.dataItems(e.row.index).CONFIRM_REPAY_AMT2;
          var prev_profit_loss_amt = e.grid.dataItems(e.row.index).PROFIT_LOSS_AMT;

          dews.confirm(dews.localize.get("반제계산된 내역이 있습니다. 초기화하시겠습니까?", 'M0013893', '', 'FI_COMDIC'), "ico2").yes(function () {
            self.clear();
          }).no(function () {
            e.grid.setCellValue(e.row.index, "TARGET_DOCU_AMT", prev_target_docu_amt, false);
            e.grid.setCellValue(e.row.index, "TARGET_DOCU_AMT2", prev_target_docu_amt2, false);
            e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT", prev_confirm_repay_amt, false);
            e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT2", prev_confirm_repay_amt2, false);
            e.grid.setCellValue(e.row.index, "PROFIT_LOSS_AMT", prev_profit_loss_amt, false);
          });
        }
      } else if (e.cell.field == "CONFIRM_REPAY_AMT2" || (e.cell.field == "CONFIRM_REPAY_AMT" && e.grid.dataItems(e.row.index).EXCH_CD == self.companyInfo.EXCH_CD)) {
        var confirm_repay_amt2 = 0;
        if (e.cell.data != undefined) {
          confirm_repay_amt2 = e.cell.data;
        }
        
        var limitAmount = pendingList.map(function (pending) {
          return pending.FMNY_BLNC_AMT;
        }).reduce(module.util.addReducer, 0);

        var targetUUID = e.grid.dataItems(e.row.index).__UUID;
        var computedRepayAmount = confirm_repay_amt2 + self.getComputedRepay(targetUUID).map(function (target) {
          return target.CONFIRM_REPAY_AMT2;
        }).reduce(module.util.addReducer, 0);

        if (e.cell.data) {
          if (pendingList.length == 0) {
            throw dews.localize.get("미결내역에 선택된 데이터가 없습니다.", 'M0013882', '', 'FI_COMDIC');
          } else if (confirm_repay_amt2 > selectRow.FMNY_BLNC_AMT) {
            throw dews.localize.get("거래확정 반제금액이 거래잔액보다 클 수 없습니다.", 'M0015210', '', 'FI_COMDIC');
          } else if (computedRepayAmount > limitAmount) {
            throw dews.localize.get("거래확정 반제금액이 미결내역의 거래잔액보다 클 수 없습니다.", 'M0019737', '', 'FI_COMDIC');
          }
        }
        
        if (!self.isLastRepay(e.row.index) || self.isAutoRepay) {
          var prev_target_docu_amt = e.grid.dataItems(e.row.index).TARGET_DOCU_AMT;
          var prev_target_docu_amt2 = e.grid.dataItems(e.row.index).TARGET_DOCU_AMT2;
          var prev_confirm_repay_amt = e.grid.dataItems(e.row.index).CONFIRM_REPAY_AMT;
          var prev_confirm_repay_amt2 = e.grid.dataItems(e.row.index).CONFIRM_REPAY_AMT2;
          var prev_profit_loss_amt = e.grid.dataItems(e.row.index).PROFIT_LOSS_AMT;

          dews.confirm(dews.localize.get("반제계산된 내역이 있습니다. 초기화하시겠습니까?", 'M0013893', '', 'FI_COMDIC'), "ico2").yes(function () {
            self.clear();
          }).no(function () {
            e.grid.setCellValue(e.row.index, "TARGET_DOCU_AMT", prev_target_docu_amt, false);
            e.grid.setCellValue(e.row.index, "TARGET_DOCU_AMT2", prev_target_docu_amt2, false);
            e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT", prev_confirm_repay_amt, false);
            e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT2", prev_confirm_repay_amt2, false);
            e.grid.setCellValue(e.row.index, "PROFIT_LOSS_AMT", prev_profit_loss_amt, false);
          });
        }
      }
    } catch (error) {
      dews.ui.snackbar.warning(error);
      if (e.cell.field == "DIFF_AMT") {
        e.grid.setCellValue(e.row.index, "DIFF_AMT", null);
      } else if (e.cell.field == "CONFIRM_REPAY_AMT") {
        e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT", null);
      } else if (e.cell.field == "CONFIRM_REPAY_AMT2") {
        e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT2", null);
      }

      setTimeout(function () {
        e.grid.select(e.row.index, e.cell.field);
      })
    }
  }
  module.BanUtil.prototype.repayGridSaveEvent = function(e){
    var self = this;
    if (e.cell.field == "DIFF_ACCT_NM") {
      if (!e.row.data.DIFF_ACCT_NM) {
        e.grid.setCellValue(e.row.index, "DIFF_ACCT_CD", null);
      }
    } else if (e.cell.field == "CC_NM" && !e.row.data.CC_NM) {
      e.grid.setCellValue(e.row.index, "CC_CD", null);
    } else if (e.cell.field == "WBS_NM" && !e.row.data.WBS_NM) {
      e.grid.setCellValue(e.row.index, "WBS_NO", null);
    } else if (e.cell.field == "BIZPLAN_NM" && !e.row.data.BIZPLAN_NM) {
      e.grid.setCellValue(e.row.index, "CC_CD", null);
    } else if (e.cell.field == "BGACCT_NM" && !e.row.data.BGACCT_NM) {
      e.grid.setCellValue(e.row.index, "BGACCT_CD", null);
    } else if (e.cell.field == "CONFIRM_REPAY_AMT" && e.row.data) {
      // 환종이 회사환종과 같을 경우 거래확정반제금액에 금액 세팅
      if(e.row.data.EXCH_CD == self.companyInfo.EXCH_CD) {
        e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT2", e.row.data.CONFIRM_REPAY_AMT);
        e.grid.setCellValue(e.row.index, 'TARGET_DOCU_AMT', e.row.data.CONFIRM_REPAY_AMT);
        e.grid.setCellValue(e.row.index, "TARGET_DOCU_AMT2", e.row.data.CONFIRM_REPAY_AMT);
      }

      
    } else if (e.cell.field == "CONFIRM_REPAY_AMT2" && e.row.data.CONFIRM_REPAY_AMT2) {
      var computedRepay = self.getComputedRepay(e.row.data.__UUID);
      var pendingList = self.pendingGrid.getCheckedRows();

      if (pendingList.length > 0) {
        var confirm_repay_amt = 0;
        var confirm_repay_amt2 = e.row.data.CONFIRM_REPAY_AMT2;

        self.repayGrid.resetRowStyle(e.row.index);
        pendingList.forEach(function (pending) {
          var balance = pending.FMNY_BLNC_AMT;

          if (confirm_repay_amt2 > 0) {
            while (computedRepay.length > 0) {
              balance -= computedRepay[0].CONFIRM_REPAY_AMT2;
              computedRepay.shift();
            }
            if (balance >= 0) {
              if (confirm_repay_amt2 > balance) {
                confirm_repay_amt += balance * pending.EXRT_RT;
                confirm_repay_amt2 -= balance;
                if (balance > 0) {
                  self.enableSplit(e.row.index);
                }
              } else {
                confirm_repay_amt += confirm_repay_amt2 * pending.EXRT_RT;
                confirm_repay_amt2 -= confirm_repay_amt2;
              }
            }
          }
        });
        if (confirm_repay_amt > 0) {
          e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT", setDecimalAmt(confirm_repay_amt, self.controlConfig.MA.MA00003.data.CTRL_VR));
        }
      }

      e.grid.setCellValue(e.row.index, "TARGET_DOCU_AMT", setDecimalAmt(e.row.data.CONFIRM_REPAY_AMT2 * e.row.data.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR));
      e.grid.setCellValue(e.row.index, "TARGET_DOCU_AMT2", e.row.data.CONFIRM_REPAY_AMT2);
    } else if (e.cell.field == "CONFIRM_REPAY_AMT2" && !e.row.data.CONFIRM_REPAY_AMT2) {
      e.grid.setCellValue(e.row.index, "CONFIRM_REPAY_AMT", null, false);
    } else if (e.cell.field == "TARGET_DOCU_AMT2" && e.row.data.TARGET_DOCU_AMT2) {
      e.grid.setCellValue(e.row.index, "PROFIT_LOSS_AMT", e.row.data.TARGET_DOCU_AMT - e.row.data.CONFIRM_REPAY_AMT);
    }
    self.update(e.row.data);
  }
  module.BanUtil.prototype.clear = function(){
    var self = this;
    self.repayList = [];
    self.isAutoRepay = false;
    self.repayGrid.cancelChanges();
    self.resetStyle();
  }
  module.BanUtil.prototype.getRepayList = function(){
    var self = this;
    if (!self.isAutoRepay) {
      self.setRepayList(self.invokeRepay());
    }
    return self.repayList;
  }
  module.BanUtil.prototype.setRepayList = function(repayList){
    var self = this;
    self.repayList = repayList;
  }
  module.BanUtil.prototype.isComplete = function () {
    var self = this;
    return self.getInCompleteList().some(function (value) {
      return value.CONFIRM_REPAY_AMT2;
    });
  }
  module.BanUtil.prototype.isLastRepay = function (index) {
    var self = this;
    var completeList = self.getInCompleteList().filter(function (value) {
      return value.CONFIRM_REPAY_AMT2;
    });
    if (completeList.length > 0) {
      var target = self.repayGrid.dataItems(index);
      var lastRepay = completeList[completeList.length - 1];
      if (target.CONFIRM_REPAY_AMT2) {
        return index == self.repayGrid.findIndex(lastRepay);
      }
    }
    return true;
  }
  module.BanUtil.prototype.enableSplit = function (index) {
    var self = this;
    self.repayGrid.setRowStyle(index, { background: '#ffeb3b' });
    self.repayGrid.setCellValue(index, "isSplit", true);
  }
  module.BanUtil.prototype.getInCompleteList = function () {
    var self = this;
    return self.repayGrid.dataItems().filter(function (value) {
      return value.BAN_ST_CD == "1";
    });
  }
  module.BanUtil.prototype.getComputedRepay = function (exceptUUID) {
    var self = this;
    return self.getInCompleteList().filter(function (value) {
      return value.__UUID != exceptUUID && value.CONFIRM_REPAY_AMT2;
    });
  }
  module.BanUtil.prototype.getDifferenceAmount = function () {
    var self = this;
    var docu_amt = self.getInCompleteList().map(function (value) {
      if (value.CONFIRM_REPAY_AMT2) {
        return value.BLNC_AMT;
      }
    }).reduce(module.util.addReducer, 0);

    var target_docu_amt = self.getInCompleteList().map(function (value) {
      if (value.CONFIRM_REPAY_AMT2) {
        return value.TARGET_DOCU_AMT;
      }
    }).reduce(module.util.addReducer, 0);

    var diff_amt = self.getInCompleteList().filter(function (value) {
      if (value.CONFIRM_REPAY_AMT2 && value.DIFF_AMT) {
        return true;
      }
    }).map(function (value) {
      return value.DIFF_AMT;
    }).reduce(module.util.addReducer, 0);

    return docu_amt - target_docu_amt - diff_amt;
  }
  module.BanUtil.prototype.resetStyle = function () {
    var self = this;
    var indexes = self.repayGrid.dataItems().map(function (value, index) { return index });
    self.repayGrid.resetRowStyle(indexes);
  }
  module.BanUtil.prototype.update = function (data) {
    var self = this;
    self.repayList.forEach(function (value) {
      value.repayList.forEach(function (repay) {
        if (repay.__UUID == data.__UUID) {
          $.extend(repay, data);
        }
      });
    });
  }
  module.BanUtil.prototype.setRepayAmount = function (index, target) {
    var self = this;
    self.repayGrid.setCellValue(index, "TARGET_DOCU_AMT", target.TARGET_DOCU_AMT, false);
    self.repayGrid.setCellValue(index, "TARGET_DOCU_AMT2", target.TARGET_DOCU_AMT2, false);
    self.repayGrid.setCellValue(index, "CONFIRM_REPAY_AMT", target.CONFIRM_REPAY_AMT, false);
    self.repayGrid.setCellValue(index, "CONFIRM_REPAY_AMT2", target.CONFIRM_REPAY_AMT2, false);
    self.repayGrid.setCellValue(index, "PROFIT_LOSS_AMT", target.PROFIT_LOSS_AMT, false);
  }
  
  module.BanUtil.prototype.invokeRepay = function () {
    var self = this;
    var repayList = [];
    var pendingList = self.pendingGrid.getCheckedRows();
    var targetList = self.getInCompleteList().filter(function (target) {
      return target.CONFIRM_REPAY_AMT2;
    });

    pendingList.forEach(function (pending) {
      if (targetList.length == 0) {
        return;
      }

      var balance = pending.BLNC_AMT;
      var fmny_balance = pending.FMNY_BLNC_AMT;
      var details = {
        pending: pending,
        repayList: []
      };

      while (targetList.length > 0) {
        var target = targetList[0];
        target.newUid = module.util.createUid();
        if (target.CONFIRM_REPAY_AMT2 <= fmny_balance) {
        	target.PROFIT_LOSS_AMT = setDecimalAmt(target.CONFIRM_REPAY_AMT2 * target.EXRT_RT - target.CONFIRM_REPAY_AMT2 * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR);

          balance -= target.CONFIRM_REPAY_AMT;
          fmny_balance -= target.CONFIRM_REPAY_AMT2;

          details.repayList.push(target);
          targetList.shift();
        } else {
          if (fmny_balance == 0) break;
          var currentTaget = $.extend({}, target, {
            CONFIRM_REPAY_AMT: balance,
            CONFIRM_REPAY_AMT2: fmny_balance,
            TARGET_DOCU_AMT: setDecimalAmt(fmny_balance * target.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR),
            TARGET_DOCU_AMT2: fmny_balance,
            PROFIT_LOSS_AMT: setDecimalAmt(fmny_balance * target.EXRT_RT - fmny_balance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR)
          });

          target.CONFIRM_REPAY_AMT -= balance;
          target.CONFIRM_REPAY_AMT2 -= fmny_balance;
          target.TARGET_DOCU_AMT = setDecimalAmt(target.CONFIRM_REPAY_AMT2 * target.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR);
          target.TARGET_DOCU_AMT2 = target.CONFIRM_REPAY_AMT2;
          balance -= balance;
          fmny_balance -= fmny_balance;

          details.repayList.push(currentTaget);
          break;
        }
      }

      if (fmny_balance > 0) {
        pending.BLNC_AMT -= balance
        pending.FMNY_BLNC_AMT -= fmny_balance;
      }
      repayList.push(details);
    });

    return repayList;
  }

  module.BanUtil.prototype.autoRepay = function () {
    var self = this;
    self.clear();
    self.isAutoRepay = true;

    var pendingList = self.pendingGrid.getCheckedRows();
    var targetList = self.getInCompleteList();
    pendingList.forEach(function (pending) {
      if (targetList.length == 0) {
        return;
      }
      var balance = pending.BLNC_AMT;
      var fmny_balance = pending.FMNY_BLNC_AMT;
      var details = {
        pending: pending,
        repayList: []
      };

      while (targetList.length > 0) {
        var target = targetList[0];
        var index = self.repayGrid.findIndex(target);
        target.balance = target.balance || target.BLNC_AMT;
        target.foreignBalance = target.foreignBalance || target.FMNY_BLNC_AMT;

        if (target.foreignBalance <= fmny_balance) {
          if (target.CONFIRM_REPAY_AMT2 > 0) {
            var currentTaget = $.extend({}, target, {
              newUid: module.util.createUid(),
              TARGET_DOCU_AMT: setDecimalAmt(target.foreignBalance * target.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR), 
              TARGET_DOCU_AMT2: target.foreignBalance,
              CONFIRM_REPAY_AMT: setDecimalAmt(target.foreignBalance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR),
              CONFIRM_REPAY_AMT2: target.foreignBalance,
              PROFIT_LOSS_AMT: setDecimalAmt(target.foreignBalance * target.EXRT_RT - target.foreignBalance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR)
            });
            details.repayList.push(currentTaget);
            self.enableSplit(index);

            target.TARGET_DOCU_AMT += currentTaget.TARGET_DOCU_AMT;
            target.TARGET_DOCU_AMT2 += currentTaget.TARGET_DOCU_AMT2;
            target.CONFIRM_REPAY_AMT += currentTaget.CONFIRM_REPAY_AMT
            target.CONFIRM_REPAY_AMT2 += currentTaget.CONFIRM_REPAY_AMT2;
            target.PROFIT_LOSS_AMT += currentTaget.PROFIT_LOSS_AMT;
            self.setRepayAmount(index, target);

            target.balance -= target.balance;
            target.foreignBalance -= target.foreignBalance;
            balance -= currentTaget.CONFIRM_REPAY_AMT;
            fmny_balance -= currentTaget.CONFIRM_REPAY_AMT2;
          } else {
            target.newUid = module.util.createUid();
            target.TARGET_DOCU_AMT = target.balance;
            target.TARGET_DOCU_AMT2 = target.foreignBalance;
            target.CONFIRM_REPAY_AMT = setDecimalAmt(target.foreignBalance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR);
            target.CONFIRM_REPAY_AMT2 = target.foreignBalance;
            target.PROFIT_LOSS_AMT = setDecimalAmt(target.foreignBalance * target.EXRT_RT - target.foreignBalance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR);
            self.setRepayAmount(index, target);
            details.repayList.push(target);

            balance -= target.balance;
            fmny_balance -= target.foreignBalance;
          }

          targetList.shift();
        } else {
          if (target.CONFIRM_REPAY_AMT > 0) {
            var currentTaget = $.extend({}, target, {
              newUid: module.util.createUid(),
              TARGET_DOCU_AMT: setDecimalAmt(fmny_balance * target.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR),
              TARGET_DOCU_AMT2: fmny_balance,
              CONFIRM_REPAY_AMT: setDecimalAmt(fmny_balance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR),
              CONFIRM_REPAY_AMT2: fmny_balance,
              PROFIT_LOSS_AMT: setDecimalAmt(fmny_balance * target.EXRT_RT - fmny_balance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR)
            });
            details.repayList.push(currentTaget);
            self.enableSplit(index);

            target.TARGET_DOCU_AMT += currentTaget.TARGET_DOCU_AMT;
            target.TARGET_DOCU_AMT2 += currentTaget.TARGET_DOCU_AMT2;
            target.CONFIRM_REPAY_AMT += currentTaget.CONFIRM_REPAY_AMT;
            target.CONFIRM_REPAY_AMT2 += currentTaget.CONFIRM_REPAY_AMT2;
            target.PROFIT_LOSS_AMT += currentTaget.PROFIT_LOSS_AMT;
            self.setRepayAmount(index, target);

            target.balance -= balance;
            target.foreignBalance -= fmny_balance;
            balance -= balance;
            fmny_balance -= fmny_balance;
            break;
          } else {
            if(fmny_balance == 0) {
              break;
            }
            target.TARGET_DOCU_AMT = setDecimalAmt(fmny_balance * target.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR);
            target.TARGET_DOCU_AMT2 = fmny_balance;
            target.CONFIRM_REPAY_AMT = setDecimalAmt(fmny_balance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR);
            target.CONFIRM_REPAY_AMT2 = fmny_balance;
            target.PROFIT_LOSS_AMT = setDecimalAmt(fmny_balance * target.EXRT_RT - fmny_balance * pending.EXRT_RT, self.controlConfig.MA.MA00003.data.CTRL_VR);
            self.setRepayAmount(index, target);

            var currentTaget = $.extend({}, target, {
              newUid: module.util.createUid(),
              TARGET_DOCU_AMT: target.TARGET_DOCU_AMT,
              TARGET_DOCU_AMT2: target.TARGET_DOCU_AMT2,
              CONFIRM_REPAY_AMT: target.CONFIRM_REPAY_AMT,
              CONFIRM_REPAY_AMT2: target.CONFIRM_REPAY_AMT2,
              PROFIT_LOSS_AMT: target.PROFIT_LOSS_AMT
            });
            details.repayList.push(currentTaget);

            target.balance -= balance;
            target.foreignBalance -= fmny_balance;
            balance -= balance;
            fmny_balance -= fmny_balance;
            break;
          }
        }
      }

      if (fmny_balance > 0) {
        pending.BLNC_AMT -= balance;
        pending.FMNY_BLNC_AMT -= fmny_balance;
      }

      self.repayList.push(details);
    });
  }
  module.BanUtil.prototype.findSplit = function (data) {
    var self = this;
    return self.getRepayList().flatMap(function (value) {
      return value.repayList;
    }).filter(function (value) {
      return value.__UUID == data.__UUID;
    });
  }
  module.BanUtil.prototype.openSplit = function (data) {
    var self = this;
    var dialog = dews.ui.dialog("AREARC00600_SPLIT", {
      url: "/view/FI/AREARC00600_SPLIT",
      title: dews.localize.get("분개내역", '11110147', '', 'FI_COMDIC'),
      width: 1200,
      height: 630,
      initData: {
        useBizplan: self.controlConfig.BM.BM00010.data.CTRL_VR == "Y",
        differenceAmount: self.getDifferenceAmount(),
        repayList: self.getRepayList(),
        repaySplitList: self.findSplit(data)
      },
      ok: function (repayList) {
        self.setRepayList(repayList);
      }
    });
    dialog.open();
  }
  module.BanUtil.prototype.init = function(){
    var self = this;

    self._setCodeDetail();
    self._setControlConfig();
    self._extendGrid();

    //메뉴단에서 정의된 save event unbind
    self.repayGrid.$element.unbind("save");
    if(self.options.repaySave != undefined){
      self.repayGrid.on('save', function(e){
        self.options.repaySave(e);    
      });
    } else {
      self.repayGrid.on('save', function(e){
        self.repayGridSaveEvent(e);
      });
    }

    //메뉴단에서 정의된 validationCheck event unbind
    self.repayGrid.$element.unbind("validationCheck");
    if(self.options.repayValCheck != undefined){
      self.repayGrid.on('validationCheck', function(e){
        self.options.repayValCheck(e);
      })
    } else {
      self.repayGrid.on('validationCheck', function(e){
        self.repayGridValCheckEvent(e);
      })
    }
  }
  module.BanUtil.prototype._setCodeDetail = function(){
    var that = this;
    for (var module in this.codeDetail) {
      var fields = Object.keys(this.codeDetail[module]);
      var codeDtl = {};
      this.commonUtil.getCodeData(codeDtl, module, fields.join("|"), fields.join("|"), "", "", "", "", "");
      fields.forEach(function (field) {
        that.codeDetail[module][field].data = codeDtl[module][field];
        that.codeDetail[module][field].dataSource = dews.ui.dataSource("dataSource", {});
        that.codeDetail[module][field].dataSource.data(that.codeDetail[module][field].data);
      });
    }
  }
  module.BanUtil.prototype._setControlConfig = function(){
    var that = this;
    for (var module in that.controlConfig) {
      var fields = Object.keys(that.controlConfig[module]);
      var data = this.commonUtil.getControlConfig(module, fields.join("|"));
      fields.forEach(function (field) {
        that.controlConfig[module][field].data = data[field];
      });
    }
  }
  module.BanUtil.prototype._extendGrid = function(){
    var self = this;
    
    var gridHandler = {
      findByUUID: function (UUID) {
        var findList = this.dataItems().filter(function (value) {
          return value.__UUID == UUID;
        });
        if (findList.length > 0) {
          return findList[0];
        }
        return null;
      },
      findIndex: function (data) {
        return this.dataItems().findIndex(function (value) {
          return value.__UUID == data.__UUID;
        });
      }
    };
    self.pageObj.$content.find(".dews-ui-grid").each(function (index, $grid) {
      Object.assign(self.pageObj[$grid.id].__proto__, gridHandler);
    });

    $.extend(self.repayGrid, {
      custom: {
        editable: function (e) {
          if (e.row.data.BAN_ST_CD == "2") {
            return false;
          } else if (e.row.data.isSplit) {
            return false;
          } else {
            return true;
          }
        }
      }
    });
  }
  module.BanUtil.prototype.chkPartnerConfig = function(pendingList, repayList) {
	var self = this;
	var slipChk = true;
	var fi01330 = self.controlConfig.FI.FI01330.data.CTRL_VR;
	if (fi01330 != null && fi01330 == "Y") {
	  // 가수금 내역 그리드와 반제대상 내역 그리드의 거래처 각각 비교
	  var pendingPartner = pendingList.map(function (ele) { return ele.PARTNER_CD; });
	  var distPendingPartner = pendingPartner.filter(function (item, idx, lst) { return lst.indexOf(item) == idx; });
	  var repayPartner = repayList.map(function (ele) { return ele.PARTNER_CD; });
	  var distRepayPartner = repayPartner.filter(function (item, idx, lst) { return lst.indexOf(item) == idx; });
	  if (!(JSON.stringify(distPendingPartner.sort()) === JSON.stringify(distRepayPartner.sort()))) {
		  slipChk = false;
	  }
	}
	return slipChk;
  }

  module.SlipUtil = function(banUtil, options){
    var self = this;
    self.ban = banUtil;
    self.pageObj = self.ban.pageObj;
    self.preview = options.preview;
    self.save = options.save;
    self.remove = options.remove;
  }

  module.SlipUtil.prototype.isFillRepayAccount = function () {
    var self = this;
    return self.ban.getInCompleteList().every(function (value) {
      return value.ACCT_CD;
    });
  }
  module.SlipUtil.prototype.isSelfMenu = function (pendingRepay) {
    var self = this;
    return pendingRepay.every(function (value) {
      return value.MENU_CD == self.pageObj.menu.id;
    });
  }
  module.SlipUtil.prototype.isCompleteRepay = function (list) {
    var self = this;
    return list.some(function (value) {
      return value.BAN_ST_CD == "2";
    });
  }
  module.SlipUtil.prototype.isApproval = function (list) {
    var self = this;
    return list.some(function (value) {
      return value.DOCU_ST_CD == "1";
    });
  }
  module.SlipUtil.prototype.loadSlip = function () {
    var self = this;
    dews.ui.loading.show({
      type: "tiny",
      text: dews.localize.get("전표정보를 불러오는 중입니다.", 'M0004105', '', 'FI_COMDIC')
    });
    return dews.api.post(self.preview.url, {
      data: self.preview.param()
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    }).always(function () {
      dews.ui.loading.hide();
    })
  }
  module.SlipUtil.prototype.openPreview = function openPreview(docuData) {
    var self = this;
    var dialog = dews.ui.dialog("GLDDOC00500_PREVIEW", {
      url: "/view/FI/GLDDOC00500_PREVIEW",
      title: dews.localize.get("전표처리정보", 'D0004061', '', 'FI_COMDIC'),
      width: 720,
      height: 586,
      initData: {
        menuId: self.pageObj.menu.id,
        docuData: docuData,
        mainTitle: dews.localize.get("전표정보", 'D0005281', '', 'FI_COMDIC')
      },
      ok: function (data) {
        self.invokeSlip(data).done(function () {
          dews.ui.snackbar.ok(dews.localize.get("전표처리가 완료되었습니다.", 'M0001635', '', 'FI_COMDIC'));
          self.save.done();
        });
      }
    });
    dialog.open();
  }
  module.SlipUtil.prototype.invokeSlip = function (slip) {
    var self = this;
    dews.ui.loading.show({
      type: "tiny",
      text: dews.localize.get("전표처리 진행중입니다.", 'M0004106', '', 'FI_COMDIC')
    });
    return dews.api.post(self.save.url, {
      data: {
        slip: slip
      }
    }).fail(function (xhr, status, error) {
      var dialog = dews.ui.dialog("error", {
        title: dews.localize.get("에러", 'D0011132', '', 'FI_COMDIC'),
        content: error,
        width: 650,
        height: 500,
        buttons: 'close'
      });
      dialog.open();
    }).always(function () {
      dews.ui.loading.hide();
    })
  }
  module.SlipUtil.prototype.deleteSlip = function (pendingRepay) {
    var self = this;
    dews.ui.loading.show({
      type: "tiny",
      text: dews.localize.get("전표취소 진행중입니다.", 'M0012207', '', 'FI_COMDIC')
    });
    return dews.api.post(self.remove.url, {
      data: {
        pendingRepayList: JSON.stringify(pendingRepay)
      }
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    }).always(function () {
      dews.ui.loading.hide();
    })
  }
  
  console.log('## fi.ban.util.js Script Loaded!!! ##');
  var newModule = {};
  newModule.ban = module;
  window.fi = $.extend(true, extendModule, newModule);
})(window.dews, window.fi || {}, jQuery);

function setDecimalAmt(amt, decimal) {
  return +(Math.round(amt + "e+"+decimal)  + "e-"+decimal);
}
//# sourceURL=fi.ban.util.js