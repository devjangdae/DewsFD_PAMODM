(function(dews, gerp, $) {
  dews.localize.load('', "FI_COMDIC");

  var module = {};
  var moduleCode = 'FI_CM_UTIL';
  var DateEnum = {
    DATE : 1,   //일
    MONTH : 2,  //월
    YEAR : 3,   //년
    HOUR : 4,   //시
    MINUTE : 5, //분
    SECOND : 6, //초
    LAST_DAY_OF_MONTH : 7,  //월 마지막 일
    WEEK_OF_MONTH : 8,      //월의 주
    WEEK_OF_YEAR : 9,       //년의 주
    DAY_OF_WEEK : 10        //요일
  };
  var MessageEnum = {
    SEARCH_AGAIN_CONFIRM : dews.localize.get('저장하지 않은 데이터가 있습니다.\n조회를 계속하시겠습니까?', 'M0000638', '', 'FI_COMDIC'),   //재조회 확인 메세지
    CLOSE_CONFIRM : dews.localize.get('저장하지 않은 데이터가 있습니다.\n닫기를 계속하시겠습니까?', 'M0000646', '', 'FI_COMDIC'),          //종료 확인 메세지
    SAVE_CONFIRM : dews.localize.get('저장하시겠습니까?', 'M0000002', '', 'FI_COMDIC'),                                                 //저장 확인 메세지
    SAVE_DONE_ALERT : dews.localize.get('저장이 완료되었습니다.', 'M0000021', '', 'FI_COMDIC'),                                         //저장 완료 메세지
    SAVE_NO_DATA_ALERT : dews.localize.get('저장할 데이터가 없습니다.', 'M0001179', '', 'FI_COMDIC'),                                   //저장할 데이터 없는 메세지
    SAVE_VALID_ALERT : dews.localize.get('필수항목을 입력하지 않았습니다.', 'M0003685', '', 'FI_COMDIC'),                                //저장 필수값 메세지
    DELETE_CONFIRM : dews.localize.get('삭제 하시겠습니까?\n(반드시 저장을 하셔야 반영이 됩니다.)', 'D0088637', '', 'FI_COMDIC'),         //삭제 확인 메세지(화면상에서 삭제)
    DELETE_IMME_CONFIRM : dews.localize.get('삭제 하시겠습니까?', 'M0003805', '', 'FI_COMDIC'),                                         //삭제 확인 메세지(DB 삭제)
    DELETE_DONE_ALERT : dews.localize.get('삭제 되었습니다.', 'M0002500', '', 'FI_COMDIC'),                                             //삭제 완료 메세지
    SEARCH_LOADING : dews.localize.get('조회하는 중입니다.', 'M0007041', '', 'FI_COMDIC'),                                              //조회 로딩 메세지
    SAVE_LOADING : dews.localize.get('저장하는 중입니다.', 'M0007093', '', 'FI_COMDIC'),                                                //저장 로딩 메세지
    DELETE_LOADING : dews.localize.get('삭제하는 중입니다.', 'M0009058', '', 'FI_COMDIC')                                               //삭제 로딩 메세지
  }

  module.HttpUtil = {
		  
	// 현재 도메인 주소를 전달
    getDomain : function() {
        var url = window.location.hostname;
        if(location.port != null && location.port != '' && location.port != '80' && location.port != '443'){
          url +=":" + location.port;
        }
        return url;
    },
    
    // 로그인한 사용자의 X-Authenticate-Token 헤더를 전달
    getLoginUserAccessToken : function() {    	
     var accessToken = null;
     
	 dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'getLoginUserAccessToken'), {
        async: false
	 }).done(function(data) {
    	  accessToken = data;
	 }).fail(function(e) {
    	  accessToken = null;
	 });	 
	 return accessToken;    
    }
  }
  
  module.StringUtil = {
    /**
     * @section Description
     * @details 입력 받은 padChar 문자를 문자열 sourceString의 왼쪽에 문자열 길이가 totalLength 만큼 되도록 문자를 덧댄다.
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param String sourceString 입력 문자열
     * @param String padChar 덧댈 문자
     * @param Number totalLength 문자열 전체 길이
     * - @return String 변환 문자열
     * @example var dateString = stringUtil.padLeft("abcd", "*", 6);
     */
    padLeft : function(sourceString, padChar, totalLength){
      if(typeof sourceString != "string"){
        sourceString = sourceString + "";
      }
      var padding = "";
      for(var i = 0 ; i < totalLength ; i++){
        padding += padChar;
      }
      return padding.substring(sourceString.length) + "" + sourceString;
    }
  }

  module.ConvertUtil = {
    Date : {
      DateEnum : DateEnum,
      /**
       * @section Description
       * @details Date 타입을 입력 받아 'yyyyMMdd' 포맷의 문자열로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param Date sourceDate 입력 날짜
       * - @return String 변환 문자열
       * @example var dateString = convertUtil.Date.toString(new Date());
       */
      toString : function(sourceDate){
        var year = module.DateUtil.get(sourceDate, this.DateEnum.YEAR),
            month = module.DateUtil.get(sourceDate, this.DateEnum.MONTH),
            date = module.DateUtil.get(sourceDate, this.DateEnum.DATE);
        return year + module.StringUtil.padLeft(month, "0", 2) + module.StringUtil.padLeft(date, "0", 2);
      }
    },
    String : {
      /**
       * @section Description
       * @details String타입을 입력 받아 정수형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return Number 변환 값
       * @example var intValue = convertUtil.String.toInteger("123");
       */
      toInteger : function(sourceValue){
        return parseInt(sourceValue);
      },
      /**
       * @section Description
       * @details String타입을 입력 받아 실수형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return  변환 값
       * @example var doubleValue = convertUtil.String.toDouble("123.123");
       */
      toDouble : function(sourceValue){
        return parseFloat(sourceValue);
      },
      /**
       * @section Description
       * @details yyyyMMdd 포맷의 String 타입을 입력 받아 Date 형 데이터로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 문자열
       * - @return Date 변환 값
       * @example var dateValue = convertUtil.String.toDate("20181012");
       */
      toDate : function(sourceValue){
        if(sourceValue.length == 8){
          return new Date(sourceValue.substring(0, 4) + "/" + sourceValue.substring(4, 6) + "/" + sourceValue.substring(6, 8));
        } else {
          return undefined;
        }
      },
      /**
       * @section Description
       * @details 숫자를 입력받아, 3자리 마다 ',' 찍은 금액 문자열 반환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 값
       * - @return String 변환 값
       * @example var dateValue = convertUtil.String.toAmount("123123");
       */
      toAmount : function(sourceValue){
    	  if(isNaN(sourceValue)){
    		  console.log("ConvertUtil toAmount Call : sourceValue is not Number Type");
    		  return undefined
    	  } else {
    		  return sourceValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    	  }
      }
    },
    Array : {
      /**
       * @section Description
       * @details Array 형 데이터를 입력 받아 JSON 문자열로 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 배열
       * - @return String 변환 문자열
       * @example var stringValue = convertUtil.Array.toJsonString([1, 2, 3]);
       */
      toJsonString : function(sourceValue){
        return JSON.stringify(sourceValue);
      },
      /**
       * @section Description
       * @details Array 형 데이터를 입력 받아 구분자를 '|' 문자로 하는 문자열 변환
       * @author 강진혁(jhkang1313@douzone.com)
       * - @param String sourceValue 입력 배열
       * - @return String 변환 문자열
       * @example var stringValue = convertUtil.Array.toPipeString([1, 2, 3]);
       */
      toPipeString : function(sourceValue){
        return sourceValue.join('|');
      }
    }
  }

  module.DateUtil = {
    DateEnum : DateEnum,
    /**
     * @section Description
     * @details Date 형 데이터와 날짜 필드(정수형)를 입력 받아 날짜 필드 반환
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.get(new Date(), dateUtil.DateEnum.DATE);
     */
    get : function(sourceDate, dateEnum){
      var returnValue = undefined;
      if(!sourceDate instanceof Date){
        console.log('DateUtil get Call : sourceDate is not Date Object Type');
      } else if (!dateEnum instanceof Number){
        console.log('DateUtil get Call : dateEnum is not DateEnum Type');
      } else {
        switch(dateEnum){
          case this.DateEnum.DATE :
            returnValue = sourceDate.getDate();
            break;
          case this.DateEnum.MONTH :
            returnValue = sourceDate.getMonth() + 1;
            break;
          case this.DateEnum.YEAR :
            returnValue = sourceDate.getFullYear();
            break;
          case this.DateEnum.HOUR :
            returnValue = sourceDate.getHours();
            break;
          case this.DateEnum.MINUTE :
            returnValue = sourceDate.getMinutes();
            break;
          case this.DateEnum.SECOND :
            returnValue = sourceDate.getSeconds();
            break;
          case this.DateEnum.LAST_DAY_OF_MONTH :
            var year = this.get(sourceDate, this.DateEnum.YEAR);
            var month = this.get(sourceDate, this.DateEnum.MONTH);
            returnValue = (new Date(year, month, 0)).getDate();
            break;
          case this.DateEnum.DAY_OF_WEEK :
            returnValue = sourceDate.getDay();
            break;
          case this.DateEnum.WEEK_OF_MONTH :
            var date = this.get(sourceDate, this.DateEnum.DATE);
         	  var day = this.get(sourceDate, this.DateEnum.DAY_OF_WEEK);
         	  returnValue =  parseInt((6 + date - day) / 7) + 1;
            break;
          case this.DateEnum.WEEK_OF_YEAR :
            var year = this.get(sourceDate, this.DateEnum.YEAR);
            var month = this.get(sourceDate, this.DateEnum.MONTH);

            var totalWeek = 0;
            for(var i = month - 1; i > 0 ; i--){
              totalWeek += this.get(new Date(year, month, 0), this.DateEnum.WEEK_OF_MONTH);
            }
            totalWeek += this.get(sourceDate, this.WEEK_OF_MONTH);
            returnValue = totalWeek;
            break;
          default :
            console.log('DateUtil get Call : dateEnum is invalid');
            break;
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터와 날짜 필드(정수형), 증가 값을 입력 받아, 입력 날짜의 날짜 필드를 증가 값 만큼 더한 날짜 데이터 반환
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * @param Number value 증가 값
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.add(new Date(), dateUtil.DateEnum.DATE, 2);
     */
    add : function(sourceDate, dateEnum, value){
      var returnValue = undefined;
      if(!sourceDate instanceof Date){
        console.log('DateUtil add Call : sourceDate is not Date Object Type');
      } else if(!dateEnum instanceof Number){
        console.log('DateUtil add Call : dateEnum is not DateEnum Type');
      } else if(!value instanceof Number){
        console.log('DateUtil add Call : value is not Number Type');
      } else {
        switch(dateEnum){
          case this.DateEnum.DATE :
            returnValue = new Date(sourceDate.setDate(sourceDate.getDate() + value));
            break;
          case this.DateEnum.MONTH :
            returnValue = new Date(sourceDate.setMonth(sourceDate.getMonth() + value));
            break;
          case this.DateEnum.YEAR :
            returnValue = new Date(sourceDate.setFullYear(sourceDate.getFullYear() + value));
            break;
          case this.DateEnum.HOUR :
            returnValue = new Date(sourceDate.setHours(sourceDate.getHours() + value));
            break;
          case this.DateEnum.MINUTE :
            returnValue = new Date(sourceDate.setMinutes(sourceDate.getMinutes() + value));
            break;
          case this.DateEnum.SECOND :
            returnValue = new Date(sourceDate.setSeconds(sourceDate.getSeconds() + value));
          break;
          default :
            console.log('DateUtil get Call : dateEnum is invalid');
          break;
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터와 날짜 필드(정수형), 감소 값을 입력 받아, 입력 날짜의 날짜 필드를 감소 값 만큼 뺀 날짜 데이터 반환
     * @author 김샛별(sbkim13@douzone.com)
     * - @param Date sourceDate 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * @param Number value 감소 값
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.sub(new Date(), dateUtil.DateEnum.DATE, 2);
     */
    sub : function(sourceDate, dateEnum, value){
      var returnValue = undefined;
      if(!sourceDate instanceof Date){
        console.log('DateUtil sub Call : sourceDate is not Date Object Type');
      } else if(!dateEnum instanceof Number){
        console.log('DateUtil sub Call : dateEnum is not DateEnum Type');
      } else if(!value instanceof Number){
        console.log('DateUtil sub Call : value is not Number Type');
      } else {
        switch(dateEnum){
          case this.DateEnum.DATE :
            returnValue = new Date(sourceDate.setDate(sourceDate.getDate() - value));
            break;
          case this.DateEnum.MONTH :
            returnValue = new Date(sourceDate.setMonth(sourceDate.getMonth() - value));
            break;
          case this.DateEnum.YEAR :
            returnValue = new Date(sourceDate.setFullYear(sourceDate.getFullYear() - value));
            break;
          case this.DateEnum.HOUR :
            returnValue = new Date(sourceDate.setHours(sourceDate.getHours() - value));
            break;
          case this.DateEnum.MINUTE :
            returnValue = new Date(sourceDate.setMinutes(sourceDate.getMinutes() - value));
            break;
          case this.DateEnum.SECOND :
            returnValue = new Date(sourceDate.setSeconds(sourceDate.getSeconds() - value));
          break;
          default :
            console.log('DateUtil get Call : dateEnum is invalid');
          break;
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터를 2개와 날짜 필드(정수형)을 입력 받아, 해당 날짜 필드에 대해 두 날짜의 차이 값을 반환
     * @details sourceDate2 - sourceDate1
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate1 입력 날짜
     * @param Date sourceDate2 입력 날짜
     * @param Number dateEnum 입력 날짜 필드
     * - @return Number 반환 값
     * @example var dateValue = dateUtil.differenceBetween(new Date(2018, 9, 1), new Date(), dateUtil.DateEnum.DATE);
     */
    differenceBetween : function(sourceDate1, sourceDate2, dateEnum){
      var returnValue = undefined;
      if(!sourceDate1 instanceof Date){
        console.log('DateUtil differenceBetween Call : sourceDate1 is not Date Object Type');
      } else if(!sourceDate2 instanceof Date){
        console.log('DateUtil differenceBetween Call : sourceDate2 is not Date Object Type');
      } else if (!dateEnum instanceof Number){
        console.log('DateUtil get Call : dateEnum is not DateEnum Type');
      } else {
        switch(dateEnum){
          case this.DateEnum.DATE :
            var diffTime = sourceDate1.getTime() - sourceDate2.getTime();
            returnValue = Math.ceil(diffTime / (1000 * 3600 * 24));
            break;
          case this.DateEnum.MONTH :
          case this.DateEnum.YEAR :
          case this.DateEnum.HOUR :
          case this.DateEnum.MINUTE :
          case this.DateEnum.SECOND :
            var val1 = this.get(sourceDate1, dateEnum);
            var val2 = this.get(sourceDate2, dateEnum);
            returnValue = val2 - val1;
          break;
          default :
            console.log('DateUtil differenceBetween Call : dateEnum is invalid');
        }
      }
      return returnValue;
    },
    /**
     * @section Description
     * @details Date 형 데이터를 2개와 날짜 필드(정수형)을 입력 받아, 크기 비교
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Date sourceDate1 입력 날짜
     * @param Date sourceDate2 입력 날짜
     * - @return Number 반환 값(if sourceDate1 > sourceDate2 than return 1, else if sourceDate1 == sourceDate2 than return 0, else if sourceDate1 < sourceDate2 than return -1)
     * @example var compareValue = dateUtil.compareWith(new Date(2018, 9, 1), new Date());
     */
    compareWith : function(sourceDate1, sourceDate2){
      var returnValue = undefined;
      if(!sourceDate1 instanceof Date){
        console.log('DateUtil compareWith Call : sourceDate1 is not Date Object Type');
      } else if(!sourceDate2 instanceof Date){
        console.log('DateUtil compareWith Call : sourceDate2 is not Date Object Type');
      } else {
        if(sourceDate1.getTime() == sourceDate2.getTime()){
          returnValue = 0;
        } else if(sourceDate1.getTime() > sourceDate2.getTime()){
          returnValue = 1;
        } else {
          returnValue = -1;
        }
      }
      return returnValue;
    }
  };
  module.ExcelUtil ={
    /**
     * @section Description
     * @details fileButton에서 선택한 파일과 처리할 API URL, 서버단 처리 완료시 작업할 CallBack 함수를 정의하여 선택한 엑셀파일 서버로 전송
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Object e 파일 탐색기에서 선택한 파일 객체
     * @param String url 업로드 처리할 서버 API URL
     * @param function callback 업로드 처리 이후 동작 로직
     * @example  excelUtil.upload(e, dews.url.getApiUrl("FI", "SampleService", "sample00700_list_excel_upload"), function(data){
     *             self.gridDataSource.data(data);
     *             self.grid.setDatSource(gridDataSource);
     *           })
     */
    upload : function(e, url, callback, apiParams){
    	var formData = new FormData();
    	formData.append('file', e.target.files[0]);
    	formData.append('isText', 'false');
    	formData.append('token', JSON.parse(dews.ui.page.token).access_token);

    	var xhr = new XMLHttpRequest();
        xhr.open('POST', "/upload/file", true);

        var completeHandler = function (e) {
            var fileData = {};
            if (this.status === 200) {
                var data = JSON.parse(this.responseText);

                if (data.success === 'true') {
                    data = data.data;
                    fileData.NEW_FILE_DC = data.newFilename;
                    fileData.ORGL_FILE_DC = data.originalFilename;
                    fileData.ORGL_FEXTSN_DC = data.originalExtension;
                    fileData.FILE_VR = parseInt(data.fileSize, 10);

                    newParams = {
                      fileModel : JSON.stringify(fileData)
                    };

                    if(apiParams != undefined){
                      $.each(Object.keys(apiParams), function(idx, data){
                        newParams[data] = apiParams[data];
                      });
                    }
                    dews.api.post(url, {
                    	async : false,
                    	data : newParams
                    }).done(function(data){
                    	callback(data);
                    }).fail(function (xhr, status, error) {
                      var err = {
                        xhr : xhr,
                        status: status,
                        error : error
                      };
                      callback(err);
                    });
                }
            }
        };

        xhr.addEventListener('load', completeHandler);
        xhr.send(formData);
    },
    /**
     * @section Description
     * @details 서버에서 작성된 Excel 파일을 다운
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Object data 서버에서 작성한 Excel 파일. DzDownloadModel
     * @example
     *  dews.api.get(dews.url.getApiUrl("FI", "SampleService", "sample00800_excel_download"), {
     *    async : false
     *  }).done(function(data){
     *    excelUtil.download(data);
     *  });
     */
  	download : function(data){
      var fileData = new Blob([new Uint8Array(data.file)], {type : data.contentType});
      if(window.navigator && window.navigator.msSaveOrOpenBlob){
        window.navigator.msSaveOrOpenBlob(fileData, data.fileName);
      } else {
        var anchorTag = window.document.createElement('a');
        anchorTag.href = window.URL.createObjectURL(fileData);
        anchorTag.download = data.fileName;
        document.body.appendChild(anchorTag);
        anchorTag.click();
        document.body.removeChild(anchorTag);
      }
  	}
  }

  console.log('## FI COMMON UTIL Script Loaded!!! ##');

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=cm.util.js
