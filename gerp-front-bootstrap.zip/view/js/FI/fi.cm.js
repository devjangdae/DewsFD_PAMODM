(function(dews, gerp, $) {
  dews.localize.load('', "FI_COMDIC");

  var module = {};
  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'FI'; // 모듈 코드를 입력 해주세요.

  // 공통 함수 정의
  module = (function() {
    return {

      /**
       * 공통코드 세팅
       * 사용방법 :  gerp.FI.getCodeData(fiObj,'FI', "P30250|P30150|", "P30150|","","","","","");
       * @param {*} objCodeData
       * @param {*} cd_module
       * @param {*} field_cd_pipe
       * @param {*} empty_field -> 공백이 들어가야되는 필드
       * @param {*} syscode_yn
       * @param {*} base_yn
       * @param {*} foreign_yn
       * @param {*} end_dt
       * @param {*} keyword
       */
      getCodeData : function(objCodeData, module_cd, field_cd_pipe, empty_field, syscode_yn, base_yn, foreign_yn, end_dt, keyword) {
        if (!objCodeData.hasOwnProperty(module_cd)) {
          objCodeData[module_cd] = {};
        }
        var arrCdField = field_cd_pipe.split("|");
        $.each(arrCdField, function (index, value) { //공백이 들어가야되는 필드
          if (value != null && value != "") {
            objCodeData[module_cd][value] = [];
            if (empty_field.indexOf(value) != -1) {
              objCodeData[module_cd][value].push({ FIELD_CD: '', SYSDEF_CD: '', SYSDEF_NM: '' , FLAG_CD : ''});
            }
          }
        });

        dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService","common_codeDtl_list"), {
          async: false,
          data: {
            module_cd: module_cd,          // 모듈
            field_cd_pipe: field_cd_pipe,  // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
            syscode_yn:  syscode_yn,       // 시스템코드 유무(Y,N)
            base_yn: base_yn,              // 디폴트 코드구분(Y,N)
            foreign_yn: foreign_yn,        // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
            end_dt: end_dt,                // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
            keyword: keyword               // 검색할 코드 또는 명
          }
        }).done(function (data) {
          var nowDate = dews.date.format(new Date(),'yyyyMMdd')
          if (data.length > 0) {
            $.each(data, function (i, obj) {
              if(obj.END_DT==null||!(obj.END_DT!= null && Number(obj.END_DT)<Number(nowDate))){
                objCodeData[module_cd][obj.FIELD_CD].push(obj);
              }
            });
          }
        }).fail(function (xhr, status, error) {
          dews.error(dews.localize.get("코드도움 데이터 조회 오류", "D0090430", '', 'FI_COMDIC'));
        });
      },

      setCdPc : function(dewself, controlId){
        var cdPcData =
        [
          {
            PC_CD : dewself.user.profitCenterCode,
            PC_NM : dewself.user.profitCenterName
          }
        ];
        dewself[controlId].setData(cdPcData);
      },

      setDdlDataSource : function (id, datas) {
        var dataSource = null;
        dataSource = dews.ui.dataSource(id, {
          data: datas
        });
        return dataSource;
      },

      /** @method 계정유형 GET
        * @description 계정유형 데이터 정보 불러오기
        * @param {string} gap 공백입력 처리(true:false)
       */
      getGaapCodes : function(gap) {
        var codeGaaps = [];

        dews.api.get(dews.url.getApiUrl('CM', 'CommonCodeDtlService', dews.string.format('common_multiGaap_list_company')), {
            async : false,
        }).done(function (data) {
          if (data.length > 0) {
            if(typeof(gap) != "undefined" && gap) {
              codeGaaps.insert(0, { SYSDEF_CD : '', SYSDEF_NM : ''});
            }
            $.each(data, function(idx ,item) {
              codeGaaps.push({
                SYSDEF_CD : item.SYSDEF_CD,
                SYSDEF_NM : item.SYSDEF_NM,
              });
            });
          }
        }).fail(function (xhr, status, error){
          dews.ui.snackbar.error(error);
        });

        return codeGaaps;
      },

      /** @method 회계기수정보 GET
        * @description 회계기수  정보 불러오기
        * @param {*} date_dt 날짜(format:yyyyMMdd or date)
       */
      getAccSeq : function(date_dt) {
        var accSeqs = [];
        dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', dews.string.format('accountSequence')), {
            async : false,
            data  : {
              date_dt : typeof(date_dt) != "undefined" ? dews.date.format(date_dt, "yyyyMMdd") : '',
            }
        }).done(function (data) {
          if (data.length > 0) {
            accSeqs = data;
          }
        }).fail(function (xhr, status, error){
          dews.ui.snackbar.error(error);
        });

        return accSeqs;
      },

      /**
       * @method 전기회계기수정보
       * @description 전기회계기수정보 정보 불러오기
       * @param {*} date_dt 날짜(format:yyyyMMdd or date)
       */
      getFormerAccSeq : function(date_dt) {
        var formerAccSeq = [];
        try {
          if(typeof date_dt == "undefined") {
            throw "parameter is null";
          } else {
            var accSeqs = this.getAccSeq();

            var today = dews.date.format(date_dt, "yyyyMMdd");
            for(var key in accSeqs) {
              if(accSeqs[key].START_DT <= today && accSeqs[key].END_DT >= today) {
                formerAccSeq = accSeqs.filter(function(value) {
                  if(value.ACCSEQ_SQ == (accSeqs[key].ACCSEQ_SQ -1)) {
                    return value;
                  }
                });
              }
            }
          }
        } catch (error) {
          console.error(error);
        }
        return formerAccSeq;
      },

      /** @method 회사정보조회 get
        * @description 회사정보를 조회하고 데이터를 반환한다.
       */
      getCompanyInfo : function() {
        var companyInfo = {};

        dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'companyInformation'), {
          async : false
        }).done(function(data) {
          companyInfo = data[0];
        }).fail(function (xhr, status, error){
          dews.error(error);
        });

        return companyInfo;
      },

      /** @method 회사환경설정 정보 GET
        * @description 회사환경설정 데이터 정보 불러오기
        * @param {string} cd_module 모듈코드
        * @param {string} ctrl_cd_pipe 통제코드(파이프 형식)
       */
      getControlConfig : function(module_cd, ctrl_cd_pipe) {
        var controlConfig = {};
        var codeCtrls = ctrl_cd_pipe != null ? ctrl_cd_pipe.split("|") : [];

        try {
          if(codeCtrls.length ==0) {
            throw "ctrl_cd_pipe is null";
          } else {
            $.map(codeCtrls,function(value, key){
              dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "controlConfig"), {
                async : false,
                data : {
                  module_cd : module_cd,
                  ctrl_cd : value,
                }
              }).done(function(data){
                controlConfig[value] = data[0];
              }).fail(function(xhr,status,error){
                dews.ui.snackbar.error(error);
              });
            });
          }
        } catch (error) {
          dews.ui.snackbar.error(error);
        }
        return controlConfig;
      },

      /** @method 회계단위 정보 GET
        * @description 회계단위 데이터 정보 불러오기
        * @param {string} yn_use 사용여부 처리("Y" : "N")
        * @param {string} empty 공백입력 처리(true:false)
       */
      getAccountingUnit : function(empty) {
        var accountingUnits = [];

        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "accountingUnits"),{
          async: false,
        }).done(function(data){
          if(data.length > 0) {
            if(typeof(empty) != "undefined" && empty) {
              accountingUnits.insert(0, { PC_CD : '', PC_NM : ''});
            }
            $.each(data, function(idx, item) {
              accountingUnits.push({
                PC_CD : item.PC_CD,
                PC_NM : item.PC_NM,
              });
            });
          }
        }).fail(function(xhr, status, error){
          dews.ui.snackbar.error(error);
        });

        return accountingUnits;
      },

      /**
       * @method 예산금액 정보
       * @param {*} bg_cd 예산코드
       * @param {*} bizplan_cd 사업계획코드
       * @param {*} bgacct_cd 예산계정코드
       * @param {*} ym 실행년월
       * @param {*} request_amt 신청금액
       */
      getBmControl : function(bg_cd, bizplan_cd, bgacct_cd, ym, request_amt) {
        var bmControl = {};
        if(ym instanceof Date) {
          ym = dews.date.format(ym, 'yyyyMMdd');
        }
        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "bmControl"),{
          async : false,
          data : {
            bg_cd : bg_cd,
            bizplan_cd : bizplan_cd,
            bgacct_cd : bgacct_cd,
            ym : ym,
            am_request : request_amt
          }
        }).done(function(data){
          if(data != null) {
            bmControl = data;
          }
        }).fail(function(e){
          if(e && e.responseJSON && e.responseJSON.message)
        	  dews.ui.snackbar.error(e.responseJSON.message);
          else
        	  dews.ui.snackbar.error(dews.localize.get("예산 정보를 가져 올 수 없습니다.", "M0004190", '', 'FI_COMDIC'));
        });
        return bmControl;
      },

      /**
       * @method 예산추출 정보
       * @param {*} data 파라미터 정보
       * @param {*} data.company_cd 회사코드
       * @param {*} data.pc_cd 회계단위
       * @param {*} data.docu_cd 전표유형
       * @param {*} data.actg_dt 회계일
       * @param {*} data.drcrfg_cd 차대코드
       * @param {*} data.acct_cd 계정코드
       * @param {*} data.cc_cd 비용센터코드
       * @param {*} data.pca_cd 손익센터코드
       * @param {*} data.wbs_no 프로젝트코드
       * @param {*} data.ord_no 설비번호
       * @param {*} data.plant_cd 공장번호
       * @param {*} data.atmvoe_fg_cd
       * @param {*} data.item_cd
       */
      getExtractBudget : function(data) {
        var res = {};
        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "extract-budget"),{
          async : false,
          data : {
            company_cd : data.company_cd,
            pc_cd : data.pc_cd,
            docu_cd : data.docu_cd,
            actg_dt : data.actg_dt,
            drcrfg_cd : data.drcrfg_cd || "",
            acct_cd: data.acct_cd || "",
            cc_cd: data.cc_cd || "",
            pca_cd : data.pca_cd || "",
            wbs_no : data.wbs_no || "",
            ord_no : data.ord_no || "",
            plant_cd : data.plant_cd || "",
            atmvoe_fg_cd : data.atmvoe_fg_cd || "",
            item_cd : data.item_cd || ""
          }
        }).done(function(data){
          if(data != null) {
            res = data;
          }
        }).fail(function(){
          dews.ui.snackbar.error(dews.localize.get("예산 추출 정보를 가져 올 수 없습니다.", "M0019807", '', 'FI_COMDIC'));
        });
        return res;
      },

      /**
       * @method 계정정보
       * @param {*} acctattr_cd 계정속성코드
       */
      getAccountMasterHasAttr : function(acctattr_cd) {
        var rows = [];

        dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'accountMasterHasAttr'), {
          async : false,
          data : {
            acctattr_cd : acctattr_cd
          }
        }).done(function(data) {
          if(data.length > 0){
            rows = data;
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
        return rows;
      },

      /**
       * @method 계정정보
       * @param {*} acct_cd 계정코드
       */
      getAccountMaster : function(acct_cd) {
        var rows = [];

        dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'accountMaster'), {
          async : false,
          data : {
            acct_cd : acct_cd
          }
        }).done(function(data) {
          if(data.length > 0){
            rows = data;
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
        return rows;
      },

      /**
       * @method 환종별포멧 정보
       */
      getExchangeFormat : function() {
        var exchangeFormats = {};

        dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'exchange-format'), {
          async : false,
        }).done(function(data) {
          if(data.length > 0){
            $.each(data, function(idx, format){
              exchangeFormats[format.EXCH_CD] = format;
            });
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
        return exchangeFormats;
      },

      /**
       * 프린트 API
       * @param {*} dewself this
       * @param {*} reportId 리포트ID
       * @param {*} objectId 오브젝트ID
       * @param {*} params 파라미터
       * @param {*} customParams 파라미터
       */
      invokePrint : function(dewself, reportId, objectId, params, customParams = null) {
        var items = [];

        $(params).each(function(idx, item) {
          items.push( {
            RPRT_CD : reportId,
            OBJECT_CD : objectId,
            PARA_CD : item.name,
            PARA_TXT : item.value
          });
        });

        //파라미터 저장 요청
        dews.api.post(dews.url.getApiUrl("CM","printService","setPrintParam"), {
          async : false,
          data : {
            reportCode : reportId,
            items : JSON.stringify(items)
          }
        }).done(function(data){
          if(data != null && data != "") {
            dews.app.print({
              reportId : reportId,
              parameterKey : data,
              customParams: customParams
            });
          }
        }).fail(function(xhr,status, error) {
          dews.ui.snackbar.error(error);
        });
      },

       /**
       * @method 전표정보
       * @param {*} company_cd 회사코드
       * @param {*} pc_cd 회계단위코드
       * @param {*} docu_no 전표번호
       */
      getDocument : function(company_cd, pc_cd, docu_no) {
        var fiDocument = {};

        dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'document'), {
          async : false,
          data : {
            company_cd : company_cd,
            pc_cd : pc_cd,
            docu_no : docu_no
          }
        }).done(function(data) {
          if(data.length > 0){
            fiDocument = JSON.parse(data);
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
        return fiDocument;
      },

      /**
       * @method 원전표정보
       * @PA
       * @param {*} options 원전표 정보
       * @param {필수} options.company_cd 회사코드
       * @param {필수} options.pc_cd 회계단위
       * @param {필수} options.docu_no 반제전표번호
       * @param {선택} options.doline_sq 라인번호
       * @param {선택} options.drcrfg_cd 차대코드
       */
      getRefererDocument : function(options) {
        var document = {};

        dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'referer-document'), {
          async : false,
          data : options
        }).done(function(data) {
          if(data.length > 0){
            document = data
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
        return document;
      },

       /**
       * @method 결의서정보
       * @param {*} company_cd 회사코드
       * @param {*} pc_cd 회계단위코드
       * @param {*} abdocu_no 결의서번호
       */
      getResolution : function(company_cd, pc_cd, abdocu_no) {
        var fiResoultionDocument = {};

        dews.api.get(dews.url.getApiUrl('FI', 'FinancialCommonService', 'resolutionDocument'), {
          async : false,
          data : {
            company_cd : company_cd,
            pc_cd : pc_cd,
            abdocu_no : abdocu_no
          }
        }).done(function(data) {
          if(data.length > 0){
            fiResoultionDocument = JSON.parse(data);
          }
        }).fail(function (xhr, status, error) {
          dews.ui.snackbar.error(error);
        });
        return fiResoultionDocument;
      },

      /**
       * @method 어음정보
       * @description 연동항목코드에 따른 어음정보
       * @param {company_cd, relation_cd, bil_no} params
       */
      getBilMaster : function(params) {
        var bilDocument = {};

        try {
          if($.isEmptyObject(params)) {
            throw "parameter is undefined";
          }
          dews.api.get(dews.url.getApiUrl('FI', "FinancialCommonService", "bill"), {
            async : false,
            data : {
              company_cd : params.company_cd,
              relation_cd : params.relation_cd,
              bil_no : params.bil_no
            }
          }).done(function(data) {
            if(data.length > 0){
              bilDocument = JSON.parse(data);
            }
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error(error);
          });

        } catch (error) {
          console.error(error)
        }
        return bilDocument;
      },

      /**
        * @method  메인버튼 VISIBLE 처리 Method
        * @description   메인버튼 VISIBLE 처리
        * @param {string} target
            target :  add      - 추가
                      search   - 조회
                      save     - 저장
                      approval - 결재
                      delete   - 삭제
                      print    - 인쇄
                      favorite - 즐겨찾기
                      all      - 전체
                ex : "add|print" , "all"
        * @param {boolean} visible true or false
        * @param {boolean} hide true or false
        */
       setMainButtons : function(target, visible, hide) {
        if(!hide) {
          hide = false;
        }

        if(target != "all") {
          $(target.split("|")).each(function(idx,item) {
            if(visible  == true) {
              dews.ui.mainbuttons[item].show();
              dews.ui.mainbuttons[item].disable(false);
            } else {
              if(hide) {
                dews.ui.mainbuttons[item].hide();
              } else {
                dews.ui.mainbuttons[item].disable(true);
              }
            }
          });
        } else {    //전체를 보여주거나 disabled
          $.map(dews.ui.mainbuttons,function(idx,item) {
            if(typeof(dews.ui.mainbuttons[item].disable) != "undefined") {
              if(visible == true) {
                dews.ui.mainbuttons[item].show();
                dews.ui.mainbuttons[item].disable(false);
              } else {
                if(hide) {
                  dews.ui.mainbuttons[item].hide();
                } else {
                  dews.ui.mainbuttons[item].disable(true);
                }
              }
            }
          });
        }

        var authKey;
        Object.keys(dews.ui.page.mainButtons).map(function(key) {
          authKey = key;
          if(key == "add"){authKey = "create"}
          else if(key == "approval"){authKey = "gw"}
          else if(key =="etnapproval"){authKey = "approval"}
          else if(key =="search"){authKey = "read"}
          if(key != "approval" && key != "etnapproval"){
            if(dews.ui.page.authority[authKey]){
              if(!dews.ui.mainbuttons[key].disabled && dews.ui.page.authority[authKey] == "1") {
                dews.ui.mainbuttons[key].disable(true)
              }
              if(!dews.ui.mainbuttons[key].hidden && dews.ui.page.authority[authKey] == "0") {
                dews.ui.mainbuttons[key].hide(true)
              }
            }
          }
        });
      },

      /**
       * 양식정보
       * @param {*} gaap_cd 계정유형
       * @param {*} form_fg_cd 양식구분코드
       */
      getFsForm : function(gaap_cd, form_fg_cd) {
        var fsforms = [];

        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "fsform"), {
          async: false,
          data : {
            gaap_cd : gaap_cd,
            fsform_fg_cd : form_fg_cd
          }
        }).done(function(data){
          if(data.length > 0) {
            fsforms = data;
          }
        }).fail(function(xhr,status, error) {
          dews.ui.snackbar.error(dews.localize.get("양식 데이터를 가져오는데 실패하였습니다.", "M0019808", '', 'FI_COMDIC'));
        });
        return fsforms;
      },

      /**
       * 자산기준정보
       * @param {*} asset_dp_fg 자산상각구분
       * @param {*} asset_tp_cd 자산유형코드
       */
      getAssetCriteria : function(asset_dp_fg, asset_tp_cd) {
        var assetCriteria;

        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "assetCriteria"), {
          async: false,
          data : {
            asset_dp_fg : asset_dp_fg,
            asset_tp_cd : asset_tp_cd
          }
        }).done(function(data){
          if(data.length > 0) {
            assetCriteria = data[0];
          }
        }).fail(function(xhr,status, error) {
          dews.ui.snackbar.error(dews.localize.get("자산기준정보를 가져오는데 실패하였습니다.", "M0004205", '', 'FI_COMDIC'));
        });
        return assetCriteria;
      },

      /**
        * @method 임시토큰
        * @description 임시토큰 발급
       */
      getAuthToken : function() {
        var token;
        dews.api.get("/auth/temporary/token", {
          async: false
        }).done(function(data) {
          token = data;
        });
        return token;
      },
      /**
        * @method 엑셀다운
        * @description 웹소켓방식 엑셀다운로드
       */
       wsExcelDown : function(url, parameter) {
        var progressBar = dews.ui.progress("progressBar", {
          total: 100,
          modal: true,
          textTemplate: dews.localize.get('데이터를', 'D0090437') + ' <strong>#=percent#</strong> ' + dews.localize.get('처리 중 입니다.', 'M0016920'),
          alterTextTemplate: dews.localize.get('진행 상황: #=progress#', 'D0005460')
      });
        return dews.ws.ltx(url, {
          data: parameter,
          done: function (e) {
            progressBar.setCurrent(0);
            var resultList = JSON.parse(e.resultData)
            var token;
            $.each(resultList, function (index, resultData) {
              dews.api.get("/auth/temporary/token", {
                async: false
              }).done(function(data) {
                token = data;
                var key = resultData.split('/')[0];
                var filename = resultData.split('/')[1];
                var url = dews.string.format("/download/tempfile?token={0}&key={1}&filename={2}", token, key, encodeURI(filename));

                var xhr = new XMLHttpRequest();
                xhr.open("GET", url, true);
                xhr.responseType = "blob";
                xhr.send();
                xhr.onload = function (e) {
                  if(window.navigator && window.navigator.msSaveOrOpenBlob){
                    window.navigator.msSaveOrOpenBlob(xhr.response, filename);
                  } else {
                    var element = window.document.createElement("a");
                    element.href = window.URL.createObjectURL(xhr.response);
                    element.download = filename;
                    element.click();
                  }
                };
              });
            });

            setTimeout(function () {
              if (progressBar.container.is(":visible")) {
                progressBar.close();
              }
            });
          },
          error: function (e) {
            progressBar.close();
            setTimeout(function () { dews.error(e.resultData) });
          },
          progress: function (e) {
            progressBar.setCurrent(e.resultData);
          }
        });
      },
      /**
      * @method 엑셀다운로드
      * @description 웹소켓방식 엑셀다운로드(메뉴명 표시 및 인터렉션 허용)
      */
      wsExcelDownInteraction : function(menu_nm, url, parameter) {
        var progressBar = dews.ui.progress("progressExcel" + dews.ui.page.menu.id, {
          total: 100,
          position: {
            align: 'right|bottom',
            margin: [0,0,0,0]
          },
          titlebar: {
            text: menu_nm + dews.localize.get(" 엑셀 다운로드", "D0098134", '', 'FI_COMDIC')
          },
          textTemplate: dews.localize.get('데이터를', 'D0090437') + ' <strong>#=percent#</strong> ' + dews.localize.get('처리 중 입니다.', 'M0016920'),
          alterTextTemplate: dews.localize.get('진행 상황: #=progress#', 'D0005460')
        });
        return dews.ws.ltx(url, {
          data: parameter,
          done: function (e) {
            var receivedData = JSON.parse(e.resultData);
            var resultList;
            progressBar.setCurrent(99);

            if(receivedData.length == 1 && receivedData[0].slice('-4') == '.csv') {
              resultList = receivedData;
            } else {
              resultList = receivedData.fileList;
            }
            var token;
            $.each(resultList, function (index, resultData) {
              dews.api.get("/auth/temporary/token", {
                async: false
              }).done(function(data) {
                token = data;
                var key = resultData.split('/')[0];
                var filename = resultData.split('/')[1];
                var url = dews.string.format("/download/tempfile?token={0}&key={1}&filename={2}", token, key, encodeURI(filename));

                var xhr = new XMLHttpRequest();
                xhr.open("GET", url, true);
                xhr.responseType = "blob";
                xhr.send();
                xhr.onload = function (e) {
                  if(window.navigator && window.navigator.msSaveOrOpenBlob){
                    window.navigator.msSaveOrOpenBlob(xhr.response, filename);
                  } else {
                    if (window.document.readyState == "complete") {
                      if (progressBar.container.is(":visible")) {
                        progressBar.close();
                        if(receivedData.csvSizeOverFlag) {
                          dews.alert(dews.localize.get("엑셀 다운로드 데이터가 100만건이 넘어\n분할되어 다운로드되었습니다.", "M0024189", '', 'FI_COMDIC'), 'info');
                        } else {
                          dews.alert(dews.localize.get("엑셀 다운로드가 완료되었습니다.", "M0023123", '', 'FI_COMDIC'),'info');
                        }
                      }
                    }
                    var element = window.document.createElement("a");
                    element.href = window.URL.createObjectURL(xhr.response);
                    element.download = filename;
                    element.click();
                  }
                };
              });
            });
            // setTimeout(function () {
            //   if (progressBar.container.is(":visible")) {
            //     progressBar.close();
            //     if(data.csvSizeOverFlag) {
            //       dews.alert(dews.localize.get("엑셀 다운로드 데이터가 100만건이 넘어\n분할되어 다운로드되었습니다.", "M0024189", '', 'FI_COMDIC'), 'info');
            //     } else {
            //       dews.alert(dews.localize.get("엑셀 다운로드가 완료되었습니다.", "M0023123", '', 'FI_COMDIC'),'info');
            //     }
            //   }
            // });
          },
          error: function (e) {
            progressBar.close();
            setTimeout(function () { dews.error(e.resultData) });
          },
          progress: function (e) {
            if(typeof JSON.parse(e.resultData) == 'number') {
              progressBar.setCurrent(e.resultData);
            } else {
              var data = JSON.parse(e.resultData);
              progressBar.setTextTemplate(data.message);
              progressBar.setCurrent(data.current);
            }
          }
        });
      },
      /**
       * @method 기간정보
       * @description 기간구분코드 따른 기간정보
       * @param {*} period_cd
       * @param {*} from_dt
       * @param {*} to_dt
       */
      getPeriodList : function(period_cd, from_dt, to_dt) {
        var periodList = [];

        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "periodList"), {
          async : false,
          data : {
            period_cd : period_cd,
            from_dt : from_dt,
            to_dt : to_dt
          }
        }).done(function(data){
          if(data.length > 0) {
            periodList = data;
          }
        }).fail(function(xhr, status, error){
          dews.ui.snackbar.error(error);
        });
        return periodList;
      },

      /**
       * @method 결제조건정보
       * @description 결제조건코드 따른 결제정보
       * @param {*} terpay_cd
       */
      getPaymentMaster : function(terpay_cd) {
        var list = [];

        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "payment"), {
          async : false,
          data : {
            terpay_cd : terpay_cd || ""
          }
        }).done(function(data){
          if(data.length > 0) {
            list = data;
          }
        }).fail(function(xhr, status, error){
          dews.ui.snackbar.error(error);
        });
        return list;
      },

      /**
       * @method 거래처정보
       * @description 거래처코드에 따른 거래처정보
       * @param {*} partner_cd
       */
      getPartner : function(partner_cd) {
        var partner = {};

        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "partner"), {
          async : false,
          data : {
            partner_cd : partner_cd || ""
          }
        }).done(function(data){
          if(data.length > 0) {
            partner = data[0];
          }
        }).fail(function(xhr, status, error){
          dews.ui.snackbar.error(error);
        });
        return partner;
      },

      /** @method 캘린더정보
        * @description 달력정보 정보 불러오기
        * @param {string} bwrk_fg_cd 근무구분코드(1:휴일, 2:근무)
        * @param {string} start_dt 시작일
        * @param {string} end_dt 종료일
      */
      getCalendar : function(bwrk_fg_cd, start_dt, end_dt) {
        var calendar = [];

        if(bwrk_fg_cd != null) {
          dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "calendar"), {
            async: false,
            data : {
              bwrk_fg_cd : bwrk_fg_cd,
              start_dt : start_dt ? start_dt : "",
              end_dt : end_dt ? end_dt : ""
            }
          }).done(function (data) {
            calendar = data;
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error(error);
          });
        }

        return calendar;
      },
      /**
       * @method 회사모듈정보
       * @description 회사모듈정보
       * @param {*} module_cd
       */
      getCompanyModuleInfo : function(module_cd) {
        var list = [];

        dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonService", "company-module-info"), {
          async : false,
          data : {
            module_cd : module_cd || ""
          }
        }).done(function(data){
          if(data.length > 0) {
            list = data;
          }
        }).fail(function(xhr, status, error){
          dews.ui.snackbar.error(error);
        });
        if(list.length == 1) {
          return list[0];
        }
        return list;
      },
      /**
       * @method 결제일자
       * @description 결제조건코드 따라 결제일 계산
       * @param {*} terpay_cd
       * @param {*} date
       */
      convertDateFromPayment : function(terpay_cd, date) {
        var list = this.getPaymentMaster(terpay_cd);

        if(list.length > 0) {
          var payment = list[0];
          date = date instanceof Date ? date : dews.date.parse(date, "yyyyMMdd");
          var tempDate = new Date();

          if(payment.IMDTLY_STLM_YN == "N") { //즉시결제여부
            if(payment.LYDY_YN == "Y") {    //말일결제여부, 추가월수
              tempDate.setMonth(date.getMonth() + Number(payment.ADD_MM));
              tempDate = dews.date.parse(this.dateUtil.lastDate(tempDate), "yyyyMMdd");
            } else if(payment.FIX_DT == "00") {   //고정일이 0일 때 기산일수
              tempDate.setMonth(date.getMonth() + Number(payment.ADD_MM));
              tempDate.setDate(date.getDate() + Number(payment.STLM_RECKN_DY));
            } else {                              //고정일이 0이 아닐때 추가월수, 고정일
              tempDate.setMonth(date.getMonth() + Number(payment.ADD_MM));
              var tempLastDay = String(this.dateUtil.lastDate(tempDate)).substring(6,8);
              if(parseInt(payment.FIX_DT) && parseInt(payment.FIX_DT) > Number(tempLastDay)){
                tempDate.setDate(Number(tempLastDay));
              }else{
                tempDate.setDate(Number(payment.FIX_DT));
              }
            }
          }

          var formatDate = dews.date.format(tempDate, "yyyyMMdd");
          while(true) {
            formatDate = dews.date.format(tempDate, "yyyyMMdd");
            var holidays = this.getCalendar("1", formatDate, formatDate);
            if(holidays.length == 0) {
              break;
            }
            if(payment.HLDY_PROC_CD == "1") tempDate.setDate(tempDate.getDate()-1);
            else if(payment.HLDY_PROC_CD == "2") tempDate.setDate(tempDate.getDate()+1);
          }
        }
        return dews.date.format(tempDate, "yyyyMMdd");
      },
      updateCompanyForBankTransaction : function(start_dt, end_dt) {
        var progress = dews.ui.progress('progress', {
          textTemplate: '데이터를 <strong>#=percent#</strong> 처리 중 입니다.',
          alterTextTemplate: dews.localize.get('진행 상황: #=progress#', 'D0005460', '', 'FI_COMDIC')
        });
        var startDate = dews.date.parse(start_dt);
        var endDate = dews.date.parse(end_dt);
        var total = this.dateUtil.dateDiff(start_dt, end_dt);
        progress.setTotal(total);

        var current = 0;
        for(var date = startDate; date <= endDate; date.setDate(date.getDate()+1)) {
          dews.api.post(dews.url.getApiUrl("FI", "TransactionCompanyUpdateService", "bank"), {
            async : true,
            data: {
              date_dt: dews.date.format(date,'yyyyMMdd'),
            }
          }).done(function (data) {
            current++;
            progress.setCurrent(current);
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error(error);
          });
        }
      },
      updateCompanyForCardTransaction : function(start_dt, end_dt) {
        var progress = dews.ui.progress('progress', {
          textTemplate: '데이터를 <strong>#=percent#</strong> 처리 중 입니다.',
          alterTextTemplate: dews.localize.get('진행 상황: #=progress#', 'D0005460', '', 'FI_COMDIC')
        });
        var startDate = dews.date.parse(start_dt);
        var endDate = dews.date.parse(end_dt);
        var total = this.dateUtil.dateDiff(start_dt, end_dt);
        progress.setTotal(total);

        var current = 0;
        for(var date = startDate; date <= endDate; date.setDate(date.getDate()+1)) {
          dews.api.post(dews.url.getApiUrl("FI", "TransactionCompanyUpdateService", "card"), {
            async : true,
            data: {
              date_dt: dews.date.format(date,'yyyyMMdd'),
            }
          }).done(function (data) {
            current++;
            progress.setCurrent(current);
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error(error);
          });
        }
      },
      /** @method 환경설정및공통코드 이관 조회
       * @description 회사에 이관되지 않은 환경설정정보 및 공통코드를 다이얼로그에 출력하며, 회사환경설정 데이터를 리턴한다
       * @param {*} checkCtrlConfigItems 환경설정 모듈코드 및 통제코드('FI:FI00010|PS:PS00223|PS:PS05001|PS:PS01800')
       * @param {*} checkCommonCodeItems 공통코드 모듈코드 및 필드코드('FI:P10670|AU:P00003|AU:P00006')
       * @param {*} return_yn 환경설정 및 공통코드 데이터 리턴 여부
      */
      checkMissingEnvironmentShowDialog: function (ctrl_config_list, common_code_list, return_yn) {
        let environmentData = {};
          
        try {
          let ctrlConfigItems = [];
          let commonCodeItems = [];
           
          $.each(ctrl_config_list, function (index, item) {
            if(item.MODULE_CD === undefined || item.MODULE_CD === null || item.MODULE_CD === '' ||
               item.CTRL_CD === undefined || item.CTRL_CD === null || item.CTRL_CD === '') {
              return true;
            }
            ctrlConfigItems.push(item.MODULE_CD + ':' + item.CTRL_CD);
          });

          $.each(common_code_list, function (index, item) {
            if(item.MODULE_CD === undefined || item.MODULE_CD === null || item.MODULE_CD === '' ||
            item.FIELD_CD === undefined || item.FIELD_CD === null || item.FIELD_CD === '') {
              return true;
            }
            commonCodeItems.push(item.MODULE_CD + ':' + item.FIELD_CD);
          });

          let check_data = {ctrlConfigItems : ctrlConfigItems.join('|'),
                            commonCodeItems : commonCodeItems.join('|'),
                            return_yn : return_yn};
          
          dews.api.post(dews.url.getApiUrl('FI', 'FinancialCommonService', 'checkMissingEnvironmentShowDialog'), {
            async: false,
            data: {
              check_data: JSON.stringify(check_data), 
            }
          }).done(function (data) {
            let result = data[0];
            if(return_yn) {
              //조회한 데이터 리턴
              environmentData = result;
           
            } 
            
            let saveList = result.saveList; 
            if(saveList.length !== 0) {
              let dialog = dews.ui.dialog("H_FI_CHECK_MISSING_ENVIRONMENT_POP",
              { 
                
                url: '/codehelp/FI/H_FI_CHECK_MISSING_ENVIRONMENT_POP',
                title: dews.localize.get('환경설정 및 공통코드 누락정보', 'D0116828'),
                width: '800px',
                height: '500px',
                resizable: true
              });

            dialog.setInitData(saveList);
            dialog.open();
            }
            
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error(error);
          });
          
        } catch (e) {
          console.log(e);
        }
          return environmentData;  
      },
      /** @method 환경설정및공통코드 이관 조회 및 저장
       * @description 회사에 이관되지 않은 환경설정정보 및 공통코드를 저장하며, 회사환경설정 데이터를 리턴한다 
       * @param {*} checkCtrlConfigItems 환경설정 모듈코드 및 통제코드('FI:FI00010|PS:PS00223|PS:PS05001|PS:PS01800')
       * @param {*} checkCommonCodeItems 공통코드 모듈코드 및 필드코드('FI:P10670|AU:P00003|AU:P00006')
       * @param {*} return_yn 환경설정 및 공통코드 데이터 리턴 여부
      */
      checkMissingEnvironment: function (ctrl_config_list, common_code_list, return_yn) {
        let environmentData = {};
          
        try {
          let ctrlConfigItems = [];
          let commonCodeItems = [];
           
          $.each(ctrl_config_list, function (index, item) {
            if(item.MODULE_CD === undefined || item.MODULE_CD === null || item.MODULE_CD === '' ||
               item.CTRL_CD === undefined || item.CTRL_CD === null || item.CTRL_CD === '') {
              return true;
            }
            ctrlConfigItems.push(item.MODULE_CD + ':' + item.CTRL_CD);
          });

          $.each(common_code_list, function (index, item) {
            if(item.MODULE_CD === undefined || item.MODULE_CD === null || item.MODULE_CD === '' ||
            item.FIELD_CD === undefined || item.FIELD_CD === null || item.FIELD_CD === '') {
              return true;
            }
            commonCodeItems.push(item.MODULE_CD + ':' + item.FIELD_CD);
          });

          let check_data = {ctrlConfigItems : ctrlConfigItems.join('|'),
                            commonCodeItems : commonCodeItems.join('|'),
                            return_yn : return_yn};
          
          dews.api.post(dews.url.getApiUrl('FI', 'FinancialCommonService', 'checkMissingEnvironment'), {
            async: false,
            data: {
              check_data: JSON.stringify(check_data), 
            }
          }).done(function (data) {
            let result = data[0];
            if(return_yn) {
              //조회한 데이터 리턴
              environmentData = result;
           
            } 
            
          }).fail(function (xhr, status, error) {
            dews.ui.snackbar.error(error);
          });
          
        } catch (e) {
          console.log(e);
        }
          return environmentData;  
      },
      // /** @method 회사환경설정 이관 조회
      //  * @description 회사에 이관되지 않은 환경설정정보를 리턴함 
      //  * @param {*} checkCtrlConfigItems 모듈코드 및 통제코드('FI:FI00010|PS:PS00223|PS:PS05001|PS:PS01800')
      // */
      // checkCtrlConfig: function (ctrl_config_list) {
      //   try {
          
      //     let checkCtrlConfigItems = [];

      //     $.each(ctrl_config_list, function (index, item) {
      //       if(item.MODULE_CD === undefined || item.MODULE_CD === null || item.MODULE_CD === '' ||
      //          item.CTRL_CD === undefined || item.CTRL_CD === null || item.CTRL_CD === '') {
      //         return true;
      //       }
            
      //       checkCtrlConfigItems.push(item.MODULE_CD + ':' + item.CTRL_CD);
  
      //     });


      //     dews.api.post(dews.url.getApiUrl('FI', 'FinancialCommonService', 'checkCtrlConfig'), {
      //       async: false,
      //       data: {
      //         checkCtrlConfigItems: JSON.stringify(checkCtrlConfigItems.join('|'))
      //       }
      //     }).done(function (data) {
      //       if (data == 0) return;

      //       let dialog = dews.ui.dialog("H_FI_CHECK_MISSING_ENVIRONMENT_POP",
      //         {
      //           url: '/codehelp/FI/H_FI_CHECK_MISSING_ENVIRONMENT_POP',
      //           title: '환경설정 누락정보',
      //           width: '800px',
      //           height: '500px',
      //           resizable: true
      //         });

      //       dialog.setInitData(data);
      //       dialog.open();

      //     }).fail(function (xhr, status, error) {
      //       dews.ui.snackbar.error(error);
      //     });

      //   } catch (e) {
      //     console.log(e);
      //   }
      // },

      // /** @method 공통코드 이관 조회
      //   * @description 회사에 이관되지 않은 공통코드를 리턴함 
      //   * @param {*} checkCommonCodeItems 모듈코드 및 필드코드('FI:P10670|AU:P00003|AU:P00006')
      //  */
      // checkCommonCode: function (common_code_list) {
      //   try {
      //     let checkCommonCodeItems = [];

      //     $.each(common_code_list, function (index, item) {
      //       if(item.MODULE_CD === undefined || item.MODULE_CD === null || item.MODULE_CD === '' ||
      //       item.FIELD_CD === undefined || item.FIELD_CD === null || item.FIELD_CD === '') {
      //         return true;
      //       }
          
      //       checkCommonCodeItems.push(item.MODULE_CD + ':' + item.FIELD_CD);
      //     });

      //     dews.api.post(dews.url.getApiUrl('FI', 'FinancialCommonService', 'checkCommonCode'), {
      //       async: false,
      //       data: {
      //         checkCommonCodeItems: JSON.stringify(checkCommonCodeItems.join('|'))
      //       }
      //     }).done(function (data) {
      //       if (data == 0) return;

      //       let dialog = dews.ui.dialog("H_FI_CHECK_MISSING_ENVIRONMENT_POP",
      //         {
      //           url: '/codehelp/FI/H_FI_CHECK_MISSING_ENVIRONMENT_POP',
      //           title: '공통코드 누락정보',
      //           width: '800px',
      //           height: '500px',
      //           resizable: true
      //         });

      //       dialog.setInitData(data);
      //       dialog.open();

      //     }).fail(function (xhr, status, error) {
      //       dews.ui.snackbar.error(error);
      //     });
      //   } catch (e) {
      //     console.log(e);
      //   }
      // },
    };
  })();

  module.budget = {
    findBudgetConnection : function(dept_cd) {
      var budgetConnection = {};

      dews.api.get(dews.url.getApiUrl("FI", "FinancialCommonBudgetService", "budget-connection"), {
        async : false,
        data : {
          dept_cd : dept_cd
        }
      }).done(function(data){
        budgetConnection = data;
      }).fail(function(xhr, status, error){
        dews.ui.snackbar.error(error);
      });
      return budgetConnection;
    }
  }

  module.dateUtil = {
    lastDate : function(date) {
      var lastDate;
      if(date) {
        date = date instanceof Date ? date : dews.date.parse(date, "yyyyMMdd");
        date.setMonth(date.getMonth() + 1);
        date.setDate(0);
        lastDate = dews.date.format(date, "yyyyMMdd");
      }
      return lastDate;
    },
    dateDiff : function(sourceDate, targetDate) {
      var startDate = dews.date.parse(sourceDate);
      var endDate = dews.date.parse(targetDate);

      var diff = Math.abs(startDate.getTime() - endDate.getTime());
      return Math.ceil(diff / (1000 * 3600 * 24));
    },

    timeFormat : function(date) {
      if(date instanceof Date) {
        return kendo.toString(date, "HH:mm:ss");
      } else if(date.length == 6) {
        return dews.string.format("{0}:{1}:{2}", date.substring(0,2), date.substring(2,4), date.substring(4,6));
      }
    }
  }

  module.ExcelUtil ={
    /**
     * @section Description
     * @details fileButton에서 선택한 파일과 처리할 API URL, 서버단 처리 완료시 작업할 CallBack 함수를 정의하여 선택한 엑셀파일 서버로 전송
     * @author 강진혁(jhkang1313@douzone.com)
     * - @param Object e 파일 탐색기에서 선택한 파일 객체
     * @param String url 업로드 처리할 서버 API URL
     * @param function callback 업로드 처리 이후 동작 로직
     * @example  excelUtil.upload(e, dews.url.getApiUrl("FI", "SampleService", "sample00700_list_excel_upload"), function(data){
     *             self.gridDataSource.data(data);
     *             self.grid.setDatSource(gridDataSource);
     *           })
     */
    upload : function(e, url, callback, apiParams){
    	var formData = new FormData();
    	formData.append('file', e.target.files[0]);
    	formData.append('isText', 'false');
    	formData.append('token', JSON.parse(dews.ui.page.token).access_token);

    	var xhr = new XMLHttpRequest();
        xhr.open('POST', "/upload/file", true);

        var completeHandler = function (e) {
            var fileData = {};
            if (this.status === 200) {
                var data = JSON.parse(this.responseText);

                if (data.success === 'true') {
                    data = data.data;
                    fileData.NEW_FILE_DC = data.newFilename;
                    fileData.ORGL_FILE_DC = data.originalFilename;
                    fileData.ORGL_FEXTSN_DC = data.originalExtension;
                    fileData.FILE_VR = parseInt(data.fileSize, 10);

                    newParams = {
                      fileModel : JSON.stringify(fileData)
                    };

                    if(apiParams != undefined){
                      $.each(Object.keys(apiParams), function(idx, data){
                        newParams[data] = apiParams[data];
                      });
                    }
                    dews.api.post(url, {
                    	async : false,
                    	data : newParams
                    }).done(function(data){
                    	callback(data);
                    }).fail(function (xhr, status, error) {
                      var err = {
                        xhr : xhr,
                        status: status,
                        error : error
                      };
                      callback(err);
                    });
                }
            }
        };

        xhr.addEventListener('load', completeHandler);
        xhr.send(formData);
    },
    formDownload : function(fileName, fileTitle){
      var xhr = new XMLHttpRequest();
      xhr.open("GET", window.location.origin+"/download/excel?excel=" + fileName, true);
      xhr.setRequestHeader("X-Authenticate-Token", JSON.parse(dews.ui.page.token).access_token);
      xhr.responseType = "blob";
      xhr.send();
      xhr.onload = function(e) {
        if(window.navigator && window.navigator.msSaveOrOpenBlob){
          window.navigator.msSaveOrOpenBlob(xhr.response, fileTitle);
        } else {
          var element = window.document.createElement("a");
          element.href = window.URL.createObjectURL(xhr.response);
          element.download = fileTitle;
          element.click();
        }
      };
    }
  }
  module.DataSourceProxy = function(id, options, container) {
    var store = {};
    var url = options.transport.read.url;
    var type = options.transport.read.type || "get";
    var async = options.transport.read.async || true;
    var expirationTime = options.transport.read.expirationTime || 30000;

    var dataSource = dews.ui.dataSource(id, options, container);
    return $.extend(dataSource, {
      read : function() {
        var data = typeof options.transport.read.data == 'function' ? options.transport.read.data() : options.transport.read.data;
        var key = JSON.stringify(data);
        if(store[key]) {
          return Promise.resolve(store[key]).finally(function() {
            dews.ui.loading.hide();
          });
        } else {
          if(async) {
            dews.ui.loading.show(options.transport.read.loading || {});
          }
          return dews.api[type](url, {
            async : async,
            data : data
          }).then(function(data) {
            if(data.length > 0) {
              store[key] = data;
            }
            setTimeout(function(){
              delete store[key];
            }, expirationTime);
            return data;
          }).fail(function(xhr,status, error) {
            dews.ui.snackbar.error(error);
          }).always(function(){
            dews.ui.loading.hide();
          });
        }
      },
      setExpirationTime : function(expTime) {
        expirationTime = Number(expTime);
      },
      props : {
        store : store,
        type : type,
        expirationTime : expirationTime
      }
    });
  }

  module.polyFill = (function() {
    //Array Polyfill
    if (!Array.prototype.findIndex) {
      Object.defineProperty(Array.prototype, 'findIndex', {
        value: function (predicate) {
          'use strict';
          if (this == null) {
            throw new TypeError('Array.prototype.findIndex called on null or undefined');
          }
          if (typeof predicate !== 'function') {
            throw new TypeError('predicate must be a function');
          }
          var list = Object(this);
          var length = list.length >>> 0;
          var thisArg = arguments[1];
          var value;

          for (var i = 0; i < length; i++) {
            value = list[i];
            if (predicate.call(thisArg, value, i, list)) {
              return i;
            }
          }
          return -1;
        },
        enumerable: false,
        configurable: false,
        writable: false
      });
    }

    if (!Array.prototype.find) {
      Object.defineProperty(Array.prototype, 'find', {
        value: function(predicate) {
        // 1. Let O be ? ToObject(this value).
          if (this == null) {
            throw new TypeError('"this" is null or not defined');
          }

          var o = Object(this);

          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;

          // 3. If IsCallable(predicate) is false, throw a TypeError exception.
          if (typeof predicate !== 'function') {
            throw new TypeError('predicate must be a function');
          }

          // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
          var thisArg = arguments[1];

          // 5. Let k be 0.
          var k = 0;

          // 6. Repeat, while k < len
          while (k < len) {
            // a. Let Pk be ! ToString(k).
            // b. Let kValue be ? Get(O, Pk).
            // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
            // d. If testResult is true, return kValue.
            var kValue = o[k];
            if (predicate.call(thisArg, kValue, k, o)) {
              return kValue;
            }
            // e. Increase k by 1.
            k++;
          }

          // 7. Return undefined.
          return undefined;
        },
        configurable: true,
        writable: true
      });
    }

    if (!Array.prototype.includes) {
      Object.defineProperty(Array.prototype, 'includes', {
        value: function(searchElement, fromIndex) {

          if (this == null) {
            throw new TypeError('"this" is null or not defined');
          }

          // 1. Let O be ? ToObject(this value).
          var o = Object(this);

          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;

          // 3. If len is 0, return false.
          if (len === 0) {
            return false;
          }

          // 4. Let n be ? ToInteger(fromIndex).
          //    (If fromIndex is undefined, this step produces the value 0.)
          var n = fromIndex | 0;

          // 5. If n ≥ 0, then
          //  a. Let k be n.
          // 6. Else n < 0,
          //  a. Let k be len + n.
          //  b. If k < 0, let k be 0.
          var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

          function sameValueZero(x, y) {
            return x === y || (typeof x === 'number' && typeof y === 'number' && isNaN(x) && isNaN(y));
          }

          // 7. Repeat, while k < len
          while (k < len) {
            // a. Let elementK be the result of ? Get(O, ! ToString(k)).
            // b. If SameValueZero(searchElement, elementK) is true, return true.
            if (sameValueZero(o[k], searchElement)) {
              return true;
            }
            // c. Increase k by 1.
            k++;
          }

          // 8. Return false
          return false;
        }
      });
    }

    if (typeof Object.assign != 'function') {
      // Must be writable: true, enumerable: false, configurable: true
      Object.defineProperty(Object, "assign", {
        value: function assign(target, varArgs) { // .length of function is 2
          'use strict';
          if (target == null) { // TypeError if undefined or null
            throw new TypeError('Cannot convert undefined or null to object');
          }

          var to = Object(target);

          for (var index = 1; index < arguments.length; index++) {
            var nextSource = arguments[index];

            if (nextSource != null) { // Skip over if undefined or null
              for (var nextKey in nextSource) {
                // Avoid bugs when hasOwnProperty is shadowed
                if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
                  to[nextKey] = nextSource[nextKey];
                }
              }
            }
          }
          return to;
        },
        writable: true,
        configurable: true
      });
    }

    if (!Array.prototype.flat != 'function') {
      Object.defineProperty(Array.prototype, "flat", {
        configurable: !0,
        value: function r() {
          var t = isNaN(arguments[0]) ? 1 : Number(arguments[0]);
          return t ? Array.prototype.reduce.call(this, function (a, e) {
            return Array.isArray(e) ? a.push.apply(a, r.call(e, t - 1)) : a.push(e), a;
          }, []) : Array.prototype.slice.call(this);
        },
        writable: !0
      });
    }

    if (!Array.prototype.flatMap != 'function') {
      Object.defineProperty(Array.prototype, "flatMap", {
        configurable: !0,
        value: function (r) {
          return Array.prototype.map.apply(this, arguments).flat();
        },
        writable: !0
      });
    }
    if (!Array.from) {
      Array.from = (function () {
        var toStr = Object.prototype.toString;
        var isCallable = function (fn) {
          return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
        };
        var toInteger = function (value) {
          var number = Number(value);
          if (isNaN(number)) { return 0; }
          if (number === 0 || !isFinite(number)) { return number; }
          return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
        };
        var maxSafeInteger = Math.pow(2, 53) - 1;
        var toLength = function (value) {
          var len = toInteger(value);
          return Math.min(Math.max(len, 0), maxSafeInteger);
        };

        // The length property of the from method is 1.
        return function from(arrayLike/*, mapFn, thisArg */) {
          // 1. Let C be the this value.
          var C = this;

          // 2. Let items be ToObject(arrayLike).
          var items = Object(arrayLike);

          // 3. ReturnIfAbrupt(items).
          if (arrayLike == null) {
            throw new TypeError('Array.from requires an array-like object - not null or undefined');
          }

          // 4. If mapfn is undefined, then let mapping be false.
          var mapFn = arguments.length > 1 ? arguments[1] : void undefined;
          var T;
          if (typeof mapFn !== 'undefined') {
            // 5. else
            // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
            if (!isCallable(mapFn)) {
              throw new TypeError('Array.from: when provided, the second argument must be a function');
            }

            // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
            if (arguments.length > 2) {
              T = arguments[2];
            }
          }

          // 10. Let lenValue be Get(items, "length").
          // 11. Let len be ToLength(lenValue).
          var len = toLength(items.length);

          // 13. If IsConstructor(C) is true, then
          // 13. a. Let A be the result of calling the [[Construct]] internal method
          // of C with an argument list containing the single item len.
          // 14. a. Else, Let A be ArrayCreate(len).
          var A = isCallable(C) ? Object(new C(len)) : new Array(len);

          // 16. Let k be 0.
          var k = 0;
          // 17. Repeat, while k < len… (also steps a - h)
          var kValue;
          while (k < len) {
            kValue = items[k];
            if (mapFn) {
              A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
            } else {
              A[k] = kValue;
            }
            k += 1;
          }
          // 18. Let putStatus be Put(A, "length", len, true).
          A.length = len;
          // 20. Return A.
          return A;
        };
      }());
    }
  })();

  console.log('## FI Module Script Loaded!!! ##');


  //////// 작성 영역 - 끝 ////////

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.cm.js
