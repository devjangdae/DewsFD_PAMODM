//임시파일입니다.
(function(dews, gerp, $) {
  var dewself = dews.ui.page;
  var $buttonGroup = dewself.$content.find("#divTopButtons");
  var $btnBudgetExtract = $('<button type="button" id="btnBudgetExtract">예산추출</button>');
  $buttonGroup.append($btnBudgetExtract);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.x10005.glddoc00500.js
