(function(dews, gerp, $) {
  dews.localize.load('', "FI_COMDIC");

  var module = {};

  //////// 작성 영역 - 시작 ////////
  var moduleCode = 'FI'; // 모듈 코드를 입력 해주세요.

  //Array Polyfill
  if(!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
      value: function (predicate) {
        'use strict';
        if (this == null) {
          throw new TypeError('Array.prototype.findIndex called on null or undefined');
        }
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }
        var list = Object(this);
        var length = list.length >>> 0;
        var thisArg = arguments[1];
        var value;

        for (var i = 0; i < length; i++) {
          value = list[i];
          if (predicate.call(thisArg, value, i, list)) {
            return i;
          }
        }
        return -1;
      },
      enumerable: false,
      configurable: false,
      writable: false
    });
  }
  
  module.AccountReceivable = {
    getWorker : function(dewself) {
      var worker = new AccountReceivableWorker(dewself);
      return worker;
    },
    ready : function(dewself, callback) {
      var dfd = $.Deferred();
      var that = this;

      dews.ui.loading.show({
        type : "tiny",
        text : dews.localize.get("페이지를 불러오는중입니다.", "M0019787", '', 'FI_COMDIC')
      });

      $.ajax({
        type : "GET",
        url : "/view/FI/ARECMTPAGE",
        async : true,
        success : function(response) {
          dewself.$content.find("script").before(response);
          $(document).trigger('inituicontrols', [ dewself.$content ]);  
          dfd.resolve(true);
          dews.ui.loading.hide();
        },
        error : function(response) {
          dfd.reject(false);
        }
      });

      dfd.promise().done(function(resolve){
        if($.type(callback) === "function") {
          var worker = that.getWorker(dewself);
          callback(worker);
        }
      }).fail(function(reject){
        dews.alert(dews.localize.get("매출채권 페이지를 불러오는데 실패하였습니다.", 'M0019788', '', 'FI_COMDIC'), "error");
      });
    }
  };

  function AccountReceivableBulider(dewself) {
    if(!(this instanceof AccountReceivableBulider) ) {
      return new AccountReceivableBulider(dewself);
    }
    
    this.dewself = dewself;     
    this.dewself.AccountReceivable = this;
    this.arGrid = this.getGrid();
    this.differenceInterval;                   
    this.calulateInterval;

    this.initialize();

    //조회
    dewself.$btnSearch.on("click", function(e) {
      dewself.AccountReceivable.onSearch();
    });

    //계산
    dewself.$btnCalculate.on("click", function(e) {
      e.preventDefault();
      try {
        if(dewself.AccountReceivable.isRepayment()) {
          throw dews.localize.get("반제완료된 데이터가 존재합니다.", "M0019789", '', 'FI_COMDIC');
        }
  
        if(!dewself.DIFF_ACCT_CD_P.code() && dewself.DIFF_AMT_V.value() > 0) {
          clearInterval(dewself.AccountReceivable.differenceInterval);
        }
        dewself.AccountReceivable.onCalculate();
      } catch (error) {
        dews.ui.snackbar.warning(error);
      }
    });

    //계산버튼 활성화처리
    dewself.$btnCalculate.hover(function(e) {
      if(dewself.REPAYMENT_EX_AMT_V.value() == 0) {
        if(dewself.AccountReceivable.arGrid.getCheckedRows().length > 0 && dewself.AccountReceivable.calulateInterval) {
          dewself.AccountReceivable.activeCalculateButton(false);
        }
      }
    }, function(e) {
      try {
        if(dewself.AccountReceivable.isRepayment()) {
          throw dews.localize.get("반제완료된 데이터입니다.", "M0019790", '', 'FI_COMDIC');
        }
        if(dewself.REPAYMENT_EX_AMT_V.value() == 0) {
          if(dewself.AccountReceivable.arGrid.getCheckedRows().length > 0 && !dewself.AccountReceivable.calulateInterval) {
            dewself.AccountReceivable.activeCalculateButton(true);
          }
        }
      } catch (error) {
        dews.ui.snackbar.warning(error);
      }
    });

    //상단그리드 체크박스
    dewself.$grid.on("selected", function(e) {
      if(dewself.AccountReceivable.arGrid.dataItems().length > 0) {
        dews.alert(dews.localize.get("수금정보에 변경된 사항이 있어 반제정보를 초기화합니다.", 'M0019791', '', 'FI_COMDIC'), "warning").done(function(){
          dewself.AccountReceivable.arGrid.dataSource.data([]);
        });
      }
      dewself.AccountReceivable.requestForCollection(e.cell.isClicked);
    });

    //상단그리드 데이터바운드
    dewself.$grid.on("dataBound", function(e) {
      if(dewself.AccountReceivable.arGrid.dataItems().length > 0) {
        dews.alert(dews.localize.get("수금정보에 변경된 사항이 있어 반제정보를 초기화합니다.", 'M0019791', '', 'FI_COMDIC'), "warning").done(function(){
          dewself.AccountReceivable.arGrid.dataSource.data([]);
          dewself.AccountReceivable.resetCollectionView();
        });
      }
    });

    //상단그리드 전표번호 더블클릭시
    dewself.$grid.on("dblClicked", function(e) {
      if(e.cell.field == "SDOCU_NO" && e.row.data.SDOCU_NO) {
        dews.ui.openMenu("FI", "GLDDOC00700", {
          pc_cd : e.row.data.PC_CD,
          docu_no : e.row.data.SDOCU_NO,
          doline_sq : e.row.data.SDOCU_LINE_SQ
        });
      }
    });
    
    //차액계정
    dewself.$DIFF_ACCT_CD_P.on("setData", function(e, data) {
      if(!data.ACCT_CD && dewself.DIFF_AMT_V.value() > 0) {
        dewself.AccountReceivable.activeDifferenceAccount();
      } else {
        clearInterval(dewself.AccountReceivable.differenceInterval);
      }
    });
  }
  
  AccountReceivableBulider.prototype.initialize = function() {
    var common = this.getCommon();
    
    this.dewself.ACTG_DT_P.value(new Date());
    this.dewself.DEPT_CD_P.setData({ DEPT_CD : this.dewself.user.deptCode, DEPT_NM : this.dewself.user.deptName });
    this.dewself.EMP_NO_P.setData({ EMP_NO : this.dewself.user.empCode, KOR_NM : this.dewself.user.username });
    this.dewself.GAIN_ACCT_CD_P.setDataSource(
      common.getAccountMasterHasAttr("825").map(function(value){
        return {
          ACCT_NM : value.ACCT_CD + " "+value.ACCT_NM,
          ACCT_CD : value.ACCT_CD
        };
      })
    );
    this.dewself.LOSS_ACCT_CD_P.setDataSource(
      common.getAccountMasterHasAttr("905").map(function(value){
        return {
          ACCT_NM : value.ACCT_CD + " "+value.ACCT_NM,
          ACCT_CD : value.ACCT_CD
        };
      })
    );

    this.dewself.PC_CD_L.setData({ PC_CD : this.dewself.user.profitCenterCode, PC_NM : this.dewself.user.profitCenterName });
    this.dewself.ACTG_DT_L.setupToday();

    var codeDetail = new Object();
    common.getCodeData(codeDetail, "FI", "S40880", "", "", "", "", "", "");
    this.dewself.BAN_ST_CD_L.setDataSource(codeDetail.FI.S40880);
  };

  AccountReceivableBulider.prototype.getCommon = function() {
    var common; 

    dews.ajax.script('~/view/js/FI/fi.cm.js', { 
      once: true , 
      async : false
    }).done(function() {
      common = gerp.FI;
    }).fail(function(xhr, status, error) { 
      dews.alert("Common API Service not found","error");
    });

    return common;
  };

  AccountReceivableBulider.prototype.createDataSource = function() {
    var dataSource = dews.ui.dataSource('dataSource', {
      grid: true,
      error: function (e) {
        if (e) {
          dews.error({
            message: e.message || dews.localize.get("데이터를 전송받지 못하였습니다.", 'M0000084', '', 'FI_COMDIC'),
            error: e.error || ''
          });
          dews.ui.loading.hide();
        }
      },
      schema: {
        model: {
          fields: [
            { field : 'COMPANY_CD', type : "string" },   //회사코드 
            { field : 'PC_CD', type : "string" },        //회계단위
            { field : 'DOCU_CD', type : "string" },      //원전표 전표유형
            { field : 'GAAP_CD', type : "string" },      //원전표 계정유형
            { field : 'ACTG_DT', type : "string" },      //회계일    
            { field : 'ACCT_CD', type : "string" },      //매출채권 계정코드
            { field : 'DOCU_NO', type : "string" },      //전표번호
            { field : 'DOLINE_SQ', type : "string" },    //라인순번
            { field : 'BAN_ST_CD', type : "string" },    //반제상태
            { field : 'PARTNER_CD', type :'string'},     //거래처코드 
            { field : 'PARTNER_NM', type : 'string'},    //거래처명 
            { field : 'CC_CD', type : 'string'},         //비용센터코드 
            { field : 'CC_NM', type : 'string'},         //비용센터명
            { field : 'PJT_CD', type : 'string'},        //프로젝트코드
            { field : 'PJT_NM', type : 'string'},        //프로젝트명
            { field : 'END_DT', type : 'string'},        //만기일
            { field : 'DEPT_CD', type : 'string'},       //부서코드 
            { field : 'DEPT_NM', type : 'string'},       //부서명
            { field : 'NOTE_DC', type : 'string'},       //적요
            { field : 'DOCU_AMT', type : "number" },     //발생금액(장부통화)
            { field : 'FMNY_AMT', type : "number" },     //발생금액(거래통화)
            { field : 'EXCH_CD', type : "string" },      //환종
            { field : 'EXRT_RT', type : "number" },      //환율
            { field : 'BAN_AMT', type : "number" },      //기반제금액(장부통화)
            { field : 'FMNY_BAN_AMT', type : "number" }, //기반제금액(거래통화)
            { field : 'BAL_AMT', type : "number" },      //잔액(장부통화)
            { field : 'FMNY_BAL_AMT', type : "number" }, //잔액(거래통화)
            { field : 'REPAY_RT', type : "number" },     //반제비율
            { field : 'REPAY_EX_AMT', type : "number" }, //반제액(거래통화)
            { field : 'IN_EX_AMT', type : "number" },    //수금액(거래통화)
            { field : 'REPAY_AMT', type : "number" },    //반제액(장부통화)
            { field : 'IN_AMT', type : "number" },       //수금액(장부통화)
            { field : 'GAINLOSS_AMT', type : "number" }, //환차손익
            { field : 'SDOCU_NO', type : "number" },     //처리 전표번호
            { field : 'SDOCU_LINE_SQ', type : "number" },//처리전표 라인순번
            { field : 'SALESORGN_CD', type : "string" }, //영업조직코드
            { field : 'SALESORGN_NM', type : "string" }, //영업조직명
            { field : 'SAOFF_CD', type : "string" },     //사업부코드
            { field : 'SAOFF_NM', type : "string" },     //사업부명
            { field : 'SALEGRP_CD', type : "string" },   //영업그룹코드
            { field : 'SALEGRP_NM', type : "string" },   //영업그룹명
            { field : 'ITEM_CD', type : "string" },      //품목코드
            { field : 'ITEM_NM', type : "string" },      //품목명
            { field : 'PRDUCTGRP_CD', type : "string" }, //제품군코드
            { field : 'PRDUCTGRP_NM', type : "string" }, //제품군명
            { field : 'DISCH_CD', type : "string" },     //유통경로코드
            { field : 'DISCH_NM', type : "string" },     //유통경로명
            { field : 'CUST_GRP_CD', type : "string" },  //고객그룹코드
            { field : 'CUST_GRP_NM', type : "string" },  //고객그룹명
          ]
        }
      }
    });
    return dataSource;
  };

  AccountReceivableBulider.prototype.getGrid = function() {
    var dewself = this.dewself;

    var grid = dews.ui.grid(dewself.$arGrid, {
      dataSource: this.createDataSource(),
      selectable: true,
      checkable: true,
      autoBind: false,
      noData: true,
      editSkip: true,
      height: 150,
      editable: true,
      columns: [
        {
          field: 'ACTG_DT', 
          title: dews.localize.get('회계일', 'D0003036', '', 'FI_COMDIC'),
          width: 75,
          align: 'left',
          formats: {
            type: 'date',
            predefined: true,
            format: 'MA00007' 
          },
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'DOCU_NO', 
          title: dews.localize.get('전표번호', 'D0003047', '', 'FI_COMDIC'),
          width: 110,
          align: 'left',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'DOLINE_SQ',
          title: dews.localize.get("라인순번", "D0003400", '', 'FI_COMDIC'),
          width: 60,
          align: 'right',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'PARTNER_CD',
          title: dews.localize.get("거래처코드", "D0000046", '', 'FI_COMDIC'),
          width: 80,
          align: 'left',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'PARTNER_NM',
          title: dews.localize.get("거래처명", "D0000047", '', 'FI_COMDIC'),
          width: 130,
          align: 'left',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'DEPT_CD',
          title: dews.localize.get("부서코드", "D0000676", '', 'FI_COMDIC'),
          width: 80,
          align: 'left',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'DEPT_NM',
          title: dews.localize.get("부서명", "D0000077", '', 'FI_COMDIC'),
          width: 130,
          align: 'left',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'NOTE_DC', 
          title: dews.localize.get('적요', 'D0003295', '', 'FI_COMDIC'),
          width: 200,
          align: 'left',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'FMNY_AMT', 
          title: dews.localize.get('발생금액(거래통화)', 'D0090427', '', 'FI_COMDIC'),
          width: 130,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'EXCH_CD', 
          title: dews.localize.get('환종', 'D0001008', '', 'FI_COMDIC'),
          width: 45,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'EXRT_RT', 
          title: dews.localize.get('환율', 'D0002959', '', 'FI_COMDIC'),
          width: 60,
          align: 'right',
          visible: true,
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00006' 
          },
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'FMNY_BAN_AMT', 
          title: dews.localize.get('기반제금액(거래통화)', 'D0090428', '', 'FI_COMDIC'),
          width: 130,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'FMNY_BAL_AMT', 
          title: dews.localize.get('잔액', 'D0003298', '', 'FI_COMDIC'),
          width: 130,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'REPAY_RT', 
          title: dews.localize.get('반제비율', 'D0090429', '', 'FI_COMDIC'),
          width: 70,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          editor : {
            type : "number",
            editable : function(e) {
              return true;
            }
          },
          visible: true,
          suffix : "%",
        },
        {
          field: 'REPAY_EX_AMT', 
          title: dews.localize.get('반제액(거래통화)', 'D0011608', '', 'FI_COMDIC'),
          width: 130,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'IN_EX_AMT', 
          title: dews.localize.get('수금액(거래통화)', 'D0011603', '', 'FI_COMDIC'),
          width: 130,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          editor : {
            type : "number",
            predefined: true,
            format: 'MA00003',
            editable : function(e) {
              if(dewself.AccountReceivable.getHighExchangeCode() == dewself.AccountReceivable.getLowExchangeCode()) {
                return false;
              } else {
                return true;
              }
            }
          },
          visible: true,
        },
        {
          field: 'REPAY_AMT', 
          title: dews.localize.get('반제액(장부통화)', 'D0011609', '', 'FI_COMDIC'),
          width: 130,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'IN_AMT', 
          title: dews.localize.get('수금액(장부통화)', 'D0011604', '', 'FI_COMDIC'),
          width: 130,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'GAINLOSS_AMT', 
          title: dews.localize.get('환차손익', 'D0011610', '', 'FI_COMDIC'),
          width: 130,
          align: 'right',
          formats: {
            type: 'number',
            predefined: true,
            format: 'MA00003' 
          },
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'SDOCU_NO', 
          title: dews.localize.get('처리전표번호', 'D0011605', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'SDOCU_LINE_SQ',
          title: dews.localize.get("라인순번", "D0003400", '', 'FI_COMDIC'),
          width: 60,
          align: 'right',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'SALESORGN_CD', 
          title: dews.localize.get('영업조직코드', 'D0000099', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'SALESORGN_NM', 
          title: dews.localize.get('영업조직명', 'D0000100', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'SAOFF_CD', 
          title: dews.localize.get('사업부코드', 'D0000983', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'SAOFF_NM', 
          title: dews.localize.get('사업부명', 'D0000982', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'SALEGRP_CD', 
          title: dews.localize.get('영업그룹코드', 'D0000988', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'SALEGRP_NM', 
          title: dews.localize.get('영업그룹명', 'D0000105', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'ITEM_CD', 
          title: dews.localize.get('품목코드', 'D0000033', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'ITEM_NM', 
          title: dews.localize.get('품목명', 'D0000034', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'PRDUCTGRP_CD', 
          title: dews.localize.get('제품군코드', 'D0000133', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'PRDUCTGRP_NM', 
          title: dews.localize.get('제품군명', 'D0000104', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'DISCH_CD', 
          title: dews.localize.get('유통경로코드', 'D0000106', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'DISCH_NM', 
          title: dews.localize.get('유통경로명', 'D0000103', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'CUST_GRP_CD', 
          title: dews.localize.get('고객그룹코드', 'D0003239', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
        {
          field: 'CUST_GRP_NM', 
          title: dews.localize.get('고객그룹명', 'D0003240', '', 'FI_COMDIC'),
          width: 100,
          align: 'center',
          visible: true,
          attributes: {
            class: "readonly"
          },
        },
      ],
      dataBound : function(e) {
        dewself.AccountReceivable.resetRepaymentView();
        clearInterval(dewself.AccountReceivable.differenceInterval);
        dewself.AccountReceivable.activeCalculateButton(false);
        e.grid.setFocus();
      },
      validationCheck : function(e) {
        if(e.cell.field == "REPAY_RT") {    //반제비율
          if(e.cell.data > 100 || e.cell.data < 0) {
            e.grid.setCellValue(e.row.index, e.cell.field, 100);
          }
        } else if(e.cell.field == "IN_EX_AMT") {  //수금액(거래통화)
          if(e.cell.data > e.grid.getCellValue(e.row.index, "REPAY_EX_AMT")) {
            e.grid.setCellValue(e.row.index, e.cell.field, e.grid.getCellValue(e.row.index, "REPAY_EX_AMT"));
          }
        }
      },
      selected : function(e) {
        if(dewself.REPAYMENT_EX_AMT_V.value() > 0) {
          dews.alert(dews.localize.get("반제정보에 변경된 사항이 있어 반제정보를 초기화합니다.", 'M0019792', '', 'FI_COMDIC'), "warning").done(function(){
            dewself.AccountReceivable.arGrid.dataSource.data([]);
            dewself.AccountReceivable.resetRepaymentView();
          });
        } else {
          if(dewself.AccountReceivable.getHighExchangeCode() != dewself.AccountReceivable.getLowExchangeCode()) {
            if(e.cell.isClicked) {
              dewself.AccountReceivable.activeRequiredCollection(e.row.index, e.cell.header.isClicked, true);
            } else {
              dewself.AccountReceivable.activeRequiredCollection(e.row.index, e.cell.header.isClicked, false);
            }
          } 

          if(e.cell.isClicked) {
            if(dewself.AccountReceivable.isRepayment()) {
              return false;
            }
            if(e.grid.getCheckedRows().length == 1 || (e.cell.header.isClicked && !dewself.AccountReceivable.calulateInterval)) {
              dewself.AccountReceivable.activeCalculateButton(true);
            }   
          } else {
            if(e.grid.getCheckedRows().length == 0) {
              dewself.AccountReceivable.activeCalculateButton(false);
            }
          }
        }
      },
      save : function(e) {
        if(e.cell.field == "REPAY_RT") {
          dewself.AccountReceivable.changeRepayment(e.row.index, e.row.data.FMNY_BAL_AMT, e.row.data.REPAY_RT);
        }
      },
      dblClicked : function(e) {
        if(e.cell.field == "DOCU_NO" && e.row.data.DOCU_NO) {
          dews.ui.openMenu("FI", "GLDDOC00700", {
            pc_cd : e.row.data.PC_CD,
            docu_no : e.row.data.DOCU_NO,
            doline_sq : e.row.data.DOLINE_SQ
          });
        }
      }
    });
    return grid;
  };
  
  /**
   * 수금처리시 공통 필드 정보
   * @param  {} field
   */
  AccountReceivableBulider.prototype.getField = function(field) {
    var COLLECTION_MODEL = new Object({
      PC_CD : "PC_CD",
      COLLECT_EX_AMT : "COLLECT_EX_AMT",
      COLLECT_AMT : "COLLECT_AMT",
      EXCH_CD : "EXCH_CD",
      EXRT_RT : "EXRT_RT",
      DOCU_NO : "DOCU_NO",
      DOLINE_SQ : "DOLINE_SQ",
      SDOCU_NO : "SDOCU_NO",
      SDOCU_LINE_SQ : "SDOCU_LINE_SQ"
    });
    return COLLECTION_MODEL[field];
  };

  AccountReceivableBulider.prototype.onSearch = function() {
    var common = this.getCommon();
    try {
      var companyExchangeCode = common.getCompanyInfo().EXCH_CD;

      var checkRows = this.dewself.grid.getCheckedRows();
      if(checkRows.length == 0) {
        throw dews.localize.get("수금정보에 선택된 데이터가 없습니다.", "M0019793", '', 'FI_COMDIC');
      } else if(this.hasSlip(checkRows)) {
        throw dews.localize.get("수금정보에 수금처리된 데이터가 존재합니다.", "M0019794", '', 'FI_COMDIC');
      } else if(!this.getHighExchangeCode() || !this.getLowExchangeCode()){
        return false;
      } else if(checkRows.length > 1 && this.getHighExchangeCode() != this.getLowExchangeCode()) {
        throw dews.localize.get("이종 환종 수금처리의 경우 복수의 수금정보를 선택할 수 없습니다.", "M0019795", '', 'FI_COMDIC');
      } else {
        if(this.dewself.lowCondition.validate()) {
          this.search(this.arGrid);

          if(this.getHighExchangeCode() == this.getLowExchangeCode()) {
            this.setCellStyle(this.arGrid, "IN_EX_AMT", { background : "#f5f5f5" });
          } else {
            this.setCellStyle(this.arGrid, "IN_EX_AMT", { background : "#ffffff" });
          }
        }
      }  
    } catch (error) {
      var dewself = this.dewself;
      dews.alert(error, "warning").done(function(){
        dewself.grid.setCheck(dewself.grid.getCheckedIndex(), false);
        dewself.grid.setHeaderCheck(false);
      });
    }
  };

  AccountReceivableBulider.prototype.onCalculate = function() {
    try {
      var checkRows = this.dewself.grid.getCheckedRows();

      if(checkRows.length == 0) {
        throw dews.localize.get("수금정보에 선택된 데이터가 없습니다.", "M0019793", '', 'FI_COMDIC');
      } else if(this.arGrid.getCheckedRows().length == 0) {
        throw dews.localize.get("반제정보에 선택된 데이터가 없습니다.", "M0019796", '', 'FI_COMDIC');
      } else if(!this.getHighExchangeCode() || !this.getLowExchangeCode()){
        return false;
      } else if(checkRows.length > 1 && this.getHighExchangeCode() != this.getLowExchangeCode()) {
        throw dews.localize.get("이종 환종 수금처리의 경우 복수의 수금정보를 선택할 수 없습니다.", "M0019795", '', 'FI_COMDIC');
      } else {
        this.invokeCalculate();
        this.arGrid.commitCell();
      }
    } catch (error) {
      dews.alert(error, "warning");
    }
  };

  AccountReceivableBulider.prototype.invokeCalculate = function() {
    try {
      if(this.validate()) {
        var balance = this.invokeFifo();

        if(balance > 0) {
          this.dewself.DIFF_AMT_V.value(balance);
          
          if(!this.dewself.DIFF_ACCT_CD_P.code()) {
            this.activeDifferenceAccount();
          }
        }

        var indexes = this.getPureRepayment().indexes;
        var repaymentExchangeAmount = this.getCellAddAmount(this.arGrid, indexes, "REPAY_EX_AMT");
        var repaymentAmount = this.getCellAddAmount(this.arGrid, indexes, "REPAY_AMT");
        var gainLossAmount = this.getCellAddAmount(this.arGrid, indexes, "GAINLOSS_AMT");

        this.dewself.EXCH_CD_V.text(this.arGrid.getCheckedRows()[0].EXCH_CD);
        this.dewself.REPAYMENT_EX_AMT_V.value(repaymentExchangeAmount);
        this.dewself.REPAYMENT_AMT_V.value(repaymentAmount);
        this.dewself.GAINLOSS_AMT_V.value(gainLossAmount);
      }
    } catch (error) {
      dews.alert(error, "warning");
    }
  };

  AccountReceivableBulider.prototype.search = function(grid) {
    var dewself = this.dewself;

    dews.ui.loading.show({
      text: dews.localize.get('내용을 불러오고 있습니다.', 'M0000004', '', 'FI_COMDIC')
    });
    dews.api.get(dews.url.getApiUrl("FI", "AccountReceivableService", "list"),{
      data : {
        pc_cd : dewself.PC_CD_L.code(),                  //회계단위코드
        partner_cd : dewself.PARTNER_CD_L.code(),        //거래처코드
        bond_acct_cd : dewself.BOND_ACCT_CD_L.code(),    //채권계정코드
        start_dt : dewself.ACTG_DT_L.getStartDate(),     //회계일 시작일자
        end_dt : dewself.ACTG_DT_L.getEndDate(),         //회계일 종료일자
        high_exch_cd : dewself.AccountReceivable.getHighExchangeCode(), //상단 조회조건 환종코드
        exch_cd : dewself.EXCH_CD_L.code(),              //환종
        ban_st_cd : dewself.BAN_ST_CD_L.value(),         //반제상태여부
        dept_cd : dewself.DEPT_CD_L.code(),              //부서코드
        dvsn_cd : dewself.DVSN_CD_L.code(),              //사업부코드
        salegrp_cd : dewself.SALEGRP_CD_L.code(),        //영업그룹코드
        salesorgn_cd : dewself.SALESORGN_CD_L.code(),    //영업조직코드
        disch_cd : dewself.DISCH_CD_L.code(),            //유통경로코드
        grp_cust_cd : dewself.GRP_CUST_CD_L.code(),      //고객그룹코드
        prductgrp_cd : dewself.PRDUCTGRP_CD_L.code(),    //제품군코드
        item_cd : dewself.ITEM_CD_L.code(),              //품목코드
      }
    }).done(function(data){
      if(data.length == 0) {
        grid.dataSource.data([]);
      } else {
        grid.dataSource.data(data);
      }
    }).fail(function(xhr,status,error){
      dews.ui.snackbar.error(dews.localize.get("데이터를 전송받지 못하였습니다.", 'M0000084', '', 'FI_COMDIC'));
    }).always(function(){
      dews.ui.loading.hide();
    });
  };

  AccountReceivableBulider.prototype.requestForCollection = function(isClicked) {
    var dewself = this.dewself;
    var indexes = dewself.grid.getCheckedIndex();
    
    var exchangeCode;
    if(indexes.length > 0) {
      exchangeCode = dewself.grid.getCellValue(indexes[0], this.getField("EXCH_CD"));
    }
    try {
      if(isClicked) {
        if(indexes.length > 1 && !this.verifyExchangeCode(exchangeCode)) {
          throw dews.localize.get("외화 수금일경우\n 복수의 수금 데이터를 선택할 수 없습니다.", "M0019797", '', 'FI_COMDIC');
        } 
      }
    } catch (error) {
      dews.alert(error, "warning").done(function(){
        dewself.grid.setCheck(indexes, false);
        dewself.grid.setHeaderCheck(false);
        
        if(dewself.AccountReceivable.arGrid.dataItems().length > 0) {
          dewself.AccountReceivable.arGrid.dataSource.data([]);
        }
      });
    } finally {  
      var collectExchangeAmount = this.getCellAddAmount(dewself.grid, indexes, this.getField("COLLECT_EX_AMT"));
      var collectAmount = this.getCellAddAmount(dewself.grid, indexes, this.getField("COLLECT_AMT"));

      dewself.COLLECT_EX_AMT_V.value(collectExchangeAmount);
      dewself.COLLECT_AMT_V.value(collectAmount);

      if(dewself.COLLECT_EX_AMT_V.value() > 0 || dewself.COLLECT_AMT_V.value() > 0 ) {
        dewself.COLLECT_EXCH_CD_V.text(exchangeCode);
      } else {
        dewself.COLLECT_EXCH_CD_V.text(null);
      }
    }
  };
  
  
  /**
   * 통화 코드 일치 여부 검증
   * @param  {} exchangeCode
   */
  AccountReceivableBulider.prototype.verifyExchangeCode = function(exchangeCode) {
    var verify = false;
    if(exchangeCode) {
      var companyInfo = this.getCommon().getCompanyInfo();
      
      if(companyInfo.EXCH_CD === exchangeCode) {
        verify = true;
      }
    }
    return verify;
  };

  AccountReceivableBulider.prototype.getHighExchangeCode = function() {
    var exchangeCode;
    var dewself = this.dewself;

    var nodes = this.dewself.$content.find("[data-dews-help-params='module_cd=MA&field_cd=P00840']");
    if(nodes.length > 0) {
      $(nodes).each(function(index, node){
        if(node.id != dewself.$EXCH_CD_L.attr("id")) {
          if(!dewself[node.id].code()) {
            dewself[node.id].focus();
            dews.ui.tooltip.show($(dewself[node.id]._element), {
              durationTime: 0,
              fadeOutTime: 3000,
              position: "top",
              text: dews.localize.get("상단 조회조건 환종이 입력되지 않았습니다.", "M0019798", '', 'FI_COMDIC'),
              type: "required"
            });
            return false;
          } else {
            exchangeCode = dewself[node.id].code();
          }
        }
      });
    }  
   
    return exchangeCode;
  };

  AccountReceivableBulider.prototype.getLowExchangeCode = function() {
    var exchangeCode = this.dewself.EXCH_CD_L.code();
    
    if(!exchangeCode) {
      this.dewself.EXCH_CD_L.focus();
      dews.ui.tooltip.show(this.dewself.$EXCH_CD_L, {
        durationTime: 0,
        fadeOutTime: 3000,
        position: "top",
        text: dews.localize.get("하단 조회조건 환종이 입력되지 않았습니다.", "M0019799", '', 'FI_COMDIC'),
        type: "required"
      });
    }
    return exchangeCode;
  };

  AccountReceivableBulider.prototype.getCellAddAmount = function(grid, indexes, field) {
    var addReducer = function(previous, current) { return previous + current; };
    return indexes.map(function(index) { 
      
      if(grid.getCellValue(index, field)) {
        return grid.getCellValue(index, field);
      } else {
        return 0;
      }
    }).reduce(addReducer, 0);
  };

  AccountReceivableBulider.prototype.getPureRepayment= function() {
    var pureRepayment = {};

    var indexes = this.arGrid.getCheckedIndex();
    if(indexes.length > 0) {
      var arGrid = this.arGrid;

      var pureIndexes = [];
      var pureRows = [];
      indexes.forEach(function(index) {
        var row = arGrid.dataItem(index);
        if(row.REPAY_EX_AMT > 0 && row.REPAY_AMT > 0 && row.IN_EX_AMT > 0 && row.IN_AMT > 0) {
          pureIndexes.push(index);
          pureRows.push(row);
        }
      });
      
      pureRepayment.indexes = pureIndexes;
      pureRepayment.rows = pureRows;
    } 

    return pureRepayment;
  };

  AccountReceivableBulider.prototype.setRepaymentAmount = function(index, amount) { 
    if(this.getHighExchangeCode() == this.getLowExchangeCode()){
      this.arGrid.setCellValue(index, "IN_EX_AMT", amount);  
      this.arGrid.setCellValue(index, "IN_AMT", amount * this.dewself.grid.getCheckedRows()[0][this.getField("EXRT_RT")]);
    } else {
      var inExchangeAmount = this.arGrid.getCellValue(index, "IN_EX_AMT");
      var exchangeRate =  this.dewself.grid.getCheckedRows()[0][this.getField("EXRT_RT")];

      this.arGrid.setCellValue(index, "IN_AMT", inExchangeAmount * exchangeRate);
    }
    this.arGrid.setCellValue(index, "REPAY_EX_AMT", amount);
    this.arGrid.setCellValue(index, "REPAY_AMT", amount * this.arGrid.getCellValue(index, "EXRT_RT"));
    this.arGrid.setCellValue(index, "GAINLOSS_AMT", this.arGrid.getCellValue(index, "IN_AMT") - this.arGrid.getCellValue(index, "REPAY_AMT"));
  };

  AccountReceivableBulider.prototype.activeDifferenceAccount = function() {
    var that = this;

    this.differenceInterval = setInterval(function(){
      if(that.dewself.$DIFF_ACCT_CD_P.parent().prop("class").indexOf("dews-state-focused") == -1) {
        that.dewself.$DIFF_ACCT_CD_P.parent().addClass("dews-state-focused");
      } else {
        that.dewself.$DIFF_ACCT_CD_P.parent().removeClass("dews-state-focused");
      }
      dews.ui.tooltip.show(that.dewself.$DIFF_ACCT_CD_P, {
        durationTime: 0,
        fadeOutTime: 3000,
        position: "top",
        text: dews.localize.get("차액계정을 입력하세요.", "M0019800", '', 'FI_COMDIC'),
        type: "nomal"
      });
    }, 500);
  };

  AccountReceivableBulider.prototype.activeCalculateButton = function(isActive) {
    var that = this.dewself;
    if(isActive) {
      this.calulateInterval = setInterval(function(){
        if(that.$btnCalculate.css("background-color") == "rgb(255, 255, 255)") {
          that.$btnCalculate.css("background", "#f0f0f0");
        } else {
          that.$btnCalculate.css("background", "#fff");
        }
      }, 400);
    } else {
      clearInterval(this.calulateInterval);
      that.AccountReceivable.calulateInterval = null;
      that.$btnCalculate.removeAttr("style");  
    }
  };

  AccountReceivableBulider.prototype.resetCollectionView = function() {
    this.dewself.COLLECT_EXCH_CD_V.text(null);
    this.dewself.COLLECT_EX_AMT_V.value(0);
    this.dewself.COLLECT_AMT_V.value(0);
  };

  AccountReceivableBulider.prototype.resetRepaymentView = function() {
    this.dewself.EXCH_CD_V.text(null);
    this.dewself.REPAYMENT_EX_AMT_V.value(0);
    this.dewself.REPAYMENT_AMT_V.value(0);
    this.dewself.DIFF_AMT_V.value(0);
    this.dewself.GAINLOSS_AMT_V.value(0);
  };

  AccountReceivableBulider.prototype.changeRepayment = function(index, balanceAmount, ratio) {
    if(this.getHighExchangeCode() != this.getLowExchangeCode()) {
      this.arGrid.setCellValue(index, "REPAY_EX_AMT", balanceAmount * (ratio / 100));
      this.arGrid.commitCell();
    }
  };

  AccountReceivableBulider.prototype.getCheckedIndex = function() {
    var checkIndex = new Array();
    try {
      var arGrid = this.arGrid;
      arGrid.sortDataItems().forEach(function(row) {
        arGrid.getCheckedIndex().forEach(function(index){
          var checkRow = arGrid.dataItem(index);
          if(checkRow.DOCU_NO == row.DOCU_NO) {
            checkIndex.push(index);
          }
        });
      });  
    } catch (error) {
      dews.alert(error, "warning");
    }
    return checkIndex;
  };

  AccountReceivableBulider.prototype.validate = function() {
    var validate = false;
    try {
      if(this.getHighExchangeCode() != this.getLowExchangeCode()){
        var arGrid = this.arGrid;

        validate = arGrid.getCheckedIndex().every(function(index){
          var inExchangeAmount = arGrid.getCellValue(index, "IN_EX_AMT");
          
          if(inExchangeAmount) {
            return true;
          } else {
            arGrid.select(index, "IN_EX_AMT");
            throw dews.localize.get("수금액(거래통화)는 필수 입력입니다.", "M0019801", '', 'FI_COMDIC');
          }
        });  
      } else {
        validate = true;
      }
    } catch (error) {
      dews.ui.snackbar.warning(error);
    }
    return validate;
  };

  AccountReceivableBulider.prototype.invokeFifo = function() {
    var that = this;

    var collectExchangeAmount = that.dewself.COLLECT_EX_AMT_V.value();
    if(that.getHighExchangeCode() != that.getLowExchangeCode()) {
      collectExchangeAmount *= that.dewself.grid.getCheckedRows()[0][that.getField("EXRT_RT")];
    } 
    $.each(that.arGrid.getCheckedIndex(),function(indexes, index) {
      var rateAmount = that.arGrid.getCellValue(index, "FMNY_BAL_AMT") * (that.arGrid.getCellValue(index, "REPAY_RT") / 100);

      if(collectExchangeAmount - rateAmount >= 0) {
        that.setRepaymentAmount(index, rateAmount);
        collectExchangeAmount -= rateAmount;
      } else {
        that.setRepaymentAmount(index, collectExchangeAmount);
        collectExchangeAmount -= rateAmount;
        return false;
      }
    });

    return collectExchangeAmount;
  };
  
  AccountReceivableBulider.prototype.getRepaymentSlip = function() {
    var grid = this.dewself.grid;
    var arGrid = this.arGrid;
    var document;
    
    dews.api.post(dews.url.getApiUrl("FI", "AccountReceivableService", "repayment"), {
      async : false,
      data: {
        menu_id : this.dewself.menu.id,
        actg_dt : this.dewself.ACTG_DT_P.value(),
        dept_cd : this.dewself.DEPT_CD_P.code(),
        emp_no : this.dewself.EMP_NO_P.code(),
        diff_amt : this.dewself.DIFF_AMT_V.value(),
        diff_acct_cd : this.dewself.DIFF_ACCT_CD_P.code(),
        gainloss_amt : this.dewself.GAINLOSS_AMT_V.value(),
        gain_acct_cd : this.dewself.GAIN_ACCT_CD_P.value(),
        loss_acct_cd : this.dewself.LOSS_ACCT_CD_P.value(),
        collectionsRows : JSON.stringify(this.dewself.grid.getCheckedRows()),
        arGridRows : JSON.stringify(this.getPureRepayment().rows),
      }
    }).done(function(data){
      if(data.length > 0) {
        document = JSON.parse(data);
      }
    }).fail(function(xhr, status, error){
      dews.alert(error, "error").done(function(){
        arGrid.dataSource.data([]);
        grid.dataSource.data([]);
      });
    });
    
    return document;
  };

  AccountReceivableBulider.prototype.openPreview = function(slip) { 
    var dfd = $.Deferred();
    var that = this;

    var preview = dews.ui.dialog("GLDDOC00500_PREVIEW",{
      url : "/view/FI/GLDDOC00500_PREVIEW",
      title : this.dewself.menu.name,
      width : 720,
      height: 586,
      ok : function(data) {
        if(!that.saveRepayment(data)) {
          preview.close();
          dfd.reject("fail");
        } else {
          dfd.resolve("success");
        }
      }
    });
    preview.setInitData({
      menuId : this.dewself.menu.id,
      docuData : JSON.stringify(slip),
      mainTitle : this.dewself.menu.name,
    });
    preview.open();
    return dfd.promise();
  };

  AccountReceivableBulider.prototype.saveRepayment = function(slip) { 
    var isSuccess = false;
    var that = this;
    
    dews.api.post(dews.url.getApiUrl("FI", "AccountReceivableService", "saveRepayment"), {
      async : false,
      data : {
        collectionsRows : JSON.stringify(this.dewself.grid.getCheckedRows()),
        strFiDocuMstList : slip
      }
    }).done(function(){
      dews.ui.snackbar.ok(dews.localize.get("수금처리가 완료되었습니다.", "M0019802", '', 'FI_COMDIC'));
      isSuccess = true;
    }).fail(function(xhr, status, error) {
      dews.ui.snackbar.error(error);
      that.arGrid.dataSource.data([]);
      that.dewself.grid.dataSource.data([]);
    });
    return isSuccess;
  };

  AccountReceivableBulider.prototype.getSlipRows = function() {
    var field = this.getField("SDOCU_NO");
    return this.dewself.grid.getCheckedRows().filter(function(row){
      if(row[field]) {
        return row;
      }
    });
  };

  AccountReceivableBulider.prototype.hasSlip = function(rows) {
    var field = this.getField("SDOCU_NO");
    return rows.some(function(row){
      if(row[field]) {
        return true;
      }
    });
  };

  AccountReceivableBulider.prototype.setCellStyle = function(grid, field, styles) {
    grid._grid.setColumnProperty(
      grid._grid.columnByField(field),
      "dynamicStyles", 
      function(grid, index) {
        return styles;
      }
    );
  };

  AccountReceivableBulider.prototype.getFindIndex = function(docu_no) {
    return this.arGrid.dataItems().findIndex(function(row) {
      if(row.DOCU_NO === docu_no) {
          return true;
      }
    });
  };

  AccountReceivableBulider.prototype.activeRequiredCollection = function(index, isHeaderClicked, isActive) {
    var that = this;

    var rows;
    if(isHeaderClicked) {
      rows = that.arGrid.dataItems();
    } else {
      if(!$.isArray(index)) {
        rows = [that.arGrid.dataItems(index)];
      } else {
        rows = that.arGrid.dataItems(index);
      }
    }

    rows.forEach(function(row){
      var index = that.getFindIndex(row.DOCU_NO);

      if(isActive) {
        that.arGrid.setCellStyle(index, "IN_EX_AMT", { background : "#fef4f4" });
      } else {
        that.arGrid.setCellStyle(index, "IN_EX_AMT", { background : "#ffffffff" });
      }
    });
  };

  //반제 완료여부 검사
  AccountReceivableBulider.prototype.isRepayment = function() {
    var REPAYMENT_CODE = "2";

    return this.arGrid.getCheckedRows().some(function(value){
      return value.BAN_ST_CD == REPAYMENT_CODE;
    });
  }

  AccountReceivableBulider.prototype.invokeRepayment = function(callback) {};
  AccountReceivableBulider.prototype.revokeRepayment = function(callback) {};

  function AccountReceivableWorker(dewself) {
    AccountReceivableBulider.call(this, dewself);
  }

  AccountReceivableWorker.prototype = Object.create(AccountReceivableBulider.prototype);
  AccountReceivableWorker.constructor = AccountReceivableWorker;

  AccountReceivableWorker.prototype.invokeRepayment = function(callback){
    var that = this;
    try {
      var gridCheckRows = this.dewself.grid.getCheckedRows();

      if(this.hasSlip(gridCheckRows)) {
        throw dews.localize.get("수금정보에 수금처리된 데이터가 존재합니다.", "M0019794", '', 'FI_COMDIC');
      } else if(this.isRepayment()) {
        throw dews.localize.get("반제정보에 반제완료 데이터가 존재합니다.", "M0019803", '', 'FI_COMDIC');
      } else if(gridCheckRows.length == 0) {
        throw dews.localize.get("수금정보에 선택된 데이터가 없습니다.", "M0019793", '', 'FI_COMDIC');
      } else if(this.arGrid.getCheckedRows().length == 0) {
        throw dews.localize.get("반제정보에 선택된 데이터가 없습니다.", "M0019796", '', 'FI_COMDIC');
      } else if(this.dewself.REPAYMENT_EX_AMT_V.value() == 0 && this.dewself.REPAYMENT_AMT_V.value() == 0) {
        throw dews.localize.get("계산 처리를 하지 않았습니다.", "M0019804", '', 'FI_COMDIC');
      } else if(this.dewself.DIFF_AMT_V.value() != 0 && !this.dewself.DIFF_ACCT_CD_P.code()) {
        throw dews.localize.get("입금 차액이 존재하여 선수금 계정을 선택해야합니다.", "M0019805", '', 'FI_COMDIC');
      } else {
        var slip = this.getRepaymentSlip();
        if(slip) {
          this.openPreview(slip).done(function(success){
            callback(success);
            that.arGrid.dataSource.data([]);
          }).fail(function(fail){
            callback(fail);
          });
        }
      }
    } catch (error) {
      dews.alert(error, "warning");
    }
  };

  AccountReceivableWorker.prototype.revokeRepayment = function(callback) {
    try {
      var slipRows = this.getSlipRows();

      if(slipRows.length == 0) {
        throw dews.localize.get("취소할 미결 전표 데이터가 없습니다.", "M0019806", '', 'FI_COMDIC');
      } else {
        var that = this;
        
        var confirm = dews.confirm(dews.localize.get("전표취소 하시겠습니까?", 'M0001581', '', 'FI_COMDIC'), "ico2").yes(function(aaa) {
          var pc_cd_field = that.getField("PC_CD");
          var docu_no_field = that.getField("SDOCU_NO");

          dews.api.post(dews.url.getApiUrl("FI", "AccountReceivableService", "revokeRepayment"), {
            async : false,
            data : {
              pc_cd : slipRows[0][pc_cd_field],
              docus_no : JSON.stringify(slipRows.map(function(row){ return row[docu_no_field]; }))
            }
          }).done(function(){
            dews.ui.snackbar.ok(dews.localize.get("취소가 완료되었습니다.", "M0001776", '', 'FI_COMDIC'));
          }).fail(function(xhr, status, error) {
            dews.ui.snackbar.error(error);
          });
        }).no(function(){
          dews.ui.snackbar.ok(dews.localize.get("취소되었습니다.", "M0000030", '', 'FI_COMDIC'));
        });

        confirm.promise().done(function(aa){
          callback("success");
        }).fail(function(){
          callback("fail");
        });
      }
    } catch (error) {
      dews.alert(error, "warning");
    }
  };

  console.log('## FI AR Module Script Loaded!!! ##');

  //////// 작성 영역 - 끝 ////////

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.ar.js