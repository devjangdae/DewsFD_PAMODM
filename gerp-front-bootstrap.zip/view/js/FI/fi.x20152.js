(function(dews, gerp, $) {
    
  // 버튼추가
  if(dews.ui.page.$content.find("#btneCMS").length == 0){
    dews.ui.page.$content.find(".dews-button-group").eq(0).prepend(
      '<button id="btneCMS" class="dews-ui-button">eCMS 전송</button>'
    )
    // 버튼 초기화
    dews.ui.page.btneCMS = dews.ui.button(dews.ui.page.$content.find("#btneCMS"));
    dews.ui.page.btneCMS.on("click", function(){

      if (dews.ui.page.validateForm.validate({tooltip: true, message: dews.localize.get("필수항목은 입력하세요.", 'M0000918')})) {
        
        if(dews.ui.page.pc_cd.codes().length > 1) {
          dews.alert("eCMS 전송시에는 멀티 회계단위 선택이 불가합니다.\r1개 회계단위 선택 후 클릭 바랍니다.","warning");
          return;
        }

        dews.ui.loading.show({
          type : "tiny",
          text : "eCMS 전송할 데이터를 조회 중 입니다."
        });

        var acct_lv = dews.ui.page.cd_level.dataSource.options.data[dews.ui.page.cd_level.dataSource.options.data.length - 1].SYSDEF_CD;        
        dews.api.get(dews.url.getApiUrl('FI', 'GeneralLedgerDocumentFSMService', 'gldfsm00100_send_eCMS'), {
          async : true,
          data  : {
            pc_cd       : dews.ui.page.pc_cd.codes().join("|"),
            dt_standard : dews.ui.page.dt_standard.value(),
            fsform_cd   : dews.ui.page.fsform_cd.value(),
            gaap_cd     : dews.ui.page.gaap_cd.value(),
            acct_lv     : /*dews.ui.page.cd_level.value(),*/ acct_lv,
            monthsum_yn : dews.ui.page.cd_month.value(),
            zero_ex     : dews.ui.page.EMPTY_CD.value() == "1" ? "Y" : "N",
            unit        : dews.ui.page.s_unit.value()
          }
        }).done(function(data) {
          dews.alert("eCMS 전송을 완료하였습니다.","success");
        }).fail(function (xhr, status, error) {
          dews.error(error);
        }).always(function() {
          dews.ui.loading.hide();
        });
      }        
    });    
  }


})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.x20152.js
