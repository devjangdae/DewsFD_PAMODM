﻿(function(dews, gerp, $) {
  var module = {};
  var moduleCode = 'FI';

  module = (function() {
    return {  
      Glddoc00300GroupWareStore : function(dewself, config) {
        var store = new Map();
        var properties = {
          package : {
            desc : "package",
            URL_TYPE : "",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300_X10033"
          },
          10017 : {
            desc : "프레시지",
            URL_TYPE : "x10017",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300_X10017",
            getFixContents : function() {
              var contents;
              $.ajax({
                type : "GET",
                url : "/view/FI/GLDDOC00300_FIXED_FORM",
                async : false,
                success : function(data) {
                  contents = data;
                }
              });
              return contents;
            }
          },
          10029 : {
            desc : "벽산",
            URL_TYPE : "x10029",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300_X10029"
          },
          10033 : {
            desc : "유라클",
            URL_TYPE : "x10033",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300_X10033"
          },
          10035 : {
            desc : "엘케이마끼다총판",
            URL_TYPE : "x10035",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10035"
          },
          10043 : {
            desc : "데브시스터즈(주)",
            URL_TYPE : "x10043",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10043"
          },
          10080 : {
            desc : "더마펌",
            URL_TYPE : "x10080",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10080"
          },
          10090 : {
            desc : "오픈엣지테크놀로지(주)",
            URL_TYPE : "x10090",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10090"
          },
          10091 : {
            desc : "삼광의료재단",
            URL_TYPE : "x10091",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10091"
          },
          10093 : {
            desc : "타이어픽",
            URL_TYPE : "x10093",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10093"
          },
          10096 : {
            desc : "인카금융서비스(주)",
            URL_TYPE : "x10096",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10096"
          },
          10098 : {
            desc : "(주)가영세라믹스",
            URL_TYPE : "x10098",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10098"
          },
          20059 : {
            desc : "에스와이씨",
            URL_TYPE : "x20059",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20059"
          },
          10114 : {
            desc : "에스케이핀크스(주)",
            URL_TYPE : "x10114",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10114",
            openView : function(url, data) {
              var title = dewself.grid.getCellValue(dewself.grid.select(),'CNSUL_DC')
                gerp.CM.EltrAthzUtil.createEltrAthz(url, {
                  params : {
                    compSeq : dewself.user.companyCode
                    ,approKey : data.athz_rpts_cd
                    ,outProcessCode : this.GW_PROC_CD
                    ,formId : this.FORM_ID
                    ,mod : data.mode
                    ,contentsType : "inner"
                    ,contentsStr : ""
                    ,title : title != null?title.replaceAll('%','％'):""
                    ,contentsEnc : "U"
                    ,loginId : data.loginId
                    ,widthYn : true
                  },
                close : function() {
                  dews.ui.mainbuttons.search.click();
                }
              });
            }
          },
          20124 : {
            desc : "옵투스제약",
            URL_TYPE : "x20124",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20124",
            openView : function(url, data) {
              var abdocuNo = dewself.grid.getCellValue(dewself.grid.select(),'ABDOCU_NO');
              var cnsulDc = dewself.grid.getCellValue(dewself.grid.select(),'CNSUL_DC');
              cnsulDc = cnsulDc != null?cnsulDc.replaceAll('%','％'):"";
              var title = "["+abdocuNo+"] " + cnsulDc;
                gerp.CM.EltrAthzUtil.createEltrAthz(url, {
                  params : {
                    compSeq : dewself.user.companyCode
                    ,approKey : data.athz_rpts_cd
                    ,outProcessCode : this.GW_PROC_CD
                    ,formId : this.FORM_ID
                    ,mod : data.mode
                    ,contentsType : "inner"
                    ,contentsStr : ""
                    ,title : title
                    ,contentsEnc : "U"
                    ,loginId : data.loginId
                    ,widthYn : true
                  },
                close : function() {
                  dews.ui.mainbuttons.search.click();
                }
              });
            }
          },
          10124 : {
            desc : "(주)금영이엔지",
            URL_TYPE : "x10124",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10124"
          },
          10132 : {
            desc : "(주)하이라이트브랜즈",
            URL_TYPE : "x10132",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10132"
          },
          10134 : {
            desc : "주식회사 씨메스",
            URL_TYPE : "x10134",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10134"
          },
          10140 : {
            desc : "(주)쓰리빌리언",
            URL_TYPE : "x10140",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x10140"
          },
          20008 : {
            desc : "(주)아그루코리아",
            URL_TYPE : "x20008",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20008"
          },
          20009 : {
            desc : "비전세미콘(주)",
            URL_TYPE : "x20009",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20009"
          },
          20017 : {
            desc : "스파클(주)",
            URL_TYPE : "x20017",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20017"
          },
          20038 : {
            desc : "(주)데코뷰",
            URL_TYPE : "x20038",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20038"
          },
          20050 : {
            desc : "셀피글로벌",
            URL_TYPE : "x20050",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20050"
          },
          20056 : {
            desc : "(주)신한금융플러스",
            URL_TYPE : "x20056",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20056"
          },
          20064 : {
            desc : "주식회사 지평주조",
            URL_TYPE : "x20064",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20064"
          },
          20069 : {
            desc : "(주)창조종합건축사사무소",
            URL_TYPE : "x20069",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20069",
            FILE_USE_YN :'Y'
          },
          20081 : {
            desc : "(주)사피온코리아",
            URL_TYPE : "x20081",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20081"
          },
          20087 : {
            desc : "(주)넥서스커뮤니티",
            URL_TYPE : "x20087",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20087"
          },
          20091 : {
            desc : "브이피주식회사",
            URL_TYPE : "x20091",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20091",
            openView : function(url, data) {
              var titleData = dewself.grid.dataItem(dewself.grid.select())
                gerp.CM.EltrAthzUtil.createEltrAthz(url, {
                  params : {
                    compSeq : dewself.user.companyCode
                    ,approKey : data.athz_rpts_cd
                    ,outProcessCode : this.GW_PROC_CD
                    ,formId : this.FORM_ID
                    ,mod : data.mode
                    ,contentsType : "inner"
                    ,contentsStr : ""
                    ,title : dewself.s_abdocu_fg_cd.dataSource.data().filter(function(flagItem){return titleData.ABDOCU_FG_CD== flagItem.SYSDEF_CD})[0].SYSDEF_NM +"-"+titleData.CNSUL_DC+"-"+titleData.WRT_EMP_NM
                    ,contentsEnc : "U"
                    ,loginId : data.loginId
                    ,widthYn : true
                  },
                close : function() {
                  dews.ui.mainbuttons.search.click();
                }
              });
            }
          },
          20014 : {
            desc : "(주)유피케미칼",
            URL_TYPE : "x20014",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20014"
          },
          20015 : {
            desc : "주식회사 엠티어",
            URL_TYPE : "x20015",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20015"
          },
          20155 : {
            desc : "한화라이프랩(주)",
            URL_TYPE : "x20155",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20155"
          },
          20116 : {
            desc : "(주)피씨디렉트",
            URL_TYPE : "x20116",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20116",
            openView : function(url, data) {
              var title = dewself.grid.getCellValue(dewself.grid.select(),'CNSUL_DC')
                gerp.CM.EltrAthzUtil.createEltrAthz(url, {
                  params : {
                    compSeq : dewself.user.companyCode
                    ,approKey : data.athz_rpts_cd
                    ,outProcessCode : this.GW_PROC_CD
                    ,formId : this.FORM_ID
                    ,mod : data.mode
                    ,contentsType : "inner"
                    ,contentsStr : ""
                    ,title : title != null?title.replaceAll('%','％'):""
                    ,contentsEnc : "U"
                    ,loginId : data.loginId
                    ,widthYn : true
                  },
                close : function() {
                  dews.ui.mainbuttons.search.click();
                }
              });
            }
          },
          20085 : {
            desc : " 코니카미놀타프로프린트솔루션스코리아 주식회사",
            URL_TYPE : "x20085",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20085"
          },
          20089 : {
            desc : " 코츠테크놀로지",
            URL_TYPE : "x20089",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20089",
            openView : function(url, data) {
              var title = dewself.grid.getCellValue(dewself.grid.select(),'CNSUL_DC')
                gerp.CM.EltrAthzUtil.createEltrAthz(url, {
                  params : {
                    compSeq : dewself.user.companyCode
                    ,approKey : data.athz_rpts_cd
                    ,outProcessCode : this.GW_PROC_CD
                    ,formId : this.FORM_ID
                    ,mod : data.mode
                    ,contentsType : "outer"
                    ,title : title != null?title.replaceAll('%','％'):""
                    ,contentsEnc : "U"
                    ,loginId : data.loginId
                    ,widthYn : true
                  },
                close : function() {
                  dews.ui.mainbuttons.search.click();
                }
              });
            }
          },
          20096 : {
            desc : "피에스텍(주)",
            URL_TYPE : "x20096",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20096",
            openView : function(url, data) {
              var title = dewself.grid.getCellValue(dewself.grid.select(),'CNSUL_DC')
                gerp.CM.EltrAthzUtil.createEltrAthz(url, {
                  params : {
                    compSeq : dewself.user.companyCode
                    ,approKey : data.athz_rpts_cd
                    ,outProcessCode : this.GW_PROC_CD
                    ,formId : this.FORM_ID
                    ,mod : data.mode
                    ,contentsType : "outer"
                    ,title : title != null?title.replaceAll('%','％'):""
                    ,contentsEnc : "U"
                    ,loginId : data.loginId
                    ,widthYn : true
                  },
                close : function() {
                  dews.ui.mainbuttons.search.click();
                }
              });
            }
          },
          20099 : {
            desc : "휴마시스(주)",
            URL_TYPE : "x20099",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20099",
            openView : function(url, data) {
              var cnsul_dc = dewself.grid.getCellValue(dewself.grid.select(),'CNSUL_DC') ? dewself.grid.getCellValue(dewself.grid.select(),'CNSUL_DC') : "";
              var abdocu_no = dewself.grid.getCellValue(dewself.grid.select(),'ABDOCU_NO');
                gerp.CM.EltrAthzUtil.createEltrAthz(url, {
                  params : {
                    compSeq : dewself.user.companyCode
                    ,approKey : data.athz_rpts_cd
                    ,outProcessCode : this.GW_PROC_CD
                    ,formId : this.FORM_ID
                    ,mod : data.mode
                    ,contentsType : "outer"
                    ,contentsStr : ""
                    ,title : "[" + abdocu_no + "] " + cnsul_dc
                    ,contentsEnc : "U"
                    ,loginId : data.loginId
                    ,widthYn : true
                  },
                close : function() {
                  dews.ui.mainbuttons.search.click();
                }
              });
            }
          },
          20118 : {
            desc : "(주)지아이이노베이션",
            URL_TYPE : "x20118",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20118"
          },
          20175 : {
            desc : "유니코로지스틱스(주)",
            URL_TYPE : "x20175",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20175"
          },
          20160 : {
            desc : "우수정기(주)",
            URL_TYPE : "x20160",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20160"
          },
          20075 : {
            desc : "(주)티맥스소프트",
            URL_TYPE : "x20075",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "amaranth",
            GROUPSEQ:"gcmsAmaranth32922",
            SERVICE_NAME : "Glddoc00300Service_x20075",
            FILE_USE_YN :'Y'
          },
          amaranth : {
            desc : "portal",
            URL_TYPE : "amaranth",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "amaranth",
            SERVICE_NAME : "Glddoc00300Service_amaranth",
            GROUPSEQ:"",
            LOGINID:"",
            FILE_USE_YN :''
          },
          20176 : {
            desc : "주식회사 라인건설",
            URL_TYPE : "x20176",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "amaranth",
            GROUPSEQ : "",
            SERVICE_NAME : "Glddoc00300Service_x20176",
            FILE_USE_YN : ''
          },
          20211 : {
            desc : "연합인포맥스",
            URL_TYPE : "x20211",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "bizbox",
            SERVICE_NAME : "Glddoc00300Service_x20211"
          },
          20187 : {
            desc : "(주)아닉스",
            URL_TYPE : "x20187",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "amaranth",
            GROUPSEQ : "",
            SERVICE_NAME : "Glddoc00300Service_x20187",
            FILE_USE_YN : ''
          },
          'dev' : {
            desc : "(주)티맥스소프트",
            URL_TYPE : "x20176",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "amaranth",
            GROUPSEQ:"",
            SERVICE_NAME : "Glddoc00300Service_x20176",
            FILE_USE_YN :'Y'
          },      
          10012 : {
            desc : "JB",
            URL_TYPE : "common",
            FORM_ID : "jbfgbudget001",
            //SPECS : "width=800,height=600,",
            provider : "external",
            SERVICE_NAME : "Glddoc00300_X10012",
            getMeetingFileKeys : function(pc_cd, abdocu_no) {
              var fileKeys = [];
              dews.api.get(dews.url.getApiUrl('FI', 'Glddoc00300_X10012', 'createFileKeys'), {
                async : false,
                data : {
                  pc_cd : pc_cd,
                  abdocu_no : abdocu_no
                }
              }).done(function (data) {
                if(data.length > 0) {
                  fileKeys = data;
                }
              }).fail(function(xhr, status, error) {
                dews.ui.snackbar.error(error);
              });
              return fileKeys;
            },
            downloadMeetingFiles : function() {
              var row = grid.dataItems(grid.select());
              if(!row.ABDOCU_NO) {
                return;
              }
              var fileKeys = this.getMeetingFileKeys(row.PC_CD, row.ABDOCU_NO);
              fileKeys.forEach(function(key, index) {
                var token = gerp.FI.getAuthToken();
                var url = dews.string.format("/download/file?token={0}&key={1}&filename={2}", token, key, dews.localize.get("회의록", 'D0028809')+(index+1)+".xlsx");
                var $frame;
                if(dewself.$content.find("#frmDownLoad").length > 0){
                  $frame = dewself.$content.find("#frmDownLoad");
                } else{
                  $frame = $('<iframe id="frmDownLoad" style="display: none; width: 0; height: 0;"></iframe>');
                  dewself.$content.find(".dews-button-group").append($frame)
                }
                $frame.prop('src', url);
              });
            },
            openView : function(url, data) {
              var empCode = dewself.user.empCode;
              if (dewself.user.empCode == "RPA001") {
                empCode = dewself.s_no_emp_write.code() == "" ? dewself.user.empCode : dewself.s_no_emp_write.code();
              }
              url = dews.string.format("{0}?formAlias={1}&sabun={2}&viewMode=NEW&legacyKey={3}", url, this.FORM_ID, empCode, data.athz_rpts_cd);

              gerp.CM.EltrAthzUtil.createEltrAthz_x10034(url, "_blank", "width=800,height=600");
              //window.open(url, "_blank", this.SPECS);
            }
          },
          10034 : {
            desc : "KC",
            URL_TYPE : "common",
            URL : "https://kct.kcmaterials.kr",
            APPROVAL_URI : "/ekp/view/openapi/IF_EAP_ERP_LINK",
            VIEW_URI : "/ekp/view/openapi/IF_EAP_ERP_VIEW",
            FORM_ID : "KC-FC-001",
            provider : "external",
            SERVICE_NAME : "Glddoc00300Service_x10034",
            getInterlockCode : function() {
              if(config.codeDetail.MA.Z005_10034.data && config.codeDetail.MA.Z005_10034.data.length > 0) {
                var interlock = config.codeDetail.MA.Z005_10034.data.find(function(value) {
                  return value.SYSDEF_CD === dewself.user.companyCode;
                });
                return interlock && interlock.SYSDEF_NM || "C100190326";
              }
              return "C100190326";
            },
            openView : function(url, data) {
              var interlockCode = this.getInterlockCode();
              var viewName = "GLDDOC00300";

              if(data.mode == "W") {
                url = url + this.APPROVAL_URI + private.toQueryString({
                  CMP_ID : interlockCode,
                  empno : dewself.user.empCode,
                  interformno : this.FORM_ID,
                  athz_rpts_cd : data.athz_rpts_cd
                });
                viewName = "GLDDOC00300_APPROVAL";
              } else if(data.mode == "V") {
                url = url + this.VIEW_URI + private.toQueryString({
                  CMP_ID : interlockCode,
                  USER_ID : dewself.user.empCode,
                  APP_ID : data.gwDocuNo
                });
                viewName = "GLDDOC00300_VIEW";
              }
              gerp.CM.EltrAthzUtil.createEltrAthz_x10034(url, viewName, "width=981,height=769");
              //window.open(url, viewName, "width=981,height=769");
            }
          },
          10131 : {
            desc : "롯데미래전략연구소(주)",
            URL_TYPE : "x10131",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "external",
            URL : "https://ewf.lotte.net/external/dbapproval.asmx",
            SERVICE_NAME : "Glddoc00300Service_x10131",
            openView : function(url, data) {
              var moinData = JSON.parse(data.saveResult);
              var openUrl = moinData.httpResponseUrl;
              var width = 981;
              var height = 769;
              var eltrAthzPopup = window.open(openUrl,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                setTimeout(function () {
                  dews.ui.loading.show({
                    text: '전자결재 진행 중입니다.'
                  })
                });

                var popupTick = setInterval(function() {
                  if (eltrAthzPopup.closed) {
                    clearInterval(popupTick);
                    dews.ui.loading.hide();
                    dews.ui.mainbuttons.search.click();
                  }
                }, 500);
            }
          },
          20159 : {
            desc : "롯데헬스케어(주)",
            URL_TYPE : "x20159",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "external",
            URL : "https://ewf.lotte.net/external/dbapproval.asmx",
            SERVICE_NAME : "Glddoc00300Service_x20159",
            openView : function(url, data) {
              var moinData;
              if(data.mode == "W"){
                moinData = JSON.parse(data.saveResult);
              }else{
                var mstData = dewself.grid.dataItem(dewself.grid.select());
                dews.api.post(dews.url.getApiUrl("FI", this.SERVICE_NAME, "loadApproval"), {
                  async: false,
                  data: {
                    pc_cd: mstData.PC_CD,
                    abdocu_no: mstData.ABDOCU_NO,
                    athz_rpts_cd: data.athz_rpts_cd,
                    gwdocu_no: data.gwDocuNo
                  }
                }).done(function (urlData) {
                  if(data){
                    moinData = JSON.parse(urlData);
                  }
                }).fail(function (xhr, status, error) {
                  dews.ui.snackbar.error(error);
                })
              }
              if(moinData){

                var openUrl = moinData.httpResponseUrl;
                var width = 981;
                var height = 769;
                var eltrAthzPopup = window.open(openUrl,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                  setTimeout(function () {
                    dews.ui.loading.show({
                      text: '전자결재 진행 중입니다.'
                    })
                  });

                  var popupTick = setInterval(function() {
                    if (eltrAthzPopup.closed) {
                      clearInterval(popupTick);
                      dews.ui.loading.hide();
                      dews.ui.mainbuttons.search.click();
                    }
                  }, 500);

              }else{
                dews.ui.snackbar.error("URL 정보를 가져올수 없습니다.");
              }
            }
          },
          20173 : {
            desc : "롯데에이엠씨(주)",
            URL_TYPE : "x20173",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "external",
            URL : "https://ewf.lotte.net/external/dbapproval.asmx",
            SERVICE_NAME : "Glddoc00300Service_x20173",
            openView : function(url, data) {
              var moinData = JSON.parse(data.saveResult);
              var openUrl = moinData.httpResponseUrl;
              var width = 981;
              var height = 769;
              var eltrAthzPopup = window.open(openUrl,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                setTimeout(function () {
                  dews.ui.loading.show({
                    text: '전자결재 진행 중입니다.'
                  })
                });

                var popupTick = setInterval(function() {
                  if (eltrAthzPopup.closed) {
                    clearInterval(popupTick);
                    dews.ui.loading.hide();
                    dews.ui.mainbuttons.search.click();
                  }
                }, 500);
            }
          },
          20054 : {
            desc : "(주)자이언트스텝",
            URL_TYPE : "x20054",
            FORM_ID : "FI01",
            GW_PROC_CD : "",
            provider : "external",
            URL:"https://portal.giantstepcorp.com/common/sso?companyId=10&gosso=",
            APPROVAL_URI : "/app/approval/giantstep/ppcr",
            VIEW_URI : "/app/approval/document",
            SERVICE_NAME : "Glddoc00300Service_x20054",
            openView : function(url, data) {
              url = this.URL;
              dews.api.get(dews.url.getApiUrl("FI", "Glddoc00300Service_x20054", "getAes_encode"), {
                  async : false,
                }).done(function (aes_encode) {
                  url += aes_encode;
                })
                if(data.mode == "W") {
                  url = url + "&url=" + encodeURIComponent(this.APPROVAL_URI +"?"+ private.toQueryString({form_id : this.FORM_ID,athz_rpts_cd : data.athz_rpts_cd}));
                } else if(data.mode == "V") {
                  url = url + "&url=" + encodeURIComponent(this.VIEW_URI +"/"+ data.gwDocuNo)
                }
                var width = 981;
                var height = 769;
                var eltrAthzPopup = window.open(url,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                  setTimeout(function () {
                    dews.ui.loading.show({
                      text: '전자결재 진행 중입니다.'
                    })
                  });

                  var popupTick = setInterval(function() {
                    if (eltrAthzPopup.closed) {
                      clearInterval(popupTick);
                      dews.ui.loading.hide();
                      dews.ui.mainbuttons.search.click();
                    }
                  }, 500);
            }
          },
          20086 : {
            desc : "(주)한살림사업연합",
            URL_TYPE : "x20086",
            FORM_ID : "",
            GW_PROC_CD : "",
            provider : "external",
            URL:"https://portal.hansalim.or.kr/common/sso?companyId=10&gosso=",
            APPROVAL_URI : "/app/approval/integration/erp",
            VIEW_URI : "/app/approval/document",
            SERVICE_NAME : "Glddoc00300Service_x20086",
            openView : function(url, data) {
              var titleData = dewself.grid.dataItem(dewself.grid.select())
              url = this.URL;
              var ssoYn = true;
              dews.api.get(dews.url.getApiUrl("FI", "Glddoc00300Service_x20086", "getAes_encode"), {
                  async : false,
                }).done(function (aes_encode) {
                  url += aes_encode;
                }).fail(function (xhr, status, error) {
                  ssoYn = false;
                  dews.ui.snackbar.error(error);
                })
                if(ssoYn){

                  if(data.mode == "W") {
                    if(titleData.ABDOCU_FG_CD == "30"){
                      this.FORM_ID = "NEWAR";
                    }else if(titleData.ABDOCU_FG_CD == "11"){
                      this.FORM_ID = "NEWSR";
                    }
                    url = url + "&url=" + encodeURIComponent(this.APPROVAL_URI +"?"+ private.toQueryString({
                      formSerial : this.FORM_ID,
                      EXPD_RSLU_NO : titleData.COMPANY_CD +"-"+titleData.PC_CD+"-"+titleData.ABDOCU_NO,
                      ATHZ_RPTS_CD : data.athz_rpts_cd
                    }));
                  } else if(data.mode == "V") {
                    url = url + "&url=" + encodeURIComponent(this.VIEW_URI +"/"+ data.gwDocuNo)
                  }
                  var width = 981;
                  var height = 769;
                  var eltrAthzPopup = window.open(url,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                    setTimeout(function () {
                      dews.ui.loading.show({
                        text: '전자결재 진행 중입니다.'
                      })
                    });

                    var popupTick = setInterval(function() {
                      if (eltrAthzPopup.closed) {
                        clearInterval(popupTick);
                        dews.ui.loading.hide();
                        dews.ui.mainbuttons.search.click();
                      }
                    }, 500);
                }
            }
          },
          20123 : {
            desc : "㈜베베쿡",
            URL_TYPE : "x20123",
            FORM_ID : "10",
            GW_PROC_CD : "",
            provider : "external",
            URL:"http://alvins.bebecook.com/common/sso?companyId=10&gosso=", // 도메인 수정 대기
            APPROVAL_URI : "/app/approval/integration/erp10", // url 수정 대기
            VIEW_URI : "/app/approval/document", // url 수정 대기
            SERVICE_NAME : "Glddoc00300Service_x20123",
            openView : function(url, data) {
              dews.api.get(dews.url.getApiUrl("FI", "Glddoc00300Service_x20123", "getAes_encode"), {
                  async : false,
                }).done(function (aes_encode) {
                  url += aes_encode;
                })

              if(data.mode == "W") {
                url = url + "&url=" +  encodeURIComponent(this.APPROVAL_URI +"?"+ private.toQueryString({
                  form_id : this.FORM_ID,
                  athz_rpts_cd  : data.athz_rpts_cd,

                }));
              } else if(data.mode == "V") {
                url = url + "&url=" +  encodeURIComponent(this.VIEW_URI +"/"+ data.gwDocuNo)
              }
              var width = 981;
              var height = 769;
              var eltrAthzPopup = window.open(url,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                setTimeout(function () {
                  dews.ui.loading.show({
                    text: '전자결재 진행 중입니다.'
                  })
                });

                var popupTick = setInterval(function() {
                  if (eltrAthzPopup.closed) {
                    clearInterval(popupTick);
                    dews.ui.loading.hide();
                    dews.ui.mainbuttons.search.click();
                  }
                }, 500);
              }
          },
          20129 : {
            desc : "(주)다담리테일",
            URL_TYPE : "x20129",
            FORM_ID : "form001",
            GW_PROC_CD : "",
            provider : "external",
            URL:"http://portal.umac.co.kr/app/approval",
            APPROVAL_URI : "/dz/slip",
            VIEW_URI : "/document",
            SERVICE_NAME : "Glddoc00300Service_x20129",
            openView : function(url, data) {
              var titleData = dewself.grid.dataItem(dewself.grid.select())

              if(titleData.COMPANY_CD == '1000'){
                this.FORM_ID = 'form001';
              }else if(titleData.COMPANY_CD == '2000'){
                this.FORM_ID = 'form002';
              }else if(titleData.COMPANY_CD == '3000'){
                this.FORM_ID = 'form003';
              }else if(titleData.COMPANY_CD == '4000'){
                this.FORM_ID = 'form004';
              }

              if(data.mode == "W") {
                url = url + this.APPROVAL_URI +"?"+ private.toQueryString({
                  formCode : this.FORM_ID,
                  dataId  : data.athz_rpts_cd,
                  title:(titleData.ABDOCU_FG_CD == "11"?"[지출결의서] ":"[수입결의서] ")+(titleData.CNSUL_DC != null ?titleData.CNSUL_DC:"")
                });
              } else if(data.mode == "V") {
                url = url + this.VIEW_URI +'/'+data.gwDocuNo
              }
              var width = 981;
              var height = 769;
              var eltrAthzPopup = window.open(url,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                setTimeout(function () {
                  dews.ui.loading.show({
                    text: '전자결재 진행 중입니다.'
                  })
                });

                var popupTick = setInterval(function() {
                  if (eltrAthzPopup.closed) {
                    clearInterval(popupTick);
                    dews.ui.loading.hide();
                    dews.ui.mainbuttons.search.click();
                  }
                }, 500);
              }
          },
          20154 : {
            desc : "대영채비(주)",
            URL_TYPE : "x20154",
            FORM_ID : "form001",
            GW_PROC_CD : "",
            provider : "external",
            URL:"http://ngw.chaevi.co.kr/common/sso?companyId=10&gosso=",
            APPROVAL_URI : "/app/approval/dz/erp",
            VIEW_URI : "/app/approval/document",
            SERVICE_NAME : "Glddoc00300Service_x20154",
            openView : function(url, data) {
              dews.api.get(dews.url.getApiUrl("FI", "Glddoc00300Service_x20154", "getAes_encode"), {
                  async : false,
                }).done(function (aes_encode) {
                  url += aes_encode;
                })
              // var titleData = dewself.grid.dataItem(dewself.grid.select())
              if(data.mode == "W") {
                url = url +"&url=" + encodeURIComponent(this.APPROVAL_URI +"?"+ private.toQueryString({
                  formCode : this.FORM_ID,
                  dataId  : data.athz_rpts_cd,
                  // title:(titleData.CNSUL_DC != null ?titleData.CNSUL_DC:"")
                }));
              } else if(data.mode == "V") {
                url = url + "&url=" + encodeURIComponent(this.VIEW_URI +"/"+ data.gwDocuNo)
              }
              var width = 981;
              var height = 769;
              var eltrAthzPopup = window.open(url,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                setTimeout(function () {
                  dews.ui.loading.show({
                    text: '전자결재 진행 중입니다.'
                  })
                });

                var popupTick = setInterval(function() {
                  if (eltrAthzPopup.closed) {
                    clearInterval(popupTick);
                    dews.ui.loading.hide();
                    dews.ui.mainbuttons.search.click();
                  }
                }, 500);
              }
          },
          20165 : {
            desc : "(주)더블유컨셉코리아",
            URL_TYPE : "x20165",
            FORM_ID : "10",
            GW_PROC_CD : "",
            provider : "external",
            URL:"http://gw.wconcept.co.kr",
            APPROVAL_URI : "/app/approval/dz/erp",
            VIEW_URI : "/app/approval/document",
            SERVICE_NAME : "Glddoc00300Service_x20165",
            openView : function(url, data) {
              url = this.URL;

              if(data.mode == "W") {
                url = url + this.APPROVAL_URI +"?"+ private.toQueryString({
                  formCode : this.FORM_ID,
                  dataId  : data.athz_rpts_cd
                });
              } else if(data.mode == "V") {
                url = url + this.VIEW_URI +'/'+data.gwDocuNo
              }
              var width = 981;
              var height = 769;
              var eltrAthzPopup = window.open(url,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                setTimeout(function () {
                  dews.ui.loading.show({
                    text: '전자결재 진행 중입니다.'
                  })
                });

                var popupTick = setInterval(function() {
                  if (eltrAthzPopup.closed) {
                    clearInterval(popupTick);
                    dews.ui.loading.hide();
                    dews.ui.mainbuttons.search.click();
                  }
                }, 500);
              }
          },
          20006 : {
            desc : "(주)한국경제신문",
            URL_TYPE : "x20006",
            FORM_ID : "GLDDOC00300-01",
            GW_PROC_CD : "",
            provider : "external",
            URL:"https://ked.co.kr/",
            APPROVAL_URI : "ezConn/ezApprGate.do",
            VIEW_URI : "ezConn/ezApprGate.do",
            SERVICE_NAME : "Glddoc00300Service_x20006",
            openView : function(url, data) {
              var mstItemGwD = dewself.grid.dataItem(dewself.grid.select());

                if (dewself.user.deptCode == undefined || dewself.user.gEmpCode == undefined) {
                  dews.ui.snackbar.warning(dews.localize.get('사용자 필수 정보가 누락되었습니다.', 'M0021066'));
                  return;
                }

                // if(data.mode == "W") {
                  url = url + this.APPROVAL_URI +"?"+ private.toQueryString({
                    connkey : btoa(mstItemGwD.COMPANY_CD+"|"+ dewself.user.deptCode +"|"+ dewself.user.gEmpCode +"|"+data.athz_rpts_cd+"|"+this.FORM_ID),
                  });
                  var width = 981;
                  var height = 769;
                  var eltrAthzPopup = window.open(url,"headers=Content-Disposition: attachment;", "eltrAthzPopup", "width=" + width +",height="+height+",scrollbars=yes");
                    setTimeout(function () {
                      dews.ui.loading.show({
                        text: '전자결재 진행 중입니다.'
                      })
                    });

                    var popupTick = setInterval(function() {
                      if (eltrAthzPopup.closed) {
                        clearInterval(popupTick);
                        dews.ui.loading.hide();
                        dews.ui.mainbuttons.search.click();
                      }
                    }, 500);
                // } else if(data.mode == "V") {
                  // url = url + this.VIEW_URI +'/'+data.gwDocuNo
                // }
              }
          },
        };
        var private = {
          setup : function(drsCode) {
            var that = this;
            var propertie = properties[dewself.mainEnv.drsCode] || properties.package;
            if(dewself.mainEnv.drsCode == "10034"){
              if(config.codeDetail.MA.Z005_10034.data && config.codeDetail.MA.Z005_10034.data.length > 0) {
                //URL가져오기
                propertie.URL = config.codeDetail.MA.Z005_10034.data[0].FLAG_CD;
                propertie.APPROVAL_URI = config.codeDetail.MA.Z005_10034.data[0].REL_FLAG_1_CD + "?";
                propertie.VIEW_URI = config.codeDetail.MA.Z005_10034.data[0].REL_FLAG_2_CD + "?"
              }
            }
            var abdocu_fgs = [];
            dews.api.get(dews.url.getApiUrl("FI", "Glddoc00300Service", "getGwFormInfo"), {
                  async : true,
                }).done(function (data) {
                  var gwFormInfo = JSON.parse(data);

                  if(gwFormInfo.controlconfigfi04010
                      && gwFormInfo.controlconfigfi04010[0]
                      && gwFormInfo.controlconfigfi04010[0].CTRL_VR == "4"
                      ){
                        propertie = properties[dewself.mainEnv.drsCode]
                      }
                  // var userCodeUsedDrs =["10080","10080","10090","10091","10096","10132","10043","20064","20014","20015"]
                  gwFormInfo.codeDtlsP10100.forEach(function(item){
                    if(item.SYSDEF_CD == '11'|item.SYSDEF_CD == '15'){
                      abdocu_fgs.push(item.SYSDEF_CD)
                    }else if(
                      // (userCodeUsedDrs.indexOf(dewself.mainEnv.drsCode) != -1) &&
                      item.FLAG_CD == '1'){
                      abdocu_fgs.push(item.SYSDEF_CD)
                    }
                  })
                  abdocu_fgs.forEach(function(abdocu_fg_cd) {
                    var erpFormCode = dewself.menu.id+"-"+abdocu_fg_cd;
                    if(properties[dewself.mainEnv.drsCode] != null){
                      var data = that.extendsAttribute(propertie, erpFormCode,gwFormInfo.GwFormInfo);
                      store.set(abdocu_fg_cd, data);
                    }else{
                      if(propertie.desc == "portal"
                      // && gerp.CM.EltrAthzUtil.getCookieInfo(encodeURIComponent('am10:auth:token')) != undefined
                      ){
                        var data = that.extendsAttribute(propertie, erpFormCode,gwFormInfo.GwFormInfo);
                        store.set(abdocu_fg_cd, data);
                      }
                    }
                  });
                }).fail(function(){

                })
          },
          extendsAttribute : function(propertie, erpFormCode, GwFormInfo) {
            if(propertie.provider == "bizbox"||propertie.provider == "amaranth") {
              if(GwFormInfo != null){
                GwFormInfo.forEach(function(item){
                  if(item.FORM_ID == erpFormCode){
                      propertie = $.extend({}, propertie, {
                        FORM_ID : item.GW_FORM_ID,
                        GW_PROC_CD : item.GW_PROC_CD
                      });
                  }
                })
              }
            }
            return $.extend({}, propertie, {
              getUrl : function(athz_rpts_cd) {
                if(["10034","10131","20054","20006","20129","20154","20173","20159"].indexOf(dewself.mainEnv.drsCode)!=-1) {
                  return propertie.URL;
                }
                var url = gerp.CM.EltrAthzUtil.getApprovalUrl(propertie.URL_TYPE);
                return url;
              },
              getContents : function(params) {
                var contents = "";
                var getcontentsisc = true;
                dews.api.post(dews.url.getApiUrl("FI", propertie.SERVICE_NAME, "content"), {
                  async: false,
                  data: {
                    pc_cd : params.pc_cd,
                    abdocu_no : params.abdocu_no
                  }
                }).done(function (data) {
                  contents = data;
                  if(dewself.mainEnv.drsCode == '20154'){
                    var titleData = dewself.grid.dataItem(dewself.grid.select())
                    contents = JSON.stringify({
                      'title':(titleData.CNSUL_DC != null ?titleData.CNSUL_DC:""),
                      'contents':contents
                    })
                    }
                }).fail(function (xhr, status, error) {
                  getcontentsisc = false;
                  contents = error;
                  dews.ui.mainbuttons.search.click();
                });
                return {contentsText:contents,isc:getcontentsisc};
              },
              sendRequest : function(data) {
                var that = this;
                if(properties[dewself.mainEnv.drsCode] == undefined && propertie.desc != "portal") {
                  dews.ui.snackbar.warning("DRS CODE : " + dewself.mainEnv.drsCode + dews.localize.get("는 정의되지 않은 전용 코드입니다.", 'M0018613'));
                  return false
                }
                var contents = (["10131","20173","20159"].indexOf(dewself.mainEnv.drsCode)==-1)?that.getContents({ pc_cd : data.PC_CD, abdocu_no : data.ABDOCU_NO }):"";

                if(contents.isc){
                  contents = contents.contentsText;
                }else if(["10131","20173","20159"].indexOf(dewself.mainEnv.drsCode)!=-1){

                }else{
                  dews.ui.snackbar.error(contents.contentsText);
                  return false;
                }
                var emp_no = dewself.user.empCode;
                if (dewself.mainEnv.drsCode == "10012") {
                  if (dewself.user.empCode == "RPA001") {
                    emp_no = dewself.s_no_emp_write.code() == "" ? dewself.user.empCode : dewself.s_no_emp_write.code();
                  }
                }

                dews.ui.loading.show({
                  text : dews.localize.get("결재신청 진행중입니다.", 'M0011658')
                });
                var paramFileYn = false;
                  if(dewself.gridDetail.dataItems().length > 600){
                    paramFileYn = true;
                    var xhr = new XMLHttpRequest();
                    var blob = new Blob([JSON.stringify(contents)], { type: "text/plain;charset=utf-8" });
                    var formData = new FormData();
                    formData.append("file", blob);
                    formData.append("isText", "false");
                    formData.append("token", JSON.parse(dews.ui.page.token).access_token);
                    xhr.open("POST", "/upload/file", false);
                    var comp = function (e) {contents = JSON.parse(e.target.response).data.newFilename}
                      xhr.addEventListener("load", comp);
                      xhr.send(formData);
                  }
                return dews.api.post(dews.url.getApiUrl("HR", "GroupWareConnection", "approval"+(paramFileYn?"ContentsFile":"")), {
                    async: false,
                    data: {
                      company_cd: dewself.user.companyCode,
                      module_cd: "FI",
                      //req_emp_no: dewself.user.empCode,
                      req_emp_no: emp_no,
                      gwaprvlst_cd: "1",
                      form_id: propertie.FORM_ID,
                      contents_txt: contents,
                      rmenu_cd: dewself.menu.id,
                      table_nm: "FI_RDOCU_MST",
                      matkey_vr: data.COMPANY_CD + "|" + data.PC_CD + "|" + data.ABDOCU_NO+(dewself.grid.getCellValue(dewself.grid.select()=="5")?"":("|"+private.createUUID())),
                      gwapproval_dt: dews.date.format(new Date(), "yyyyMMdd"),
                      service_url: dews.url.getApiUrl("FI", propertie.SERVICE_NAME, "confirm")
                    }
                  }).fail(function (xhr, status, error) {
                    dews.error(error);
                  }).always(function(){
                    dews.ui.loading.hide();
                  }).then(function(res) {
                    var response = { error : "", success : true};
                    if(res.length > 0 && res[0].error_message) {
                      response.error = res[0].error_message;
                      response.success = false;
                      dews.error(response.error)
                    } else {
                      response.athz_rpts_cd = res[0].data[0].ATHZ_RPTS_CD;
                      response.loginId = res[0].aes_key;
                      response.saveResult = that.saveRequest({ pc_cd : data.PC_CD, abdocu_no : data.ABDOCU_NO, athz_rpts_cd : response.athz_rpts_cd});
                    }
                    return response;
                  });
              },
              saveRequest : function(params) {
                var aprovaldata;
                dews.api.post(dews.url.getApiUrl("FI", propertie.SERVICE_NAME, "approval"), {
                  async: false,
                  data: {
                    pc_cd: params.pc_cd,
                    abdocu_no: params.abdocu_no,
                    athz_rpts_cd: params.athz_rpts_cd
                  }
                }).done(function (data) {
                  aprovaldata = data;
                  if(propertie.provider == "bizbox"){
                    dews.ui.snackbar.info(dews.localize.get("결재신청 되었습니다.", 'M0011612'));
                  }
                }).fail(function (xhr, status, error) {
                  dews.ui.snackbar.error(error);
                })
                return aprovaldata
              },
              openView : function(data){
                var url = this.getUrl(data.athz_rpts_cd);
                if(propertie.provider == "external") {
                  return propertie.openView(url, data);
                } else if(['10114','20089','20091','20096','20116','20099','20124'].indexOf(dewself.mainEnv.drsCode) != -1){
                  propertie.openView(url, data);
                }else {
                  var contentsStr = "";
                  if(data.mode == "W" && propertie.getFixContents != null) {
                    contentsStr = propertie.getFixContents();
                  }

                  var gwApprovalData ={
                      compSeq : dewself.user.companyCode
                      ,approKey : data.athz_rpts_cd
                      ,outProcessCode : propertie.GW_PROC_CD
                      ,formId : propertie.FORM_ID
                      ,mod : data.mode
                      ,contentsType : "inner"
                      ,contentsStr : contentsStr
                      ,loginId : data.loginId
                      ,widthYn : true
                    }


                  if(propertie.provider =="amaranth"){
                      gwApprovalData.groupSeq = propertie.GROUPSEQ;
                      // if(dewself.mainEnv.drsCode == '20187'){
                      if(dewself.mainEnv.drsCode == 'dev'){
                        gwApprovalData.groupSeq = 'klagoDev'
                        gwApprovalData.loginId = 'erp01'
                        gwApprovalData.outProcessCode = 'FI_GLDDOC00300_00002'
                        gwApprovalData.formId = '959'
                      }else{
                        gwApprovalData.loginId = dewself.user.userid;
                      }
                      if(dewself.mainEnv.drsCode != 'dev' && propertie.desc == "portal" && gerp.CM.EltrAthzUtil.getCookieInfo(encodeURIComponent('am10:auth:token'))!=undefined){
                        var authtoken = decodeURIComponent(gerp.CM.EltrAthzUtil.getCookieInfo(encodeURIComponent('am10:auth:token')))
                        gwApprovalData.groupSeq = authtoken.split('|')[0];
                        gwApprovalData.loginId = dewself.user.userid;
                      }

                      if(data.mode == "W" && (data.file_dc != null || data.file_dcs != null)) {
                        gwApprovalData.fileKey = data.file_dc != null? data.file_dc: data.file_dcs.join("|");
                      }
                    gwApprovalData.close = function() { dews.ui.mainbuttons.search.click()}
                    gerp.CM.EltrAthzUtil.createEltrAthz_amaranth(gwApprovalData);

                  }else{

                      if(data.mode == "W" && (data.file_dc != null || data.file_dcs != null)) {
                        if(data.file_dc != null){
                          gwApprovalData.fileKey = gerp.CM.EltrAthzUtil.getFileKey(data.file_dc, "N");
                        }else{

                          gwApprovalData.fileKey = gerp.CM.EltrAthzUtil.getFileKey(JSON.stringify(data.file_dcs), "N",'Y');
                        }
                      }

                    gerp.CM.EltrAthzUtil.createEltrAthz(url, {
                      params : gwApprovalData,
                      close : function() {
                        dews.ui.mainbuttons.search.click();
                      }
                    });
                  }
                }
              }
            });
          },
          toQueryString : function(obj) {
            return Object.keys(obj).map(function(val) { return val+"="+obj[val]; }).join("&");
          },
          subProperty : function () {
            //0x10000 = 65536 ( 2 byte )
            return ((1 + Math.random()) * 0x10000 | 0).toString(16).substring(1);
          },
          createUUID : function () {
            return private.subProperty() + private.subProperty() + '-' + private.subProperty() + '-' + private.subProperty() + '-' + private.subProperty() + '-' + private.subProperty() +
            private.subProperty() + private.subProperty();
          }
        };
        var api = {
          get : function(abdocu_fg_cd) {
            return store.get(abdocu_fg_cd);
          }
        };
        private.setup(dewself.mainEnv.drsCode);
        return api;
      }
    }
  })();
  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.goddoc00300_gw.js
