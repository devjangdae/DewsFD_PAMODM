// 2023-05-24 written by ironman
//    - Script Version : 1.20230707-01
//    - 동방에스엔디 우남 증빙 연동 스크립트
//	

(function(dews, gerp, $) {

  // [증빙첨부 - 체크모드] 버튼추가
  if(dews.ui.page.$content.find("#btnWoonam_AttachEvdn_x10057").length == 0){
    dews.ui.page.$content.find(".dews-button-group").eq(0).prepend(
      '<button id="btnWoonam_AttachEvdn_x10057" class="dews-ui-button">증빙첨부</button>'
    );
    // [증빙첨부] 버튼 초기화
    dews.ui.page.btnWoonam_AttachEvdn_x10057 = dews.ui.button(dews.ui.page.$content.find("#btnWoonam_AttachEvdn_x10057"));
  }
  
  // [증빙첨부 - 더블클릭용] 버튼추가
  if(dews.ui.page.$content.find("#btnWoonam_AttachEvdn_DblClick_x10057").length == 0){
    dews.ui.page.$content.find(".dews-button-group").eq(0).prepend(
      '<button id="btnWoonam_AttachEvdn_DblClick_x10057" class="dews-ui-button" style="display:none"></button>'
    );
    // [증빙첨부] 버튼 초기화
    dews.ui.page.btnWoonam_AttachEvdn_DblClick_x10057 = dews.ui.button(dews.ui.page.$content.find("#btnWoonam_AttachEvdn_DblClick_x10057"));
  }

  if(dews.ui.page.$content.find("#btnWoonam_MakeEvdn_x10057").length == 0){
    // [증빙생성] 버튼추가
    dews.ui.page.$content.find(".dews-button-group").eq(0).prepend(
      '<button id="btnWoonam_MakeEvdn_x10057" class="dews-ui-button">증빙생성</button>'      
    );
    // [증빙생성] 버튼 초기화
    dews.ui.page.btnWoonam_MakeEvdn_x10057 = dews.ui.button(dews.ui.page.$content.find("#btnWoonam_MakeEvdn_x10057"));
  }
  
  function attachEvdn_x10057(selectedRow) {
	  var hData = selectedRow;
	      
	  if(!hData.DOCU_NO){
	    dews.ui.snackbar.warning("저장후 증빙을 첨부할 수 있습니다.");
	    return;
	  }
	  /*
	   * 승인된 상태일지라도 첨부를 하겠다고 함 (2023-06-28)
	   * 
	   * else if(hData.DOCU_ST_CD == "1" && !hData.CONN_KEY_YN) {
	    dews.ui.snackbar.warning("전표 승인전 첨부된 증빙이 없습니다.\n추가 증빙 첨부가 필요한 경우 전표승인 해제 후 첨부 하시기 바랍니다.");
	    return;
	  }*/
	
	  if(!hData.CONN_KEY_VR) {
	    var key = "";
		dews.api.post(dews.url.getApiUrl('FI', 'GeneralLedgerDocumentDOCService', 'getConnKeyVr'), {
		  async: false,
		  data: {
		    company_cd: hData.COMPANY_CD,
		    pc_cd: hData.PC_CD,
		    docu_no: hData.DOCU_NO
		  },
		}).done(function (data) {
		  key = data;
		}).fail(function (xhr, status, error) {
		  dews.error(error);
		}).always(function () {
		  // 성공, 실패와 관계없이 항상 실행합니다.
	    });
	  }
	  else {
	    key = hData.CONN_KEY_VR;
	  }
	
	  var viewMode = "VIEW";
	  if(hData.DOCU_ST_CD == "2" && (
		  hData.GWAPRVLST_CD == "1" || 
		  hData.GWAPRVLST_CD == "2" || hData.GWAPRVLST_CD == "3" || 
		  hData.GWAPRVLST_CD == "5" || hData.GWAPRVLST_CD == "6" || 
		  hData.GWAPRVLST_CD == "7" || hData.GWAPRVLST_CD == "9")) {
		  viewMode = "EDIT";
	  }
	  else if(hData.DOCU_ST_CD == "1" && hData.GWAPRVLST_CD == "4") {
		  viewMode = "AFTER";
	  }
	  
	  var emp_no = dews.ui.page.user.empCode ? dews.ui.page.user.empCode : hData.WRT_EMP_NO;
	  var company_cd = dews.ui.page.user.companyCode;
	  var url = "http://ea.dongbang.co.kr:9780/OfficeViewer/index.jsp?KEY=" + key + "&PROJ=DONGBANG&CORP=" + company_cd + "&USER=" + emp_no +  "&SVR=DEV&MODE=" + viewMode + "&VIEW=MULTI&POP=ACTOR&CALL=ERP";
	  console.log("증빙뷰어 : " + url);
	  var ret = window.open(url, "woonam","width=1400,height=700");   
  }
  
  dews.ui.page.btnWoonam_AttachEvdn_x10057.on("click", function(e){
    
    var checkedRows = dews.ui.page.grid.getCheckedRows();
    
    if(checkedRows.length == 0) {
      dews.alert('증빙을 첨부할 전표를 체크하시기 바랍니다.', 'warning');
      return;
    }
    
    if(checkedRows.length > 1) {
      dews.alert('증빙첨부는 1건의 전표만 선택 가능합니다.', 'warning');
      return;
    }    
    attachEvdn_x10057(checkedRows[0]);    
  });
  
  dews.ui.page.btnWoonam_AttachEvdn_DblClick_x10057.on("click", function(e){
	  
	if(dews.ui.page.grid.select() < 0) {
		dews.alert('증빙을 첨부할 전표를 선택하시기 바랍니다.', 'warning');
	}       
    attachEvdn_x10057(dews.ui.page.grid.dataItem(dews.ui.page.grid.select()));    
  });
  

  dews.ui.page.btnWoonam_MakeEvdn_x10057.on("click", function(){

    var checkedRows = dews.ui.page.grid.getCheckedRows();

    if(checkedRows.length == 0) {
      dews.alert('증빙생성이 필요한 전표를 체크하시기 바랍니다.', 'warning');
      return;
    }

    var docu_no_pipe = "";
    $.each(checkedRows, function(index, row){
      if(!row.DOCU_NO) {
        dews.ui.snackbar.warning("저장하지 않은 전표는 증빙을 생성할 수 있습니다.");
        return false;
      }
      docu_no_pipe += row.DOCU_NO + "|";
    });

    var confirm =  dews.confirm("선택한 전표의 증빙을 생성하시겠습니까 ?\n\n선택한 건수에 따라 작업시간이\n다소 소요될 수 있습니다.","question").yes(function(){
      var url = dews.string.format("/{0}/{1}/{2}/{3}", "ws", "FI", "Glddoc00500Service", "wsWoonamMakeEvdn_x10057");
      var searchProgress = dews.ui.progress("searchProgress" + dews.ui.page.menu.id, {
          total: 100,
          modal: true,
          position: {
              align: 'right|bottom',
              margin: [0, 0, 0, 0]
          },
          titlebar: {
              text: "우남 증빙생성"
          },
          textTemplate: "증빙생성을 준비 중 입니다.",
          alterTextTemplate: "#=progress#"
      });
      
      var ltx = dews.ws.ltx(url, {
        data: {
          company_cd  : dews.ui.page.user.companyCode,
          pc_cd  : dews.ui.page.s_pc_cd.code(),
          docu_no_pipe : docu_no_pipe       
        },
        done: function (e) {
          var packet = JSON.parse(e.resultData);
          /*searchProgress.setTextTemplate(packet.message);*/
          searchProgress.setCurrent(100);
          searchProgress.close();
                    
          var dialog = dews.ui.dialog('GLDDOC00500_x10057_ERROR_MODALLESS', {
              content: packet.message,
              modal: false,
              title: '증빙생성 결과',
              width:750,
              height:570,
              buttons: 'close',
              resizable: true
          });
          dialog.open();          
          /*dews.alert(packet.message);*/
          dews.ui.page._mainButtons.search.click();
        },
        error: function (e) {
          searchProgress.close();
          setTimeout(function () { dews.error(e.resultData) });
        },
        disconnect: function (e) {
          searchProgress.close();          
          setTimeout(function () { dews.error("증빙 생성 중 연결이 끊어졌습니다.\n\n(" + e.resultData + ")") });
        },
        progress: function (e) {
          var packet = JSON.parse(e.resultData);
          searchProgress.setTextTemplate(packet.message);
          searchProgress.setCurrent(packet.current);         
          console.log(packet.message);
        }
      }); 
      
      ltx.on('disconnect', function(){
        searchProgress.close();        
      });

      ltx.start();
      searchProgress.setCurrent(0);
    });
  });  

})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=fi.x10057.js
