 /*********************************************************************************************
 * @desc    IE 모듈 공통 함수 (동서발전 전용)
 * @author  이민현
 * @date    2020.12.14
 * @path    /view/js/ie_x10005.js

   var ieJS;
   dews.ajax.script('~/view/js/IE/ie_x10005.js', {
     once: true,
     async: false
   }).done(function() {
     ieJS = gerp.IE;
   });
 **********************************************************************************************/
(function(dews, gerp, $) {
  var module = {};
  var moduleCode = "IE"; // 모듈 코드

  //공통
  module.com = { };

  //API
  module.api = { };

  //-------------------------------------------End-------------------------------------------
  /*********************************************************************************************
   *  @desc  js파일 상속
   *  @param {Object} targetJS [필수] js 객체 변수
   *  @ex
   * ------------------------------------------------------------------------------------------*/
  module.extendJS = function(targetJS) {
    $.each(Object.keys(targetJS), function(idx, key) {
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
       겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName) {
        if (keyArr.indexOf(kName) >= 0) {
          console.error(
            "js 상속중 동일한 메소드 명이 존재합니다 - ",
            key + "." + kName
          );
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  };

  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  // im.js 상속
  dews.ajax
    .script("~/view/js/IE/ie.js", {
      once: true,
      async: false,
    })
    .done(function () {
      module.extendJS(gerp.IE);
      console.log("*** IE Module(X10005) Script Loaded ***");
    });

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=IE.js
