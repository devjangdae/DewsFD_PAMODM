 /*********************************************************************************************
 * @desc    IE 모듈 공통 함수
 * @author  류승준
 * @date    2019.08.09
 * @path    /view/js/ie.js

   var ieJS;
   dews.ajax.script('~/view/js/IE/ie.js', {
     once: true,
     async: false
   }).done(function() {
     ieJS = gerp.IE;
   });
 **********************************************************************************************/
(function(dews, gerp, $) {
  var module = {};
  var moduleCode = "IE"; // 모듈 코드

  //공통
  module.com = {
    openErrPop: function(errList, title){
      var dialog = dews.ui.dialog("H_IE_ERROR_C2",{
        url: "/codehelp/IE/H_IE_ERROR_C2",
        title: title || '저장실패',
        width: "700",
        height: "300"
      });
      dialog.setInitData(errList);
      dialog.open();
    },

    /*********************************************************************************************
     *  @desc   문서-첨부파일창을 오픈합니다.
     *          실제 저장되는 FILE_DC: 회사코드_[module_cd]_[docu_no]
     *          실제 저장되는 FILE_ATCH_TXT(FILE_PATH.파일경로): /모듈/중메뉴코드/
     *  @param  {String}  module_cd - [필수] 모듈코드(self.menu.module)
     *  @param  {String}  menu_cd   - [필수] 메뉴코드(self.menu.id)
     *  @param  {String}  docu_no   - [필수] 문서번호
     *  @param  {Object}  options   - [옵션] 옵션값(title, download, upload, read)
     *  @return {Promise} 도움창에서 변경된 데이터 있을시 사용.
     *  @ex     sdJS.com.openDocuFilePop(self.menu.module, self.menu.id, self.mstGrid.dataItem(e.row.index).SODOC_NO)
                .then(function(data) {
                  console.log(data);
                });
     * ------------------------------------------------------------------------------------------*/
    openDocuFilePop: function(module_cd, menu_cd, docu_no, options){
      if(module.com.isNull(module_cd) || module.com.isNull(menu_cd) || module.com.isNull(docu_no)){
        console.error("ieJS - openDocuFilePop 함수의 파라미터가 부족합니다.");
      } else{
        // 파일내역(PK) 설정
        var file_dc = menu_cd.substr(0, 6) + '_' + docu_no;
        return module.com.openFilePop(module_cd, menu_cd, file_dc, options);
      }
    },
    /*********************************************************************************************
     *  @desc   첨부파일창을 오픈합니다. #고유문서번호가 있는 경우, openDocuFilePop메소드 사용
     *          실제 저장되는 FILE_ATCH_TXT(FILE_PATH.파일경로): /모듈/중메뉴코드/
     *  @param  {String}  module_cd - [필수] 모듈코드(self.menu.module)
     *  @param  {String}  menu_cd   - [필수] 메뉴코드(self.menu.id) - 파일경로 설정.
     *  @param  {String}  file_dc   - [필수] 파일내역(PK) - 회사코드 제외하고 넘길것(실제 저장되는 FILE_DC: 회사코드_모듈코드_[file_dc])
     *  @param  {Object}  options   - [옵션] 옵션값(title, download, upload, read)
     *  @return {Promise} 도움창에서 변경된 데이터 있을시 사용.
     *  @ex     sdJS.com.openFilePop(self.menu.module, self.menu.id, '')
                .then(function(data) {
                  console.log(data);
                });
     * ------------------------------------------------------------------------------------------*/
    openFilePop: function(module_cd, menu_cd, file_dc, options){
      return new Promise(function(resolve){
        if(module.com.isNull(module_cd) || module.com.isNull(file_dc) || module.com.isNull(menu_cd)){
          console.error("ieJS - openFilePop 함수의 파라미터가 부족합니다.");
          resolve(false);
        } else{
          // 옵션값 세팅
          options = options || {};
          options.upload   = options.hasOwnProperty('upload')   ? options.upload   : true; // upload, delete 버튼 true/false
          options.download = options.hasOwnProperty('download') ? options.download : true; // download 버튼 true/false
          options.read     = options.hasOwnProperty('read')     ? options.read     : true; // read 자동조회 true/false
          options.title    = options.hasOwnProperty('title')    ? options.title    : '첨부파일'; // 타이틀 변경

          // 다이얼로그 세팅
          var dialog = dews.ui.dialog("H_IE_FILE_C", {
            url : "/codehelp/IE/H_IE_FILE_C",
            width : 680,
            height : 260,
            buttons : "none",
            ok: function(data){
              resolve(data);
            }
          });
          dialog.setInitData({
            file_dc   : file_dc,
            file_path : '/' + module_cd + '/' + menu_cd.substr(0, 6),
            options   : options
          });
          dialog.open();
        }
      });
    },
     /*********************************************************************************************
     *  @desc   첨부파일창을 오픈합니다.
     *          기존의 'openFilePop' 함수는 file_path가 'H_IE_FILE_C' 도움창의 file_path와 불일치하여 오류발생합니다.
     *          2022-03-15 파일 업로드 및 다운로드 함수 신규 생성
     *          실제 저장되는 FILE_ATCH_TXT(FILE_PATH.파일경로): /temp
     *  @param  {String}  module_cd - [필수] 모듈코드(self.menu.module)
     *  @param  {String}  menu_cd   - [필수] 메뉴코드(self.menu.id) - 파일내역 생성용도
     *  @param  {String}  docu_no   - [필수] 문서번호(SHIPNG_NO) - 파일내역 생성용도
     *  @param  {Object}  options   - [옵션] 옵션값(title, download, upload, read)
     *  @return {Promise} 도움창에서 변경된 데이터 있을시 사용.
     *  @ex     sdJS.com.openFilePop(self.menu.module, self.menu.id, '')
                .then(function(data) {
                  console.log(data);
                });
     * ------------------------------------------------------------------------------------------*/
    openFilePop2: function(module_cd, menu_cd, docu_no, options){
      return new Promise(function(resolve){
        if(module.com.isNull(module_cd) || module.com.isNull(menu_cd) || module.com.isNull(docu_no)){
          console.error("ieJS - openFilePop2 함수의 파라미터가 부족합니다.");
          resolve(false);
        } else{
          // 옵션값 세팅
          options = options || {};
          options.upload   = options.hasOwnProperty('upload')   ? options.upload   : true; // upload, delete 버튼 true/false
          options.download = options.hasOwnProperty('download') ? options.download : true; // download 버튼 true/false
          options.read     = options.hasOwnProperty('read')     ? options.read     : true; // read 자동조회 true/false
          options.title    = options.hasOwnProperty('title')    ? options.title    : '첨부파일'; // 타이틀 변경

          // 다이얼로그 세팅
          var file_dc = menu_cd.substr(0, 6) + '_' + docu_no;
          var dialog = dews.ui.dialog("H_IE_FILE_C", {
            url : "/codehelp/IE/H_IE_FILE_C",
            width : 680,
            height : 260,
            buttons : "none",
            ok: function(data){
              resolve(data);
            }
          });
          dialog.setInitData({
            file_dc   : file_dc,
            file_path : '/IE/UploadFile',
            options   : options
          });
          dialog.open();
        }
      });
    }
  };

  //API
  module.api = {
    /* --------------------------------------------------------------------------------------------
     *  @desc           배부기준 조회함수
     *  @param          - obj_std_dis : 배부기준
     *
     *  @return         - CTRL_VR, NM : 고객사일 경우 공급사 정보
     *                  - NULL        : 등록된 데이터가 없음
     *
     *  @ex             var std_dis_cd = ieApi.get_fn_StdDis_info(dewself.s_std_dis);
     * ------------------------------------------------------------------------------------------*/
    get_fn_StdDis_info: function(obj_std_dis) {
      var std_dis_cd = null;
      dews.api
        .get(
          dews.url.getApiUrl("IE", "IeCommonService", "get_fn_StdDis_info"),
          {
            async: false,
            data: {}
          }
        )
        .done(function(data) {
          if (data.length > 0) {
            std_dis_cd = data[0].CTRL_VR;
            obj_std_dis.text(data[0].CTRL_VR_NM);
          }
        })
        .fail(function(xhr, status, error) {
          dews.error(
            error || dews.localize.get("작업이 실패하였습니다.", "M0000055")
          );
        });
      return std_dis_cd;
    },

    clearPanel_ie: function(dewself, enable, exception_id) {
      var ret = dewself.$content.find(".dews-form-panel li input[class|='dews-ui'], .dews-form-panel li select[class|='dews-ui']")
      $(ret).each(function (index, node) {
        var target = self[node.id];

        if( exception_id != undefined && exception_id != []){
          var bException = false;
          $(exception_id).each(function (index2, exception_node) {
            if(exception_node.id == node.id){
              bException = true;
            }
          });
          if ( bException ){
            return true;
          }
        }

        if (target != undefined) {
        var dewsControl = $(node).data('dews-control');
        if(
            ($(node).hasClass("dews-ui-dropdownlist") ||
            $(node).hasClass("dews-ui-numerictextbox") ||
            $(node).hasClass("dews-ui-maskedtextbox") ||
            $(node).hasClass("dews-ui-datepicker") ||
            $(node).hasClass("dews-ui-timepicker") ||
            $(node).hasClass("dews-ui-monthpicker") ||
            $(node).hasClass("dews-ui-datetimepicker") ||
            $(node).hasClass("dews-ui-zipcodepicker") ||
            $(node).hasClass("dews-ui-combobox")) && dewsControl != undefined
          )
          {
            dewsControl.enable(enable);
            dewsControl.value('');
            if(typeof(dewsControl.text) == "function") {
              dewsControl.text('');
            }
          }
          else if($(node).hasClass("dews-ui-textbox")) {
            dewsControl.text('');
          }
          else if(
            $(node).hasClass("dews-ui-monthperiodpicker") ||
            $(node).hasClass("dews-ui-weekperiodpicker"))
          {
            var start ="", end = "";
            dewsControl.setPeriod(start, end);
          }
          else if($(node).hasClass("dews-ui-periodpicker")) {
            var start ="", end = "";
            dewsControl.setStartDate(start);
            dewsControl.setEndDate(end);
          }
          else if($(node).hasClass("dews-ui-codepicker")) {
            var obj = {};
            obj[dewsControl.options.codeField] = '';
            obj[dewsControl.options.textField] = '';
            dewsControl.setData(obj, false);
          }
          else if($(node).hasClass("dews-ui-multicodepicker")) {
            var arr = [];
            for( var i = 0 ; i < dt.length ; i++ ) {
              var obj = {};
              obj[dewsControl.options.codeField] = dt[i].code;
              obj[dewsControl.options.textField] = dt[i].name;
              arr.push(obj);
            }
            dewsControl.setData(arr);
          }
        }
      });
    }
  };

  //-------------------------------------------End-------------------------------------------
  /*********************************************************************************************
   *  @desc  js파일 상속
   *  @param {Object} targetJS [필수] js 객체 변수
   *  @ex
   * ------------------------------------------------------------------------------------------*/
  module.extendJS = function(targetJS) {
    $.each(Object.keys(targetJS), function(idx, key) {
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
       겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function(idx, kName) {
        if (keyArr.indexOf(kName) >= 0) {
          console.error(
            "js 상속중 동일한 메소드 명이 존재합니다 - ",
            key + "." + kName
          );
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  };




  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  var scmJS;
  dews.ajax
    .script("~/view/js/MA/ma.scm.js", {
      once: true,
      async: false
    })
    .done(function() {
      scmJS = gerp.MA;
    });

  module.extendJS(scmJS);

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=IE.js
