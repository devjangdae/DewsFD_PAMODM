/* 소스변환 : 홍소명(thaud1324) 변환시간 : 2018-08-13 18:09:45  */
// MA 모듈 공통 함수
(function (dews, gerp) {
  /**
   * 사용자/그룹 권한에 따른 코드피커/멀티코드피커 DefaultValue Setting
   */
  function setControlByAuth() {
    var self = this;
    var resultData = [];
    var grantCodeHelp = {
      'S': [],
      'C': ['COMPANY'],
      'P': ['COMPANY', 'PC'],
      'B': ['COMPANY', 'PC', 'BIZAREA'],
      'D': ['COMPANY', 'PC', 'BIZAREA', 'DEPT'],
      'E': ['COMPANY', 'PC', 'BIZAREA', 'DEPT', 'EMP']
    };

    self.$content.find('.dews-condition-panel-form .dews-ui-codepicker, .dews-ui-multicodepicker').each(function (idx, data) {
      var dewsControl = $(data).data('dews-control');
      var codeHelp = dewsControl.options.helpCode;
      var keyword = codeHelp.substring(5, codeHelp.length).replace(/(.+)(\_MST(\_S[0-9]*))|(\_S[0-9]*)/gi, '$1');
      var grantCode = '';

      if (!self.authority || !self.authority.grant || self.user.groupCode == 'MASATER' || self.user.groupCode == 'SYSTEM') {
        grantCode = 'S';
      } else {
        grantCode = self.authority.grant;
      }

      if ($.inArray(keyword, grantCodeHelp[grantCode]) != -1) {
        var settingData = {};

        if (self.user.userGbnName == "내부") {
          switch (keyword) {
            case 'COMPANY':
              settingData[dewsControl.options.codeField] = self.user.companyCode;
              settingData[dewsControl.options.textField] = self.user.companyName;
              break;
            case 'PC':
              settingData[dewsControl.options.codeField] = self.user.profitCenterCode;
              settingData[dewsControl.options.textField] = self.user.profitCenterName;
              break;
            case 'BIZAREA':
              settingData[dewsControl.options.codeField] = self.user.bizAreaCode;
              settingData[dewsControl.options.textField] = self.user.bizAreaName;
              break;
            case 'DEPT':
              settingData[dewsControl.options.codeField] = self.user.deptCode;
              settingData[dewsControl.options.textField] = self.user.deptName;
              break;
            case 'EMP':
              settingData[dewsControl.options.codeField] = self.user.empCode;
              settingData[dewsControl.options.textField] = self.user.username;
              break;
          }
        }

        if (data.classList.contains('dews-ui-multicodepicker')) {
          var settingDataList = [];
          settingDataList.push(settingData);
          dewsControl.setData(settingDataList);
        } else {
          dewsControl.setData(settingData);
        }

        // dewsControl.enable(false);
      }
    });
  };
  /**
   * default value 저장하기
   * @example DEFAULT.setMenuDefaultValue(dewself, true);
   * @example DEFAULT.setMenuDefaultValue(dewself, false, dewself.$content.find(".dews-ui-condition-panel .dews-form-control"));
   * @param {*} dewself : dews 객체
   * @param {*} onlyRequired : required만 대상 true/false
   * @param {*} postData : 컨트롤 설정을 위한 컨트롤 객체 배열(생략가능)
   * @return {*} none
   */
  function setMenuDefaultValue(dewself, onlyRequired, postData) {
    var items = [];
    var pageId = dewself.menu ? dewself.menu.id : dewself.id;
    var dewsContent;
    if (arguments.length == 2) {
      if (onlyRequired) {
        dewsContent = dewself.$content.find(".dews-ui-condition-panel .required");
      }
      else {
        dewsContent = dewself.$content.find(".dews-ui-condition-panel .dews-form-control");
      }
    } else if (arguments.length == 3) {
      dewsContent = postData;
    } else {
      return false;
    }
    if (dewsContent.length) {
      $(dewsContent).each(function (index, node) {
        if (!$(node).hasClass("disabled")) {
          var dewsControl = $(node).data('dews-control');
          if (dewsControl) {
            var obj = undefined;
            if (
              $(node).hasClass("dews-ui-dropdownlist") ||
              $(node).hasClass("dews-ui-numerictextbox") ||
              $(node).hasClass("dews-ui-maskedtextbox") ||
              $(node).hasClass("dews-ui-datepicker") ||
              $(node).hasClass("dews-ui-timepicker") ||
              $(node).hasClass("dews-ui-monthpicker") ||
              $(node).hasClass("dews-ui-datetimepicker") ||
              $(node).hasClass("dews-ui-zipcodepicker") ||
              $(node).hasClass("dews-ui-combobox")
            ) {
              var name = typeof (dewsControl.text) == "function" ? dewsControl.text() : "";
              obj = { id: node.id, code: dewsControl.value(), name: name, etc: "" };
            }
            else if (
              $(node).hasClass("dews-ui-monthperiodpicker") ||
              $(node).hasClass("dews-ui-periodpicker")) {
              items.push({ id: node.id + "_#START", code: dewsControl.getStartDate(), name: "", etc: "" });
              items.push({ id: node.id + "_#END", code: dewsControl.getEndDate(), name: "", etc: "" });
            }
            else if ($(node).hasClass("dews-ui-weekperiodpicker")) {
              items.push({ id: node.id + "_#START", code: dewsControl.getStartWeek(), name: "", etc: "" });
              items.push({ id: node.id + "_#END", code: dewsControl.getEndWeek(), name: "", etc: "" });
            }
            else if ($(node).hasClass("dews-ui-textbox")) {
              obj = { id: node.id, code: dewsControl.text(), name: "", etc: "" };
            }
            else if ($(node).hasClass("dews-ui-codepicker")) {
              var code = dewsControl.code() == "NULL" || dewsControl.code() == null ? "" : dewsControl.code();
              obj = { id: node.id, code: code, name: dewsControl.text(), etc: "" };
            }
            else if ($(node).hasClass("dews-ui-multicodepicker")) {
              for (var i = 0; i < dewsControl.codes().length; i++) {
                items.push({ id: node.id + "_#" + i, code: dewsControl.codes()[i], name: dewsControl.texts()[i], etc: "" });
              }
            }
            if (obj) {
              items.push(obj);
            }
          }

        }
      });
      dews.api.post(dews.url.getApiUrl('CM', 'AuthorityService', 'setMenuDefaultValue'), {
        async: false,
        data: {
          menuId: pageId,
          items: JSON.stringify(items)
        }
      }).done(function (data) {
      }).fail(function (xhr, satus, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.'));
      });
    }
  }
  /**
   * default value 가져오기
   * @example DEFAULT.getMenuDefaultValue(dewself, true);
   * @example DEFAULT.getMenuDefaultValue(dewself, false, dewself.$content.find(".dews-ui-condition-panel .dews-form-control"));
   * @param {*} dewself : dews 객체
   * @param {*} onlyRequired : required만 대상 true/false
   * @param {*} postData : 컨트롤 설정을 위한 컨트롤 객체 배열(생략가능)
   * @return {*} none
   */
  function getMenuDefaultValue(dewself, onlyRequired, postData) {
    var dewsContent;
    var menuDefault = [];
    // argument 비교
    if (arguments.length == 2) {
      if (onlyRequired) {
        dewsContent = dewself.$content.find(".dews-ui-condition-panel .required");
      }
      else {
        dewsContent = dewself.$content.find(".dews-ui-condition-panel .dews-form-control");
      }
    } else if (arguments.length == 3) {
      dewsContent = postData;
    } else {
      return false;
    }
    if (dewself.authority) { // 메뉴 페이지
      menuDefault = dewself.authority.menuDefault;
    }
    else { // 다이얼로그 페이지
      dews.api.get(dews.url.getApiUrl('CM', 'AuthorityService', 'getMenuDefaultValue'), {
        async: false,
        data: {
          menuId: dewself.id,
        }
      }).done(function (data) {
        if (data) {
          menuDefault = data;
        }
      }).fail(function (xhr, satus, error) {
        dews.error(error || dews.localize.get('작업이 실패하였습니다.'));
      });
    }
    if (menuDefault.length > 0) {
      if (dewsContent.length) {
        $(dewsContent).each(function (index, node) {
          if (!$(node).hasClass("disabled")) {
            var dewsControl = $(node).data('dews-control');
            if (dewsControl) {
              var dt = $.grep(menuDefault, function (v, i) {
                var vlen = v.id.length;
                var nlen = node.id.length;
                return vlen >= nlen && v.id.substring(0, nlen) == node.id;
              });

              if (dt.length > 0) {
                if (
                  $(node).hasClass("dews-ui-dropdownlist") ||
                  $(node).hasClass("dews-ui-numerictextbox") ||
                  $(node).hasClass("dews-ui-maskedtextbox") ||
                  $(node).hasClass("dews-ui-datepicker") ||
                  $(node).hasClass("dews-ui-timepicker") ||
                  $(node).hasClass("dews-ui-monthpicker") ||
                  $(node).hasClass("dews-ui-datetimepicker") ||
                  $(node).hasClass("dews-ui-zipcodepicker") ||
                  $(node).hasClass("dews-ui-combobox")
                ) {
                  dewsControl.value(dt[0].code);
                  if (typeof (dewsControl.text) == "function") {
                    dewsControl.text(dt[0].name);
                  }
                }
                else if (
                  $(node).hasClass("dews-ui-monthperiodpicker") ||
                  $(node).hasClass("dews-ui-weekperiodpicker")) {
                  var start = "", end = "";
                  for (var i = 0; i < dt.length; i++) {
                    if (i == 0) end = dt[i].code;
                    else start = dt[i].code;
                  }
                  dewsControl.setPeriod(start, end);
                }
                else if ($(node).hasClass("dews-ui-periodpicker")) {
                  var start = "", end = "";
                  for (var i = 0; i < dt.length; i++) {
                    if (i == 0) end = dt[i].code;
                    else start = dt[i].code;
                  }
                  dewsControl.setStartDate(start);
                  dewsControl.setEndDate(end);
                }
                else if ($(node).hasClass("dews-ui-textbox")) {
                  dewsControl.text(dt[0].code);
                }
                else if ($(node).hasClass("dews-ui-codepicker")) {
                  var obj = {};
                  obj[dewsControl.options.codeField] = dt[0].code;
                  obj[dewsControl.options.textField] = dt[0].name;
                  dewsControl.setData(obj);
                }
                else if ($(node).hasClass("dews-ui-multicodepicker")) {
                  var arr = [];
                  for (var i = 0; i < dt.length; i++) {
                    var obj = {};
                    obj[dewsControl.options.codeField] = dt[i].code;
                    obj[dewsControl.options.textField] = dt[i].name;
                    arr.push(obj);
                  }
                  dewsControl.setData(arr);
                }
              }
            }
          }
        });
      }
    }
  }
  /**
   * CODEHELP 가져오기
   * @return ["공통도움창_id", "공통도움창_id2"]
   */
  function getDefaultPagingId() { 
      return ['H_FI_BIZPLAN_MST_S01','H_FI_BGACCT_MST_S02','H_FI_BGACCT_MST_S03'];
  }

  window.gerp = $.extend(true, gerp, {
    MA: {
      setControlByAuth: setControlByAuth,
      setMenuDefaultValue: setMenuDefaultValue,
      getMenuDefaultValue: getMenuDefaultValue
    },
    CODEHELP: { // 추가
      getDefaultPagingId: getDefaultPagingId
    }
  });

  // preReadies 배열에 추가
  dews.preReadies = dews.preReadies || [];
  dews.preReadies.push(gerp.MA.setControlByAuth);
  dews.preReadies.push(gerp.CODEHELP.getDefaultPagingId); // 추가
})(window.dews, window.gerp || {});

// # sourceURL=site.js
