/*
 * CO 모듈 공통 함수 (테이블 관련)
 * /view/js/co.cm.tbl.js
 */
(function (dews, gerp, $) {

  var module = {};
  var moduleCode = 'CO';  //CO 모듈 코드

  //version : 1.0.22102502

  module.CONTROL = {
    init : function(self, object, html, callback, delay) {
      object.html($(html));

      if (!delay) {
        delay = 0;
      }

      setTimeout(function() {
        module.CONTROL.initalControls(self, object);

        if (typeof callback === 'function') {
          callback(object);
        }
      }, delay);
    },
    initBinding : function(self, object, html, dataRow, callback, delay) {
      object.html($(html));

      if (!delay) {
        delay = 0;
      }

      setTimeout(function() {
        module.CONTROL.initalControls(self, object);

        if (typeof callback === 'function') {
          callback(true);
        }

        object = $(object.selector, self.$content);
        module.BINDING.bindingControls(self, object, dataRow);
      }, delay);
    },
    initalControls : function (self, object) {
      object.trigger('inituicontrols');

      //컨트롤생성
      //textbox
      var textboxs = object.find(".dews-ui-textbox");
      $.each(textboxs, function (i, ctrl) {
        self[ctrl.id] = dews.ui.textbox($(ctrl));
      });
      // numerictextbox
      var numerictextboxs = object.find(".dews-ui-numerictextbox");
      $.each(numerictextboxs, function (i, ctrl) {
        self[ctrl.id] = dews.ui.numerictextbox($(ctrl));
      });
      //dropdownlist
      var dropdownlists = object.find(".dews-ui-dropdownlist");
      $.each(dropdownlists, function (i, ctrl) {
        self[ctrl.id] = dews.ui.dropdownlist($(ctrl));
      });
      //checkbox
      var checkboxs = object.find(".dews-ui-checkbox");
      $.each(checkboxs, function (i, ctrl) {
        self[ctrl.id] = dews.ui.checkbox($(ctrl));
      });
      //codepicker
      var codepickers = object.find(".dews-ui-codepicker");
      $.each(codepickers, function (i, ctrl) {
        self[ctrl.id] = dews.ui.codepicker($(ctrl));
      });    
      //datepicker
      var datepickers = object.find(".dews-ui-datepicker");
      $.each(datepickers, function (i, ctrl) {
        self[ctrl.id] = dews.ui.datepicker($(ctrl));
      });
      //datepicker
      var datetimepickers = object.find(".dews-ui-datetimepicker");
      $.each(datetimepickers, function (i, ctrl) {
        self[ctrl.id] = dews.ui.datetimepicker($(ctrl));
      });
      //monthpicker
      var monthpickers = object.find(".dews-ui-monthpicker");
      $.each(monthpickers, function(i, ctrl){
        self[ctrl.id] = dews.ui.monthpicker($(ctrl));
      });
      //yearpicker
      var yearpickers = object.find(".dews-ui-yearpicker");
      $.each(yearpickers, function(i, ctrl){
        self[ctrl.id] = dews.ui.yearpicker($(ctrl));
      });
      //file
      var files = object.find(".dews-ui-file");
      $.each(files, function(i, ctrl){
        self[ctrl.id] = dews.ui.file($(ctrl));
      });
      //multifile
      var multifiles = object.find(".dews-ui-multifile");
      $.each(multifiles, function(i, ctrl){
        self[ctrl.id] = dews.ui.multifile($(ctrl));
      });
      // formpanel
      var formpanels = object.find(".dews-ui-form-panel");
      $.each(formpanels, function(i, ctrl){
        self[ctrl.id] = dews.ui.formpanel($(ctrl));
      });
    }   
  }

  //user table binding
  module.BINDING = {
    /**
     * JQeryObject에 항목들에 데이터 바인딩합니다.
     * @example BINDING.bindingControls($('#content_ITAOTS00200 #tabJyunS'), dataRow);
     * @param {*} object : jqueryObject
     * @param {*} dataRow : 데이터소스 행
     * @return {*} boolean : true (성공), false (실패)
     */    
    bindingControls : function(self, object, dataRow) {
      var ret = true;
      var mformat = null;
      var dformat = null;

      //td관련
      var tdList = object.find("td");
      $.each(tdList, function (i, target) {
        if (target.id != undefined && target.id != "") {

          var targetid = target.id;
          var bindid = $(target).attr("data-binding-colname");
          if(bindid != undefined && bindid != ""){
            targetid = bindid;
          }

          if ($(target).attr("type") == "date") {
            var data = dataRow[targetid];
            if (!data) {
              target.innerHTML = "";
            }
            else {
              if (data.length == 6) {
                if (!mformat) { 
                  mformat = dews.ui.page.env.MA00008.format == "MM-yyyy" ? "{1}-{0}" : "{0}-{1}";
                }
                target.innerHTML = dews.string.format(mformat, data.substring(0, 4), data.substring(4, 6));
              }
              else if (data.length == 8) {
                if (!dformat) { 
                  dformat = dews.ui.page.env.MA00007.format == "yyyy-dd-MM" ? "{0}-{2}-{1}" : 
                            dews.ui.page.env.MA00007.format == "MM-dd-yyyy" ? "{1}-{2}-{0}" : 
                            dews.ui.page.env.MA00007.format == "dd-MM-yyyy" ? "{2}-{1}-{0}" : "{0}-{1}-{2}";
                }
                target.innerHTML = dews.string.format(dformat, data.substring(0, 4), data.substring(4, 6), data.substring(6, 8));
              }
              else {
                target.innerHTML = "";
              }
            }
          }
          else if ($(target).attr("type") == "datetime") {
            var data = dataRow[targetid];
            var dtformat = "{3}:{4}:{5}";
            if (!data) {
              target.innerHTML = "";
            }
            else {
              var date, str_date;
              var year , month, day, hour, minites, seconds;
              
              date = new Date(data);

              year  = date.getFullYear().toString();
              month = date.getMonth() + 1;
              month = month < 10 ? '0' + month.toString() : month.toString();
              day = date.getDate();
              day = day < 10 ? '0' + day.toString() : day.toString();
              hour = date.getHours();
              hour = hour < 10 ? '0' + hour.toString() : hour.toString();
              minites = date.getMinutes();
              minites = minites < 10 ? '0' + minites.toString() : minites.toString();
              seconds = date.getSeconds();
              seconds = seconds < 10 ? '0' + seconds.toString() : seconds.toString();

              str_date = year + month + day + hour + minites + seconds;

				      if (str_date.length == 14) {
                if (!dformat) { 
                  dformat = dews.ui.page.env.MA00007.format == "yyyy-dd-MM" ? "{0}-{2}-{1}" : 
                            dews.ui.page.env.MA00007.format == "MM-dd-yyyy" ? "{1}-{2}-{0}" : 
                            dews.ui.page.env.MA00007.format == "dd-MM-yyyy" ? "{2}-{1}-{0}" : "{0}-{1}-{2}";
                  dtformat = dformat + " " + dtformat;
                }
                target.innerHTML = dews.string.format(dtformat, str_date.substring(0, 4), str_date.substring(4, 6), str_date.substring(6, 8), 
                                      str_date.substring(8, 10), str_date.substring(10, 12), str_date.substring(12, 14))
              }
              else {
                target.innerHTML = "";
              }
            }
          }
          else if ($(target).attr("type") == "period") {
            var startdata = dataRow[$(target).attr("date-start-colname")];
            var enddata = dataRow[$(target).attr("date-end-colname")];
            var start = "", end = "";
            if (startdata) {
              if (startdata.length == 6) {
                if (!mformat) { 
                  mformat = dews.ui.page.env.MA00008.format == "MM-yyyy" ? "{1}-{2}" : "{0}-{1}";
                }
                start = dews.string.format(mformat, startdata.substring(0, 4), startdata.substring(4, 6));
              }
              else if (startdata.length == 8) {
                if (!dformat) { 
                  dformat = dews.ui.page.env.MA00007.format == "yyyy-dd-MM" ? "{0}-{2}-{1}" : 
                            dews.ui.page.env.MA00007.format == "MM-dd-yyyy" ? "{1}-{2}-{0}" : 
                            dews.ui.page.env.MA00007.format == "dd-MM-yyyy" ? "{2}-{1}-{0}" : "{0}-{1}-{2}";
                }
                start = dews.string.format(dformat, startdata.substring(0, 4), startdata.substring(4, 6), startdata.substring(6, 8));
              }
            }
            if (enddata) {
              if (enddata.length == 6) {
                if (!mformat) { 
                  mformat = dews.ui.page.env.MA00008.format == "MM-yyyy" ? "{1}-{2}" : "{0}-{1}";
                }
                end = dews.string.format(mformat, enddata.substring(0, 4), enddata.substring(4, 6));
              }
              else if (startdata.length == 8) {
                if (!dformat) { 
                  dformat = dews.ui.page.env.MA00007.format == "yyyy-dd-MM" ? "{0}-{2}-{1}" : 
                            dews.ui.page.env.MA00007.format == "MM-dd-yyyy" ? "{1}-{2}-{0}" : 
                            dews.ui.page.env.MA00007.format == "dd-MM-yyyy" ? "{2}-{1}-{0}" : "{0}-{1}-{2}";
                }
                end = dews.string.format(dformat, enddata.substring(0, 4), enddata.substring(4, 6), enddata.substring(6, 8));
              }
            }

            if (start != "" || end != "") {
              target.innerHTML = start + " ~ " + end;
            }
            else {
              target.innerHTML = "";
            }
          }
          else if ($(target).attr("type") == "numeric") {
            var data = dataRow[targetid];
            if (!data) {
              target.innerHTML = "";
            }
            else {
              target.innerHTML = data.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
          }
          else {
            target.innerHTML = dataRow[targetid] ? dataRow[targetid].replace(/\n/gi, "<br>") : "";
          }
        }
      });
      //td 끝

      //textBox관련
      var txtList = object.find(".dews-ui-textbox"), _txt;
      $.each(txtList, function (i, txt) {
        var targetid = txt.id;
        var target = self[txt.id];
        var bindid = $(txt).attr("data-binding-colname");
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          _txt = typeof dataRow[targetid] === "undefined" ? "" : dataRow[targetid] || "";
          target.text(_txt);
        }
      });

      //dropDownList관련
      var dropList = object.find(".dews-ui-dropdownlist");
      $.each(dropList, function (i, drop) {
        var targetid = drop.id;
        var target = self[drop.id];
        var bindid = $(drop).attr("data-binding-colname");
        
        if (bindid) {
          targetid = bindid;
        }

        if (target != undefined) {
          if (typeof dataRow[targetid] == "undefined") {
            target.text("");
          }
          else {
            target.value(dataRow[targetid]);
          }
        }
      });

      //datePicker관련
      var dateList = object.find(".dews-ui-datepicker");
      $.each(dateList, function (i, date) {
        var targetid = date.id;
        var target = self[date.id];    
        var bindid = $(date).attr("data-binding-colname");    
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          target.value(typeof dataRow[targetid] === "undefined" ? "" : dataRow[targetid]);
        }
      });

      //monthpicker관련
      var dateList = object.find(".dews-ui-monthpicker");
      $.each(dateList, function (i, date) {
        var targetid = date.id;
        var target = self[date.id];    
        var bindid = $(date).attr("data-binding-colname");    
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          target.value(typeof dataRow[targetid] === "undefined" ? "" : dataRow[targetid]);
        }
      });

      //yearPicker관련
      var yearList = object.find(".dews-ui-yearpicker");
      $.each(yearList, function (i, date) {
        var targetid = date.id;
        var target = self[date.id];
        var bindid = $(date).attr("data-binding-colname");    
        if (bindid) {
          targetid = bindid;
        }        
        if (target != undefined) {
          target.value(typeof dataRow[targetid] === "undefined" ? "" : dataRow[targetid]);
        }
      });

      var periodList = object.find('.dews-ui-periodpicker');
      $.each(periodList, function (i, period) {
        //var targetid = period.id;
        var target = self[period.id];
        var sbindid = $(period).attr("data-binding-start-colname");  
        var ebindid = $(period).attr("data-binding-end-colname");  
        if (target != undefined) {
          target.setStartDate(typeof dataRow[sbindid] === "undefined" ? "" : dataRow[sbindid]);
          target.setEndDate(typeof dataRow[ebindid] === "undefined" ? "" : dataRow[ebindid]);
        }
      });

      //datetimepicker
      var datetimeList = object.find(".dews-ui-datetimepicker");
      $.each(datetimeList, function (i, date) {
        var targetid = date.id;
        var target = self[date.id];
        var bindid = $(date).attr("data-binding-colname");    
        if (bindid) {
          targetid = bindid;
        }        
        if (target != undefined) {
          target.value(typeof new Date(dataRow[targetid]) === "undefined" ? "" : new Date(dataRow[targetid]));
        }
      });

      //codePicker관련
      var codepickerList = object.find(".dews-ui-codepicker");
      $.each(codepickerList, function (i, codepicker) {
        var target = self[codepicker.id];
        if (target != undefined) {
          var col = $(codepicker).attr("data-dews-code-field");
          var colname = $(codepicker).attr("data-dews-text-field");
          var code = dataRow[$(codepicker).attr("data-dews-bind-code")];
          var name = dataRow[$(codepicker).attr("data-dews-bind-text")];
          var objData = {};
          objData[col] = typeof code === "undefined" ? "" : code;
          objData[colname] = typeof name === "undefined" ? "" : name;
          target.setData(objData, false);
        }
      });

      //numeric관련
      var numericList = object.find(".dews-ui-numerictextbox");
      $.each(numericList, function (i, numeric) {        
        var targetid = numeric.id;
        var target = self[numeric.id];
        var bindid = $(numeric).attr("data-binding-colname");
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          target.value(typeof dataRow[targetid] === "undefined" ? 0 : dataRow[targetid]);
        }
      });

      var checkboxList = object.find(".dews-ui-checkbox");
      $.each(checkboxList, function (i, checkbox) {
        var targetid = checkbox.id;
        var target = self[checkbox.id];
        var bindid = $(checkbox).attr("data-binding-colname");
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          target.check(typeof dataRow[targetid] === "undefined" ? false : ( $(checkbox).attr("data-dews-bind-checked-value") == dataRow[targetid] ? true : false ));  //dataRow[targetid]
        }
      });

      return ret;
    },
    /**
     * JQeryObject에 항목들에 데이터를 리셋합니다.
     * @example BINDING.bindingResetControls($('#content_ITAOTS00200 #tabJyunS'));
     * @param {*} object : jqueryObject
     * @param {*} dataRow : 데이터소스 행
     * @return {*} boolean : true (성공), false (실패)
     */
    bindingResetControls : function(self, object) {
      var ret = true;

      //td관련
      var tdList = object.find("td");
      $.each(tdList, function (i, target) {
        if (target.id != undefined && target.id != "") {
          target.innerHTML = "";
        }
      });

      //textBox관련
      var txtList = object.find(".dews-ui-textbox"), _txt;
      $.each(txtList, function (i, txt) {
        var target = self[txt.id];
        if (target != undefined) {
          target.text("");
        }
      });

      //dropDownList관련
      var dropList = object.find(".dews-ui-dropdownlist");
      $.each(dropList, function (i, drop) {
        var target = self[drop.id];
        if (target != undefined) {
          target.text("");
        }
      });

      //datePicker관련
      var dateList = object.find(".dews-ui-datepicker");
      $.each(dateList, function (i, date) {
        var target = self[date.id];
        if (target != undefined) {
          target.value("");
        }
      });

      //codePicker관련
      var codepickerList = object.find(".dews-ui-codepicker");
      $.each(codepickerList, function (i, codepicker) {
        var target = self[codepicker.id];
        if (target != undefined) {
          var col = $(codepicker).attr("data-dews-code-field");
          var colname = $(codepicker).attr("data-dews-text-field");
          var objData = {};
          objData[col] = "";
          objData[colname] = ""
          target.setData(objData, false);
        }
      });

      //numeric관련
      var numericList = object.find(".dews-ui-numerictextbox");
      $.each(numericList, function (i, numeric) {
        var target = self[numeric.id];
        if (target != undefined) {
          target.value(0);
        }
      });

      var checkboxList = object.find(".dews-ui-checkbox");
      $.each(checkboxList, function (i, checkbox) {
        var target = self[checkbox.id];
        if (target != undefined) {
          target.check(false);
        }
      });

      return ret;
    },
    bindingTd: function(self, object, id, data) {           
      var tdList = object.find("td#" + id);
      var dformat = null;

      if (tdList.length > 0) {
        $.each(tdList, function (i, target) {

          if ($(target).attr("type") == "date") {

            if (!data) {
              target.innerHTML = "";
            }
            else {
              if (data.length == 6) {
                if (!mformat) { 
                  mformat = dews.ui.page.env.MA00008.format == "MM-yyyy" ? "{1}-{0}" : "{0}-{1}";
                }
                target.innerHTML = dews.string.format(mformat, data.substring(0, 4), data.substring(4, 6));
              }
              else if (data.length == 8) {
                if (!dformat) { 
                  dformat = dews.ui.page.env.MA00007.format == "yyyy-dd-MM" ? "{0}-{2}-{1}" : 
                            dews.ui.page.env.MA00007.format == "MM-dd-yyyy" ? "{1}-{2}-{0}" : 
                            dews.ui.page.env.MA00007.format == "dd-MM-yyyy" ? "{2}-{1}-{0}" : "{0}-{1}-{2}";
                }
                target.innerHTML = dews.string.format(dformat, data.substring(0, 4), data.substring(4, 6), data.substring(6, 8));
              }
              else {
                target.innerHTML = "";
              }
            }
          }
          else if ($(target).attr("type") == "datetime") {

            var dtformat = "{3}:{4}:{5}";

            if (!data) {
              target.innerHTML = "";
            }
            else {
              var date, str_date;
              var year , month, day, hour, minites, seconds;
              
              date = new Date(data);

              year  = date.getFullYear().toString();
              month = date.getMonth() + 1;
              month = month < 10 ? '0' + month.toString() : month.toString();
              day = date.getDate();
              day = day < 10 ? '0' + day.toString() : day.toString();
              hour = date.getHours();
              hour = hour < 10 ? '0' + hour.toString() : hour.toString();
              minites = date.getMinutes();
              minites = minites < 10 ? '0' + minites.toString() : minites.toString();
              seconds = date.getSeconds();
              seconds = seconds < 10 ? '0' + seconds.toString() : seconds.toString();

              str_date = year + month + day + hour + minites + seconds;
              
              if (str_date.length == 14) {
                if (!dformat) { 
                  dformat = dews.ui.page.env.MA00007.format == "yyyy-dd-MM" ? "{0}-{2}-{1}" : 
                            dews.ui.page.env.MA00007.format == "MM-dd-yyyy" ? "{1}-{2}-{0}" : 
                            dews.ui.page.env.MA00007.format == "dd-MM-yyyy" ? "{2}-{1}-{0}" : "{0}-{1}-{2}";
                  dtformat = dformat + " " + dtformat;
                }
                target.innerHTML = dews.string.format(dtformat, str_date.substring(0, 4), str_date.substring(4, 6), str_date.substring(6, 8), 
                                      str_date.substring(8, 10), str_date.substring(10, 12), str_date.substring(12, 14))
              }
              else {
                target.innerHTML = "";
              }
            }
          }
          else if ($(target).attr("type") == "period") {
            var startdata = dataRow[$(target).attr("date-start-colname")];
            var enddata = dataRow[$(target).attr("date-end-colname")];
            var start = "", end = "";
            if (startdata) {
              if (startdata.length == 6) {
                if (!mformat) { 
                  mformat = dews.ui.page.env.MA00008.format == "MM-yyyy" ? "{1}-{2}" : "{0}-{1}";
                }
                start = dews.string.format(mformat, startdata.substring(0, 4), startdata.substring(4, 6));
              }
              else if (startdata.length == 8) {
                if (!dformat) { 
                  dformat = dews.ui.page.env.MA00007.format == "yyyy-dd-MM" ? "{0}-{2}-{1}" : 
                            dews.ui.page.env.MA00007.format == "MM-dd-yyyy" ? "{1}-{2}-{0}" : 
                            dews.ui.page.env.MA00007.format == "dd-MM-yyyy" ? "{2}-{1}-{0}" : "{0}-{1}-{2}";
                }
                start = dews.string.format(dformat, startdata.substring(0, 4), startdata.substring(4, 6), startdata.substring(6, 8));
              }
            }
            if (enddata) {
              if (enddata.length == 6) {
                if (!mformat) { 
                  mformat = dews.ui.page.env.MA00008.format == "MM-yyyy" ? "{1}-{2}" : "{0}-{1}";
                }
                end = dews.string.format(mformat, enddata.substring(0, 4), enddata.substring(4, 6));
              }
              else if (startdata.length == 8) {
                if (!dformat) { 
                  dformat = dews.ui.page.env.MA00007.format == "yyyy-dd-MM" ? "{0}-{2}-{1}" : 
                            dews.ui.page.env.MA00007.format == "MM-dd-yyyy" ? "{1}-{2}-{0}" : 
                            dews.ui.page.env.MA00007.format == "dd-MM-yyyy" ? "{2}-{1}-{0}" : "{0}-{1}-{2}";
                }
                end = dews.string.format(dformat, enddata.substring(0, 4), enddata.substring(4, 6), enddata.substring(6, 8));
              }
            }

            if (start != "" || end != "") {
              target.innerHTML = start + " ~ " + end;
            }
            else {
              target.innerHTML = "";
            }
          }
          else if ($(target).attr("type") == "numeric") {
            if (!data) {
              target.innerHTML = "";
            }
            else {
              target.innerHTML = data.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
          }
          else {
            target.innerHTML = data ? data.replace(/\n/gi, "<br>") : "";
          }
        });
      }
    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=co.cm.tbl.js
