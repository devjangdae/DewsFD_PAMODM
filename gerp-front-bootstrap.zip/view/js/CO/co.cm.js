/*
 * CO 모듈 공통 함수
 * /view/js/co.cm.js
 */
(function (dews, gerp, $) {
  var module = {};

  //---------Setting
  var moduleCode = 'CO';  //모듈 코드
  var ynClose = 'N';      //Y.마감, N.미마감
  var tpClose;
  var tVersion;
  //---------Start

  //Date공통함수
  module.DATE = {

    /**
     * 날짜가져오기 (yyyyMM)
     * @example var yyyyMM = DATE.getDate(-1); -> 현재월기준 전달
     * @param {*} value 조정월 / nothing 현재월
     * @return {*} 년월
     */
    getDate: function(value) {

      var today = new Date();
      var yyyyMM;

      if (value > 0) {
        yyyyMM = (today.getFullYear() + Math.floor(value / 12) + Math.floor((today.getMonth() + 1 + (value % 12)) / 12)).toString()
              + ((today.getMonth() + 1 + (value % 12)) % 12).toString().replace(/^(\d)$/, '0$1');
      }
      else if (value == 0) {
        yyyyMM = today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, '0$1');
      }
      else {
        value = Math.abs(value);

        if (today.getMonth() + 1 - (value % 12) <= 0) {
          yyyyMM = (today.getFullYear() - 1 - Math.floor(value / 12)).toString()
                 + ((today.getMonth() + 1 - (value % 12)) == 0 ? 12 : (12 + (today.getMonth() + 1 - (value % 12))).toString().replace(/^(\d)$/, '0$1'));
        }
        else {
          yyyyMM = (today.getFullYear() - Math.floor(value / 12)).toString()
                + (today.getMonth() + 1 - (value % 12)).toString().replace(/^(\d)$/, '0$1');
        }
      }

      return yyyyMM;
    },
    /**
     * 공통코드 CO/P00170 의 연월 기준값에 따른 값 리턴
     * @example DATE.getDateP00170("11");
     * @param {*} type : 11.현재월, 12.다음월, 13.현재 연도 1월, 14.현재 연도 12월, 15: 다음 연도 1월, 16: 다음 연도 12월
     * @return {*} 해당 연월
     */
    getDateP00170 : function (type) {
      var yyMM = "";
      var now = new Date();
      if(type == "11") { // 현재월
        yyMM = new Date(now.getFullYear(), now.getMonth());
      }
      else if(type == "12") { // 다음월
        yyMM = new Date(now.getFullYear(), now.getMonth()+1);
      }
      else if(type == "13") { // 현재 연도 1월
        yyMM = new Date(now.getFullYear(), now.getMonth());
      }
      else if(type == "14") { // 현재 연도 12월
        yyMM = new Date(now.getFullYear(), 11);
      }
      else if(type == "15") { // 다음 연도 1월
        yyMM = new Date(now.getFullYear()+1, 0);
      }
      else if(type == "16") { // 다음 연도 12월
        yyMM = new Date(now.getFullYear()+1, 11);
      }
      return yyMM;
    },
    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMM = DATE.getFirstDate(-1); -> 현재월기준 전달(yyyyMMdd)
     * @param {*} value 조정월
     * @return {*} 년월일(시작일 : 1일)
     */
    getFirstDate: function(value) {
      var yyyyMM = this.getDate(value);

      return yyyyMM + "01";
    },

    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMM = DATE.getLastDate(-1); -> 현재월기준 전달(yyyyMMdd)
     * @param {*} value 조정월
     * @return {*} 년월일(마지막일자)
     */
    getLastDate: function(value) {

      var yyyyMMdd;
      var yyyyMM = this.getDate(value);

      var ecdays =  new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
      var cyear = new Date(Number(yyyyMM.substr(0,4)), Number(yyyyMM.substr(4, 2)) - 1);
      if ((((cyear.getFullYear() % 4) == 0) && ((cyear.getFullYear() % 100) != 0)) || ((cyear.getFullYear() % 400) == 0)) ecdays[1] = 29;
      yyyyMMdd = yyyyMM + ecdays[cyear.getMonth()];

      return yyyyMMdd;
    },

    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMM = DATE.getFirstDateS("201801"); -> 현재월기준 전달
     * @param {*} value 조정월
     * @return {*} 년월일(시작일 : 1일)
     */
    getFirstDateS: function(value) {
      var today = new Date(Number(value.substr(0, 4)), Number(value.substr(4, 2)));

      var yyyyMMstart;
      if (today.getMonth() == 0) {
        today.setFullYear(today.getFullYear() - 1);
        yyyyMMstart = today.getFullYear().toString() + "12" + "01";
      }
      else {
        yyyyMMstart = today.getFullYear().toString() + today.getMonth().toString().replace(/^(\d)$/, "0$1");
        yyyyMMstart += "01";
      }

      return yyyyMMstart;
    },
    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMM = DATE.getLastDateS("201801"); -> 현재월기준 전달
     * @param {*} value 조정월
     * @return {*} 년월일(마지막일)
     */
    getLastDateS: function(value) {
      var today = new Date(Number(value.substr(0, 4)), Number(value.substr(4, 2)));

      var yyyyMMstart, yyyyMMend;
      if (today.getMonth() == 0) {
        today.setFullYear(today.getFullYear() - 1);
        yyyyMMend = today.getFullYear().toString() + "12" + "31";
      }
      else {
        yyyyMMstart = today.getFullYear().toString() + today.getMonth().toString().replace(/^(\d)$/, "0$1");
        var ecdays =  new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
        var cyear = new Date(today.getFullYear(), today.getMonth() - 1);
        if ((((cyear.getFullYear() % 4) == 0) && ((cyear.getFullYear() % 100) != 0)) || ((cyear.getFullYear() % 400) == 0)) ecdays[1] = 29;
        yyyyMMend = yyyyMMstart + ecdays[cyear.getMonth()];
      }

      return yyyyMMend;
    },
    parseDateYYYYMMDD: function(str){
      var targetDate = new Date(str);
      var year = targetDate.getFullYear();
      var month = (targetDate.getMonth() + 1).toString();
      var date = targetDate.getDate().toString();

      if(month.length == 1){
        month = '0' + month;
      }

      if(date.length == 1){
        date = '0' + date;
      }

      return year + month + date;
    },
    parseDateYYYYMM: function(str){
      var targetDate = new Date(str);
      var year = targetDate.getFullYear();
      var month = (targetDate.getMonth() + 1).toString();

      if(month.length == 1){
        month = '0' + month;
      }

      return year + month;
    }
  };

  //CO, 마감 관련
  module.CLOSE = {

    /**
     * value 가 null 이거나 undefined 가 아니라면 false 를 리턴
     * @param {*} value 체크객체
     * @returns {boolean} Null 인지 여부
     */
    isNull: function (value) {
      if (value != null && value != undefined) {
        return false;
      }

      return true;
    },

    /**
     * @param {*} value 모듈코드(마감코드)
     */
    setCloseCode: function(value) {
      tpClose = value;
    },

    setChangeVersion: function(value) {
      tVersion = value;
    },
    /**
    * @example var magam = Close.regetClose('201801');
    * @param {*} yyyyMM 결산년
    * @param {*} tpClose 관리회계 마감 구분 (코드관리)
    * @return {*} 마감여부 Y.마감, N.미마감
    */
    regetClose: function(yyyyMM) {

      if (!this.isNull(yyyyMM) && !this.isNull(tpClose)) {

        dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_close"), {
          async: false,
          data: {
            module_cd: "CO", 
            close_ym: yyyyMM, 
            close_tp_cd: tpClose,
            ver_no: tVersion ? tVersion : ""
          }
        }).done(function (data) {
          if (data) {
            ynClose = data; //"Y", "N"
          }
        });
      }

      return ynClose;
    },

    /** arguments.length == 0
     * @return {*} 마감여부 Y.마감, N.미마감
     */
    /** arguments.length == 2
    * @example var magam = Close.getClose('35', 201801');
    * @param {*} yyyyMM 결산년
    * @param {*} closetp 관리회계 마감 구분 (코드관리)
    * @return {*} 마감여부 Y.마감, N.미마감
    */
    getClose: function(closetp, yyyyMM) {

      if (arguments.length == 2) {
        var ynCloseEtc = 'N';

        if (!this.isNull(yyyyMM) && !this.isNull(closetp)) {

          dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_close"), {
            async: false,
            data: {
              module_cd: "CO",
              close_ym: yyyyMM,
              close_tp_cd: closetp,
              ver_no: tVersion ? tVersion : ""
            }
          }).done(function (data) {
            if (data) {
              ynCloseEtc = data; //"Y", "N"
            }            
          });
        }

        return ynCloseEtc;
      }
      else {
        return ynClose;
      }
    },

    /** arguments.length == 0
     * 스낵바를 띄우고 마감여부리터 (스낵바)
     * @return {*} 마감여부 Y.마감, N.미마감
     */
    /** arguments.length == 2
    * @example var magam = Close.getCloseMsg('35', 201801');
    */
    getCloseMsg: function(closetp, yyyyMM) {

      if (arguments.length == 2) {
        var ynCloseEtc = this.getClose(closetp, yyyyMM);
        if (ynCloseEtc == "N") {
          dews.ui.snackbar.warning(dews.localize.get("자동전기 마감이 되어 있지 않습니다.", 'M0019776', dews.localize.language(), "CBCBIM01100"));
        }

        return ynCloseEtc;
      }
      else  {
        if (ynClose == "Y") {
          dews.ui.snackbar.warning(dews.localize.get("마감된 기간입니다.", 'M0006749', dews.localize.language(), "CBCBIM01100"));
        }

        return ynClose;
      }
    },
    /** arguments.length == 0
     * 메시지박스를 띄우고 마감여부리터
     * @return {*} 마감여부 Y.마감, N.미마감
     */
    /** arguments.length == 2
    * @example var magam = Close.getCloseMsgBox('35', 201801');
    */
    getCloseMsgBox: function(closetp, yyyyMM) {

      if (arguments.length == 2) {
        var ynCloseEtc = this.getClose(closetp, yyyyMM);
        if (ynCloseEtc == "N") {
          dews.alert(dews.localize.get("자동전기 마감이 되어 있지 않습니다.", 'M0019776', dews.localize.language(), "CBCBIM01100") 
                  + "\n" 
                  + dews.localize.get("마감 후 진행 하실 수 있습니다.", 'M0019777', dews.localize.language(), "CBCBIM01100"), 'warning');
        }

        return ynCloseEtc;
      }
      else {
        if (ynClose == "Y") {
          dews.alert(dews.localize.get("마감된 기간입니다.", 'M0006749', dews.localize.language(), "CBCBIM01100"), 'warning');
        }

        return ynClose;
      }
    },

    getCloseMsgBox2: function(closetp, yyyyMM) {

      var ynCloseEtc = this.getClose(closetp, yyyyMM);
      if (ynCloseEtc == "Y") {
        dews.alert(dews.localize.get("비용센터 결산마감이 되어 있습니다.", 'M0019778', dews.localize.language(), "CBCBIM01100") 
              + "\n" 
              + dews.localize.get("마감취소 후 진행 하실 수 있습니다.", 'M0019779', dews.localize.language(), "CBCBIM01100"), 'warning');
      }

      return ynCloseEtc;
    },

    /**
    * @example var magam = Close.regetClose('201801');
    * @param {*} yyyyMM 결산년
    * @param {*} tpClose 관리회계 마감 구분 (코드관리)
    * @return {*} 마감여부 Y.마감, N.미마감
    */
    getCloseList: function(selectyyyyMMPipe, selectCloseCode) {

      var closeList = null;

      if (!this.isNull(selectCloseCode) && !this.isNull(selectyyyyMMPipe)) {

        dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_close_multi"), {
          async: false,
          data: {
            module_cd: "CO", 
            close_ym_pipe: selectyyyyMMPipe,
            close_tp_cd: selectCloseCode,
            ver_no: ""
          }
        }).done(function (data) {
          if (data) {
            closeList = data;
          }
        });
      }

      return closeList;
    },
    getCloseListPlan: function(selectyyyyMMPipe, selectCloseCode, ver_no) {

      var closeList = null;

      if (!this.isNull(selectCloseCode) && !this.isNull(selectyyyyMMPipe)) {

        dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_close_multi"), {
          async: false,
          data: {
            module_cd: "CO", 
            close_ym_pipe: selectyyyyMMPipe,
            close_tp_cd: selectCloseCode,
            ver_no: ver_no
          }
        }).done(function (data) {
          if (data) {
            closeList = data;
          }
        });
      }

      return closeList;
    },

    /**
    * //결산마감등록 메뉴에서 완료여부값 변경시 사용하는 api
    * @example var magam = Close.getCloseAble('35', 201801');
    * @param {*} yyyyMM 결산년
    * @param {*} tpClose 관리회계 마감 구분 (코드관리)
    * @return {*} 마감여부 Y.마감, N.미마감
    */
    getCloseAble: function(abletp, yyyyMM) {

      var ableClose = 'Y';

      if (!this.isNull(yyyyMM)) {

        dews.api.get(dews.url.getApiUrl("CO", "CostCenterAccountingCAPService", "ccacap00300_select_closeable"), {
          async: false,
          data: {
            close_ym: yyyyMM,
            close_tp_cd: abletp
          }
        }).done(function (data) {
          if (data > 0) {
            ableClose = 'N'
          }
        });
      }

      return ableClose;
    }
  };

  /**
	 * 권한있는 부서리스트 조회
	 * @return PLANT_CD, PLANT_NM
	 * @throws Exception
	 */
  module.getPlantAuth = function () {
    var result = null;

    dews.api.get(dews.url.getApiUrl('CO', 'CoCommonService', 'list_plant'), {
      async: false
    }).done(function (data) {
        result = data;
    }).fail(function (xhr, status, error) {
      dews.ui.snackbar.error(error);
    });

    return result;
  };

  module.CLOSED = function() {
    return {
      self: {},
      c_ynClose: "N",      //Y.마감, N.미마감
      c_tpClose: "",
      c_tVersion: "",
      initData: function(self) {
        var pself = this;
        pself.self = self;

        var _html = '<label class="co-common-close dews-ui-multilingual" data-dews-localize-key="D0002040" style="color: #faa733;width: 50px;height: 27px;float: left;padding-top: 3px;border: 1px solid;text-align: center;margin-left:1px;display:none;">' 
              + dews.localize.get("마감", 'D0002040', dews.localize.language(), "CBCBIM01100") + '</label>';
        
        if ($('.dews-button-group', self.$content).length > 0) {
          $('.dews-button-group', self.$content).first().prepend($(_html));
        }
      },
      isNull: function (value) {
        if (value != null && value != undefined) {
          return false;
        }
  
        return true;
      },
  
      /**
       * @param {*} value 모듈코드(마감코드)
       */
      setCloseCode: function(value) {
        var self = this;        
        self.c_tpClose = value;
      },
  
      setViewClose: function(value) {
        var pself = this;
        if ($('.co-common-close', pself.self.$content).length > 0) {
          if (value == "Y") {
            $('.co-common-close', pself.self.$content).css("display", "");
          }
          else {
            $('.co-common-close', pself.self.$content).css("display", "none");
          }
        }
      },

      setChangeVersion: function(value) {
        var self = this;
        self.c_tVersion = value;
      },
      /**
      * @example var magam = Close.regetClose('201801');
      * @param {*} yyyyMM 결산년
      * @param {*} tpClose 관리회계 마감 구분 (코드관리)
      * @return {*} 마감여부 Y.마감, N.미마감
      */
      regetClose: function(yyyyMM) {
        
        var self = this;

        if (!this.isNull(yyyyMM) && !this.isNull(self.c_tpClose)) {
          
          dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_close"), {
            async: false,
            data: {
              module_cd: "CO", 
              close_ym: yyyyMM, 
              close_tp_cd: self.c_tpClose,
              ver_no: self.c_tVersion ? self.c_tVersion : ""
            }
          }).done(function (data) {
            if (data) {
              self.c_ynClose = data; //"Y", "N"
            }
          });
        }
  
        return self.c_ynClose;
      },
  
      /** arguments.length == 0
       * @return {*} 마감여부 Y.마감, N.미마감
       */
      /** arguments.length == 2
      * @example var magam = Close.getClose('35', 201801');
      * @param {*} yyyyMM 결산년
      * @param {*} closetp 관리회계 마감 구분 (코드관리)
      * @return {*} 마감여부 Y.마감, N.미마감
      */
      getClose: function(closetp, yyyyMM) {
        
        var self = this;

        if (arguments.length == 2) {
          var ynCloseEtc = 'N';
  
          if (!this.isNull(yyyyMM) && !this.isNull(closetp)) {

            dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_close"), {
              async: false,
              data: {
                module_cd: "CO",
                close_ym: yyyyMM,
                close_tp_cd: closetp,
                ver_no: self.c_tVersion ? self.c_tVersion : ""
              }
            }).done(function (data) {
              if (data) {
                ynCloseEtc = data; //"Y", "N"
              }            
            });
          }
  
          return ynCloseEtc;
        }
        else {
          return self.c_ynClose;
        }
      },
  
      /** arguments.length == 0
       * 스낵바를 띄우고 마감여부리터 (스낵바)
       * @return {*} 마감여부 Y.마감, N.미마감
       */
      /** arguments.length == 2
      * @example var magam = Close.getCloseMsg('35', 201801');
      */
      getCloseMsg: function(closetp, yyyyMM) {
        
        var self = this;

        if (arguments.length == 2) {
          var ynCloseEtc = this.getClose(closetp, yyyyMM);
          if (ynCloseEtc == "N") {
            dews.ui.snackbar.warning(dews.localize.get("자동전기 마감이 되어 있지 않습니다.", 'M0019776', dews.localize.language(), "CBCBIM01100"));
          }
  
          return ynCloseEtc;
        }
        else  {
          this.setViewClose(self.c_ynClose);

          if (self.c_ynClose == "Y") {
            dews.ui.snackbar.warning(dews.localize.get("마감된 기간입니다.", 'M0006749', dews.localize.language(), "CBCBIM01100"));
          }
  
          return self.c_ynClose;
        }
      },
      /** arguments.length == 0
       * 메시지박스를 띄우고 마감여부리터
       * @return {*} 마감여부 Y.마감, N.미마감
       */
      /** arguments.length == 2
      * @example var magam = Close.getCloseMsgBox('35', 201801');
      */
      getCloseMsgBox: function(closetp, yyyyMM) {
  
        var self = this;

        if (arguments.length == 2) {
          var ynCloseEtc = this.getClose(closetp, yyyyMM);
          if (ynCloseEtc == "N") {
            dews.alert(dews.localize.get("자동전기 마감이 되어 있지 않습니다.", 'M0019776', dews.localize.language(), "CBCBIM01100") 
                  + "\n" 
                  + dews.localize.get("마감 후 진행 하실 수 있습니다.", 'M0019777', dews.localize.language(), "CBCBIM01100"), 'warning');
          }
  
          return ynCloseEtc;
        }
        else {
          this.setViewClose(self.c_ynClose);

          if (self.c_ynClose == "Y") {
            dews.alert(dews.localize.get("마감된 기간입니다.", 'M0006749', dews.localize.language(), "CBCBIM01100"), 'warning');
          }
  
          return self.c_ynClose;
        }
      },
      getCloseMsgBox2: function(closetp, yyyyMM) {

        var ynCloseEtc = this.getClose(closetp, yyyyMM);
        if (ynCloseEtc == "Y") {
          dews.alert(dews.localize.get("비용센터 결산마감이 되어 있습니다.", 'M0019778', dews.localize.language(), "CBCBIM01100") 
                  + "\n" 
                  + dews.localize.get("마감취소 후 진행 하실 수 있습니다.", 'M0019779', dews.localize.language(), "CBCBIM01100") , 'warning');
        }
  
        return ynCloseEtc;
      },
      /**
      * @example var magam = Close.regetClose('201801');
      * @param {*} yyyyMM 결산년
      * @param {*} tpClose 관리회계 마감 구분 (코드관리)
      * @return {*} 마감여부 Y.마감, N.미마감
      */
      getCloseList: function(selectyyyyMMPipe, selectCloseCode) {
  
        var closeList = null;
  
        if (!this.isNull(selectCloseCode) && !this.isNull(selectyyyyMMPipe)) {
  
          dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_close_multi"), {
            async: false,
            data: {
              module_cd: "CO", 
              close_ym_pipe: selectyyyyMMPipe,
              close_tp_cd: selectCloseCode,
              ver_no: ""
            }
          }).done(function (data) {
            if (data) {
              closeList = data;
            }
          });
        }
  
        return closeList;
      },
      getCloseListPlan: function(selectyyyyMMPipe, selectCloseCode, ver_no) {
  
        var closeList = null;
  
        if (!this.isNull(selectCloseCode) && !this.isNull(selectyyyyMMPipe)) {
  
          dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_close_multi"), {
            async: false,
            data: {
              module_cd: "CO", 
              close_ym_pipe: selectyyyyMMPipe,
              close_tp_cd: selectCloseCode,
              ver_no: ver_no
            }
          }).done(function (data) {
            if (data) {
              closeList = data;
            }
          });
        }
  
        return closeList;
      },
  
      /**
      * //결산마감등록 메뉴에서 완료여부값 변경시 사용하는 api
      * @example var magam = Close.getCloseAble('35', 201801');
      * @param {*} yyyyMM 결산년
      * @param {*} tpClose 관리회계 마감 구분 (코드관리)
      * @return {*} 마감여부 Y.마감, N.미마감
      */
      getCloseAble: function(abletp, yyyyMM) {
  
        var ableClose = 'Y';
  
        if (!this.isNull(yyyyMM)) {
  
          dews.api.get(dews.url.getApiUrl("CO", "CostCenterAccountingCAPService", "ccacap00300_select_closeable"), {
            async: false,
            data: {
              close_ym: yyyyMM,
              close_tp_cd: abletp
            }
          }).done(function (data) {
            if (data > 0) {
              ableClose = 'N'
            }
          });
        }
  
        return ableClose;
      }
    };
  };

  module.setMaxIntegerLength = function(grid, col, maxIntegerLength){
    
    if(grid && grid._grid && grid._grid.getColumnProperty){
      var options = grid._grid.getColumnProperty(col,  'editorOptions');
      if(options){

        //전체자릿수(소수점이하포함)가 15를 넘지 않도록 함.
        var decimalPlaceRegex = /[^.]*$/;
        var formatLetters = decimalPlaceRegex.exec(options.format)[0];
        var formatLettersLength = formatLetters.length;
        var formatLetter = formatLetters.charAt(formatLettersLength - 1);
        if(formatLetter + maxIntegerLength > 15){
          maxIntegerLength = 15 - formatLetter;
        }

        options['maxIntegerLength'] = maxIntegerLength;
        grid._grid.setColumnProperty(col, 'editorOptions', options);		
      }
    }
  }

  module.VF = {
    maxLength: function (colName, maxlength) {
      if(dews.ui.page.env.digit[colName] && dews.ui.page.env.digit[colName].yn_use == "Y") {
        return dews.ui.page.env.digit[colName].ctl;
      }
      else {
        return maxlength;
      }      
    },
    verifyLength: function (colName, length, name) {            
      var msg = null;

      var digit = dews.ui.page.env.digit[colName];      
      if (digit) {
        if (digit.yn_use == "Y" && digit.regulate == '1') { //같음
          if (digit.ctl != length) {
            msg = dews.string.format(dews.localize.get("{0}를 {1} 자리로 입력해 주십시오.", 'M0019780', dews.localize.language(), "CBCBIM01100"), name, digit.ctl);        
          }
        }
      }      

      return msg;
    }
  }

  /***
   * 단순 파라미터 사용시
   * 조회조건 파이프 저장시 사용
   */
  module.setLongParam = function(menu_cd, apicall_txt) {
    var guid_no = null;

    dews.api.post(dews.url.getApiUrl("CO", "CoCommonService", "insert_apicall"), {
      async: false,
      data: {
        menu_cd: menu_cd, 
        apicall_txt: apicall_txt
      }
    }).done(function (data) {
      if (data) {
        guid_no = data;
      }
    });

    return guid_no;
  }
  module.setLongParamNC = function(menu_cd, apicall_txt, isclear) {
    var guid_no = null;

    dews.api.post(dews.url.getApiUrl("CO", "CoCommonService", "insert_apicallNC"), {
      async: false,
      data: {
        menu_cd: menu_cd, 
        apicall_txt: apicall_txt,
        isclear: isclear
      }
    }).done(function (data) {
      if (data) {
        guid_no = data;
      }
    });

    return guid_no;
  }

  /***
   * 단순 파라미터 사용시
   * 조회조건 파이프 로드시 사용 (검증용)
   */
  module.getLongParam = function(menu_cd, guid_no_pipe) {
    var rets = null;

    dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_apicall"), {
      async: false,
      data: {
        menu_cd: menu_cd, 
        guid_no_pipe: guid_no_pipe != null ? "" : guid_no_pipe
      }
    }).done(function (data) {
      rets = data;
    });

    return rets;
  }

  /***
   * ERROR LOG 조회
   * gubn : 1.CO LOG, 2.CM LOG
   */
  module.getErrorlog = function(menu_cd, start_dt, end_dt, guid_no_pipe, gubn) {
    var rets = null;
    dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_error" + (gubn == 2 ? "_cm":"")), {
      async: false,
      data: {
        menu_cd: menu_cd, 
        start_dt: start_dt,
        end_dt: end_dt,
        guid_no_pipe: guid_no_pipe != null ? "" : guid_no_pipe
      }
    }).done(function (data) {
      rets = data;
    });

    return rets;
  }

  module.viewErrorList = function(menu_cd, menu_nm) {
    var inputData = {
      MENU_CD: menu_cd,
      MENU_NM: menu_nm
    }
  
    var dlgError;
  
    dlgError = dews.ui.dialog("CBCPEC00100_ERR", {
      url: "/view/CO/CBCPEC00100_ERR",
      title: dews.localize.get("에러로그조회", 'D0090411', dews.localize.language(), "CBCBIM01100"),
      width: 1100,
      height: 732,
      initData: inputData
    });
  
    dlgError.open();
  }

  $(document).unbind('keydown.co');

  $(document).bind('keydown.co', function (e) {
    if (e.altKey && e.shiftKey && e.ctrlKey && event.keyCode == 79) {
      if (dews.ui.page.menu.module == "CO"
        || (dews.ui.page.menu.module == "MA" 
            && (dews.ui.page.menu.id == "BASUDR00100" || dews.ui.page.menu.id == "BASUDR00200" || dews.ui.page.menu.id == "BASUDR00300" 
             || dews.ui.page.menu.id == "BASUDR00400" || dews.ui.page.menu.id == "BASUDR00500" || dews.ui.page.menu.id == "BASUDR00600")
           )
         ) {
        module.viewErrorList(dews.ui.page.menu.id, dews.ui.page.menu.name);
      }
    }
  });

  /***
   * STATE LOG 조회
   * 1.계산, 2.계산취소,3.전표생성, 4.전표취소, 5.계산실행중, 6.계산취소실행중, 7.전표생성실행중, 8.전표취소실행중
   */
  module.getState = function(menu_cd, col1_cd, col2_cd) {
    var rets = null;
    dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_state"), {
      async: false,
      data: {
        menu_cd: menu_cd, 
        col1_cd: col1_cd,
        col2_cd: col2_cd
      }
    }).done(function (data) {
      rets = data;
    });

    return rets;
  }
  module.getStateMsg = function(menu_cd, col1_cd, col2_cd) {
    var ret = true;
    dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "list_state"), {
      async: false,
      data: {
        menu_cd: menu_cd, 
        col1_cd: col1_cd,
        col2_cd: col2_cd
      }
    }).done(function (data) {

      if (data == "5") {
        ret = false;
        dews.alert("계산 진행중입니다.");
      }
      else if (data == "6") {
        ret = false;
        dews.alert("계산취소 진행중입니다.");
      }
      else if (data == "7") {
        ret = false;
        dews.alert("전표생성 진행중입니다.");
      }
      else if (data == "8") {
        ret = false;
        dews.alert("전표취소 진행중입니다.");
      }
    });

    return ret;
  }
  module.setStateDelete = function(menu_cd, col1_cd, col2_cd) {
    var rets = null;
    dews.api.get(dews.url.getApiUrl("CO", "CoCommonService", "delete_state"), {
      async: false,
      data: {
        menu_cd: menu_cd, 
        col1_cd: col1_cd,
        col2_cd: col2_cd
      }
    }).done(function (data) {
      rets = data;
    });

    return rets;
  }
  //---------End

  dews.localize.load(dews.localize.language(), 'CBCBIM01100');

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=co.cm.js
