(function (dews, gerp, $) {
  var module = {};
  var moduleCode = 'LR';
  var objCodeDtl = {};

  /**
   *  (func 연체료 계산) module.ReUtil.Arrrg.calcArrrg(수납우선코드(1월수/2일수), 연체대상금액, 연체율, (일수), (단위코드));
   *  (func 단위코드 처리) module.ReUtil.Arrrg.calcAmUnit(대상금액, 단위코드); //단위코드(MA_P00190):(16:정상, 11:0자리 내림, 12:0자리 올림, 15:0자리 반올림)
   *
   *  var reUtil;
      dews.ajax.script('~/view/js/hdg.re.util.js', {
          once : true
      }).done(function(){
          reUtil = gerp.LR.ReUtil.Arrrg;
      });

      var returnAmt = reUtil.calcArrrg(param1,param2,param3..);
   */

  module.ReUtil = {
    Arrrg: {
      /**
       * @section Description
       * @details 연체료 계산
       * @author 곽민기
       * - @param String set_arrrg_fg 수납우선코드(1월수/2일수)
       * @param Number arrrg_target_amt 연체대상금액
       * @param Number arrrg_rt 연체율
       * @param Number (arrrg_calcDays 일수)
       * @param String (unit_cd 단위코드 (MA_P00190):(16:정상(절사), 11:0자리 내림, 12:0자리 올림, 15:0자리 반올림..) )
       * - @return Number 문자열
       * @example var return_amt = ReUtil.Arrrg.calcArrrg("1", 1000, 0.20, 10);
       */
      calcArrrg: function (set_arrrg_fg, arrrg_target_amt, arrrg_rt, arrrg_calcDays, unit_cd) {
        arrrg_calcDays = typeof (arrrg_calcDays) != "undefined" ? arrrg_calcDays : 0; // 일수 default: 0

        var return_amt = 0;
        if (set_arrrg_fg == '1') {
          // 월수기준 연체료(((연체대상금액 * 연체율) / 100 / 12)
          return_amt = ((arrrg_target_amt * arrrg_rt) / 100 / 12); // 발생연체료

          if (typeof (unit_cd) != "undefined") {
            return_amt = this.calcAmUnit(return_amt, unit_cd);
          }
        }
        else {
          // 일수기준 연체료(연체대상금액 * (연체율/100) * (일수/365))
          return_amt = (arrrg_target_amt * (arrrg_rt / 100) * (arrrg_calcDays / 365)); //확정연체금액

          if (typeof (unit_cd) != "undefined") {
            return_amt = this.calcAmUnit(return_amt, unit_cd);
          }
        }
        return return_amt;
      },

      /* 보증금수납전용 월수기준 일경우 월수만큼 곱함, arrrg_calcDays 4번째 연체일수 대신 연체월수 넘기기*/
      calcArrrg_month: function (set_arrrg_fg, arrrg_target_amt, arrrg_rt, arrrg_mths_cnt, unit_cd) {
        arrrg_mths_cnt = typeof (arrrg_mths_cnt) != "undefined" ? arrrg_mths_cnt : 1; // 월수 default: 1

        var return_amt = 0;
        if (set_arrrg_fg == '1') {
          // 월수기준 연체료(((연체대상금액 * 연체율) / 100 / 12)
          return_amt = ((arrrg_target_amt * arrrg_rt) / 100 / 12) * arrrg_mths_cnt; // 발생연체료

          if (typeof (unit_cd) != "undefined") {
            return_amt = this.calcAmUnit(return_amt, unit_cd);
          }
        }
        return return_amt;
      },

      /**
       * @section Description
       * @details 단위코드 처리
       * @author 곽민기
       * @param Number (am 대상금액)
       * @param String (round 단위코드 (MA_P00190):(16:정상(0자리절사), 11:0자리 내림, 12:0자리 올림, 15:0자리 반올림..) )

       *  ps.js getNumberRound 와 같게 변경
       *  @desc           단수조정
       *  @ex             getNumberRound()
       *  @params         n 값  round PS_P800값
        // PS_P800 단수조정구분
        // *  1 : 1원미만 절사
        // *  2 : 1원미만절상
        // *  3 : 10원미만절사
        // *  4 : 10원미만절상 -> 9를 더한 뒤에 10원미만자리 절사
        // *  5 : 반올림
        // *  6 : 정상
        // *  7 : 100원미만절사
        // *  8 : 100원미만절상 -> 90을 더한 뒤에 100원미만자리 절사.
        // *  9 : 1000원미만절사
        // *  10 : 1000원미만절상 -> 900을 더한 뒤에 1000원미만자리 절사.

        * - @return Number 문자열
       * @example var amt = ArrrgAmtUtil.calcAmUnit(123.456, '15');
       */
      calcAmUnit: function (n, round) {
        if (isNaN(n)) {
          return 0;
        }
        //        var returnValue = null;
        //	      switch (round) {
        //	        case "1": // 1원미만절사
        //	          returnValue = Math.floor(n);
        //	          break;
        //	        case "2": // 1원미만절상
        //	          returnValue = Math.ceil(n);
        //	          break;
        //	        case "3": //10원미만절사
        //	          returnValue = Math.floor(n / 10) * 10;
        //	          break;
        //	        case "4": //10원미만절상
        //	          returnValue = Math.ceil(n / 10) * 10;
        //	          break;
        //	        case "5": //반올림
        //	          returnValue = Math.round(n);
        //	          break;
        //	        case "7": //100원미만절사
        //	          returnValue = Math.floor(n / 100) * 100;
        //	          break;
        //	        case "8": //100원이상절상
        //	          returnValue = Math.ceil(n / 100) * 100;
        //	          break;
        //	        case "9": //1000원미만절사
        //	          returnValue = Math.floor(n / 1000) * 1000;
        //	          break;
        //	        case "10": //1000원미만절상
        //	          returnValue = Math.ceil(n / 1000) * 1000;
        //	          break;
        //	        default:
        //	          //returnValue = n;
        //	        	returnValue = Math.floor(n);
        //	          break;
        //	      }
        //        return returnValue;

        var vat = n;
        //vat 라운드처리
        //CD_FIELD:P00190 ??? round 11 절사 round 10
        switch (round) {
          case "11":
            vat = decimalAdjust('floor', vat, 0);
            break;
          case "12":
            vat = decimalAdjust('ceil', vat, 0);
            break;
          case "13":
            vat = decimalAdjust('floor', vat, 1);
            break;
          case "14":
            vat = decimalAdjust('ceil', vat, 1);
            break;
          case "15":
            vat = decimalAdjust('round', vat, 0);
            break;
          case "16":
            vat = decimalAdjust('floor', vat, 0);
            break;
          case "17":
            vat = decimalAdjust('floor', vat, 2);
            break;
          case "18":
            vat = decimalAdjust('ceil', vat, 2);
            break;
          case "19":
            vat = decimalAdjust('floor', vat, 3);
            break;
          case "20":
            vat = decimalAdjust('ceil', vat, 3);
            break;
          case "21":
            vat = decimalAdjust('floor', vat, -3);
            break;
          case "22":
            vat = decimalAdjust('round', vat, -3);
            break;
          case "23":
            vat = decimalAdjust('ceil', vat, -3);
            break;
          case "24":
            vat = decimalAdjust('floor', vat, -2);
            break;
          case "25":
            vat = decimalAdjust('round', vat, -2);
            break;
          case "26":
            vat = decimalAdjust('ceil', vat, -2);
            break;
          case "27":
            vat = decimalAdjust('floor', vat, -1);
            break;
          case "28":
            vat = decimalAdjust('round', vat, -1);
            break;
          case "29":
            vat = decimalAdjust('ceil', vat, -1);
            break;
          default:
            vat = decimalAdjust('floor', vat, 0);
            break;
        }

        return vat;
      },
      /* --------------------------------------------------------------------------------------------
      *  @desc       숫자만 추출하기.
      *  @return     '123'
      *  @call       LR_UTIL.replaceOnlyNumber('_1a23')
      * ------------------------------------------------------------------------------------------*/
      replaceOnlyNumber: function (str) {
        var res;
        res = str.replace(/[^0-9]/g,"");
        return res;
      },
      /**
       * 정수만입력가능(keyDown이벤트에서 사용가능합니다.)
       * @example LR_UTIL.onlyNumber(e, exceptionList);
       * @param {*} event: keyDown이벤트
       * @param {*} exceptionList : 추가로 입력가능한 예외키코드
       *                          : var exceptionList = [];
                                    exceptionList.push('188'); -> 콤마
      * @return {*} boolean
      */
      onlyNumber : function (event, exceptionList){
        //event = event || window.event;

        console.log('event.key' + '/ ' + event.key );
        console.log('event.which' + '/ ' + event.which );
        console.log('event.keyCode' + '/ ' + event.keyCode );

        var keyID = (event.which) ? event.which : event.keyCode;
        if(exceptionList) {
          for(var i = 0; i < exceptionList.length ; i++) {
            if(keyID == exceptionList[i]) {
              return;
            }
          }
        }

        if ( (keyID >= 35 && keyID <= 36) //35:HOME, 36:END
            //|| (event.ctrlKey == true && (keyID == 67 ||  keyID == 86) ) Copy&Paste
            || (keyID >= 48 && keyID <= 57)   //0~9
            || (keyID >= 96 && keyID <= 105)  //0~9 숫자패드
            || (keyID >= 37 && keyID <= 40)   //방향키
            || keyID == 8 || keyID == 13 || keyID == 27 || keyID == 46/*|| keyID == 109 || keyID == 189*/ //8:백스페이스, 13:Enter, 17:CTRL, 20:SHIFT, 27:ESC, 46:DEL, 109,189:-
          )
          return;
        else{
          event.preventDefault();
          return;
        }
      },
      /* --------------------------------------------------------------------------------------------
    *  @desc           36자리 난수키를 생성한다.
    *  @ex             PS.UTIL.getUUID()
    *  @call           getUUID()
    * --------------------------------------------------------------------------------------------*/
      getUUID: function () {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
          var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 3 | 8);
          return v.toString(16);
        });
      },


      /* --------------------------------------------------------------------------------------------
      *  @desc           objCodeDtl 객체를 초기화한다.
      *  @ex             gerp.PS.UTIL.getCodeClear()
      *  @memo           메뉴마다 사용되는 코드가 다르므로 메뉴를 열때마다 초기화를 시킵니다.
      *  @call           getCodeClear()
      * --------------------------------------------------------------------------------------------*/
      getCodeClear: function () {
        objCodeDtl = {};
      },

      /* --------------------------------------------------------------------------------------------
       *  @no
       *  @desc           공통코드조회
       *  @ex             gerp.PS.UTIL.getCodeData("PS", "Y:P00730|N:P00790|", null, null, null, null, null);
       *  @memo           이 함수를 타기전에 셋팅하는 부분을 타는 경우는 에러발생함.
       * --------------------------------------------------------------------------------------------
       *  @module_cd      모듈코드
       *  @cd_field_pipe  코드디테일 코드(PIPE 사용) >>> Y:P00730 빈칸여부를 Y, N으로 세팅한다.
       *  @yn_sycode     시스템코드 유무(Y,N)
       *  @base_yn        디폴트 코드구분(Y,N)
       *  @yn_foreign     외국언어적용 유무(Y,N)- Y : NM_SYSDEF2, N : NM_SYSDEF
       *  @end_dt         종료일-종료일이 있는 경우 종료일 이전 데이터 제외 =>(수정)
       *                  common_codeDtl_list API 통신 시 오늘날짜(var today // yyyymmdd포맷)의 데이터를 보낸다. [210203-수정-김동은]
       *  @nm_keyword        검색할 코드 또는 명
       * --------------------------------------------------------------------------------------------
       *  @return         검색된 code에 대한 data set
       * ------------------------------------------------------------------------------------------*/
      getCodeData: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword) {
        if (!objCodeDtl.hasOwnProperty(module_cd)) {
          objCodeDtl[module_cd] = {};
        }

        var isEmpty;
        var str;
        var cd_field_pipe_result = "";
        // [210203-수정-김동은]
        var today = gerp.LR.ReUtil.Arrrg.getToday();


        $.each(cd_field_pipe.split("|"), function (i, v) {
          if (v.indexOf(':') != -1) {
            isEmpty = v.split(":")[0]; // 'Y' or 'N'
            str = v.split(":")[1]; // P00100
            if (isEmpty == "Y") {
              objCodeDtl[module_cd][str] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];
            }
            cd_field_pipe_result = cd_field_pipe_result + str + "|";
          }
          else {
            if (v != null && v != "") {
              objCodeDtl[module_cd][v] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];

              cd_field_pipe_result = cd_field_pipe_result + v + "|";
            }
          }
        });



        dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", "common_codeDtl_list"), {
          async: false,
          data: {
            module_cd: module_cd,
            field_cd_pipe: cd_field_pipe_result,
            syscode_yn: yn_sycode,
            base_yn: base_yn,
            foreign_yn: yn_foreign,
            end_dt: today,
            keyword: nm_keyword,
          }
        }).done(function (data) {

          $.each(data, function (i, obj) {
            if (objCodeDtl[module_cd][obj.FIELD_CD] == null) {
              objCodeDtl[module_cd][obj.FIELD_CD] = [{ SYSDEF_CD: obj.SYSDEF_CD, SYSDEF_NM: obj.SYSDEF_NM, FLAG_CD: obj.FLAG_CD, SYSCODE_YN: obj.SYSCODE_YN }];
            } else {
              objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
            }
          });

        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
        return objCodeDtl;
      },
      getCodeData_Flag: function (module_cd, cd_field_pipe, yn_sycode, base_yn, yn_foreign, end_dt, nm_keyword, flag_cd) {
        if (!objCodeDtl.hasOwnProperty(module_cd)) {
          objCodeDtl[module_cd] = {};
        }

        var isEmpty;
        var str;
        var cd_field_pipe_result = "";

        $.each(cd_field_pipe.split("|"), function (i, v) {
          if (v.indexOf(':') != -1) {
            isEmpty = v.split(":")[0]; // 'Y' or 'N'
            str = v.split(":")[1]; // P00100
            if (isEmpty == "Y") {
              objCodeDtl[module_cd][str] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];
            }
            cd_field_pipe_result = cd_field_pipe_result + str + "|";
          }
          else {
            if (v != null && v != "") {
              objCodeDtl[module_cd][v] = [{ SYSDEF_CD: '', SYSDEF_NM: '', FLAG_CD: '', SYSCODE_YN: '' }];

              cd_field_pipe_result = cd_field_pipe_result + v + "|";
            }
          }
        });


        dews.api.get(dews.url.getApiUrl("CM", "CommonCodeDtlService", "common_codeDtl_list"), {
          async: false,
          data: {
            module_cd: module_cd,
            field_cd_pipe: cd_field_pipe_result,
            syscode_yn: yn_sycode,
            base_yn: base_yn,
            foreign_yn: yn_foreign,
            end_dt: end_dt,
            keyword: nm_keyword,
          }
        }).done(function (data) {

          var objFLAG_CD = "";
          $.each(data, function (i, obj) {
            objFLAG_CD = "";
            if (objCodeDtl[module_cd][obj.FIELD_CD] == null) {
              if (obj.FLAG_CD) {
                objFLAG_CD = obj.FLAG_CD;
              }
              if (objFLAG_CD.indexOf(flag_cd) != -1) {
                objCodeDtl[module_cd][obj.FIELD_CD] = [{ SYSDEF_CD: obj.SYSDEF_CD, SYSDEF_NM: obj.SYSDEF_NM, FLAG_CD: obj.FLAG_CD, SYSCODE_YN: obj.SYSCODE_YN }];
              }
            } else {
              if (obj.FLAG_CD) {
                objFLAG_CD = obj.FLAG_CD;
              }
              if (objFLAG_CD.indexOf(flag_cd) != -1) {
                objCodeDtl[module_cd][obj.FIELD_CD].push(obj);
              }
            }
          });

        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
        return objCodeDtl;
      },
      /* --------------------------------------------------------------------------------------------
       *  @desc           화면상의 모든컨트롤을 초기화(CLEAR)합니다.
       *  @ex             PS_UTIL.clearPanel(dewself)
       *  @memo           컨트롤초기화
       * --------------------------------------------------------------------------------------------*/
      clearPanel: function (dewself) {
        var ret = dewself.$content.find(".dews-form-panel li input[class|='dews-ui'], " +
          ".dews-form-panel li select[class|='dews-ui'], " +
          ".dews-form-panel li span[class|='dews-ui'], " +
          ".dews-form-panel li textarea[class|='dews-ui']")
        $(ret).each(function (index, node) {
          var target = dewself[node.id];
          if (target != undefined) {
            var dewsControl = $(node).data('dews-control');
            if (
              $(node).hasClass("dews-ui-dropdownlist") ||
              $(node).hasClass("dews-ui-maskedtextbox") ||
              $(node).hasClass("dews-ui-datepicker") ||
              $(node).hasClass("dews-ui-timepicker") ||
              $(node).hasClass("dews-ui-monthpicker") ||
              $(node).hasClass("dews-ui-datetimepicker") ||
              $(node).hasClass("dews-ui-zipcodepicker") ||
              $(node).hasClass("dews-ui-combobox") ||
              $(node).hasClass("dews-ui-yearpicker")
            ) {
              dewsControl.value('');
              if (typeof (dewsControl.text) == "function") {
                dewsControl.text('');
              }
            }
            else if ($(node).hasClass("dews-ui-textbox")) {
              dewsControl.text('');
            }
            else if ($(node).hasClass("dews-ui-numerictextbox")) {
              dewsControl.value(null);
            }
            else if (
              $(node).hasClass("dews-ui-monthperiodpicker") ||
              $(node).hasClass("dews-ui-weekperiodpicker")) {
              dewsControl.setPeriod("", "");
            }
            else if ($(node).hasClass("dews-ui-periodpicker")) {
              dewsControl.setStartDate("");
              dewsControl.setEndDate("");
            }
            else if ($(node).hasClass("dews-ui-codepicker")) {
              var obj = {};
              obj[dewsControl.options.codeField] = '';
              obj[dewsControl.options.textField] = '';
              dewsControl.setData(obj, false);

              // [2020년 12월의 마지막날-이현태] clearData를 사용할경우 해당컨트롤에 focus가 이동되는 문제가 발생함.
              // 그리드에서 포커스가 컨트롤로 이동되면서 방향키로 행이동이 멈춤.
              // dewsControl.clearData();
            }
            else if ($(node).hasClass("dews-ui-multicodepicker")) {
              var arr = [];
              for (var i = 0; i < dt.length; i++) {
                var obj = {};
                obj[dewsControl.options.codeField] = dt[i].code;
                obj[dewsControl.options.textField] = dt[i].name;
                arr.push(obj);
              }
              dewsControl.setData(arr);
              // [2020년 12월의 마지막날-이현태] clearData를 사용할경우 해당컨트롤에 focus가 이동되는 문제가 발생함.
              // 그리드에서 포커스가 컨트롤로 이동되면서 방향키로 행이동이 멈춤.
              // dewsControl.clear();
            }
            else if ($(node).hasClass("dews-ui-checkbox")) {
              dewsControl.target[0].checked = false;
            }
            else if ($(node).hasClass("dews-ui-radio-group")) {
              dewsControl.select(0);
            }
            else if ($(node).hasClass("dews-ui-multidropdownlist")) {
              dewsControl.deselectAll();
            }
          }
        });
      },
      /* --------------------------------------------------------------------------------------------
       *  @desc           해당ContainerItem 하위의 dews-form-panel의 모든컨트롤을 초기화(CLEAR)합니다.
       *  @ex             PS_UTIL.clearTabPanel(dewself, dewself.$containerItemAct --> form-panel의 상위 containerItem ID)
       *  @memo           컨트롤초기화
       * --------------------------------------------------------------------------------------------*/
      clearTabPanel: function (dewself, panel) {
        var ret = panel.find(".dews-form-panel li input[class|='dews-ui'], "
          + ".dews-form-panel li select[class|='dews-ui'], "
          + ".dews-form-panel li span[class|='dews-ui'], "
          + ".dews-form-panel li textarea[class|='dews-ui']")
        $(ret).each(function (index, node) {
          var target = dewself[node.id];
          if (target != undefined) {
            var dewsControl = $(node).data('dews-control');
            if (
              $(node).hasClass("dews-ui-dropdownlist") ||
              $(node).hasClass("dews-ui-numerictextbox") ||
              $(node).hasClass("dews-ui-maskedtextbox") ||
              $(node).hasClass("dews-ui-datepicker") ||
              $(node).hasClass("dews-ui-timepicker") ||
              $(node).hasClass("dews-ui-monthpicker") ||
              $(node).hasClass("dews-ui-datetimepicker") ||
              $(node).hasClass("dews-ui-zipcodepicker") ||
              $(node).hasClass("dews-ui-combobox")
            ) {
              dewsControl.value('');
              if (typeof (dewsControl.text) == "function") {
                dewsControl.text('');
              }
            }
            else if ($(node).hasClass("dews-ui-textbox")) {
              dewsControl.text('');
            }
            else if (
              $(node).hasClass("dews-ui-monthperiodpicker") ||
              $(node).hasClass("dews-ui-weekperiodpicker")) {
              var start = "", end = "";
              dewsControl.setPeriod(start, end);
            }
            else if ($(node).hasClass("dews-ui-periodpicker")) {
              var start = "", end = "";
              dewsControl.setStartDate(start);
              dewsControl.setEndDate(end);
            }
            else if ($(node).hasClass("dews-ui-codepicker")) {
              var obj = {};
              obj[dewsControl.options.codeField] = '';
              obj[dewsControl.options.textField] = '';
              dewsControl.setData(obj, false);
            }
            else if ($(node).hasClass("dews-ui-multicodepicker")) {
              var arr = [];
              for (var i = 0; i < dt.length; i++) {
                var obj = {};
                obj[dewsControl.options.codeField] = dt[i].code;
                obj[dewsControl.options.textField] = dt[i].name;
                arr.push(obj);
              }
              dewsControl.setData(arr);
            }
            else if ($(node).hasClass("dews-ui-checkbox")) {
              dewsControl.target[0].checked = false;
            }
          }
        });
      },
      /* --------------------------------------------------------------------------------------------
        *  @desc       현재년월일 or 파라미터Date의 년월일 구하기
        *  @return     yyyyMMdd
        *  @call       getToday()
        * ------------------------------------------------------------------------------------------*/
      getToday: function (date) {
        if (date) {
          return date.getFullYear().toString() + (date.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
            + (date.getDate()).toString().replace(/^(\d)$/, "0$1");
        } else {
          var today = new Date();
          return today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, "0$1")
            + (today.getDate()).toString().replace(/^(\d)$/, "0$1");
        }
      },
      /**
     * 메뉴점프(openmenu)시 현재 로그인한그룹이 해당 메뉴로 어떤 모듈에 등록되어있는가를 조회합니다.
     * @param {*} 이동할 menuid
     * @return module_cd(PS, CX....)
     */
       getGrpMenuModuleCd: function(menuid) {
        var module_cd = "";
        dews.api.get(dews.url.getApiUrl("LR", "LRCommonService", "LRApiProvider_GROUP_MENU_MODULE_INFO"), {
          async: false,
          data: {
            menu_cd: menuid
          }
        }).done(function (mResultData) {
          if(mResultData.SUCCESS) {
            module_cd = mResultData.MSG;
          } else {
            // [2021.02.25-이현태] 메뉴진입시 해당 함수를 바로 호출하는 부분이 있어서 주석처리합니다.
            // mResultData.MSG = "로그인한 그룹으로 해당 메뉴에 대한 접근 권한이 없습니다." + menuid
            // setTimeout(function () {
            //   dews.alert(mResultData.MSG, { icon: mResultData.TYPE_CD });
            // }, 200);
          }
        }).fail(function (xhr, status, error) {
          console.error(error);
          setTimeout(function () {
            dews.error('오류가 발생하였습니다.');
          }, 200);
        });
        return module_cd;
      },
    }
  }

  //round, floor, ceil
  function decimalAdjust(type, value, exp) {
    // If the exp is undefined or zero...
    if (typeof exp === 'undefined' || +exp === 0) {
      return Math[type](value);
    }
    value = +value;
    exp = +exp;
    // If the value is not a number or the exp is not an integer...
    if (isNaN(value) || !(typeof exp === 'number' && exp % 1 === 0)) {
      return NaN;
    }
    // If the value is negative...
    if (value < 0) {
      return -this.decimalAdjust(type, -value, exp);
    }
    // Shifta
    value = value.toString().split('e');
    value = Math[type](+(value[0] + 'e' + (value[1] ? (+value[1] - exp) : -exp)));
    // Shift back
    value = value.toString().split('e');
    return +(value[0] + 'e' + (value[1] ? (+value[1] + exp) : exp));
  }

  console.log('## HDG LR UTIL Script Loaded!!! ##');

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=re.util.js
