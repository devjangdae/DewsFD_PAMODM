/*********************************************************************************************
 * @desc    MF 모듈 공통 함수
 * @author  kji6649
 * @date    2020.03.11
 * @path    /view/js/MF/mf.js
 * @update  
   var mfJS;
   dews.ajax.script('~/view/js/MF/mf.js', {
     once: true,
     async: false
   }).done(function() {
     mfJS = gerp.MF;
   });
**********************************************************************************************/
(function (dews, gerp, $) {
  var module = {};
  var moduleCode = "MF"; //모듈 코드
  const defaultFindStr = '*[class^=dews-ui-][id]'; //패널 find 용 기본 문자열

  //------------------------------------------Start------------------------------------------
  //공통
  module.com = {
    /*********************************************************************************************
     *  @desc   공통코드(MA_CODEDTL)를 가져옵니다.
     *  @param  {String} module_cd     - [필수]모듈코드
     *  @param  {String} field_cd_pipe - [필수]필드코드(multi)
     *  @return {Array}  해당 모듈/필드의 데이터를 배열(파라미터 부족등의 오류시 빈 배열)
     *  @ex     var objCodeDtl_SD = scmJS.api.getCodeData('SD', 'C00010|C00020');
     * ------------------------------------------------------------------------------------------*/
    getCodeData: function(module_cd, field_cd_pipe, syscode_yn, base_yn, foreign_yn, end_dt, keyword, flag_cd_pipe) {
      var objCodeDtl = {};
      syscode_yn   = (syscode_yn   != undefined ? syscode_yn   : null);
      base_yn      = (base_yn      != undefined ? base_yn      : null);
      foreign_yn   = (foreign_yn   != undefined ? foreign_yn   : null);
      end_dt       = (end_dt       != undefined ? end_dt       : null);
      keyword      = (keyword      != undefined ? keyword      : null);
      flag_cd_pipe = (flag_cd_pipe != undefined ? flag_cd_pipe : null);
      if(!module_cd){
        console.error("scmJS - getCodeData 함수의 'module_cd' 파라미터가 부족합니다.");
        return [];
      } else if(!field_cd_pipe){
        console.error("scmJS - getCodeData 함수의 'field_cd_pipe' 파라미터가 부족합니다.");
        return [];
      } else{
        $.each(field_cd_pipe.split("|"), function (i, v) {
          if (v != null && v != "") {
            objCodeDtl[v] = [];
          }
        });
        dews.api.get(dews.url.getApiUrl("PU", "PuCommonService_X10005", "common_codeDtl_list_flag"), {
          async: false,
          data: {
            module_cd: module_cd, // 모듈
            field_cd_pipe: field_cd_pipe,   // 코드디테일 코드(PIPE 사용) >>> 전표유형, 전표상태
            syscode_yn: syscode_yn,   // 시스템코드 유무(Y,N)
            base_yn: base_yn,   // 디폴트 코드구분(Y,N)
            foreign_yn: foreign_yn,   // 외국언어적용 유무(Y,N)- Y : NM_SYSDEF2의 값을 넘겨줌
            end_dt: end_dt,   // 종료일-종료일이 있는 경우 종료일 이전 데이터 제외
            keyword: keyword,    // 검색할 코드 또는 명
            flag_cd_pipe: flag_cd_pipe
          }
        }).done(function (data) {
          if (data.length > 0) {
            $.each(data, function (i, obj) {
              objCodeDtl[obj.FIELD_CD].push(obj);
              tmpCdField = obj.FIELD_CD;
            });
          } else {
          }
        }).fail(function (xhr, status, error) {
          dews.error(error || dews.localize.get('작업이 실패하였습니다.', 'M0000055'));
        });
        return objCodeDtl;
      }
    },
    /* 
      패널 아이템 읽기전용 처리(boolean) 
      ex) panelItemReadonly(self, '.required', self.$puwewc00500_condition, isNotZeroRow);
    */
    panelItemReadonly: function (page, cssClass, panel, bEnable) {
      if ((cssClass || "") == "") {
        panel.find(defaultFindStr).each(function () { //패널내부 아이템 전체 검색
          var data = this;
          //버튼, 체크박스 예외처리
          if (page[data.id] && page[data.id].element && page[data.id].element.hasClass("dews-ui-button")){
            page[data.id].enable(!bEnable);
          }
          else if(page['$' + data.id] && page['$' + data.id].hasClass("dews-ui-checkbox")){
            page[data.id].disable(bEnable);
          }
          else {
            page[data.id].readonly(bEnable);
          }
        });
      }
      //cssClass 수동버전
      else {
        panel.find(defaultFindStr + cssClass).each(function () { //패널내부 아이템 중 특정 cssClass 를 가진 컴포넌트만 검색
          var data = this;
          page[data.id].readonly(bEnable);
        });
      }
    },
    /*********************************************************************************************
     *  @desc  저장 실패시 에러 메세지를 보여줄 수 있는 다이얼로그를 오픈한다
     *  @param {Array} arrErrorMsg    에러 메세지를
     *  @ex    mfJS.com.openErrorMsgDialog(arrErrorMsg);
     *********************************************************************************************/
    openErrorMsgDialog : function(arrErrorMsg){
      dialog = dews.ui.dialog("H_PU_ERROR_C",
        {
          url: "/codehelp/PU/H_PU_ERROR_C",
          title: "저장실패",
          width: "700",
          height: "300",
          ok: function (data, e) {
          }
        });
      dialog.setInitData(arrErrorMsg);
      dialog.open();
    }
  };

  //API
  module.api = {
    /*********************************************************************************************
     *  @desc  폼패널 요소들 readonly true/false 처리 함수
     *  @param {object}  dewself 해당 페이지의 self
     *  @param {object}  form    폼 패널 DOM객체 - self.$expccm00100_form
     *  @param {Boolean} cond    true(활성화)/false(비활성화)
     *  @ex    mfJS.api.readonlyForm(self, self.$expccm00100_form, true(default = false));
     * ------------------------------------------------------------------------------------------*/
    //2020.10.16 오타수정 cond = false -> cond
    //사용메뉴 : 유연탄하역지시생성
    readonlyForm: function (self, panel, cond) {
      if (!self || !panel) {
        console.error("mfJS - readonlyForm 함수 인자가 부족합니다.");
      } else {
        var self = self;
        var panel = panel.$element || panel;
      }

      $.each(panel.find("*[class^=dews-ui-]"), function (idx, node) {
        if (!$(node).hasClass("dews-ui-multilingual")) {
          if (
            !($(node).hasClass("dews-ui-radio-group dews-form-control dews-control dews-control-activate") || $(node).hasClass("dews-ui-title"))
          )
            self[node.id].readonly(cond);
        }
      });
    },
        /* --------------------------------------------------------------------------------------------
    *  @desc                 공통 세팅데이터 조회
    *  @author               김준일 (kji6649)
    *  @ex                   puApi.getXmlData({P_XML_ID: "get_MA_PARTNERPU_INFO", P_PURORG_CD: "1000", P_PARTNER_CD: "2000001001"})
    * --------------------------------------------------------------------------------------------
    *  params                파라미터 오브젝트
        P_XML_ID             P_XML_ID (필수)
    * --------------------------------------------------------------------------------------------
    *  @return               List<Map<String, Object>>, Exception
    *  @수정
    * ------------------------------------------------------------------------------------------*/
    getXmlData: function(obj){
      var returnVr = null;
      if(obj && obj.P_XML_ID){
        dews.api.post(dews.url.getApiUrl("MF", "MfCommonService", "getXmlData"),{
          async : false,
          data : {
            params: JSON.stringify(obj)
          }
        }).done(function(data){
          returnVr = data;
        }).fail(function (xhr, status, error) {
          dews.error(error);
        });
      }
      return returnVr;
    }
  };

  /*********************************************************************************************
   *  @desc  js파일 상속
   *  @param {Object} targetJS [필수] js 객체 변수
   *  @ex
   * ------------------------------------------------------------------------------------------*/
  module.extendJS = function (targetJS) {
    $.each(Object.keys(targetJS), function (idx, key) {
      var keyArr = module[key] ? Object.keys(module[key]) : [];
      /* 겹치는 메소드가 있는지 확인,
        겹치는 메소드 존재시 console.error 띄워주고 targetJS의 메소드로 덮어씌워짐 */
      $.each(Object.keys(targetJS[key]), function (idx, kName) {
        if (keyArr.indexOf(kName) >= 0) {
          console.error(
            "js 상속중 동일한 메소드 명이 존재합니다 - ",
            key + "." + kName
          );
        }
      });
      module[key] = $.extend({}, module[key], targetJS[key]);
    });
  };

  /**********************************************************************************************/
  // #### 상속할 js파일 리스트는 이곳에 기술, 메소드명이 겹치지 않게 유의할 것

  // ma.scm.js 상속
  var scmJS;
  dews.ajax
    .script("~/view/js/MA/ma.scm.js", {
      once: true,
      async: false,
    })
    .done(function () {
      scmJS = gerp.MA;
    });
  module.extendJS(scmJS);
  //-------------------------------------------End-------------------------------------------

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);
//# sourceURL=/js/MF/mf.js