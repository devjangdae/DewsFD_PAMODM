/*
 * AU 모듈 공통 함수
 * /view/js/au.cm.js
 */
(function (dews, gerp, $) {
  var module = {};

  //---------Setting
  var moduleCode = 'AU';  //모듈 코드

  //---------Start

  //첨부파일
  module.FILE = {

    /**
     * 멀티파일 데이터 가져오기
     * @example var ret = FILE.bind(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} fgrp_sq : 파일그룹순번
     * @return {*} boolean
     */
    bind: function(ctrl, fgrp_sq) {
      var ret = false;

      if (!fgrp_sq) {
        if (ctrl.options.dataSource._data) {
          for (var i = ctrl.options.dataSource._data.length; i > 0; i--) {
            ctrl.deleteMultiFile(i - 1);
          }
        }
      }
      else {
        dews.api.get(dews.url.getApiUrl("AU", "AuCommonService", "au_common_file_list"), {
          async: false,
          data: {
            fgrp_sq: fgrp_sq
          }
        }).done(function (data) {
          if (data) {
            ret = true;

            var filelist = dews.ui.dataSource('filelist', { data: data });
            ctrl.setDataSource(filelist);
            filelist.read();
          }
        });
      }
      return ret;
    },

   /**
	   * 생성일 : 2020.07.01 생성자 : 전상만
     * 멀티파일 데이터 가져오기
     * @example var ret = FILE.bind_multi(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} fgrp_sq_pipe : 파일그룹순번리스트(파이프)
     * @return {*} boolean
     */
    bind_multi: function(ctrl, fgrp_sq_pipe) {
      var ret = false;

      if (!fgrp_sq_pipe) {
        if (ctrl.options.dataSource._data) {
          for (var i = ctrl.options.dataSource._data.length; i > 0; i--) {
            ctrl.deleteMultiFile(i - 1);
          }
        }
      }
      else {
        dews.api.get(dews.url.getApiUrl("AU", "AuCommonService", "au_common_file_multi_list"), {
          async: false,
          data: {
            fgrp_sq_pipe: fgrp_sq_pipe
          }
        }).done(function (data) {
          if (data) {
            ret = true;

            var filelist = dews.ui.dataSource('filelist', { data: data });
            ctrl.setDataSource(filelist);
            filelist.read();
          }
        });
      }
      return ret;
    },

    /**
     * 멀티파일 데이터 저장하기
     * @example var ret = FILE.upload(1, fileInfo);
     * @param {*} fgrp_sq : 파일그룹순번
     * @param {*} fileInfo : 파일정보
     * @return {*} boolean
     */
    upload: function(fgrp_sq, fileInfo) {
      var ret = null;

      if (!fgrp_sq) {
        fgrp_sq = "";
      }
      dews.api.post(dews.url.getApiUrl("AU", "AuCommonService", "au_common_file_upload"), {
        async: false,
        data: {
          fgrp_sq: fgrp_sq,
          fileInfo: JSON.stringify(fileInfo)
        }
      }).done(function (data) {
        ret = data;
      });

      return ret;
    },

    /**
     * 멀티파일 데이터 식제
     * @example var ret = FILE.delete(1, '1|2|');
     * @param {*} fgrp_sq : 파일그룹순번
     * @param {*} file_sq_pipe : 파일순번(파이프)
     * @return {*} boolean
     */
    delete: function(fgrp_sq, fileInfo) {
      var ret = false;

      if (fgrp_sq) {

        dews.api.post(dews.url.getApiUrl("AU", "AuCommonService", "au_common_file_delete"), {
          async: false,
          data: {
            fgrp_sq: fgrp_sq,
            fileInfo: JSON.stringify(fileInfo)
          }
        }).done(function (data) {
          ret = true;
        });
      }

      return ret;
    },

    /**
     * Single파일 데이터 가져오기
     * @example var ret = FILE.get(ctrl, 1);
     * @param {*} ctrl : 멀티파일컨트롤
     * @param {*} fgrp_sq : 파일그룹순번
     * @return {*} boolean
     */
    bindSingle: function(ctrl, fgrp_sq) {
      var ret = false;

      if (!fgrp_sq) {
        ctrl.deleteFile(); //체인지 이벤 발생 안함
      }
      else {
        dews.api.get(dews.url.getApiUrl("AU", "AuCommonService", "au_common_file_list"), {
          async: false,
          data: {
            fgrp_sq: fgrp_sq
          }
        }).done(function (data) {
          if (data) {
            ret = true;

            // 파일 정보
            if (data.length > 0) {
              var fileInfo = {
                fileKey: data[0]["NEW_FILE_DC"],
                filename: data[0]["FILE_NM"],
                extension: data[0]["ORGL_FEXTSN_DC"],
                size: data[0]["FILE_VR"]
              };
              ctrl.setFile(fileInfo);
            }
            else {
              ctrl.deleteFile();
            }
          }
        });
      }
      return ret;
    }
  };
  

  //user table binding
  module.BINDING = {
    /**
     * JQeryObject에 항목들에 데이터 바인딩합니다.
     * @example BINDING.bindingControls($('#content_ITAOTS00200 #tabJyunS'), dataRow);
     * @param {*} object : jqueryObject
     * @param {*} dataRow : 데이터소스 행
     * @return {*} boolean : true (성공), false (실패)
     */
    bindingControls : function(self, object, dataRow) {
      var ret = true;

      //td관련
      var tdList = object.find("td");
      $.each(tdList, function (i, target) {
        if (target.id != undefined && target.id != "") {

          if ($(target).attr("type") == "date") {
            var data = dataRow[target.id];
            if (!data) {
              target.innerHTML = "";
            }
            else {
              if (data.length == 6) {
                target.innerHTML = dews.string.format("{0}-{1}", data.substring(0, 4), data.substring(4, 6));
              }
              else if (data.length == 8) {
                target.innerHTML = dews.string.format("{0}-{1}-{2}", data.substring(0, 4), data.substring(4, 6), data.substring(6, 8));
              }
              else {
                target.innerHTML = "";
              }
            }
          }
          else if ($(target).attr("type") == "period") {
            var startdata = dataRow[$(target).attr("date-start-colname")];
            var enddata = dataRow[$(target).attr("date-end-colname")];
            var start = "", end = "";
            if (startdata) {
              if (startdata.length == 6) {
                start = dews.string.format("{0}-{1}", startdata.substring(0, 4), startdata.substring(4, 6));
              }
              else if (startdata.length == 8) {
                start = dews.string.format("{0}-{1}-{2}", startdata.substring(0, 4), startdata.substring(4, 6), startdata.substring(6, 8));
              }
            }
            if (enddata) {
              if (enddata.length == 6) {
                end = dews.string.format("{0}-{1}", enddata.substring(0, 4), enddata.substring(4, 6));
              }
              else if (startdata.length == 8) {
                end = dews.string.format("{0}-{1}-{2}", enddata.substring(0, 4), enddata.substring(4, 6), enddata.substring(6, 8));
              }
            }

            if (start != "" || end != "") {
              target.innerHTML = start + " ~ " + end;
            }
            else {
              target.innerHTML = "";
            }
          }
          else if ($(target).attr("type") == "numeric") {
            var data = dataRow[target.id];
            if (!data) {
              target.innerHTML = "";
            }
            else {
              target.innerHTML = data.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
          }
          else {
            // target.innerHTML = dataRow[target.id] ? dataRow[target.id] : "";
            target.innerHTML = dataRow[target.id] ? dataRow[target.id].replace(/\n/gi, "<br>") : "";
          }
        }
      });

      //textBox관련
      var txtList = object.find(".dews-ui-textbox"), _txt;
      $.each(txtList, function (i, txt) {
        var targetid = txt.id;
        var target = self[txt.id];
        var bindid = $(txt).attr("data-binding-colname");
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          _txt = typeof dataRow[targetid] === "undefined" ? "" : dataRow[targetid] || "";
          target.text(_txt);
        }
      });

      //dropDownList관련
      var dropList = object.find(".dews-ui-dropdownlist");
      $.each(dropList, function (i, drop) {
        var targetid = drop.id;
        var target = self[drop.id];
        var bindid = $(drop).attr("data-binding-colname");
        
        if (bindid) {
          targetid = bindid;
        }

        if (target != undefined) {
          if (typeof dataRow[targetid] == "undefined") {
            target.text("");
          }
          else {
            target.value(dataRow[targetid]);
          }
        }
      });

      //datePicker관련
      var dateList = object.find(".dews-ui-datepicker");
      $.each(dateList, function (i, date) {
        var targetid = date.id;
        var target = self[date.id];    
        var bindid = $(date).attr("data-binding-colname");    
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          target.value(typeof dataRow[targetid] === "undefined" ? "" : dataRow[targetid]);
        }
      });

      //yearPicker관련
      var yearList = object.find(".dews-ui-yearpicker");
      $.each(yearList, function (i, date) {
        var targetid = date.id;
        var target = self[date.id];
        var bindid = $(date).attr("data-binding-colname");    
        if (bindid) {
          targetid = bindid;
        }        
        if (target != undefined) {
          target.value(typeof dataRow[targetid] === "undefined" ? "" : dataRow[targetid]);
        }
      });

      var periodList = object.find('.dews-ui-periodpicker');
      $.each(periodList, function (i, period) {
        //var targetid = period.id;
        var target = self[period.id];
        var sbindid = $(period).attr("data-binding-start-colname");  
        var ebindid = $(period).attr("data-binding-end-colname");  
        if (target != undefined) {
          target.setStartDate(typeof dataRow[sbindid] === "undefined" ? "" : dataRow[sbindid]);
          target.setEndDate(typeof dataRow[ebindid] === "undefined" ? "" : dataRow[ebindid]);
        }
      });

      //codePicker관련
      var codepickerList = object.find(".dews-ui-codepicker");
      $.each(codepickerList, function (i, codepicker) {
        var target = self[codepicker.id];
        if (target != undefined) {
          var col = $(codepicker).attr("data-dews-code-field");
          var colname = $(codepicker).attr("data-dews-text-field");
          var code = dataRow[$(codepicker).attr("data-dews-bind-code")];
          var name = dataRow[$(codepicker).attr("data-dews-bind-text")];
          var objData = {};
          objData[col] = typeof code === "undefined" ? "" : code;
          objData[colname] = typeof name === "undefined" ? "" : name;
          target.setData(objData, false);
        }
      });

      //numeric관련
      var numericList = object.find(".dews-ui-numerictextbox");
      $.each(numericList, function (i, numeric) {
        
        var targetid = numeric.id;
        var target = self[numeric.id];
        var bindid = $(numeric).attr("data-binding-colname");
        if (bindid) {
          targetid = bindid;
        }
        if (target != undefined) {
          target.value(typeof dataRow[targetid] === "undefined" ? 0 : dataRow[targetid]);
        }
      });

      return ret;
    },
    /**
     * JQeryObject에 항목들에 데이터를 리셋합니다.
     * @example BINDING.bindingResetControls($('#content_ITAOTS00200 #tabJyunS'));
     * @param {*} object : jqueryObject
     * @param {*} dataRow : 데이터소스 행
     * @return {*} boolean : true (성공), false (실패)
     */
    bindingResetControls : function(self, object) {
      var ret = true;

      //td관련
      var tdList = object.find("td");
      $.each(tdList, function (i, target) {
        if (target.id != undefined && target.id != "") {
          target.innerHTML = "";
        }
      });

      //textBox관련
      var txtList = object.find(".dews-ui-textbox"), _txt;
      $.each(txtList, function (i, txt) {
        var target = self[txt.id];
        if (target != undefined) {
          target.text("");
        }
      });

      //dropDownList관련
      var dropList = object.find(".dews-ui-dropdownlist");
      $.each(dropList, function (i, drop) {
        var target = self[drop.id];
        if (target != undefined) {
          target.text("");
        }
      });

      //datePicker관련
      var dateList = object.find(".dews-ui-datepicker");
      $.each(dateList, function (i, date) {
        var target = self[date.id];
        if (target != undefined) {
          target.value("");
        }
      });

      //codePicker관련
      var codepickerList = object.find(".dews-ui-codepicker");
      $.each(codepickerList, function (i, codepicker) {
        var target = self[codepicker.id];
        if (target != undefined) {
          var col = $(codepicker).attr("data-dews-code-field");
          var colname = $(codepicker).attr("data-dews-text-field");
          var objData = {};
          objData[col] = "";
          objData[colname] = ""
          target.setData(objData, false);
        }
      });

      //numeric관련
      var numericList = object.find(".dews-ui-numerictextbox");
      $.each(numericList, function (i, numeric) {
        var target = self[numeric.id];
        if (target != undefined) {
          target.value(0);
        }
      });


      return ret;
    },
    /**
     * JQeryObject에 항목들에 데이터 바인딩합니다.
     * @example BINDING.getState($('#content_ITAOTS00200 #state'), dataRow);
     * @param {*} object : jqueryObject
     * @param {*} stateValue : 상태값
     * @return {*} boolean : true (성공), false (실패)
     */
    getState : function(object, stateValue) {
      var ret = true;
        //td관련
      var tdList = object.find("td");
      if (tdList.length > 0) {
        var target = tdList[0];

        //모든 클래스 삭제
        target.removeAttribute("class");
        //스타일 클래스 추가
        $(target).addClass("bt-state");

        //상태클래스 추가
        if (stateValue == "110") { //state-pending : orange -> 미평가
          $(target).addClass("state-pending");
        }
        else if (stateValue == "140") { //state-issue : orange -> 이슈 (icon)
          $(target).addClass("state-issue");
        }
        else if (stateValue == "120" || stateValue == "150" || stateValue == "170" || stateValue == "210" || stateValue == "141" || stateValue == "151") { //state-inprogress : blue -> ~중
          $(target).addClass("state-inprogress");
        }
        else if (stateValue == "220" || stateValue == "320" || stateValue == "340" || stateValue == "360" || stateValue == "380"
              || stateValue == "400" || stateValue == "420" || stateValue == "440" || stateValue == "460" || stateValue == "480"
              || stateValue == "820" || stateValue == "840") { //state-reject : red -> 반려
          $(target).addClass("state-reject");
        }
        else if (stateValue == "130" || stateValue == "160" || stateValue == "310" || stateValue == "330" || stateValue == "350"
              || stateValue == "370" || stateValue == "390" || stateValue == "410" || stateValue == "430" || stateValue == "450"
              || stateValue == "470" || stateValue == "710" || stateValue == "810" || stateValue == "830" || stateValue == "161") { //state-confirm : green -> 완료
          $(target).addClass("state-confirm");
        }
      }

      return ret;
    }

  };

  module.STATE = function() {
    return {
      self: {},
      initData: function(self) {
        var pself = this;
        pself.self = self;

        //차후 문구만 다국어 처리하세요.
        //연결 색상 - 진행중:#3071e8, 완료:#1249a1, 승인:#3fa684 (보류)
        //감사 색상 - 진행중:#3fa684, 완료:#faa733, 승인:#1249a1
        //연결 최소사이즈 적용 - min-width:72px
        var _html = '<label class="au-state-edit" style="color: #3fa684;min-width:72px;height: 27px;float: left;padding: 3px;border: 1px solid;text-align: center;margin-left:1px;display:none;">'
                  + '진행중' 
                  + '</label>' 
                  + '<label class="au-state-complete" style="color: #faa733;min-width:72px;height: 27px;float: left;padding: 3px;border: 1px solid;text-align: center;margin-left:1px;display:none;">'
                  + '완료'
                  + '</label>' 
                  + '<label class="au-state-confirm" style="color: #1249a1;min-width:72px;height: 27px;float: left;padding: 3px;border: 1px solid;text-align: center;margin-left:1px;display:none;">'
                  + '승인'
                  + '</label>'
                  + '<label class="au-state-nofinalize" style="color: #1249a1;min-width:72px;height: 27px;float: left;padding: 3px;border: 1px solid;text-align: center;margin-left:1px;display:none;">'
                  + '미확정'
                  + '</label>'
                  + '<label class="au-state-finalize" style="color: #1249a1;min-width:72px;height: 27px;float: left;padding: 3px;border: 1px solid;text-align: center;margin-left:1px;display:none;">'
                  + '확정'
                  + '</label>';
        
        if ($('.au-state', self.$content).length > 0) {
          $('.au-state', self.$content).first().prepend($(_html));
        }
      },
      setViewState: function(value) { // 0.not view, 1.진행중(완료취소), 2.완료(승인취소), 3.승인, 4.미확정, 5.확정
        var pself = this;
        if ($('.au-state-edit', pself.self.$content).length > 0) {
          $('.au-state-edit', pself.self.$content).css("display", "none");
          $('.au-state-complete', pself.self.$content).css("display", "none");
          $('.au-state-confirm', pself.self.$content).css("display", "none");
          $('.au-state-nofinalize', pself.self.$content).css("display", "none");
          $('.au-state-finalize', pself.self.$content).css("display", "none");

          if (value == "1") {
            $('.au-state-edit', pself.self.$content).css("display", "");
          }
          else if (value == "2") {
            $('.au-state-complete', pself.self.$content).css("display", "");
          }
          else if (value == "3") {
            $('.au-state-confirm', pself.self.$content).css("display", "");
          }
          else if (value == "4") {
            $('.au-state-nofinalize', pself.self.$content).css("display", "");
          }
          else if (value == "5") {
            $('.au-state-finalize', pself.self.$content).css("display", "");
          }
        }
      },
      /***
       * 해당되는 상태값을 저장한다.(pipe에서 대상이 되는것들만)
       * prgr_st_cd: 01.진행중,완료취소, 02.완료,승인취소, 03.승인
       * prgr_st_tp: 1.exec, 2.cancel
       */
      save : function(audit_chklist_tp, actg_yy, ver_no, dept_cd_pipe, emp_no_pipe, prgr_st_cd, prgr_st_tp) {
        var ret = false;

        dews.api.get(dews.url.getApiUrl("AU", "AuCommonService", "au_state_save"), {
          async: false,
          data: {
            audit_chklist_tp: audit_chklist_tp,
            actg_yy: actg_yy,
            ver_no: ver_no,
            dept_cd_pipe: dept_cd_pipe,
            emp_no_pipe: emp_no_pipe,
            prgr_st_cd: prgr_st_cd,
            prgr_st_tp: prgr_st_tp
          }
        }).done(function (data) {
          ret = data;
        });

        return ret;
      },
      getConfirm : function(audit_chklist_tp, actg_yy, ver_no) {
        var ret = false;

        dews.api.get(dews.url.getApiUrl("AU", "AuCommonService", "au_state_confirm"), {
          async: false,
          data: {
            audit_chklist_tp: audit_chklist_tp,
            actg_yy: actg_yy,
            ver_no: ver_no,
            confirm_tp: "1"
          }
        }).done(function (data) {
          ret = data;
        });

        return ret;
      },
      setConfirm : function(audit_chklist_tp, actg_yy, ver_no, is_confirm) { //true.확정, false.미확정
        var ret = false;

        dews.api.get(dews.url.getApiUrl("AU", "AuCommonService", "au_state_confirm"), {
          async: false,
          data: {
            audit_chklist_tp: audit_chklist_tp,
            actg_yy: actg_yy,
            ver_no: ver_no,
            confirm_tp: is_confirm ? "2" : "3"
          }
        }).done(function (data) {
          ret = data;
        });

        return ret;
      },
    };
  };

  module.DATE = {
    getYYYY: function(value) {
      var today = new Date();
      return (today.getFullYear() + value).toString();
    },
    /**
     * 날짜가져오기 (yyyyMM)
     * @example var yyyyMM = DATE.getDate(-1); -> 현재월기준 전달
     * @param {*} value 조정월 / nothing 현재월
     * @return {*} 년월
     */
    getDate: function(value) {

      var today = new Date();
      var yyyyMM;

      if (value > 0) {
        yyyyMM = (today.getFullYear() + Math.floor(value / 12) + Math.floor((today.getMonth() + 1 + (value % 12)) / 12)).toString()
              + ((today.getMonth() + 1 + (value % 12)) % 12).toString().replace(/^(\d)$/, '0$1');
      }
      else if (value == 0) {
        yyyyMM = today.getFullYear().toString() + (today.getMonth() + 1).toString().replace(/^(\d)$/, '0$1');
      }
      else {
        value = Math.abs(value);

        if (today.getMonth() + 1 - (value % 12) <= 0) {
          yyyyMM = (today.getFullYear() - 1 - Math.floor(value / 12)).toString()
                 + ((today.getMonth() + 1 - (value % 12)) == 0 ? 12 : (12 + (today.getMonth() + 1 - (value % 12))).toString().replace(/^(\d)$/, '0$1'));
        }
        else {
          yyyyMM = (today.getFullYear() - Math.floor(value / 12)).toString()
                + (today.getMonth() + 1 - (value % 12)).toString().replace(/^(\d)$/, '0$1');
        }
      }

      return yyyyMM;
    },
    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMM = DATE.getFirstDate(-1); -> 현재월기준 전달(yyyyMMdd)
     * @param {*} value 조정월
     * @return {*} 년월일(시작일 : 1일)
     */
    getFirstDate: function(value) {
      var yyyyMM = this.getDate(value);

      return yyyyMM + "01";
    },

    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMM = DATE.getLastDate(-1); -> 현재월기준 전달(yyyyMMdd)
     * @param {*} value 조정월
     * @return {*} 년월일(마지막일자)
     */
    getLastDate: function(value) {

      var yyyyMMdd;
      var yyyyMM = this.getDate(value);

      var ecdays =  new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
      var cyear = new Date(Number(yyyyMM.substr(0,4)), Number(yyyyMM.substr(4, 2)) - 1);
      if ((((cyear.getFullYear() % 4) == 0) && ((cyear.getFullYear() % 100) != 0)) || ((cyear.getFullYear() % 400) == 0)) ecdays[1] = 29;
      yyyyMMdd = yyyyMM + ecdays[cyear.getMonth()];

      return yyyyMMdd;
    },
    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMM = DATE.getFirstDateS("201801"); -> 현재월기준 전달
     * @param {*} value 조정월
     * @return {*} 년월일(시작일 : 1일)
     */
    getFirstDateS: function(value) {
      var today = new Date(Number(value.substr(0, 4)), Number(value.substr(4, 2)));

      var yyyyMMstart;
      if (today.getMonth() == 0) {
        today.setFullYear(today.getFullYear() - 1);
        yyyyMMstart = today.getFullYear().toString() + "12" + "01";
      }
      else {
        yyyyMMstart = today.getFullYear().toString() + today.getMonth().toString().replace(/^(\d)$/, "0$1");
        yyyyMMstart += "01";
      }

      return yyyyMMstart;
    },
    /**
     * 날짜가져오기 (yyyyMMdd)
     * @example var yyyyMM = DATE.getLastDateS("201801"); -> 현재월기준 전달
     * @param {*} value 조정월
     * @return {*} 년월일(마지막일)
     */
    getLastDateS: function(value) {
      var today = new Date(Number(value.substr(0, 4)), Number(value.substr(4, 2)));

      var yyyyMMstart, yyyyMMend;
      if (today.getMonth() == 0) {
        today.setFullYear(today.getFullYear() - 1);
        yyyyMMend = today.getFullYear().toString() + "12" + "31";
      }
      else {
        yyyyMMstart = today.getFullYear().toString() + today.getMonth().toString().replace(/^(\d)$/, "0$1");
        var ecdays =  new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
        var cyear = new Date(today.getFullYear(), today.getMonth() - 1);
        if ((((cyear.getFullYear() % 4) == 0) && ((cyear.getFullYear() % 100) != 0)) || ((cyear.getFullYear() % 400) == 0)) ecdays[1] = 29;
        yyyyMMend = yyyyMMstart + ecdays[cyear.getMonth()];
      }

      return yyyyMMend;
    },
    parseDateYYYYMMDD: function(str){
      var targetDate = new Date(str);
      var year = targetDate.getFullYear();
      var month = (targetDate.getMonth() + 1).toString();
      var date = targetDate.getDate().toString();

      if(month.length == 1){
        month = '0' + month;
      }

      if(date.length == 1){
        date = '0' + date;
      }

      return year + month + date;
    },
    parseDateYYYYMM: function(str){
      var targetDate = new Date(str);
      var year = targetDate.getFullYear();
      var month = (targetDate.getMonth() + 1).toString();

      if(month.length == 1){
        month = '0' + month;
      }

      return year + month;
    }
  }

  module.CODE = {
    get: function(code_fg, date_cd) {
      var ret = "";

      dews.api.get(dews.url.getApiUrl("AU", "AuCommonService", "au_common_code"), {
        async: false,
        data: {
          code_fg: code_fg, 
          date_cd: date_cd,
        }
      }).done(function (data) {
        ret = data;
      });

      return ret;
    }
  }

  module.DRS = {
    get: function() {
      return dews.ui.page.mainEnv.drsCode;
    }
  }

  module.GW = function() {
    return {
      self: {},
      class: '.gwfile-td',
      gwdocu_fgrp_sq: '',
      exclude_yn: 'Y',
      count: 1,
      evt: null,
      czgb: null,
      mode: "U",
      bg_delete: 'background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAOCAYAAAD0f5bSAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjlBNDU3QTQ4MUE5MDExRTg5MjRGRUQwNEZENjBGQzI3IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjlBNDU3QTQ5MUE5MDExRTg5MjRGRUQwNEZENjBGQzI3Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OUE0NTdBNDYxQTkwMTFFODkyNEZFRDA0RkQ2MEZDMjciIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OUE0NTdBNDcxQTkwMTFFODkyNEZFRDA0RkQ2MEZDMjciLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5Nf8oQAAAAQklEQVR42mJkwATFQKyGxL8OxBMYCICZBPgMjNgEiQUzSVHHRI4NTHhsnYnLFVSzaahrol88sUDp20TadgNEAAQYANXzCl0mUjPUAAAAAElFTkSuQmCC) no-repeat 50%;',
      bg_download: 'background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozNzU4QTYyMjNBMjA2ODExODIyQUU2QzQ2QjIzOEVDRiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDowM0QwOUZEQUM4MUMxMUU3QTBCMkExRjhDMDk3NEY2NiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDowM0QwOUZEOUM4MUMxMUU3QTBCMkExRjhDMDk3NEY2NiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RkE0Rjc3NzM0QjIwNjgxMTgyMkFFNkM0NkIyMzhFQ0YiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Mzc1OEE2MjIzQTIwNjgxMTgyMkFFNkM0NkIyMzhFQ0YiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4h8CFRAAAAkUlEQVR42mLcuXPnfwbC4AMQu7q5uZ1Bl2AEGeDs7IxT5969exlkZGQYnjx58hHIdUE3hIkI2xmEhIRAhvADmXt27dplSrIBf//+ZeDn52eQlZUFGbIbWY6FCP3vr169iswXJMkAYPgIoocJyV7AB1Bc0HTpB06FdXochA3ApWjUBfgBxdFInXSAnrpIAQABBgB4xi4LZIQXqwAAAABJRU5ErkJggg==) no-repeat 50%;',
      init: function(self, ctrlclass, itemcount, mode) {
        var my = this;
        my.self = self;

        if (ctrlclass) {
          my.class = ctrlclass;
        }

        //init
        //<button type='button' class='dews-ui-button ico-search ico-search-au'></button> \
        var gwfiletag = " \
            <div class='dews-ui-gwfile' data-dews-width='100%' data-dews-height='100%' style='min-width: 200px;'> \
              <div class='dews-gwfile-head'> \
                <div class='dews-button-group'> \
                  <input type='checkbox' class='dews-ui-checkbox dews-ui-gwfile-check'> \
                  <label class='dews-ui-title dews-ui-gwfile-title'>{mode_title}</label> \
                  <button type='button' class='dews-ui-button ico-add' {mode}></button> \
                  <button type='button' class='dews-ui-button ico-delete' {mode}></button> \
                </div> \
              </div> \
              <div class='dews-gwfile-contents'>	\
                <ul> \
                </ul> \
              </div> \
            </div> \
        ";

        if (mode) {
          my.mode = mode;
        }

        gwfiletag = gwfiletag.replaceAll("{mode}", my.mode == "D" ? "style='display:none;'" : "");
        gwfiletag = gwfiletag.replaceAll("{mode_title}", my.mode == "D" ? "문서목록" : "전체선택");

        $(my.class, self.$content).html($(gwfiletag));
        $(my.class, self.$content).trigger('inituicontrols');

        if(my.mode == "D") {
          $(my.class + ' .dews-checkbox-wrapper', self.$content).prop("style", "display:none;");
        }

        if (itemcount) {
          $(my.class + ' .dews-gwfile-contents', my.self.$content).prop("style", "overflow-y:auto;height:" + (27 * itemcount).toString() + "px");
        }
        else {
          $(my.class + ' .dews-gwfile-contents', my.self.$content).prop("style", "overflow-y:auto;height:" + ($('.gwfile-td', my.self.$content).height() - 28).toString() + "px");
        }          
        
        my.setBindYn(false);
        my.setCheckEabledT(false);

        $(my.class + ' .dews-ui-gwfile-check', my.self.$content).change(function() {
          my.setChecked();
        });

        //추가
        $(my.class + ' .dews-ui-gwfile .ico-add', my.self.$content).click(function() {          
          my.viewLoadPop();
        });

        //삭제
        $(my.class + ' .dews-ui-gwfile .ico-delete', my.self.$content).click(function() {

          var $this = $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li .dews-ui-gwfile-check-child', my.self.$content);
          var isDelete = false;
          for (var i = $this.length - 1; i >= 0; i--) {
            if ($($this[i]).prop("checked")) {
              isDelete = true;
              break;
            }
          }

          if (isDelete) {
            var confirm = dews.confirm("선택된 문서를 삭제하시겠습니까?", "ico2").yes(function(){
              confirm.dialog.dialog.bind('deactivate', function(){              
                for (var i = $this.length - 1; i >= 0; i--) {
                  if ($($this[i]).prop("checked")) {
                    my.deleteRow($($this[i]).parent().parent().find(".APRVL_ID").text());
                    $($this[i]).parent().parent().remove();
                  }
                }
                my.setCheckEabledH();
                my.event('N');
              })
            }).no(function(){
            });
          }
          else {
            dews.alert("선택된 문서가 없습니다.", "warning");
          }
        });

        //조회
        // $(my.class + ' .dews-ui-gwfile .ico-search', my.self.$content).click(function() {          
        //   my.bind(1);
        // });

        //customEvent
        my.evt = jQuery.Event("gwChange", { key: my.gwdocu_fgrp_sq, count:  my.count });
      },
      setBindYn: function (value) {
        var my = this;        
        if (!value) {
          $(my.class + ' .dews-ui-gwfile .dews-gwfile-head .dews-ui-button', my.self.$content).addClass("k-state-disabled");
          $(my.class + ' .dews-ui-gwfile .dews-gwfile-head .dews-ui-button', my.self.$content).prop("disabled", true);
        }
        else {
          $(my.class + ' .dews-ui-gwfile .dews-gwfile-head .dews-ui-button', my.self.$content).removeClass("k-state-disabled");
          $(my.class + ' .dews-ui-gwfile .dews-gwfile-head .dews-ui-button', my.self.$content).prop("disabled", false);
        }
      },
      bindKey: function (gwdocu_fgrp_sq) {
        var my = this;
        my.gwdocu_fgrp_sq = gwdocu_fgrp_sq;
      },
      bind: function (gwdocu_fgrp_sq) {
        var my = this;
        my.gwdocu_fgrp_sq = gwdocu_fgrp_sq;

        my.setBindYn(gwdocu_fgrp_sq !== undefined);

        if (gwdocu_fgrp_sq) {

          dews.api.get(dews.url.getApiUrl('AU', 'AuGWService', 'list_doc'), {
            async: false,
            data: {
              gwdocu_fgrp_sq: my.gwdocu_fgrp_sq
            }
          }).done(function (data) {
            
            $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul', my.self.$content).html('');

            if (data) {
              my.setListBind(data);              
            }
          }).fail(function (xhr, status, error) {          
            dews.alert("데이터 조회 오류입니다.", "error");
          });
        }
        else {
          my.setListClear();          
        }
      },
      viewLoadPop: function() {
        var my = this;

        var inputData = {
          gwdocu_fgrp_sq: my.gwdocu_fgrp_sq,
          exclude_yn: my.exclude_yn,
          menu_id: dews.ui.page.menu.id
        }

        return new Promise(function (resolve, reject) {
          var dialog = dews.ui.dialog("H_AU_GW_C", {
            url: "~/codehelp/AU/H_AU_GW_C",
            width: 1200,
            height: 535,
            title: "그룹웨어문서 목록",
            initData: inputData,
            ok: function (data) {

              //데이터 처리
              if (data) {

                dews.ui.loading.show({ 
                  type: 'tiny', 
                  target: my.class,
                  text: '데이터를 불러오고 있습니다.' 
                });

                setTimeout(function (e) {

                  if (data != null && data.length != 0) {
                    my.insertRows(data);
                    my.setListBind(data);                      
                    my.event('N');
                  }

                  dews.ui.loading.hide({
                    target: my.class
                  });

                });
              }
            }
          });

          dialog.open();
        });
      },
      athzInsertRow: function (data) {
        var my = this;

        dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'insert_doc_athz'), {
          async: false,
          data: {
            athz_rpts_cd: data,
            gwdocu_fgrp_sq: my.gwdocu_fgrp_sq
          }
        }).done(function (data) {
          
          if (my.gwdocu_fgrp_sq != "") {
            my.gwdocu_fgrp_sq = data;
          }     
          
          //my.event('Y');
        }).fail(function (xhr, status, error) {          
          dews.alert("데이터 추가 오류입니다.", "error");
        });  
        
        return my.gwdocu_fgrp_sq;
      },
      cleanGwDoc: function (data) {
        dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'clean_gwdoc'), {
          async: false,
          data: {
            menu_cd: data
          }
        }).done(function (data) {     
               
        }).fail(function (xhr, status, error) {          
        });  
      },
      reGwDoc: function () {
        dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'reupdate_gwdoc'), {
          async: false
        }).done(function (data) {     
               
        }).fail(function (xhr, status, error) {          
        }); 
      },
      insertRows: function (data) {
        var my = this;

        dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'insert_doc'), {
          async: false,
          data: {
            items: JSON.stringify(data),
            gwdocu_fgrp_sq: my.gwdocu_fgrp_sq
          }
        }).done(function (data) {
          
          if (my.gwdocu_fgrp_sq != "") {
            my.gwdocu_fgrp_sq = data;
          }         
        }).fail(function (xhr, status, error) {          
          dews.alert("데이터 추가 오류입니다.", "error");
        });
      },
      deleteRow: function (aprvl_id) {
        var my = this;

        dews.api.post(dews.url.getApiUrl('AU', 'AuGWService', 'delete_doc'), {
          async: false,
          data: {
            gwdocu_fgrp_sq: my.gwdocu_fgrp_sq,
            aprvl_id: aprvl_id
          }
        }).done(function (data) {
          
        }).fail(function (xhr, status, error) {          
          dews.alert("데이터 삭제 오류입니다.", "error");
        });
      },      
      link: function (aprvl_id, doc_no) {
        var my = this;
        if (module.DRS.get() == "10062") { //가스기술공사
          if (my.czgb == null) {
            dews.ajax.script('~/view/js/CZ/gb.common.js', {
              once: true,
              async: false
            }).done(function () {
              my.czgb = gerp.CZ.GB;
            });
            if (!my.self.user) {
              my.self.user = dews.ui.page.user;
            }
            my.czgb.initialize(my.self);
          }
          my.czgb.viewAthzDocumentByDocId(aprvl_id);
        }
        else {
          dews.alert(dews.string.format("결재번호 : {0}, 문서번호 : {1}", aprvl_id, doc_no));
        }
      },
      setListBind: function (data) {
        var my = this;

        $.each(data, function (i, row) {
          var addhtml = " \
            <li class style='width:100%'> \
              <input type='checkbox' class='dews-ui-checkbox dews-ui-gwfile-check-child'> \
              <span class='TITL_DC'>{TITL_DC}</span> \
              <span class='DOC_NM'>[{DOC_NO}]</span> \
              <span class='APRVL_ID' style='display:none;'>{APRVL_ID}</span> \
              <span class='DOC_NO' style='display:none;'>{DOC_NO}</span> \
              <span class='LINE_SQ' style='display:none;'>{LINE_SQ}</span> \
              <button class='btn-icon download'></button> \
              <button class='btn-icon delete'></button> \
            </li> \
          "
          addhtml = addhtml.replaceAll("{TITL_DC}", row.TITL_DC);
          addhtml = addhtml.replaceAll("{DOC_NO}", row.DOC_NO);
          addhtml = addhtml.replaceAll("{APRVL_ID}", row.APRVL_ID);
          addhtml = addhtml.replaceAll("{LINE_SQ}", row.LINE_SQ);

          $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul', my.self.$content).append($(addhtml));
          $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last', my.self.$content).trigger('inituicontrols');

          if(my.mode == "D") {
            $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .dews-checkbox-wrapper', self.$content).prop("style", "display:none;");
          }

          $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .download', my.self.$content).prop('style', my.bg_download);
          $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .delete', my.self.$content).prop('style', my.bg_delete);


          $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last span', my.self.$content).click(function(e) {
            var $this = $(this).parent().find(".dews-ui-gwfile-check-child");
            $this.prop("checked", !$this.prop("checked"));

            my.setCheckedH();
          });

          $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last span', my.self.$content).dblclick(function(e) {
            $(this).parent().find(".download").click();
          });

          $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .download', my.self.$content).click(function(e) {
            $this = $(this).parent();
            var aprvl_id = $this.find(".APRVL_ID").text();
            var doc_no = $this.find(".DOC_NO").text();
            my.link(aprvl_id, doc_no);
          });
          
          if (my.mode != "D") {
            $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .delete', my.self.$content).click(function(e) {                        
              var $this = $(this).parent();
              var confirm = dews.confirm("선택된 문서를 삭제하시겠습니까?", "ico2").yes(function(){
                confirm.dialog.dialog.bind('deactivate', function(){
                  my.deleteRow($this.find(".APRVL_ID").text());
                  $this.remove();
                  my.setCheckEabledH();
                  my.event('N');
                })
              }).no(function(){
              });
            });
          }
          else {
            $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .delete', my.self.$content).prop("style", "display:none;")
            $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li:last .delete', my.self.$content).removeClass('btn-icon');
          }
        });

        my.setCheckEabledH();
      },
      setListClear: function () {
        var my = this;
        $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul', my.self.$content).html('');
        my.setCheckEabledT(false);
      },
      setCheckEabledH() {
        var my = this;
        my.setCheckEabledT($(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li', my.self.$content).length != 0);
      },
      setCheckEabledT(value) { //상단 체크박스 활성화 여부        
        var my = this;
        if (!value) {
          $(my.class + ' .dews-ui-gwfile-check', my.self.$content).prop("checked", "");
        }
        $(my.class + ' .dews-ui-gwfile-check', my.self.$content).prop("disabled", value ? "" : "disabled");
      },
      setCheckedH() {
        var my = this;

        var $this = $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li .dews-ui-gwfile-check-child', my.self.$content);
        var _check = 0;
        var _nocheck = 0;
        for (var i = $this.length - 1; i >= 0; i--) {
          if ($($this[i]).prop("checked")) {
            _check++;
          }
          else {
            _nocheck++;
          }
        }
        my.setCheckedT(_check != 0 && _nocheck == 0);
      },
      setCheckedT(isCheck) { //상단 체크
        var my = this;     
        $(my.class + ' .dews-ui-gwfile-check', my.self.$content).prop("checked", isCheck ? "checked" : "");
      },
      setChecked() { //자식들 체크
        var my = this;     
        var isCheck = $(my.class + ' .dews-ui-gwfile-check', my.self.$content).prop("checked");
        $(my.class + ' .dews-ui-gwfile-check-child', my.self.$content).prop("checked", isCheck ? "checked" : "");
      },
      event(data) {
        var my = this;
        my.count = $(my.class + ' .dews-ui-gwfile .dews-gwfile-contents ul li', my.self.$content).length;
        my.evt.key = my.gwdocu_fgrp_sq;
        my.evt.count = my.count;
        my.evt.athz = data;
        $(my.class, my.self.$content).trigger(my.evt);
      }
    };
  }

  module.PRINT = {
    /**
     * 인쇄 호출.
     * @argument {String} reportId         : RPRT_CD 값 (ex.  "R_MLEMIA00400_0")
     * @argument {List} parameters params  : RPRT_CD, OBJECT_CD, PARA_CD, PARA_TXT
     */
    invoke: function (self, reportId, params) {

      /* 파라미터 저장 요청 */
      dews.api.post(dews.url.getApiUrl("CM", "printService", "setPrintParam"), {
        async : false,
        data : {
          reportCode : reportId,
          items : JSON.stringify(params)
        }
      }).done(function(data){
        /* 파라미터 키 리턴 */
        var parameterKey = data;

        if(parameterKey != "" && parameterKey != null){

          /* 인증토큰 */
          var authToken = JSON.parse(self.token).access_token;

          /* 출력물 정보 */
          var reportInfoUrl = window.location.protocol + "//" + window.location.host + dews.url.getApiUrl('CM','printService', 'getPrintFormList');

          /* DERPViewer 호출 */
          location.href = 'GERP://" "' + authToken + '" "' + reportId + '" "' + reportInfoUrl + '" "' + parameterKey + '" "' + (self.menu || {}).id;
        }
      });
    }
  };

  var newModule = {};
  newModule[moduleCode] = module;
  window.gerp = $.extend(true, gerp, newModule);
})(window.dews, window.gerp || {}, jQuery);

//# sourceURL=au.cm.js
